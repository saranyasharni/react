import React from 'react'
import { connect } from 'react-redux'
import { addClick } from '../actions'
import {FirstCount} from '../actions'

const ClickLink = ({ownProps, dispatch }) => {
	
	return (
		<button count= {FirstCount.InitialVal} onClick = {e => {

          e.preventDefault()
          dispatch(addClick('clicked'))
 
        }}>Click me here!</button>
	)
}

export default connect()(ClickLink)

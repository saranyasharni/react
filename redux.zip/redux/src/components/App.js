import React from 'react'
import Footer from './Footer'
import AddTodo from '../containers/AddTodo'
import VisibleTodoList from '../containers/VisibleTodoList'
import ClickLink from '../containers/ClickLink'
import Res from './restaurents'
import {BrowserRouter as Router,
Switch,
Route,
Link
} from "react-router-dom"

const App = () => (
<Router>
  	<div>
	    <AddTodo />
	    <VisibleTodoList />
	    <Footer />
	    <ClickLink />
  	</div>
  	<div>
  	<Link to ='/test'> test</Link>
  	</div>
    <Switch>
        <Route exact path="/test" component = {Res} />
    </Switch>
  </Router>
)

export default App
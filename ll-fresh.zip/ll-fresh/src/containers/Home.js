import { connect } from "react-redux";
import HomeComponent from "../components/HomePage";
import * as actions from "../actions/Home";
const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getCategories: () => {
      dispatch(actions.getCategories());
    },
    getEvents: () => {
      dispatch(actions.getEvents());
    }
  };
};

const Home = connect(mapStateToProps, mapDispatchToProps)(HomeComponent);

export default Home;

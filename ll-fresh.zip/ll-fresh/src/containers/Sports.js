import { connect } from "react-redux";
import SportsComponent from "../components/Sports";

const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const Sports = connect(mapStateToProps, mapDispatchToProps)(SportsComponent);

export default Sports;

import { connect } from "react-redux";
import LifeStyleComponent from "../components/LifeStyle";

const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const LifeStyle = connect(
  mapStateToProps,
  mapDispatchToProps
)(LifeStyleComponent);

export default LifeStyle;

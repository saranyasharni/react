import { connect } from "react-redux";
import HeaderComponent from "../../components/HomePageSections/Header";

const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const Header = connect(mapStateToProps, mapDispatchToProps)(HeaderComponent);
export default Header;

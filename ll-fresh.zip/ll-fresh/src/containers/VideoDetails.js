import { connect } from "react-redux";
import VideodetailsComponent from "../components/VideodetailsPage";

const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const Videodetails = connect(
  mapStateToProps,
  mapDispatchToProps
)(VideodetailsComponent);

export default Videodetails;

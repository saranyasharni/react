import { connect } from "react-redux";
import EntertainmentComponent from "../components/Entertainment";

const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const Entertainment = connect(
  mapStateToProps,
  mapDispatchToProps
)(EntertainmentComponent);

export default Entertainment;

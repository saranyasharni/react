import { connect } from "react-redux";
import FeaturedComponent from "../components/Featured";

const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const Featured = connect(
  mapStateToProps,
  mapDispatchToProps
)(FeaturedComponent);

export default Featured;

import config from "./API/Api_links";
import history from "../store/history";
//helper variable
export let email = "";

const AuthSuccess = data => ({
  type: "LOGIN_SUCCESS",
  payload: {
    loggedIn: true,
    email: data.email,
    name: data.name,
    plan: data.plan_name
  }
});
const AuthFailure = data => ({
  type: "ERORR",
  payload: data
});
export const setSignup = data => ({
  type: "SIGNUP_SUCCESS",
  payload: data
});
export const setError = data => ({
  type: "SET_ERROR"
});
const SignupFail = data => ({
  type: "ERORR",
  payload: data
});
const Logout = () => ({
  type: "LOGOUT"
});
const SetLoading = data => ({
  type: "SET_LOADING",
  payload: data
});
export const LoginAuth = data => {
  console.log(data);
  var myHeaders = new Headers();

  myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

  var urlencoded = new URLSearchParams();
  urlencoded.append("email", data.email);
  urlencoded.append("password", data.password);

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: urlencoded,
    redirect: "follow"
  };
  return dispatch => {
    dispatch(SetLoading(true));

    return fetch(config.login, requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data, "from auth");
        if (data.status === 1) {
          localStorage.setItem("token", data.token);
          localStorage.setItem("name", data.data.name);

          localStorage.setItem("email", data.data.email);
          localStorage.setItem("plan", data.data.plan_name);

          console.log(data, "data from signin");
          dispatch(AuthSuccess(data.data));
          dispatch(SetLoading(false));
        } else {
          dispatch(AuthFailure(data.message));
          dispatch(SetLoading(false));
        }
      })
      .catch(err => {
        dispatch(AuthFailure(err));
        dispatch(SetLoading(false));
        console.log(err);
      });
  };
};

export const LogoutAuth = email => {
  console.log(email, "email");
  var myHeaders = new Headers();

  myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

  var urlencoded = new URLSearchParams();
  urlencoded.append("email", email);

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: urlencoded,
    redirect: "follow"
  };
  return dispatch => {
    dispatch(SetLoading(true));

    return fetch(config.sign_out, requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        if (data.status === 1) {
          localStorage.removeItem("token");
          localStorage.removeItem("name");

          localStorage.removeItem("email");
          localStorage.removeItem("plan");

          dispatch(Logout());
          history.push("/");
          window.location.reload(true);
          dispatch(SetLoading(false));
        } else {
          dispatch(AuthFailure(data.message));
          dispatch(SetLoading(false));
        }
      });
  };
};

export const SignupAuth = values => {
  console.log(values);
  var myHeaders = new Headers();

  myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

  var urlencoded = new URLSearchParams();
  urlencoded.append("email", values.email);
  urlencoded.append("password", values.password);
  urlencoded.append("login_type", 1);
  urlencoded.append("register_type", "Free");
  urlencoded.append("mobileNumber", values.contact_number);
  urlencoded.append("name", values.name);

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: urlencoded,
    redirect: "follow"
  };
  return dispatch => {
    dispatch(SetLoading(true));

    return fetch(config.signup, requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data, "from auth");
        if (data.status === 1) {
          email = values.email;
          dispatch(setSignup(true));
          dispatch(SetLoading(false));
        } else {
          dispatch(SignupFail(data.message));
          dispatch(SetLoading(false));
        }
      })
      .catch(err => {
        dispatch(SignupFail(err));
        dispatch(SetLoading(false));
        console.log(err);
      });
  };
};

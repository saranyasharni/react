import config from "./API/Api_links";

export const categoriesData = data => ({
  type: "FETCH_CATEGORIES",
  payload: data
});
export const setCategory = data => ({
  type: "SET_CATEGORY",
  payload: data
});
export const eventsData = data => ({
  type: "FETCH_EVENTS",
  payload: data
});
export const getCategories = data => {
  return dispatch => {
    return fetch(config.categories2, {
      headers: {
        "x-app-id": 7386573047397500
      }
    })
      .then(res => {
        if (res.status === 200) {
          return res.json();
        } else {
          return res.json({
            error: true
          });
        }
      })
      .then(data => {
        dispatch(categoriesData(data.data));
      })
      .catch(error => dispatch(categoriesData(error)));
  };
};

export const getEvents = data => {
  let id = data !== undefined ? data : "bbd3d761-1247-4348-86fb-fe93893214a6";
  console.log(data);
  return dispatch => {
    return fetch(
      `https://api.live2.asia/api/v1/events?category_id=${id.toString()}`,
      {
        headers: {
          "x-app-id": 7386573047397500
        }
      }
    )
      .then(res => {
        if (res.status === 200) {
          return res.json();
        } else {
          return res.json({
            error: true
          });
        }
      })
      .then(data => {
        console.log(data, "from home actions");
        dispatch(eventsData(data.data));
      })
      .catch(error => dispatch(eventsData(error)));
  };
};

export const setlogin = data => ({
  type: "SET_LOGIN",
  payload: data
});
export const setLogin = data => {
  return dispatch => {
    dispatch(setlogin(data));
  };
};

export const getCategoryById = id => {
  console.log(id);
  return dispatch => {
    return fetch(config.categories3 + id)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        dispatch(setCategory(data));
      })
      .catch(err => {
        console.log(err, "from one catrgory");
      });
  };
};

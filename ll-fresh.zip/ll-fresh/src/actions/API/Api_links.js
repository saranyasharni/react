var siteUrl = "https://api.espx.cloud/api/v1";
var siteUrl2 = "https://api.live2.asia/api/v1";
var siteUrl3 = "https://api.live2.asia/api/v1/events?category_id=";
var siteUrl4 = "https://api.live2.asia/api/v1/categories/";
var authUrl =
  "http://ec2-54-169-154-79.ap-southeast-1.compute.amazonaws.com:5000";
var config = {
  categories: siteUrl + "/categories",
  events: siteUrl2 + "/events",
  categories2: siteUrl2 + "/categories",
  events2: siteUrl3,
  movies: siteUrl2 + "/movies",
  movies_recomended: siteUrl2 + "/movies-recommend",
  categories3: siteUrl4,
  login: authUrl + "/sign_in",
  signup: authUrl + "/sign_up",
  sign_out: authUrl + "/sign_out"
};
export default config;

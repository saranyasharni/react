import React, { Component, Fragment } from "react";
// import { _CONFIG } from './Live_Player'
// import { ESPxPlayer } from '../../js/ESPX_Player'
import MediaQuery from "react-responsive";

export default class Live_Stream extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pgId: props.id
    };
  }

  static getDerivedStateFromProps(props, state) {
    if (props.id !== state.pgId) {
      return {
        pgId: props.id
      };
    }
    return null;
  }
  componentDidMount() {
    this.addPlayer();
  }
  componentDidUpdate(prevProps) {
    if (prevProps.id !== this.props.id) {
      var element = document.getElementById("player");
      window.ESPxPlayer.destroyPlayer();
      element.parentNode.removeChild(element);
      this.addPlayer();
    }
  }

  addPlayer = () => {
    const elem2 = document.createElement("script");
    elem2.type = "text/javascript";
    elem2.src = "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
    elem2.id = "player";
    elem2.async = false;
    elem2.onload = () =>
      this.scriptLoaded(
        this.props.id ? this.props.id : "682134dd-b05d-4de5-b70e-d52177d3b983"
      );
    document.head.appendChild(elem2);
  };
  scriptLoaded(programmeID) {
    const _CONFIG = {
      divID: "#player-container",
      appID: "7386573047397500",
      autoPlay: false,
      config: "espxplayer",
      authorizationToken:
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImI0NzM1NDYzLWJkMWEtNGMyNy05MzFhLWUzOTdhYmY0MDY3YiIsInJvbGVzIjpbXSwiaWF0IjoxNTk1OTM4NTcxLCJleHAiOjE1OTYwMjQ5NzEsImlzcyI6IkVTUHhNZWRpYSJ9.8NesK03fNlB27sOljRDkZSvSf6SK2eEKcB9RNQd8QJo",
      programme_id: programmeID,
      countdown: true
    };
    window.ESPxPlayer.createPlayer(_CONFIG).then(p => {
      this.player = p;
    });
  }
  componentWillUnmount() {
    var element = document.getElementById("player");
    window.ESPxPlayer.destroyPlayer();
    element.parentNode.removeChild(element);
  }

  render() {
    return (
      <section className="live-stream container-fluid">
        <div className="row">
          {/* <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL + "/assets/images/livestream-banner.jpg"}
                        alt="livestream"
                    />
         
         <div className="live-option"> */}
          <MediaQuery minDeviceWidth={770}>
            <div
              id="player-container"
              style={{ width: "100%", height: "480px", maxWidth: "100%" }}
            ></div>
          </MediaQuery>

          <MediaQuery maxDeviceWidth={580}>
            <div
              id="player-container"
              style={{ width: "100%", height: "250px", maxWidth: "100%" }}
            ></div>
          </MediaQuery>
          <MediaQuery maxDeviceWidth={768}>
            <div
              id="player-container"
              style={{ width: "100%", height: "350px", maxWidth: "100%" }}
            ></div>
          </MediaQuery>

          {/* <div className="info">
                            <span className="stream mr-3">
                                <img className="mr-2" src={process.env.PUBLIC_URL + "/assets/images/live-video.svg"} alt="icon" />
                                    Live Streaming
                                </span>
                            <span className="view">
                                <img className="mr-1" src={process.env.PUBLIC_URL + "/assets/images/view.svg"} alt="icon" />
                                    139 views
                                </span>
                        </div>
                        <div className="timing">
                            <span>18:09</span>
                            <a href="javascript:;">
                                <img src={process.env.PUBLIC_URL + "/assets/images/fullscreen.svg"} alt="icon" />
                            </a>
                            <a href="javascript:;">
                                <img src={process.env.PUBLIC_URL + "/assets/images/volume.svg"} alt="icon" />
                            </a>
                        </div> */}
          {/* </div> */}
        </div>
      </section>
    );
  }
}

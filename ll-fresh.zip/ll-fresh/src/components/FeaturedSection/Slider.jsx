import React, { useEffect, useState } from "react";
import Carousel from "react-bootstrap/Carousel";
import slideone from "../../assets/images/sports-1.jpg";
import slidetwo from "../../assets/images/sports-2.jpg";
import slidethree from "../../assets/images/sports-3.jpg";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2
} from "react-html-parser";
import { Link } from "react-router-dom";
function Slider(props) {
  const [items, setItems] = useState(props.program);
  useEffect(() => {
    setItems(props.program);
  }, [props.program]);

  // useEffect(() => {
  //   console.log(items, "items");
  // }, [items]);
  return (
    <div>
      <section className="feeatured-slider">
        <div className="conatiner">
          <div className="row m-0">
            <h2 className="yellow">Featured</h2>
            <div className="col-sm-12 p-0">
              <span className="line"></span>
              <br />
              <div
                id="sports-slider-one"
                className="carousel slide"
                data-ride="carousel"
              >
                <div className="carousel-inner common-slider">
                  <Carousel>
                    <Carousel.Item>
                      <div className="row m-0">
                        <div className="col-sm-4 p-0 adjust-slider">
                          <div className="common-box">
                            <img
                              className="img-fluid"
                              src={slideone}
                              alt="First slide"
                            />
                            <div className="box-content">
                              <h3>First slide label</h3>
                              <p>Nulla vitae elit liberoa pharetra.</p>
                            </div>
                          </div>
                        </div>
                        <div className="col-sm-4 p-0 adjust-slider">
                          <div className="common-box">
                            <img
                              className="img-fluid"
                              src={slidetwo}
                              alt="First slide"
                            />
                            <div className="box-content">
                              <h3>First slide label</h3>
                              <p>Nulla vitae elit liberoa pharetra.</p>
                            </div>
                          </div>
                        </div>
                        <div className="col-sm-4 p-0 adjust-slider">
                          <div className="common-box">
                            <img
                              className="img-fluid"
                              src={slidethree}
                              alt="First slide"
                            />
                            <div className="box-content">
                              <h3>First slide label</h3>
                              <p>Nulla vitae elit liberoa pharetra.</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Carousel.Item>

                    <Carousel.Item>
                      <div className="row m-0">
                        <div className="col-sm-4 p-0 adjust-slider">
                          <div className="common-box">
                            <img
                              className="img-fluid"
                              src={slideone}
                              alt="First slide"
                            />
                            <div className="box-content">
                              <h3>First slide label</h3>
                              <p>Nulla vitae elit liberoa pharetra.</p>
                            </div>
                          </div>
                        </div>
                        <div className="col-sm-4 p-0 adjust-slider">
                          <div className="common-box">
                            <img
                              className="img-fluid"
                              src={slidetwo}
                              alt="First slide"
                            />
                            <div className="box-content">
                              <h3>First slide label</h3>
                              <p>Nulla vitae elit liberoa pharetra.</p>
                            </div>
                          </div>
                        </div>
                        <div className="col-sm-4 p-0 adjust-slider">
                          <div className="common-box">
                            <img
                              className="img-fluid"
                              src={slidethree}
                              alt="First slide"
                            />
                            <div className="box-content">
                              <h3>First slide label</h3>
                              <p>Nulla vitae elit liberoa pharetra.</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Carousel.Item>
                  </Carousel>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="feeatured-slider">
        <div className="conatiner">
          <div className="row m-0">
            <h2 className="yellow">{props.name}</h2>
            <div className="col-sm-12 p-0">
              <span className="line"></span>
              <br />
              <div
                id="sports-slider-one"
                className="carousel slide"
                data-ride="carousel"
              >
                <div className="carousel-inner common-slider">
                  <Carousel>
                    <Carousel.Item>
                      <div className="row m-0">
                        {!items ? (
                          ""
                        ) : (
                          <>
                            {" "}
                            {items.slice(0, 3).map(item => {
                              return (
                                <div
                                  className="col mx-1 p-0 adjust-slider2"
                                  key={item.id}
                                >
                                  <Link
                                    to={{
                                      pathname: `/program/details`,
                                      state: {
                                        pgId: item.id
                                      }
                                    }}
                                  >
                                    <div className="common-box">
                                      <img
                                        className="d-block w-100"
                                        src={item.img_url}
                                        alt="First slide"
                                      />
                                      <div className="box-content">
                                        <h3>{item.name}</h3>
                                        <p>{ReactHtmlParser(item.descr)}</p>
                                      </div>
                                    </div>
                                  </Link>
                                </div>
                              );
                            })}
                          </>
                        )}
                      </div>
                    </Carousel.Item>

                    <Carousel.Item>
                      <div className="row m-0">
                        {!items ? (
                          ""
                        ) : (
                          <>
                            {" "}
                            {items.slice(3, 8).map(item => {
                              return (
                                <div
                                  className="col mx-1 p-0 adjust-slider2"
                                  key={item.id}
                                >
                                  <div className="common-box">
                                    <img
                                      className="d-block w-100"
                                      src={item.img_url}
                                      alt="First slide"
                                    />
                                    <div className="box-content">
                                      <h3>{item.name}</h3>
                                      <p>{ReactHtmlParser(item.descr)}</p>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </>
                        )}
                      </div>
                    </Carousel.Item>
                  </Carousel>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Slider;

import React, { useState, useEffect } from "react";
import Flickity from "react-flickity-component";
import ReactHtmlParser from "react-html-parser";
import { Link } from "react-router-dom";
const CarouselSlider = props => {
  const [items, setItems] = useState(props.program);
  useEffect(() => {
    setItems(props.program);
  }, [props.program]);
  const flickityOptions = {
    wrapAround: false,
    pageDots: false,
    cellAlign: "center",
    contain: true
  };
  return (
    <div className="my-5">
      <h2 className="yellow ml-5">{props.name}</h2>
      <span className="line ml-5 mb-5"></span>

      <Flickity
        options={flickityOptions}
        className={"carousel"}
        reloadOnUpdate={true}
      >
        {!items ? (
          ""
        ) : (
          <>
            {items.map(item => {
              return (
                <Link
                  to={{
                    pathname: "/program/details",
                    state: {
                      pgId: item.id
                    }
                  }}
                >
                  {" "}
                  
                  <div key={item.id} className="common-box mr-5">
                    
                    <img
                      src={item.img_url}
                      // style={{ width: "300px", height: "300px" }}
                      alt="slider"
                    />
                    <div className="box-content">
                      <h3>{item.name}</h3>
                      <p>{ReactHtmlParser(item.descr)}</p>
                    </div>
                  </div>
                </Link>
              );
            })}
          </>
        )}
      </Flickity>
    </div>
  );
};

export default CarouselSlider;

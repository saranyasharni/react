import React, { useState, useEffect } from "react";
import Searchbox from "./Searchbox";
import Cardinfobox from "./Cardinfobox";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
function Searchpage() {
  const [query, setQuery] = useState("");
  const handleChange = event => {
    setQuery(event.target.value);
    console.log(event.target.value);
  };
  return (
    <div>
      <Header />
      <Searchbox query={query} change={handleChange} />
      <Cardinfobox query={query} />
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </div>
  );
}

export default Searchpage;

import React, { useState, useEffect } from "react";
import Slider from "./EntertainmentSection/Slider";
import Header from "./HomePageSections/Header";
import Footer from "./HomePageSections/Footer";
function Entertainment(props) {
  const [item, setItem] = useState([]);
  useEffect(() => {
    console.log(props);
    let data = props.categories.filter(item => {
      return item.name === "Entertainment";
    });
    setItem(data[0]);
  }, []);
  useEffect(() => {
    console.log(item);
  }, [item]);
  return (
    <>
      <Header />
      <section className="entertainment-banner relative">
        <div className="banner-text">
          <h1>Red Bull Rampage 2020</h1>
          <p>{item.descr}</p>
        </div>
      </section>
      <Slider />
      <Footer />
    </>
  );
}

export default Entertainment;

import React from 'react';
import { Button, Form, FormGroup, Input, Label } from 'react-bootstrap';

function ContributorPageDetails() {
    return (
        <>
            <div className="container contributors-section">
               <div className="row">
                  <div className="col-sm-8 col-offset-2">
                    <h1>Contribute with us</h1><br/>
                    <p>Please ensure the given details are correct and our experts will get in touch with you shortly</p>
                    <Form>
                        <Form.Group controlId="formBasictext" className="relative">                        
                        <Form.Control type="text" placeholder="Enter Name" />
                        <span className="icon-contribute"><i class="fa fa-user-o" aria-hidden="true"></i></span>                     
                        </Form.Group>

                        <Form.Group controlId="formBasicEmail" className="relative">                        
                        <Form.Control type="email" placeholder="Enter Email" />   
                        <span className="icon-contribute"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>                  
                        </Form.Group>

                        <Form.Group controlId="formBasicnumber" className="relative">                        
                        <Form.Control type="text" placeholder="Mobile Number" />     
                        <span className="icon-contribute"><i class="fa fa-phone" aria-hidden="true"></i></span>                
                        </Form.Group>

                        <Form.Group controlId="formBasicnCategory" className="relative">
                        <Form.Control as="select" >
                         <option>Latest Features</option>
                         <option>Sports Entertainment</option>
                         <option>Lifestyle News</option>
                         <option>Latest News Events</option>
                        </Form.Control>
                        <span className="icon-contribute"><i class="fa fa-th-large" aria-hidden="true"></i></span>
                        </Form.Group>

                        <Form.Group controlId="exampleForm.ControlTextarea1">                        
                        <Form.Control as="textarea" rows="3" placeholder="Message" />                       
                        
                        <span className="icon-contribute" style={{position: 'absolute', top: '38rem',left: '2rem'}}><i class="fa fa-comments-o" aria-hidden="true"></i>
                        </span>
                        </Form.Group>

                        <Button variant="primary" type="submit" className="contribtuor-button">
                         Submit Details
                        </Button>
                    </Form>
                  </div>
               </div>
            </div>
        </>
    )
}

export default ContributorPageDetails

import React from 'react'
import { Accordion, Card, Button } from 'react-bootstrap';

function Jobpagedetails() {
    return (
        <>
        <div className="container Jobdetail-section">
            <div className="row">
                <div className="col-sm-10 col-offset-1 col-xs-12">
                   <div className="job-details-section">
                   <Accordion defaultActiveKey="0">           
  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="0">
      <div className="job-header-details">
       <h2>Research Developer in Advertising</h2>
       <p>KOLKATTA <span><i class="fa fa-calendar" aria-hidden="true"></i> Jan 12, 2020</span></p>
       </div>
       <div className="text-right cta">
         <button className="btn btn-primary">Apply</button>
        </div>
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="0">
      <Card.Body>
         <h4>About the Role</h4>
         <p>At Live Live, we have 300 million users and capture close to a billion click stream messages daily. The engineering team at Live Live is at the center of the action and is responsible for creating unmatched user experience. Our engineers solve real life complex problems and create compelling experiences for our customers.</p>
         <br/><h4>Your key responsibilities</h4>
         <ul>
             <li>Key contributor of continuous improvements in the quality of the ads targeting and ads delivery.</li>
         <li>Keep track of both industry and academic research trends in related areas, including but not limited to ad targeting and delivery, machine learning and distributed computation.</li>
         <li>Participate in ad projects planning with product managers and the team based on data-driven investigation methods and industry trends.</li>
         <li>Propose, implement, test and verify algorithmic solutions for upcoming ads product features</li>
         </ul>
         <br/><h4>Qualification</h4>
         <ul>
             <li>Master degree or above. 3+ years industry experience of practical algorithm design and implementation in ads or machine learning related fields. Experience in ad server will be a plus.</li>
             <li>Strong mathematics, computer and machine learning background.</li>
             <li>Ability to master new technology in short time and apply to solve practical problems.</li>
         </ul><br/>
         <div className="text-center cta">
         <button className="btn btn-primary">Apply</button>
         </div>
 
        
      </Card.Body>
    </Accordion.Collapse>
  </Card>
  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="1">
    <div className="job-header-details">
    <h2>Senior Research Developer in AD Platform</h2>
       <p>MAHARASTRA <span><i class="fa fa-calendar" aria-hidden="true"></i> April 11, 2020</span></p>
    </div>
      <div className="text-right cta">
         <button className="btn btn-primary">Apply</button>
        </div>
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="1">
      <Card.Body>
      <h4>About the Role</h4>
         <p>At Live Live, we have 300 million users and capture close to a billion click stream messages daily. The engineering team at Live Live is at the center of the action and is responsible for creating unmatched user experience. Our engineers solve real life complex problems and create compelling experiences for our customers.</p>
         <br/><h4>Your key responsibilities</h4>
         <ul>
             <li>Key contributor of continuous improvements in the quality of the ads targeting and ads delivery.</li>
         <li>Keep track of both industry and academic research trends in related areas, including but not limited to ad targeting and delivery, machine learning and distributed computation.</li>
         <li>Participate in ad projects planning with product managers and the team based on data-driven investigation methods and industry trends.</li>
         <li>Propose, implement, test and verify algorithmic solutions for upcoming ads product features</li>
         </ul>
         <br/><h4>Qualification</h4>
         <ul>
             <li>Master degree or above. 3+ years industry experience of practical algorithm design and implementation in ads or machine learning related fields. Experience in ad server will be a plus.</li>
             <li>Strong mathematics, computer and machine learning background.</li>
             <li>Ability to master new technology in short time and apply to solve practical problems.</li>
         </ul><br/>
         <div className="text-center cta">
         <button className="btn btn-primary">Apply</button>
         </div>
      </Card.Body>
    </Accordion.Collapse>
  </Card>


  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="2">
    <div className="job-header-details">
    <h2>Senior Software Development Engineer - Android</h2>    
       <p>CHENNAI <span><i class="fa fa-calendar" aria-hidden="true"></i> May 12, 2020</span></p>
    </div>
       <div className="text-right cta">
         <button className="btn btn-primary">Apply</button>
        </div>
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="2">
      <Card.Body>
      <h4>About the Role</h4>
         <p>At Live Live, we have 300 million users and capture close to a billion click stream messages daily. The engineering team at Live Live is at the center of the action and is responsible for creating unmatched user experience. Our engineers solve real life complex problems and create compelling experiences for our customers.</p>
         <br/><h4>Your key responsibilities</h4>
         <ul>
             <li>Key contributor of continuous improvements in the quality of the ads targeting and ads delivery.</li>
         <li>Keep track of both industry and academic research trends in related areas, including but not limited to ad targeting and delivery, machine learning and distributed computation.</li>
         <li>Participate in ad projects planning with product managers and the team based on data-driven investigation methods and industry trends.</li>
         <li>Propose, implement, test and verify algorithmic solutions for upcoming ads product features</li>
         </ul>
         <br/><h4>Qualification</h4>
         <ul>
             <li>Master degree or above. 3+ years industry experience of practical algorithm design and implementation in ads or machine learning related fields. Experience in ad server will be a plus.</li>
             <li>Strong mathematics, computer and machine learning background.</li>
             <li>Ability to master new technology in short time and apply to solve practical problems.</li>
         </ul><br/>
         <div className="text-center cta">
         <button className="btn btn-primary">Apply</button>
         </div>
      </Card.Body>
    </Accordion.Collapse>
  </Card>

  

  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="3">
    <div className="job-header-details">
    <h2>Senior Software Developer in iOS Mobile Development</h2>
       <p>BANGALORE <span><i class="fa fa-calendar" aria-hidden="true"></i> Jan 19, 2019</span></p>
     </div>
       <div className="text-right cta">
         <button className="btn btn-primary">Apply</button>
        </div>
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="3">
      <Card.Body>
      <h4>About the Role</h4>
         <p>At Live Live, we have 300 million users and capture close to a billion click stream messages daily. The engineering team at Live Live is at the center of the action and is responsible for creating unmatched user experience. Our engineers solve real life complex problems and create compelling experiences for our customers.</p>
         <br/><h4>Your key responsibilities</h4>
         <ul>
             <li>Key contributor of continuous improvements in the quality of the ads targeting and ads delivery.</li>
         <li>Keep track of both industry and academic research trends in related areas, including but not limited to ad targeting and delivery, machine learning and distributed computation.</li>
         <li>Participate in ad projects planning with product managers and the team based on data-driven investigation methods and industry trends.</li>
         <li>Propose, implement, test and verify algorithmic solutions for upcoming ads product features</li>
         </ul>
         <br/><h4>Qualification</h4>
         <ul>
             <li>Master degree or above. 3+ years industry experience of practical algorithm design and implementation in ads or machine learning related fields. Experience in ad server will be a plus.</li>
             <li>Strong mathematics, computer and machine learning background.</li>
             <li>Ability to master new technology in short time and apply to solve practical problems.</li>
         </ul><br/>
         <div className="text-center cta">
         <button className="btn btn-primary">Apply</button>
         </div>
      </Card.Body>
    </Accordion.Collapse>
  </Card>
</Accordion>
                   </div>
                 </div>
            </div>
        </div> 
     </> 
    )
}

export default Jobpagedetails

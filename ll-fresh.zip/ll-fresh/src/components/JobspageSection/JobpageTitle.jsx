import React from 'react'

function JobpageTitle() {
    return (
        <>
           <div className="container Jobtitle-section">
               <div className="row">
                   <div className="col-sm-8 col-offset-2 col-xs-12">
                       <h1>Current Job Openings</h1>
                       
                    </div>
               </div>
           </div> 
        </> 
    )
}

export default JobpageTitle

import React from "react";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";

import HeroComponent from "./HomePageSections/HeroComponent";
import RecommendedChannels from "./HomePageSections/RecommendedChannels";
import Advertisement from "./HomePageSections/Advertisement";
import EntertainmentNews from "./HomePageSections/EntertainmentNews";
import ConfirmationDialog from "./AuthSection/ConfirmationDialog";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";

function Home(props) {
  const { categories } = props;
  React.useEffect(() => {
    props.getCategories();
  }, []);
  React.useEffect(() => {
    console.log(props);
  }, [props]);
  return (
    <div>
      <Header />
      <ConfirmationDialog />
      <HeroComponent items={categories} />
      <section className="live-news-feed">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-8 col-sm-8 col-xs-12 latest-news-sections">
              <EntertainmentNews
                title={true}
                cat_id="0ece8134-fbcd-4091-82b0-54cad4cec4b3"
                title_value="SPORTS"
                title_small="sports"
              />
              <EntertainmentNews
                title={true}
                cat_id="e09be9c3-910d-40e4-b935-b539389660bd"
                title_value="ENTERTAINMENT"
                title_small="entertainment"
              />
              <EntertainmentNews
                title={true}
                cat_id="afe5d562-b0a3-4d65-90d7-3a59f42e092f"
                title_value="LIFE STYLE"
                title_small="life style"
              />
              <EntertainmentNews
                title={true}
                cat_id="83442ec6-f09c-40e4-87fc-bd666e67bd04"
                title_value="NEWS & INSIGHTS"
                title_small="news & insights"
              />
            </div>
            <div className="col-md-4 col-sm-4 col-xs-12 channel-sections">
              <RecommendedChannels />
              <Advertisement />
              <RecommendedChannels />
              <Advertisement />
              <Advertisement />
            </div>
          </div>
        </div>
      </section>
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav name="Home" />
      </MediaQuery>
    </div>
  );
}

export default Home;

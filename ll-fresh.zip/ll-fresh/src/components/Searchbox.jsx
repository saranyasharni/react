import React from "react";

function Searchbox(props) {
  return (
    <>
      <div className="container-fluid search-bg relative">
        <div className="search-text">
          <div className="col-md-6 offset-md-3 col-xs-8 offset-xs-2">
            <h4 clasName="text-center">
              Search programms eg:badmiton,sports2 etc...
            </h4>
            <div className="input-group">
              <input
                type="text"
                class="form-control"
                placeholder="Search ......"
                aria-label="Recipient's username"
                value={props.query}
                onChange={props.change}
              />
              <div className="input-group-append">
                <span className="input-group-text">
                  <i class="fa fa-search"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Searchbox;

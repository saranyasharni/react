import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import config from "../actions/API/Api_links";
function Recommendedvideo(props) {
  const [program, setProgram] = useState([]);
  useEffect(() => {
    fetch(config.movies_recomended + `?movie_id=${props.id}`, {
      headers: {
        "x-app-id": 7386573047397500,
        token:
          "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjA5MTNlNjg1LWM5NTYtNDYxYS1iYzMzLWU0ZmZhZjk3ZGJmMyIsInJvbGVzIjpbXSwiaWF0IjoxNTkzNzgzNTEwLCJleHAiOjE1OTM4Njk5MTAsImlzcyI6Im1QbGF5In0.tNUZFIXDm9aUPLQWZSm1Bfrla5exOsuRNaPGH-_m-hI"
      }
    })
      .then(res => res.json())
      .then(data => {
        setProgram(data);
      });
  }, [props]);
  return (
    <>
      {/* <div className="relative">
        <h4 className="recom-hedings">Recommended Videos</h4>
      </div> */}

      <div className="right-side-recommended">
        <div className="img-holders">
          {!program.length
            ? ""
            : program.slice(0, 5).map(item => {
                return (
                  <>
                    <div className="img__container-wraper d-flex">
                      <div
                        // onClick={() => props.handleVideo(item.id)}
                        className="img-container relative"
                      >
                        <Link to={`/program/details/${item.id}`}>
                          <img
                            src={item.img_url}
                            alt=""
                            className="img-fluid"
                          />
                          <div className="play-icons">
                            <i class="fa fa-play" aria-hidden="true"></i>
                          </div>
                        </Link>
                      </div>

                      <div className="img__container-info">
                        <div className="img__container-title">Sample Video</div>
                        <div className="img__container-small">
                          Description asjhdgasjhdgcj
                        </div>
                      </div>
                    </div>
                  </>
                );
              })}
        </div>
      </div>
    </>
  );
}

export default Recommendedvideo;

import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import BottomNavigation from "@material-ui/core/BottomNavigation";
import BottomNavigationAction from "@material-ui/core/BottomNavigationAction";
import { Link } from "react-router-dom";
import { ReactComponent as HomeIcon } from "../../assets/images/home_icon.svg";
import { ReactComponent as LikeIcon } from "../../assets/images/heart2.svg";
import { ReactComponent as WatchListIcon } from "../../assets/images/watch_list.svg";
import { ReactComponent as PlanIcon } from "../../assets/images/plans_icon.svg";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
const useStyles = makeStyles({
  root: {
    width: "100%",
    backgroundColor: "black",
    position: "fixed",
    bottom: "0"
  }
});

export default function BottomNav(props) {
  const classes = useStyles();
  const [value, setValue] = React.useState(props.name);
  React.useEffect(() => {
    console.log(value);
    setValue(props.name);
  }, [props.name]);
  return (
    <BottomNavigation
      value={value}
      // onChange={(event, newValue) => {
      //   console.log("called");
      //   console.log("new", newValue);
      //   setValue(newValue);
      // }}
      showLabels
      className={classes.root}
    >
      {" "}
      <BottomNavigationAction
        label="Home"
        value="Home"
        icon={
          <>
            {" "}
            <Link to="/">
              <HomeIcon />
            </Link>
          </>
        }
      />
      <BottomNavigationAction
        label="WatchList"
        value="WatchList"
        icon={
          <>
            <Link to="/home/watchlist">
              <WatchListIcon />
            </Link>
          </>
        }
      />
      <BottomNavigationAction
        label="My Likes"
        value="MyLikes"
        icon={
          <Link to="/home/mylikes">
            <LikeIcon />
          </Link>
        }
      />
      <BottomNavigationAction
        label="Plans"
        value="Plans"
        icon={
          <Link to="/home/plans">
            <PlanIcon />
          </Link>
        }
      />
      <BottomNavigationAction
        label="Account"
        value="Account"
        icon={
          <Link to="/home/myaccount">
            {" "}
            <AccountCircleIcon style={{ fontSize: "25px", color: "#ff8a00" }} />
          </Link>
        }
      />
    </BottomNavigation>
  );
}

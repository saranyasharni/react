import React, { useState } from "react";
import Carousel from "react-bootstrap/Carousel";
function SmCarousel(props) {
  const [data, setData] = useState(props.items);
  React.useEffect(() => {
    console.log(props.items);
    setData(props.items);
  }, [props.items]);
  return (
    <div>
      <Carousel>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://bit.ly/2VRHIEO"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>Sample</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://bit.ly/2VRHIEO"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>Sample</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://bit.ly/2VRHIEO"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>Sample</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    </div>
  );
}

export default SmCarousel;

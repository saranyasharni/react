import React from "react";
import { useMediaQuery } from "react-responsive";
import { Link } from "react-router-dom";
import MediaQuery from "react-responsive";
// npm install react-animated-slider
import Slider from "react-animated-slider";
import SmCarousel from "./SmCarousel";
import Carousel from "react-bootstrap/Carousel";

function HeroComponent(props) {
  const [data, setData] = React.useState([]);
  React.useEffect(() => {
    console.log(props.items);
    setData(props.items);
  }, [props.items]);
  const isTabletOrMobile = useMediaQuery({ query: "(max-width: 680px)" });
  return (
    <div>
      <MediaQuery minDeviceWidth={581}>
        <section className="main-banner">
          <div className="container-fluid">
            <div className="row">
              <div className="col-md-6 col-sm-12 col-12 p-0 pointer-link hero-left">
                {isTabletOrMobile
                  ? !props.items
                    ? ""
                    : props.items.slice(0, 1).map(item => {
                        return (
                          <Link
                            to={{
                              pathname: `/category/Featured/${item.name.replace(
                                /\s+/g,
                                ""
                              )}/${item.id}`,
                              state: {
                                data: item.id
                              }
                            }}
                            className="hero__link"
                          >
                            {" "}
                            <div
                              className="banner-one relative common-zoom"
                              style={{
                                backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),url(${item.img})`,
                                height: "100%",
                                backgroundSize: "cover",
                                backgroundPosition: "center",
                                backgroundRepeat: "no-repeat"
                              }}
                            >
                              <div className="inner-banner">
                                <h1 className="text-truncate">{item.name}</h1>
                              </div>
                            </div>
                          </Link>
                        );
                      })
                  : !props.items
                  ? ""
                  : props.items.slice(0, 1).map(item => {
                      return (
                        <Link
                          to={{
                            pathname: `/category/Featured/${item.name.replace(
                              /\s+/g,
                              ""
                            )}/${item.id}`,
                            state: {
                              data: item.id
                            }
                          }}
                        >
                          {" "}
                          <div className="inner-banner">
                            <h1 className="text-truncate">{item.name}</h1>
                          </div>
                          <div
                            className="banner-one relative common-zoom"
                            style={{
                              backgroundImage: `url(${item.img})`,
                              height: "100%",
                              backgroundSize: "cover",
                              backgroundPosition: "center",
                              backgroundRepeat: "no-repeat"
                            }}
                          >
                            
                          </div>{" "}
                        </Link>
                      );
                    })}
              </div>
              <div className="col-md-6 p-0 hero-right">
                <div className="col-12 p-0 pointer-link hero-right-top">
                {!props.items
                  ? ""
                  : props.items.slice(13, 15).map(item => {
                      return (
                        <Link
                          to={{
                            pathname: `/category/Featured/${item.name.replace(
                              /\s+/g,
                              ""
                            )}/${item.id}`,
                            state: {
                              data: item.id
                            }
                          }}
                        >
                          {" "}
                          <div className="inner-banner">
                              <h1 className="text-truncate">{item.name}</h1>
                            </div>
                          <div
                            className="banner-two relative common-zoom"
                            style={{
                              backgroundImage: `url(${item.img})`,
                              height: "100%",
                              backgroundSize: "cover",
                              backgroundPosition: "center",
                              backgroundRepeat: "no-repeat"
                            }}
                          >
                            
                          </div>
                        </Link>
                      );
                    })}
              </div>
                <div className="col-12 p-0 pointer-link hero-right-bottom">
                {!props.items
                  ? ""
                  : props.items.slice(9, 12).map(item => {
                      return (
                        <Link
                          to={{
                            pathname: `/category/Featured/${item.name.replace(
                              /\s+/g,
                              ""
                            )}/${item.id}`,
                            state: {
                              data: item.id
                            }
                          }}
                        >
                          {" "}
                          <div className="inner-banner">
                              <h1 className="text-truncate">{item.name}</h1>
                            </div>
                          <div
                            className="banner-four relative common-zoom"
                            style={{
                              backgroundImage: `url(${item.img})`,
                              height: "100%",
                              backgroundSize: "cover",
                              backgroundPosition: "center",
                              backgroundRepeat: "no-repeat"
                            }}
                          >
                            
                          </div>
                        </Link>
                      );
                    })}
              </div>
              </div>
              </div>
          </div>
        </section>
      </MediaQuery>
      <MediaQuery maxDeviceWidth={580}>
        <section className="main-banner">
          <div className="container-fluid">
            <div className="row">
              <div className="col-12 p-0 pointer-link hero-left">
                {!props.items
                  ? ""
                  : props.items.slice(0, 1).map(item => {
                      return (
                        <Link
                          to={{
                            pathname: `/category/Featured/${item.name.replace(
                              /\s+/g,
                              ""
                            )}/${item.id}`,
                            state: {
                              data: item.id
                            }
                          }}
                          className="hero__link"
                        >
                          {" "}
                          <div
                            className="banner-one relative common-zoom"
                            style={{
                              backgroundImage: `url(${item.img})`,
                              height: "100%",
                              backgroundSize: "cover",
                              backgroundPosition: "center",
                              backgroundRepeat: "no-repeat"
                            }}
                          >
                            <div className="inner-banner">
                              <h1 className="text-truncate">{item.name}</h1>
                            </div>
                          </div>
                        </Link>
                      );
                    })}
              </div>
              <div className="col-12 hero-right p-0">
                <div className="col-12 p-0 pointer-link hero-right-top">
                  {!props.items
                    ? ""
                    : props.items.slice(13, 15).map(item => {
                        return (
                          <Link
                            to={{
                              pathname: `/category/Featured/${item.name.replace(
                                /\s+/g,
                                ""
                              )}/${item.id}`,
                              state: {
                                data: item.id
                              }
                            }}
                          >
                            {" "}
                            <div
                              className="banner-two relative common-zoom"
                              style={{
                                backgroundImage: `url(${item.img})`,
                                height: "100%",
                                backgroundSize: "cover",
                                backgroundPosition: "center",
                                backgroundRepeat: "no-repeat"
                              }}
                            >
                              <div className="inner-banner">
                                <h1 className="text-truncate">{item.name}</h1>
                              </div>
                            </div>
                          </Link>
                        );
                      })}
                </div>
                <div className="col-12 p-0 pointer-link hero-right-bottom">
                {!props.items
                  ? ""
                  : props.items.slice(9, 12).map(item => {
                      return (
                        <Link
                          to={{
                            pathname: `/category/Featured/${item.name.replace(
                              /\s+/g,
                              ""
                            )}/${item.id}`,
                            state: {
                              data: item.id
                            }
                          }}
                        >
                          {" "}
                          <div
                            className="banner-four relative common-zoom"
                            style={{
                              backgroundImage: `url(${item.img})`,
                              height: "100%",
                              backgroundSize: "cover",
                              backgroundPosition: "center",
                              backgroundRepeat: "no-repeat"
                            }}
                          >
                            <div className="inner-banner">
                              <h1 className="text-truncate">{item.name}</h1>
                            </div>
                          </div>
                        </Link>
                      );
                    })}
              </div>
              </div>
            </div>
          </div>
        </section>
      </MediaQuery>
    </div>
  );
}

export default HeroComponent;

import React from "react";
import Recommendone from "../../assets/images/recommend-1.jpg";
import Recommendtwo from "../../assets/images/recommend-2.jpg";
import Recommendthree from "../../assets/images/recommend-3.jpg";

function RecommendedChannels() {
  return (
    <div>
      <div className="recommend-head">
        <h3>Recommended Channels</h3>
      </div>
      <div className="recommend-channel-section">
        <div className="img-sec">
          <img src={Recommendone} alt="" className="img-fluid" />
        </div>
        <div className="content_rec">
          <p>This girl is matered in classical dance</p>
          <a href="#">More about this</a>
          <div className="subscribe relative">
            {" "}
            <p>Subscribe </p>
            <span>2.7k</span>
          </div>
        </div>
      </div>
      <div className="recommend-channel-section">
        <div className="img-sec">
          <img src={Recommendtwo} alt="" className="img-fluid" />
        </div>
        <div className="content_rec">
          <p>This girl is matered in classical dance</p>
          <a href="#">More about this</a>
          <div className="subscribe relative">
            {" "}
            <p>Subscribe </p>
            <span>2.7k</span>
          </div>
        </div>
      </div>
      <div className="recommend-channel-section">
        <div className="img-sec">
          <img src={Recommendthree} alt="" className="img-fluid" />
        </div>
        <div className="content_rec">
          <p>This girl is matered in classical dance</p>
          <a href="#">More about this</a>
          <div className="subscribe relative">
            {" "}
            <p>Subscribe </p>
            <span>2.7k</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RecommendedChannels;

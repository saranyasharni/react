import React from "react";

function Plans() {
  return (
    <div id="accountmodal">
      <div className="table-responsive">
        <table className="table table-borderless">
          <thead>
            <tr>
              <th scope="col" className="inner-head"></th>
              <th scope="col"></th>
              <th scope="col">Free</th>

              <th scope="col">Standard</th>
              <th scope="col">Premium</th>
            </tr>
          </thead>
          <tbody>
            <tr className="grey">
              <td>Uninterrupted Viewing</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="dark-grey">
              <td>Unlimited Downloads</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="grey">
              <td>Stream Cast Enabled</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="dark-grey">
              <td>Access To LIIVE Content</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="grey">
              <td>SameDay Release</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="dark-grey">
              <td>Major Events Coverage</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="grey">
              <td>All Access Pass</td>
              <td></td>
              <td>
                <i className="fa fa-times" aria-hidden="true"></i>{" "}
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
              <td>
                <i className="fa fa-check" aria-hidden="true"></i>
              </td>
            </tr>
            <tr className="blue-bg">
              <td></td>
              <td></td>
              <td className="yel-bg">Free</td>
              <td className="yel-bg">Standard</td>
              <td className="yel-bg">Premium</td>
            </tr>
          </tbody>
        </table>
        <div className="tab-bot-content">
          <small>
            <span style={{ color: "orange", marginRight: "5px" }}>"Free"</span>
            plans subscribers whom are registered via email or Facebook will
            have limited access to recorded and on-demand content.
          </small>
          <br />
          <small>
            <span style={{ color: "orange", marginRight: "5px" }}>
              "Standard"
            </span>
            plans subscribers will have access to all content and selected LIVE
            events.
          </small>
          <br />
          <small>
            <span style={{ color: "orange", marginRight: "5px" }}>
              "Premium"
            </span>
            " plans subscribers will have access all content and secured
            broadcast content in LIVE and recorded format for the duration of
            the events.
          </small>
          <br />
          <small>
            For the full terms and conditions, please refer to the
            <span style={{ color: "orange", marginLeft: "5px" }}>
              Terms and Conditions
            </span>
          </small>
        </div>
        <br />
        <div className="table-footer-img text-center">
          {/* <img src="images/g-1.jpg" alt=""/>
     <img src="images/g-2.jpg" alt=""/>
     <img src="images/fb-fb.png" alt=""/>
     <img src="images/twitter.png" alt=""/>
     <img src="images/insta.png" alt=""/>
     <img src="images/youtube.png" alt=""/> */}
        </div>
      </div>
    </div>
  );
}

export default Plans;

import React from "react";
import logo from "../../assets/images/logo.png";
import { Navbar, Nav } from "react-bootstrap";
import { Link } from "react-router-dom";
import LoginSection from "../AuthSection/LoginSection";
import SignupSection from "../AuthSection/SignupSection";
import AccountSection from "./AccountSection";
import { connect } from "react-redux";
import MediaQuery from "react-responsive";
import SideBar from "./SideBar";
import SearchIcon from "@material-ui/icons/Search";
function Header(props) {
  return (
    <>
      <MediaQuery minDeviceWidth={801}>
        <Navbar
          collapseOnSelect
          expand="lg"
          className="main-navbar"
          variant="dark"
        >
          <MediaQuery maxDeviceWidth={800} minDeviceWidth={540}>
            <SideBar />
          </MediaQuery>
          <Navbar.Brand>
            <Link
              className="navbar-brand mr-0 ml-md-2 ml-lg-5 pl-lg-5"
              to="/"
              aria-label="Bootstrap"
            >
              <img src={logo} alt="" />
            </Link>
          </Navbar.Brand>

          {/* <Navbar.Toggle aria-controls="responsive-navbar-nav" /> */}
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="mr-auto">
              <Link className="nav-link mr-lg-4" to="/main/Featured">
                Featured
              </Link>
              <Link className="nav-link mr-lg-4" to="/main/Sports">
                Sports
              </Link>
              <Link className="nav-link mr-lg-4 " to="/main/Entertainment">
                Entertainment
              </Link>
              <Link className="nav-link mr-lg-4" to="/main/Lifestyle">
                Lifestyle
              </Link>
              <Link className="nav-link mr-lg-4" to="/main/newsInsights">
                News & Insights
              </Link>
            </Nav>
            <Nav className="mr-lg-5">
              <Link className="nav-link mr-lg-3" to="/search/programms">
                Search
              </Link>
            </Nav>
          </Navbar.Collapse>
          <Nav className="mr-lg-5">
            {!props.login ? (
              <>
                <Nav.Link className="mr-lg-5">Library</Nav.Link>
                <LoginSection />
                <SignupSection />
              </>
            ) : (
              <AccountSection />
            )}
          </Nav>
        </Navbar>
      </MediaQuery>

      {/* //for tablets */}

      <MediaQuery maxDeviceWidth={800} minDeviceWidth={580}>
        <Navbar
          collapseOnSelect
          expand="lg"
          className="main-navbar"
          variant="dark"
        >
          <div className="d-flex align-items-center">
            <MediaQuery maxDeviceWidth={800}>
              <SideBar />
            </MediaQuery>
            <Navbar.Brand className="align-self-start">
              <Link className="navbar-brand" to="/" aria-label="Bootstrap">
                <img src={logo} alt="" />
              </Link>
            </Navbar.Brand>
          </div>
          <Nav className="d-flex">
            {" "}
            <Link className="nav-link" to="/search/programms">
              <SearchIcon style={{ fontSize: 40, color: "white" }} />
            </Link>
            <Nav>
              {!props.login ? (
                <>
                  <LoginSection />
                  <SignupSection />
                </>
              ) : (
                <AccountSection />
              )}
            </Nav>
          </Nav>
        </Navbar>
      </MediaQuery>

      {/* //for Mobiles */}

      <MediaQuery maxDeviceWidth={580}>
        <Navbar
          collapseOnSelect
          expand="lg"
          className="main-navbar"
          variant="dark"
        >
          <MediaQuery maxDeviceWidth={800}>
            <SideBar />
          </MediaQuery>
          <Navbar.Brand className="align-self-start-md">
            <Link className="navbar-brand" to="/" aria-label="Bootstrap">
              <img src={logo} alt="" />
            </Link>
          </Navbar.Brand>
          {/* <Nav className="d-flex"> */}{" "}
          <Link className="nav-link" to="/search/programms">
            <SearchIcon style={{ fontSize: 40, color: "white" }} />
          </Link>
          {/* <Nav>
              {!props.login ? (
                <>
                  <LoginSection />
                  <SignupSection />
                </>
              ) : (
                <AccountSection />
              )}
            </Nav> */}
          {/* </Nav> */}
        </Navbar>
      </MediaQuery>
    </>
  );
}
const mapStateToProps = (state, ownProps) => {
  return {
    login: state.Auth.loggedIn
  };
};

export default connect(mapStateToProps, null)(Header);

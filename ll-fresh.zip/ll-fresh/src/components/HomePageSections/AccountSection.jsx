import { ReactComponent as ArrowIcon } from "../../assets/icons/arrow.svg";
import { ReactComponent as Arrow } from "../../assets/images/arrow_left.svg";
import { ReactComponent as Share } from "../../assets/images/share.svg";
import { ReactComponent as Plus } from "../../assets/images/add.svg";
import { ReactComponent as Like } from "../../assets/images/heart.svg";
import { Link } from "react-router-dom";
import Avatar from "@material-ui/core/Avatar";
import React, { useState, useEffect, useRef } from "react";
import { CSSTransition } from "react-transition-group";
import { makeStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import Plans from "./Plans";
import * as actions from "../../actions/Home";
import { LogoutAuth } from "../../actions/Auth";
const list = [1, 2, 3, 4, 5, 6];

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    "& > *": {
      margin: theme.spacing(1)
    }
  },
  small: {
    width: theme.spacing(3),
    height: theme.spacing(3)
  },
  large: {
    width: theme.spacing(6),
    height: theme.spacing(6),
    cursor: "pointer",
    border: "3px solid orange"
  }
}));

function AccountSection(props) {
  const classes = useStyles();

  const [open, setOpen] = useState(false);

  return (
    <li className="nav-item mr-lg-5">
      {/* <a href="#" className="icon-button" onClick={() => setOpen(!open)}>
        sample
      </a> */}
      <Avatar onClick={() => setOpen(!open)} className={classes.large}>
        H
      </Avatar>
      {open && (
        <DropdownMenu
          name={props.name}
          email={props.email}
          plan={props.plan}
          logoutAuth={props.LogoutAuth}
        ></DropdownMenu>
      )}
    </li>
  );
}

function DropdownMenu(props) {
  const [activeMenu, setActiveMenu] = useState("main");
  const [menuHeight, setMenuHeight] = useState(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    setMenuHeight(dropdownRef.current?.firstChild.offsetHeight);
  }, []);

  function calcHeight(el) {
    const height = el.offsetHeight;
    setMenuHeight(height);
  }

  function DropdownItem(props) {
    useEffect(() => {
      console.log(props, "from drop");
    }, []);
    return (
      <Link
        to={props.link ? props.link : "#"}
        className="menu-item"
        onClick={() => props.goToMenu && setActiveMenu(props.goToMenu)}
      >
        {/* <span className="icon-button">{props.leftIcon}</span> */}
        {props.children}
        {/* <span className="icon-right">{props.rightIcon}</span> */}
      </Link>
    );
  }

  return (
    <div
      className={activeMenu === "main" ? "dropdown" : "dropdown2"}
      style={
        activeMenu === "main"
          ? {
              height: "280px",
              width: "200px",
              transform: "translateX(-70%)"
            }
          : activeMenu === "account"
          ? {
              height: "550px",
              width: "300px",
              transform: "translateX(-80%)"
            }
          : activeMenu === "plans"
          ? {
              width: "80vw",
              transform: "translateX(-100%)"
            }
          : {
              height: "500px",
              width: "500px",
              transform: "translateX(-88%)",
              border: "1px solid orange"
            }
      }
      ref={dropdownRef}
    >
      <CSSTransition
        in={activeMenu === "main"}
        timeout={500}
        classNames="menu-primary"
        unmountOnExit
        onEnter={calcHeight}
      >
        <div className="menu">
          <DropdownItem goToMenu="account">My Account</DropdownItem>
          <DropdownItem goToMenu="watchlist">My Watch List</DropdownItem>
          <DropdownItem goToMenu="likes">My Likes</DropdownItem>

          <DropdownItem goToMenu="plans">Plans</DropdownItem>
          <DropdownItem link="/helpcenter">Help Center</DropdownItem>
        </div>
      </CSSTransition>

      <CSSTransition
        in={activeMenu === "account"}
        timeout={500}
        classNames="menu-secondary"
        unmountOnExit
        onEnter={calcHeight}
      >
        <div className="menu__acc">
          <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
            <Arrow /> <h2>My Account</h2>
          </DropdownItem>
          <div
            className="menu__acc-signout"
            onClick={() => {
              props.logoutAuth(props.email);
            }}
          >
            Sign Out
          </div>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcReiyHYtDJQ0t5jCs4j_PiD5ESMvPwnvHVa3w&usqp=CAU"
            className="menu__acc-profile"
            alt="profile"
          />
          <div className="menu__acc-name">{props.name}</div>
          <div className="menu__acc-member">{props.plan} Membership</div>
          <div className="menu__acc-upgrade">
            <DropdownItem goToMenu="plans">Upgrade</DropdownItem>
          </div>
          <div className="menu__acc-share">Share and Invite Friends</div>
          <div className="menu__acc-changepass">Change Password</div>
        </div>
      </CSSTransition>

      <CSSTransition
        in={activeMenu === "watchlist"}
        timeout={500}
        classNames="menu-secondary"
        unmountOnExit
        onEnter={calcHeight}
      >
        <div className="menu__watch">
          <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
            <Arrow /> <h2>My Watch List</h2>
          </DropdownItem>
          <div className="watch__wrapper">
            {list.map(i => {
              return (
                <>
                  <div className="watch__card">
                    <img
                      src="https://bit.ly/38cxZ0U"
                      alt=""
                      className="watch__card-img"
                    />
                    <div className="watch__card-desc ml-3">
                      <div className="watch__card-title">AVENGERS ENDGAME</div>
                      <div className="watch__card-info">
                        <span className="watch__card-info-1">Sci-fi</span>
                        <span className="watch__card-info-2">2019</span>
                        <span className="watch__card-info-3">M18</span>
                      </div>

                      <div className="watch__card-icon">
                        <div className="mr-2 d-flex heart">
                          {" "}
                          <Like /> 23
                        </div>
                        <div className="mr-2">
                          {" "}
                          <Share />
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </CSSTransition>

      <CSSTransition
        in={activeMenu === "likes"}
        timeout={500}
        classNames="menu-secondary"
        unmountOnExit
        onEnter={calcHeight}
      >
        <div className="menu__watch">
          <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
            <Arrow /> <h2>My Likes</h2>
          </DropdownItem>
          <div className="watch__wrapper">
            {list.map(i => {
              return (
                <>
                  <div className="watch__card">
                    <img
                      src="https://bit.ly/38cxZ0U"
                      alt=""
                      className="watch__card-img"
                    />
                    <div className="watch__card-desc ml-3">
                      <div className="watch__card-title">AVENGERS ENDGAME</div>
                      <div className="watch__card-info">
                        <span className="watch__card-info-1">Sci-fi</span>
                        <span className="watch__card-info-2">2019</span>
                        <span className="watch__card-info-3">M18</span>
                      </div>

                      <div className="watch__card-icon">
                        <div className="mr-2 d-flex heart">
                          {" "}
                          <Like /> 23
                        </div>
                        <div className="mr-2">
                          {" "}
                          <Share />
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </CSSTransition>

      <CSSTransition
        in={activeMenu === "plans"}
        timeout={500}
        classNames="menu-secondary"
        unmountOnExit
        onEnter={calcHeight}
      >
        <div className="menu__plan">
          <DropdownItem goToMenu="main" leftIcon={<ArrowIcon />}>
            <Arrow /> <h2>Plans</h2>
          </DropdownItem>
          <Plans />
        </div>
      </CSSTransition>
    </div>
  );
}
const mapStateToProps = (state, ownProps) => {
  const { name, email, plan } = state.Auth;
  return {
    name,
    email,
    plan
  };
};
const mapDispatchToProps = (dispatch, state) => {
  return {
    LogoutAuth: data => {
      dispatch(LogoutAuth(data));
    }
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(AccountSection);

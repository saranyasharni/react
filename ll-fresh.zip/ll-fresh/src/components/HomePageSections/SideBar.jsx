import React from "react";
import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import Button from "@material-ui/core/Button";
import List from "@material-ui/core/List";
import Divider from "@material-ui/core/Divider";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import InboxIcon from "@material-ui/icons/MoveToInbox";
import MailIcon from "@material-ui/icons/Mail";
import MenuIcon from "@material-ui/icons/Menu";
import IconButton from "@material-ui/core/IconButton";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import LoginSection from "../AuthSection/LoginSection";
import SignupSection from "../AuthSection/SignupSection";
import { Nav } from "react-bootstrap";
import { Link } from "react-router-dom";
const useStyles = makeStyles(theme => ({
  list: {
    width: 250,
    fontSize: "2rem",
    color: "#ff8a00"
  },
  fullList: {
    width: "auto"
  },
  sidebartext: {
    fontSize: "2rem"
  },
  drawerHeader: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    justifyContent: "flex-start"
  }
}));

export default function SideBar() {
  const classes = useStyles();
  const [state, setState] = React.useState({
    top: false,
    left: false,
    bottom: false,
    right: false
  });

  const toggleDrawer = (anchor, open) => event => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };

  const list = anchor => (
    <div
      className={clsx(classes.list, {
        [classes.fullList]: anchor === "top" || anchor === "bottom"
      })}
      role="presentation"
      onClick={toggleDrawer(anchor, false)}
      onKeyDown={toggleDrawer(anchor, false)}
    >
      <h2 style={{ color: "white", margin: "1em 1em" }}>Categories</h2>
      <Divider />
      <List>
        {[
          "Sports",
          "Featured",
          "Entertainment",
          "Lifestyle",
          "News&Insights"
        ].map((text, index) => {
          if (text === "News&Insights") {
            text = "newsInsights";
          }
          return (
            <>
              <ListItem button key={text}>
                {/* <ListItemIcon>
              {index % 2 === 0 ? (
                <InboxIcon style={{ fontSize: 30, color: "#ff8a00" }} />
              ) : (
                <MailIcon style={{ fontSize: 30, color: "#ff8a00" }} />
              )}
            </ListItemIcon> */}
                <Link to={`/main/${text}`} style={{ color: "#ff8a00" }}>
                  <ListItemText
                    primary={text}
                    className={classes.sidebartext}
                  />
                </Link>
              </ListItem>
            </>
          );
        })}
      </List>
    </div>
  );

  return (
    <div>
      <React.Fragment key="left">
        <Button onClick={toggleDrawer("left", true)}>
          <MenuIcon style={{ fontSize: 40, color: "orange" }} />
        </Button>
        <Drawer
          anchor="left"
          open={state["left"]}
          onClose={toggleDrawer("left", false)}
        >
          {list("left")}
        </Drawer>
      </React.Fragment>
    </div>
  );
}

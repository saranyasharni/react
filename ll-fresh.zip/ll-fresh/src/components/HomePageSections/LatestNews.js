import React, { useEffect } from "react";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2
} from "react-html-parser";
import { Link } from "react-router-dom";
import { Card } from "react-bootstrap";
function LatestNews(props) {
  const item = props.items;
  useEffect(() => {
    console.log(props.items);
  }, [props]);

  return (
    <div>
      {!item
        ? ""
        : item.map(i => {
            return (
              <>
                <Link
                  className="nav-link "
                  to={{
                    pathname: `/category/${i.name.replace(/\s+/g, "")}`,
                    state: {
                      data: i.id
                    }
                  }}
                >
                  {" "}
                  <Card className="bg-dark text-white  list__card mb-5">
                    <Card.Img
                      src={i.img}
                      alt="Card image"
                      style={{
                        width: "100%",
                        height: "200px"
                      }}
                    />
                    <Card.ImgOverlay>
                      <Card.Title className="card__title">{i.name}</Card.Title>
                      <Card.Text>{i.descr}</Card.Text>
                      <Card.Text>{i.no_of_views}</Card.Text>
                    </Card.ImgOverlay>
                  </Card>
                </Link>
              </>
            );
          })}
    </div>
  );
}

export default LatestNews;

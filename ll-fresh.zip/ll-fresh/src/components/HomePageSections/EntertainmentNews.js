import React, { useEffect, useState } from "react";
import { ReactComponent as Share } from "../../assets/images/share.svg";
import { ReactComponent as Plus } from "../../assets/images/add.svg";
import { ReactComponent as Like } from "../../assets/images/heart.svg";
import { ReactComponent as Star } from "../../assets/images/star.svg";
import {
  FacebookIcon,
  FacebookShareButton,
  WhatsappShareButton,
  WhatsappIcon,
  TwitterIcon,
  TwitterShareButton
} from "react-share";
import ReactHtmlParser from "react-html-parser";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import { Link } from "react-router-dom";
import config from "../../actions/API/Api_links";
function EntertainmentNews(props) {
  const [item, setItem] = useState([]);
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };
  useEffect(() => {
    console.log(props.cat_id, "cat_id");
  }, [props.cat_id]);
  const handleClose = () => {
    setAnchorEl(null);
  };
  useEffect(() => {
    let url = props.id
      ? config.movies + `?event_id=${props.id}`
      : props.cat_id
      ? config.movies + `?category_id=${props.cat_id}`
      : config.movies;

    fetch(url)
      .then(res => res.json())
      .then(data => {
        setItem(data.data);
      });
  }, [props.cat_id, props.id]);
  return (
    <div>
      <>
        <div className="sports-news">
          <div className="sports-heading">
            {props.title && (
              <>
                {" "}
                <h2
                  style={{
                    color: "orange",
                    fontSize: "4rem",
                    fontWeight: "400"
                  }}
                >
                  {props.title_value}
                </h2>
                <h4>Top {props.title_small} Moments</h4>
              </>
            )}
          </div>
          {item.slice(0, 4).map(item => {
            return (
              <>
                <div className="sports-content" key={item.id}>
                  <div className="sports-one">
                    <img src={item.img_url} className="img-fluid" alt="" />
                  </div>
                  <div className="inner-content">
                    <small>TRENDING</small>
                    <h3>{item.name}</h3>
                    <div className="like-details">
                      <p>
                        <i className="fa fa-film" aria-hidden="true"></i>
                        <span>Most popular so far</span>
                      </p>
                      <p>
                        <i className="fa fa-clock-o" aria-hidden="true"></i>
                        <span>Added 6 months ago</span>
                      </p>
                    </div>
                    <p>
                      {ReactHtmlParser(
                        // !item.descr ? "" : item.descr.slice(0, 100)
                        item.descr
                      )}
                    </p>
                    <br />
                    <div className="d-flex align-items-center justify-content-md-end">
                      <span>
                        <span
                          className="mr-3 mr-md-1"
                          style={{ cursor: "pointer" }}
                        >
                          <Share
                            aria-controls="simple-menu"
                            aria-haspopup="true"
                            onClick={handleClick}
                          />
                          <Menu
                            id="simple-menu"
                            anchorEl={anchorEl}
                            keepMounted
                            open={Boolean(anchorEl)}
                            onClose={handleClose}
                          >
                            <MenuItem onClick={handleClose}>
                              <WhatsappShareButton
                                url={`http://ec2-18-138-252-117.ap-southeast-1.compute.amazonaws.com:3000/program/details/${item.id}`}
                                title={item.name}
                                separator=":: "
                              >
                                <WhatsappIcon size={32} round />
                              </WhatsappShareButton>
                            </MenuItem>
                            <MenuItem onClick={handleClose}>
                              <FacebookShareButton
                                url={`http://ec2-18-138-252-117.ap-southeast-1.compute.amazonaws.com:3000/program/details/${item.id}`}
                                quote={item.name}
                              >
                                <FacebookIcon size={32} round />
                              </FacebookShareButton>
                            </MenuItem>
                            <MenuItem onClick={handleClose}>
                              <TwitterShareButton
                                url={`http://ec2-18-138-252-117.ap-southeast-1.compute.amazonaws.com:3000/program/details/${item.id}`}
                                title={item.name}
                              >
                                <TwitterIcon size={32} round />
                              </TwitterShareButton>
                            </MenuItem>
                          </Menu>
                        </span>
                        <span
                          className="mr-3 mr-md-1  pg__like"
                          style={{ cursor: "pointer" }}
                        >
                          {" "}
                          <Like />
                        </span>
                        <span style={{ cursor: "pointer" }}>
                          {" "}
                          <Star />
                        </span>
                      </span>
                      <Link
                        to={{
                          pathname: `/program/details/${item.id}`
                        }}
                      >
                        <button className="btn btn-default read-more ml-3 ml-md-1">
                          VIEW MORE
                        </button>
                      </Link>
                    </div>
                  </div>
                </div>
                <div className="gap"></div>
              </>
            );
          })}
        </div>
      </>
    </div>
  );
}

export default EntertainmentNews;

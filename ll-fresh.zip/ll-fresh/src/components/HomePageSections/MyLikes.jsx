import React from "react";
import { ReactComponent as ArrowIcon } from "../../assets/icons/arrow.svg";
import { ReactComponent as Arrow } from "../../assets/images/arrow_left.svg";
import { ReactComponent as Share } from "../../assets/images/share.svg";
import { ReactComponent as Plus } from "../../assets/images/add.svg";
import { ReactComponent as Like } from "../../assets/images/heart.svg";
import { Link } from "react-router-dom";
import Header from "../../containers/common/Header";
import Footer from "./Footer";
import BottomNav from "./BottomNav";
import { LogoutAuth } from "../../actions/Auth";
import { connect } from "react-redux";
import { Nav } from "react-bootstrap";
import LoginSection from "../AuthSection/LoginSection";
import SignupSection from "../AuthSection/SignupSection";
const list = [1, 2, 3, 4, 5, 6];

function MyLikes(props) {
  React.useEffect(() => {
    console.log(props);
  }, [props]);
  return (
    <>
      <Header />
      {props.loggedIn ? (
        <div className="menu__watch">
          <h2>My Likes</h2>
          <div className="watch__wrapper">
            {list.map(i => {
              return (
                <>
                  <div className="watch__card">
                    <img
                      src="https://bit.ly/38cxZ0U"
                      alt=""
                      className="watch__card-img"
                    />
                    <div className="watch__card-desc ml-3">
                      <div className="watch__card-title">AVENGERS ENDGAME</div>
                      <div className="watch__card-info">
                        <span className="watch__card-info-1">Sci-fi</span>
                        <span className="watch__card-info-2">2019</span>
                        <span className="watch__card-info-3">M18</span>
                      </div>

                      <div className="watch__card-icon">
                        <div className="mr-2 d-flex heart">
                          {" "}
                          <Like /> 23
                        </div>
                        <div className="mr-2">
                          {" "}
                          <Share />
                        </div>
                      </div>
                    </div>
                  </div>
                  ):
                </>
              );
            })}
          </div>
        </div>
      ) : (
        <>
          {" "}
          <div className="d-flex flex-column align-items-center justify-content-center p-3">
            <h3 style={{ color: "#ff8a00" }}>
              Login or signup to Access your Liked Videos
            </h3>
            <div style={{ color: "black" }}>
              {" "}
              <LoginSection color="black" font="2rem" />
            </div>
            <div>
              {" "}
              <SignupSection />
            </div>
          </div>
        </>
      )}

      <BottomNav name="MyLikes" />
    </>
  );
}
const mapStateToProps = (state, ownProps) => {
  const { name, email, plan, loggedIn } = state.Auth;
  return {
    name,
    email,
    plan,
    loggedIn
  };
};
const mapDispatchToProps = (dispatch, state) => {
  return {
    LogoutAuth: data => {
      dispatch(LogoutAuth(data));
    }
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(MyLikes);

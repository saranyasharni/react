import React from "react";
import { LogoutAuth } from "../../actions/Auth";
import { connect } from "react-redux";
import Header from "../../containers/common/Header";
import BottomNav from "./BottomNav";
import { Nav } from "react-bootstrap";
import LoginSection from "../AuthSection/LoginSection";
import SignupSection from "../AuthSection/SignupSection";

function MyAccount(props) {
  return (
    <>
      <Header />
      {props.loggedIn ? (
        <div className="menu__acc">
          <h2>My Account</h2>
          <div
            className="menu__acc-signout"
            onClick={() => {
              props.LogoutAuth(props.email);
            }}
            style={{ color: "black" }}
          >
            Sign Out
          </div>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcReiyHYtDJQ0t5jCs4j_PiD5ESMvPwnvHVa3w&usqp=CAU"
            className="menu__acc-profile"
            alt="profile"
          />
          <div className="menu__acc-name" style={{ color: "black" }}>
            {props.name}
          </div>
          <div className="menu__acc-member" style={{ color: "black" }}>
            {props.plan} Membership
          </div>
          <div className="menu__acc-upgrade" style={{ color: "black" }}>
            Upgrade
          </div>
          <div className="menu__acc-share" style={{ color: "black" }}>
            Share and Invite Friends
          </div>
          <div className="menu__acc-changepass" style={{ color: "black" }}>
            Change Password
          </div>
        </div>
      ) : (
        <>
          {" "}
          <div className="d-flex flex-column align-items-center justify-content-center p-3">
            <h3 style={{ color: "#ff8a00" }}>
              Login or signup to Access your account
            </h3>
            <div style={{ color: "black" }}>
              {" "}
              <LoginSection color="black" font="2rem" />
            </div>
            <div>
              {" "}
              <SignupSection />
            </div>
          </div>
        </>
      )}
      <BottomNav name="Account" />
    </>
  );
}
const mapStateToProps = (state, ownProps) => {
  const { name, email, plan, loggedIn } = state.Auth;
  return {
    name,
    email,
    plan,
    loggedIn
  };
};
const mapDispatchToProps = (dispatch, state) => {
  return {
    LogoutAuth: data => {
      dispatch(LogoutAuth(data));
    }
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(MyAccount);

import React from "react";
import advertiseone from "../../assets/images/sports-1.jpg";

function Advertisement() {
  return (
    <div>
      <div className="addvertisement-section my-5">
        <img
          src="https://via.placeholder.com/300x600/FF8A00/FFFF?text=Advertisement Space"
          className="img-fluid"
          style={{ width: "100%", height: "500px" }}
          alt="ad"
        />
      </div>
    </div>
  );
}

export default Advertisement;

import React from "react";
import { Link } from "react-router-dom";
import SignupSection from "../AuthSection/SignupSection";
function Footer() {
  return (
    <div>
      <section className="footer-section">
        <div className="footer-link text-center">
          <Link to="/about"> About Us</Link>
          <Link to="/whatsnew">What's New</Link>
          <Link to="/helpcenter">Help Center</Link>
          <Link to="/job"> Jobs</Link>
          <Link to="/contributor">Contributor</Link>
          {/* <a href="#">Become a Member</a> */}
          <SignupSection from={"footer"} />
        </div>
      </section>
    </div>
  );
}

export default Footer;

import React from "react";
import Header from "../../containers/common/Header";
import BottomNav from "./BottomNav";

function PlansSection() {
  return (
    <div>
      <Header />
      <div class="columns">
        <ul class="price">
          <li class="header">FREE</li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>Uninterrupted
            Viewing -With Ads
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            Unlimited Downloads - 0 downloads
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            Stream Cast Enabled - Streaming Disabled
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            Access to LIVE content - No LIVE Access
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            Same Day Release -After 22 hrs
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            Major Events Coverage - No Access
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            All Access Pass - Limited Drama and Varitey Only
          </li>
          <li class="grey">
            <a href="#" class="button">
              Free
            </a>
          </li>
        </ul>
      </div>

      <div class="columns">
        <ul class="price">
          <li style={{ backgroundColor: "#ff8a00", color: "white" }}>
            STANDARD
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>Uninterrupted
            Viewing - No Video Ads
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Unlimited Downloads
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Stream Cast Enabled - Streaming Enabled
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Access to LIVE content - LIVE Access Enabled
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Same Day Release
          </li>
          <li>
            {" "}
            <i className="fa fa-times mr-3" aria-hidden="true"></i>
            Major Events Coverage - Coverage Enabled
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            All Access Pass - Drama,Varitey,Movies,Kids
          </li>
          <li class="grey">
            <a href="#" class="button">
              Upgrade Now!
            </a>
          </li>
        </ul>
      </div>

      <div class="columns">
        <ul class="price">
          <li style={{ backgroundColor: "#ff8a00", color: "white" }}>
            PREMIUM
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>Uninterrupted
            Viewing
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Unlimited Downloads
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Stream Cast Enabled
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Access to LIVE content
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Same Day Release
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            Major Events Coverage
          </li>
          <li>
            {" "}
            <i className="fa fa-check mr-3" aria-hidden="true"></i>
            All Access Pass
          </li>
          <li class="grey">
            <a href="#" class="button">
              Upgrade Now!
            </a>
          </li>
        </ul>
      </div>
      <BottomNav name="Plans" />
    </div>
  );
}

export default PlansSection;

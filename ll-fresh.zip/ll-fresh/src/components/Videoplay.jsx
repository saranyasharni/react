import React, { useState, useEffect } from "react";
// import videobanner from "../assets/images/video-banner.jpg";
import LiveStream from "./Live_Stream";
import config from "../actions/API/Api_links";

function Videoplay(props) {
  const [program, setProgram] = useState({});
  useEffect(() => {
    fetch(config.movies + `/${props.id}`, {
      headers: {
        "x-app-id": 7386573047397500
      }
    })
      .then(res => res.json())
      .then(data => {
        setProgram(data);
      });
  }, [props]);
  return (
    <div>
      <div className="video-player-section relative">
        <LiveStream id={props.id} />

        {/* <div className="video-contentflow">
          <h4>{program.name}</h4>
          <br />
          <div className="container p-0">
            <div className="row">
              <div className="col-sm-6">
                <div className="video-view-likesmain">
                  <p>{program.no_of_views} views</p>
                  <p className="posted-date">Jan 12,2020</p>
                  <p className="shhare-links">
                    <i class="fa fa-thumbs-up mr-2" aria-hidden="true"></i>

                    <span>{program.no_of_likes}</span>
                  </p>
                </div>
              </div>
              <div className="col-sm-6">
                <div className="video-view-likesmain-w text-right">
                  
                </div>
              </div>
            </div>
          </div>
        </div> */}
        <br />
      </div>
    </div>
  );
}

export default Videoplay;

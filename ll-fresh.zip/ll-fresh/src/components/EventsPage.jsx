import React, { useEffect, useState } from "react";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import Advertisement from "./HomePageSections/Advertisement";
import EntertainmentNews from "./HomePageSections/EntertainmentNews";
import { ReactComponent as Arrow } from "../assets/images/arrow_left.svg";
import { Link } from "react-router-dom";
import { useMediaQuery } from "react-responsive";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
import ReactHtmlParser from "react-html-parser";
import config from "../actions/API/Api_links";
function EventsPage(props) {
  const { id } = props.match.params;
  const [event, setEvent] = useState("");
  useEffect(() => {
    fetch(config.events)
      .then(res => res.json())
      .then(data => {
        setEvent(data);
      });
  }, [props.match.params.id]);
  const isTablet = useMediaQuery({ query: "(max-width: 768px)" });

  return (
    <div>
      <Header />
      <header
        className="main__banner"
        style={{
          backgroundImage: `url(${event.img_url})`,
          backgroundPosition: "center",
          backgroundSize: "cover",

          width: "100%",
          position: "relative"
        }}
      >
        <Link
          className="main__banner-nav"
          to={`/category/${props.match.params.category}/${props.match.params.name}/${props.match.params.catid}`}
        >
          <Arrow />
          Sports
        </Link>
        <section className="main__banner-info">
          <div className="main__banner-info-title">{event.name}</div>
          <div className="main__banner-info-descr">
            {/* On a gusty day in Southern Utah, a group of 25 daring mountain
            bikers blew the doors off what is possible on two wheels, unleashing
            some of the biggest moments the sport has ever seen. While mother
            nature only allowed for one full run before the conditions made it
            impossible to ride, that was all that was needed for event veteran
            Kyle Strait, who won the event for the second time -- eight years
            after his rst Red Bull Rampage titl */}
            {ReactHtmlParser(event.descr)}
          </div>
        </section>
      </header>
      <section className="live-news-feed">
        <div className="conatiner-fluid">
          <div className="row">
            <div className="col-md-8 col-sm-8 col-xs-12 latest-news-sections">
              <EntertainmentNews id={id} title={false} />
            </div>
            <div className="col-md-4 col-sm-4 col-xs-12 channel-sections">
              {/* <RecommendedChannels /> */}
              <Advertisement />
            </div>
          </div>
        </div>
      </section>
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </div>
  );
}

export default EventsPage;

import React from "react";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import AboutDescription from "./AboutPageSection/AboutDescription";
import AboutSubheadingDetails from "./AboutPageSection/AboutSubheadingDetailsl";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
function Aboutpage() {
  return (
    <div>
      <Header />
      <AboutDescription />
      <AboutSubheadingDetails />
      <AboutSubheadingDetails />
      <AboutSubheadingDetails />
      <AboutSubheadingDetails />
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </div>
  );
}

export default Aboutpage;

import React, { useState, useEffect } from "react";
import ListSlider from "./ListSlider";
function ProgramsList(props) {
  const [data, setData] = useState([]);
  useEffect(() => {
    fetch(`https://api.live2.asia/api/v1/movies?event_id=${props.id}`)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        setData(data.data);
      })
      .catch(err => console.log(err, "from prog"));
  }, [props.id]);
  return (
    <>
      <ListSlider prog={data} />
    </>
  );
}

export default ProgramsList;

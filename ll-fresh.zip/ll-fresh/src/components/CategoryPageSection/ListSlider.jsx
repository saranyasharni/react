import React, { useEffect, useState } from "react";
import Flickity from "react-flickity-component";
import { connect } from "react-redux";
import * as actions from "../../actions/Home";
import { Card } from "react-bootstrap";
import { Link } from "react-router-dom";

const flickityOptions = {
  initialIndex: 1,
  resize: false,
  wrapAround: false,
  autoPlay: false,
  pageDots: false
};

function ListSlider(props) {
  const [programms, setProg] = useState([]);
  useEffect(() => {
    setProg(props.prog);
  }, [props.prog]);
  return (
    <div style={{ position: "relative" }}>
      <div className="cards__overlay"></div>
      <Flickity
        className={"carousel2"} // default ''
        elementType={"div"} // default 'div'
        options={flickityOptions} // takes flickity options {}
        disableImagesLoaded={false} // default false
        // reloadOnUpdate={true} // default false
        // static= // default false
      >
        {programms.map(i => {
          return (
            // <div className="ml-3 list__slider" key={i.id}>
            //   <img src={i.img_url} alt="img" />
            // </div>
            <Link
              to={{
                pathname: "/program/details",
                state: {
                  pgId: i.id
                }
              }}
            >
              {" "}
              <Card className="bg-dark text-white ml-5 list__card">
                <Card.Img
                  src={i.img_url}
                  alt="Card image"
                  className="list__slider-img"
                />
                <Card.ImgOverlay>
                  <Card.Title className="card__title">{i.name}</Card.Title>
                  <Card.Text>{i.descr}</Card.Text>
                  <Card.Text>{i.no_of_views}</Card.Text>
                  <i className="fa fa-play" aria-hidden="true"></i>{" "}
                </Card.ImgOverlay>
              </Card>
            </Link>
          );
        })}
      </Flickity>
    </div>
  );
}

export default ListSlider;

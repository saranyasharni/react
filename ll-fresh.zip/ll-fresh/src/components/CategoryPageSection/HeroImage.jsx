import React from "react";
import Badge from "react-bootstrap/Badge";
function HeroImage(props) {
  return (
    <>
      {/* <div className="wrapper masthead-1 ml-5">
        <div
          className="poster"
          style={{
            backgroundImage: `url(${props.img})`,
            width: "790px",
            height: "400px",
            backgroundSize: "cover",
            position: "absolute"
          }}
        ></div>
        <div className="poster-blur"></div>
        <div className="colour"></div>

        <div className="content">
          <h1>{props.name}</h1>
          <p className="meta">
            <Badge variant="success">{props.status}</Badge> &#8226;{" "}
            {props.likes} &#8226; {props.views} &#8226; 15+ &#8226; English
          </p>
          <p className="description">
            Deprived of his mighty hammer Mjolnir, Thor must escape the other
            side of the universe to save his home, Asgard, from Hela, the
            goddess of death.
            {props.descr}
          </p>
        </div>
      </div> */}
      <div
        className="movie-card"
        style={{
          backgroundImage: `url(${props.img})`,
          backgroundPosition: "center",
          backgroundSize: "cover"
        }}
      >
        <div className="card-overlay"></div>
        {/* <div className="card-share">
                <a className="share-link" href="#">
                  <i className="fa fa-heart" aria-hidden="true"></i>
                </a>
                <a className="share-link" href="#">
                  <i className="fa fa-comment" aria-hidden="true"></i>
                </a>
                <a className="share-link" href="#">
                  <i className="fa fa-share-alt" aria-hidden="true"></i>
                </a>
              </div> */}
        <div className="list__card">
          <div className="movie-card-description">
            <h1 className="movie-title">{props.name}</h1>
            <p className="movie-subtitle">
              <p className="meta">
                <Badge variant="success">{props.status}</Badge> &#8226;{" "}
                {props.likes} &#8226; {props.views} &#8226; 15+ &#8226; English
              </p>
            </p>
            <p className="movie-shorts">
              Fairy Tail is set in Earth-land, a fictional land where wizards
              coalesce into guilds to apply their magical abilities for paid job
              requests. Novice wizard Lucy Heartfilia runs away from home to
              join Fairy Tail, a guild famous for its members' overly
              destructive antics.
            </p>
            <button type="button" className="watch-btn">
              <i className="fa fa-play" aria-hidden="true"></i> &emsp; Watch
              Trailer
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default HeroImage;

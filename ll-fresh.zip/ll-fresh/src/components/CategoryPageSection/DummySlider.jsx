import React, { useEffect, useState } from "react";
import Flickity from "react-flickity-component";
import Badge from "react-bootstrap/Badge";

import { Card } from "react-bootstrap";
import { Link } from "react-router-dom";
const flickityOptions = {
  initialIndex: 1,
  resize: false,
  wrapAround: true,
  autoPlay: false,
  pageDots: false
};

function DummySlider(props) {
  //   const [programms, setProg] = useState([]);
  //   useEffect(() => {
  //     setProg(props.prog);
  //   }, [props.prog]);
  const [data, setData] = useState([]);
  useEffect(() => {
    // props.getEvents(props.id);
    fetch(`https://api.live2.asia/api/v1/movies?category_id=${props.id}`)
      .then(res => res.json())
      .then(data => {
        setData(data.data);
      })
      .catch(err => console.log(err, "primary slider"));
  }, [props.id]);
  const programms = [1, 2, 3, 4, 5, 6, 7];
  return (
    <>
      <Flickity
        className={"carousel3"} // default ''
        elementType={"div"} // default 'div'
        options={flickityOptions} // takes flickity options {}
        disableImagesLoaded={false} // default false
        // reloadOnUpdate={true} // default false
        // static= // default false
      >
        {data.map(i => {
          return (
            // <Link
            //   to={{
            //     pathname: "/program/details",
            //     state: {
            //       pgId: i.id
            //     }
            //   }}
            // >
            <div
              className="movie-card"
              style={{
                backgroundImage: `url(${i.img_url})`,
                backgroundPosition: "center",
                backgroundSize: "cover"
              }}
            >
              <div className="card-overlay"></div>
              {/* <div className="card-share">
                <a className="share-link" href="#">
                  <i className="fa fa-heart" aria-hidden="true"></i>
                </a>
                <a className="share-link" href="#">
                  <i className="fa fa-comment" aria-hidden="true"></i>
                </a>
                <a className="share-link" href="#">
                  <i className="fa fa-share-alt" aria-hidden="true"></i>
                </a>
              </div> */}
              <div className="list__card">
                <div className="movie-card-description">
                  <h1 className="movie-title">{i.name}</h1>
                  <p className="movie-subtitle">
                    <p className="meta">
                      <Badge variant="success">{i.status}</Badge> &#8226;{" "}
                      {i.likes} &#8226;<i class="fas fa-eye"></i>{" "}
                      {i.no_of_views} &#8226; 15+ &#8226; English
                    </p>
                  </p>
                  <p className="movie-shorts">
                    Fairy Tail is set in Earth-land, a fictional land where
                    wizards coalesce into guilds to apply their magical
                    abilities for paid job requests. Novice wizard Lucy
                    Heartfilia runs away from home to join Fairy Tail, a guild
                    famous for its members' overly destructive antics.
                  </p>
                  <Link
                    to={{
                      pathname: "/program/details",
                      state: {
                        pgId: i.id
                      }
                    }}
                  >
                    {" "}
                    <button type="button" className="watch-btn">
                      <i className="fa fa-play" aria-hidden="true"></i> &emsp;
                      Watch
                    </button>
                  </Link>
                </div>
              </div>
            </div>
            // </Link>
          );
        })}
      </Flickity>
    </>
  );
}

export default DummySlider;

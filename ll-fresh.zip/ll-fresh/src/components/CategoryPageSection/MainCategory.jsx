import React, { useEffect, useState } from "react";
import Header from "../../containers/common/Header";
import Footer from "../HomePageSections/Footer";
import Card from "react-bootstrap/Card";
import RecommendedChannels from "../HomePageSections/RecommendedChannels";
import Advertisement from "../HomePageSections/Advertisement";
import EntertainmentNews from "../HomePageSections/EntertainmentNews";
import { ReactComponent as Arrow } from "../../assets/images/arrow_left.svg";
import { Link } from "react-router-dom";
import ReactHtmlParser from "react-html-parser";
import { connect } from "react-redux";
import * as actions from "../../actions/Home";
import SportsImg from "../../assets/images/sports-banner.jpg";
import Entertainment from "../../assets/images/entertainment-banner.jpg";
import Featured from "../../assets/images/silhouette-of-dancing-people-inside-club-1677710.jpg";
import LifeStyle from "../../assets/images/lifestyle-banner.jpg";
import News from "../../assets/images/insight-banner.jpg";
import BottomNav from "../HomePageSections/BottomNav";
import MediaQuery from "react-responsive";

const data = {
  Sports: {
    img: SportsImg,
    descr: ""
  },
  Entertainment: {
    img: Entertainment
  },
  Featured: {
    img: Featured
  },
  Lifestyle: {
    img: LifeStyle
  },
  newsInsights: {
    img: News
  }
};
const MainCategory = props => {
  const main_category = props.match.params.category;
  const [items, setItems] = useState([]);
  const [id, setId] = useState("");
  useEffect(() => {
    let new_cat = props.categories.filter(i => {
      return category_list[main_category].includes(i.name);
    });
    console.log(new_cat, "from maincat");
    console.log(props);
    setItems(new_cat);
    setId(new_cat[0].id);
  }, [props.match.params.category]);

  return (
    <>
      <Header />
      <header
        className="main__banner"
        style={{
          backgroundImage: `url(${data[main_category].img})`
        }}
      >
        <Link className="main__banner-nav" to="/">
          <Arrow />
          {main_category === "newsInsights" ? "News & Insights" : main_category}
        </Link>
        <section className="main__banner-info">
          <div className="main__banner-info-title">Red Bull Rampage 2019</div>
          <div className="main__banner-info-descr">
            On a gusty day in Southern Utah, a group of 25 daring mountain
            bikers blew the doors off what is possible on two wheels, unleashing
            some of the biggest moments the sport has ever seen. While mother
            nature only allowed for one full run before the conditions made it
            impossible to ride, that was all that was needed for event veteran
            Kyle Strait, who won the event for the second time -- eight years
            after his rst Red Bull Rampage titl
          </div>
        </section>
      </header>
      <section className="container-fluid pl-lg-5 pr-lg-3">
        <div className="category__cards  my-5">
          {!items
            ? ""
            : items.map(i => {
                return (
                  <Link
                    to={{
                      pathname: `/category/${main_category}/${i.name.replace(
                        /\s+/g,
                        ""
                      )}/${i.id}`,
                      state: {
                        data: i.id
                      }
                    }}
                  >
                    <div key={i.id}>
                      <Card className="bg-dark text-white  list__card mb-5">
                        <Card.Img
                          src={i.img}
                          alt="Card image"
                          className="list__slider-img"
                        />
                        <Card.ImgOverlay>
                          <Card.Title className="card__title">
                            {i.name}
                          </Card.Title>
                        </Card.ImgOverlay>
                      </Card>
                    </div>
                  </Link>
                );
              })}
        </div>
      </section>
      <section className="live-news-feed">
        <div className="conatiner-fluid">
          <div className="row">
            <div className="col-md-8 col-sm-8 col-xs-12 latest-news-sections">
              <EntertainmentNews
                title={true}
                cat_id={id}
                title_value="Recomended For You"
                title_small={main_category}
              />
            </div>
            <div className="col-md-4 col-sm-4 col-xs-12 channel-sections">
              {/* <RecommendedChannels /> */}
              <Advertisement />
            </div>
          </div>
        </div>
      </section>
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </>
  );
};
const mapStateToProps = (state, ownProps) => {
  return {
    categories: state.Home.categories,
    events: state.Home.events
  };
};
export default connect(mapStateToProps, null)(MainCategory);

const category_list = {
  Sports: ["Esports", "Fitness & Sports"],
  Entertainment: [
    "Kids",
    "Box Office",
    "Dramas",
    "Anime",
    "Variety Shows",
    "Reality",
    "Asian Movies"
  ],
  Featured: [
    "New Releases",
    "Tech Talk",
    "Adventure Travel",
    "THG TV",
    "LiveLive Originals",
    "TV Channels"
  ],
  Lifestyle: [
    "Food",
    "Wellness",
    "Life, Arts, People",
    "Home and Deco",
    "Lifestyle"
  ],
  newsInsights: ["News & Insights", "Discover"]
};

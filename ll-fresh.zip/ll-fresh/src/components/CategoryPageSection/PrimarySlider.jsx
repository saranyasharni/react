import React, { useEffect, useState } from "react";
import Flickity from "react-flickity-component";
import HeroImage from "./HeroImage";
import { connect } from "react-redux";
import * as actions from "../../actions/Home";
import Badge from "react-bootstrap/Badge";

import DummySlider from "./DummySlider";
const flickityOptions = {
  initialIndex: 2,
  resize: false,
  wrapAround: true,
  autoPlay: true,
  pageDots: false
};
const arr = [1, 2, 3, 4, 5, 6, 7, 8];
function PrimarySlider(props) {
  const [data, setData] = useState([]);
  useEffect(() => {
    // props.getEvents(props.id);
    fetch(`https://api.live2.asia/api/v1/movies?category_id=${props.id}`)
      .then(res => res.json())
      .then(data => {
        setData(data.data);
      })
      .catch(err => console.log(err, "primary slider"));
  }, []);
  return (
    <div>
      <Flickity
        className={""} // default ''
        elementType={"div"} // default 'div'
        options={flickityOptions} // takes flickity options {}
        disableImagesLoaded={false} // default false
        // reloadOnUpdate={true} // default false
        // static={true} // default false
      >
        {!data ? (
          <div>No items</div>
        ) : (
          data.slice(0, 4).map(i => {
            return (
              <>
                <div key={i.id}>
                  {/* <img
                  src="https://img0.hotstar.com/image/upload/f_auto,t_hs_tab_xxhdpi/sources/r1/cms/prod/178/110178-h"
                  alt="img"
                  className="primary__slider-img"
                /> */}
                  {/* <HeroImage
                    img={i.img_url}
                    name={i.name}
                    status={i.status}
                    likes={i.no_of_likes}
                    views={i.no_of_views}
                    logo={i.event_logo}
                    descr={i.descr}
                  /> */}

                  {/* <DummySlider 
                  img={i.img_url}
                  name={i.name}
                  status={i.status}
                  likes={i.no_of_likes}
                  views={i.no_of_views}
                  logo={i.event_logo}
                  descr={i.descr}
                  /> */}
                  <div
                    className="movie-card"
                    style={{
                      backgroundImage: `url(${i.img_url})`,
                      backgroundPosition: "center",
                      backgroundSize: "cover"
                    }}
                  >
                    <div className="card-overlay"></div>
                    <div className="card-share">
                      <a className="share-link" href="#">
                        <i className="fa fa-heart" aria-hidden="true"></i>
                      </a>
                      <a className="share-link" href="#">
                        <i className="fa fa-comment" aria-hidden="true"></i>
                      </a>
                      <a className="share-link" href="#">
                        <i className="fa fa-share-alt" aria-hidden="true"></i>
                      </a>
                    </div>
                    <div className="list__card">
                      <div className="movie-card-description">
                        <h1 className="movie-title">{i.name}</h1>
                        <p className="movie-subtitle">
                          <p className="meta">
                            <Badge variant="success">{i.status}</Badge> &#8226;{" "}
                            {props.likes} &#8226; {i.no_of_views} &#8226; 15+
                            &#8226; English
                          </p>
                        </p>
                        <p className="movie-shorts">
                          Fairy Tail is set in Earth-land, a fictional land
                          where wizards coalesce into guilds to apply their
                          magical abilities for paid job requests. Novice wizard
                          Lucy Heartfilia runs away from home to join Fairy
                          Tail, a guild famous for its members' overly
                          destructive antics.
                        </p>
                        <button type="button" className="watch-btn">
                          <i className="fa fa-play" aria-hidden="true"></i>{" "}
                          &emsp; Watch Trailer
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            );
          })
        )}
      </Flickity>
    </div>
  );
}

const mapStateToProps = (state, ownProps) => {
  return { events: state.Home.events };
};
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // getEvents: id => {
    //   dispatch(actions.getEvents(id));
    // }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(PrimarySlider);

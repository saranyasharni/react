import React from 'react'

function AboutSubheadingDetails() {
    return (
        <div>
            <div className="container about-subeading-details">
                <div className="row">
                <div className="col-sm-12">
                        <h4>Seamless Video Playback</h4>
                        <p>Our adaptive video streaming technology ensures that the best possible video quality is played back automatically based on the available bandwidth, therefore making it a great video experience on both mobile networks as well as WiFi internet connections. Our video is optimized to play on mobile networks with inconsistent throughput so that our users don't have to compromise on their experience on the low end, and play HD quality video on the top end of bandwidth availability. Additionally, our users can manually select the quality of video that suits their taste.</p>
                        <h4>Friendly User Interface</h4>
                        <p>Content organization on Live Live is a result of a thoughtful user experience approach and strong design principles that ensure that the user is not overwhelmed with the breadth of content available. Using a mix of algorithms and human curation, users at any stage of their interaction with Live Live will discover content and see their experience evolve with their interaction patterns over time.</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AboutSubheadingDetails

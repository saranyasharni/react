import React from 'react'

function AboutDescription() {
    return (
        <div>
            <div className="container about-description">
                <div className="row">
                    <div className="col-sm-12">
                        <h2>About Us</h2>
                        <p>Live Live is an online video streaming platform owned by Novi Digital Entertainment Private Limited, a wholly owned subsidiary of Star India Private Limited. Live Live currently offers over 100,000 hours of TV content and movies across 9 languages, and every major sport covered live. Highly evolved video streaming technology and a high attention to quality of experience across devices and platforms, make Live Live the most complete video destination for Over The Top (OTT) video consumers.</p>
                    </div>
                </div>
            </div>
           
        </div>
    )
}

export default AboutDescription

import React from "react";
import JobpageTitle from "./JobspageSection/JobpageTitle";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import Jobpagedetails from "./JobspageSection/Jobpagedetails";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
function Jobspage() {
  return (
    <div>
      <Header />
      <JobpageTitle />
      <Jobpagedetails />
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </div>
  );
}

export default Jobspage;

import React from 'react';
import { Accordion, Card, Button } from 'react-bootstrap';

function HelpcenterPageDetails() {
    return (
        <>
  
      
             <div className="container">
                 <div className="row">
                     <div className="col-sm-10 col-sm-ofset-2">
                     <div className="help-center-accordian">
            <Accordion defaultActiveKey="0">
          
  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="0">
       <h5>What is Live Live Premium Membership?</h5>
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="0">
      <Card.Body>
        <p>This membership gives you access to all our premium titles (including Disney+ titles) which are currently available on the platform as well as the titles which we will be added in the future.<br/>
In addition, you also get access to Unlimited live sports (Cricket, Pro Kabaddi League, ISL, Tennis grand slams, Premier League, Bundesliga, F1 & more), latest Indian movies' digital premieres, Disney+ Originals, popular Disney movies & kids shows (in English & select Indian languages), Hotstar Specials and Star serials before TV.<br/>
We offer 2 plans for Live Live Premium membership. A deeply discounted yearly plan for Rs. 1499 or a monthly plan for Rs. 299. All our subscription plans are non-refundable. Our free content continues to be available for free for all users.<br/>
Please note that the premium videos that we can offer are subject to streaming rights available with us. This means that we may have rights to stream only certain seasons of a show, or that only a certain number of latest episodes may be available with us.</p>
      </Card.Body>
    </Accordion.Collapse>
  </Card>
  <Card>
    <Accordion.Toggle as={Card.Header} eventKey="1">
      <h5>What videos are available in the premium catalogue?</h5>
    </Accordion.Toggle>
    <Accordion.Collapse eventKey="1">
      <Card.Body>
          <p>Premium English shows and movies are exclusively available to members only. We have library as well as current seasons for a number of shows, and we are continuously adding to our extensive premium catalogue.<br/>
We also have latest Hindi and regional movies for exclusive access to premium members.<br/>
This also includes Disney movies, Kids shows, American TV shows & Hollywood movies. You also get access to many popular Disney+ Originals such as Mandalorian.<br/>
You can see the premium shows and movies available with us at premium.hotstar.com<br/>
Not only this, we also allow exclusive early access to your favourite prime time TV shows. Latest primetime episodes are available on Live Live at 6pm IST every day, before they air on TV.</p>
      </Card.Body>
    </Accordion.Collapse>
  </Card>
</Accordion>
</div>
                     </div>
                 </div>                  
             </div>
             
        </>
    )
}

export default HelpcenterPageDetails

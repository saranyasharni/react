import React from 'react'

function Helpcentertitle() {
    return (
        <div>
                   <div className="container help-center-accordian-heading">
            <div className="row">
            <div className="col-sm-10 col-sm-ofset-2">
            <h1>Frequently Asked Questions</h1><br/>
            <h3>Live Live Premium</h3>
            </div>
        </div>
        </div>
        </div>
    )
}

export default Helpcentertitle

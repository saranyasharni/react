import React, { useEffect } from "react";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
// import PrimarySlider from "./CategoryPageSection/PrimarySlider";
import { connect } from "react-redux";
// import ProgramsList from "./CategoryPageSection/ProgramsList";
import * as actions from "../actions/Home";
// import DummySlider from "./CategoryPageSection/DummySlider";
import Card from "react-bootstrap/Card";
// import RecommendedChannels from "../HomePageSections/RecommendedChannels";
import Advertisement from "./HomePageSections/Advertisement";
import EntertainmentNews from "./HomePageSections/EntertainmentNews";
import { ReactComponent as Arrow } from "../assets/images/arrow_left.svg";
import { Link } from "react-router-dom";
import ReactHtmlParser from "react-html-parser";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
const items = [1, 2, 3, 4, 5, 6];
function CategoryPage(props) {
  // const [categoryData, setCategoryData] = useState("");
  useEffect(() => {
    props.getEvents(props.match.params.id);
    props.getCategoryById(props.match.params.id);
    console.log(props.match.params.id, "id");
  }, [props.match.params.id]);
  return (
    <>
      <Header />
      <header
        className="main__banner"
        style={{
          backgroundImage: `url(${props.category.img})`,
          backgroundPosition: "center",
          backgroundSize: "cover",
          height: "80vh",
          width: "100%",
          position: "relative"
        }}
      >
        <Link
          className="main__banner-nav"
          to={`/main/${props.match.params.category}`}
        >
          <Arrow />
          {props.category.name}
        </Link>
        <section className="main__banner-info">
          <div className="main__banner-info-title">{props.category.name}</div>
          <div className="main__banner-info-descr">
            {/* On a gusty day in Southern Utah, a group of 25 daring mountain
            bikers blew the doors off what is possible on two wheels, unleashing
            some of the biggest moments the sport has ever seen. While mother
            nature only allowed for one full run before the conditions made it
            impossible to ride, that was all that was needed for event veteran
            Kyle Strait, who won the event for the second time -- eight years
            after his rst Red Bull Rampage titl */}
            {ReactHtmlParser(props.category.descr)}
          </div>
        </section>
      </header>
      <section className="container-fluid pl-5 pr-3">
        <div className="category__cards my-5">
          {!props.events
            ? ""
            : props.events.map(i => {
                return (
                  <div key={i.id}>
                    <Link
                      to={{
                        pathname: `event/${props.match.params.category}/${
                          props.match.params.name
                        }/${props.match.params.catid}/${i.name.replace(
                          /\s+/g,
                          ""
                        )}/${i.id}`,
                        state: {
                          data: {
                            name: i.name,
                            id: i.id,
                            descr: i.descr,
                            img: i.img_url
                          }
                        }
                      }}
                    >
                      {" "}
                      <Card className="bg-dark text-white  list__card mb-5">
                        <Card.Img
                          src={i.img_url}
                          alt="Card image"
                          className="list__slider-img"
                        />
                        <Card.ImgOverlay>
                          <Card.Title className="card__title">
                            {i.name}
                          </Card.Title>
                        </Card.ImgOverlay>
                      </Card>
                    </Link>
                  </div>
                );
              })}
        </div>
      </section>
      <section className="live-news-feed">
        <div className="conatiner-fluid">
          <div className="row">
            <div className="col-md-8 col-sm-8 col-xs-12 latest-news-sections">
              <EntertainmentNews
                title={true}
                cat_id={props.category.id}
                title_value="Recomended For You"
                title_small={props.category.name}
              />
            </div>
            <div className="col-md-4 col-sm-4 col-xs-12 channel-sections">
              {/* <RecommendedChannels /> */}
              <Advertisement />
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </>
  );
}

const mapStateToProps = (state, ownProps) => {
  return {
    events: state.Home.events,
    category: state.Home.category
  };
};
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getEvents: category => {
      dispatch(actions.getEvents(category));
    },
    getCategoryById: id => {
      dispatch(actions.getCategoryById(id));
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CategoryPage);

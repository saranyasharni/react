import React, { Component } from "react";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import HelpcenterPageDetails from "./HelpcenterPageSection/HelpcenterPageDetails";
import Helpcentertitle from "./HelpcenterPageSection/Helpcentertitle";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
export class HelpCenterPage extends Component {
  render() {
    return (
      <div>
        <Header />
        <Helpcentertitle />
        <HelpcenterPageDetails />
        <HelpcenterPageDetails />
        <HelpcenterPageDetails />

        <Footer />
        <MediaQuery maxDeviceWidth={540}>
          <BottomNav />
        </MediaQuery>
      </div>
    );
  }
}

export default HelpCenterPage;

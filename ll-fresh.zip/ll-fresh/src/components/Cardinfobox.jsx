import React, { useEffect, useState } from "react";
// import videosec from "../assets/images/fitness-1.jpg";
// import videosec2 from "../assets/images/fitness-2.jpg";
// import videosec3 from "../assets/images/fitness-3.jpg";
import { Link } from "react-router-dom";
import { Card, CardColumns, Spinner } from "react-bootstrap";
function Cardinfobox(props) {
  const [loading, setLoading] = useState(false);
  const [searchItems, setSearchItem] = useState([]);

  //   useEffect(() => {

  //   }, [props.query]);

  useEffect(() => {
    setLoading(true);
    if (props.query === "") {
      fetch("https://api.live2.aisa/api/v1/programmes", {
        headers: {
          "x-app-id": 7386573047397500
        }
      })
        .then(res => res.json())
        .then(data => {
          let temp = data.data.map((item, index) => {
            return (
              <>
                <Link
                  to={{
                    pathname: "program/details",
                    state: {
                      pgId: item.id
                    }
                  }}
                >
                  {" "}
                  <Card className="mx-3">
                    {index === 0 ? (
                      <Card.Img
                        variant="top"
                        src="https://static-cdn.espx.cloud/userstorage/bf01b389-16cc-46ed-94cd-35d151cefde2/xOTpazDN8bfNN4ps.jpg"
                      />
                    ) : index === 8 ? (
                      <Card.Img
                        variant="top"
                        src="https://static-cdn.espx.cloud/userstorage/bf01b389-16cc-46ed-94cd-35d151cefde2/xOTpazDN8bfNN4ps.jpg"
                      />
                    ) : (
                      <Card.Img variant="top" src={item.img_url} />
                    )}

                    <Card.Body>
                      <Card.Title>{item.name}</Card.Title>
                      <Card.Text>{item.descr}</Card.Text>
                    </Card.Body>
                  </Card>
                </Link>
              </>
            );
          });

          setSearchItem(temp);
          setLoading(false);
          console.log(data.data);
        });
    } else {
      fetch(
        `https://api.espx.cloud/api/v1/programmes?name=$like${props.query}__%`
      )
        .then(res => res.json())
        .then(data => {
          console.log(data.data);
          let temp = data.data.map((item, index) => {
            return (
              <>
                <Link
                  to={{
                    pathname: "program/details",
                    state: {
                      pgId: item.id
                    }
                  }}
                >
                  {" "}
                  <Card className="mx-3">
                    {index === 0 ? (
                      <Card.Img
                        variant="top"
                        src="https://static-cdn.espx.cloud/userstorage/bf01b389-16cc-46ed-94cd-35d151cefde2/xOTpazDN8bfNN4ps.jpg"
                      />
                    ) : index === 8 ? (
                      <Card.Img
                        variant="top"
                        src="https://static-cdn.espx.cloud/userstorage/bf01b389-16cc-46ed-94cd-35d151cefde2/xOTpazDN8bfNN4ps.jpg"
                      />
                    ) : (
                      <Card.Img variant="top" src={item.img_url} />
                    )}

                    <Card.Body>
                      <Card.Title>{item.name}</Card.Title>
                      <Card.Text>{item.descr}</Card.Text>
                    </Card.Body>
                  </Card>
                </Link>
              </>
            );
          });
          setSearchItem(temp);
          setLoading(false);
        })
        .catch(error => console.log(error));
    }
  }, [props.query]);

  return (
    <div className="mx-lg-5 mx-sm-2 px-lg-5 px-sm-2 my-5">
      <h3 style={{ marginLeft: "20px", color: "orange", marginBottom: "20px" }}>
        {props.query === "" ? "Popular Searches" : "your search result"}
      </h3>
      <CardColumns>
        {loading ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              width: "100vw",
              marginBottom: "500px"
            }}
          >
            <Spinner
              animation="grow"
              variant="warning"
              style={{ width: "200px", height: "200px" }}
            />
          </div>
        ) : (
          searchItems
        )}
      </CardColumns>
    </div>
  );
}

export default Cardinfobox;

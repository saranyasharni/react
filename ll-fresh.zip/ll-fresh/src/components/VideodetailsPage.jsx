import React, { useEffect, useState } from "react";
import Videoplay from "./Videoplay";
import Recommendedvideo from "./Recommendedvideo";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import RecommendedChannels from "./HomePageSections/RecommendedChannels";
import Advertisement from "./HomePageSections/Advertisement";
import EntertainmentNews from "./HomePageSections/EntertainmentNews";
import config from "../actions/API/Api_links";
import ReactHtmlParser from "react-html-parser";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";

function VideodetailsPage(props) {
  const [programId, setProgramId] = useState(props.match.params.pgId);
  const [program, setProgram] = useState("");
  useEffect(() => {
    console.log(props, "props");

    setProgramId(props.match.params.pgId);
    fetch(config.movies + `/${props.match.params.pgId}`, {
      headers: {
        "x-app-id": 7386573047397500
      }
    })
      .then(res => res.json())
      .then(data => {
        setProgram(data);
      });
  }, [props.match.params.pgId]);

  const handleVideo = id => {
    console.log("entered,", id);
    setProgramId(() => {
      return id;
    });
  };
  return (
    <div>
      <Header />
      <div className="container-fluid video__main">
        <div className="row p-2">
          <div className="col-sm-9 col-xs-12">
            <Videoplay id={programId} />
          </div>
          <div className="col-sm-3 col-xs-12">
            <Recommendedvideo id={programId} handleVideo={handleVideo} />
          </div>
        </div>
      </div>
      <section className="p-5 mx-2 d-flex flex-grow-1 flex-column">
        <h1 style={{ color: "orange" }}>{program.name}</h1>
        <div style={{ fontSize: "1.5rem", width: "70%" }}>
          {ReactHtmlParser(program.descr)}
        </div>
      </section>
      <div className="container-fluid">
        <div className="row">
          {/* <div className="col-md-4 col-sm-8 col-xs-12 latest-news-sections">
              <LatestNews items={categories.slice(0, 5)} />

            </div>
            <div className="col-md-4 col-sm-8 col-xs-12 latest-news-sections">
              <LatestNews items={categories.slice(5, 10)} />
              
            </div> */}

          <div className="col-md-8 col-sm-8 col-xs-12 latest-news-sections">
            <EntertainmentNews title={true} title_value="Recomended For You" />
          </div>
          <div className="col-md-4 col-sm-4 col-xs-12 channel-sections">
            <RecommendedChannels />
            <Advertisement />
            {/* <RecommendedChannels /> */}
            {/* <Advertisement />
              <RecommendedChannels /> */}
          </div>
        </div>
      </div>
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </div>
  );
}

export default VideodetailsPage;

import React, { useEffect, useState } from "react";
import CarouselSlider from "./FeaturedSection/CarouselSlider";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import ReactHtmlParser from "react-html-parser";
function Featured(props) {
  const [featured, setFeatured] = useState({});
  const [categoryData, setCategoryData] = useState("");
  useEffect(() => {
    setCategoryData(props.location.state.data);
  }, [props]);
  useEffect(() => {
    console.log(props);
    let data = props.events.filter(item => {
      return item.category === categoryData;
    });
    setFeatured({ ...data[0] });
  }, [categoryData]);
  useEffect(() => {
    console.log(featured);
  }, [featured]);
  return (
    <>
      <Header />
      <section className="insights-banner relative">
        <div className="banner-text">
          <h1>{featured.name}</h1>
          {featured.descr !== null ? (
            <p>{ReactHtmlParser(featured.descr)}</p>
          ) : (
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita
              ullam architecto esse iste dolorem quia, earum, doloremque
              consequatur veritatis quisquam dignissimos corporis accusantium
              voluptas recusandae. Adipisci nulla temporibus quas atque!
            </p>
          )}
        </div>
      </section>
      {/* <Slider
        events={props.events}
        program={featured.programmes}
        categoryData={categoryData}
        name={featured.name}
      /> */}
      <CarouselSlider
        events={props.events}
        program={featured.programmes}
        categoryData={categoryData}
        name={featured.name}
      />
      <Footer />
    </>
  );
}
export default Featured;

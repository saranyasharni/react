import React, { useState, useEffect } from "react";
import Slider from "./SportSection/Slider";
import Header from "./HomePageSections/Header";
import Footer from "./HomePageSections/Footer";
function Sports(props) {
  const [sports, setSports] = useState({});
  useEffect(() => {
    console.log(props);
    let data = props.events.filter(item => {
      return item.category === "Sports & Entertainment";
    });
    setSports({ ...data[0] });
  }, []);
  useEffect(() => {
    console.log(sports.name);
  }, [sports]);
  return (
    <>
      <Header />
      <section className="sports-banner relative">
        <div className="banner-text">
          <h1>Red Bull Rampage 2020</h1>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita
            ullam architecto esse iste dolorem quia, earum, doloremque
            consequatur veritatis quisquam dignissimos corporis accusantium
            voluptas recusandae. Adipisci nulla temporibus quas atque!
          </p>
        </div>
      </section>
      <Slider events={props.events} />
      <Footer />
    </>
  );
}

export default Sports;

import React from 'react'

function WhatsnewpageDetails() {
    return (
        <>
            <div className="container whatsnewpage-details">
                <div className="row">
                    <div className="col-sm-12">
                        <h1>Latest Features</h1>
                        <br/>
                         <h3>Live Streaming</h3>
                         <p>Live Live is a streaming service that allows our members to watch a wide variety of award-winning TV shows, movies, documentaries, and more on thousands of internet-connected devices. With Live Live, you can enjoy unlimited ad-free viewing of our content. There's always something new to discover, 
                             and more TV shows and movies are added every month! If you're already a member and would like to learn more about using Live Live, visit Getting started with Live Live.</p>
                        <br/>
                        <h3>Live Live Latest Event & Videos</h3>
                        <p>In over 190 countries, Live Live members get instant access to great content. Live Live has an extensive global content library featuring award-winning Live Live originals, feature films, documentaries, TV shows, and more. Live Live content will vary by region, and may change over time.</p>
                        <p>The more you watch, the better Live Live gets at recommending TV shows and movies you’ll love.</p>
                        <p>You can play, pause, and resume watching without ads or commitments.</p>
                        <h3>Streaming Devices</h3>
                        <p>Watch anywhere, anytime, on thousands of devices. Live Live streaming software allows you to instantly watch content from Live Live through any internet-connected device that offers the Live Live app, including smart TVs, game consoles, streaming media players, set-top boxes, smartphones, and tablets. View our Internet Speed Recommendations to achieve the best performance. You can also stream Live Live directly from your computer or laptop. We recommend reviewing the System Requirements for web browser compatibility.</p>
                    </div>
                </div>
            </div>
        </>
    )
}

export default WhatsnewpageDetails

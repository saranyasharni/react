import React from "react";
import Header from "../containers/common/Header";
import Footer from "./HomePageSections/Footer";
import ContributorPageDetails from "./ContributorPageSection/ContributorPageDetails";
import MediaQuery from "react-responsive";
import BottomNav from "./HomePageSections/BottomNav";
function ContributorPage() {
  return (
    <div>
      <Header />
      <ContributorPageDetails />
      <Footer />
      <MediaQuery maxDeviceWidth={540}>
        <BottomNav />
      </MediaQuery>
    </div>
  );
}

export default ContributorPage;

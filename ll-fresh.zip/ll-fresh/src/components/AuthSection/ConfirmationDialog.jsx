import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { ReactComponent as Arrow } from "../../assets/images/arrow_left.svg";
import { Modal, Button } from "react-bootstrap";
import { email, setSignup } from "../../actions/Auth";

function ConfirmationDialog(props) {
  const [show, setShow] = useState(false);
  const handleClose = () => {
    setShow(false);
    props.setSignup(false);
  };
  useEffect(() => {
    if (props.signup) {
      setShow(true);
    }
  }, [props.signup]);
  const handleShow = () => {
    setShow(true);
  };
  return (
    <>
      {/* <Button onClick={handleShow}>Show</Button> */}
      <Modal
        className="modal fade"
        id="dialog"
        show={show}
        centered
        onHide={handleClose}
        size="lg"
      >
        <Modal.Body className="dialog__modal">
          <div className="dialog__wrapper mb-5">
            Thanks for joining LIVEitLIVE !!, To activate your account please
            click on the verificatio link sent to
            <span
              style={{ color: "#ff8a00", fontSize: "1.6rem", margin: "0 3px" }}
            >
              {email}
            </span>
          </div>
        </Modal.Body>
        <Button onClick={handleClose} className="btn btn-outline dialog__btn">
          Close
        </Button>
      </Modal>
    </>
  );
}
const mapStateToProps = (state, ownProps) => {
  const { signup } = state.Auth;
  return {
    signup
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setSignup: data => {
      dispatch(setSignup(data));
    }
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ConfirmationDialog);

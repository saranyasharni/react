import React, { useState, useEffect } from "react";
import { Modal, Nav, Form, Button } from "react-bootstrap";
import { useFormik } from "formik";
import * as Yup from "yup";
import { Link } from "react-router-dom";
import captcha from "../../assets/images/captcha.png";
import logo from "../../assets/images/logo.png";
import { ReactComponent as Arrow } from "../../assets/images/arrow_left.svg";
import { connect } from "react-redux";
import * as actions from "../../actions/Auth";
const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const SignupSection = props => {
  const [show, setShow] = useState(false);
  const handleClose = () => {
    props.setError("");
    setShow(false);
  };
  const handleShow = () => setShow(true);
  useEffect(() => {
    console.log(props.error);
  }, [props.error]);
  useEffect(() => {
    if (props.signup) {
      handleClose();
    }
  }, [props.signup]);
  const formik = useFormik({
    initialValues: {
      password: "",
      email: "",
      name: "",
      cpassword: "",
      contact_number: "",
      captcha: ""
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Please Enter Valid Email")
        .required("Please Enter Email"),
      password: Yup.string()
        .required("Please Enter Password")
        .min(6, "Password Should be minimum 6 characters"),
      name: Yup.string().required("Please Enter Your Name"),
      contact_number: Yup.string()
        .matches(phoneRegExp, "Phone number is not valid")
        .required("Please Enter Your Phone Number")
        .min(10, "Enter Valid Phone Number")
        .max(10, "Enter Valid Phone Number"),
      cpassword: Yup.string()
        .required("Please Enter the password again")
        .oneOf([Yup.ref("password"), null], "Password must be same"),
      captcha: Yup.string().required("Please Enter the above code")
    }),
    onSubmit: values => {
      props.SignupAuth(values);
    }
  });

  return (
    <>
      {props.from === "footer" ? (
        <Link onClick={handleShow}>Become a Member</Link>
      ) : (
        <div className="nav-item signup mr-lg-5">
          <Nav.Link className="nav-link" onClick={handleShow}>
            SIGN UP
          </Nav.Link>{" "}
        </div>
      )}

      <Modal
        className="modal fade"
        id="register"
        show={show}
        centered
        onHide={props.loading ? "" : handleClose}
        size="xl"
      >
        {" "}
        <div
          className="ml-5 mt-5"
          onClick={handleClose}
          style={{ cursor: "pointer" }}
        >
          {" "}
          <Arrow />
        </div>
        <Modal.Body>
          <div className="text-center form_register_logo">
            <img src={logo} alt="" className="img-fluid" />
          </div>
          <br />
          <div className="text-center reg-head">
            <h2>Register as a member</h2>
            {props.error && (
              <h2 style={{ color: "red", fontSize: "2rem" }}>{props.error}</h2>
            )}
          </div>
          <br />
          <Form
            className="register-form mx-lg-5"
            noValidate
            onSubmit={formik.handleSubmit}
          >
            <div className="container">
              <div className="row">
                <div className="col-lg-5">
                  <Form.Group>
                    <Form.Control
                      type="text"
                      className="form-control"
                      id="name"
                      placeholder="Name"
                      name="name"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.name}
                      isInvalid={!!formik.errors.name}
                    />
                    <Form.Control.Feedback
                      type="invalid"
                      className="auth__error"
                    >
                      {formik.errors.name}
                    </Form.Control.Feedback>
                  </Form.Group>
                  <Form.Group>
                    <Form.Control
                      type="text"
                      className="form-control"
                      id="number"
                      placeholder="Contact Number"
                      name="contact_number"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.contact_number}
                      isInvalid={!!formik.errors.contact_number}
                    />
                    <Form.Control.Feedback
                      type="invalid"
                      className="auth__error"
                    >
                      {formik.errors.contact_number}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group>
                    <Form.Control
                      type="email"
                      className="form-control"
                      id="emailid"
                      placeholder="Email"
                      name="email"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.email}
                      isInvalid={!!formik.errors.email}
                    />
                    <Form.Control.Feedback
                      type="invalid"
                      className="auth__error"
                    >
                      {formik.errors.email}
                    </Form.Control.Feedback>
                    <small id="alert-text">
                      Please ensure that you have entered the correct email
                    </small>
                  </Form.Group>
                </div>

                <div className="col-lg-2"></div>
                <div className="col-lg-5">
                  <Form.Group>
                    <Form.Control
                      type="password"
                      className="form-control"
                      id="password"
                      placeholder="Enter Password"
                      name="password"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.password}
                      isInvalid={!!formik.errors.password}
                    />
                    <Form.Control.Feedback
                      type="invalid"
                      className="auth__error"
                    >
                      {formik.errors.password}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group>
                    <Form.Control
                      type="password"
                      className="form-control"
                      id="confirm_password"
                      placeholder="Confirm Password"
                      name="cpassword"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.cpassword}
                      isInvalid={!!formik.errors.cpassword}
                    />
                    <Form.Control.Feedback
                      type="invalid"
                      className="auth__error"
                    >
                      {formik.errors.cpassword}
                    </Form.Control.Feedback>
                  </Form.Group>
                  <br />
                  <div className="text-center">
                    <img src={captcha} alt="" className="img-fluid" />
                  </div>
                  <br />
                  <Form.Group>
                    <Form.Control
                      type="text"
                      className="form-control"
                      id="enter_code"
                      placeholder="Enter Above Code"
                      name="captcha"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.captcha}
                      isInvalid={!!formik.errors.captcha}
                    />
                    <Form.Control.Feedback
                      type="invalid"
                      className="auth__error"
                    >
                      {formik.errors.captcha}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <div className="text-center register-btns">
                    <Button
                      type="submit"
                      className="btn btn-warning btn-block premium-member"
                      disabled={props.loading}
                    >
                      {props.loading ? "Signing In..." : "Start Living !"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </Form>
          <br />
          <br />
          <div className="terms-text text-center">
            <small>
              To know our terms and services please visit{" "}
              <a href="#">Terms and Conditions</a>
            </small>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};
const mapDispatchToProps = (dispatch, state) => {
  return {
    SignupAuth: data => {
      dispatch(actions.SignupAuth(data));
    },
    setError: data => {
      dispatch(actions.setError(data));
    }
  };
};
const mapStateToProps = (state, ownProps) => {
  const { error, loading, signup } = state.Auth;
  return {
    error,
    loading,
    signup
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(SignupSection);

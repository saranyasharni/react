import React, { useState, useEffect } from "react";
import logo from "../../assets/images/logo.png";
import { ReactComponent as Fb } from "../../assets/images/facebook.svg";
import { ReactComponent as Arrow } from "../../assets/images/arrow_left.svg";
import { connect } from "react-redux";
import * as actions from "../../actions/Auth";

import { Modal, Nav, Form, Button } from "react-bootstrap";
import { useFormik } from "formik";
import * as Yup from "yup";

function LoginSection(props) {
  const [show, setShow] = useState(false);
  const handleClose = event => {
    if (event.type === "keydown") {
      return;
    }
    props.setError("");
    setShow(false);
    console.log(show);
  };
  const handleShow = () => setShow(true);

  const formik = useFormik({
    initialValues: {
      password: "",
      email: ""
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Please Enter Valid Email")
        .required("Please Enter Email"),
      password: Yup.string()
        .required("Please Enter Password")
        .min(6, "Password Should be minimum 6 characters")
    }),
    onSubmit: values => {
      props.LoginAuth(values);
    }
  });
  useEffect(() => {
    if (props.loggedIn) {
      handleClose();
    }
  }, [props.loggedIn]);
  return (
    <div>
      <Nav.Link
        onClick={handleShow}
        style={{ color: props.color, fontSize: props.font }}
        className="mr-lg-3"
      >
        Login
      </Nav.Link>
      <Modal
        className="modal fade"
        id="signin"
        show={show}
        centered
        // onHide={props.loading ? "" : handleClose}
        size="xl"
      >
        <div
          className="ml-5 mt-5"
          onClick={handleClose}
          onKeyDown={handleClose}
          style={{ cursor: "pointer" }}
        >
          {" "}
          <Arrow />
        </div>
        <Modal.Body className="login__modal">
          <div className="text-center form-logo">
            <img src={logo} alt="" className="img-fluid" />
          </div>
          {props.error && (
            <h2 style={{ color: "red", fontSize: "2rem" }}>{props.error}</h2>
          )}
          <br />
          <Form
            noValidate
            className="register-form"
            onSubmit={formik.handleSubmit}
          >
            <h4>Sign In</h4>
            <Form.Group>
              <Form.Control
                type="email"
                className="form-control"
                id="emailid"
                placeholder="Email"
                name="email"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.email}
                isInvalid={!!formik.errors.email}
              />
              <Form.Control.Feedback type="invalid" className="auth__error">
                {formik.errors.email}
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group>
              <Form.Control
                type="password"
                className="form-control"
                id="password"
                placeholder="Enter Password"
                name="password"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.password}
                isInvalid={!!formik.errors.password}
              />
              {/* {formik.touched.password && formik.errors.password ? (
                <div className="auth__error">{formik.errors.password}</div>
              ) : null} */}
              <Form.Control.Feedback type="invalid" className="auth__error">
                {formik.errors.password}
              </Form.Control.Feedback>
            </Form.Group>
            <br />

            <div className="text-center register-btns">
              <Button
                type="submit"
                className="btn btn-warning btn-block free-member"
                disabled={props.loading}
              >
                {props.loading ? "LogingIn..." : "SUBMIT"}
              </Button>
            </div>

            <div className="subscribe-sec">
              <input
                class="styled-checkbox"
                id="styled-checkbox-1"
                type="checkbox"
                value="value1"
              />
              <label for="styled-checkbox-1">Remember me</label>
              <p>Sign up</p>
            </div>
          </Form>
          <br />
          <div className="fb-section relative" style={{ cursor: "pointer" }}>
            <div className="fb__icon">
              {" "}
              <Fb />
            </div>
            <p>Login with facebook</p>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

const mapDispatchToProps = (dispatch, state) => {
  return {
    LoginAuth: data => {
      dispatch(actions.LoginAuth(data));
    },
    setError: data => {
      dispatch(actions.setError(data));
    }
  };
};
const mapStateToProps = (state, ownProps) => {
  const { error, loading, loggedIn } = state.Auth;
  return {
    error,
    loading,
    loggedIn
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(LoginSection);

const initialState = {
  categories: [],
  events: [],
  login: false,
  category: ""
};

export const Home = (state = initialState, action) => {
  switch (action.type) {
    case "SET_LOGIN":
      return {
        ...state,
        login: action.payload
      };
    case "FETCH_CATEGORIES":
      return {
        ...state,
        categories: action.payload
      };
    case "FETCH_EVENTS":
      return {
        ...state,
        events: action.payload
      };
    case "SET_CATEGORY":
      return {
        ...state,
        category: action.payload
      };
    default:
      return state;
  }
};

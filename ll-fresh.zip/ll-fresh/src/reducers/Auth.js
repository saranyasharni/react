let token = localStorage.getItem("token");
let name = localStorage.getItem("name");
let email = localStorage.getItem("email");
let plan = localStorage.getItem("plan");
export const initialState = token
  ? {
      loggedIn: true,
      signup: false,
      loading: false,
      error: "",
      email: email,
      name: name,
      plan: plan,
      open: ""
    }
  : {
      loggedIn: false,
      signup: false,
      loading: false,
      error: "",
      name: "",
      plan: "",
      email: "",
      open: ""
    };

export const Auth = (state = initialState, action) => {
  switch (action.type) {
    case "LOGIN_SUCCESS":
      return {
        ...state,
        loggedIn: action.payload.loggedIn,
        email: action.payload.email,
        name: action.payload.name,
        plan: action.payload.plan,
        open: false,
        error: ""
      };

    case "SIGNUP_SUCCESS":
      return {
        ...state,
        signup: action.payload,
        error: ""
      };

    case "SET_LOADING":
      return {
        ...state,
        loading: action.payload
      };
    case "SET_ERROR":
      return {
        ...state,
        error: ""
      };
    case "ERORR":
      return {
        ...state,
        error: action.payload
      };
    case "LOGOUT":
      return {
        ...state,
        loggedIn: false,
        error: "",
        loading: false,
        open: false
      };
    default:
      return state;
  }
};

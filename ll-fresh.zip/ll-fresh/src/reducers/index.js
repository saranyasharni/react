import { combineReducers } from "redux";
import { connectRouter } from "connected-react-router";
import { Home } from "./Home";
import { Auth } from "./Auth";
// import { reducer as reduxFormReducer } from "redux-form";
const RootReducer = history =>
  combineReducers({
    Home,
    Auth,
    router: connectRouter(history)
    // form: reduxFormReducer // mounted under "form"
  });

export default RootReducer;

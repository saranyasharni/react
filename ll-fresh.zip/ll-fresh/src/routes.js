import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Home from "./containers/Home";
import Entertainment from "./containers/Entertainment";
import Sports from "./containers/Sports";
import LifeStyle from "./containers/LifeStyle";
import Featured from "./containers/Featured";
import VideoDetails from "./containers/VideoDetails";
import Searchpage from "./components/Searchpage";
import About from "./components/Aboutpage";
import Whatsnew from "./components/WhatsnewPage";
import Helpcenter from "./components/HelpCenterPage";
import Jobspage from "./components/Jobspage";
import contributors from "./components/ContributorPage";
import CategoryPage from "./components/CategoryPage";
import MainCategory from "./components/CategoryPageSection/MainCategory";
import EventsPage from "./components/EventsPage";
import ScrollTop from "./ScrollTop";
import WatchList from "./components/HomePageSections/WatchList";
import MyAccount from "./components/HomePageSections/MyAccount";
import MyLikes from "./components/HomePageSections/MyLikes";
import PlansSection from "./components/HomePageSections/PlansSection";
function routes() {
  return (
    <>
      <Router>
        <ScrollTop />
        <Route exact path="/" component={Home} />
        {/* <Route exact path="/entertainment" component={Entertainment} /> */}
        {/* <Route exact path="/sports" component={Sports} /> */}
        {/* <Route exact path="/lifestyle" component={LifeStyle} /> */}
        <Route exact path="/program/details/:pgId" component={VideoDetails} />
        <Route exact path="/category" component={Featured} />
        <Route exact path="/search/programms" component={Searchpage} />
        <Route exact path="/about" component={About} />
        <Route exact path="/whatsnew" component={Whatsnew} />
        <Route exact path="/helpcenter" component={Helpcenter} />
        <Route exact path="/job" component={Jobspage} />
        <Route exact path="/contributor" component={contributors} />
        <Route
          exact
          path="/category/:category/:name/:id"
          component={CategoryPage}
        />
        <Route exact path="/main/:category" component={MainCategory} />
        <Route
          exact
          path="/event/:main/:category/:catid/:name/:id"
          component={EventsPage}
        />
        <Route exact path="/home/watchlist" component={WatchList} />
        <Route exact path="/home/mylikes" component={MyLikes} />
        <Route exact path="/home/myaccount" component={MyAccount} />
        <Route exact path="/home/plans" component={PlansSection} />
      </Router>
    </>
  );
}

export default routes;

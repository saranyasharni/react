import React from "react";
import "./assets/styles/root.scss";
import "./assets/styles/flickity.css";
import "./assets/styles/Pages/main.css";
import Routes from "./routes";
import history from "./store/history";
import { ConnectedRouter } from "connected-react-router";

function App() {
  return (
    <>
      <ConnectedRouter history={history}>
        <Routes />
      </ConnectedRouter>
    </>
  );
}

export default App;

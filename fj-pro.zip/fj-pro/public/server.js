const express = require('express');
const app = express();
const port = process.env.PORT || 3002;
const path = require('path');
const fs = require('fs');
const request_npm = require('request');
const { replace } = require('lodash');

// const siteUrl = "https://api.thehomeground.asia/api/v1";

app.get('/404.html', function(request, response) {
    response.sendFile(__dirname + '/404.html');
});

// app.get('/', function (request, response) {
//     console.log('Home page visited!', request.originalUrl);
//     const filePath = path.resolve(__dirname, 'index.html');

//     fs.readFile(filePath, 'utf8', function (err, data) {
//         if (err) {
//             return console.log(err);
//         }

//         result = data;

//         if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

//             var original_link = request.originalUrl;
//             var remove_quest_mark = original_link.split('?');

//             var remove_slug_slash = remove_quest_mark[0].split('/');        
//             var meta_social_title = 'TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV';
//             var meta_social_description = 'TheHomeGround Asia – Latest and trending news and events happening around Asia. Delving deeper to better explain stories. Letting readers voice their opinions. Watch events live.';
//             var meta_title = 'TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV';
//             var meta_description = 'TheHomeGround Asia – Latest and trending news and events happening around Asia. Delving deeper to better explain stories. Letting readers voice their opinions. Watch events live.';
//             var meta_keywords = "Latest news from Singapore, Top news stories from Singapore, Latest Singapore news and headlines, Latest Singapore News & Headlines, Latest News and Updates on Singapore";
//             var article_image = 'https://thehomeground.asia/assets/images/thg_567.jpeg'

//             data = data.replace(/\$META_TITLE/g, meta_title);
//             data = data.replace(/\$META_DESCRIPTION/g, meta_description);
//             data = data.replace(/\$META_KEYWORDS/g, meta_keywords);

//             data = data.replace(/\$OG_TITLE/g, meta_social_title);
//             data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
//             data = data.replace(/\$OG_IMAGE/g, article_image);
//             result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
//             response.send(result);
//         }      
           
//     });
// });

app.use(express.static(path.resolve(__dirname)));

app.get('*', function (request, response) {
    const filePath = path.resolve(__dirname, 'index.html');
    response.sendFile(filePath);
});

app.listen(port, () => console.log(`Listening on port ${port}`));
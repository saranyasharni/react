import React, { useState } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import Model from "./model";
import ModelLogin from "./signinModel";
import { setFieldValues } from "../../actions/Home";
function Header(props) {
  return (
    <>
      {/* Header Starts here */}
      <header className="row">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 col-md-4 col-6">
              <Link to={'/'} className="nav-brand">
                <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/flexi-logo.png"} alt="FlexiJobs" />
              </Link>
            </div>
            <div className="col-lg-6 col-md-8 col-12">
              <nav className="navbar navbar-expand-md">
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#hdr-menu">
                  <span>&nbsp;</span>
                  <span>&nbsp;</span>
                  <span>&nbsp;</span>
                </button>
                <div className="collapse navbar-collapse" id="hdr-menu">
                  <ul className="navbar-nav">
                    <li className="nav-item dropdown">
                      <a className="nav-link dropdown-toggle" href="javascript:;" data-toggle="dropdown">Explore the Job</a>
                      <div className="dropdown-menu">
                        {
                          props.jobs.length > 0 && props.jobs[0].jobs.map((i,k)=>{
                            return (
                              <Link 
                              key = {k}
                              to = {`/jobs/${i.id}`}
                              className="dropdown-item" 
                              href="javascript:;">
                                {i.industry_name}
                              </Link>  
                            )
                          })
                        }
                        {/* <Link className="dropdown-item" to={'/jobs/2'}>Logistics</Link>
                        <Link className="dropdown-item" to={'/jobs/3'}>Hospitality</Link>
                        <Link className="dropdown-item" to={'/jobs/4'}>Event &amp; Promotion</Link>
                        <Link className="dropdown-item" to={'/jobs/5'}>F&amp;B</Link> */}
                      </div>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" href="javascript:;">About Us
                      </a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link btn-login" 
                      href="javascript:;" 
                      onClick={() => props.setFieldValues('show_login', true)}
                      >Login</a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link btn-signup" href="javascript:;" onClick={() => props.setFieldValues('show', true)} >Sign Up</a>
                    </li>
                    {
                    // localStorage.getItem('employee_id') || localStorage.getItem('emp_id') ?
                    // "":(
                    <>
                    
                    </>
                    // )
                    }
                    
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </header>
      {/* Header Ends here */}
      <Model />
      <ModelLogin />
    </>
  );
}

const mapStateToProps = (state, ownProps) => {
  return {
    jobs:state.Home.jobs,
    // categories: state.Home.categories
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setFieldValues: (f, v) => dispatch(setFieldValues(f, v))
  }
};
export default connect(mapStateToProps, mapDispatchToProps)(Header);

import React from "react";
import { connect } from "react-redux";


function Footer(props) {
  return (
    <>
    {/* Footer Starts here */}
    <footer className="container-fluid">
    <div className="row">
    <div className="element-wrap">
    <img className="ftr-lt" src={process.env.PUBLIC_URL+"/assets/images/ftr-lft-curve.svg"} alt="elements" />
    <img className="ftr-br" src={process.env.PUBLIC_URL+"/assets/images/ftr-rgt-curve.svg"} alt="elements" />
    <img className="ftr-oval img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/ftr-element.svg"} alt="elements" />
    </div>
    <div className="container">
    <div className="row">
      <div className="col-lg-6 col-md-3 col-12 ftr-lft">
        <h6>FlexiJobs</h6>
        <p>Content simply dummy text of the printing and typesetting industry.</p>
      </div>
      <div className="col-lg-2 col-md-3 col-6">
        <h5>Quick Links</h5>
        <ul className="list-unstyled ftr-nav">
          <li><a href="javascript:;">About Us</a></li>
          <li><a href="javascript:;">Blog</a></li>
          <li><a href="javascript:;">Contact</a></li>
          <li><a href="javascript:;">FAQ</a></li>
        </ul>
      </div>
      <div className="col-lg-2 col-md-3 col-6">
        <h5>Legal Stuff</h5>
        <ul className="list-unstyled ftr-nav">
          <li><a href="javascript:;">Disclaimer</a></li>
          <li><a href="javascript:;">Financing</a></li>
          <li><a href="javascript:;">Privacy Policy</a></li>
          <li><a href="javascript:;">Terms of Service</a></li>
        </ul>
      </div>
      <div className="col-lg-2 col-md-3 col-12">
        <h5>Social</h5>
        <ul className="list-unstyled ftr-nav">
          <li><a href="javascript:;">Facebook</a></li>
          <li><a href="javascript:;">Twitter</a></li>
          <li><a href="javascript:;">Instagram</a></li>
        </ul>
      </div>
    </div>
    </div>
    </div>
    </footer>
    {/* Footer Ends here */}
    </>
  );
}

const mapStateToProps = (state, ownProps) => {
  return {
   
    categories: state.Home.categories
  };
  
};
export default connect(mapStateToProps, null)(Footer);

import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { connect } from 'react-redux';
import * as actions from "../../../actions/Notifications"
import moment from "moment";

function Header(props) {
  useEffect(() => {
    let employeeId = localStorage.getItem('employee_id')
    props.getNotification({
      employee_id :employeeId
    })
  }, [])

  
  return (
    <header className="row px-3">
      <div className="col-lg-9 col-md-10 col-6 hdr-lft">
        <a href="javascript:;" className="lft-btn">
          <img src="/assets/images/app/hdr-lft-icon.svg" alt="icon" />
        </a>
        
        <nav className="navbar navbar-expand-md">
          <div className="collapse navbar-collapse" id="app-hdr-nav">
            <ul className="navbar-nav">
              {console.log(window.location.pathname.split('/')[1],
              "ljkljhkjkh"
              )}
              <li 
              className={`${window.location.pathname.split('/')[1] === 'employee-dashboard' ?
              "nav-item active":  "nav-item"
            }`}
            >
                <Link 
                className="nav-link " 
                to = {'/employee-dashboard'}
                >
                  Dashboard
                </Link>
              </li>
              <li className={`${window.location.pathname.split('/')[1] === 'employee-view-jobs' ?
              "nav-item active":  "nav-item"
            }`}>
                <Link className="nav-link"
                to = "/employee-view-jobs"
                >
                  Search Job
                </Link>
              </li>
              <li className={`${window.location.pathname.split('/')[1] === 'employee_applied_jobs' ?
              "nav-item active":  "nav-item"
            }`}>
                <Link className="nav-link" 
                to = "/employee_applied_jobs"
                >
                  My Jobs
                </Link>
              </li>
              <li className={`${window.location.pathname.split('/')[1] === 
                'offers' ?
                "nav-item active":  "nav-item"
                }`}>
                <Link className="nav-link" 
                to = "/offers"
                >
                 List of offers
                </Link>
              </li>
              <li className={`${window.location.pathname.split('/')[1] === 
                'extended-requests' ?
                "nav-item active":  "nav-item"
                }`}>
                <Link className="nav-link" 
                to = "/extended-requests"
                >
                 Work Requests
                </Link>
              </li>
              <li className={`${window.location.pathname.split('/')[1] === 
                'my-profile' ?
                "nav-item active":  "nav-item"
                }`}>
                <Link className="nav-link" 
                to = "/my-profile"
                >
                  My Profile
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div className="col-lg-3 col-md-2 col-6 hdr-rgt">
        <div className="notify-drop">
          {
            props.employeeNotifications && 
            props.employeeNotifications.unviewedCount !== 0 &&
            <span className={props.employeeNotifications &&
              props.employeeNotifications.unviewedCount === 0 ?
              '' : "count"}
              >{
                props.employeeNotifications &&
              props.employeeNotifications.unviewedCount === 0 ?
              '' : props.employeeNotifications.unviewedCount
            }</span>
          }
        
          <button className="btn">
            <img src="/assets/images/app/notification-icon.svg" alt="icon" />
          </button>
          {
            props.employeeNotifications &&
            props.employeeNotifications.notifications &&
            props.employeeNotifications.notifications.length > 0 &&
            <div className="dd-menu">
            <p className="lead">Notification</p>
            <p className="day">
              <span>Today</span>
            </p>
            {
            props.employeeNotifications &&
            props.employeeNotifications.notifications &&
            props.employeeNotifications.notifications.length > 0 &&
            props.employeeNotifications.notifications.slice(0,4).map((i,k) => {
              return(
                <Link className="notify-item mt-2" key = {k}
                style = {{textDecoration:'none'}}
                to = {"/employee-notifications"}
                onClick = {() => {
                  
                  props.viewEmployeeNotification()
                }}
                >
                <div className="icon-wrap">
                  <img
                    className="img-fluid"
                    src="/assets/images/app/notify-orange.svg"
                    alt="icon"
                  />
                </div>
                
                <div className="n-cont">
                  <p>{i.notification_title}</p>
                  <span>{moment.utc((i.createdAt)).fromNow()}</span>
                </div>
              </Link>
              )
            })
            }
          <div className="w-100 text-right">
            <Link 
              to = {"/employee-notifications"}
             className="cl-notify fs-12"
             onClick = {() => {
                  
              props.viewEmployeeNotification()
            }}
             >View All</Link>
          </div>
          </div>
          }
          
        </div>
        <div className="dropdown profile-drop">
        <button className="btn dropdown-toggle" type="button"
         id="dropdownMenuButton"
          data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
          >
              <img className="logo-icon"
              style = {{height:'100%'}}
               src=
              {
                localStorage.employee_profile_url !== null &&
                localStorage.employee_profile_url !== 'null'  &&
                localStorage.employee_profile_url !== "" ?
                localStorage.getItem('employee_profile_url') :
                process.env.PUBLIC_URL+"/assets/images/app/profile-icon.svg"
              }
              // "/assets/images/app/logo-icon.png" 
              />
            </button>
          <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <div className="dd-top">
              <button className="btn btn-gray"
              onClick = { () => {
                // alert()
                // localStorage.clear()
                localStorage.removeItem('employee_id');
                localStorage.removeItem('employee_profile_url');
                localStorage.removeItem('employee_name');
                localStorage.removeItem('employee_email');
                localStorage.removeItem('chat_room_id');
                localStorage.removeItem('notify_model');
                window.location.href = '/'
              }
              }
              >
              <img src="/assets/images/app/logout-icon.svg" alt="icon" />
                Sign Out
              </button>
             
              <span>
              <Link
              to = "/my-profile"
              style = {{color: '#3267d9',
              textDecoration : 'none'
            }}
              >
                <img src="/assets/images/app/profile-icon.svg"alt="icon" />
                Profile
                </Link>
              </span>
              
            </div>
            <div className="p-cont">
              <p className="lead">{localStorage.getItem('employee_name')}</p>
              <span>{localStorage.getItem('employee_email')}</span>
            </div>
          </div>
        </div>
        <button
          className="navbar-toggler nav-res"
          type="button"
          data-toggle="collapse"
          data-target="#app-hdr-nav"
        >
          <span>&nbsp;</span>
          <span>&nbsp;</span>
          <span>&nbsp;</span>
        </button>
      </div>
    </header>
  );
}

const mapStateToProps = (state, ownProps) => {
  return {
      // show: state.Home.show_login,
      profile_img : state.Emp_Profile.profile_img,
      employeeNotifications :state.Notifications.employeeNotifications
      // categories: state.Home.categories
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getNotification : (data) => dispatch(actions.getNotification(data)),
    viewEmployeeNotification : () => dispatch(actions.viewEmployeeNotification())
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);


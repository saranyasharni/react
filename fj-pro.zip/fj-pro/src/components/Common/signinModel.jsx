import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
// import jQuery from 'jquery';
import { Modal } from 'react-bootstrap';
import { setFieldValues } from "../../actions/Home";

class SignModel extends Component {
    constructor(props) {
        super(props);
    };

    render() {

        return (

            <Modal show={this.props.show} dialogClassName="modal-lg sign-modal"
                style={{ "paddingRight": 17 }} onHide={() => this.props.setFieldValues('show_login', false)}
                className="modal fade " id="sign-modal" tabIndex="-1" role="dialog" aria-hidden="true"
                aria-labelledby="contained-modal-title-vcenter"
                centered>
                <div className="modal-header">
                    <h5 className="modal-title" id="contained-modal-title-vcenter exampleModalLabel">LOGIN</h5>
                    <button type="button" className="close" onClick={() => this.props.setFieldValues('show_login', false)} aria-label="Close">
                        <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                    </button>
                </div>
                <div className="modal-body">
                    <div className="col-12">
                        <div className="row">
                            <div className="col-md-6 col-12">
                                <a className="signup-snippet" href="/login_work">
                                    <img src="/assets/images/for-work-icon.png" alt="icon" />
                                    <p>Login for work</p>
                                </a>
                            </div>
                            <div className="col-md-6 col-12">
                                <a className="signup-snippet" href="/login_hire">
                                    <img src="/assets/images/for-hire-icon.png" alt="icon" />
                                    <p>Login to hire</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </Modal>

        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        show: state.Home.show_login
        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(setFieldValues(f, v))
    }
};


export default connect(mapStateToProps, mapDispatchToProps)(SignModel);
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Autocomplete from "react-google-autocomplete";
import $ from "jquery";
import { View_Job, View_job_list,  } from "../../../actions/Employee/viewJob";
import { connect } from 'react-redux';
import {getIndustries} from "../../../actions/Home";

function View_navtab (props) {

  const[state, setState] = useState({
    employee_id: localStorage.getItem('employee_id'),
    filter:0,
    filter_by:null,
    location:null,
    lat:null,
    lon:null,
    radius_search:null,
    distance: null
  })

  useEffect(() => {
    $(document).ready(function () {
      window.$(".selectpicker").selectpicker();
    })
    props.getIndustries()
        // require("../../../assets/css/app-style.css");    
  }, []);

  useEffect(() => {
    $(document).ready(function () {
      window.$(".selectpicker").selectpicker('refresh');
    })
  })
    
  const gridStausChange = () => {
    props.setFieldValues("grid", true);
    // props.setFieldValues("grid_active", "active");
    props.setFieldValues("list", false);
    // props.setFieldValues("list_active", "");
    
  };
    
  const listStatusChange = () => {
    
    props.setFieldValues("list", true);
    // props.setFieldValues("list_active", "active");
    props.setFieldValues("grid", false);
    // props.setFieldValues("grid_active", "");
    
  };
  // console.log("search",props.grid_show,props.list_show)
   return(
    <React.Fragment>
      <div className="row">
      <div className="col-12 view-cont-hdr">
                <form className="custom-form row">
                <div className="form-group col-lg-4 col-md-6">
                    <img className="inside-input" src="assets/images/app/search-icon.svg" alt="icon" />
                    <select className="form-control lft-ico selectpicker"
                    data-live-search="true"    
                    title = "Choose Industry"
                    value = {state.filter_by}
                    id="industry"
                    onChange = {(e) => {setState({
                      ...state,
                      filter: 1,
                      filter_by : e.target.value
                    });
                    props.viewJobListAction({
                      employee_id: localStorage.getItem('employee_id'),
                      filter:1,
                      filter_by: e.target.value,
                      location:null
                    })
                  }
                    
                  }
                  >
                    
                  {/* <option value = "">Choose Industry</option> */}
                    {props.industries &&
                    props.industries.length > 0 &&
                    props.industries.map((i,k) => {
                        return <option
                        key = {k}
                        // id = {i.id}
                        value = {i.industry_type}>{i.industry_type}</option>
                        
                    })}
                  
                  </select>
                </div>
                <div className="form-group col-lg-4 col-md-6">
                    {/* <img className="inside-input" src="assets/images/app/location-pin-icon.svg" alt="icon" /> */}
                    <Autocomplete
                      apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                      className="form-control"
                      onChange = {(e) => {
                        console.log(state.filter_by, "on change ..................")
                        console.log($('#industry').val(), "jquery .................")
                        setState({
                          ...state,
                          filter_by: $('#industry').val(),
                          location:e.target.value
                        });
                        props.viewJobListAction({
                          employee_id: localStorage.getItem('employee_id'),
                          filter:1,
                          filter_by: $('#industry').val(),
                          location: e.target.value, 
                        })
                      }}
                      value = {state.location}
                      onPlaceSelected={(place) => {
                        
                        console.log(state, "on place select ..................")
                        console.log(place.geometry.location.lat());
                        console.log(place.geometry.location.lng());
                        setState({
                          ...state,
                          filter: 1,
                          filter_by:  $('#industry').val(),
                          location:place.formatted_address && place.formatted_address,
                          lat: place.geometry.location.lat(),
                          lon: place.geometry.location.lng(),
                        });
                        
                        props.viewJobListAction({
                          employee_id: localStorage.getItem('employee_id'),
                          filter:1,
                          // filter_by:  $('#industry').val(),
                          filter_by:null,
                          location:place.formatted_address && place.formatted_address,
                          // lat: place.
                        })
                          // console.log(place.geometry.location);

                          // console.log(this.props.lat);
                          // this.props.changeInput("lat", place.geometry.location.lat() !== '' ? place.geometry.location.lat() : this.props.lat);
                          // this.props.changeInput("lon", place.geometry.location.lng() !== '' ? place.geometry.location.lng() : this.props.lon);
                          // this.props.changeInput("location", place.formatted_address);
                      }}
                      options={{
                          types: ['address'],
                          // componentRestrictions: { country: "ru" },
                      }}
                      // defaultValue={this.props.location}
                    /> 
                    {/* <input className="form-control" 
                    onChange = {(e) => {
                      setState({
                        ...state,
                        location:e.target.value
                      });
                      props.viewJobListAction({
                        employee_id: localStorage.getItem('employee_id'),
                        filter:1,
                        filter_by: state.filter_by,
                        location:e.target.value
                      })
                    }}
                    value = {state.location}
                    type= "text" placeholder = "Singapore"/> */}
                    {/* <select className="form-control selectpicker lft-ico">
                    <option>St Andrews Lane, London, UK</option>
                    <option>Address line 1</option>
                    <option>Address line 2</option>
                    <option>Address line 3</option>
                    <option>Address line 4</option>
                    </select> */}
                </div>
                <div className="form-group col-lg-2 col-md-6 ">
                    <select className="form-control selectpicker"
                        data-live-search="true"    
                        title = "Choose One"
                        value = {state.distance}
                        onChange = {(e) => {setState({
                          ...state,
                          filter: 1,
                          distance: e.target.value,
                          radius_search: 1
                        });
                        
                    props.viewJobListAction({
                      employee_id: localStorage.getItem('employee_id'),
                      filter:1,
                      filter_by: null,
                      location:null,
                      lat: state.lat,
                      lon: state.lon,
                      distance: e.target.value,
                      radius_search:1
                    })
                  } }
                  >
                    <option value="10">5km to 10km</option>
                    <option value="15">10km to 15km</option>
                    <option value="25">15km to 25km</option>
                    <option value="35">25km to 35km</option>
                    {/* <option>Distance line 2</option>
                    <option>Distance line 3</option>
                    <option>Distance line 4</option> */}
                    </select>
                </div>
                {/* <div className="col-lg-2 col-md-6">
                    <a className="btn btn-search map">
                    <img src="assets/images/app/location-filled.png" alt="icon" />
                    </a>
                    <button className="btn btn-blue"
                    type = "button"
                    onClick = {() => {props.viewJobListAction(state)}}
                    >Search</button>
                </div> */}
                <div className="col-lg-2 col-md-6">
                    {/* <a className="btn btn-search map">
                    <img src="assets/images/app/location-filled.png" alt="icon" />
                    </a> */}
                    <button className="btn btn-blue"
                    type = "button"
                    onClick = {() => {
                      window.$('.selectpicker').selectpicker('val', '');
                      setState({
                        filter:0,
                        filter_by:"",
                        location:""  
                      })
                      props.viewJobListAction({
                      employee_id: localStorage.getItem('employee_id'),
                      filter:0,
                      filter_by:null,
                      location:null
                    })}}
                    >Reset All</button>
                </div>
                </form>
            </div>
        <div class="col-12 hdr-row ff-col">
          <ul class="nav nav-tabs">
            <li>
              <a class="active" data-toggle="tab" 
              href="#my_sear_jobs">
                Jobs
                <span class="badge">{props.job_list.length}</span>
              </a>
            </li>
            <li>
              <a data-toggle="tab" 
            
              href="#saved_jobs">
                Saved Jobs
                <span class="badge">{props.savedJobLists.length}</span>
              </a>
            </li>
            
          </ul>
        <div class="df-ac">
        <div className="btn-set mr-0">
          <a className={!props.viewStatuslist? "active":''} onClick={()=>{
            props.setFieldValues("viewStatuslist", false)}}>
              <img src="assets/images/app/grid-icon.svg" alt="icon" />
          </a>
          <a className={props.viewStatuslist ? "active":''} onClick={()=>{
            props.setFieldValues("viewStatuslist", true)}}>
              <img src="assets/images/app/list-icon.svg" alt="icon" />
          </a>
        </div>
        </div> 
    </div>
    </div>
  </React.Fragment>
  )
};

const mapStateToProps = (state, ownProps) => {
    return {
      show: state.Emp_View_Job.show_login,
      grid: state.Emp_View_Job.grid_active,
      list: state.Emp_View_Job.list_active,
      grid_show: state.Emp_View_Job.grid,
      viewStatuslist: state.Emp_View_Job.viewStatuslist,      
      job_list: state.Emp_View_Job.job_list,
      closed_job: state.Emp_View_Job.closed_jobs_list,
      show_alert: state.Emp_View_Job.show_alert,
      showMsg: state.Emp_View_Job.showMsg,
      sort_asc: state.Emp_View_Job.sort_asc,
      status: state.Emp_View_Job.active_status,
      varient: state.Emp_View_Job.varient,
      searchDisplay: state.Emp_View_Job.searchDisplay,
      savedJobLists : state.Emp_View_Job.savedJobLists,
      industries : state.Home.industries,
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
      setFieldValues: (f, v) => dispatch(View_Job(f, v)),
      getIndustries : () => dispatch(getIndustries()),
      viewJobListAction: (input) => dispatch(View_job_list(input)),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(View_navtab);
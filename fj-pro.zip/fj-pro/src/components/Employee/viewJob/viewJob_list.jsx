import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import Share from "../../Employer/Modals/shareModal";
import { View_Job, savedJob, ViewJobDetail, } from "../../../actions/Employee/viewJob";
import history from "../../../stores/history";
import { Link } from "react-router-dom"
import moment from 'moment';

function View_list(props) {
    // const[state, setState] = useState({
    //     employee_id: localStorage.getItem('employee_id'),
    //     filter:0,
    //     filter_by:null,
    //     location:null
    //   })
    useEffect(() => {
        // require("../../../assets/css/app-style.css");
       

    }, []);

    const sendFunc = (val) => {
        props.setFieldValues('job_id', val)
        history.push("/employee_view_jobs_details/"+val)
    };

    // console.log("native", props.job_list)
    return (

        <React.Fragment>
        <div className="col-12 pb-4">
        <div className="tab-content">
        <div id="my_sear_jobs" className="tab-pane fade in show active">
            <div className="row job-list">
            {(() => {
                
                if (props.job_list.length > 0) {
                    return (

                                props.job_list.map((lis, k) => {
                                    // let date1 = lis.start_date;
                                    // let date1arr = date1.split('/');
                                    // let date1change =date1arr[1]+"/"+date1arr[0]+"/"+date1arr[2];
                                    // let date2 = lis.end_date;
                                    // let date2arr = date2.split('/');
                                    // let date2change =date2arr[1]+"/"+date2arr[0]+"/"+date2arr[2]
                                    let stat_date = moment(new Date(lis.start_date)).format("ddd DD");
                                    let end_date = moment(new Date(lis.end_date)).format("ddd DD");
                                    return (
                                        <div className="col-12" key = {k}>

                                    <div className="job-snippet">
                                    
                                        <div className="img-wrap">
                                            <img className="img-fluid" 
                                            style = {{
                                                height : '136px'
                                            }}
                                            src={
                                                lis['employer.profile_url'] ?
                                                lis['employer.profile_url'] :
                                                process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                            } alt="img" 
                                            onClick={() => { 
                                                sendFunc(lis.id) }}
                                            />
                                             {
                                            lis.applied === 1 &&
                                            <span className="date badge">{"Applied"}</span>
                                            }
                                            <a href="javascript:;" 
                                            className = {`favorite ${lis.saved 
                                            === '1' || lis.saved === 1
                                            ? 'saved':''}`}
                                        
                                            onClick = {(e) => {
                                                
                                                props.savedJob({
                                                    employee_id:localStorage.getItem('employee_id'),
                                                    job_id:lis.id,
                                                    saved:lis.saved === '0' || lis.saved === 0 ? '1' : '0' 
                                                })
                                            }}
                                            >
                                            <img src="assets/images/app/heart-icon.svg"
                                            alt="icon" />
                                            </a>

                                        </div>
                                        <div className="r-job-item">
                                            <div className="dropdown more">
                                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <img src="assets/images/app/more-btn.svg" />
                                                </button>
                                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                                    <ul className="list-unstyled">
                                                        {/* <li>
                                                            <Link 
                                                            to = {`employee/chat/${lis.employerId}`}
                                                            >
                                                                Chat
                                                            </Link>
                                                        </li> */}
                                                        <li><a href="javascript:;" onClick={() => {
                                                        props.setFieldValues("share_show", true)
                                                        props.detailsCall(lis.id)
                                                        }}>Share</a></li>
                                                        {/* <li><a href="javascript:;" className="red">Decline</a></li> */}
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-md-8"
                                                onClick={() => { 
                                                    sendFunc(lis.id) }}
                                                >
                                                    <h6>{lis.job_title}</h6>
                                                    <span className="job-type text-truncate">
                                                        {lis['employer.company_name']}
                                                    </span>
                                                    <p className="text-truncate">Salary {lis.currency} {new Intl.NumberFormat('en-US', 
                                                    {style: 'decimal', minimumFractionDigits: 2}).
                                                    format(isNaN(lis.amount)
                                                    ? '0.00':lis.amount)} {lis.salary_based}
                                                        {" "}({stat_date} - {end_date})
                                                    </p>
                                                    {/* <span className="date badge"></span> */}
                                                    <span className="location text-truncate d-block">
                                                        <img src="assets/images/app/location-pin-icon.svg" alt="icon" />
                                                        {!lis.job_location ? 
                                                        "" : lis.job_location}
                                                    </span>
                                                </div>
                                                <div className="col-md-4 text-left text-md-right job-l-right">
                                                    {
                                                        lis.expiration_date !== 0 &&
                                                        <p className="expire">
                                                        Job Expires in {lis.expiration_date}{" "}{
                                                        lis.expiration_date === 1? 
                                                        'day' : 'days'
                                                        } 
                                                            </p>
                                                    }
                                                    
                                                    <button className="btn btn-blue px-4 mt-5" onClick={() => { 
                                                    sendFunc(lis.id) }}>
                                                    More Info
                                                    </button>
                                                </div>
                                            </div>
                                            </div>
                                            </div>
                                        </div>
                                    )
                                })
                    )
                } else {
                    return (
                        <div className="empty-job">
                            <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                            <p>There's nothing here.</p>
                        </div>
                    )
                }
            })()}
            </div>
            </div>
            <div id="saved_jobs" className="tab-pane fade">
            <div className="row job-list">
            {(() => {
                if (props.savedJobLists.length > 0) {
                return (
                props.savedJobLists.map((lis, k) => {
                    
                // let date1 = lis.start_date;
                // let date1arr = date1.split('/');
                // let date1change =date1arr[1]+"/"+date1arr[0]+"/"+date1arr[2];
                // let date2 = lis.end_date;
                // let date2arr = date2.split('/');
                // let date2change =date2arr[1]+"/"+date2arr[0]+"/"+date2arr[2]
                let stat_date = moment(new Date(lis[0].start_date)).format("ddd DD");
                let end_date = moment(new Date(lis[0].end_date)).format("ddd DD");
                return (
                    <div className="col-12" key = {k}>
                        
                        <div className="job-snippet">
                            <div className="img-wrap">
                                <img className="img-fluid" src={
                                    lis && lis.employer &&
                                    lis.employer.profile_url !== null &&
                                    lis.employer.profile_url !== 'null' &&
                                    lis.employer.profile_url !== ''
                                    ?
                                    lis.employer.profile_url :
                                    process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                } alt="img" onClick={() => { 
                                        sendFunc(lis[0].id) }}/>
                                        {
                                            lis.applied === 1 &&
                                            <span className="date badge">{lis.applied}</span>
                                        }
                                
                                <a href="javascript:;" className = {`favorite saved`}
                       
                       onClick = {(e) => {
                           // let val = gri[0].saved === '1'
                           // ? '0' : '1'
                           props.savedJob({
                               employee_id:localStorage.getItem('employee_id'),
                               job_id:lis[0].id,
                               saved:'0'
                           })
                       }}
                       >
                           <img src="assets/images/app/heart-icon.svg" alt="icon" />
                       </a>
                            </div>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                    <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <img src="assets/images/app/more-btn.svg" />
                                    </button>
                                    <div className="dropdown-menu" aria-labelledby="more-menu">
                                        <ul className="list-unstyled">
                                            {/* <li>
                                                <Link 
                                                to = {`employee/chat/${lis[0].employerId}`}
                                                >
                                                    Chat
                                                </Link>
                                            </li> */}
                                            <li><a href="javascript:;" onClick={() => {
                                            props.setFieldValues("share_show", true)
                                            props.detailsCall(lis[0].id)
                                            }}>Share</a></li>
                                            {/* <li><a href="javascript:;" className="red">Decline</a></li> */}
                                        </ul>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-8"
                                    onClick={() => { 
                                        sendFunc(lis[0].id) }}
                                    >
                                        <h6>{lis[0].job_title}</h6>
                                        <span className="job-type text-truncate">
                                        {lis[0]['employer.company_name']}
                                        </span>
                                        <p className="text-truncate">Salary {lis[0].currency} {new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(lis[0].amount)
                                        ? '0.00':lis[0].amount)} {lis[0].salary_based}
                                        {" "} ({stat_date} - {end_date})
                                        </p>
                                        <span className="location text-truncate d-block">
                                            <img src="assets/images/app/location-pin-icon.svg" alt="icon" />
                                            {!lis[0].job_location ? 
                                            lis[0].employer.location : lis[0].job_location}
                                        </span>
                                    </div>
                                    <div className="col-md-4 text-left text-md-right job-l-right">
                                        {
                                            lis[0].expiration_date !== 0 &&
                                            <p className="expire">
                                            Job Expires in {lis[0].expiration_date} {" "}{
                                            lis[0].expiration_date === 1? 
                                            'day' : 'days'
                                            } 
                                            </p>
                                        }
                                        
                                        <button className="btn btn-blue px-4 mt-5" onClick={() => { 
                                        sendFunc(lis[0].id) }}>
                                        More Info
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    )
                })
                )
                } else {
                    return (
                        <div className="empty-job">
                            <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                            <p>There's nothing here.</p>
                        </div>
                    )
                }
            })()}

            </div>
            </div>
            </div>
            </div>
            {/* <div className="map-sec">
                <div className="col-12 hdr-row">
                    <h2>Map</h2>
                    <a className="close" href="javascript:;"><img src="images/app/cross-black.svg" alt="icon" /></a>
                </div>
                <div className="col-12 px-0">
                    <img className="img-fluid w-100" src="images/app/map-img.png" alt="Map" />
                </div>
            </div> */}
            <Share />
        </React.Fragment>

    )

};

const mapStateToProps = (state, ownProps) => {
    return {
        job_list: state.Emp_View_Job.job_list,
        closed_job: state.Emp_View_Job.closed_jobs_list,
        status: state.Emp_View_Job.active_status,
        savedJobLists : state.Emp_View_Job.savedJobLists,
        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(View_Job(f, v)),
        detailsCall: (id) => dispatch(ViewJobDetail(id)),
        savedJob: (data) => dispatch(savedJob(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(View_list);
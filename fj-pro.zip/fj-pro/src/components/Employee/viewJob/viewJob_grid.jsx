import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import Share from "../../Employer/Modals/shareModal";
import { View_Job, View_job_list, ViewJobDetail, savedJob } from "../../../actions/Employee/viewJob";
import history from "../../../stores/history";
import { Link } from "react-router-dom"
import moment from 'moment';
import jQuery from "jquery";

function View_grid (props) {
    
    useEffect(() => {
        // require("../../../assets/css/app-style.css");
            
    },[]);
    return(

        <React.Fragment>
        
        <div className="col-12">
        <div className="tab-content">
        <div id="my_sear_jobs" className="tab-pane fade in show active">
        {props.job_grid && props.job_grid.length > 0 ?
             <div className="row dashboard-snip-sec">
                {
                    props.job_grid.map((gri, k) => {
                    var date1 = new Date(gri.createdAt);
                    var date2 = new Date();
                    var Difference_In_Time = date2.getTime() - date1.getTime();
                    var Difference_In_Days =  Math.round(Difference_In_Time / (1000 * 3600 * 24));
                    return (
                    <div className="col-xl-3 col-lg-4 col-md-6" key = {k}>
                    <div className="job-snippet profile-snippet">
                    <a 
                        className="img-wrap"
                        href="javascript:;"
                        >
                        <img className="img-fluid" 
                         src={
                            gri['employer.profile_url'] ?
                            gri['employer.profile_url'] :
                            process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                        }
                        onClick = {() => {
                            let path = `employee_view_jobs_details/${gri.id}`
                            history.push(path)             
                        }}
                        alt="img" />
                        { Difference_In_Days == 0 ? (
                            <span className="new badge">New</span>
                        ):(
                            null
                        )}
                        { Difference_In_Days == 0 ?(
                            null
                        ):(
                        <span className="date badge">
                            {
                            Difference_In_Days === 1 ?
                            Difference_In_Days + ' Day Ago':Difference_In_Days + ' Days Ago'
                            } 
                        </span>
                        )}
                        <a href="javascript:;" className = {`favorite ${gri.saved 
                        === '1' || gri.saved === 1
                        ? 'saved':''}`}
                       
                        onClick = {(e) => {
                            
                            props.savedJob({
                                employee_id:localStorage.getItem('employee_id'),
                                job_id:gri.id,
                                saved:gri.saved === '0' || gri.saved === 0 ? '1' : '0' 
                            })
                        }}
                        >
                            <img src="assets/images/app/heart-icon.svg" alt="icon" />
                        </a>
                    </a>
                        <div className="r-job-item">
                            <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                        {/* <li>
                                        <Link 
                                            to = {`employee/chat/${gri.employerId}`}
                                            >
                                            Chat
                                        </Link>
                                        </li> */}
                                        <li><a href="javascript:;"onClick={() => {
                                            props.setFieldValues("share_show", true)
                                            props.detailsCall(gri.id)
                                            }}
                                            >Share
                                            </a>
                                        </li>
                                        <li>
                                            {/* <Link 
                                            // href="javascript:;" 
                                            to = { () => {history.push("/employee_view_jobs_details/"+gri.id)}}
                                            className="red">
                                            More Info
                                            </Link> */}
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <h6 className="text-truncate"
                            onClick = {() => {
                                let path = `employee_view_jobs_details/${gri.id}`
                                history.push(path)             
                            }}
                            >{gri.job_position}</h6>
                            <span className="job-type text-truncate"
                            onClick = {() => {
                                let path = `employee_view_jobs_details/${gri.id}`
                                history.push(path)             
                            }}
                            >{gri.industry_type}</span>
                            <p className="text-truncate"
                            onClick = {() => {
                                let path = `employee_view_jobs_details/${gri.id}`
                                history.push(path)             
                            }}
                            >{gri.job_title} | {gri.salary_based}{gri.currency} {new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(gri.amount)
                                        ? '0.00':gri.amount)
                            } {gri.salary_based}</p>
                            <span className="location text-truncate d-block" 
                            onClick = {() => {
                                let path = `employee_view_jobs_details/${gri.id}`
                                history.push(path)             
                            }}
                            >
                                <img src="assets/images/app/location-pin-icon.svg" alt="icon" />
                                {!gri.job_location ? 
                                "" : 
                                gri.job_location}
                            </span>
                        </div>
                    </div>
                </div>
                
                
                        )
                    })
                }
             
             </div> : (
                        <div className="empty-job">
                         <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                         <p>There's nothing here.</p>
                     </div>
             )

        }
       
        </div>
        <div id="saved_jobs" className="tab-pane fade">
        {props.savedJobLists && props.savedJobLists.length > 0 ?
             <div className="row dashboard-snip-sec">
                {
                    props.savedJobLists.map((gri, k) => {
                    var date1 = new Date(gri[0].createdAt);
                    var date2 = new Date();
                    var Difference_In_Time = date2.getTime() - date1.getTime();
                    var Difference_In_Days =  Math.round(Difference_In_Time / (1000 * 3600 * 24));
                    return (
                    <div className="col-xl-3 col-lg-4 col-md-6" key = {k}>
                    <div className="job-snippet profile-snippet">
                    <a 
                        className="img-wrap"
                        href="javascript:;"
                        >
                        <img className="img-fluid" 
                        src={
                            gri && gri.employer &&
                            gri.employer.profile_url !== null &&
                            gri.employer.profile_url !== 'null' &&
                            gri.employer.profile_url !== ''
                            ?
                            gri.employer.profile_url :
                            process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                        }
                        onClick = {() => {
                            let path = `employee_view_jobs_details/${gri[0].id}`
                            history.push(path)             
                        }}
                        alt="img" />
                        { Difference_In_Days == 0 ? (
                            <span className="new badge">New</span>
                        ):(
                            null
                        )}
                        { Difference_In_Days == 0 ?(
                            null
                        ):(
                        <span className="date badge">
                            {
                            Difference_In_Days === 1 ?
                            'Day Ago':'Days Ago'
                            } 
                        </span>
                        )}
                        <a href="javascript:;" className = {`favorite saved`}
                       
                        onClick = {(e) => {
                            // let val = gri[0].saved === '1'
                            // ? '0' : '1'
                            
                            props.savedJob({
                                employee_id:localStorage.getItem('employee_id'),
                                job_id:gri[0].id,
                                saved:'0'
                            })
                        }}
                        >
                            <img src="assets/images/app/heart-icon.svg" alt="icon" />
                        </a>
                    </a>
                        <div className="r-job-item">
                            <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                        {/* <li>
                                        <Link 
                                            to = {`employee/chat/${gri[0].employerId}`}
                                            >
                                            Chat
                                        </Link>
                                        </li> */}
                                        <li><a href="javascript:;"onClick={() => {
                                            props.setFieldValues("share_show", true)
                                            props.detailsCall(gri[0].id)
                                            }}
                                            >Share
                                            </a>
                                        </li>
                                        <li>
                                            {/* <Link 
                                            // href="javascript:;" 
                                            to = { () => {history.push("/employee_view_jobs_details/"+gri[0].id)}}
                                            className="red">
                                            More Info
                                            </Link> */}
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <h6 className="text-truncate"
                             onClick = {() => {
                                let path = `employee_view_jobs_details/${gri[0].id}`
                                history.push(path)             
                            }}
                            >{gri[0].job_position}</h6>
                            <span className="job-type text-truncate"
                             onClick = {() => {
                                let path = `employee_view_jobs_details/${gri[0].id}`
                                history.push(path)             
                            }}
                            >{gri[0].industry_type}</span>
                            <p className="text-truncate"
                             onClick = {() => {
                                let path = `employee_view_jobs_details/${gri[0].id}`
                                history.push(path)             
                            }}
                            >{gri[0].job_type} | {gri[0].salary_based}{gri[0].currency} {gri[0].amount}</p>
                            <span className="location text-truncate d-block"
                             onClick = {() => {
                                let path = `employee_view_jobs_details/${gri[0].id}`
                                history.push(path)             
                            }}
                            >
                                <img src="assets/images/app/location-pin-icon.svg" alt="icon" />
                                {!gri[0].job_location ? 
                                gri[0].employer.location : 
                                gri[0].job_location}
                            </span>
                        </div>
                    </div>
                </div>
                
                
                        )
                    })
                }
             
             </div> : (
                        <div className="empty-job">
                         <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                         <p>There's nothing here.</p>
                     </div>
             )

        }
       
        </div>
        </div>
        </div>

        <Share />
    </React.Fragment>
    )

};


const mapStateToProps = (state, ownProps) => {
    return {
        job_grid: state.Emp_View_Job.job_list,
        status: state.Emp_View_Job.active_status,
        savedJobLists : state.Emp_View_Job.savedJobLists
        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {

        setFieldValues: (f, v) => dispatch(View_Job(f, v)),
       
        detailsCall: (id) => dispatch(ViewJobDetail(id)),
        savedJob: (data) => dispatch(savedJob(data))
        
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(View_grid);
import React, { useEffect } from "react";
import Header from "../../Common/App/AppHeader";
import { connect } from 'react-redux';
import { View_Job,setShow, View_job_list, 
ApplyJob, ViewJobDetail } from "../../../actions/Employee/viewJob";
import Alert from "react-bootstrap/Alert";
import {Link} from "react-router-dom";
import moment from 'moment';
import history from "../../../stores/history";
import $ from 'jquery'
import NotifyModel from "../../NotifyModel"
function View_details (props) {
    useEffect(() => {
        // require("../../..//assets/css/app-style.css");
        props.detailsCall(window.location.pathname.split('/')[2]);
    },[]);
    
    useEffect(()=> {
      if (props.varient === "success" || props.varient === "danger") {
        setTimeout(function() {
          props.setFieldValues('show_alert', false)
        }, 5000)
      }
    })
    // console.log("det",props.job_id)
    return(
      <React.Fragment>
        <div className="container-fluid">
          {/* header Starts here */}
          <Header />
          {/* header Ends here */}
          {/* Main Content Starts here */}
          <section className="row main-content">
            <div className="container">
              <div className="row">
                <div className="col-12 hdr-row">
                  <h1>
                    <Link 
                    // to = { history.goBack()}
                    // href="javascript:;" 
                    onClick={() => 
                      history.goBack()
                    } 
                    className="back n__back-button"
                    >
                      <img src="/assets/images/app/back-arrow.svg" alt="icon" /> 
                      <span
                      style={{marginLeft:'20px'}}
                      >Back</span>
                    </Link>
                    {/* Back */}
                  </h1>
                  <div>
                    {/* <a href="javascript:;" 
                    className="btn btn-gray mr-2">Chat</a> */}
                    <a href="javascript:;" className="btn btn-blue"
                    onClick = { () => {
                      
                      if (localStorage.notify_model === '1') {
                        window.$('#notify-model').modal('show')
                      } else {
                       
                        props.ApplyJob({
                          job_id : window.location.pathname.split("/")[2],
                          employee_id : localStorage.getItem('employee_id'),
                          employer_id : props.get_details && props.get_details[0] 
                          && props.get_details[0].employerId
                        })
                      }

                    }}
                    >
                      {
                     
                      props.applyLoad ? 'Loading...':'Apply'}
                      </a>
                  </div>
                </div>
                {
                // console.log(props.get_details, 'props.get_details'),
                props.get_details.length > 0 ?
                props.get_details.map((det, k)=> {
                return(
                <div className="col-12 mb-5" key = {k}>
                  <Alert
                    show={props.show_alert}
                    variant={props.varient}
                    dismissible
                    onClose={() => props.setShow(false)}
                    >
                    <strong>
                        {props.job_applied_status === 1
                        ? "Success!"
                        : "Error!"}
                    </strong>{" "}
                    {props.showMsg}
                    </Alert>
                  <div className="snippet-box p-4 job-detail">
                    <div className="row">
                      <div className="col-md-4 lft-col">
                        <div className="img-wrap">
                          <img className="img-fluid" src="/assets/images/app/job-snip-img.jpg" alt="image" />
                        </div>
                        <div className="row job-desc mt-4">
                        <div className="col-12">
                        {/* <h4 className="mb-3">Basic Info </h4>
                         */}
                         <h4 className="mb-3">Time & Location </h4>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Start Date</p>
                            </div>
                            <div className="col-md-7">
                            <span>
                              {moment(new Date(det.start_date)).format("DD MMMM YYYY")}
                            </span>
                            </div>
                        </div>
                       
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>End Date</p>
                            </div>
                            
                            <div className="col-md-7">
                            <span>
                            {moment(new Date(det.end_date)).format("DD MMMM YYYY")}
                            </span>
                            </div>
                            
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Start Time</p>
                            </div>
                            
                            <div className="col-md-7">
                            <span>
                            {det.start_time}
                            </span>
                            </div>
                            
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>End Time</p>
                            </div>
                            
                            <div className="col-md-7">
                            <span>
                           {det.end_time}
                            </span>
                            </div>
                            
                        </div>
                        {/* {
                          det.job_requirements &&
                          det.job_requirements.length > 0 &&
                          det.job_requirements[2].requirement !== "" ?
                        
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Requirements</p>
                            </div>
                            
                            <div className="col-md-7">
                            <span>
                            {det.job_requirements[2].requirement === "0" ||
                            det.job_requirements[2].requirement === "1" ?
                            '' :det.job_requirements[2].requirement
                             }
                            </span>
                            </div>
                            
                        </div> :""
                       } */}
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Location</p>
                            </div>
                            
                            <div className="col-md-7">
                            <a
                            target="blank" 
                            style= {{
                              fontSize:'14px'
                            }}
                            href={`http://maps.google.com/?q=${det.job_location}`}>{
                            det.job_location
                            }</a>
                            {/* <span>
                            {det.job_location}
                            </span> */}
                            </div>
                            
                        </div>
                        
                        </div>
                    </div>
                      {/* <div className="row job-desc contact mt-4 mb-4">
                          <div className="col-12">
                            <h4 className="mb-3">Contact</h4>
                            <p>
                              <img src="/assets/images/app/ic-email.svg" alt="icon" />
                              <a href="mailto:amanda.reyes99@gmail.com">{det.employer.email}</a>
                            </p>
                            <p>
                              <img src="/assets/images/app/ic-gps-pin.svg" alt="icon" />
                              {!det.job_location ? '' : det.job_location}
                            </p>
                            <p>
                              <img src="/assets/images/app/ic-phone.svg" alt="icon" />
                              <a href="tel:(499)-430-5810">{det.employer.contact_mobile}</a>
                            </p>
                          </div>
                        </div> */}
                      </div>
                      <div className="col-md-8 rgt-col">
                        <div className="row job-desc">
                          <div className="col-12">
                            <h4 className="mb-3">Company Info</h4>
                            <h2 className="mb-1">{det.job_position}</h2>
                            <span className="designation dark">{
                            det.employer &&
                            det.employer.company_name
                            }</span>
                            <p className="job-desc-light mt-3">{det.job_description}</p>
                          </div>
                        </div>
                        <div className="row job-desc mt-2">
                          <div className="col-xl-6 col-lg-12 mt-4">
                            
                            <div className="row mb-3">
                              <h4 className="col-12">Job Info</h4>
                              <div className="col-md-5">
                                <p>Salary/hour</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.currency}{new Intl.NumberFormat('en-US', 
                                {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(det.amount)? '0.00':det.amount)}</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Working Hrs/Day </p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.number_of_hours}{
                                  det.number_of_hours === '1.0' ?
                                  ' Hr' : ' Hrs'
                                }</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Working Days</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.number_of_days}{
                                  det.number_of_days === '1' ?
                                  ' day' : ' days'
                                }</span>
                              </div>
                            </div>
                            
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Industry</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.industry_type}</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Job Title</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.job_title}</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Vacancy</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.job_vacancy}</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Gender</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.gender}</span>
                              </div>
                            </div>
                       
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Total Payout </p>
                              </div>
                              <div className="col-md-7">
                                <span>
                                 RM {det.job_salaries &&
                                  det.job_salaries.length > 0 &&
                                  det.job_salaries[0].total_salary_base_by_employer
                                }</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Employment Type</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.job_type}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                )}) : ''
              }
              </div>
            </div>
          </section>
          {/* Main Content Ends here */}
        </div>
        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
        <NotifyModel/>
        </React.Fragment>
    )
};

const mapStateToProps = (state, ownProps) => {
  return {
      job_list: state.Emp_View_Job.job_list,
      get_details:state.Emp_View_Job.get_details,
      job_id:state.Emp_View_Job.job_id,
      job_applied_status:state.Emp_View_Job.job_applied_status,
      applyLoad:state.Emp_View_Job.applyLoad,
      show_alert:state.Emp_View_Job.show_alert,
      varient:state.Emp_View_Job.varient,
      showMsg:state.Emp_View_Job.showMsg,
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(View_Job(f, v)),
        detailsCall: (id) => dispatch(ViewJobDetail(id)),
        ApplyJob : (data) => dispatch(ApplyJob(data)),
        setShow: (data) => dispatch(setShow(data)),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(View_details);
import React,{useEffect} from "react";
import { Dasboard,JobCard } from "../../../actions/Employee/Dashboard";
import { connect } from 'react-redux';
import { Link } from "react-router-dom";

function JobCardShow (props) {

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
      props.getCard();
    }, []);

    return(
        <React.Fragment>
             <div className="col px-0">
                <div className="hdr-row snippet mb-3">
                  <h3 className="mb-0">
                    Based on your profile and career interest
                  </h3>
                </div>
                <div className="row dashboard-snip-sec">
                {props.get_card.length > 0 ? props.get_card.map((val, k)=>{
                  var date1 = new Date(val.createdAt);
                  var date2 = new Date();
                  var Difference_In_Time = date2.getTime() - date1.getTime();
                  var Difference_In_Days =  Math.round(Difference_In_Time / (1000 * 3600 * 24));
                return(                        
                  <div className="col-lg-4 col-md-6" key= {k}>
                  <Link className="job-snippet profile-snippet"
                  to = {`employee_view_jobs_details/${val.id}`}
                  >
                    <div className="img-wrap">
                      <img className="img-fluid" src="/assets/images/app/job-snip-img-1.jpg" alt="img" />
                      {/* <span className="new badge">New</span> */}
                      {/* <span className="date badge">2 Days Ago</span> */}
                      { Difference_In_Days == 0 ? (
                          <span className="new badge">New</span>
                      ):(
                        null
                      )}
                      { Difference_In_Days == 0 ?(
                        null
                      ):(
                      <span className="date badge">{Difference_In_Days} Days Ago</span>
                      )}
                      <a href="javascript:;" className="favorite">
                        <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                      </a>
                    </div>
                    <div className="r-job-item">
                    <h6 className="text-truncate">{val.job_position}</h6>
                      <span className="job-type text-truncate">
                        
                           {val.industry_type}
                        
                        {/* Roseberry portfolio solutions Pvt Ltd */}
                      </span>
                      <p className="text-truncate">
                      {val.job_title} | {val.salary_based} {val.currency}{new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}
                        </p>
                      <span className="location text-truncate d-block">
                        <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                        {val.job_location}
                      </span>
                    </div>
                  </Link>
                </div>
    
                // <div className="col-lg-4 col-md-12 px-0">
                //     <div className="job-snippet profile-snippet">
                //       <div className="img-wrap">
                //         <img
                //           className="img-fluid"
                //           src="assets//assets/images/app/job-snip-img-1.jpg"
                //           alt="img"
                //         />
                //         <span className="new badge">New</span>
                //         <span className="date badge">2 Days Ago</span>
                //         <a href="javascript:;" className="favorite">
                //           <img
                //             src="assets//assets/images/app/heart-icon.svg"
                //             alt="icon"
                //           />
                //         </a>
                //       </div>
                //       <div className="r-job-item">
                //         <h6 className="text-truncate">{val.job_position}</h6>
                //         <span className="job-type text-truncate">
                //           {val.industry_type}
                //         </span>
                //         <p className="text-truncate">
                //           {val.job_type} | {val.salary_based} {val.currency} {val.amount}
                //         </p>
                //         <span className="location text-truncate d-block">
                //           <img
                //             src="assets//assets/images/app/location-pin-icon.svg"
                //             alt="icon"
                //           />
                //           Nissi Fresh Store, Kuala Lumpur, Malaysia
                //         </span>
                //       </div>
                //     </div>
                //   </div>
                  )}
                  )
                  :<div className = "no-article"
                  style = {{
                    textAlign: 'center',
                    marginLeft: '173px',
                    marginTop: '151px'
                  }}
                  >   
                  <b className="text-truncate">{
                    "Please Update your Skills to view relevent jobs "
                    }</b>
                    </div>
                } 
                  </div>
                  </div>
            
        </React.Fragment>

    )
};




const mapStateToProps = (state, ownProps) => {
    return {
      get_card: state.Emp_Dasboard.job_card,
      
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(Dasboard(f, v)),
        getCard :()=>dispatch(JobCard()),
      
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(JobCardShow);
import React,{useEffect} from "react";
import { Dasboard,JobOffer,AcceptOffer,DeclineOffer } from "../../../actions/Employee/Dashboard";
import { connect } from 'react-redux';
import moment from 'moment';
import history from '../../../stores/history'
import $ from "jquery"
import {
  acceptedOffers,rejectOffers,
  ConfirmOffer, ViewOffers
}from '../../../actions/Employee/Offers'
import { Link } from "react-router-dom";

function JobOfferDetails (props) {

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        props.getOffer();
      }, []);


    return(
        <React.Fragment>
            <div className="col-lg-12 col-md-12 px-0">
              <div className="col px-0 h-100">
                <h3>{
                  props.get_offer &&
                  props.get_offer.length > 0 &&
                  props.get_offer.map(i => {
                    if (i.application_status === 'on-board') {
                      i.application_status = 'On Board'
                    } else if (i.application_status === 'hired') {
                      i.application_status = 'Job Offer'
                    } else if (i.application_status === 'offer-accepted') {
                      i.application_status = 'Accepted Offer'
                    } else if (i.application_status === 'completed') {
                      i.application_status = 'Completed Work'
                    } else {
                      i.application_status = 'Ongoing Work'
                    }
                    return(i.application_status)
                  }) 
                  }</h3>
                {props.get_offer &&
                props.get_offer.length > 0 ? props.get_offer.map((val, k)=> {
                return(
                <div className="r-job-item job-offer" key= {k}>
                  <div className="dropdown more dd-active">
                    <button
                      className="btn dropdown-toggle"
                      type="button"
                      id="more-menu"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      <img src="assets/images/app/more-btn.svg" />
                    </button>
                    <div className="dropdown-menu" aria-labelledby="more-menu">
                      <ul className="list-unstyled">
                      {
                           val.application_status === 'Job Offer' ||
                           val.application_status === 'Accepted Offer'  ? 
                        <li>
                        
                            <a href="javascript:;"  onClick={()=>{
                              if (val.application_status === 'Job Offer'){
                                props.acceptedOffers({
                                  application_id:val.id,
                                  status_code:4,
                                })
                              } else if (val.application_status === 'Accepted Offer') {
                                props.ConfirmOffer({
                                  application_id:val.id
                                })
                              } else if (val.application_status === 'on-board') {
  
                              } else if (val.application_status === 'completed') {
  
                              } else {
  
                              }
                            }
                            }
                              >
                              {
                              val.application_status === 'Job Offer' ? 'Accept Offer'
                              :val.application_status === 'Accepted Offer' ? 'Confirm '
                              :val.application_status === 'on-board' ? 'on board'
                              :val.application_status === 'working' ? 'Working':
                              'Request Payment'
                              }
                              </a> 
                        </li>
                        : ""
                        }
                        {/* <li>
                          <a href='#'
                          >
                            Chat
                          </a>
                        </li> */}
                        <li>
                          <a href="javascript:;" className="red"  onClick={()=>{
                            props.rejectOffers({
                              application_id:val.id
                            })}}>
                            Reject
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <h6 className="mb-1 pr-4">{val.job ? val.job.job_title: ''}</h6>
                  <p className="mb-4 pr-4 mt-1">
                    {val.job && val.job.employer.company_name},
                     {val.job && val.job.job_location}
                  </p>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>Company Name</p>
                    </div>
                    <div className="col-6">
                      <span>
                        
                        {val.job && val.job.employer && 
                        val.job.employer.company_name &&
                        val.job.employer.company_name
                        }
                      </span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>Position</p>
                    </div>
                    <div className="col-6">
                      <span>
                        
                        {val.job && val.job.job_position && 
                        val.job.job_position
                        }
                      </span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>Start Date</p>
                    </div>
                    <div className="col-6">
                      <span>
                        
                        {val.job && val.job.start_date && 
                        moment(new Date(val.job.start_date)).format("DD MMMM YYYY")
                        }
                      </span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>End Date</p>
                    </div>
                    <div className="col-6">
                      {
                        val.job &&
                        <span>{moment(new Date(val.job.end_date)).format("DD MMMM YYYY")}
                        </span>
                      }
                      
                    </div>
                  </div>
                  
                  {/* <div className="row mb-2">
                    <div className="col-6">
                     
                      <p>{val.job && val.job.salary_based
                      }</p>
                    </div>
                    <div className="col-6">
                      <span>{val.job && val.job.currency} {val.job && 
                      new Intl.NumberFormat('en-US', 
                      {style: 'decimal', minimumFractionDigits: 2}).
                      format(isNaN(val.job.amount)
                      ? '0.00':val.job.amount)
                      }</span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>No of Hour(Per Day)</p>
                    </div>
                    <div className="col-6">
                      <span>{val.job && 
                       val.job.number_of_hours
                      }</span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>No of Days</p>
                    </div>
                    <div className="col-6">
                      <span>{val.job && val.job.number_of_days}</span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>{val.job 
                      && val.job.job_salaries.length > 0
                      && val.job.job_salaries[0].salary_for === 'below-60'?
                      'EPF (9%)':'EPF (0%)'
                      }</p>
                    </div>
                    <div className="col-6">
                      <span>RM{val.job && val.job.job_salaries 
                      && val.job.job_salaries.length > 0 
                        && 
                        new Intl.NumberFormat('en-US', 
                      {style: 'decimal', minimumFractionDigits: 2}).
                      format(isNaN(val.job.job_salaries[0].employee_epf)
                      ? '0.00':val.job.job_salaries[0].employee_epf)
                        }</span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>{val.job 
                      && val.job.job_salaries
                      && val.job.job_salaries.length > 0
                      && val.job.job_salaries[0].salary_for === 'below-60'?
                      'Socso (0.5%)':'Socso (0%)'
                      }</p>
                    </div>
                    <div className="col-6">
                      <span>RM{val.job && val.job.job_salaries 
                      && val.job.job_salaries.length > 0
                      && 
                      new Intl.NumberFormat('en-US', 
                      {style: 'decimal', minimumFractionDigits: 2}).
                      format(isNaN(val.job.job_salaries[0].employee_Socso)
                      ? '0.00':val.job.job_salaries[0].employee_Socso)
                      }</span>
                    </div>
                  </div>
                  <div className="row mb-2">
                    <div className="col-6">
                      <p>
                      {val.job 
                      && val.job.job_salaries
                      && val.job.job_salaries.length > 0
                      && val.job.job_salaries.salary_for === 'below-60'?
                      'EIS (0.2%)':'EIS (0%)'
                      }
                      </p>
                    </div>
                    <div className="col-6">
                      <span>RM{val.job && val.job.job_salaries 
                      && val.job.job_salaries.length > 0
                      && new Intl.NumberFormat('en-US', 
                      {style: 'decimal', minimumFractionDigits: 2}).
                      format(isNaN(val.job.job_salaries[0].employee_eis)
                      ? '0.00':val.job.job_salaries[0].employee_eis)
                        }</span>
                    </div>
                  </div>
                  <div className="row mb-4">
                    <div className="col-6">
                      <p>Total Pay</p>
                    </div>
                    <div className="col-6">
                      <span>
                        <strong>{val.job && val.job.currency} {""}
                        {val.job && val.job.job_salaries
                        && val.job.job_salaries.length > 0 
                        && 
                        new Intl.NumberFormat('en-US', 
                      {style: 'decimal', minimumFractionDigits: 2}).
                      format(isNaN(val.job.job_salaries[0].reduced_salary_for_employee)
                      ? '0.00':val.job.job_salaries[0].reduced_salary_for_employee)
                        
                        }</strong>
                      </span>
                    </div>
                  </div> */}
                  <div className="row">
                    <div className="col-5 pr-0">
                      <Link className="btn btn-gray w-100"
                      to = {
                        // val && val.application_status === 'hired'?
                        // `view-job-offer/${val.id}`:
                        // val.application_status === 'offer-accepted'?
                        `view-job-offer/${val.application_status}/${val.id}`
                        // :''
                      }
                      
                      >
                     {
                    //  val && val.application_status === 'hired' ? 'View'
                    //   :val.application_status === 'offer-accepted' ? 'View'
                      // :val.application_status === 'on-board' ? 'Chat'
                      // :val.application_status === 'working' ? 'Chat':
                      // :val.application_status === 'on-board' ? 'View'
                      // :val.application_status === 'working' ? 'View':
                      'View'
                      }
                      </Link>
                    </div>
                    <div className="col-7">
                      {
                        val.application_status === 'Job Offer' ||
                        val.application_status === 'Accepted Offer'  ? 
                        <button className="btn btn-blue w-100" 
                      onClick={(e)=>{
                        
                        if ($(e.target).text() === 'Accept Offer') {
                          props.acceptedOffers({
                            application_id:val.id,
                            status_code:4,
                          })
                        } else if ($(e.target).text() === 'Confirm') {
                          props.ConfirmOffer({
                            application_id:val.id
                          })
                          
                        } else if ($(e.target).text() === 'Request Payment') {
                          props.ConfirmOffer({
                            application_id:val.id
                          })
                        }
                      }
                        // props.acceptedOffers(val.id,val.job.id)}
                      }
                      >
                      {val.application_status === 'Job Offer' ? 'Accept Offer'
                      :val.application_status === 'Accepted Offer' ? 'Confirm'
                      
                      :
                      'Request Payment'
                      }
                      </button> :""
                      }
                      
                    </div>
                  </div>
                </div>
               )}):
               <div className="r-job-item job-offer"
               style = {{
                marginTop : '50px',
                // marginLeft : '130px'
               }}
               >
               
               <div className="col-6">
                 <span>
                   <strong>No Offers</strong>
                 </span>
               </div>
             </div>
              }
              </div>
            </div>

        </React.Fragment>

    )
};



const mapStateToProps = (state, ownProps) => {
    return {
      get_offer: state.Emp_Dasboard.job_offer,
      showMsg: state.Offers.showMsg,
      status: state.Offers.status,
      show:state.Offers.show,
      varient: state.Offers.varient,  
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(Dasboard(f, v)),
        getOffer :()=>dispatch(JobOffer()),
        ConfirmOffer: (data) => dispatch(ConfirmOffer(data)),
        rejectOffers:(id,job)=>dispatch(rejectOffers(id,job)),
        acceptedOffers:(id,job)=>dispatch(acceptedOffers(id,job)),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(JobOfferDetails);
import React,{useEffect} from "react";
import { Dasboard,JobInfo } from "../../../actions/Employee/Dashboard";
import { connect } from 'react-redux';
import history from "../../../stores/history";
function JobInfoDetails (props) {

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        props.getInfo();
    }, []);

// console.log("lex",props.get_job)
    return(
        <React.Fragment>
              <div className='col-lg-12 col-md-12 px-0'> 
              { props.get_job.length > 0 ?
              props.get_job.map((job, k) => {
              return( 
              <div className="col mb-4 px-0" key = {k}
              style = {{
                cursor:'pointer'
              }}
              >
                <div className="row">
                  <h3 className="col-12">Job Info</h3>
                  <div className="col-md-4"
                    onClick = {() => {history.push('/employee_applied_jobs')}}
                  >
                    <div className="stamp green w-100 mr-0">
                      <p>Applied Jobs</p>
                      <span>{job.applied_jobs}</span>
                    </div>
                  </div>
                  <div className="col-md-4"
                    onClick = {() => {history.push('/employee-view-jobs')}}
                  >
                    <div className="stamp purple w-100 mr-0">
                      <p>Jobs Starting Soon</p>
                      <span>{job.saved_jobs}</span>
                    </div>
                  </div>
                  <div className="col-md-4"
                  onClick = {() => {history.push('/offers')}}
                  >
                    <div className="stamp cyan w-100 mr-0">
                      <p>Job Offers</p>
                      <span>{job.job_offers}</span>
                    </div>
                  </div>
                </div>
              </div>
              )}

              ):(
                <strong>No Workers Yet </strong>
              )}
              </div>
             
            
        </React.Fragment>

    )
};




const mapStateToProps = (state, ownProps) => {
    return {
      get_job: state.Emp_Dasboard.job_info,
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(Dasboard(f, v)),
        getInfo :()=>dispatch(JobInfo()),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(JobInfoDetails);
import React, { useEffect } from "react";
import Header from "../../Common/App/AppHeader";
import { connect } from 'react-redux';
import { AppliedJob, Applied_job_list,
  viewCompletedProfile ,
  AppliedJobDetail, AppliedClosedJob, 
  AppliedClosedJobList } from "../../../actions/Employee/AppliedJobs";
import ReactHtmlParser from 'react-html-parser';
import {Link} from "react-router-dom";
import moment from 'moment';
import history from '../../../stores/history';

function JobDetails(props) {
  useEffect(() => {
    // require("../../../assets/css/app-style.css");
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    
    if (window.location.pathname.split('/')[3] !== 'completed') {
      props.detailsCall(window.location.pathname.split('/')[2]);
    } else {
      props.viewCompletedProfile(window.location.pathname.split('/')[2]);
    }
    
  }, []);
  
  return (
    <React.Fragment>
    <div className="container-fluid">
          {/* header Starts here */}
          <Header />
          {/* header Ends here */}
          {/* Main Content Starts here */}
          <section className="row main-content">
            <div className="container">
              <div className="row">
                <div className="col-12 hdr-row">
                  <h1>
                    <a href="javascript:;" 
                    onClick={() => {history.goBack()}} className="back"
                    >
                      <img src="/assets/images/app/back-arrow.svg" alt="icon" />
                    </a>
                    Back
                  </h1>
                 
                </div>
                {
                props.get_details.length > 0 &&
                props.get_details.map((det, k)=>{
                return(
                <div className="col-12 mb-5" key = {k}>
                  <div className="snippet-box p-4 job-detail">
                    <div className="row">
                      <div className="col-md-4 lft-col">
                        <div className="img-wrap">
                          <img className="img-fluid" src="/assets/images/app/job-snip-img.jpg" alt="image" />
                        </div>
                   
                        <div className="row job-desc mt-4">
                        <div className="col-12">
                        <h4 className="mb-3">Basic Info </h4>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Start Date</p>
                            </div>
                            <div className="col-md-7">
                              {
                                det.application &&
                                det.application.job &&
                                <span>
                                {moment(new Date(det.application.job.start_date)).format("DD MMMM YYYY")}
                              </span>
                              }
                           
                            </div>
                        </div>
                       
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>End Date</p>
                            </div>
                            {
                                 det.application &&
                                 det.application.job &&
                                 <div className="col-md-7">
                            <span>
                            
                            {moment(new Date(det.application.job.end_date)).format("DD MMMM YYYY")}
                            </span>
                            </div>
                            }
                            
                            
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Start Time</p>
                            </div>
                            
                            <div className="col-md-7">
                            <span>
                            {det.application &&
                            det.application.job &&
                            det.application.job.start_time}
                            </span>
                            </div>
                            
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>End Time</p>
                            </div>
                            
                            <div className="col-md-7">
                            <span>
                            {
                            det.application &&
                            det.application.job &&
                            det.application.job.end_time}
                            </span>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Location</p>
                            </div>
                            <div className="col-md-7">
                            <span>
                            {det.application &&
                              det.application.job &&
                              det.application.job.job_location
                            }
                            </span>
                            </div>
                        </div>
                        </div>
                      </div>
                        {/* <div className="row job-desc contact mt-4 mb-4">
                          <div className="col-12">
                            <h4 className="mb-3">Required Skills</h4>
                            <p>
                              
                              <a href="mailto:amanda.reyes99@gmail.com">UI grapic Design</a>
                            </p>
                            <p>
                            
                              UX/UI design conversions
                            </p>
                            <p>
                            
                              <a href="tel:(499)-430-5810">Web Designer</a>
                            </p>
                          </div>
                        </div> */}
                        {/* <div className="row job-desc contact mt-4 mb-4">
                          <div className="col-12">
                            <h4 className="mb-3">Disability</h4>
                            <p>
                              <img src="/assets/images/app/ic-email.svg" alt="icon" />
                              <a href="mailto:amanda.reyes99@gmail.com">Persons with Disabilities can apply</a>
                            </p>
                          </div>
                        </div> */}
                      </div>
                      <div className="col-md-8 rgt-col">
                        <div className="row job-desc">
                          <div className="col-12">
                            <h4 className="mb-3">Company Info</h4>
                            <h2 className="mb-1">{det.application &&
                            det.application.job &&
                            
                            det.application.job.industry_type}</h2>
                            <span className="designation dark">{det.application &&
                            det.application.job && det.application.job.employer &&
                            
                            det.application.job.employer.company_name}</span>
                            <p className="job-desc-light mt-3">
                              {det.application &&
                            det.application.job &&
                            ReactHtmlParser(det.application.job.job_description)
                            }
                            </p>
                          </div>
                        </div>
                        <div className="row job-desc mt-2">
                          <div className="col-xl-6 col-lg-12 mt-4">
                            <div className="row mb-3">
                              <h4 className="col-12">Job Info</h4>
                              <div className="col-md-5">
                                <p>Salary ({
                                  det.application &&
                                  det.application.job && 
                                  det.application.job.salary_based
                                  })</p>
                              </div>
                              <div className="col-md-7">
                                <span>
                                  {det.application &&
                                  det.application.job && 
                                  det.application.job.currency
                                  } 
                                  {
                                    det.application &&
                                    det.application.job && 
                                    new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(det.application.job.amount)
                                    ? '0.00':det.application.job.amount)
                                    
                                  }
                                </span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Salary Base</p>
                              </div>
                              <div className="col-md-7">
                                <span>{
                                  det.application &&
                                  det.application.job && 
                                  det.application.job.salary_based
                                  }</span>
                              </div>
                            </div>
                           <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Job Position</p>
                              </div>
                              <div className="col-md-7">
                                <span>{
                                  det.application &&
                                  det.application.job && 
                                  det.application.job.job_position
                                  }</span>
                              </div>
                            </div>
                            {/*  <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Languages</p>
                              </div>
                              <div className="col-md-7">
                                <span>English -Strong</span>
                              </div>
                            </div> */}
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Employment</p>
                              </div>
                              <div className="col-md-7">
                                <span>{det.application &&
                                  det.application.job &&
                                  det.application.job.job_type}</span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Gender</p>
                              </div>
                              <div className="col-md-7">
                                <span>{
                                  det.application &&
                                  det.application.job &&
                                  det.application.job.gender
                                  }
                                </span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Total Working Days</p>
                              </div>
                              {
                                det.application &&
                                det.application.job &&
                                <div className="col-md-7">
                                <span>
                                {det.application && 
                                det.application.job &&
                                det.application.job.number_of_days}{
                                det.application.job.number_of_days === '1' ?
                                'day' : 'days'
                                }
                                </span>
                              </div>
                              }
                              
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Working Hrs(Per Day)</p>
                              </div>
                              <div className="col-md-7">
                                <span>
                                  {
                                    det.application &&
                                    det.application.job &&
                                    det.application.job.number_of_hours
                                  } {
                                    det.application &&
                                    det.application.job &&
                                    det.application.job.number_of_hours === '1.0' ?
                                    'Hr' : 'Hrs'
                                  }
                                </span>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div className="col-md-5">
                                <p>Total Salary</p>
                              </div>
                              <div className="col-md-7">
                                <span>
                                RM{
                                    det.application &&
                                    det.application.job &&
                                    det.application.job.job_salaries &&
                                    det.application.job.job_salaries.length > 0 &&
                                    det.application.job.job_salaries[0].total_salary_base_by_employer
                                  }
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="row job-desc mt-4">
                        <div className="col-12 col-lg-9">
                          <h4 className="mb-3">Status</h4>
                          {
                          det.application &&
                          det.application.application_status &&
                          det.application.application_status === 'applied' ||
                          det.application.application_status === 'shortlisted' ?
                          <div className="row mb-2">
                            <div className="col-12 mb-2">
                            <p>
                              {
                                det.application.application_status === 'applied' 
                                ? 'You have applied for this job' 
                                :det.application.application_status === 'shortlisted' 
                                ? 'You have been Shortlisted for this job' :"" 
                              }
                              </p>
                          </div> 
                          </div>:
                          det.schedule ?
                          <>
                          <div className="row mb-2">
                            <div className="col-12 mb-2">
                              <span>Employer has scheduled an interview.</span>
                            </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col-md-3">
                              <p>Interview Date</p>
                            </div>
                            <div className="col-md-9">
                              <p>{det.schedule &&
                              moment(new Date(det.schedule.interview_date)).format("DD MMMM YYYY")}</p>
                            </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col-md-3">
                              <p>Interview Time</p>
                            </div>
                            <div className="col-md-9">
                              <p>
                                {det.schedule && det.schedule.start_time} 
                                - 
                                {det.schedule && det.schedule.end_time} </p>
                            </div>
                          </div>
                          <div className="row mb-2">
                            {/* <div className="col-md-3">
                              <p>Place</p>
                            </div>
                            <div className="col-md-9">
                              <p>-</p>
                            </div> */}
                            {/* <div className="col-12">
                              <button className="btn btn-outline-blue">Add Interview Date to Calendar</button>
                            </div> */}
                          </div>
                        </> :
                        det.application.work_status ?
                          <div className="row mb-2">
                          <div className="col-12 mb-2">
                          <p className = "text-success">
                            Your Work is Completed
                            </p>
                        </div> 
                        </div>
                        : ""
                        }
                        </div>
                      </div>

                      </div>
                    </div>
                  </div>
                </div>
                )})}
              </div>
            </div>
          </section>
          {/* Main Content Ends here */}
        </div>
        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
        </React.Fragment>
  )};


  const mapStateToProps = (state, ownProps) => {
    return {
      job_list: state.Appliedjob.job_list,
      get_details:state.Appliedjob.get_details,
      job_id:state.Appliedjob.job_id,
        // categories: state.Home.categories
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(AppliedJob(f, v)),
        detailsCall: (id) => dispatch(AppliedJobDetail(id)),
        viewCompletedProfile: (id) => dispatch(viewCompletedProfile(id)),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(JobDetails);
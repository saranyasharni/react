import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { AppliedJob, Applied_job_list, 
  AppliedJobDetail, AppliedClosedJob, 
  AppliedClosedJobList , getWorkingJobs
} from "../../../actions/Employee/AppliedJobs";
import { connect } from 'react-redux';

function Employee_navtab(props) {

  useEffect(() => {
    // require("../../../assets/css/app-style.css");
  });

  const gridStausChange = () => {
    props.setFieldValues("grid", true);
    props.setFieldValues("grid_active", "active");
    props.setFieldValues("list", false);
    props.setFieldValues("list_active", "");
    let input = {
      employee_id: localStorage.getItem('employee_id'),
      filter: "0",
      filter_name: 'null',
      filter_term: 'null',
      status_code:'1',
      page_no : '0',
      limit : '50'
    };
   let closedJob = {
      employee_id: localStorage.getItem('employee_id'),
      page_no : '0',
      limit : '50'
    }
    if (props.status == "active") {
      	props.postedJobListAction(input);
      	props.getWorkingJobs({
		  	employee_id : localStorage.getItem('employee_id'),
			page_no : 0,
			limit : '50'
		})
    } else {
      props.closedJobListAction(closedJob);
    };
  };

  const listStatusChange = () => {
    props.setFieldValues("list", true);
    props.setFieldValues("list_active", "active");
    props.setFieldValues("grid", false);
    props.setFieldValues("grid_active", "");
    let input = {
		employee_id: localStorage.getItem('employee_id'),
		filter: "0",
		filter_name: 'null',
		filter_term: 'null',
		status_code:'1',
		page_no : '0',
		limit : '50'
    };
    let closedJob = {
      employee_id: localStorage.getItem('employee_id'),
      page_no : '0',
      limit : '50'
    }

    if (props.status == "active") {
      props.postedJobListAction(input);
    } else {
      props.closedJobListAction(closedJob);
    };
  };

  const changeFunc2 = () => {
    let input = {
		employee_id: localStorage.getItem('employee_id'),
		filter: "1",
		filter_name: "sort",
		filter_term: "2",
		status_code:'1',
		page_no : '0',
    limit : '50'
    }
    let closedJob = {
      employee_id: localStorage.getItem('employee_id'),
      page_no : '0',
      limit : '50'
    }
    props.setFieldValues("sort_asc", !props.sort_asc)
    if (props.status == "active") {
      props.postedJobListAction(input);
    } else {
      props.closedJobListAction(closedJob);
    }
  };

  const changeFunc1 = () => {
    let input = {
		employee_id: localStorage.getItem('employee_id'),
		filter: "1",
		filter_name: "sort",
		filter_term: "1",
		page_no : '0',
    	limit : '50',
      status_code :'1'
    }
    let closedJob = {
      employee_id: localStorage.getItem('employee_id'),
      page_no : '0',
      limit : '50'
    }
    props.setFieldValues("sort_asc", !props.sort_asc)
    if (props.status == "active") {
      props.postedJobListAction(input);
    } else {
      props.closedJobListAction(closedJob);
    }
  };

  const searchFunc = (e) => {
    let input;
    let closedJob;
    if (e.target.value !== "") {
      input = {
        employee_id: localStorage.getItem('employee_id'),
        filter: "1",
        filter_name: "search",
        filter_term: e.target.value,
		page_no : '0',
    	limit : '50',
      status_code:'1',
      };
      closedJob = {
        employee_id: localStorage.getItem('employee_id'),
        page_no : '0',
        limit : '50'
      }
    } else {
      input = {
        employee_id: localStorage.getItem('employee_id'),
        filter: "0",
        filter_name: 'null',
        filter_term: 'null',
        status_code:'1',
		page_no : '0',
    	limit : '50'
      };
      closedJob = {
        employee_id: localStorage.getItem('employee_id'),
        page_no : '0',
        limit : '50'
      }
    }
    if (props.status == "active") {
      props.postedJobListAction(input);
    } else {
      props.closedJobListAction(closedJob);
    }
  }

  const statusChange = (val) => {
    let input = {
      employee_id: localStorage.getItem('employee_id'),
      filter: "0",
      filter_name: 'null',
      filter_term: 'null',
	  status_code:'1',
		page_no : '0',
    limit : '50'
    };
    let closedJob = {
      employee_id: localStorage.getItem('employee_id'),
      page_no : '0',
      limit : '50'
    }
    if (val == "active") {
      props.postedJobListAction(input);
    } else {
      props.closedJobListAction(closedJob);
    };
  };
  
  return (
    <React.Fragment>
      <div class="col-12 hdr-row ff-col">
        <ul class="nav nav-tabs">
          <li>
            <a class="active" data-toggle="tab" onClick={() => {
              props.setFieldValues("active_status", "active")
              statusChange("active")
            }} href="#active">
              Applied
              <span class="badge">{props.job_list.length}</span>
            </a>
          </li>
          <li>
            <a data-toggle="tab" 
            // onClick={() => {
            //   props.setFieldValues("active_status", "closed")
            //   statusChange("closed")
            // }} 
            href="#working">
              Currently Working
              <span class="badge">{props.working_jobs.length}</span>
            </a>
          </li>
          <li>
            <a data-toggle="tab" onClick={() => {
              props.setFieldValues("active_status", "closed")
              statusChange("closed")
            }} href="#closed">
              Completed
              <span class="badge">{props.closed_job.length}</span>
            </a>
          </li>
        </ul>
        <div class="df-ac">
          <button class="btn btn-gray ico mr-3">
            <img src="/assets/images/app/search-icon-dark.svg" onClick={() => {
              if (props.searchDisplay == "none") {
                props.setFieldValues("searchDisplay", "block")
              } else {
                props.setFieldValues("searchDisplay", "none")
              }
            }} alt="icon" />
          </button>
          <button class="btn btn-gray ico mr-3">
            {(props.sort_asc == true) ? (
              <img src="/assets/images/app/sort-icon.svg" alt="icon" onClick={changeFunc1} />
            ) : (
                <img src="/assets/images/app/desc-sort-icon.svg" alt="icon" onClick={changeFunc2}
                />
              )
            }
          </button>
          <div class="btn-set mr-0">
            <a className={props.grid} onClick={gridStausChange}>
              <img src="/assets/images/app/grid-icon.svg" alt="icon" />
            </a>
            <a className={props.list} onClick={listStatusChange} >
              <img src="/assets/images/app/list-icon.svg" alt="icon" />
            </a>
          </div>
         
        </div>
        
      </div>
      <div className="col-12 hdr-row ff-col mt-0" style={{display:props.searchDisplay}}>
        <form action="" className="search-form form-section w-100">
            <div className="form-group mb-0">
                <input placeholder="Search..." onChange={searchFunc} className="form-control" type="text"/>
            </div>
            <a href="javascript:;" className="search-close">
                <img className="img-fluid" onClick={()=>props.setFieldValues("searchDisplay","none")} src="/assets/images/modal-close-icon.svg" alt="icon" />
            </a>
        </form>
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = (state, ownProps) => {
  return {
    show: state.Appliedjob.show_login,
    working_jobs : state.Appliedjob.working_jobs,
    grid: state.Appliedjob.grid_active,
    list: state.Appliedjob.list_active,
    grid_show: state.Appliedjob.grid,
    list_show: state.Appliedjob.list,
    job_list: state.Appliedjob.job_list,
    closed_job: state.Appliedjob.closed_jobs_list,
    show_alert: state.Appliedjob.show_alert,
    showMsg: state.Appliedjob.showMsg,
    sort_asc: state.Appliedjob.sort_asc,
    status: state.Appliedjob.active_status,
    varient: state.Appliedjob.varient,
    working_jobs : state.Appliedjob.working_jobs,
    searchDisplay: state.Appliedjob.searchDisplay,
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setFieldValues: (f, v) => dispatch(AppliedJob(f, v)),
    postedJobListAction: (input) => dispatch(Applied_job_list(input)),
    closedJobListAction: (input) => dispatch(AppliedClosedJobList(input)),
    getWorkingJobs : (data) => dispatch(getWorkingJobs(data))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Employee_navtab);

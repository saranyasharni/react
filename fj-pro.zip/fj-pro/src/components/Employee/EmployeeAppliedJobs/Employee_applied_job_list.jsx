import React, { useEffect } from "react";
import { connect } from 'react-redux';
import { AppliedJob, Applied_job_list,
  AppliedJobDetail, AppliedClosedJob,
  AppliedClosedJobList,getWorkingJobs
} from "../../../actions/Employee/AppliedJobs";
import history from "../../../stores/history";
import Share from "./ShareModel";
import { Link } from "react-router-dom"
import moment from 'moment';

function AppliedJobList(props) {
  const[state, setState] = React.useState(
    {
        start_date: "",
        end_date:'',
        industry_type:'',
        job_position:'',
        currency:'',
        amount:'',
        salary_based:'',
        job_location:''
    }
)
  useEffect(() => {
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    let input = {
      employee_id: localStorage.getItem('employee_id'),
      filter: "0",
      filter_name: 'null',
      filter_term: 'null',
      status_code:'1',
      page_no : '0',
      limit : '50'
    };
    let closedJob = {
      employee_id: localStorage.getItem('employee_id'),
      page_no : '0',
      limit : '50'
    }
    if (props.status == "active") {
      props.postedJobListAction(input);
      props.closedJobListAction(closedJob);
      // props.getWorkingJobs(localStorage.getItem('employee_id'))
    };
  }, []);

  const sendFunc = (val,status) => {    
    props.setFieldValues('job_id', val)
    history.push(`/employee_applied_jobs_details/${val}/${status}`)
  };
  
  return (
    <React.Fragment>

      <div className="col-12 pb-4">
        <div className="tab-content">
          <div id="active" className="tab-pane fade in show active">
            <div className="row job-list">

              {(() => {
                if (props.job_list.length > 0) {
                  
                  return (
                    props.job_list.map((val, k) => {
                      let stat_date = moment(new Date(val.job.start_date)).format("ddd DD")
                      // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                      // let start_date_val = stat_date.getDate()
                      let end_date = moment(new Date(val.job.end_date)).format("ddd DD")
                      return (
                        <div className="col-12" key = {k}>
                          <div className="job-snippet">
                            <div className="img-wrap" >
                              <img className="img-fluid" 
                              style = {{
                                height :'136px'
                              }}
                              src={
                                val.job &&
                                val.job.employer &&
                                val.job.employer.profile_url !== null &&
                                val.job.employer.profile_url !== 'null' &&
                                val.job.employer.profile_url !== ''
                                ?
                                val.job.employer.profile_url :
                                process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                              } alt="img" 
                               onClick={() => { sendFunc(val.id,val.application_status) }}
                              />
                              <span className="date badge">{stat_date} - {end_date}</span>
                            </div>
                            <div className="r-job-item">
                              <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                  <ul className="list-unstyled">
                                    {/* <li>
                                      <Link to={`/employee/chat/${val.job.id}`}>
                                        Chat
                                      </Link>
                                      </li> */}
                                    <li><a href="javascript:;" onClick={() => {
                                      let Start_date = moment(new Date(val.job && val.job.start_date)).format("ddd DD")
                                      let End_date = moment(new Date(val.job && val.job.end_date)).format("ddd DD")
                                      setState({
                                          ...state,
                                          start_date: Start_date,
                                          end_date:End_date,
                                          industry_type:val.job && val.job.industry_type,
                                          job_position:val.job && val.job.job_position,
                                          currency:val.job && val.job.currency,
                                          amount:val.job && val.job.amount,
                                          salary_based:val.job && val.job.salary_based,
                                          job_location:val.job && val.job.job_location
                                      })
                                      props.setFieldValues("share_show", true)
                                      props.detailsCall(val.job.id)
                                    }}>Share</a></li>
                                    <li>
                                      {/* <a href="javascript:;" className="red" onClick={() => { props.closedListCall(val.job.id,val.id) }} >Decline</a> */}
                                      </li>
                                  </ul>
                                </div>
                              </div>
                              <div className="row" >
                                <div className="col-md-8"
                                 onClick={() => { sendFunc(val.id,val.application_status) }}
                                >
                                  <span className="date badge d-inline-block d-lg-none">
                                  {stat_date} - {end_date}
                                    </span>
                                  <h6>{val.job.industry_type}</h6>
                                  <span className="job-type text-truncate">{val.job.job_title}/{val.job.job_position}</span>
                                  <span className="location text-truncate d-block">
                                    <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                    {!val.job.job_location ? '' : val.job.job_location}
                                  </span>
                                  <p className="text-truncate">
                                    {val.job.job_type}
                                     | {val.job.salary_based} {val.job.currency} {new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(val.job.amount)
                                        ? '0.00':val.job.amount)} 
                                  </p>
                                </div>
                                <div class="col-md-4 text-left text-md-right job-l-right">
                                  <p class="expire">
                                    {/* Job Expires in {val.expiration_date} days */}
                                  </p>
                                  <button class="btn btn-blue px-4 mt-5" 
                                  onClick={() => { sendFunc(val.id,val.application_status) }}
                                  >
                                    More Info
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )
                    })
                  )
                } else {
                  return (
                    <div className="empty-job">
                      <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                      <p>There's nothing here.</p>
                    </div>
                  )
                }
              })()}

            </div>
          </div>

          <div id="working" className="tab-pane fade">
            <div className="row job-list">
              {(() => {
                // console.log(props.working_jobs, 'working_jobs')
                if (props.working_jobs.length > 0) {
                return (
                props.working_jobs.map((val,k) => {
                  // let stat_date = moment(new Date(val.job.start_date)).format("ddd DD")
                  // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                  // let start_date_val = stat_date.getDate()
                  // let end_date = moment(new Date(val.job.end_date)).format("ddd DD")
                  return (
                    
                  <div className="col-12" key = {k}>
                  <div className="tab-content">
                    <div id="active" className="tab-pane fade in show active">
                      <div className="row dashboard-snip-sec job-list">
                        <div className="col-12">
                          <div className="job-snippet">
                            <div className="img-wrap">
                              <img className="img-fluid" 
                              style = {{
                                height :'136px'
                              }}
                                  src={
                                    val.job &&
                                    val.job.employer &&
                                    val.job.employer.profile_url !== null &&
                                    val.job.employer.profile_url !== 'null' &&
                                    val.job.employer.profile_url !== ''
                                    ?
                                    val.job.employer.profile_url :
                                    process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                  } 
                              alt="img" 
                              onClick = {() => history.push(`/view-applied-profile/${val.id}`)}
                              />
                              {/* <span className="date badge">{stat_date} - {end_date}</span> */}
                            </div>
                            <div className="r-job-item">
                              <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                  <ul className="list-unstyled">
                                    {/* <li><a href="javascript:;">Chat</a></li> */}
                                    <li><a href="javascript:;" onClick={() => {
                                      let Start_date = moment(new Date(val.job && val.job.start_date)).format("ddd DD")
                                      let End_date = moment(new Date(val.job && val.job.end_date)).format("ddd DD")
                                      setState({
                                          ...state,
                                          start_date: Start_date,
                                          end_date:End_date,
                                          industry_type:val.job && val.job.industry_type,
                                          job_position:val.job && val.job.job_position,
                                          currency:val.job && val.job.currency,
                                          amount:val.job && val.job.amount,
                                          salary_based:val.job && val.job.salary_based,
                                          job_location:val.job && val.job.job_location
                                      })
                                     props.setFieldValues("share_show", true)
                                      props.detailsCall(val.job.id)
                                    }}>Share</a></li>
                                    {/* <li><a href="javascript:;" className="red"onClick={() => { props.closedListCall(val.job.id) }}>Decline</a></li> */}
                                  </ul>
                                </div>
                              </div>
                              <div className="row"
                              >
                                <div className="col-md-8"
                                 onClick = {() => history.push(`/view-applied-profile/${val.id}`)}
                                >
                                  <h6>{val.job &&
                                   val.job.industry_type }</h6>
                                  <span className="job-type text-truncate">
                                    {val.job
                                    && val.job.employer &&
                                    val.job.employer &&
                                    val.job.employer.company_name
                                    }
                                  </span>
                                  {
                                    val.job && 
                                    <p className="text-truncate">Salary {val.job && val.job.currency} {val.job.amount && new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(val.job.amount)
                                    ? '0.00':val.job.amount)} {val.job.salary_based && val.job.salary_based}
                                  </p>
                                  }
                                  
                                  <span className="location text-truncate d-block">
                                    <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                    {val.job &&  val.job.job_location}
                                  </span>
                                </div>
                                <div className="col-md-4 text-left text-md-right job-l-right">
                                  <p className="expire">
                                    {/* Job Expires in {val.expiration_date} days */}
                                    </p>
                                  <Link className="btn btn-blue px-4" 
                                  to = {`/view-applied-profile/${val.id}`}
                                  // onClick={() => { sendFunc(val.job.id) }}
                                  >More Info</Link>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        </div>
                            </div>
                          </div>
                        </div>
                      )
                    })
                  )
                } else {
                  return (
                    <div className="empty-job">
                      <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                      <p>There's nothing here.</p>
                    </div>
                  )
                }
              })()}
            </div>
          </div>

          <div id="closed" className="tab-pane fade">
            <div className="row job-list">
              {(() => {
                if (props.closed_job.length > 0) {
                  return (
                  props.closed_job.map((val, k) => {
                    let start_date = ""
                    let end_date = ""
                    if (val.job.start_date && val.job.end_date) {
                     start_date= moment(new Date(val.job.start_date)).format("ddd DD")
                      // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                      // let start_date_val = stat_date.getDate()
                      end_date = moment(new Date(val.job.end_date)).format("ddd DD")
                    } else {
                      start_date = ""
                      end_date = ""
                    }
                   
                    return (
                    
                  <div className="col-12" key = {k}>
                  <div className="tab-content">
                    <div id="active" className="tab-pane fade in show active">
                      <div className="row dashboard-snip-sec job-list">
                        <div className="col-12">
                          <div className="job-snippet">
                            <div className="img-wrap">
                              <img className="img-fluid" 
                                 style = {{
                                   height :'136px'
                                 }}
                                  src={
                                    val.job &&
                                    val.job.employer &&
                                    val.job.employer.profile_url !== null &&
                                    val.job.employer.profile_url !== 'null' &&
                                    val.job.employer.profile_url !== ''
                                    ?
                                    val.job.employer.profile_url :
                                    process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                  } 
                               alt="img"
                               onClick={() => { 
                                sendFunc(val.id, val.work_status)
                               }}
                                />
                              <span className="date badge">{start_date} - {end_date}</span>
                            </div>
                            <div className="r-job-item">
                              <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                  <ul className="list-unstyled">
                                    {/* <li><a href="javascript:;">Chat</a></li> */}
                                    <li><a href="javascript:;" onClick={() => {
                                    let Start_date = moment(new Date(val.job && val.job.start_date)).format("ddd DD")
                                    let End_date = moment(new Date(val.job && val.job.end_date)).format("ddd DD")
                                    setState({
                                          ...state,
                                          start_date: Start_date,
                                          end_date:End_date,
                                          industry_type:val.job && val.job.industry_type,
                                          job_position:val.job && val.job.job_position,
                                          currency:val.job && val.job.currency,
                                          amount:val.job && val.job.amount,
                                          salary_based:val.job && val.job.salary_based,
                                          job_location:val.job && val.job.job_location
                                    })
                                     props.setFieldValues("share_show", true)
                                      props.detailsCall(val.job.id)
                                    }}>Share</a></li>
                                    {/* <li><a href="javascript:;" className="red"onClick={() => { props.closedListCall(val.job.id) }}>Decline</a></li> */}
                                  </ul>
                                </div>
                              </div>
                              <div className="row">
                                <div className="col-md-8"
                                onClick={() => { 
                                  sendFunc(val.id, val.work_status)
                                 }}
                                >
                                  <h6>{val.job && 
                                  val.job.industry_type &&
                                   val.job.industry_type}</h6>
                                  <span className="job-type text-truncate">{
                                    val.job &&
                                    val.job.employer && 
                    
                                  val.job.employer.company_name
                                  }</span>
                                  <p className="text-truncate">Salary {
                                  val.job && val.job.currency} {val.job && new Intl.NumberFormat('en-US', 
                                  {style: 'decimal', minimumFractionDigits: 2}).
                                  format(isNaN(val.job.amount)
                                  ? '0.00':val.job.amount)} {val.job && val.job.salary_based}</p>
                                  <span className="location text-truncate d-block">
                                    <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                    {val.job && val.job.job_location 
                                    ? val.job.job_location : ''
                                    }
                                  </span>
                                </div>
                                <div className="col-md-4 text-left text-md-right job-l-right">
                                  <p className="expire">
                                    {/* Job Expires in {val.expiration_date} days */}
                                    </p>
                                  <button className="btn btn-blue px-4" onClick={() => { 
                                    sendFunc(val.id, val.work_status)
                                   }}>More Info</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        </div>
                            </div>
                          </div>
                        </div>
                      )
                    })
                  )
                } else {
                  return (
                    <div className="empty-job">
                      <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                      <p>There's nothing here.</p>
                    </div>
                  )
                }
              })()}
            </div>
          </div>
        </div>
      </div>

      {/* Main Wrapper Ends here */}
      {/* Modal Wrapper Starts here */}
      <Share
                jobDetails = {state}
            />
      {/* Modal Wrapper Ends here */}
      {/* Script Starts here */}
      {/* Script Ends here */}
    </React.Fragment>
  )
};

const mapStateToProps = (state, ownProps) => {
  
  return {
    job_list: state.Appliedjob.job_list,
    closed_job: state.Appliedjob.closed_jobs_list,
    status: state.Appliedjob.active_status,
    working_jobs : state.Appliedjob.working_jobs
    // categories: state.Home.categories
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setFieldValues: (f, v) => dispatch(AppliedJob(f, v)),
    postedJobListAction: (input) => dispatch(Applied_job_list(input)),
    detailsCall: (id) => dispatch(AppliedJobDetail(id)),
    closedJobListAction: (input) => dispatch(AppliedClosedJobList(input)),
    getWorkingJobs : (data) => dispatch(getWorkingJobs(data)),
    closedListCall: (id,app_id) => dispatch(AppliedClosedJob(id,app_id)),
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(AppliedJobList);
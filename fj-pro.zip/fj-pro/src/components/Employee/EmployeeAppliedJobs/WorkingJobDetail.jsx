import React, { useEffect, useState } from "react";
import Header from "../../Common/App/AppHeader";
import { connect } from 'react-redux';
import  * as actions  from "../../../actions/Employee/AppliedJobs";
import {Link} from "react-router-dom";
import moment from 'moment';
import Alert from "react-bootstrap/Alert";
import jQuery from 'jquery';
import history from '../../../stores/history'

function JobDetails(props) {
  const [start_time, setTime] = useState('')  

  useEffect(() => {
	jQuery(document).ready(function() {
		window.jQuery(".input-group.date").datepicker({
		format: "mm/dd/yyyy",
    todayHighlight: true,
    autoclose:true
		// endDate: "+0d",
		}).off("change")
		.change((e) => {{
			props.inputChange('correct_login_date', e.target.value)
		}});
	})
    // require("../../../assets/css/app-style.css");
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets//assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    props.detailsCall(window.location.pathname.split('/')[2]);
  }, []);

  useEffect (() => {
	console.log(props.job_status, 'props.request_status')
  if (props.varient ==='danger' || props.varient === 'success') {
    
    setTimeout(function(){
      props.setShow(false)
    }, 3000)
  }
	if (props.request_status === 1) {
        jQuery("#late-request .alert").html(
          `<strong>Success!</strong> ${props.modelMessage}.`
        );
        jQuery("#late-request .alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
        props.setModelSuccess(0, '');
        setTimeout(function () {
          jQuery("#late-request .alert").removeClass("alert-success");
		  jQuery("#late-request .alert").html("");
		  window.jQuery("#late-request").modal("hide");
        }, 2000);
        
    } else if (props.request_status === 2){
		jQuery("#late-request .alert").html(
			`<strong>Error!</strong> ${props.modelMessage}.`
		  );
		  jQuery("#late-request .alert")
			.removeClass("alert-success")
			.addClass("alert-danger");
		  props.setModelSuccess(0, '');
		  setTimeout(function () {
			jQuery("#late-request .alert").removeClass("alert-danger");
			jQuery("#late-request .alert").html("");
		  }, 2000);
	} else {
		return;
	}
  }) 

  return (
    <React.Fragment>
    <div className="container-fluid">
          {/* header Starts here */}
          <Header />
          {/* header Ends here */}
          {/* Main Content Starts here */}
          <section className="row main-content">
          <div className="container">
            <div className="row">
              <div className="col-12 hdr-row">
                <h1>
                  <a href="javascript:;" className="back n__back-button"
                  onClick={() => {history.goBack()}}
                  >
                    <img src="/assets/images/app/back-arrow.svg" alt="icon" /><span>Back</span>
                  </a>
                  {/* Back */}
                </h1>
              </div>
              <div className="col-12 mb-5">
              <Alert
                show={props.show}
                variant={props.varient}
                dismissible
                onClose={() => props.setShow(false)}
                >
                <strong>
                    {props.job_status === 1
                    ? "Success!"
                    : "Error!"}
                </strong>{" "}
                {props.showMsg}
                </Alert>
                <div className="snippet-box p-4 job-detail">
                  {/* {console.log(props.currentJobDetail, 'currentJobDetail')} */}
                  <div className="row">
                    <div className="col-md-4 lft-col">
                      <div className="img-wrap">
                        <img className="img-fluid" src="/assets/images/app/job-snip-img.jpg" alt="image" />
                      </div>
                      <div className="row job-desc mt-4 mb-4">
                        <div className="col-12">
                        <h4 className="mb-3">Job Info </h4>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Position</p>
                            </div>
                            <div className="col-md-7">
                            <span>
                              { props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.job_position}
                            </span>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Location</p>
                            </div>
                            <div className="col-md-7">
                            <span>
                              { props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.job_location}
                            </span>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                            <p>Job Type</p>
                            </div>
                            <div className="col-md-7">
                            <span>
                              {   props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.job_type}
                            </span>
                            </div>
                        </div>
         
                        </div>
                      </div>
                    </div>
                    <div className="col-md-8 rgt-col">
                      <div className="row job-desc">
                        <div className="col-12">
                          <h4 className="mb-3">Company Info</h4>
                          <h2 className="mb-1">
                            {
                              props.currentJobDetail &&
                              props.currentJobDetail.job &&
                              props.currentJobDetail.job.industry_type
                            }
                          </h2>
                          <span className="designation dark">
                            {
                              props.currentJobDetail &&
                              props.currentJobDetail.job &&
                              props.currentJobDetail.job.employer &&
                              props.currentJobDetail.job.employer.company_name
                            }
                          

                          </span>
                          <p></p>
                          {/* <p className="job-desc-light mt-3">Required 3 freshers/experience office Admin need Travel management, Management Information System (MIS), MS-Office, Office administration, Communication Skills</p> */}
                          <br/>
                          <div className="row">
                              <h4 className="col-12">Work Detail</h4>
                              {/* <div className="col-md-5 mb-2">
                                <p>Total no of Days</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>{props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.number_of_days}days</span>
                              </div> */}
                              <div className="col-md-5 mb-2">
                                <p>Total no of Days</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>{props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.number_of_days}days</span>
                              </div>
                              <div className="col-md-5 mb-2">
                                <p>Earned Salary</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>RM{props.currentJobDetail && props.currentJobDetail.total_salary ?
                                Number.parseFloat(props.currentJobDetail.total_salary).toFixed(2) : '0.00'}</span>
                              </div>
                              <div className="col-md-5 mb-2">
                                <p>Start Date</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>{props.currentJobDetail && props.currentJobDetail.job &&
                               moment(new Date(props.currentJobDetail.job.start_date)).format("DD MMMM YYYY")
                               }</span>
                              </div>
                              <div className="col-md-5 mb-2">
                                <p>End Date</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>{props.currentJobDetail && props.currentJobDetail.job &&
                               moment(new Date(props.currentJobDetail.job.end_date)).format("DD MMMM YYYY")
                               }</span>
                              </div>
                              <div className="col-md-5 mb-2">
                                <p>Total Worked Hours</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>{props.currentJobDetail &&
                                props.currentJobDetail.hours_worked
                                }Hrs</span>
                              </div>
                              <div className="col-md-5 mb-2">
                                <p>Salary({props.currentJobDetail &&
                                props.currentJobDetail.job && 
                                props.currentJobDetail.job.salary_based})</p>
                              </div>
                              <div className="col-md-7 mb-2">
                                <span>RM{props.currentJobDetail &&
                                props.currentJobDetail.job && 
                                new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(props.currentJobDetail.job.amount)
                                    ? '0.00':props.currentJobDetail.job.amount)
                                }</span>
                              </div>
                            </div>
                            
                          
                        </div>
                      </div>
                      <div className="row job-desc mt-2">
                        <div className="col-xl-6 col-lg-12 mt-4">
                          <div className="row mb-3">
                            <h4 className="col-12">Attendance</h4>
                            <div className="col-12">
                              <p className="fs-12 mb-2">Insert your attendance here.</p>
                              <p className="mb-1">{moment().format('DD MMMM YYYY')}</p>
                              <p className="mb-3">Your work plan : {" "}
                              {
                                props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.start_time
                              } {" "}
                                - {" "}
                              {
                                props.currentJobDetail &&
                                props.currentJobDetail.job &&
                                props.currentJobDetail.job.end_time
                              }{" "}
                              </p>
                              <p className="mb-1">
                                {
                                  
                                  props.work_status === 1 || props.work_status === 2 ? 
                                  
                                  props.work_start_time:  "You have not started yet."
                                  
                                }
                              </p>
                            </div>
                            <div className="col-12 start-stop-sec my-4">
                              <button className="btn btn-blue start mr-3 px-3"
                              onClick = {() => {
                                setTime(
                                  moment().format('HH:mm')
                                )
                                let date = moment().format('MM/DD/YYYY')
                                let startTime = moment().format('HH:mm')
                                props.startWork({
                                  work_id:props.currentJobDetail.id,
                                  employee_id:localStorage.getItem('employee_id'),
                                  job_id:props.currentJobDetail.jobId,
                                  login_date:date,
                                  login_time:startTime,
                                  extended:props.currentJobDetail && 
                                  props.currentJobDetail.extended_works.length > 0
                                  ? 1: 0,
                                  extended_work_id:props.currentJobDetail && 
                                  props.currentJobDetail.extended_works.length > 0
                                  ?props.currentJobDetail.extended_works[0].id :null
                                })
                              }}
                              >
                                <img className="mr-2" src="/assets/images/app/play-icon.svg" alt="icon" />
                                {props.loading ? 'Loading': "Start"}
                              </button>
                              <button className="btn btn-outline-danger stop px-3"
                              onClick = {() => {
                                setTime(
                                  moment().format('HH:mm')
                                )
                                let date = moment().format('MM/DD/YYYY')
                                let startTime = moment().format('HH:mm')
                                
                                let extended_work_id = props.currentJobDetail && 
                                props.currentJobDetail.extended_works.length > 0 
                                ?props.currentJobDetail.extended_works[0].id :null
                                props.stopWork({
                                  work_id:props.currentJobDetail.id,
                                  employee_id:localStorage.getItem('employee_id'),
                                  job_id:props.currentJobDetail.jobId,
                                  login_date:date,
                                  login_time:startTime,
                                  extended:props.currentJobDetail && 
                                  props.currentJobDetail.extended_works.length > 0
                                  ? 1: 0,
                                  extended_work_id:extended_work_id
                                })
                              }}
                              >
                                <img className="mr-2" src="/assets/images/app/stop-icon.svg" alt="icon" />
                                {props.stop_loading ? 'Loading': "Stop"}
                              </button>
                            </div>
                            {/* <div className="col-12">
                              <p className="mb-3">Late log in? Send request to employer.</p>
                              <button className="btn btn-blue"
                              onClick = {() => {                 
                                window.jQuery('#late-request').modal('show')
                                
                              }}
                              >Send Request</button>
                            </div> */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

          {/* Main Content Ends here */}
        </div>
        <div className="modal fade custom-modal" id="late-request" 
        tabIndex={-1} role="dialog" aria-hidden="true">
			
          <div className="modal-dialog modal-dialog-centered" role="document">
		  
            <div className="modal-content">

              <div className="modal-header">

                <h5 className="mt-2 modal-title w-100 justify-content-center">Send Request</h5>
                <button type="button" 
                className="close" 
                data-dismiss="modal" 
                aria-label="Close"
                onClick = {(e) => {
                  window.jQuery('#late-request').modal('hide')
                }}
                >
                  <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                </button>
				
              </div>
			  
              <div className="modal-body px-md-5 px-3">
                <div className="row">
                  <form className="form-section col-md-12">
				          <div className="alert" role="alert">  </div>
                    <div className="row">
                      <div className="form-group col-md-6">
                        <label>Date</label>
                        <div className="input-group date mar-t-no" data-date-format="dd/mm/yyyy">
                        <input type="text" className="form-control" />
                        <div className="input-group-addon">
                          <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                      </div>
                      </div>
                      <div className="form-group col-md-6">
                        <label>Correct Log In Time</label>
                        <input type="time"
                        className="form-control" 
                        onChange = {(e) =>
                          props.inputChange('correct_login_time', e.target.value)
                        }
                        name= "correct_login_time" />
                      </div>
                    </div>
                    <div className="form-group">
                      <label>Description</label>
                        <input type="text" 
                        className="form-control" 
                        placeholder = "Description"
                        onChange = {(e) =>
                          props.inputChange('description', e.target.value)
                        }
                        /> 
                    </div>
                  </form>
                </div>
                <div className="row mt-2 mb-3">
                  <div className="col-md-12 text-right">
                    <button className="btn btn-blue"
					onClick = {(e) => {
						props.requestLateLogin({
						employee_id:localStorage.getItem('employee_id'),
						employer_id:props.currentJobDetail.employerId,
						job_id:props.currentJobDetail.jobId,
						request_date:props.correct_login_date,
						request_time:props.correct_login_time,
						description:props.description
            })
					}}
					>Send Request</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
        </React.Fragment>
  )};


  const mapStateToProps = (state, ownProps) => {
    return {
      // job_list: state.Appliedjob.job_list,
      // get_details:state.Appliedjob.get_details,
      // job_id:state.Appliedjob.job_id,
		show:state.Appliedjob.show,
    work_status:state.Appliedjob.work_status,
    work_start_time:state.Appliedjob.work_start_time,
		varient:state.Appliedjob.varient,
		showMsg:state.Appliedjob.showMsg,
		correct_login_date : state.Appliedjob.correct_login_date,
		correct_login_time : state.Appliedjob.correct_login_time,
		description : state.Appliedjob.description,
      	job_status:state.Appliedjob.job_status,
		request_status : state.Appliedjob.request_status,
    	modelMessage : state.Appliedjob.modelMessage,
      currentJobDetail : state.Appliedjob.currentJobDetail,
      loading : state.Appliedjob.loading,
      stop_loading : state.Appliedjob.stop_loading
        // categories: state.Home.categories
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
      // createJob: (data) => dispatch(actions.createJob(data)),
        startWork : (data) => dispatch(actions.startWork(data)),
        stopWork : (data) => dispatch(actions.stopWork(data)),
        requestLateLogin : (data) => dispatch(actions.requestLateLogin(data)),
        inputChange : (f,v) => dispatch(actions.inputChange(f,v)),
        setShow : (data) => dispatch(actions.setShow(data)),
        setModelSuccess : (data) => dispatch(actions.setModelSuccess(data)),
        setWorkeringTime : data => dispatch(actions.setWorkeringTime(data)),
          // setFieldValues: (f, v) => dispatch(AppliedJob(f, v)),  
        detailsCall: (id) => dispatch(actions.WorkingJobDetail(id)),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(JobDetails);
import React, { useEffect } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import { PostedJob,postedJobDetail } from "../../../actions/EmployerPostedJob";
import {AppliedJob} from "../../../actions/Employee/AppliedJobs";
import {View_Job} from "../../../actions/Employee/viewJob";
import {FacebookShareButton,TwitterShareButton,WhatsappShareButton} from "react-share";
import Sharer from 'sharer.npm.js';
import moment from "moment";

function EmployerShare(props) {
    useEffect(() => {
        
        // require("../../../assets/css/app-style.css");
        
    }, []);


    const copyToClipboard = () => {
        const textField = document.createElement('textarea');
        textField.innerText = window.location.href
        document.body.appendChild(textField);
        textField.select();
        document.execCommand('copy');
        textField.remove();
        props.setFieldValues('show_alert',true)
        props.setFieldValues('varient','success')
        props.setFieldValues('showMsg',"Copy to URL Successful")
        props.setFieldValues('share_show', false)
    };

    const handleClick =(e)=> {
      const sharer = new Sharer(e.target)
      sharer.share()
    }

    return (
        <Modal show={props.show} className="custom-modal"
        style={{ "paddingRight": 17 }} 
        onHide={() => props.setFieldValues('share_show', false)}
        tabindex="-1" role="dialog" aria-hidden="true"
        centered
        >
          {
            // console.log(props.jobDetails, 'jobDetails')
          }
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Share job</h5>
              <button type="button" className="close" onClick={() => props.setFieldValues('share_show', false)}>
                <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
              </button>
            </div>
            
            <div className="modal-body pt-0">
              <div className="col-12">
                <div className="row job-list">
                  <div className="job-snippet profile-snippet">
                    <div className="img-wrap">
                      <img className="img-fluid" src="/assets/images/app/job-snip-img.jpg" alt="img" />
                      <span className="date badge">
                          {props.jobDetails &&
                          props.jobDetails.start_date
                          } - {props.jobDetails &&
                            props.jobDetails.end_date}</span>
                      {/* <span className="new badge">New</span> */}
                      {/* <a href="javascript:;" className="favorite">
                        <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                      </a> */}
                    </div>
                    <div className="r-job-item">
                      <div className="row">
                        <div className="col-md-12">
                          <h6>{props.jobDetails &&
                          props.jobDetails.industry_type}</h6>
                          <span className="job-type text-truncate">
                            {props.jobDetails &&
                          props.jobDetails.job_position}
                            {/* Nissi Fresh Store */}
                            </span>
                          <p className="text-truncate mt-0">Salary {props.jobDetails &&
                          props.jobDetails.currency} {props.jobDetails &&
                          props.jobDetails.amount} {props.jobDetails &&
                          props.jobDetails.salary_based}</p>
                          <span className="location text-truncate d-block mt-3">
                            <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                            {props.jobDetails &&
                          props.jobDetails.job_location}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            
              <div className="col-12 job-share px-0">
                <h6>Share with</h6>
                <ul className="list-inline">
                  <li className="list-inline-item">
                    <a href="javascript:;" onClick={copyToClipboard}>
                      <img src="/assets/images/app/copy-link-icon.svg" alt="icon" />
                      Copy Link
                    </a>
                  </li>
                  <li className="list-inline-item">
                  <FacebookShareButton
      url={window.location.href}
      title="Facebook">
                    <a href="javascript:;">
                      <img src="/assets/images/app/fb-icon.svg" alt="icon" />
                      Facebook
                    </a>
                    </FacebookShareButton>
                  </li>
                  <WhatsappShareButton
                  title={props.jobDetails &&
                          props.jobDetails.job_position}
                  />
                  {/* <li className="list-inline-item" >
                    <a href="javascript:;" data-sharer="skype" data-url={window.location.href} data-title="Checkout Sharer.js!">
                      <img src="/assets/images/app/skype-icon.svg"  alt="icon" />
                      Skype
                    </a>
                  </li> */}
                  <li className="list-inline-item">
                  <TwitterShareButton
      url={window.location.href}
      title="Twitter">
        <a>
      <img src="/assets/images/app/twitter-icon.svg" alt="icon" />
      Twitter
                    </a>
    </TwitterShareButton>
    </li>
                 
                </ul>
              </div>
              {/* <div className="col-12 text-right mt-2 px-0">
                <button className="btn btn-gray">Cancel</button>
                <button className="btn btn-blue">Share</button>
              </div> */}
            </div>
          </div>
        </Modal>
    )};


    const mapStateToProps = (state, ownProps) => {
      if(window.location.pathname =="/employer_posted_job_list"){
        return {
            show: state.Postedjob.share_show,
            job_id:state.Postedjob.job_id,
            get_details:state.Postedjob.get_details,
           
        };
      }else if (window.location.pathname =="/employee_applied_jobs"){
        return {
          show: state.Appliedjob.share_show,
          job_id:state.Appliedjob.job_id,
          get_details:state.Appliedjob.get_details,
         
      };
      }else{
        return {
          show: state.Emp_View_Job.share_show,
          job_id:state.Emp_View_Job.job_id,
          get_details:state.Emp_View_Job.get_details,
         
      };

      };
    
    };
    
    const mapDispatchToProps = (dispatch, ownProps) => {
      if(window.location.pathname =="/employer_posted_job_list"){
        return {
            setFieldValues: (f, v) => dispatch(PostedJob(f, v)),    
        }
      }else if (window.location.pathname =="/employee_applied_jobs"){
        return{
          setFieldValues: (f, v) => dispatch(AppliedJob(f, v)),
        }
      }else{
        return{
          setFieldValues: (f, v) => dispatch(View_Job(f, v)),
        }
      }
    };

    export default connect(mapStateToProps, mapDispatchToProps)(EmployerShare); 
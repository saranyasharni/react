import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import * as actions from '../../../actions/Employer/Chat';
import { io } from 'socket.io-client';
import $ from "jquery";
const endPoint = "http://ec2-54-169-157-197.ap-southeast-1.compute.amazonaws.com:3001/"
const socket = io(endPoint)

function ChatRight(props) {
   
    useEffect(() => {
        
    }, []);

    const getOneChat = (id, type, e) => {
        // console.log(id, 'chat_room_id')
        socket.emit('joinRoom', ({chatRoomId: id, user_type: "employee"}))
        socket.on('chatRoomId', (chatRoomId, profileData) => {
            console.log(chatRoomId, 'chatRoomID')
            props.setChatData(
                chatRoomId.messages
            )
            props.setChatRoomId(
                chatRoomId.chatRoomId
            )
            localStorage.setItem('chat_room_id', id)
            props.setProfileInfo(
                chatRoomId.profileData
            )
           
        })
        
        window.$(e.target).find('.unread-encl').find('.unread').text('')
        window.$(e.target).find('.unread-encl').find('.unread').removeClass('.unread')
        
    }
    return (
        <div className="chat-left">        
        <form className="search-form">
        <div className="form-group">
            <label>Search</label>
            <input className="form-control pr-5" type="text" name placeholder="Ex Purchase Manager" />
            <button className="btn"><img className="img-fluid" src="/assets/images/app/search-icon-dark.svg" /></button>
        </div>
        </form>
        <div className="chat-list">
        <div className="mscroll-y">
            {
                // console.log(props.chatLists, 'props.chatLists'),
                props.chatLists &&
                props.chatLists.chatRoomsList &&
                props.chatLists.chatRoomsList.map((i,k) => {

                let clas_name = i.messages.length > 0 ? '' : ''
               
                return (
                    <>
                    <div className={`card-row ${clas_name}`} key = {k} 
                    onClick = {(e) => {getOneChat(i.id, 'employee', e)}
                    }
                    >
                    <div className="card-left">
                        <div className="avatar">
                        <img className="img-fluid" src="/assets/images/app/avatar-1.png" alt="Username" />
                        </div>
                    </div>
                    <div className="card-right">
                        <div>
                            <p className="lead text-truncate">{i.employer_name}</p>
                            <span className="sub text-truncate">{i.messages.length > 0 ?
                            i.messages[0].message :''
                            }</span>
                        </div>
                        {
                        i.messages.length > 0 ? (
                        <span className="unread-encl">
                        {/* <span className="unread">{i.messages.length}</span> */}
                        <Moment fromNow>{i.messages.length > 0 ?
                        i.messages[0].createdAt :''
                        }</Moment>
                        </span>
                        ): ''
                        }
                    </div>
                    </div>
                    </>
                )
            })
            }
            
            {/* <div className="card-row">
            <div className="card-left">
                <div className="avatar">
                <img className="img-fluid" src="/assets/images/app/avatar-2.png" alt="Username" />
                </div>
            </div>
            <div className="card-right">
                <div>
                <p className="lead text-truncate">William Tillman</p>
                <span className="sub text-truncate">How are you getting</span>
                </div>
                <span className="unread-encl">
                a month ago
                </span>
            </div>
            </div>
            <div className="card-row">
            <div className="card-left">
                <div className="avatar">
                <img className="img-fluid" src="/assets/images/app/avatar-3.png" alt="Username" />
                </div>
            </div>
            <div className="card-right">
                <div>
                <p className="lead text-truncate">Bette Lowe PhD</p>
                <span className="sub text-truncate">Great idea!</span>
                </div>
                <span className="unread-encl">
                2 months ago
                </span>
            </div>
            </div>
            <div className="card-row">
            <div className="card-left">
                <div className="avatar">
                <img className="img-fluid" src="/assets/images/app/avatar-4.png" alt="Username" />
                </div>
            </div>
            <div className="card-right">
                <div>
                <p className="lead text-truncate">Mellie Huels</p>
                <span className="sub text-truncate">How is your job?</span>
                </div>
                <span className="unread-encl">
                3 months ago
                </span>
            </div>
            </div> */}
        </div>
        </div>    
        </div>
    )
    }


const mapStateToProps = (state, ownProps) => {
    return {
        chatContents : state.Chat.chatContents
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        setChatData : (data) => dispatch(actions.setChatData(data)),        
        setChatRoomId : (data) => dispatch(actions.setChatRoomId(data)),
        setProfileInfo : (data) => dispatch(actions.setProfileInfo(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ChatRight);
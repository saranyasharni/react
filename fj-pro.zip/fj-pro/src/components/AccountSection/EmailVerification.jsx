import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import history from "../../stores/history";

class emailVerification extends Component {
    constructor(props) {
        super(props);
    }

  componentDidMount() {
    // require("../../assets/css/custom-style.css");
    let removingElament = document.getElementById("design_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
      removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "custom_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    setTimeout(function() {
      if (localStorage.getItem('user') === 'employee') {
        history.push('/login_work')
      } else {
        history.push('/login_hire')
      }
      
    }, 2000)
  }

  render() {
   
    return (
      <div className="container-fluid main-wrap">
        <div className="row">
          <div className="col-md-6 signup-lft" />
          <div className="col-md-6 signup-rgt verification">
            <h3>Email Verified</h3>
            <p>
              Your email address was successfully verified{" "}
              .
            </p>
            <br/>
            
            <p>

              Your account registration will be reviewed by FlexiJobs. Please allow 3 working days for your account to be reviewed. You will receive an email on approval. Thank you.
            
           
            </p>
           
           
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {};
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const log = connect(mapStateToProps, mapDispatchToProps)(emailVerification);

export default log;

import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import $ from "jquery";
import * as actions from "../../actions/signupWork";
import moment from "moment"
import {
  getIndustries, 
  getPositions,
  getSkills,
  getLanguages,
  getQualifications,
  getPassoutYear
} from "../../actions/Home"
import Autocomplete from "react-google-autocomplete";
// import Dropzone from "react-dropzone";
// import { setPassword } from "../../actions/resetPassword";
import Alert from "react-bootstrap/Alert";

class WorkSign extends Component {
  constructor(props) {
    super(props);
    this.state = {
      languageSkills: [
        {
          language: "",
          spoken: "",
          read: "",
          written: "",
          new_lang:0
        },
      ],
      count: 0,
      visibility:false,
      visibility_pass:false,
    };
  }

  componentDidMount() {
    this.props.getSkills()
    this.props.getQualifications()
    this.props.getLanguages()
    this.props.getPassoutYear()

    let removingElament = document.getElementById("design_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
      removingElament.remove()
    }
    
    this.props.getIndustries()
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "custom_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    let THIS = this;
    
    $(document).ready(function () {
      $('input.example').on('change', function() {
        
        $('input.example').not(this).prop('checked', false);  
      });
      window.$(".selectpicker").selectpicker();
      window.$(".dob_date1").datepicker({
          format: "dd/mm/yyyy",
          endDate: "+0d",
          autoclose:true,
          
        })
        // .off("change")
        .change((e) => {
          
          THIS.props.changeInput("dob", e.target.value);
        });

        window.$(".date_start").datepicker({
          format: "dd/mm/yyyy",
          // startDate: new Date(),
          autoclose:true,
          // endDate: "+0d",
        }).off("change")
        // .change((e) => {
        //   THIS.changeJobExperience(e, $(date_start).attr('data-id'), "start_date")
        // });
       
        window.$(".date_exp_end").datepicker({
          format: "dd/mm/yyyy",
          // startDate: new Date(),
          autoclose:true,
          // endDate: "+0d",
        }).off("change")
        // .change((e) => {
        //   THIS.changeJobExperience(e, $(e.target).attr('data-id'), "end_date")
        //   THIS.calculateExp()
        // });      
    });
  }

  componentDidUpdate() {
    let THIS = this;
    $(document).ready(function () {
      $('input.example').on('change', function(e) {
        
        $('input.example').not(this).prop('checked', false);  
      });
      window.$(".selectpicker").selectpicker('refresh');
      window.$(".dob_date1")
        .datepicker({
          format: "dd/mm/yyyy",
          endDate: "+0d",
          //  autoclose: true 
        })
        .off("change")
        .change((e) => {
          THIS.props.changeInput("dob", e.target.value);
        });
      
        window.$(".date_start").datepicker({
          format: "dd/mm/yyyy",
          // endDate: "+0d",
        }).off("change")
        .change((e) => {
          THIS.changeJobExperience(e, $(e.target).attr('data-id'), "start_date")
        });
        window.$(".date_exp_end").datepicker({
          format: "dd/mm/yyyy",
          // endDate: "+0d",
        }).off("change")
        .change((e) => {
        THIS.changeJobExperience(e, $(e.target).attr('data-id'), "end_date")
        THIS.calculateExp(e)
        });
    });
  }

  createSkills() {
    return this.state.languageSkills.map((el, i) => (
      <>
        <div className="form-group" key={i}>
          
          <label>Language</label>
          
          <select
            className="form-control selectpicker"
            data-live-search="true"    
            title = "Choose Language"
            value={el.language}
            onChange={(e) => {
              
              if (e.target.value === 'Others') {
                // alert()
                this.addAllSkills(1,i,'new_lang')
                this.addAllSkills("",i,"language")
              } else {
                this.addAllSkills(0,i,'new_lang')
                this.addAllSkills(e,i,"language")
              }
              
            }}
            
          >
            {/* <option value="">Choose Language</option> */}
            
            {
              this.props.listlanguages &&
              this.props.listlanguages.length > 0 &&
              this.props.listlanguages.map((i,k) => {
                return (
                  <option value={i} key = {k}>{i}</option>
                )
              })
            }
          
          </select>
         
          <input
              value={el.language}
              id = 'lang_input'
              type="text" className={`form-control mt-1 ${el.new_lang === 1?
                '':'d-none'
              }`}
              onChange = {(e) => {this.addAllSkills(e,i,"language")}}
            placeholder="Enter Language Here" name />
        </div>
        {this.props.errors.language && this.props.errors.language.length > 0 ? (
          <small className="text-danger">{this.props.errors.language}</small>
        ) : (
          ""
        )}
        <div className="row" key={i + 1}>
          <div className="col-md-4">
            <div className="form-group">
              <label>Spoken</label>
              <select
                className="selectpicker form-control"
                data-live-search="true"    
                value={el.spoken}
                title = "Choose one"
                onChange={(e) => {
                  // this.props.changeInput("spoken", e.target.value);
                  this.addAllSkills(e,i,"spoken")
                }}
              >
                {/* <option value="">Choose one</option> */}
                <option>Excellent</option>
                <option>Good</option>
                <option>Better</option>
              </select>
              {this.props.errors.spoken &&
              this.props.errors.spoken.length > 0 ? (
                <small className="text-danger">
                  {this.props.errors.spoken}
                </small>
              ) : (
                ""
              )}
            </div>
          </div>
          <div className="col-md-4">
            <div className="form-group">
              <label>Read</label>
              <select
                className="selectpicker form-control"
                data-live-search="true"    
                title = "Choose one"
                value={el.read}
                onChange={(e) => {
                  // this.props.changeInput("read", e.target.value);
                  this.addAllSkills(e,i,"read")
                }}
              >
                {/* <option value="">Choose one</option> */}
                <option>Excellent</option>
                <option>Good</option>
                <option>Better</option>
                
              </select>
              {this.props.errors.read && this.props.errors.read.length > 0 ? (
                <small className="text-danger">{this.props.errors.read}</small>
              ) : (
                ""
              )}
            </div>
          </div>
          <div className="col-md-4">
            <div className="form-group">
              <label>Written</label>
              <select
                className="selectpicker form-control"
                data-live-search="true"    
                title = "Choose one"
                value={el.written}
                id="written_fires"
                onChange={(e) => {
                  // this.props.changeInput("written", e.target.value);
                  this.addAllSkills(e,i,"written")
                  // this.props.addAllSkills({
                  //   language: this.props.language,
                  //   read: this.props.read,
                  //   written: e.target.value,
                  //   spoken: this.props.spoken,
                  // });
                }}
              >
                {/* <option value="">Choose one</option> */}
                <option>Excellent</option>
                <option>Good</option>
                <option>Better</option>
              
              </select>
              {this.props.errors.written &&
              this.props.errors.written.length > 0 ? (
                <small className="text-danger">
                  {this.props.errors.written}
                </small>
              ) : (
                ""
              )}
            </div>
          </div>
          <div className={i===0 ? "col-12 form-section mb-4 d-none" : "col-12 form-section mb-4"}>
            <a
            href="javascript:;" className="add-sec text-danger float-right"
            onClick = {() => {
              this.deleteItem(i, 'lang') 
            }}
            >
              <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
              Delete
            </a>
          </div>  
        </div>
      </>
    ));
  }
  
  stepOneValidation(e) {
    // console.log(e.target, 'e.target.op')
    let errors = this.props.errors;
    let valid = true;
    if (this.props.empName === "") {
      valid = false
      errors.empName = "Cannot be Empty";
    }
    if (this.props.last_name === ""){
      valid = false
      errors.last_name = "Cannot be Empty"
    }
    if (this.props.gender == "") {
      valid = false;
      errors.gender = "Cannot be Empty";
    }
    if (this.props.phone_number == "") {
      valid = false;
      errors.phone_number = "Cannot be Empty";
    }
    if (this.props.phone_number !== "" && this.props.phone_number.length > 10) {
      valid = false;
      errors.phone_number = "Mobile Number must be less than 10 digits";
    }

    if (this.props.Email == "") {
      valid = false;
      errors.Email = "Cannot be Empty";
    }
    
    if (!this.props.Email == "") {
      if (!this.validateEmail(this.props.Email)) {
        valid = false;
        errors.Email = "please enter a valid email";
      }
    }
    // if (this.props.dob == "") {
    //   valid = false;
    //   errors.dob = "Cannot be Empty";
    // }
    if (this.props.Address == "") {
      valid = false;
      errors.Address = "Cannot be Empty";
    }
    
    this.props.updateErrors(errors);
    
    if (valid) {
      this.props.updateErrors({
        Email: "",
        Address: "",
        last_name: "",
        dob: "",
        phone_number: "",
        empName: "",
        gender: "",
      });
      $("#next-2").addClass("active");
      $(e.target).attr("href", "#step-2");
      $("#step-1").removeClass("active show");
      $("#step-2").addClass("active show");
    }
  }
  validateEmail(email) {
    const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

    return expression.test(String(email).toLowerCase());
  }
  
  stepTwoValidation(e) {
    // console.log(e.target, 'e.target.op')
    let errors = this.props.errors;
    let valid = true;
    // if (this.props.main_roles === "") {
    //   valid = false;
    //   errors.main_roles = "Cannot be Empty";
    // }
    // if (this.props.resume_file == "") {
    //   valid = false;
    //   errors.resume_file = "Please upload resume";
    // }
    // if (this.props.resume_privacy_setting == "") {
    //   valid = false;
    //   errors.resume_privacy_setting =
    //     "Please Choose any one resume privacy settings";
    // }
    // this.props.jobExperience.map((i,k) => {
    //   if (i.category === "") {
    //     valid = false;
    //     errors.jobExperience_category = "Cannot be Empty";  
    //   }
    //   if (i.position === "") {
    //     valid = false;
    //     errors.jobExperience_position = "Cannot be Empty";
    //   }
    // })
    
    this.props.multiSkills.map((i,k) => {
      if (i.skill_name === "") {
        valid = false;
        errors.skill_name = "Cannot be Empty";  
      }
      if (i.experience === "") {
        valid = false;
        errors.experience = "Cannot be Empty";
      }
    })
    
   
    this.props.updateErrors(errors);
    
    if (valid) {
      this.props.updateErrors({
        skill_name:"",
        experience:""
        // main_roles: "",
        // resume_file: "",
        // resume_privacy_setting: "",
      });
      $("#next-4").addClass("active");
      $(e.target).attr("href", "#step-4");
      $("#step-2").removeClass("active show");
      $("#step-4").addClass("active show");
    }
  }
  stepThreeValidation(e) {

    // let errors = this.props.errors;
    // let valid = true;
    // if (this.props.epf === "") {
    //   valid = false;
    //   errors.epf = "Cannot be Empty";
    // }
    // if (this.props.disability) {
    //   if (this.props.desc_disability === "") {
    //     valid = false;
    //     errors.desc_disability = "Cannot be Empty";
    //   }
      
    // }
    // if (this.props.socso === "") {
    //   valid = false;
    //   errors.socso = "Cannot be Empty";
    // }
    // if (this.props.bank_account_number === "") {
    //   valid = false;
    //   errors.bank_account_number = "Cannot be Empty";
    // }
    // if (this.props.ic_number === "") {
    //   valid = false;
    //   errors.ic_number = "Cannot be Empty";
    // }
    // if (this.props.total_experience === "") {
    //   valid = false;
    //   errors.total_experience = "Cannot be Empty";
    // }
    // this.props.updateErrors(errors);
    // if (valid) {
      
    //   this.props.updateErrors({
    //     // ic_number : '',
    //     // total_experience:"",
    //     // epf :'',
    //     // socso :'',
    //     // // bank_name:'',
    //     // bank_account_number :'',
    //     // disability:false,
    //     desc_disability:''
    //   });
    //   $("#next-4").addClass("active");
    //   $(e.target).attr("href", "#step-4");
    //   $("#step-3").removeClass("active show");
    //   $("#step-4").addClass("active show");
    // }
  }
  stepFourValidation(e) {
    // console.log(this.props.language_skills, 'e.target.language_skills')
    let errors = this.props.errors;
    let valid = true;
    if (this.props.qualification === "") {
      valid = false;
      errors.qualification = "Cannot be Empty";
    }
    if (this.props.disability) {
      if (this.props.desc_disability === "") {
        valid = false;
        errors.desc_disability = "Cannot be Empty";
      }
      
    }
    if (this.props.instution_name == "") {
      valid = false;
      errors.instution_name = "Cannot be Empty";
    }
    if (this.props.completion_year == "") {
      valid = false;
      errors.completion_year = "Cannot be Empty";
    }
    // if (this.props.language == "") {
    //   valid = false;
    //   errors.language = "Cannot be Empty";
    // }
    // if (this.props.written == "") {
    //   valid = false;
    //   errors.written = "Cannot be Empty";
    // }
    // if (this.props.read == "") {
    //   valid = false;
    //   errors.read = "Cannot be Empty";
    // }
    // if (this.props.spoken == "") {
    //   valid = false;
    //   errors.spoken = "Cannot be Empty";
    // }

    this.props.updateErrors(errors);
    if (valid) {
      this.props.updateErrors({
        qualification: "",
        instution_name: "",
        completion_year: "",
        language: "",
        written: "",
        read: "",
        spoken: "",
      });
      $("#next-5").addClass("active");
      $(e.target).attr("href", "#step-5");
      $("#step-4").removeClass("active show");
      $("#step-5").addClass("active show");
    }
  	}
	// newStepValidation(e) {
	// 	$("#next-4").addClass("active");
	// 	$(e.target).attr("href", "#step-4");
	// 	$("#step-3").removeClass("active show");
	// 	$("#step-4").addClass("active show");
	// }
  	signUp(e) {
    let errors = this.props.errors;
    let valid = true;
    
    if (this.props.password === "") {
      errors.password = "Password cannot be empty";
    } else if (this.props.password && this.props.password.length < 8) {
      valid = false;
      errors.password = "Password must be more than 8 characters";
    } else if (this.props.password && this.props.password.search(/\d/) == -1) {
      valid = false;
      errors.password = "Password must contain numbers";
    } else if (
      this.props.password !== "" &&
      this.props.password.search(/[a-zA-Z]/) == -1
    ) {
      valid = false;
      errors.password = "Password must contain letters";
    } else {
      valid = true;
      errors.password = "";
    }

    if (this.props.confirm_password == "") {
      valid = false;
      errors.confirm_password = "Confirm password cannot be empty";
    } else if (
      this.props.confirm_password &&
      this.props.confirm_password.length < 8
    ) {
      valid = false;
      errors.confirm_password =
        "Confirm password must be more than 8 characters";
    } else if (
      this.props.confirm_password &&
      this.props.confirm_password.search(/\d/) == -1
    ) {
      valid = false;
      errors.confirm_password = "Confirm password must contain numbers";
    } else if (
      this.props.confirm_password &&
      this.props.confirm_password.search(/[a-zA-Z]/) == -1
    ) {
      valid = false;
      errors.confirm_password = "Confirm password must contain letters";
    } else {
      valid = true;
      errors.confirm_password = "";
      this.props.updateErrors(errors);
    }

    if (this.props.password !== this.props.confirm_password) {
      valid = false;
      errors.password = "Password Not Matching";
      errors.confirm_password = "Password Not Matching";
    }

    if (this.props.resume_privacy_setting === "privacy") {
      valid = false;
      errors.resume_privacy_setting =
        "Please accept our T&C and Privacy policy";
    }

    this.props.updateErrors(errors);
    // console.log(valid)
    if (valid) {
      this.props.signUpWorkRegister({
        empName: this.props.empName,
        dob: this.props.dob,
        gender: this.props.gender,
        country_code: this.props.country_code,
        phone_number: this.props.phone_number,
        Email: this.props.Email,
        Address: this.props.Address,
        is_vaccinated : this.props.is_vaccinated,
        city: this.props.city,
        postal_code: this.props.postal_code,
        main_roles: this.props.main_roles,
        resume_file: this.props.resume_file,
        resume_privacy_setting: this.props.resume_privacy_setting,
        instution_name: this.props.instution_name,
        qualification: this.props.qualification,
        completion_year: this.props.completion_year,
        skill_details : this.props.multiSkills,
        work_experience : this.props.jobExperience,
        epf:this.props.epf,
        socso:this.props.socso,
        bank_name:this.props.bank_name,
        account_number:this.props.bank_account_number,
        ic_number : this.props.ic_number,
        total_experience : this.props.total_experience,
        disability:this.props.disability ? 'yes': 'no',
        disability_description:this.props.desc_disability,
        // lat:10.9974,
        // lon:76.9589,
        experience:this.props.total_experience,
        language_skills: this.state.languageSkills,
        password: this.props.password,
      });
      // console.log(this.props.new_position_added,
      //   this.props.new_skill_added, 'this.props.new_skill_added'
      //   )
      if (this.props.new_position_added) {
        this.props.addPositions({
          position:this.props.added_new_position,
          cat_id:this.props.added_cat_id,
        })
      }
      if (this.props.new_skill_added) {
        this.props.addSkills({
          skill:this.props.added_new_skill_name,
        })
      }
      
    }
  	}

  	handleDropzone(files) {
      if (files) {
        this.props.uploadResume(files[0], files);
      }
  	}

    calculateExp(e) {
      let arr = this.props.jobExperience
      // console.log(arr, 'arr')
      let splitstart = arr[0].start_date.split('/')
      let newStart = splitstart[2]+'-'+splitstart[1]+'-'+splitstart[0]
     
      let splitEnd = e.target.value.split('/')
      let newEnd = splitEnd[2]+'-'+splitEnd[1]+'-'+splitEnd[0]
      
      let df = new Date(newStart)
      let dt = new Date(newEnd) 
      var startMonth = df.getFullYear() * 12 + df.getMonth();  
      var endMonth = dt.getFullYear() * 12 + dt.getMonth();
      var monthInterval = (endMonth - startMonth);
      
      var yearsOfExperience = Math.floor (monthInterval / 12);
      var monthsOfExperience = monthInterval % 12;  
      let total_exp 
      if (yearsOfExperience <= 0) {
        let months = dt.getMonth() - df.getMonth() + 
        (12 * (dt.getFullYear() - df.getFullYear()))
        total_exp = months + `${months === 1? ' month' : ' months'} `
      } else {
        total_exp = yearsOfExperience +(yearsOfExperience === 1 ? ' year':' years') + ' ' +
        monthsOfExperience + (monthsOfExperience === 1 ? ' month' : ' months')
      } 
      // console.log(total_exp, 'total_exp')
      this.props.changeInput(
        "total_experience",
        total_exp
      );
      
    }
    
    changeJobExperienceCurrent(e, index, val) {
      let arr = [...this.props.jobExperience]
      
    
      arr.map((i,k)=> {
        i.current_company = "no"
      })
      
      arr[index][val] = e.target.checked ? "yes": "no";  
      this.props.changeInput("jobExperience", arr)
      
    }

    clearJobExperience(k) {
      let arr = [...this.props.jobExperience]
      console.log(arr, 'arr')  
      arr[k]['category'] = ""
      arr[k]['company_name'] = ""
      arr[k]['current_company'] = "no"
      arr[k]['end_date'] = ""
      arr[k]['start_date'] = ""
      arr[k]['new_position'] = 0
      arr[k]['position'] = ""
      arr[k]['responsibilities'] = ""
      this.props.changeInput("jobExperience", arr)
    }

    changeJobExperience(e, index, val) {
      let arr = [...this.props.jobExperience]
      let errors = this.props.errors;
      if (val === 'end_date') {
        console.log(e.target.value, arr[index]['start_date'], 'ghthtu')
        
        if (new Date(moment(e.target.value, "DD/MM/YYYY").format("MM/DD/YYYY")) <= new Date(moment(arr[index]['start_date'], "DD/MM/YYYY").format("MM/DD/YYYY")))   
        {
          errors.end_date = "End date must be grater than the start date";
        } else {
          errors.end_date = "";
        }
      }
      // this.changeJobExperience(1, k, "new_position")
          if (e === 1 || e === 0) {
            arr[index][val] = e;
          } else if (e === "") {
            arr[index][val] = e;
          } else {
            arr[index][val] = e.target.value;
          } 
      this.props.changeInput("jobExperience", arr)
      this.props.updateErrors(errors);
    }

    skillChangeFunc(e,idx,val) {
      
      let arr = [...this.props.multiSkills];
      if (e === 1 || e === 0) {
        arr[idx][val] = e;
      } else if (e === "") {
        arr[idx][val] = "";
      } else {
        arr[idx][val] = e.target.value;
      }
      
      this.props.changeInput("multiSkills", arr)
      
    };

    deleteItem(index, param) {
      
      if (param === 'skills') {
        let arr = [...this.props.multiSkills];
        arr.splice(index,1)
        this.props.changeInput("multiSkills", arr)
      }
      if (param === 'lang') {
        let arr = [...this.state.languageSkills];
        arr.splice(index,1)
        this.setState(() => ({
          languageSkills : arr
        }))
      }
      if (param === 'experience') {
        let arr = [...this.props.jobExperience]
        arr.splice(index,1)
        this.props.changeInput("jobExperience", arr)
      }
    }
    
    addAllSkills(e, idx, val) {
      let arr = [...this.state.languageSkills];
      if (e === 1 || e === 0) {
        arr[idx][val] = e
      } else if (e === "") {
        arr[idx][val] = ""
      }  else {
        arr[idx][val] = e.target.value
      }
    
      this.setState(() => ({
        languageSkills : arr
      }))
    }
    addMoreSkills() {

      this.setState((prevState) => ({
  
        languageSkills: [
          ...prevState.languageSkills,
          { language: "", spoken: "", read: "", written: "", new_lang:0 },
        ],
        count: this.state.count + 1,
      }));
  }
  	render() {
    
    return (
      <div>
        <div className="container-fluid main-wrap">
          <div className="row">
            <div className="col-md-6 signup-lft" />
   {console.log(this.props.resume_privacy_setting, 'total_experience')}
            <div className="col-md-6 signup-rgt">
              {
                <Alert
                  show={this.props.show}
                  variant={this.props.varient}
                  dismissible
                  onClose={() => this.props.setShow(false)}
                >
                  <strong>
                    {this.props.employee_register_status === 1
                      ? "Success!"
                      : "Error!"}
                  </strong>{" "}
                  {this.props.showMsg}
                </Alert>
              }

              <ul className="nav nav-pills" role="tablist">
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    data-toggle="pill"
                    href="#step-1"
                    role="tab"
                    aria-selected="true"
                  >
                    <span>1</span>
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link "
                    data-toggle="pill"
                    href="#step-2"
                    role="tab"
                    id="next-2"
                    aria-selected="false"
                  >
                    <span>2</span>
                  </a>
                </li>
                {/* <li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="pill"
                    href="#step-3"
                    role="tab"
                    id="next-3"
                    aria-selected="false"
                  >
                    <span>3</span>
                  </a>
                </li> */}
                <li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="pill"
                    id="next-4"
                    href="#step-4"
                    role="tab"
                    aria-selected="false"
                  >
                    <span>3</span>
                  </a>
                </li>
				<li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="pill"
                    id="next-5"
                    href="#step-5"
                    role="tab"
                    aria-selected="false"
                  >
                    <span>4</span>
                  </a>
                </li>
              </ul>
              <div className="tab-content">
                <div
                  className="tab-pane fade show active"
                  id="step-1"
                  role="tabpanel"
                >
                  <h3>Basic Details</h3>
                  <form className="tab-form row">
                    <div className="col-12">
                    <div className="row">
                      <div className="col-md-6">
                      <div className="form-group">
                        <label>First Name</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="Your First Name"
                          value={this.props.empName}
                          onChange={(e) => {
                            this.props.changeInput("empName", e.target.value);
                          }}
                          name
                        />
                        {this.props.errors.empName &&
                        this.props.errors.empName.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.empName}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                      </div>
                      <div className="col-md-6">
                      <div className="form-group">
                        <label>Last Name</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="Your Last Name"
                          value={this.props.last_name}
                          onChange={(e) => {
                            this.props.changeInput("last_name", e.target.value);
                          }}
                          name
                        />
                        {this.props.errors.last_name &&
                        this.props.errors.last_name.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.last_name}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                      
                      </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Date of Birth</label>
                            <div
                              className="input-group date dob_date1 mar-t-no"
                              data-date-format="DD/MM/YYYY"
                            >
                              <input type="text" 
                              className="form-control" 
                              // onBlur = {(e) => {
                                
                              //   setTimeout(() => {
                              //     this.props.changeInput("dob", e.target.value);
                              //   }, 500)                                  
                              //   }
                              // }
                              value = {this.props.dob}
                              />
                              <div className="input-group-addon">
                                <img
                                  src="/assets/images/calendar-icon.svg"
                                  alt="icon"
                                />
                              </div>
                            </div>
                            {this.props.errors.dob &&
                            this.props.errors.dob.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.dob}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Gender</label>
                            <select
                              name="gender"
                              title = "Choose gender"
                              value={this.props.gender}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "gender",
                                  e.target.value
                                );
                              }}
                              className="form-control selectpicker"
                            >
                              {/* <option value=""></option> */}
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                            
                            </select>
                            {this.props.errors.gender &&
                            this.props.errors.gender.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.gender}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                        <div className="col-lg-6 col-md-12">
                          <div className="form-group">
                            <label>Mobile Number</label>
                            <div className="two-input">
                              <select
                                value={this.props.country_code}
                                onChange={(e) => {
                                  this.props.changeInput(
                                    "country_code",
                                    e.target.value
                                  );
                                }}
                                className="form-control selectpicker"
                              >
                                <option value="+60">+60</option>
                                
                                <option value="+65">+65</option>
                                
                              </select>
                              <input
                                type="text"
                                className="form-control"
                                name
                                value={this.props.phone_number}
                                onChange={(e) => {
                                  if(e.target.value.length <= 10) {
                                    const re = /^[0-9\b]+$/;
                                  if (
                                    e.target.value === "" ||
                                    re.test(e.target.value)
                                  ) {
                                    this.props.changeInput(
                                      "phone_number",
                                      e.target.value
                                    );
                                  } 
                                } else {
                                  // console.log(e.target.value.length, 'This is fin')
                                }
                                  
                                }}
                                placeholder="17-661 0472"
                              />
                            </div>
                            {this.props.errors.phone_number &&
                            this.props.errors.phone_number.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.phone_number}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                        <div className="col-lg-6 col-md-12">
                          <div className="form-group">
                            <label>Email</label>
                            <input
                              type="text"
                              value={this.props.Email}
                              onChange={(e) => {
                                this.props.changeInput("Email", e.target.value);
                              }}
                              className="form-control"
                              name
                              placeholder="Your Email"
                            />
                            {this.props.errors.Email &&
                            this.props.errors.Email.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.Email}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Address</label>
                        <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className="form-control"
                            value = {this.props.Address}
                            onChange={(e) => {
                              this.props.changeInput("Address", e.target.value);
                            }}
                            onPlaceSelected={(place) => {
                              if (place.formatted_address &&  place.formatted_address.length >0)
                                this.props.changeInput("Address", place.formatted_address);
                                let length = place.address_components &&
                                place.address_components.length > 0 ?
                                place.address_components.length-1 :""
                                // this.props.changeInput("mailing_address1", place.address_components && place.address_components.length >0 &&
                                // place.address_components[1].long_name
                                // )
                                this.props.changeInput("city", place.address_components && place.address_components.length >0 &&place.address_components[length-2].long_name)
                                
                                if (place.address_components && place.address_components.length >0 && place.address_components[length].types[0] ==="postal_code") {
                                  this.props.changeInput("postal_code", parseInt(place.address_components[length].long_name))
                                } else {
                                  this.props.changeInput("postal_code", "")
                                } 
                            }}
                            options={{
                              types: ['address'],
                                // componentRestrictions: { country: "ru" },
                            }}
                            // defaultValue={this.props.Address}
                            />
                        {/* <input
                          type="text"
                          className="form-control"
                          value={this.props.Address}
                          onChange={(e) => {
                            this.props.changeInput("Address", e.target.value);
                          }}
                          placeholder="Your street address"
                          name
                        /> */}
                        {this.props.errors.Address &&
                        this.props.errors.Address.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.Address}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>City</label>
                           
                            <input
                              type="text"
                              className="form-control"
                              value={this.props.city}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "city",
                                  e.target.value
                                );
                              }}
                              placeholder="Kuala Lumpur"
                              name
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Postal Code</label>
                            <input
                              type="text"
                              className="form-control"
                              value={this.props.postal_code}
                              onChange={(e) => {
                                if (e.target.value.length <= 5) {
                                const re = /^[0-9\b]+$/;
                                  if (
                                    e.target.value === "" ||
                                    re.test(e.target.value)
                                  ) {
                                    this.props.changeInput(
                                      "postal_code",
                                      e.target.value
                                    );
                                  } 
                                }
                              }}
                              placeholder={50480}
                              name
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                        <label className="input mt-3">
                          <input 
                          type="checkbox" name="ot-req" 
                          checked = {this.props.is_vaccinated}
                          onChange = {(e) => {
                              let target_val = e.target.checked 
                              this.props.changeInput("is_vaccinated", target_val);
                          }}
                          />
                          Are you vacinated?
                          </label>
                          {this.props.errors.is_vaccinated &&
                          this.props.errors.is_vaccinated.length > 0 ? (
                            <small className="text-danger">
                              {this.props.errors.is_vaccinated}
                            </small>
                          ) : (
                            ""
                          )}
                      </div>
                  </form>
                  <div className="row">
                    <div className="col-12 btn-btm-wrap">
                      <button className="btn btn-gray"
                      style = {{
                        visibility : 'hidden'
                      }}
                      >
                        Back
                        </button>
                      <button
                        className="btn btn-blue"
                        data-toggle="pill"
                        // href="#step-2"
                        role="tab"
                        onClick={(e) => this.stepOneValidation(e)}
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
                <div className="tab-pane fade" id="step-2" role="tabpanel">
          
          {/* <h3>Job Experience</h3> */}
          <h3 style={{margin:0}}>Job Experience</h3>
          <label style={{marginBottom: 15}}>Please add your most recent job experiences</label>
          <form className="tab-form row">
            {
              // console.log(this.props.jobExperience, 'this.props.jobExperience'),
            this.props.jobExperience.length > 0 &&
            this.props.jobExperience.map((i,k) => {
            return (
            <div className="col-12" key = {k}>
            <div className="row">
              <div className="form-group col-lg-6">
              <label>Category</label>
              <select name="category" className="form-control selectpicker"
              data-live-search="true"    
              title = "Choose Category"
              value = {i.category}
              onChange = {(e) => {
                this.changeJobExperience(e, k, "category")
                var index = e.target.selectedIndex;
                var optionElement = e.target.childNodes[index]
                var option =  optionElement.getAttribute('data-id');
                // console.log(option, 'option')
                this.props.changeInput(
                  "added_cat_id",
                  option
                );
                
                this.props.getPositions(option)
              }}
              >
                {
                  // console.log(this.props.industries, 'industries'),
                  this.props.industries &&
                  this.props.industries.length > 0 &&
                  this.props.industries.map((i,k) => {
                    return <option
                    key = {k}
                    data-id = {i.id}
                    value = {i.industry_type}>{i.industry_type}</option>
                    
                  })
                }

              </select>
              {this.props.errors.jobExperience_category &&
                this.props.errors.jobExperience_category.length > 0 ? (
                  <small className="text-danger">
                    {this.props.errors.jobExperience_category}
                  </small>
                ) : (
                  ""
              )}
              </div>
              <div className="form-group col-lg-6">
              <label>Your Position</label>
              
              <select name="category" className="form-control selectpicker"
              data-live-search="true"
              title = "Choose Position"    
              value = {i.position}
              onChange = {(e) => {
               
                if (e.target.value.trim() == 'Others') {
                  
                  this.changeJobExperience(1, k, "new_position")
                  this.changeJobExperience("", k, "position")
                  this.props.changeInput("new_position_added",true)
                } else {
                  this.changeJobExperience(0, k, "new_position")
                  this.changeJobExperience(e, k, "position")
                }
              }}
              >
                {/* <option value = ""></option> */}
                {
                  this.props.positions &&
                  this.props.positions.length > 0 &&
                  this.props.positions.map((i,k) => {
                    return <option
                    key = {k}
                    value = {i}>{i}
                    </option>
                  })
                }
              </select>
          
              <input
              value={i.position}
              id = 'lang_input'
              type="text" className={`form-control mt-1 ${i.new_position === 0 ? 'd-none':''}`}
              onChange = {(e) => {
                this.changeJobExperience(e, k, "position");
                this.props.changeInput(
                  "added_new_position",
                  e.target.value
                );
              }}
              name 
              />
               {this.props.errors.jobExperience_position &&
                this.props.errors.jobExperience_position.length > 0 ? (
                  <small className="text-danger">
                    {this.props.errors.jobExperience_position}
                  </small>
                ) : (
                  ""
              )}
              </div>
              <div className="form-group col-12">
              <label>Company Name</label>
              <input 
              value = {i.company_name}
              type="text" className="form-control"
              onChange = {(e) => {this.changeJobExperience(e, k, "company_name")}}
              placeholder="Company Name" name />
             
              </div>
            </div>
            <div className="row">
              <div className="form-group col-lg-6">
              <label>Start Date</label>
              <div className="input-group date date_start
              mar-t-no" data-date-format="DD/MM/YYYY"
              
              >
                <input 
                type="text" className="form-control date_start_input" 
                value = {i.start_date}
                data-id = {k}
               
                />
                <div className="input-group-addon"
                
                >
                <img src="/assets/images/calendar-icon.svg" alt="icon" 
                
                />
                </div>
              </div>
              </div>
              <div className="form-group col-lg-6">
              <label>End Date</label>
              <div className="input-group date date_exp_end mar-t-no" 
              data-date-format="DD/MM/YYYY">
                <input 
                data-id = {k}
                value = {i.end_date}
                type="text" className="form-control" 
                />
                 
                <div className="input-group-addon">
                <img src="/assets/images/calendar-icon.svg" alt="icon" />
                </div>
                {this.props.errors.end_date &&
                this.props.errors.end_date.length > 0 ? (
                  <small className="text-danger">
                    {this.props.errors.end_date}
                  </small>
                ) : (
                  ""
              )}
              </div>
              </div>
              <div className="form-group col-12">
              <label>Description</label>
              <textarea rows="4" cols="50"
              className="form-control" name placeholder="Description" 
              value = {i.responsibilities}
                onChange = {(e) => {
                  this.changeJobExperience(e, k, "responsibilities")
                }}
              />
              </div>
              <div className="col-12 form-section mb-4">
              <label className="switch">
                <input type="checkbox"
                className = "example" 
                checked={i.current_company === "yes" ? true : false}
                
                // value = {i.current_company }
                onChange = {(e) => {
                  
                  this.changeJobExperienceCurrent(e, k, "current_company")
                }}
                />
                <span className="slider" />
              </label>
              <span className="txt">I Currently work here</span>
              {k !== 0 ? 
              <a
              href="javascript:;" className={
              
              "add-sec text-danger float-right"
              }
              onClick = {() => {
                this.deleteItem(k, 'experience')
                
              }}
              >
                 <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                Delete
              </a> :
              <a
              href="javascript:;" className={
              
              "add-sec text-danger float-right"
              }
              onClick = {() => {
                this.clearJobExperience(k)
              }}
              >
                 <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                Reset
              </a>
              }
              
              </div>
            </div>
            </div>
            )})
          }
          <div className="form-group col-12">
            <a href="javascript:;" className="add-sec"
            onClick = {() => {
              this.props.AddMoreField("jobExperience", 
              {
              category:'',
              position:'',
              company_name:'',
              start_date:'',
              end_date:'',
              new_position:0,
              responsibilities:'',
              current_company:''
            })}}
            >
              <img src="/assets/images/add-circle-fill-icon.svg" alt="icon" />
              Add Working Experience
            </a>
            </div>	
          </form>
          <h3>Skills</h3>
          <form className="tab-form row">
            {
              this.props.multiSkills &&
              this.props.multiSkills.map((i,idx) => {
                return <div className="col-12" key = {idx}>
                <div className="row">
                <div className="form-group col-lg-6">
                  <label>Skill</label>
                  <select name="category" className="form-control selectpicker"
                  data-live-search="true"    
                  value = {i.skill_name}
                  title = "Choose One"
                  onChange={(e) => {
                    if (e.target.value === 'Others') {
                      this.skillChangeFunc(1,idx,"extra_skill")
                      this.skillChangeFunc("",idx,"skill_name")  
                      this.props.changeInput("new_skill_added", true)
                    } else {
                      this.skillChangeFunc(e,idx,"skill_name")
                      this.skillChangeFunc(0,idx,"extra_skill")
                    }
                  }}
                  >
                  {/* <option>Choose One</option> */}
                  {
                    this.props.skills &&
                    this.props.skills.length &&
                    this.props.skills.map((i,k) => {
                      return <option
                      key = {k}
                      value = {i}
                      >{i}</option>
                    })
                  }
                  </select>
                  <input 
                  value = {i.skill_name}
                  className = {i.extra_skill === 0 ?"form-control mt-1 d-none":
                  "form-control mt-1"
                  }
                  onChange = {(e) => {
                    this.skillChangeFunc(e,idx,"skill_name");
                    this.props.changeInput("added_new_skill_name", e.target.value);
                  }}
                  />
                  {this.props.errors.skill_name &&
                    this.props.errors.skill_name.length > 0 ? (
                      <small className="text-danger">
                        {this.props.errors.skill_name}
                      </small>
                    ) : (
                      ""
                  )}
                </div>
                <div className="form-group col-lg-6">
                  <label>Proficiency</label>
                  <select name="category" 
                  title="Choose Proficiency"
                  value = {i.experience}
                  // onChange={(e) => {
                  //   this.props.changeInput(
                  //     "skill_experience",
                  //     e.target.value
                  //   );
                  //   }}
                  onChange={(e)=>{this.skillChangeFunc(e,idx,"experience")}}
                  className="form-control selectpicker"
                  data-live-search="true"    
                  >
                    <option value = "Advanced">Advanced</option>
                    <option value = "Intermediate">Intermediate</option>
                    <option value = "Beginner">Beginner</option>
                  </select>
                  {this.props.errors.experience &&
                    this.props.errors.experience.length > 0 ? (
                      <small className="text-danger">
                        {this.props.errors.experience}
                      </small>
                    ) : (
                      ""
                  )}
                </div>
                <div className={idx === 0 ? "col-12 form-section mb-2 d-none" : 
                "col-12 form-section mb-2"}>
                  {/* {console.log(this.props.multiSkills, 'this.props.multiSkills')} */}
                <a
                href="javascript:;" className="add-sec text-danger float-right"
                
                onClick = {() => {
                  this.deleteItem(idx, 'skills')
                }}
                >
                  <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                  Delete
                </a>
              </div>
                </div>
              </div>
              })
            }
          <div className="form-group col-12">
            <a href="javascript:;" className="add-sec"
            onClick = {() => {
              this.props.AddMoreField("multiSkills", 
              {
                skill_name:'',
                experience:'',
                extra_skill:0
              })}}
            >
              <img src="/assets/images/add-circle-fill-icon.svg" alt="icon" />
              Add Skill
            </a>
            
            </div>	
          </form>
          <div className="row">
            <div className="col-12 btn-btm-wrap">
            <button className="btn btn-gray"
            className="btn btn-gray"
            onClick={() => {
              $("#step-2").removeClass("active show");
              $("#step-1").addClass("active show");
            }}
            data-toggle="pill"
            href="#step-1"
            role="tab"
            >Back</button>
            <button className="btn btn-blue"
            className="btn btn-blue"
            data-toggle="pill"
            // href="#step-3"
            onClick={(e) => {
              this.stepTwoValidation(e);
            }}
            role="tab"
              // data-toggle="pill"
              // href="#step-5"
              // onClick={(e) => {
              //   this.newStepValidation(e);
              // }}
              // role="tab"
            >Next</button>
            </div>
          </div>
          </div>
          {/* <div className="tab-pane fade" id="step-3" role="tabpanel">

				
				<div className="row">
					<div className="col-12 btn-btm-wrap">
					<button className="btn btn-gray"
					 onClick={() => {
						$("#step-3").removeClass("active show");
						$("#step-2").addClass("active show");
					  }}
					  data-toggle="pill"
					  href="#step-2"
					  role="tab"
					>Back</button>
					<button className="btn btn-blue"
          className="btn btn-blue"
          data-toggle="pill"
          // href="#step-3"
          onClick={(e) => {
            this.stepThreeValidation(e);
          }}
          role="tab"
          >Next</button>
					</div>
				</div>


				</div> */}
                {/* <div className="tab-pane fade" id="step-2" role="tabpanel">
                  <h3>Professional Experience</h3>
                  <form className="tab-form row">
                    <div className="col-12">
                      <div className="form-group">
                        <label>
                          Describe your main role(s) and accomplishments
                        </label>
                        <textarea
                          value={this.props.main_roles}
                          onChange={(e) => {
                            this.props.changeInput(
                              "main_roles",
                              e.target.value
                            );
                          }}
                          className="form-control"
                          defaultValue={""}
                        />
                        {this.props.errors.main_roles &&
                        this.props.errors.main_roles.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.main_roles}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Upload your Resume</label>
                        <Dropzone
                          onDrop={(acceptedFiles) => {
                            this.handleDropzone(acceptedFiles);
                          }}
                        >
                          {({ getRootProps, getInputProps }) => (
                            <div
                              className="upload-wizard"
                              style={{ outline: "none" }}
                              {...getRootProps()}
                            >
                              <input
                                {...getInputProps()}
                                id="resume_upload"
                                type="file"
                                style={{ display: "none" }}
                              ></input>
                              <span>
                                Upload your Resume <br /> or
                              </span>
                              <a href="javascript:;">Browse File</a>
                              <strong>
                                {this.props.loading ? "Uploading..." : this.props.file_name}
                              </strong>
                            </div>
                          )}
                        </Dropzone>
                        {this.props.errors.resume_file &&
                        this.props.errors.resume_file.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.resume_file}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group mb-0">
                        <label>Resume Privacy Settings</label>
                        <div className="col-12 p-0">
                          <label className="input">
                            <input type="radio" name="privacy" 
                               onChange={(e) => {
                                this.props.changeInput(
                                  "resume_privacy_setting",
                                  'public'
                                );
                              }}
                            />
                            Public
                          </label>
                          <span className="radio-cont">Your resume will be visible to anyone, in accordance with our terms. Your phone number and email address are only provided to employers you apply or respond to. Your street address is visible only to you.</span>
                        </div>
                        <div className="col-12 p-0">
                          <label className="input">
                            <input type="radio" name="privacy" 
                              onChange={(e) => {
                                this.props.changeInput(
                                  "resume_privacy_setting",
                                  'private'
                                );
                              }}
                            />
                            Private
                          </label>
                          <span className="radio-cont">Your resume is not visible. Employers cannot find your resume, but you can attach it when you apply to a job.</span>
                        </div>
                        {this.props.errors.resume_privacy_setting &&
                        this.props.errors.resume_privacy_setting.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.resume_privacy_setting}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                  </form>
                  <div className="row">
                    <div className="col-12 btn-btm-wrap">
                      <button
                        className="btn btn-gray"
                        onClick={() => {
                          $("#step-2").removeClass("active show");
                          $("#step-1").addClass("active show");
                        }}
                        data-toggle="pill"
                        href="#step-1"
                        role="tab"
                      >
                        Back
                      </button>
                      <button
                        className="btn btn-blue"
                        data-toggle="pill"
                        // href="#step-3"
                        onClick={(e) => {
                          this.stepTwoValidation(e);
                        }}
                        role="tab"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div> */}
                <div className="tab-pane fade" id="step-4" role="tabpanel">
                
                  <h3>Qualification &amp; Skills</h3>
                  <form className="tab-form row">
                    <div className="col-12">
                      <div className="form-group">
                        <label>Institution Name</label>
                        <input
                          type="text"
                          className="form-control selectpicker"
                          data-live-search="true"    
                          placeholder="IICGS collage,penong"
                          name
                          value={this.props.instution_name}
                          onChange={(e) => {
                            this.props.changeInput(
                              "instution_name",
                              e.target.value
                            );
                          }}
                        />
                        {this.props.errors.instution_name &&
                        this.props.errors.instution_name.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.instution_name}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Qualification</label>
                            <select
                              className="form-control selectpicker"
                              data-live-search="true"    
                              title="Choose Qualification"
                              value={this.props.qualification}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "qualification",
                                  e.target.value
                                );
                              }}
                            >

                              {/* <option value="">Choose Qualification</option> */}
                              {
                                this.props.listqualifications &&
                                this.props.listqualifications.length > 0 &&
                                this.props.listqualifications.map((i,k) => {
                                  return <option value="Diploma"
                                  key = {k}
                                  value = {i}
                                  >
                                    {i}
                                  </option>
                                })
                              }
                              
                              {/* <option value="Degree">Degree</option>
                              <option value="Higher Schools">
                                Higher Schools
                              </option> */}
                            </select>
                            {this.props.errors.qualification &&
                            this.props.errors.qualification.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.qualification}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Completion Year</label>
                            <select
                              className="selectpicker form-control "
                              data-live-search="true"    
                              title = "Choose Year"
                              value={this.props.completion_year}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "completion_year",
                                  e.target.value
                                );
                              }}
                            >
                              {/* <option value="">Choose Year</option> */}
                             {
                               this.props.completion_year_arr &&
                               this.props.completion_year_arr.length > 0 &&
                               this.props.completion_year_arr.map((i,k) => {
                                 return <option key = {k}value={i}>{i}</option>
                               })
                             }
                              
                            </select>
                            {this.props.errors.completion_year &&
                            this.props.errors.completion_year.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.completion_year}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    {this.props.qualification === "Others" &&
                  <div className="col-12">
                    <div className="form-group">
                      {/* <label>Institution Name</label> */}
                      <input
                        type="text"
                        className="form-control selectpicker"
                        data-live-search="true"    
                        placeholder=""
                        name
                        value={this.props.qualification_ot}
                        onChange={(e) => {
                          this.props.changeInput(
                            "qualification_ot",
                            e.target.value
                          );
                        }}
                      />
                      {this.props.errors.qualification_ot &&
                      this.props.errors.qualification_ot.length > 0 ? (
                        <small className="text-danger">
                          {this.props.errors.qualification_ot}
                        </small>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                }
                    <span className="col-12 subtitle">Language skills</span>
                    <div className="col-12">
                      {this.createSkills()}
                      <a
                        href="javascript:;"
                        className="add-sec"
                        onClick={this.addMoreSkills.bind(this)}
                      >
                        <img
                          src="/assets/images/add-circle-fill-icon.svg"
                          alt="icon"
                        />
                        Add Language
                      </a>
                    </div>

                  <span className="col-12 subtitle">Disability</span>
        
                  <div className="col-12">
                
                  <div className="row">
                    <div className="col-md-12">
                    <label className="input mt-0 mb-3">
                      <input type="checkbox"
                      checked={this.props.disability}
                      onChange={(e) => {
                        this.props.changeInput(
                        "disability",
                        e.target.checked
                      );
                      }}
                      name="ot-req" />
                      I am a Person With Disability
                    </label>
                    <input type="text" className="form-control" name placeholder="Describe Disability" 
                    value={this.props.desc_disability}
                    onChange={(e) => {
                        this.props.changeInput(
                        "desc_disability",
                        e.target.value
                      );
                    }}
                    />
                    {this.props.errors.desc_disability &&
                    this.props.errors.desc_disability.length > 0 ? (
                      <small className="text-danger">
                        {this.props.errors.desc_disability}
                      </small>
                    ) : (
                      ""
                    )}
                    </div>
                  </div>
                  </div>
                  </form>
                  <div className="row">
                    <div className="col-12 btn-btm-wrap">
                      <button
                        className="btn btn-gray"
                        onClick={() => {
                          $("#step-4").removeClass("active show");
                          $("#step-2").addClass("active show");
                        }}
                        data-toggle="pill"
                        href="#step-2"
                        role="tab"
                      >
                        Back
                      </button>
                      <button
                        className="btn btn-blue"
                        data-toggle="pill"
                        //  href="#step-4"
                        role="tab"
                        onClick={(e) => {
                          this.stepFourValidation(e);
                        }}
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
                <div className="tab-pane fade" id="step-5" role="tabpanel">
                  <h3>Password</h3>
                  <form className="tab-form row">
                    <div className="col-12">
                      <div className="form-group pass-visible">
                        <label>Password</label>
                        <input
                          type={!this.state.visibility_pass? "password": "text"}
                          className="form-control"
                          placeholder="At least 8 characters containing letters and numbers"
                          name
                          value={this.props.password}
                          onChange={(e) => {
                            this.props.changeInput("password", e.target.value);
                          }}
                        />
                          <a href="javascript:;" className="visibility-icon">
                        <img
                          className={!this.state.visibility_pass ? "off":''}
                          src={!this.state.visibility_pass ? 
                            "/assets/images/visibility-off.svg":
                            "/assets/images/visibility-on.svg"}
                          alt="icon"
                          onClick={(e) => {
             
                            this.setState({
                              visibility_pass:!this.state.visibility_pass
                            });
                          }}
                        />
                        </a>
                        {this.props.errors.password &&
                        this.props.errors.password.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.password}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group pass-visible">
                        <label>Confirm Password</label>
                        <input
                          type={!this.state.visibility? "password": "text"}
                          className="form-control"
                          placeholder="At least 8 characters containing letters and numbers"
                          name
                          value={this.props.confirm_password}
                          onChange={(e) => {
                            this.props.changeInput(
                              "confirm_password",
                              e.target.value
                            );
                          }}
                        />
                         <a href="javascript:;" className="visibility-icon">
                         
                        <img
                          className={!this.state.visibility ? "off":''}

                          src={!this.state.visibility ? 
                            "/assets/images/visibility-off.svg":
                            "/assets/images/visibility-on.svg"}
                          alt="icon"
                          onClick={(e) => {
                            this.setState({
                              visibility:!this.state.visibility
                            });
                            
                          }}
                        />

                    </a>
                        {this.props.errors.confirm_password &&
                        this.props.errors.confirm_password.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.confirm_password}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                        
                      <label className="input mt-3">
                            
                        <input 
                        type="checkbox" name="ot-req" 
                        checked = {this.props.resume_privacy_setting === "public" ? true : false}
                        onChange = {(e) => {
                       
                            let target_val = e.target.checked ? "public":"privacy"
                            this.props.changeInput("resume_privacy_setting", target_val);
                        }}
                        />
                        I agree your T&C and Privacy policy
                        </label>
                        {this.props.errors.resume_privacy_setting &&
                        this.props.errors.resume_privacy_setting.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.resume_privacy_setting}
                          </small>
                        ) : (
                          ""
                        )}
                        </div>
                  </form>
                  <div className="row">
                    <div className="col-12 btn-btm-wrap">
                      <button
                        className="btn btn-gray"
                        onClick={() => {
                          $("#step-5").removeClass("active show");
                          $("#step-4").addClass("active show");
                        }}
                        data-toggle="pill"
                        href="#step-4"
                        role="tab"
                      >
                        Back
                      </button>
                      <button
                        disabled={this.props.loading ? true : false}
                        className="btn btn-blue"
                        onClick={(e) => this.signUp(e)}
                      >
                        {this.props.loading ? 'Loading...' :'Sign up'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    empName:state.signupWork.empName,
    dob:state.signupWork.dob,
    gender:state.signupWork.gender,
    country_code:state.signupWork.country_code,
    phone_number:state.signupWork.phone_number,
    Email:state.signupWork.Email,
    added_cat_id:state.signupWork.added_cat_id,
    added_new_position:state.signupWork.added_new_position,
    Address:state.signupWork.Address,
    city:state.signupWork.city,
    postal_code:state.signupWork.postal_code,
    main_roles:state.signupWork.main_roles,
    resume_file:state.signupWork.resume_file,
    resume_privacy_setting:state.signupWork.resume_privacy_setting,
    instution_name:state.signupWork.instution_name,
    qualification:state.signupWork.qualification,
    completion_year:state.signupWork.completion_year,
    password:state.signupWork.password,
    confirm_password:state.signupWork.confirm_password,
    language_skills:state.signupWork.language_skills,
    language:state.signupWork.language,
    spoken:state.signupWork.spoken,
    read:state.signupWork.read,
    loading:state.signupWork.loading,
    written:state.signupWork.written,
    errors:state.signupWork.errors,
    show:state.signupWork.show,
    varient:state.signupWork.varient,
    showMsg:state.signupWork.showMsg,
    file_name:state.signupWork.file_name,
    new_position_added:state.signupWork.new_position_added,
	  skill_name:state.signupWork.skill_name,
    skill_experience:state.signupWork.skill_experience,
	  epf :state.signupWork.epf,
    socso :state.signupWork.socso,
    new_skill_added:state.signupWork.new_skill_added,
    added_new_skill_name:state.signupWork.added_new_skill_name,
    bank_name:state.signupWork.bank_name,
    bank_account_number :state.signupWork.bank_account_number ,
    disability:state.signupWork.disability,
    desc_disability:state.signupWork.desc_disability,
    jobExperience:state.signupWork.jobExperience,
    ic_number:state.signupWork.ic_number,
    total_experience:state.signupWork.total_experience,
    last_name:state.signupWork.last_name,
    multiSkills :state.signupWork.multiSkills,
    display: state.PasswordSet.display,
    type: state.PasswordSet.type,
    type_conf: state.PasswordSet.type_conf,
    display_conf: state.PasswordSet.display_conf,
    positions : state.Home.positions,
    industries : state.Home.industries,
    skills: state.Home.skills,   
    listlanguages : state.Home.listlanguages,
    listqualifications: state.Home.listqualifications,
    completion_year_arr : state.Home.completion_year_arr,
    is_vaccinated:state.signupWork.is_vaccinated,
    
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  	return {
		uploadResume : (data) => dispatch(actions.UploadEmployeeProfile(data)),
    getIndustries : () => dispatch(getIndustries()),
    getSkills : () => dispatch(getSkills()),
		changeInput: (f, e) => dispatch(actions.inputChange(f, e)),
		updateErrors: (data) => dispatch(actions.updateErrors(data)),
    getPositions : data => dispatch(getPositions(data)),
		// addAllSkills: (data) => dispatch(actions.addAllLangSkills(data)),
		setShow: (data) => dispatch(actions.setShow(data)),
    getLanguages : () => dispatch(getLanguages()),
    getQualifications : () => dispatch(getQualifications()),
    getPassoutYear : () => dispatch(getPassoutYear()),
		signUpWorkRegister: (data) => dispatch(actions.signUpWorkRegister(data)),
		AddMoreField : (data, value) => dispatch(actions.AddMoreField(data, value)),
    addPositions: (data) => dispatch(actions.addPositions(data)),
    addSkills : (data) => dispatch(actions.addSkills(data))
  	};
};

const sign_work = connect(mapStateToProps, mapDispatchToProps)(WorkSign);

export default sign_work;

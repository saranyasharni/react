import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import $ from "jquery";
import * as actions from "../../actions/signupWork";
import Alert from "react-bootstrap/Alert";
import Autocomplete from "react-google-autocomplete";
import Dropzone from "react-dropzone";

class SignUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      password : true,
      confirm_password : true
    }
  }

  componentDidMount() {
    $(document).ready(function () {
      window.$(".selectpicker").selectpicker();
    });
    // require("../../assets/css/custom-style.css");
    let removingElament = document.getElementById("design_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
  }
  
  componentDidUpdate() {
    $(document).ready(function () {
      window.$(".selectpicker").selectpicker();
    });
  }

  stepOne(e) {

    let errors = this.props.errors;
    let valid = true;

    if (this.props.user_name === "") {
      errors.user_name = "Please fill in mandatory field";
    }

    if (this.props.phone_number == "") {
      valid = false;
      errors.phone_number = "Please fill in mandatory field";
    }

    if (this.props.phone_number !== "" && 
    this.props.phone_number.length > 10
    ) {
      
      valid = false;
      errors.phone_number = "Mobile number must be less than 10 digits";
    }
    
    if (this.props.Email == "") {
      valid = false;
      errors.Email = "Please fill in mandatory field";
    }

    if (this.props.emailExists === true) {
      
      valid = false;
      errors.Email = "Email already exists";
    }

    if (!this.props.Email == "") {
      if (!this.validateEmail(this.props.Email)) {
        valid = false;
        errors.Email = "Please enter a valid email";
      }
    }
    if (!this.props.privacy_policy) {
      valid = false;
      errors.privacy_policy = "Please agree the T&C and Privacy Policy";  
    }
    // if (this.props.landline_number == "") {
    //   valid = false;
    //   errors.landline_number = "Please fill in mandatory field";
    // }
    if (this.props.landline_number !== "" && this.props.landline_number.length > 10) {
      valid = false;
      errors.landline_number = "Landline number must be less than 10 digits";
    }
    this.props.updateErrors(errors);


    if (valid) {
   
      this.props.updateErrors({
        user_name: "",
        phone_number: "",
        Email: "",
        phone_number: "",
        landline_number: "",
        privacy_policy : "",
      });
      $("#next-2").addClass("active");
      $(e.target).attr("href", "#step-2");
      $("#step-1").removeClass("active show");
      $("#step-2").addClass("active show");
    }
  }

  stepTwo(e) {
    // console.log(this.props.proof_document, 'proof')
    let errors = this.props.errors;
    let valid = true;

    if (this.props.company_name === "") {
      errors.company_name = "Please fill in mandatory field";
    }
    if (this.props.landline_number == "") {
      valid = false;
      errors.landline_number = "Please fill in mandatory field";
    }
    if (this.props.landline_number !== "" && this.props.landline_number.length > 10) {
      valid = false;
      errors.landline_number = "Landline number must be less than 10 digits";
    }
   
    if (this.props.company_registration_number == "") {
      valid = false;
      errors.company_registration_number = "Please fill in mandatory field";
    }
    if (this.props.mailing_address == "") {
      valid = false;
      errors.mailing_address = "Please fill in mandatory field";
    }
    // if (this.props.mailing_address1 == "") {
    //   valid = false;
    //   errors.mailing_address1 = "Please fill in mandatory field";
    // }
    if (this.props.mailing_address_city == "") {
      valid = false;
      errors.mailing_address_city = "Please fill in mandatory field";
    }
    if (this.props.mailing_address_postal_code == "") {
      valid = false;
      errors.mailing_address_postal_code = "Please fill in mandatory field";
    }
    // if (this.props.company_landline_number !== "" 
    // && this.props.company_landline_number.length > 10) {
    //   valid = false;
    //   errors.company_landline_number = "Landline number must be less than 10 digits";
    // }
    // if (this.props.company_landline_number == "") {
    //   valid = false;
    //   errors.company_landline_number = "Please fill in mandatory field";
    // }
    // if (this.props.company_mobile_number == "") {
    //   valid = false;
    //   errors.company_mobile_number = "Cannot be Empty";
    // }
    // if (this.props.company_mobile_number !== "" 
    // && this.props.company_mobile_number.length > 10) {
      
    //   valid = false;
    //   errors.company_mobile_number = "Mobile Number must be less than 10 digits";
    // }
    
    // if (this.props.proof_document.length === 0) {
      
    //   valid = false;
    //   errors.proof_document = "Please upload a document";
    // }

    this.props.updateErrors(errors);
    if (valid) {
      this.props.updateErrors({
        company_name: "",
        company_registration_number: "",
        mailing_address: "",
        mailing_address_city:'',
        mailing_address_postal_code:'',
        billing_address: "",
        phone_number:"",
        landline_number:'',
        company_landline_number: "",
        company_mobile_number: "",
        proof_document : ""
      });
      $("#next-3").addClass("active");
      $(e.target).attr("href", "#step-3");
      $("#step-2").removeClass("active show");
      $("#step-3").addClass("active show");
    }
  }

  signUp() {

    let errors = this.props.errors;
    let valid = true;

  

    if (this.props.password === "") {
      valid = false;
      errors.password = "Please fill in mandatory field";
    } else if (this.props.password && this.props.password.length < 8) {
      valid = false;
      errors.password = "Password must be more than 8 characters";
    } else if (this.props.password && this.props.password.search(/\d/) == -1) {
      valid = false;
      errors.password = "Password must contain numbers";
    } else if (
      this.props.password !== "" &&
      this.props.password.search(/[a-zA-Z]/) == -1
    ) {
      valid = false;
      errors.password = "Password must contain letters";
    } else {
      valid = true;
      errors.password = "";
    }

    if (this.props.confirm_password == "") {
      valid = false;
      errors.confirm_password = "Please fill in mandatory field";
    } else if (
      this.props.confirm_password &&
      this.props.confirm_password.length < 8
    ) {
      valid = false;
      errors.confirm_password =
        "Confirm password must be more than 8 characters";
    } else if (
      this.props.confirm_password &&
      this.props.confirm_password.search(/\d/) == -1
    ) {
      valid = false;
      errors.confirm_password = "Confirm password must contain numbers";
    } else if (
      this.props.confirm_password &&
      this.props.confirm_password.search(/[a-zA-Z]/) == -1
    ) {
      valid = false;
      errors.confirm_password = "Confirm password must contain letters";
    } else {
      valid = true;
      errors.confirm_password = "";
      this.props.updateErrors(errors);
    }

    if (this.props.password !== this.props.confirm_password) {
      valid = false;
      errors.password = "Password Not Matching";
      errors.confirm_password = "Password Not Matching";
    }

    this.props.updateErrors(errors);
    
    if (valid) {
      this.props.signUpHireRegister({
        user_name: this.props.user_name,
        email: this.props.Email,
        // country_code:this.props.country_code,
        company_name: this.props.company_name,
        company_registration_number: this.props.company_registration_number,
        landline_number: this.props.land_line_country_code+this.props.landline_number,
        phone_number: this.props.country_code + this.props.phone_number,
        same_as_billing_address:this.props.billing_checkbox?1:0,
        mailing_address: this.props.mailing_address,
        billing_address: this.props.billing_checkbox 
        ? this.props.mailing_address :this.props.billing_address
        ,
        company_landline_number: this.props.company_land_line_country_code
        +this.props.company_landline_number,
        company_mobile_number:
          this.props.company_number_country_code +
          this.props.company_mobile_number,
        // company_number_country_code:,
        password: this.props.password,
        proof_document: this.props.proof_document,
        url :this.props.proof_document,
        mailing_address_2: this.props.mailing_address1,
        mailing_address_city: this.props.mailing_address_city,
        mailing_address_state: this.props.mailing_address_postal_code,
        mailing_country: "",
        billing_address_2: this.props.billing_checkbox ? 
        this.props.mailing_address1 :
        this.props.Address,
        billing_address_city:
        this.props.billing_checkbox ? this.props.mailing_address_city:
        this.props.city,
        billing_address_state:
        this.props.billing_checkbox ?
        this.props.mailing_address_postal_code :
        this.props.postal_code,
        billing_country: "",
      });
    }
  }

  validateEmail(email) {
    const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return expression.test(String(email).toLowerCase());
  }

  handleDropzone = (files) => {
    // console.log(files, 'files')
    if (files) {
      this.props.uploadEmployerDocument(files[0]);  
    }
  }

  setPlaces = (place, check) => {
    console.log(place, 'placesOfAdress');
    console.log(place.address_components[place.address_components.length - 1].long_name, "country..........");
    console.log(place.address_components[place.address_components.length - 2].long_name, "state.............");
    console.log(place.address_components[place.address_components.length - 3].long_name, "city.............");
    console.log(place.address_components[place.address_components.length - 4].long_name, "address..........");

    if (check === 'mailing') {
      if (place && place.formatted_address &&  place.formatted_address.length >0) {  
      this.props.changeInput("mailing_address", place.formatted_address);
      let length = place.address_components &&
                    place.address_components.length > 0 ?
                    place.address_components.length-1 :""
      this.props.changeInput("mailing_address1", place.address_components 
                                                 && place.address_components.length > 0 
                                                 && place.address_components[place.address_components.length-4].long_name
      )
      this.props.changeInput("mailing_address_city", place.address_components
                                                     && place.address_components.length > 0 
                                                     && place.address_components[length-2].long_name)
      
      if (place.address_components && place.address_components.length >0 && place.address_components[length].types[0] ==="postal_code") {
        this.props.changeInput("mailing_address_postal_code", parseInt(place.address_components[length].long_name))
      } else {
        this.props.changeInput("mailing_address_postal_code", "")
      }
      sessionStorage.setItem('Emp_address', place.formatted_address)
      sessionStorage.setItem('Emp_address_city', place.address_components[length-2].long_name)
      sessionStorage.setItem('Emp_address_postal_code', parseInt(place.address_components[length].long_name))
    } else {
        this.props.changeInput("mailing_address", "");
      this.props.changeInput("mailing_address1", "")
      this.props.changeInput("mailing_address_city", "")
      this.props.changeInput("mailing_address_postal_code", "")
      }
    } else if (check === 'billing') {
      if ( place && place.formatted_address &&  place.formatted_address.length >0) {
        this.props.changeInput("billing_address", place.formatted_address);
        let length = place.address_components &&
        place.address_components.length > 0 ?
        place.address_components.length-1 :""
        this.props.changeInput("Address", place.address_components && place.address_components.length >0 &&
        place.address_components[1].long_name
        )
        this.props.changeInput("city", place.address_components && place.address_components.length >0 &&place.address_components[length-2].long_name)
        if (place.address_components && place.address_components.length >0 && place.address_components[length].types[0] ==="postal_code") {
          this.props.changeInput("postal_code", parseInt(place.address_components[length].long_name))
        } else {
          this.props.changeInput("postal_code", "")
        }
      } else {
        this.props.changeInput("billing_address", "");
        this.props.changeInput("Address", "")
        this.props.changeInput("city", "")
        this.props.changeInput("postal_code", "")
      }
    }
  }

  render() {
    return (
      <div>
        <div className="container-fluid main-wrap">
          <div className="row">
            <div className="col-md-6 signup-lft signup-hire-bg" />
            
            <div className="col-md-6 signup-rgt">
            <div className="">
            <h2 
            className="n__signup-title mb-4">Employer Signup</h2>
            </div>

              {
                <Alert
                  show={this.props.show}
                  variant={this.props.varient}
                  dismissible
                  onClose={() => this.props.setShow(false)}
                >
                  <strong>
                    {this.props.employee_register_status === 1
                      ? "Success!"
                      : "Error!"}
                  </strong>{" "}
                  {this.props.showMsg}
                </Alert>
              }
              
              <ul className="nav nav-pills" role="tablist">
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    data-toggle="pill"
                    href="#step-1"
                    role="tab"
                    id="next-1"
                    aria-selected="true"
                  >
                    <span>1</span>
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="pill"
                    href="#step-2"
                    role="tab"
                    id="next-2"
                    aria-selected="false"
                  >
                    <span>2</span>
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link"
                    data-toggle="pill"
                    href="#step-3"
                    role="tab"
                    id="next-3"
                    aria-selected="false"
                  >
                    <span>3</span>
                  </a>
                </li>
              </ul>
              <div className="tab-content">
                <div
                  className="tab-pane fade show active"
                  id="step-1"
                  role="tabpanel"
                >
                  <h3>Let's Get Started</h3>
                  <div className="n__helper-block">
                    <span className="mb-4 n__helper-text">Please fill all the required(*) fields</span>
                    </div>
                  <br />
                  <form className="tab-form row">
                    <div className="col-12">
                      <div className="form-group">
                        <label>User Name</label>
                        <span className = "text-danger m">*</span>
                        <input
                          type="text"
                          className={this.props.errors.user_name &&
                            this.props.errors.user_name.length > 0 ? 'form-control border-danger':'form-control'}
                          value={this.props.user_name}
                          onChange={(e) => {
                            this.props.changeInput("user_name", e.target.value);
                          }}
                          placeholder="Your Name"
                          name
                        />
                        {this.props.errors.user_name &&
                        this.props.errors.user_name.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.user_name}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Email Address</label>
                        <span className = "text-danger m">*</span>
                        <input
                          type="text"
                          className={this.props.errors.Email &&
                            this.props.errors.Email.length > 0 ? 'form-control border-danger':'form-control'}
                          value={this.props.Email}
                          onChange={(e) => {
                            this.props.changeInput("Email", e.target.value);
                          }}
                          placeholder="Your Email"
                          name
                        />
                        {this.props.errors.Email &&
                        this.props.errors.Email.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.Email}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    {/* <div className="col-12">
                      <div className="form-group">
                        <label>Landline number</label>
                        <div className="two-input">
                          <select
                            value={this.props.land_line_country_code}
                            onChange={(e) => {
                              this.props.changeInput(
                                "land_line_country_code",
                                e.target.value
                              );
                            }}
                            className="form-control selectpicker"
                          >
                            <option>+60</option> 
                          </select>
                          <input
                          type="text"
                          className={this.props.errors.landline_number &&
                            this.props.errors.landline_number.length > 0 ? "form-control selectpicker border-danger":"form-control selectpicker"}
                          value={this.props.landline_number}
                          onChange={(e) => {
                            const re = /^[0-9\b]+$/;
                            if (
                              e.target.value === "" ||
                              re.test(e.target.value)
                            ) {
                              this.props.changeInput(
                                "landline_number",
                                e.target.value
                              );
                            }
                          }}
                          placeholder="3-2303 1296"
                          name
                        />
                        
                        </div>
                        {this.props.errors.landline_number &&
                        this.props.errors.landline_number.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.landline_number}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div> */}
                    <div className="col-12">
                      <div className="form-group">
                        <label>Mobile Number</label>
                        <span className = "text-danger m">*</span>
                        <div className="two-input">
                          <select
                            value={this.props.country_code}
                            onChange={(e) => {
                              this.props.changeInput(
                                "country_code",
                                e.target.value
                              );
                            }}
                            className="form-control selectpicker"
                          >
                            
                            <option>+65</option>
                            <option>+60</option>
                          </select>
                          <input
                            type="text"
                            value={this.props.phone_number}
                            onChange={(e) => {
                              const re = /^[0-9\b]+$/;
                              if (
                                e.target.value === "" ||
                                re.test(e.target.value)
                              ) {
                                this.props.changeInput(
                                  "phone_number",
                                  e.target.value
                                );
                              }
                            }}
                            className={this.props.errors.phone_number &&
                              this.props.errors.phone_number.length > 0 ? "form-control border-danger":"form-control selectpicker"}
                            name
                            placeholder="17-661 0472"
                          />
                        </div>
                        {this.props.errors.phone_number &&
                        this.props.errors.phone_number.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.phone_number}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                        
                        <label className="input mt-3">
                              
                          <input 
                          type="checkbox" name="ot-req" 
                          checked = {this.props.privacy_policy}
                          onChange = {(e) => {
                         
                              let target_val = e.target.checked 
                              this.props.changeInput("privacy_policy", target_val);
                          }}
                          />
                          I agree your T&C and Privacy policy
                          </label>
                          {this.props.errors.privacy_policy &&
                          this.props.errors.privacy_policy.length > 0 ? (
                            <small className="text-danger">
                              {this.props.errors.privacy_policy}
                            </small>
                          ) : (
                            ""
                          )}
                      </div>
                    <div className="col-12 mt-2">
                      <button
                        className="btn btn-blue w-100"
                        data-toggle="pill"
                        onClick={async (e) => {
                          await this.props.checkEmail({email: this.props.Email});
                          this.stepOne(e);
                        }}
                        // href="#step-2"
                        role="tab"
                      >
                        Next
                      </button>
                    </div>
                    <div className="col-12 signup-btm-p mt-4">
                      <p>
                        I have an Account? <a href="/login_hire">Sign in</a>
                      </p>
                      <p>
                        <a className="forgot-pass" href="/employer/forgot_password">
                          Forgot Your Password?
                        </a>
                      </p>
                    </div>
                  </form>
                </div>
                <div className="tab-pane fade" id="step-2" role="tabpanel">
                  <h3>Company Detail</h3>
                  <div className="n__helper-block">
                    <span className="mb-4 n__helper-text">Please fill all the required(*) fields</span>
                    </div>
                    <br />
                  <form className="tab-form row">
                    <div className="col-12">
                      <div className="row">
                        <div className="col-xl-6 col-lg-12 col-md-12">
                          <div className="form-group">
                            <label>Company Name</label>
                            <span className = "text-danger m">*</span>
                            <input
                              type="text"
                              className={this.props.errors.company_name &&
                                this.props.errors.company_name.length > 0  ? "form-control border-danger":"form-control"}
                              value={this.props.company_name}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "company_name",
                                  e.target.value
                                );
                              }}
                              name
                              placeholder="Your Company"
                            />
                            {this.props.errors.company_name &&
                            this.props.errors.company_name.length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.company_name}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-12 col-md-12">
                          <div className="form-group">
                            <label>Company Registration Number</label>
                            <span className = "text-danger m">*</span>
                            <input
                              type="text"
                              value={this.props.company_registration_number}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "company_registration_number",
                                  e.target.value
                                );
                              }}
                              className={this.props.errors.company_registration_number &&
                                this.props.errors.company_registration_number
                                  .length > 0  ? "form-control border-danger":"form-control"}
                              name
                              placeholder="Registration Number"
                            />
                            {this.props.errors.company_registration_number &&
                            this.props.errors.company_registration_number
                              .length > 0 ? (
                              <small className="text-danger">
                                {this.props.errors.company_registration_number}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Mailing Address Line1</label>
                        <span className = "text-danger m">*</span>
                            <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className="form-control"
                            value = {this.props.mailing_address}
                            onChange={(e) => {
                              
                              this.props.changeInput("mailing_address", e.target.value);
                            }}
                            onPlaceSelected={(place) => {
                              console.log(place, "address");
                              this.setPlaces(place, 'mailing');
                            }}
                            options={{
                              types: ["address"],
                              componentRestrictions: { country: "my" },
                            }}
                            defaultValue={this.props.mailing_address}
                            />
                        {/* <input
                          type="text"
                          value={this.props.mailing_address}
                          onChange={(e) => {
                            this.props.changeInput(
                              "mailing_address",
                              e.target.value
                            );
                          }}
                          className={this.props.errors.mailing_address &&
                            this.props.errors.mailing_address.length > 0 ? "form-control border-danger":"form-control"}
                          placeholder="Street Address"
                          name
                        /> */}
                        {this.props.errors.mailing_address &&
                        this.props.errors.mailing_address.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.mailing_address}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                      
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>City</label>
                        
                        <input
                          type="text"
                          value={this.props.mailing_address1}
                          onChange={(e) => {
                            this.props.changeInput(
                              "mailing_address1",
                              e.target.value
                            );
                          }}
                          className="form-control"
                          placeholder="Street Address"
                          name
                        />
                        {/* {this.props.errors.mailing_address1 &&
                        this.props.errors.mailing_address1.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.mailing_address1}
                          </small>
                        ) : (
                          ""
                        )} */}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>State</label>
                            <span className = "text-danger m">*</span>   
                            <input
                              type="text"
                              className={this.props.errors.mailing_address_city &&
                                this.props.errors.mailing_address_city.length > 0 ? "form-control border-danger":"form-control"}
                              value={this.props.mailing_address_city}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "mailing_address_city",
                                  e.target.value
                                );
                              }}
                              placeholder="Kuala Lumpur"
                              name
                            />
                             {this.props.errors.mailing_address_city &&
                              this.props.errors.mailing_address_city.length > 0 ? (
                                <small className="text-danger">
                                  {this.props.errors.mailing_address_city}
                                </small>
                              ) : (
                                ""
                              )}
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Postal Code</label>
                            <span className = "text-danger m">*</span>
                            <input
                              type="text"
                              className={this.props.errors.mailing_address_postal_code &&
                                this.props.errors.mailing_address_postal_code.length > 0 ? "form-control border-danger":"form-control"}

                              value={isNaN(this.props.mailing_address_postal_code) ?
                                "":this.props.mailing_address_postal_code
                              }
                              onChange={(e) => {
                                const re = /^[0-9\b]+$/;
                                if (e.target.value.length <= 5) {
                                  if (
                                    e.target.value === "" ||
                                    re.test(e.target.value)
                                  ) {
                                    this.props.changeInput(
                                      "mailing_address_postal_code",
                                      e.target.value
                                    );
                                  } 
                                }
                              }}
                              placeholder={50480}
                              name
                            />
                            {this.props.errors.mailing_address_postal_code &&
                            this.props.errors.mailing_address_postal_code.length > 0 ? (
                            <small className="text-danger">
                            {this.props.errors.mailing_address_postal_code}
                          </small>
                        ) : (
                          ""
                        )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label className="checkbox-label">
                          <input
                            type="checkbox"
                            name="address"
                            
                            checked = {this.props.billing_checkbox}
                            onChange={(e) => {
                             
                              this.props.changeInput(
                                "billing_checkbox",
                                e.target.checked
                              );
                            }}
                          />
                          Same as my Mailing Address
                        </label>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Billing Address Line1</label>
                        <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className={this.props.errors.billing_address &&
                              this.props.errors.billing_address.length > 0 ? "form-control border-danger":"form-control"}
                            value={
                              this.props.billing_checkbox ? 
                              this.props.mailing_address : this.props.billing_address
                            }
                            onChange={(e) => {
                              this.props.changeInput(
                                "billing_address",
                                e.target.value
                              );
                            }}
                            onPlaceSelected={(place) => {
                              this.setPlaces(place, 'billing')
                            }}
                            options={{
                              types: ['address'],
                              componentRestrictions: { country: "my" },
                            }}
                            defaultValue={this.props.mailing_address}
                        />
                        {/* <input
                          type="text"
                          value={
                            this.props.billing_checkbox ? 
                            this.props.mailing_address : this.props.billing_address
                          }
                          onChange={(e) => {
                            this.props.changeInput(
                              "billing_address",
                              e.target.value
                            );
                          }}
                          className={this.props.errors.billing_address &&
                            this.props.errors.billing_address.length > 0 ? "form-control border-danger":"form-control"}
                          placeholder="Street Address"
                          name
                        /> */}
                        {this.props.errors.billing_address &&
                        this.props.errors.billing_address.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.billing_address}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Billing Address Line2</label>
                        <input
                          type="text"
                          value={this.props.billing_checkbox ? this.props.mailing_address1 : this.props.Address}

                          onChange={(e) => {
                            this.props.changeInput(
                              "Address",
                              e.target.value
                            );
                          }}
                          className={this.props.errors.Address &&
                            this.props.errors.Address.length > 0 ? "form-control border-danger":"form-control"}
                          placeholder="Street Address"
                          name
                        />
                        {this.props.errors.Address &&
                        this.props.errors.Address.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.Address}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>City/State</label>
                           
                            <input
                              type="text"
                              className="form-control"
                              value={this.props.billing_checkbox ? this.props.mailing_address_city : this.props.city}
                              onChange={(e) => {
                                this.props.changeInput(
                                  "city",
                                  e.target.value
                                );
                              }}
                              placeholder="Kuala Lumpur"
                              name
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Postal Code</label>
                            <input
                              type="text"
                              className="form-control"
                              value={
                                this.props.billing_checkbox ? this.props.mailing_address_postal_code : this.props.postal_code
                              }
                              onChange={(e) => {
                                if (e.target.value.length <= 5) {
                                const re = /^[0-9\b]+$/;
                                  if (
                                    e.target.value === "" ||
                                    re.test(e.target.value)
                                  ) {
                                    this.props.changeInput(
                                      "postal_code",
                                      e.target.value
                                    );
                                  } }
                              }}
                              placeholder={50480}
                              name
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="row">
                      <div className="col-xl-6 col-lg-12 col-md-12">
                          <div className="form-group">
                            <label>Company Contact Number</label>
                            <span className = "text-danger m">*</span>
                            <div className="two-input">
                              <select
                                className="form-control selectpicker"
                                value={this.props.company_land_line_country_code}
                                onChange={(e) => {
                                  this.props.changeInput(
                                    "company_land_line_country_code",
                                    e.target.value
                                  );
                                }}
                              >
                                
                                <option>+60</option>
                               
                              </select>
                              <input
                              type="text"
                              className={this.props.errors.landline_number &&
                                this.props.errors.landline_number.length >
                                0 ? "form-control border-danger":"form-control"}
                              value={this.props.landline_number}
                              onChange={(e) => {
                                const re = /^[0-9-!@#$%+*?]/;
                                if (
                                  e.target.value === "" ||
                                  re.test(e.target.value)
                                ) {
                                  this.props.changeInput(
                                    "landline_number",
                                    e.target.value
                                  );
                                }
                              }}
                              name
                              placeholder="3-2303 1296"
                            />
                            
                            </div>
                            {this.props.errors.landline_number &&
                            this.props.errors.landline_number.length >
                              0 ? (
                              <small className="text-danger">
                                {this.props.errors.landline_number}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      {/* <div className="col-xl-6 col-lg-12 col-md-12">
                          <div className="form-group">
                            <label>Mobile Number</label>
                            <div className="two-input">
                              <select
                                className="form-control selectpicker"
                                value={this.props.company_number_country_code}
                                onChange={(e) => {
                                  this.props.changeInput(
                                    "company_number_country_code",
                                    e.target.value
                                  );
                                }}
                              >
                                
                                <option>+65</option>
                                <option>+60</option>
                              </select>
                              <input
                                type="text"
                                className={this.props.errors.phone_number &&
                                  this.props.errors.phone_number.length >
                                    0 ? "form-control border-danger":"form-control"}
                                name
                                value={this.props.phone_number}
                                onChange={(e) => {
                                  const re = /^[0-9\b]+$/;
                                  if (
                                    e.target.value === "" ||
                                    re.test(e.target.value)
                                  ) {
                                    this.props.changeInput(
                                      "phone_number",
                                      e.target.value
                                    );
                                  }
                                }}
                                placeholder="17-661 0472"
                              />
                            </div>
                            {this.props.errors.phone_number &&
                            this.props.errors.phone_number.length >
                              0 ? (
                              <small className="text-danger">
                                {this.props.errors.phone_number}
                              </small>
                            ) : (
                              ""
                            )}
                          </div>
                        </div> */}
                        
                        
                      </div>
                    </div>
                    {/* <div className="col-lg-12 col-md-12 form-group">
                          <label>Upload Your Document</label>
                          <Dropzone
                          onDrop={(acceptedFiles) => {
                            var infoArea = document.getElementById( 'file-upload-filename');
                            var fileName =  acceptedFiles[0].name;
                            infoArea.textContent =  fileName;
                            this.handleDropzone(acceptedFiles);
                          }}
                        >
                          {({ getRootProps, getInputProps }) => (
                            <div
                              className="upload-wizard"
                              style={{ outline: "none" }}
                              {...getRootProps()}
                            >
                            
                              <input
                                {...getInputProps()}
                                id="resume_upload"
                                type="file"
                                accept="application/pdf"
                                style={{ display: "none" }}
                              ></input>
                              
                              <span>
                              Upload Proof of Business Document
                                <br /> or
                              </span>
                              <a href="javascript:;">Browse File</a>
                              <strong  id="file-upload-filename" />
                              <strong>
                                {
                                   
                                props.loading ? "Uploading..." : ""} 
                              </strong>
                            </div>
                          )}
                        </Dropzone>
                        {this.props.errors.proof_document &&
                        this.props.errors.proof_document.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.proof_document}
                          </small>
                        ) : (
                          ""
                        )}
                            </div> */}
                  </form>
                  <div className="row">
                    <div className="col-12 btn-btm-wrap">
                      <button
                        className="btn btn-gray"
                        data-toggle="pill"
                        href="#step-1"
                        onClick={() => {
                          $("#step-2").removeClass("active show");
                          $("#step-1").addClass("active show");
                        }}
                        role="tab"
                      >
                        Back
                      </button>
                      <button
                        className="btn btn-blue"
                        onClick={(e) => this.stepTwo(e)}
                        data-toggle="pill"
                        // href="#step-3"
                        role="tab"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
                <div className="tab-pane fade" id="step-3" role="tabpanel">
                  <h3>Password</h3>
                  <form className="tab-form row">
                    <div className="col-12">
                      <div className="form-group pass-visible">
                        <label>Password</label>
                        <span className = "text-danger m">*</span>
                        <input
                          type={this.state.password ?"password" :"text"}
                          className={this.props.errors.password &&
                            this.props.errors.password.length > 0 ? "form-control border-danger":"form-control"}
                          value={this.props.password}
                          onChange={(e) => {
                            this.props.changeInput("password", e.target.value);
                          }}
                          placeholder="At least 8 characters containing letters and numbers"
                          name
                        />
                        <a href="javascript:;" className="visibility-icon">
                        <img
                          className="off"
                          src={this.state.password ? "/assets/images/visibility-off.svg":
                          "/assets/images/visibility-on.svg"}
                          alt="icon"
                          onClick={(e) => {
                            this.setState({
                              password:!this.state.password
                            })
                          }}
                        />
                        </a>
                        {this.props.errors.password &&
                        this.props.errors.password.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.password}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group pass-visible">
                        <label>Confirm Password</label>
                        <span className = "text-danger">*</span>
                        <input
                          type={this.state.confirm_password ?"password" :"text"}
                          className={this.props.errors.confirm_password &&
                            this.props.errors.confirm_password.length > 0 ? "form-control border-danger":"form-control"}
                            value={this.props.confirm_password}
                            onChange={(e) => {
                              $("#next-3").addClass("active");
                              this.props.changeInput(
                                "confirm_password",
                                e.target.value
                              );
                            }}
                          placeholder="At least 8 characters containing letters and numbers"
                          name
                        />
                        <a href="javascript:;" className="visibility-icon">
                        <img
                          className="off"
                          src={this.state.confirm_password ? "/assets/images/visibility-off.svg":
                          "/assets/images/visibility-on.svg"}
                          alt="icon"
                          onClick={(e) => {
                            this.setState({
                              confirm_password:!this.state.confirm_password
                            })
                          }}
                        />
                        </a>
                        {this.props.errors.confirm_password &&
                        this.props.errors.confirm_password.length > 0 ? (
                          <small className="text-danger">
                            {this.props.errors.confirm_password}
                          </small>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                  </form>
                  <div className="row">
                    <div className="col-12 btn-btm-wrap">
                      <button
                        className="btn btn-gray"
                        onClick={() => {
                          $("#step-3").removeClass("active show");
                          $("#step-2").addClass("active show");
                        }}
                        data-toggle="pill"
                        href="#step-2"
                        role="tab"
                      >
                        Back
                      </button>
                      <button
                        disabled={this.props.loading ? true : false}
                        className="btn btn-blue"
                        onClick={() => this.signUp()}
                      >
                        
                        {
                          
                          this.props.loading ? 'Loading...' : 'Sign up'
                        }
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const {
    country_code,
    phone_number,
    Email,
    landline_number,
    user_name,
    company_name,
    company_registration_number,
    mailing_address,
    billing_address,
    company_landline_number,
    company_mobile_number,
    land_line_country_code,
    company_land_line_country_code,
    company_number_country_code,
    password,
    loading,
    confirm_password,
    show,
    varient,
    showMsg,
    Address,
    city,
    postal_code,
    errors,
    billing_checkbox,
    proof_document,
    url,
    privacy_policy,
    mailing_address1,
    mailing_address_postal_code,
    mailing_address_city,
    emailExists
  } = state.signupWork;

  // const { emailExists } = state.emailExists;
  return {
    user_name,
    url,
    country_code,
    phone_number,
    billing_checkbox,
    Email,
    landline_number,
    land_line_country_code,
    company_land_line_country_code,
    company_name,
    privacy_policy,
    company_registration_number,
    mailing_address,
    billing_address,
    company_landline_number,
    company_mobile_number,
    company_number_country_code,
    password,
    confirm_password,
    loading,
    show,
    Address,
    city,
    postal_code,
    varient,
    showMsg,
    mailing_address1,
    errors,
    proof_document,
    mailing_address_postal_code,
    mailing_address_city,
    emailExists
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    changeInput: (f, e) => dispatch(actions.inputChange(f, e)),
    updateErrors: (data) => dispatch(actions.updateErrors(data)),
    setShow: (data) => dispatch(actions.setShow(data)),
    uploadEmployerDocument: (data) => dispatch(actions.uploadEmployerDocument(data)),
    signUpHireRegister: (data) => dispatch(actions.signUpHireRegister(data)),
    checkEmail: async (data) => dispatch(actions.checkEmailExistance(data))
  };
};

const sign = connect(mapStateToProps, mapDispatchToProps)(SignUp);

export default sign;

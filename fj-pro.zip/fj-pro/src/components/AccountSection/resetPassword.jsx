import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import { setPassword, sendResetPassword } from "../../actions/resetPassword";
import Alert from "react-bootstrap/Alert";

class Reset extends Component {
  constructor(props) {
    super(props);
  }

  checkFunc = (e) => {
    e.preventDefault();
    let valid = true
   
      if (this.props.password_new !== this.props.password_conf) {
        valid = false
        this.props.setPassword("same_check", true);
        this.props.setPassword("empty_check", false);
        this.props.setPassword("length_check", false);
        this.props.setPassword("number_check", false);
        this.props.setPassword("string_check", false);
      }
      else if (this.props.password_new == "" || this.props.password_conf == "") {
       
        valid = false
        this.props.setPassword("empty_check", true);
        this.props.setPassword("same_check", false);
        this.props.setPassword("length_check", false);
        this.props.setPassword("number_check", false);
        this.props.setPassword("string_check", false);
      }
      else if (
        this.props.password_new.length < 8 || 
        this.props.password_conf.length < 8 
      ) {
        
        valid = false;
        this.props.setPassword("length_check", true);
        this.props.setPassword("same_check", false);
        this.props.setPassword("empty_check", false);
        
        this.props.setPassword("number_check", false);
        this.props.setPassword("string_check", false);
      } else if (
        this.props.password_conf.search(/\d/) == -1 ||
        this.props.password_new.search(/\d/) == -1
      ) {
        
        valid = false;
        this.props.setPassword("number_check", true);
        this.props.setPassword("length_check", false);
        this.props.setPassword("same_check", false);
        this.props.setPassword("empty_check", false);
        this.props.setPassword("string_check", false)
      } else if (
        this.props.password_new.search(/[a-zA-Z]/) == -1
        || this.props.password_conf.search(/[a-zA-Z]/) == -1
      ) {
        
        valid = false;
        
        this.props.setPassword("string_check", true);
        this.props.setPassword("number_check", false);
        this.props.setPassword("length_check", false);
        this.props.setPassword("same_check", false);
        this.props.setPassword("empty_check", false);
        
      } else {
       
        let val = { 
          token: window.location.pathname.split('/')[3],
          password: this.props.password_conf,
        };
        this.props.sendResetPassword(val);
      }
    
  };
  componentDidMount() {
    // require("../../assets/css/custom-style.css");
    let removingElament = document.getElementById("design_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
  }

  render() {
    return (
      <Fragment>
        <div className="container-fluid main-wrap">
          <div className="row">
            {window.location.pathname == "/employee/reset_password" ? (
              <div className="col-md-6 signup-lft" />
            ) : (
              <div className="col-md-6 signup-lft signup-hire-bg" />
            )}
            <div className="col-md-6 signup-rgt">
            {
            <Alert
              show={this.props.show_alert}
              variant={this.props.varient}
              dismissible
              onClose={() => this.props.setPassword('show_alert', false)}
            >
              <strong>
                {this.props.varient == "success"
                  ? "Success!"
                  : "Error!"}
              </strong>{" "}
              {this.props.showMsg}
            </Alert>}
              <h3>Reset Password</h3>
              <div>
              <small className="">
                   (Password must be minimum 8 characters long and contain atleast one number)
                   </small>
              </div>
              <br />
              <form className="tab-form row" onSubmit={this.checkFunc}>
                <div className="col-12">
                  <div className="form-group pass-visible">
                    <label>New Password</label>
                    <input
                      className="form-control"
                      type={this.props.type}
                      name
                      placeholder
                      onChange={(e) => {
                        this.props.setPassword("password_new", e.target.value);
                      }}
                    />
                    
                    <a href="javascript:;" className="visibility-icon">
                      {this.props.display == false ? (
                        <img
                          className="off"
                          src="/assets/images/visibility-off.svg"
                          alt="icon"
                          onClick={(e) => {
                            this.props.setPassword("type", "text");
                            this.props.setPassword("display", true);
                          }}
                        />
                      ) : (
                        <img
                          className=""
                          src="/assets/images/visibility-on.svg"
                          alt="icon"
                          onClick={(e) => {
                            this.props.setPassword("type", "password");
                            this.props.setPassword("display", false);
                          }}
                        />
                      )}
                    </a>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group pass-visible">
                    <label>Confirm Password</label>
                    <input
                      className="form-control"
                      type={this.props.type_conf}
                      name
                      placeholder
                      onChange={(e) => {
                        this.props.setPassword("password_conf", e.target.value);
                      }}
                    />
                    <a href="javascript:;" className="visibility-icon">
                      {this.props.display_conf == false ? (
                        <img
                          className="off"
                          src="/assets/images/visibility-off.svg"
                          alt="icon"
                          onClick={(e) => {
                            this.props.setPassword("type_conf", "text");
                            this.props.setPassword("display_conf", true);
                          }}
                        />
                      ) : (
                        <img
                          className=""
                          src="/assets/images/visibility-on.svg"
                          alt="icon"
                          onClick={(e) => {
                            this.props.setPassword("type_conf", "password");
                            this.props.setPassword("display_conf", false);
                          }}
                        />
                      )}
                    </a>
                    {(() => {
                      // console.log(this.props.number_check, 'this.props.number_check')
                      // console.log(this.props.string_check, 'this.props.string_check')
                      // console.log(this.props.length_check, 'this.props.length_check')
                      if (this.props.same_check == true) {
                        return (
                          
                          <small className="text-danger">
                              *Both field must be same.
                          </small>
                          
                        );
                      } else if (this.props.empty_check == true) {
                        return (
                          
                          <small className="text-danger">
                              *Please fill both fields.
                            </small>
                          
                        );
                      } else if (this.props.number_check) {
                        return (
                          
                          <small className="text-danger">
                              *Both fields must contain numbers.
                            </small>
                          
                        );
                      } else if (this.props.string_check) {
                        return (
                          
                          <small className="text-danger">
                              *Both fields must contain letters.
                            </small>
                          
                        );
                      } else if (this.props.length_check) {
                        return (
                          
                          <small className="text-danger">
                              *Both fields must be more than 8 characters.
                            </small>
                          
                        );
                      }
                    })()}
                  </div>
                </div>
                <div className="col-12 mt-2">
                  <button type="submit" className="btn btn-blue w-100">
                    Change my Password
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    password_new: state.PasswordSet.password_new,
    password_conf: state.PasswordSet.password_conf,
    display: state.PasswordSet.display,
    type: state.PasswordSet.type,
    type_conf: state.PasswordSet.type_conf,
    display_conf: state.PasswordSet.display_conf,
    same_check: state.PasswordSet.same_check,
    empty_check: state.PasswordSet.empty_check,
    show_alert:state.PasswordSet.show_alert,
    showMsg:state.PasswordSet.showMsg,
    varient:state.PasswordSet.varient,
    length_check:state.PasswordSet.length_check,
    number_check:state.PasswordSet.number_check,
    string_check:state.PasswordSet.string_check,
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setPassword: (k, v) => dispatch(setPassword(k, v)),
    sendResetPassword: (val) => dispatch(sendResetPassword(val)),
  };
};

const reset = connect(mapStateToProps, mapDispatchToProps)(Reset);

export default reset;

import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { sendLogin, sendData } from "../../actions/login";
import Alert from "react-bootstrap/Alert";
import NotifyModel from "../NotifyEmployer"
class Login extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    // require("../../assets/css/custom-style.css");
    let removingElament = document.getElementById("design_app_style");
        
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
  }

  validation() {
    if (!this.props.user_name == "") {
      
      if (!this.validateEmail(this.props.user_name)) {
        this.props.sendLogin("valid_email", true);
        
      } else {
        let v = {
          username: this.props.user_name,
          password: this.props.password,
        };
        this.props.sendData(v)
      }
    }
  }

  validateEmail(email) {
    const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return expression.test(String(email).toLowerCase());
  }
  
  render() {
    return (
      <Fragment>
        <div className="container-fluid main-wrap">
          <div className="row">
            <div className="col-md-6 signup-lft signup-hire-bg"></div>
            <div className="col-md-6 signup-rgt">
            {
            <Alert
              show={this.props.show_alert}
              variant={this.props.varient}
              dismissible
              onClose={() => this.props.sendLogin('show_alert', false)}
            >
              <strong>
                {this.props.varient === "success"
                  ? "Success!"
                  : "Error!"}
              </strong>{" "}
              {this.props.showMsg}
            </Alert>}
           
              <h3>Sign in</h3>
              <form className="tab-form row">
                <div className="col-12">
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      className="form-control"
                      type="text"
                      name
                      autocomplete="off"
                      placeholder="Your Email"
                      onChange={(e) => {
                        
                        this.props.sendLogin("user_name", e.target.value);
                        this.props.sendLogin("user_fill", false);
                      }}
                    />
                    {this.props.user_fill == true ? (
                      <div style={{ float: "left" }}>
                        <small style={{ color: "red" }}>
                          *Please fill out Email.
                        </small>
                      </div>
                    ) : this.props.valid_email === true ? (
                      
                      <div style={{ float: "left" }}>
                        <small style={{ color: "red" }}>
                          *Please Enter a valid Email.
                        </small>
                      </div>
                    ) : ""}
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <label>Password</label>
                    <input
                      className="form-control"
                      type="password"
                      name
                      placeholder="Your Password"
                      onChange={(e) => {
                        this.props.sendLogin("password", e.target.value);
                        this.props.sendLogin("pass_fill", false);
                      }}
                    />
                    {this.props.pass_fill == true ? (
                      <div style={{ float: "left" }}>
                        <small style={{ color: "red" }}>
                          *Please fill out password.
                        </small>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                </div>
                <div className="col-12 mt-2">
                  <button
                  disabled = {this.props.loading ? true:false}
                    className="btn btn-blue w-100"
                    onClick={(e) => {
                      e.preventDefault();
                      if (
                        this.props.user_name !== "" &&
                        this.props.password !== ""
                      ) {
                        this.validation(e);
                      } else {
                        if (this.props.user_name == "") {
                          this.props.sendLogin("user_fill", true);
                        }
                        if (this.props.password == "") {
                          this.props.sendLogin("pass_fill", true);
                        }
                      }
                    }}
                  >
                    {this.props.loading ? 'Loading...':'Sign in'}
                  </button>
                </div>
              </form>
              <div className="row">
                <div className="col-12 signup-btm-p mt-4">
                <p className = "d-none">
                    Please verify your account here <a href="/employer/account_verification">Verify here</a>
                  </p>
                  <p>
                    Don’t have an Account? <a href="/signup_hire">Sign up</a>
                  </p>
                  
                  <p>
                    <Link
                      className="forgot-pass"
                      to="/employer/forgot_password"
                    >
                      Forgot Your Password?
                    </Link>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
        <NotifyModel/>
      </Fragment>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    user_fill: state.Login.user_fill,
    pass_fill: state.Login.pass_fill,
    user_name: state.Login.user_name,
    password: state.Login.password,
    loading:state.signupWork.loading,
    show_alert:state.Login.show_alert,
    showMsg:state.Login.showMsg,
    varient:state.Login.varient,
    valid_email: state.Login.valid_email
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    sendLogin: (k, v) => dispatch(sendLogin(k, v)),
    sendData: (v) => dispatch(sendData(v)),
  };
};

const log = connect(mapStateToProps, mapDispatchToProps)(Login);

export default log;

import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import Countdown, { zeroPad } from "react-countdown";
import config from "../../actions/Common/Api_Links";
import $ from "jquery";
import history from "../../stores/history";
import Alert from "react-bootstrap/Alert";
class verification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      input1: "",
      input2: "",
      input3: "",
      input4: "",
      input5: "",
      input6: "",
      show: false,
      variant:"",
      showMsg:"",
      status:0,
      timerState: Date.now() + 120000,
      loading: false,
    };
  }

  componentDidMount() {
    $(function () {
      var charLimit = 1;
      $(".form-control")
        .keydown(function (e) {
          var keys = [
            8,
            9,
            17,
            19,
            20,
            27,
            33,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            45,
            46,
            86,
            144,
            145,
          ];

          if (e.which == 8 && this.value.length == 0) {
            if ($(this).prev(".form-control").focus().length !== 0) {
              $(this).prev(".form-control").focus();
            } else {
              $(".prev_otp").focus();
            }
          } else if ($.inArray(e.which, keys) >= 0) {
            return true;
          } else if (this.value.length >= charLimit) {
            $(this).next(".form-control").focus();
            return false;
          } else if (e.shiftKey || e.which < 48 || e.which > 58) {
            return false;
          }
        })
        .keyup(function () {
          if (this.value.length >= charLimit) {
            if ($(this).next(".form-control").focus().length !== 0) {
              $(this).next(".form-control").focus();
            } else {
              $(".next_otp").focus();
            }

            return false;
          }
        });
    });

    // require("../../assets/css/custom-style.css");
    let removingElament = document.getElementById("design_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
      removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "custom_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
  }
  componentDidUpdate() {
    let THIS = this        
        if (this.state.status === 1 || this.state.status ===2) {
            setTimeout(function() {
                THIS.setState({
                  show : false
                })
            }, 2000)
        }
  }

  sendVefication() {
    this.setState({
      loading: true,
    });
    let formData = new URLSearchParams(); //formdata object
    let emp_id = localStorage.work_employee_id ? localStorage.getItem("work_employee_id") : "";
    console.log(this.state, "state values ...............");
    let otp =
      this.state.input1 +
      this.state.input2 +
      this.state.input3 +
      this.state.input4 +
      this.state.input5 +
      this.state.input6;

    formData.append("verification_code", otp);
    if (localStorage.user && localStorage.getItem("user") === "employee") {
      formData.append("employee_id", emp_id);
      fetch(config.signUpEmpVerify, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status === 200) {
            history.push("/verification_wait_page");
          } else {
            this.setState({
              loading: false,
              show: true,
              variant:"danger",
              showMsg:data.message,
              status:2,
            });
          }
        });
    } else {
      formData.append("employer_id", localStorage.getItem("hire_emp_id"));
      fetch(config.signUpEmployerVerify, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status === 200) {
            history.push("/verification_wait_page");
          } else {
            this.setState({
              loading: false,
              show: true,
              variant:"danger",
              showMsg:data.message,
              status:2,
            });
          }
        });
    }
  }

  keyPasteHandler(e) {

    if(e && e.clipboardData){
      const otp = e.clipboardData.getData('text').split("");
          this.setState({
          input1:otp[0],
          input2:otp[1],
          input3:otp[2],
          input4:otp[3],
          input5:otp[4],
          input6:otp[5],
          });
    }
    
  }

   async pasteHandler(e){
     
    const otp = e.clipboardData.getData('text').split("");
    this.setState({
     input1:otp[0],
     input2:otp[1],
     input3:otp[2],
     input4:otp[3],
     input5:otp[4],
     input6:otp[5],
    }, async() => {
      await this.sendVefication();
    });
   
  }

  inputChange(field, value) {
    this.setState({
      ...this.state,
      [field]: value,
    });
  }

  ResendVefication() {
    this.setState({
      loading: true,
      input1: "",
      input2: "",
      input3: "",
      input4: "",
      input5: "",
      input6: "",
      timerState: Date.now() + 120000,
    });
    
    let formData = new URLSearchParams(); //formdata object
    let emp_id = localStorage.work_employee_id ? localStorage.getItem("work_employee_id") : "";

    if (localStorage.user && localStorage.getItem("user") === "employee") {
      formData.append("employee_id", emp_id);
      fetch(config.signUpEmpResendOtp, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
      })
        .then((response) => response.json())
        .then((data) => {
         if (data.status === 1) {
          this.setState({
            timerState: new Date() + 120000,
            loading: false,
            show: true,
            variant:"success",
            showMsg:`Verification code sent to ${localStorage.getItem('work_emp_email_id')}`,
            status:1,
          }); 
         } else {
          this.setState({
            timerState: new Date() + 120000,
            loading: false,
            show: true,
            variant:"danger",
            showMsg:data.message,
            status:2,
          }); 
         }
        });
    } else {
      formData.append("employer_id", localStorage.getItem('hire_emp_id'));
      fetch(config.signUpEmployerResendOtp, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          // console.log(data, "verificationdata");
          if (data.status === 1) {
            this.setState({
              timerState: new Date() + 120000,
              loading: false,
              show: true,
              variant:'success',
              showMsg:`Verification code sent to ${localStorage.getItem('hire_email_id')}`,
              status:1,
            }); 
           } else {
            this.setState({
              timerState: new Date() + 120000,
              loading: false,
              show: true,
              variant:'danger',
              showMsg:data.message,
              status:2,
            }); 
           }
        });
    }
  }

  render() {
    // const
    const Completionist = () => <span>Please resend again!</span>;

    const renderer = ({ minutes, seconds, completed }) => {
      if (completed) {
        // Render a completed state
        return <Completionist />;
      } else {
        // Render a countdown
        return (
          <span>
            {zeroPad(minutes)}:{zeroPad(seconds)}
          </span>
        );
      }
    };
    return (
      <div className="container-fluid main-wrap">
        <div className="row">
          <div className="col-md-6 signup-lft" />
          <div className="col-md-6 signup-rgt verification">
              {
                // console.log(this.state.variant, 'this.state.variant'),
                <Alert
                  show={this.state.show}
                  variant={this.state.variant}
                  dismissible
                  onClose={() => this.setState({
                    show:false
                  })}
                >
                  <strong>
                    {this.state.status === 1
                      ? "Success!"
                      : "Error!"}
                  </strong>{" "}
                  {this.state.showMsg}
                </Alert>
              }
            <h3>Check Your Email</h3>
            <p>
              We have sent a verification code to{" "}
              {localStorage.user && localStorage.getItem("user") === "employee"
              
              ?
              localStorage.getItem("work_emp_email_id") : localStorage.getItem("hire_email_id")
              }.
            </p>
            <div className="otp-wrap">
              {/* <OtpInput
            className
            // value={this.state.otp}
            // className="form-control"
            // onChange={this.handleChange}
            numInputs={6}
            separator={<span>-</span>}
            /> */}
              <input
                type="text"
                name
                value={this.state.input1}
                onChange={(e) => this.inputChange("input1", e.target.value)}
                className="form-control"
                maxlength="1"
                onPaste={async (e) => await this.pasteHandler(e)}
                onKeyPress={this.keyPasteHandler}
              />
              <input
                type="text"
                name
                value={this.state.input2}
                onChange={(e) => this.inputChange("input2", e.target.value)}
                className="form-control"
                maxlength="1"
                onPaste={async (e) => await this.pasteHandler(e)}
                onKeyPress={this.keyPasteHandler}
              />
              <input
                type="text"
                name
                value={this.state.input3}
                maxlength="1"
                onChange={(e) => this.inputChange("input3", e.target.value)}
                className="form-control prev_otp"
                onPaste={async (e) => await this.pasteHandler(e)}
                onKeyPress={this.keyPasteHandler}
              />
              <span className="seperator">-</span>
              <input
                type="text"
                name
                value={this.state.input4}
                maxlength="1"
                onChange={(e) => this.inputChange("input4", e.target.value)}
                className="form-control next_otp"
                onPaste={async (e) => await this.pasteHandler(e)}
                onKeyPress={this.keyPasteHandler}
              />
              <input
                type="text"
                name
                value={this.state.input5}
                maxlength="1"
                onChange={(e) => this.inputChange("input5", e.target.value)}
                className="form-control"
                onPaste={async (e) => await this.pasteHandler(e)}
                onKeyPress={this.keyPasteHandler}
              />
              <input
                type="text"
                name
                value={this.state.input6}
                maxlength="1"
                onChange={async (e) => {
                  await this.inputChange("input6", e.target.value);
                  await this.sendVefication();
                }}
                // onClick = {}
                className="form-control"
                onPaste={async (e) => await this.pasteHandler(e)}
                onKeyPress={this.keyPasteHandler}
              />
            </div>

            <p>
              Can't find our email? Check your spam folder or
              <a
                href="javascript:;"
                onClick={this.ResendVefication.bind(this)}
                // disabled ={!this.state.loading? false:true}
              >
                {" "}
                {!this.state.loading ? "Resend" : "Loading"}
              </a>
            </p>
            {/* <p>
              Is {localStorage.email_id ? localStorage.getItem("email_id") : ""}{" "}
              the wrong address? <a href="javascript:;">Change email address</a>
            </p> */}
            <p className="timer">
              <img
                src={process.env.PUBLIC_URL + "/assets/images/timer-icon.svg"}
                alt="icon"
              />
              {/* 02:00 */}
              <Countdown date={Date.now() + 120000} renderer={renderer} />
            </p>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {};
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {};
};

const log = connect(mapStateToProps, mapDispatchToProps)(verification);

export default log;

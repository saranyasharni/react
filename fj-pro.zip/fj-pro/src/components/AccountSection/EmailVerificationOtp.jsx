import React, { Component, Fragment } from "react";
// import { Link } from "react-router-dom";
import config from "../../actions/Common/Api_Links";
import Alert from "react-bootstrap/Alert";
import history from "../../stores/history";

export default class Forgot extends Component {
    constructor(props) {
    super(props);
        this.state = {
        user_name: "",
        fill_name: false,
        varient:'',
        show_alert:false,
        showMsg:'',
        };
    }
  
    componentDidMount() {
    let removingElament = document.getElementById("design_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
    }

    sendNew = () => {
        if (this.state.user_name !== "") {
            let url;
            if (window.location.pathname == "/employee/account_verification") {
                localStorage.removeItem('hire_email_id')
                localStorage.removeItem('hire_emp_id')
                url = config.find_by_employee;
            } else {
                localStorage.removeItem('work_emp_email_id')
                localStorage.removeItem('work_employee_id')
                url = config.find_by_employer;
            }
            fetch(url, {
                method: "post",
                headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                },
                body: JSON.stringify({
                email: this.state.user_name,
                }),
            })
            .then((response) => response.json())
            .then((response) => {
            if (response.status === 1) {
                // this.setState({show_alert:true,showMsg:"OTP sent your Email",varient:"success"})
                if (window.location.pathname === "/employee/account_verification") {
                    localStorage.setItem('work_emp_email_id', this.state.user_name) 
                    localStorage.setItem('work_employee_id', response.data.employee_id) 
                    localStorage.setItem('user', 'employee') 
                    history.push('/verify')
                } else {
                    localStorage.setItem('hire_email_id', this.state.user_name) 
                    localStorage.setItem('hire_emp_id', response.data.employer_id) 
                    localStorage.setItem('user', 'employer') 
                    history.push('/verify')
                }
                
            } else {
                this.setState({show_alert:true,showMsg:response.message,varient:"danger"})
            }
            })
            .catch((e) => {
                console.log(e);
            });
        } else {
        this.setState({ fill_name: true });
        }
    };

  render() {
    return (
      <Fragment>
        <div className="container-fluid main-wrap">
          <div className="row">
            {window.location.pathname == "/employee/forgot_password" ? (
              <div className="col-md-6 signup-lft" />
            ) : (
              <div className="col-md-6 signup-lft signup-hire-bg" />
            )}
            <div className="col-md-6 signup-rgt">
            {
            <Alert
              show={this.state.show_alert}
              variant={this.state.varient}
              dismissible
              onClose={()=>this.setState({show_alert: false})}
            >
              <strong>
                {this.state.varient == "success"
                  ? "Success!"
                  : "Error!"}
              </strong>{" "}
              {this.state.showMsg}
            </Alert>}
              <h3> Verify Your New Account</h3>
              <form className="tab-form row">
                <div className="col-12">
                  <div className="form-group">
                    <label>Please Enter Your Registered Mail Id </label>
                    <input
                      className="form-control"
                      type="text"
                      name
                      placeholder="kathy.hudson@mail.com"
                      onChange={(e) =>
                        this.setState({
                          user_name: e.target.value,
                          fill_name: false,
                        })
                      }
                    />
                    {this.state.fill_name == true ? (
                      <div style={{ float: "left" }}>
                        <small style={{ color: "red" }}>
                          *Please fill out this field.
                        </small>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                </div>
              </form>
              <div className="row">
                <div className="col-12 btn-btm-wrap forgot">
                  {/* <Link to="/login_hire">
                    <button className="btn btn-gray">Login</button>
                  </Link> */}
                  <button className="btn btn-blue" onClick={this.sendNew}>
                    Send OTP
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

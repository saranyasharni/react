import React, { Component, Fragment } from "react";
import { Link } from "react-router-dom";
import config from "../../actions/Common/Api_Links";
import Alert from "react-bootstrap/Alert";

export default class Forgot extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user_name: "",
      fill_name: false,
      varient:'',
      show_alert:false,
      showMsg:'',
    };
  }
  
  componentDidMount() {
    let removingElament = document.getElementById("design_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
  }
  sendNew = () => {
    if (this.state.user_name !== "") {
      let url;
      if (window.location.pathname == "/employee/forgot_password") {
        url = config.forgotPasswordEmployee;
      } else {
        url = config.forgotPasswordEmployer;
      }
      fetch(url, {
        method: "post",
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body: JSON.stringify({
          email: this.state.user_name,
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            this.setState({show_alert:true,showMsg:"Password sent to your Email",varient:"success"})
          } else {
            this.setState({show_alert:true,showMsg:response.message,varient:"danger"})
          }
        })
        .catch((e) => {
          console.log(e);
        });
    } else {
      this.setState({ fill_name: true });
    }
  };

  render() {
    return (
      <Fragment>
        <div className="container-fluid main-wrap">
          <div className="row">
            {window.location.pathname == "/employee/forgot_password" ? (
              <div className="col-md-6 signup-lft" />
            ) : (
              <div className="col-md-6 signup-lft signup-hire-bg" />
            )}
            <div className="col-md-6 signup-rgt">
            {
            <Alert
              show={this.state.show_alert}
              variant={this.state.varient}
              dismissible
              onClose={()=>this.setState({show_alert: false})}
            >
              <strong>
                {this.state.varient == "success"
                  ? "Success!"
                  : "Error!"}
              </strong>{" "}
              {this.state.showMsg}
            </Alert>}
              <h3>Forgot Your Password?</h3>
              <form className="tab-form row">
                <div className="col-12">
                  <div className="form-group">
                    <label>Enter Email Address</label>
                    <input
                      className="form-control"
                      type="text"
                      name
                      placeholder="kathy.hudson@mail.com"
                      onChange={(e) =>
                        this.setState({
                          user_name: e.target.value,
                          fill_name: false,
                        })
                      }
                    />
                    {this.state.fill_name == true ? (
                      <div style={{ float: "left" }}>
                        <small style={{ color: "red" }}>
                          *Please fill out this field.
                        </small>
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                </div>
              </form>
              <div className="row">
                <div className="col-12 btn-btm-wrap forgot">
                  {/* <Link to="/login_hire">
                    <button className="btn btn-gray">Login</button>
                  </Link> */}
                  <button className="btn btn-blue" onClick={this.sendNew}>
                    Send Request
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

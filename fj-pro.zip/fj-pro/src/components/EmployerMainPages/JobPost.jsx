import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import $ from 'jquery';
import { Link } from "react-router-dom";
import Header from "../Employer/header";


class JobPost extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        
        return (
        <>
        <div className="container-fluid">
        {/* {console.log(profileInfo, 'opopopop')} */}
        <Header />
            <section className="row main-content">
            <div className="container">
                <div className="nodata-wrap">
                <img className="no-data-img" src="/assets/images/app/undraw-publish.svg" alt="image" />
                <p>No Jobs Posted</p>
                <Link to = {`/create/job-post`}
                className="btn btn-blue" href="hire-create-post-job.html">+ Create a Job</Link> 
                </div>
            </div>
            </section>
            </div>
            </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    
    return {
        
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
    }
};

const jobpost = connect(
    mapStateToProps,
    mapDispatchToProps,
)(JobPost);

export default jobpost;





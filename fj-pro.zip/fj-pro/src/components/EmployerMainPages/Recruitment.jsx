import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import Header from "../Employer/header";
import Search from "../Employer/Hire/StaffSearch";
import SearchEmployee from "../Employer/Hire/SearchEmployee";
import ShortList from '../Employer/Hire/ShortList';
import * as actions from '../../actions/Employer/Hire';
import Loader from '../Helper/Loader';
import Alert from "react-bootstrap/Alert";

class Recruitment extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        let employer_id = localStorage.getItem('emp_id')
        this.props.getAllEmployees({
            employer_id:employer_id,
            filter:0,
            position:null,
            location:null,
           
        })
        // this.props.getAllUnappliedEmployees({
        //     employer_id:employer_id,
        //     filter:0,
        //     position:null,
        //     location:null
        // })
        this.props.getShortListedEmployees(employer_id)
    }

    render() {
        var emp_id = localStorage.emp_id ? localStorage.getItem('emp_id') :''
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col mb-0 mb-md-4">
                    <ul className="nav nav-tabs">
                    <li>
                        <a className="active px-4" data-toggle="tab" href="#hire">
                            Scheduled Candidates
                        </a>
                    </li>
                    <li>
                        <a 
                        className="px-4" 
                        data-toggle="tab" 
                        href="#shortlist"
                        // onClick = {() => {this.props.getShortListedEmployees(1)}}
                        >
                            Selected Candidates
                        </a>
                    </li>
                    <li>
                        <a 
                        className="px-4" 
                        data-toggle="tab" 
                        href="#search_new_emp"
                        // onClick = {() => {this.props.getShortListedEmployees(1)}}
                        >
                            Rejected Candidates
                        </a>
                    </li>
                    </ul>
                </div>
                <div className="col-12">
                    <div className="tab-content">
                    {
                        <Alert
                        show={this.props.show}
                        variant={this.props.varient}
                        dismissible
                        onClose={() => this.props.setShow(false)}
                        >
                        <strong>
                            {
                            this.props.hire_status === 1 ? "Success!" 
                            : this.props.hire_status === 3 ? "Info!"
                            :"Error!"
                            }
                        </strong>{" "}
                        {this.props.showMsg}
                        </Alert>
                    }
                    <div id="hire" className="col-12 tab-pane fade in show active">
                        <div className="row column-3-8">
                        <Search
                        status = "1"
                        />
                        <div className="chat-right bg-remove">
                        <div className="row">
                        {
                            !this.props.loading ? 
                            (
                                <>
                                {
                                this.props.employeeLists 
                                && this.props.employeeLists.length > 0 ? this.props.employeeLists.map((i,k) => {
                                // let employee_id = i.employee[0].id ? 
                                // i.employee[0].id : ''
                                // console.log(i.employee, 'i.job_locations')
                                return (
                                    <>
                                    <div className="col-md-6 col-lg-6 col-xl-4" 
                                    key ={k}
                                    >
                                    <div className="job-snippet profile-snippet">
                                    <div className="img-wrap">
                                        <img className="img-fluid" 
                                        src={!i.employee.profile_url ? "/assets/images/app/avatar-thumb-1.jpg" :i.employee.profile_url
                                            } 
                                        // alt="img" 
                                        // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                                        />
                                        <a href="javascript:;" className={`favorite ${i.bookmarked  === '1' ? 'saved':''}`}
                                        onClick = {(e) => {
                                            this.props.bookMark({
                                                'application_id':i.id,
                                                'bookmarked':i.bookmarked === '1' ? '0':'1',
                                                'api_call':1
                                            })
                                        }}
                                        >
                                        <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                                        </a>
                                    </div>
                                    <div className="r-job-item">
                                    <div className="dropdown more">
                                    <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <img src="/assets/images/app/more-btn.svg" />
                                    </button>
                                    <div className="dropdown-menu" aria-labelledby="more-menu">
                                        <ul className="list-unstyled">
                                        <li><Link to = {`view-profile/${i.id}/${i.employee.id}`}>View Profile</Link></li>
                                        <li>
                                        {/* <a href="javascript:;"
                                        onClick = {(e) => {
                                            this.props.shortListEmployee({
                                                employee_id:i.employee.id,
                                                job_id:i.job.id,
                                                application_id:i.id
                                            })
                                        }}
                                        >Shortlist
                                        </a> */}
                                        </li>
                                        <li>
                                        <a href="javascript:;" className="red"
                                        onClick = {(e) => {
                                            this.props.declineEmployee({
                                                id : i.id
                                            })
                                        }}
                                        >
                                        Reject
                                        </a>
                                        </li>
                                        </ul>
                                    </div>
                                    </div>
                                    <h6>{i.employee.name}</h6>
                                    <span className="job-type text-truncate">
                                        {i.job.job_type} | {i.job.job_position}
                                    </span>
                                    <span className="location text-truncate d-block">
                                    <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                    {i.job.job_location}
                                    </span>
                                    <button className="btn btn-blue" data-toggle="modal" 
                                    onClick = {() => {this.props.hireEmployee({
                                        employee_id:i.employee.id,
                                        job_id:i.job.id
                                    })}}
                                    // data-target="#rehire-modal"
                                    >
                                        Shortlist candidate
                                    </button>
                                    </div>
                                    </div>
                                    </div>
                                    </>
                                    )
                                }) 
                                : (
                                <>
                                <div className="empty-job">
                                <img src="assets/images/app/undraw-empty.svg" alt="image"/>
                                <p>There's nothing here.</p>
                                </div>
                                </>
                                )
                                }
                                    </>
                                ): 
                                (
                                    <>
                                    <div className="empty-job">
                                        <Loader />
                                        {/* <img src="/assets/images/loader.gif" alt="icon" /> */}
                                        
                                    </div>
                                    </>
                                )
                                
                            }
                            </div>
                        </div>
                        </div>
                    </div>
                    <div id="shortlist" className="col-12 tab-pane fade">
                    <ShortList/>
                    </div>
                    <div id="search_new_emp" className="col-12 tab-pane fade">
                    <SearchEmployee/>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>
            {/* Main Content Ends here */}
            {/* Main Wrapper Ends here */}
            </>            
            </div>
            
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {   
    return {
        employeeLists:state.Hire.employeeLists,
        loading:state.Hire.loading,
        show:state.Hire.show,
        varient:state.Hire.varient,
        showMsg:state.Hire.showMsg,
        hire_status:state.Hire.hire_status
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getAllEmployees: (data) => dispatch(actions.getAllEmployees(data)),
        getAllUnappliedEmployees: (data) => dispatch(actions.getAllUnappliedEmployees(data)),
        getShortListedEmployees : (data) => dispatch(actions.getShortlistedEmployees(data)),
        shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        setShow: (data) => dispatch(actions.setShow(data)),
        declineEmployee: (data) => dispatch(actions.declineEmployee(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        bookMark:(data) => dispatch(actions.bookMark(data))
    }
};

const recruitment = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Recruitment);

export default recruitment;
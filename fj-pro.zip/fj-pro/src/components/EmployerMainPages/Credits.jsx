import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import Header from "../Employer/header";
import $, { data } from "jquery"
import * as actions from "../../actions/Transactions"
import {getCreditAmount} from '../../actions/Employer/Hire'
import moment from 'moment';
import history from '../../stores/history'
import Alert from "react-bootstrap/Alert";

class Credits extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    componentDidMount() {
        this.props.getEmployerCredits()
        this.props.getCreditAmount()
        let THIS = this
        $(document).ready(function(){

            let removingElament = document.getElementById("custom_app_style");

            if (removingElament !== null) {
                removingElament.remove()
            }
            const elem2 = document.createElement("link");
            elem2.rel = "stylesheet"
            elem2.type = "text/css"
            elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";

            elem2.id = "design_app_style"
            elem2.async = true;
       
    });
    }

    componentDidUpdate() {
        let THIS = this        
        if (this.props.status === 1 || this.props.status ===2) {
            setTimeout(function() {
                THIS.props.setShow(false)
            }, 2000)
        }
    }
    
    render() {
        
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col">
                    <h1>
                    <a href="javascript:;" className="back"
                    onClick = {() => {history.goBack()}}
                    >
                        <img src="/assets/images/app/back-arrow.svg" alt="icon" />
                    </a>
                    Credits
                    </h1>
                    <div>
                    <p className="cl-notify">
                        RM{
                        new Intl.NumberFormat('en-US', 
                        {style: 'decimal', minimumFractionDigits: 2}).
                        format(isNaN(this.props.walletAmount)
                        ? '0.00':this.props.walletAmount)
                        }</p>
                    </div>
                </div>
                <div className="col-12">
                    <div className="snippet-box p-3 p-md-5 notifi-encl">
                    <div className="row">
                        {/* <p className="day"><span>Today</span></p> */}
                        {this.props.creditList &&
                        this.props.creditList.length > 0 &&
                        this.props.creditList.map((i,k) => {
                            return (
                                <div className="col-12 my-2" key = {k}
                             
                                >
                                <div className={i.status === "unread" ? 
                                "notify-item" : "notify-item read"
                                }
                                >
                                    <div className="icon-wrap">
                                    <img className="img-fluid card-icon" 
                                    src={process.env.PUBLIC_URL+"/assets/images/app/wallet.png"} alt="icon" 
                                    />
                                    </div>
                                    <div className="n-cont">
                                    <p className="title text-capitalize">
                                        {i.message}
                                    </p>
                                    {/* <p className = "">
                                        {i.message}
                                    </p> */}
                                    <p className = "">
                                        {i.action}
                                    </p>
                                    
                                    <span className = {i.status === 'paid'?"show-color-red":"show-color-amount"}>
                                    <i className={i.status === 'paid'?"fa fa-minus":"fa fa-plus"} aria-hidden="true"></i> {" "}
                                        RM{new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.amount)
                                        ? '0.00':i.amount)}
                                    </span>
                                    </div>
                                </div>
                                </div>
                            )
                        })
                        }      
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>

            {/* Main Wrapper Ends here */}
            </>            
            </div>           
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        creditList :state.Transactions.creditList,
        walletAmount : state.Hire.walletAmount,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getCreditAmount: () => dispatch(getCreditAmount()),
        getEmployerCredits : (data) => dispatch(actions.CreditLists(data)),        
    }
};

const credits = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Credits);

export default credits;

import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
// import $, { data } from 'jquery';
import { Link } from "react-router-dom";
import Header from "../Employer/header";
import HiredSearch from '../Employer/Hire/SearchSection/HiredSeach'
// import Search from "../Employer/Hire/StaffSearch";
import SearchEmployee from "../Employer/Hire/SearchEmployee";
import SearchEmployeeSearch from '../Employer/Hire/SearchSection/ShortlistSearch'
import SearchListView from "../Employer/Hire/ListView/SearchEmployeeList";
import ApplicantsListView from "../Employer/Hire/ListView/Applicants";
import ShortListedListView from "../Employer/Hire/ListView/Shortlised";
import SchedulesListView from "../Employer/Hire/ListView/ScheduledList";
import HiredListView from "../Employer/Hire/ListView/Hired";
import RejectedListView from "../Employer/Hire/ListView/Rejected";
import ShortList from '../Employer/Hire/ShortList';
import Shedules from '../Employer/Hire/SheduledCandidates';
import Hired from "../Employer/Hire/HiredCandidates";
import Rejected from "../Employer/Hire/RejectedCandidates";
import * as actions from '../../actions/Employer/Hire';
import Loader from '../Helper/Loader';
import Alert from "react-bootstrap/Alert";
import history from '../../stores/history';
import Notify from "../NotifyEmployer"
import {getselectedIndustries,getSkills} from "../../actions/Home";
import ShortListModel from '../Employer/Hire/ShortListModel';

class Hire extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getselectedIndustries()
        this.props.getSkills()
        let employer_id = localStorage.getItem('emp_id')
        this.props.getAllEmployees({
            employer_id:employer_id,
            filter:0,
            position:null,
            location:null,
            experience:null,
            industry_type : null,
            page_no:0,
            limit:32
        })

        this.props.getAllUnappliedEmployees({
            employer_id:employer_id,
            filter:0,
            position:null,
            location:null,
            search_term : null,
            industry_type : null,
            experience:null,
            lat:'11.0176',
            lon:'76.9674',
            page_no:0,
            limit:16
        }, false)

        this.props.getScheduledCandidates({
            employer_id:employer_id,
            status_code : 8,
            filter:0,
            industry_type:null,
            job_position:null,
            page_no:0,
            limit:32
        })

        this.props.getRejectedCandidates({
            employer_id:employer_id,
            status_code:9,
            filter:0,
            industry_type:null,
            job_position:null,
            page_no:0,
            limit:32
        })

        this.props.getHiredCandidates({
            employer_id:employer_id,
            status_code : "3",
            filter:0,
            industry_type:null,
            job_position:null,
            page_no:0,
            limit:32
        })

        this.props.getShortListedEmployees({
            employer_id:employer_id,
            filter:"0",
            industry_type :'null' ,
            job_position : 'null',
            page_no:"0",
            limit : "32",
            status_code : "8"
        })

        this.props.getAllPositions({
            industry_type:"F&B"
        })

        // console.log(window.location.pathname.split('/')[1])
        
    }
    
    componentDidUpdate(){
        let THIS = this
        // if (this.props.hire_status === 1 
        //     || this.props.hire_status === 2 ||
        //     this.props.hire_status ===3
        //     ) {
        //     setTimeout(function() {
        //         THIS.props.setSuccess(0,"")
        //         THIS.props.setShow(false)
        //     },3000)
            
        // }
        // console.log(window.$('.nav-tabs a[href="#hire"]'));
       
    }

    componentWillUnmount() {

        if (this.props.hire_status === 1 
            || this.props.hire_status === 2 ||
            this.props.hire_status ===3
            ) {
            // setTimeout(function() {
                this.props.setSuccess(0,"")
                this.props.setShow(false)
            // }, 3000)
        }
    }
    
    render() {
        var emp_id = localStorage.emp_id ? localStorage.getItem('emp_id') :''
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col mb-0 mb-md-4 px-4">
                    <ul className="nav nav-tabs">
                    <li>
                        <a className={`px-3 ${(window.location.pathname.split('/').length === 2) && (window.location.pathname.split('/')[1] === 'hire-staff') ? 'active': ''}`} data-toggle="tab" 
                        href = "#search_new_emp"
                        // href="#hire"
                        >
                            Search employees 
                        </a>
                    </li>
                    
                    <li>
                        <a 
                            className={`px-3 ${(window.location.pathname.split('/').length === 3) && (window.location.pathname.split('/')[2] === 'applicants') ? 'active': ''}`}
                            data-toggle="tab" 
                            // href="#search_new_emp"
                            href="#hire"
                            onClick = {() => {this.props.setSearchApiCall(1)}}
                        >
                            Applicants
                        </a>
                    </li>

                    <li>
                        <a 
                        className={`px-3 ${window.location.pathname.split('/').length && (window.location.pathname.split('/')[2] === 'shortlisted') ? 'active': ''}`}
                        data-toggle="tab" 
                        href="#shortlist"
                        id = "tab-two"
                        onClick = {() => {this.props.setSearchApiCall(2)}}
                        >
                            Shortlisted
                        </a>
                    </li>
                    <li>
                        <a className="px-3" data-toggle="tab" href="#schedules"
                        onClick = {() => {this.props.setSearchApiCall(3)}}
                        >
                            Scheduled Interviews
                        </a>
                    </li>
                    <li>
                        <a className={`px-3 ${(window.location.pathname.split('/').length === 3) && (window.location.pathname.split('/')[2] === 'offered') ? 'active': ''}`} data-toggle="tab" href="#Hired_list"
                         onClick = {() => {this.props.setSearchApiCall(4)}}
                        >
                            Hired
                        </a>
                    </li>
                    <li>
                        <a className="px-3" data-toggle="tab" href="#Rejected"
                        onClick = {() => {this.props.setSearchApiCall(5)}}
                        >
                            Rejected
                        </a>
                    </li>
                    </ul>
                    <div className="btn-set mr-0">
                        <a className={!this.props.viewType ? 'active' : ''} href="javascript:;"
                        onClick = {() => {
                            this.props.showView(false)
                        }}
                        >
                            <img src="/assets/images/app/grid-icon.svg" alt="icon" />
                        </a>
                        <a 
                        className={this.props.viewType ? 'active' : ''} 
                        href="javascript:;"
                        onClick = {() => {
                            this.props.showView(true)
                        }}
                        >
                            <img src="/assets/images/app/list-icon.svg" alt="icon" />
                        </a>
                    </div>
                </div>
                <div className="col-12">
                    <div className="tab-content">
                    {
                        <Alert
                        show={this.props.show}
                        variant={this.props.varient}
                        dismissible
                        onClose={() => this.props.setShow(false)}
                        >
                        <strong>
                        {
                            this.props.hire_status === 1 ? "Success!" 
                            : this.props.hire_status === 2 ? "Error!"
                            :""
                        }
                        </strong>{" "}
                        {this.props.showMsg}
                        </Alert>
                    }

                    <div id="hire" 
                    className={`col-12 tab-pane fade ${window.location.pathname.split('/')[2] === 
                    'applicants'? 'in show active':''}`}
                    >
                    <HiredSearch/>
                        <div className="row">
                            {
                            !this.props.loading ? 
                                (
                                <>
                                {!this.props.viewType ?  
                                    this.props.employeeLists 
                                    && this.props.employeeLists.length > 0 
                                    ? this.props.employeeLists.map((i,k) => {
                                    // let employee_id = i.employee[0].id ? 
                                    // i.employee[0].id : ''
                                    // console.log(i.employee, 'i.job_locations')
                                    return (
                                        <>
                                        <div className="col-md-4 col-lg-3" 
                                        key ={k}
                                        >
                                        <div className="job-snippet profile-snippet">
                                        <Link className="img-wrap"
                                        to = {`view-profile/${i.id}/${i.employee.id}/applicants`}
                                        >
                                            <img className="img-fluid" 
                                            src={!i.employee.profile_url 
                                                || i.employee.profile_url === "null"
                                                || i.employee.profile_url === null
                                                ? "/assets/images/app/avatar-thumb-1.jpg" :i.employee.profile_url
                                            } 
                                            // alt="img" 
                                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                                            />
                                            {/* <a href="javascript:;" 
                                            className={`favorite ${i.bookmarked  === '1' ? 'saved':''}`}
                                            onClick = {(e) => {
                                                this.props.bookMark({
                                                    'application_id':i.id,
                                                    'bookmarked':i.bookmarked === '1' ? '0':'1',
                                                    'api_call':1
                                                })
                                            }}
                                            >
                                            <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                                            </a> */}
                                        </Link>
                                        <div className="r-job-item">
                                        <div className="dropdown more">
                                        <button className="btn dropdown-toggle" 
                                        type="button" id="more-menu" 
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <img src="/assets/images/app/more-btn.svg" />
                                        </button>
                                        <div className="dropdown-menu" aria-labelledby="more-menu">
                                            <ul className="list-unstyled">
                                            <li>
                                                <Link to = {`view-profile/${i.id}/${i.employee.id}/applicants`}>
                                                View Profile
                                                </Link>
                                            </li>
                                            <li><a href="javascript:;"
                                            onClick = {() => {
                                                if (localStorage.notify_employer_model === "1") {
                                                    // alert()
                                                    // console.log(window.$('#notify-employer-model'), 'notify modal')
                                                    window.$('#notify-employer-model').modal('show')
                                                    // <Notify />
                                                } else {
                                                    this.props.hireCandidateModal(true, true, i.id, i.employee.profile_url)
                                                    this.props.getCandidateDetails({
                                                        job_id:i.job.id,
                                                        employee_id : i.employee.id
                                                    });
                                                }
                                            }
                                            }
                                            >Hire</a></li>
                                            <li><a href="javascript:;"
                                            onClick = {() => {
                                                this.props.setShortListModel({
                                                    application_id: 'null',
                                                    employee_id: i.employee.id,
                                                    job_id : null,
                                                    show:true,
                                                    status_code: 2,
                                                    show_status: 'show',
                                                    request : 1
                                                });
                                            }
                                            }
                                            >Reshortlist</a></li>
                                            <li>
                                            <a href="javascript:;"
                                            className = 'get_scheduled_details'
                                            data-id = {i.id}
                                            data-empid = {i.employee.id}
                                            data-jobid = {i.job.id}
                                            onClick = {() => {
                                                // this.props.setShowModel(true);
                                                this.props.setShowModel({
                                                    employee_id : i.employee.id,
                                                    application_id : i.id,
                                                    show: true,
                                                    job_id : i.job.id,
                                                    show_status: 'hide',
                                                    request:0
                                                });
                                            }}
                                            // onClick = {(e) => {

                                                // this.props.shortListEmployee({
                                                //     employee_id:i.employee.id,
                                                //     job_id:i.job.id,
                                                //     application_id:i.id
                                                // })
                                            // }}
                                            
                                            >Schedule Interview
                                            </a>
                                            </li>
                                            <li><a href="javascript:;" className="red"
                                            onClick = {(e) => {
                                                this.props.rejectCandidate({
                                                    application_id:i.id,
                                                    status_code:9
                                                })
                                                // this.props.declineEmployee({
                                                //     id : i.id
                                                // })
                                            }}
                                            >Reject</a></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <h6
                                        onClick = {() => history.push(`view-profile/${i.id}/${i.employee.id}/applicants`)}>
                                            {i.employee.name}</h6>
                                        <span className="job-type text-truncate"
                                        onClick = {() => history.push(`view-profile/${i.id}/${i.employee.id}/applicants`)}
                                        >
                                            {i.job.job_title} | {i.job.job_position}</span>
                                        <span className="location text-truncate d-block"
                                        onClick = {() => history.push(`view-profile/${i.id}/${i.employee.id}/applicants`)}
                                        >
                                        <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                        {i.job.job_location}
                                        </span>
                                        <button className="btn btn-blue" data-toggle="modal" 
                                        disabled = {this.props.btnLoading ? true:false}
                                        onClick = {() => {
                                        //     this.props.hireEmployee({
                                        //     employee_id:i.employee.id,
                                        //     job_id:i.job.id
                                        // })
                                        this.props.shortListEmployee({
                                            employee_id:i.employee.id,
                                            job_id:i.job.id,
                                            application_id:i.id,                
                                            status_code: 2,
                                            request : 0
                                        })
                                    }
                                    }
                                        // data-target="#rehire-modal"
                                    >
                                    {
                                    this.props.btnLoading 
                                    ? 'Loading...':'Shortlist candidate'
                                    }
                                        
                                    </button>
                                    </div>
                                    </div>
                                    </div>
                                    </>
                                    )
                                }) 
                                : (
                                    <>
                                    <div className="empty-job">
                                        <img src="/assets/images/app/undraw-empty.svg" alt="image"/>
                                        <p>There's nothing here.</p>
                                    </div>
                                    </>
                                )
                                : <ApplicantsListView />
                                } 
                                </>
                                ): 
                                (
                                    <>
                                    <div className="empty-job">
                                        <Loader />
                                        {/* <img src="/assets/images/loader.gif" alt="icon" /> */}
                                        
                                    </div>
                                    </>
                                )
                                
                            }
                            {/* <div className="col-12 text-center my-5">
                                <button className="btn btn-blue px-5">Load More</button>
                            </div> */}

                            </div>
                    </div>
                    <div id="shortlist" className=
                    {`col-12 tab-pane fade ${window.location.pathname.split('/')[2] === 
                    'shortlisted'? 'in show active':''}`}
                     >
                    <HiredSearch/>
                        {
                            !this.props.viewType ?
                            <ShortList/> :
                            <ShortListedListView />
                        }
                    </div>
                    <div id="search_new_emp" className={`col-12 tab-pane fade ${(window.location.pathname.split('/').length === 2) && (window.location.pathname.split('/')[1] === 'hire-staff')? 'in show active':''}`}>
                    <SearchEmployeeSearch/>
                    {
                        
                        !this.props.viewType ?
                        <SearchEmployee/> :
                        <SearchListView/>
                    }
                    </div>
                    <div
                    id="schedules" className="col-12 tab-pane fade"
                    >
                        <HiredSearch/>
                    {
                        !this.props.viewType ? 
                        
                        <Shedules /> :
                        <SchedulesListView />
                    }
                    </div>
                    <div
                    id="Hired_list" className={`col-12 tab-pane fade ${window.location.pathname.split('/')[2] === 'offered'? 'in show active':''}`}
                    >
                    <HiredSearch/>
                    {
                        !this.props.viewType ? 

                        <Hired /> :
                        <HiredListView />
                    }
                    </div>
                    <div
                    id="Rejected" className="col-12 tab-pane fade"
                    >
                        <HiredSearch/>
                    {
                        !this.props.viewType ? 
                        <Rejected /> :
                        <RejectedListView />
                    }
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>
            {/* Main Content Ends here */}
            {/* Main Wrapper Ends here */}
            </>  
            <ShortListModel /> 
            <Notify/>         
            </div>
            
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    
    return {
        employeeLists:state.Hire.employeeLists,
        loading:state.Hire.loading,
        show:state.Hire.show,
        btnLoading:state.Hire.btnLoading,
        viewType:state.Hire.viewType,
        varient:state.Hire.varient,
        showMsg:state.Hire.showMsg,
        hire_status:state.Hire.hire_status
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data)),
        getAllEmployees: (data) => dispatch(actions.getAllEmployees(data)),
        getAllUnappliedEmployees: (data, val) => dispatch(actions.getAllUnappliedEmployees(data, val)),
        getShortListedEmployees : (data) => dispatch(actions.getShortlistedEmployees(data)),
        shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        setShow: (data) => dispatch(actions.setShow(data)),
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        getHiredCandidates : (data) => dispatch(actions.getAllWorkers(data)),
        getAllPositions: (data) => dispatch(actions.getAllPositions(data)),
        declineEmployee: (data) => dispatch(actions.declineEmployee(data)),
        // hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        getSkills : () => dispatch(getSkills()),
        setSuccess : (data,val) => dispatch(actions.setSuccess(data,val)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        bookMark: (data) => dispatch(actions.bookMark(data)),
        getselectedIndustries : () => dispatch(getselectedIndustries()),
        getScheduledCandidates : (data) => dispatch(actions.getSchedules(data)),
        showView : (data) => dispatch(actions.showView(data)),
        setSearchApiCall : (data) => dispatch(actions.setSearchApiCall(data)),
        rejectCandidate : (data) => dispatch(actions.rejectCandidate(data)),
        getRejectedCandidates : (data) => dispatch(actions.getRejected(data)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data))
    }
};

const hire = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Hire);

export default hire;





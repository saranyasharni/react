import React from "react";
import { connect } from 'react-redux';
import { Map, GoogleApiWrapper, InfoWindow, Marker } from 'google-maps-react';
import $ from "jquery";
import * as actions from '../../actions/Jobs'
import Geocode from "react-geocode";
import { compose } from "redux";

const mapStyles = {
    width: '100%',
    position : 'fixed',
    height: '100%'
};

export class MapContainer extends React.Component {

    constructor(props) {
        super(props)
        
        this.state = {
            showingInfoWindow: false,// Hides or shows the InfoWindow
            activeMarker: {}, // Shows the active marker upon click
            selectedPlace: {},// Shows the InfoWindow to the selected place upon a marker
            marker_name: "Current position",
            marker_lat: '',
            marker_lng:  ''  
        };
    }
    // componentDidMount() {
    
    // }
    onMarkerClick = (props, marker, e) =>
        this.setState({
        selectedPlace: props,
        activeMarker: marker,
        showingInfoWindow: true
        });

    moveMarker = (coord,map,t) => {
        console.log(coord,map,t, 'coord')
        const { latLng } = coord;
        const lat = latLng.lat();
        const lng = latLng.lng();
        this.displayLocation(lat,lng);
        // console.log(lat, 'markers1')
        // console.log(lng, 'lon')
        // this.setState({
        //     marker_lat:lat,
        //     marker_lng:lng
        // })

        this.props.changeInput("marker", {
            location:'',
            lat:lat,
            lon:lng,
        });
    }

    displayLocation(latitude,longitude){
        fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${11.0168},${76.9558}&sensor=false&key=AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8`)
        .then((response) => response.json())
        .then((data) => console.log(data, '7686876'))
        // $.get({ url: `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&sensor=false&key=${apikey}`, success(data) {
        //     console.log(data);
        // }});
    }

    onClose = props => {
        if (this.state.showingInfoWindow) {
            this.setState({
                showingInfoWindow: false,
                activeMarker: null
            });
        }
    };

    closeMap() {
        $("body").removeClass("crop");        
    }

    render() {
        return(
        <div className="map-sec">
            <div className="col-12 hdr-row">
                <h2>Map</h2>
                <a className="close" 
                href="javascript:;"
                onClick = {() => this.closeMap()}
                >
                    <img src="/assets/images/app/cross-black.svg" alt="icon" />
                </a>
            </div>
        <div className="col-12 px-0">
            {
                // console.log(this.props.lat,this.state.marker_lat, 'latcamehere'),
                // console.log(this.props.lon,this.state.marker_lng, 'latcamehere')
            }
        <Map
            google={this.props.google}
            zoom={14}
            className = "map-sec-inner"
            style={mapStyles}
            initialCenter={
            
                {
                    lat: parseFloat(this.props.lat),
                    lng: parseFloat(this.props.lon)
                }
            }
            center={
            
                {
                    lat: parseFloat(this.props.lat),
                    lng: parseFloat(this.props.lon)
                }
            }
        >
        <Marker
          onClick={this.onMarkerClick}
          draggable={false}
          position= {
            {
                lat: parseFloat(this.props.lat),
                lng: parseFloat(this.props.lon)
            }
          }
          onDragend={(t, map, coord) => this.moveMarker(coord,map,t)}
        //   name={'Kenyatta International Convention Centre'}
        />
        <InfoWindow
          marker={this.state.activeMarker}
          visible={this.state.showingInfoWindow}
          onClose={this.onClose}
        >
        <div>
            <h4>{this.state.selectedPlace.name}</h4>
        </div>
        </InfoWindow>
        </Map>

        {/* <img className="img-fluid w-100" src="/assets/images/app/map-img.png" alt="Map" /> */}
        </div>
    </div>
    )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        marker:state.Jobs.marker,
        // industry:state.Jobs.industry,
    }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        changeInput: (f,v) => dispatch(actions.updateInput(f,v)),
    }
}

const WrappedContainer = compose(
    connect(mapStateToProps,mapDispatchToProps),
    GoogleApiWrapper(({ lang }) => ({
		apiKey: 'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8',
		language: lang,
	})),
);

export default WrappedContainer(MapContainer)



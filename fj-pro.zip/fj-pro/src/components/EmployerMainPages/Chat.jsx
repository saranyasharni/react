import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
// import { Link } from "react-router-dom";
import Header from "../Employer/header";
import ChatLeft from "../Employer/Chats/ChatLeft";
import $ from "jquery"
import * as actions from '../../actions/Employer/Chat';
// import config from '../../actions/Common/Api_Links'
import ChatRight from '../Employer/Chats/ChatRight';
import { io } from 'socket.io-client';
const endPoint = "http://ec2-54-169-157-197.ap-southeast-1.compute.amazonaws.com:3001/"

class Chat extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chatContentLists : [], 
            chatContent : [], 
            chatRoomId_current : ''
        }
    }

    componentDidMount() {
        
        let THIS = this
        $(document).ready(function(){
            $(".chat-list .card-row").click(function(){
                $(".chat-right").addClass("show");
            });
            $(".chat-right .hdr-row .chat-back").click(function(){
                $(".chat-right").removeClass("show");
            });
        // $(window).on("load",function(){
        //     window.$(".mscroll-y").mCustomScrollbar({
        //         axis:"y",
        //         scrollEasing:"linear",
        //         scrollInertia: 600,
        //         autoHideScrollbar: "true",
        //         scrollbarPosition: "outsqaide"
        //     });
        //   });
          
        // console.log(endPoint , 'endPoint')
        const socket = io(endPoint)

        socket.on("connect", () => {
            console.log(socket.id, 'first check'); // x8WIv7-mJelg7on_ALbx
            socket.emit('openChat', {user_type:'employer', user_id:localStorage.getItem('emp_id')})
        });

        socket.on('chatRoomsList',( {chatRoomsList: chatRoomsList}) => {
            console.log(chatRoomsList, 'chatRoomsList')
            THIS.setState({
                chatContentLists : chatRoomsList
            })
            socket.emit('joinRoom', ({chatRoomId: chatRoomsList[0].id, user_type: "employer"}))
            socket.on('chatRoomId', (chatRoomId, profileData) => {

                THIS.props.setChatData(
                    chatRoomId.messages
                )
                THIS.props.setChatRoomId(
                    chatRoomsList[0].id
                )
                localStorage.setItem('chat_room_emp_id', chatRoomsList[0].id)
                
            })
        })
        
        // socket.emit('chat',({employee_id: 1, employer_id: 0, user_type: "employee"}))
        // socket.on('chatRoomsList', (chatRoomList) => {console.log(chatRoomList)});
        // socket.on('chatRoomId', (chatRoomId, profileData) => {console.log(chatRoomId, profileData)})
    });
    }

    componentDidUpdate() {
        $(document).ready(function(){
            $(".chat-list .card-row").click(function(){
                $(".chat-right").addClass("show");
            });
            $(".chat-right .hdr-row .chat-back").click(function(){
                $(".chat-right").removeClass("show");
            });
        })    
    }

    render() {
        
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                {
                    // console.log(this.state.chatContentLists, 'chatContentLists'),
                    this.state.chatContentLists && this.state.chatContentLists.length > 0 ? (
                    <>
                    <div className="row">
                        <div className="col-12 hdr-row">
                            <h1>Messages</h1>
                        </div>
                        <div className="col-12">
                            <div className="chat-container">
                            
                            <ChatRight
                            chatProfile = {this.state.chatContentLists}
                            />
                            <ChatLeft
                            chatRoomId_current= {this.state.chatRoomId_current}
                            />
                            
                            </div>
                        </div>
                    </div>
                    </>
                    ) : (
                    <>
                    <div className="nodata-wrap">
                    <img className="no-data-img" src="/assets/images/app/undraw-publish.svg" alt="image" />
                    <p>No Chats Started Yet</p>
                    {/* <Link to = {`/create/job-post`}
                    className="btn btn-blue" href="hire-create-post-job.html">+ Post a Job</Link>  */}
                    </div>
                    </>
                )
                }
            </div>
            </section>

            {/* Main Wrapper Ends here */}
            </>            
            </div>
            
            </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    
    return {
        
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setChatData : (data) => dispatch(actions.setChatData(data)),        
        setChatRoomId : (data) => dispatch(actions.setChatRoomId(data))
    }
};

const chat = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Chat);

export default chat;





import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import Header from "../Employer/header";
import $, { data } from "jquery"
import * as actions from "../../actions/Notifications"
import moment from 'moment';
import history from '../../stores/history'
import Alert from "react-bootstrap/Alert";

class Notifications extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    componentDidMount() {
        
        let employerId = localStorage.getItem('emp_id')
        // this.props.getEmployerNotification({
        //     employer_id :employerId
        // })
        let THIS = this
        $(document).ready(function(){

            let removingElament = document.getElementById("custom_app_style");

            if (removingElament !== null) {
                removingElament.remove()
            }
            const elem2 = document.createElement("link");
            elem2.rel = "stylesheet"
            elem2.type = "text/css"
            elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";

            elem2.id = "design_app_style"
            elem2.async = true;
       
    });
    
       
    }

    componentDidUpdate() {
        let THIS = this        
        if (this.props.status === 1 || this.props.status ===2) {
            setTimeout(function() {
                THIS.props.setShow(false)
            }, 2000)
        }
    }
    
    render() {
        
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col">
                    <h1>
                    <a href="javascript:;" className="back"
                    onClick = {() => {history.goBack()}}
                    >
                        <img src="/assets/images/app/back-arrow.svg" alt="icon" />
                    </a>
                    Notifications
                    </h1>
                    <div>
                    {/* <a href="javascript:;" className="cl-notify">Clear all notifications</a> */}
                    </div>
                </div>
                <div className="col-12">
                    <div className="snippet-box p-3 p-md-5 notifi-encl">
                    <div className="row">
                        {/* <p className="day"><span>Today</span></p> */}
                        {this.props.employeeNotifications &&
                        this.props.employeeNotifications.notifications &&
                        this.props.employeeNotifications.notifications.length > 0 &&
                        this.props.employeeNotifications.notifications.slice(0,20).map((i,k) => {
                        return (
                            <div className="col-12 my-2" key = {k}
                                onClick = {() => {
                                this.props.readNotification({
                                notification_id: i.id,
                                employer_id:localStorage.getItem('emp_id')
                                })
                            }}
                                >
                                <div className={i.status === "unread" ? 
                                "notify-item" : "notify-item read"
                                }
                                >
                                    <div className="icon-wrap">
                                    <img className="img-fluid notifi-img" 
                                    src="/assets/images/app/notify-orange.svg" 
                                    alt="icon" />
                                    </div>
                                    <div className="n-cont">
                                    <p className="title">
                                        {i.notification_title}
                                    </p>
                                    <p>
                                        {i.notification_body}
                                    </p>
                                    <span>
                                    {moment.utc((i.createdAt)).fromNow()}
                                    </span>
                                    </div>
                                </div>
                                </div>
                            )
                        })
                        }

                        {/* <p className="day mt-3"><span>Yesterday</span></p>
                        {this.props.employeeNotifications &&
                        this.props.employeeNotifications.length > 0 &&
                        this.props.employeeNotifications.slice(5,10).map((i,k) => {
                            return (
                                <div className="col-12 my-2" key = {k}>
                                <div className="notify-item">
                                    <div className="icon-wrap">
                                    <img className="img-fluid" src="/assets/images/app/notify-orange.svg" alt="icon" />
                                    </div>
                                    <div className="n-cont">
                                    <p className="title">
                                        {i.notification_title}
                                    </p>
                                    <p>
                                        {i.notification_body}
                                    </p>
                                    <span>
                                        {moment(new Date(i.createdAt)).fromNow()}
                                    </span>
                                    </div>
                                </div>
                                </div>
                            )
                        })
                        } */}
                       
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>

            {/* Main Wrapper Ends here */}
            </>            
            </div>
            
            </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        employeeNotifications :state.Notifications.employeeNotifications
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getEmployerNotification : (data) => dispatch(actions.getEmployerNotification(data)),
        readNotification : data => dispatch(actions.readNotification(data))
        
    }
};

const notifications = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Notifications);

export default notifications;

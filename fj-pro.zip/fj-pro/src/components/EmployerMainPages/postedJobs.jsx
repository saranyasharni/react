import React, { useEffect, useState } from "react";
import Header from "../Employer/header";
import Grid from "../Employer/postedJobsGrid";
import List from "../Employer/postedJobList";
import { connect } from 'react-redux';
import { PostedJob,
    sortJobs,
    draftedJobList,
    postedJobList,postedClosedJobList } from "../../actions/EmployerPostedJob";
import Alert from "react-bootstrap/Alert";
import {Link} from "react-router-dom";
import $ from 'jquery';

function SeperateHeader(props) {
    useEffect(() => {
        $(document).ready(function() {
            if (window.location.pathname.split('/')[2] === 'drafted') {
                window.$('.nav-tabs a[href="#drafted"]').tab('show');
                // console.log($('.tab-content'),'CameHrer 78')
                // window.$('#drafted').addClass('show active')
            }
        })
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    let input = {
        employer_id:localStorage.getItem('emp_id'),
        filter:"0",
        filter_name:'null',
        filter_term:'null',
        status_code:'4',
        page_no : '0',
        limit : '50'
    };
    props.draftedJobList(input);
    // const elem2 = document.createElement("link");
    // elem2.rel = "stylesheet"
    // elem2.type = "text/css"
    // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    // elem2.id = "design_app_style"
    // elem2.async = true;
    // document.head.appendChild(elem2);
    // return () => {

    // }
    }, []);

    const gridStausChange = () => {
        props.setFieldValues("grid", true);
        props.setFieldValues("grid_active", "active");
        props.setFieldValues("list", false);
        props.setFieldValues("list_active", "");
        let input ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:'null',
            filter_term:'null',
            status_code:'1',
            page_no : '0',
            limit : '50'
        };
        let input1 ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:'null',
            filter_term:'null',
            status_code:'3',
            page_no : '0',
            limit : '50'
        };
        if(props.status == "active"){
            props.postedJobListAction(input);
        } else{
            props.closedJobListAction(input1);
        };
       
    };

    const listStatusChange = () => {
        props.setFieldValues("list", true);
        props.setFieldValues("list_active", "active");
        props.setFieldValues("grid", false);
        props.setFieldValues("grid_active", "");
        let input ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:null,
            filter_term:null,
            status_code:'1',
            page_no : '0',
            limit : '50'
        };
        let input1 ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:null,
            filter_term:null,
            status_code:'3',
            page_no : '0',
            limit : '50'
        };

        if(props.status == "active"){
            props.postedJobListAction(input);
        }else{
            props.closedJobListAction(input1);
        };
    };

    const sortFun = () => {

    }
    const changeFunc2 = () =>{
        
        // props.sortJobs('desending', 'active')
        
        // let res = props.job_list.sort((a,b) => {
        //     var nameA = a.industry_type.toUpperCase(); // ignore upper and lowercase
        //     var nameB = b.industry_type.toUpperCase(); // ignore upper and lowercase
        //     if (nameA < nameB) {
        //         return -1;
        //     }
        //     if (nameA > nameB) {
        //         return 1;
        //     }
        //         // names must be equal
        //     return 0;
        // })
        // console.log(res, 'resres')
        props.setFieldValues("sort_asc",!props.sort_asc)
        // props.setFieldValues("job_list",res)
      
        let input ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"1",
            filter_name:"sort",
            filter_term:"2",
            status_code:'1',
            page_no : '0',
            limit : '15'
        }
        let input1 ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:null,
            filter_term:null,
            status_code:'3',
            page_no : '0',
            limit : '15'
        };

        if(props.status == "active"){
            props.postedJobListAction(input);
        }else{
            props.closedJobListAction(input1);
        }
    };

    const changeFunc1 = () => {
        // console.log(props.active_status, 'props.active_status');
        // if (props.active_status === 'active') {
        //     props.sortJobs('ascending', 'active')
        // } else if (props.active_status === 'closed') {
        //     props.sortJobs('ascending', 'closed')
        // } else if (props.active_status === 'drafted') {
        // props.sortJobs('ascending', 'active')
        // }
        
        props.setFieldValues("sort_asc",!props.sort_asc)
        let input ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"1",
            filter_name:"sort",
            filter_term:"1",
            status_code:'1',
            page_no : '0',
            limit : '15'
        }
        let input1 ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:null,
            filter_term:null,
            status_code:'3',
            page_no : '0',
            limit : '15'
        };
        
        if(props.status == "active"){
            props.postedJobListAction(input);
            }else{
                props.closedJobListAction(input1);
            }
    };

    const searchFunc =(e)=>{
        let input;
        let inputClosed;
        if(e.target.value !== ""){
            input ={
                employer_id:localStorage.getItem('emp_id'),
                filter:"1",
                filter_name:"search",
                filter_term:e.target.value,
                status_code:'1',
                page_no : '0',
                limit : '50'
            };
            inputClosed ={
                employer_id:localStorage.getItem('emp_id'),
                filter:"1",
                filter_name:"search",
                filter_term:e.target.value,
                status_code:'3',
                page_no : '0',
                limit : '50'
            };
        }else {
            input ={
                employer_id:localStorage.getItem('emp_id'),
                filter:"0",
                filter_name:"null",
                filter_term:"null",
                status_code:'1',
                page_no : '0',
                limit : '50'
            };
            inputClosed ={
                employer_id:localStorage.getItem('emp_id'),
                filter:"1",
                filter_name:"null",
                filter_term:"null",
                status_code:'3',
                page_no : '0',
                limit : '50'
            };

        }
        if(props.status == "active"){
            props.postedJobListAction(input);
        } else {
            props.closedJobListAction(inputClosed);
        }
    }

    const statusChange =(val)=>{
        let input ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:null,
            filter_term:null,
            status_code:'1',
            page_no : '0',
            limit : '50'
        };
        let input1 ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:null,
            filter_term:null,
            status_code:'1',
            page_no : '0',
            limit : '50'
        };
        if (val == "active") {
            props.postedJobListAction(input);
        } else {
            props.closedJobListAction(input1);
        };
    }

    return (
        
         <React.Fragment>
            <div className="container-fluid">
                {/* header Starts here */}
                <Header />
                {/* header Ends here */}
               
                {/* Main Content Starts here */}
                <section className="row main-content">
             
                    <div className="container">
                        <div className="row">
                        {
                            <Alert
                            className = "col-12 mt-3"
                            show={props.show_alert}
                            variant={props.varient}
                            dismissible
                            onClose={() =>props.setFieldValues('show_alert',false)}
                            >
                            <strong>
                                {props.varient == "success"
                                ? "Success!"
                                : "Error!"}
                            </strong>{" "}
                            {props.showMsg}
                            </Alert>
                            }
                            <div className="col-12 hdr-row ff-col" id = "tabs">
                                <ul className="nav nav-tabs">
                                    <li id = "active_jobs">
                                        <a className="active" data-toggle="tab" onClick={()=>{props.setFieldValues("active_status","active") 
                                       }} href="#active">
                                            Active
                                    <span className="badge">{props.job_list.length}</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab" 
                                        onClick={()=>{
                                            props.setFieldValues("active_status","closed")
                                       
                                            }
                                            }
                                                  href="#closed">
                                            Completed
                                        <span className="badge">{props.closed_job.length}</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab"
                                        id = "drafted_tab"
                                         onClick={()=>{props.setFieldValues("active_status","drafted")
                                            
                                             }}
                                                  href="#drafted">
                                            Drafted
                                    <span className="badge">{props.drafted_jobs.length}</span>
                                        </a>
                                    </li>
                                </ul>
                                <div className="df-ac">
                                    <button className="btn btn-gray ico mr-3">
                                        <img src="/assets/images/app/search-icon-dark.svg" onClick={()=>{
                                            if(props.searchDisplay == "none"){
                                            props.setFieldValues("searchDisplay","block")}else{
                                                props.setFieldValues("searchDisplay","none")
                                            }
                                            }} alt="icon"  />
                                    </button>
                                    <button className="btn btn-gray ico mr-3" >
                                        {(props.sort_asc == true) ? (
                                         <img src="/assets/images/app/sort-icon.svg" alt="icon"  onClick={changeFunc1} /> 
                                        ):(
                                        <img src="/assets/images/app/desc-sort-icon.svg" alt="icon" onClick={changeFunc2}
                                           />
                                        
                                        )
                                         }
                                    </button>
                                    <div className="btn-set"> 
                                        <a className={props.grid}  onClick={gridStausChange}>
                                            <img src="/assets/images/app/grid-icon.svg" alt="icon" />
                                        </a>
                                        <a className={props.list}  onClick={listStatusChange} >
                                            <img src="/assets/images/app/list-icon.svg" alt="icon" />
                                        </a>
                                    </div>
                                    <Link to="/create/job-post" className="btn btn-blue">
                                        <img className="mr-1" src="/assets/images/app/add-icon.svg" alt="icon" />
                                    Create Job
                                    </Link>
                                </div>


                            </div>
                            <div className="col-12 hdr-row ff-col mt-0" style={{display:props.searchDisplay}}>
                                <form action="" className="search-form form-section w-100">
                                    <div className="form-group mb-0">
                                        <input placeholder="Search..." onChange={searchFunc} className="form-control" type="text"/>
                                    </div>
                                    <a href="javascript:;" className="search-close">
                                        <img className="img-fluid" onClick={()=>props.setFieldValues("searchDisplay","none")} src="/assets/images/modal-close-icon.svg" alt="icon" />
                                    </a>
                                </form>
                            </div>
            
                            {
                            console.log(props.grid_show, 'props.grid_show'),
                            props.grid_show == true?(
                                <Grid />
                            ):(
                            <List />
                            )}
                        </div>
                    </div>
                </section>
                {/* Main Content Ends here */}
            </div>
        

            </React.Fragment>
    )
}


const mapStateToProps = (state, ownProps) => {
    return {
        show: state.Postedjob.show_login,
        grid: state.Postedjob.grid_active,
        list: state.Postedjob.list_active,
        grid_show: state.Postedjob.grid,
        list_show: state.Postedjob.list,
        job_list: state.Postedjob.job_list,
        closed_job:state.Postedjob.closed_jobs_list,
        show_alert:state.Postedjob.show_alert,
        showMsg:state.Postedjob.showMsg,
        sort_asc:state.Postedjob.sort_asc,
        status:state.Postedjob.active_status,
        varient:state.Postedjob.varient,
        drafted_jobs:state.Postedjob.drafted_jobs,
        searchDisplay:state.Postedjob.searchDisplay
        

        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(PostedJob(f, v)),
        sortJobs : (data, active) => dispatch(sortJobs(data, active)),
        postedJobListAction: (input) => dispatch(postedJobList(input)),
        closedJobListAction: (input) => dispatch(postedClosedJobList(input)),
        draftedJobList: (input) => dispatch(draftedJobList(input))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(SeperateHeader);

import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import Header from "../Employer/header";
import RecentJobs from "../Employer/DashBoard/RecentJobs";
import {getSchedules} from '../../actions/Employer/Hire';
import Schedule from '../Employer/DashBoard/Schedule'
import config from "../../actions/Common/Api_Links";
import moment from "moment";

class EmployeeDashboard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            total_jobs:0,
            completed:0,
            working:0,
            absent:0,
            ongoing:[],
            active_jobs:0,
            openings:0,
            active_vacancy:0,
            jobs_posted: 0,
            applicants: 0,
            offered: 0,
            filled: 0
        }
    }
    
    componentWillMount() {
      let formData = new URLSearchParams();//formdata object
      formData.append("employer_id", localStorage.getItem('emp_id'))
      fetch(config.headCount, {
          method: "post",
          headers: {
              "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
              Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body:formData
      })
      .then((response) => response.json())
      .then((response) => {
          if (response.status === 1) {
              this.setState({
                  total_jobs:response.data[0].total_jobs,
                  completed:response.data[0].completed,
                  working:response.data[0].working,
                  ongoing:response.data[0].ongoing,
                  absent:response.data[0].absent,
                  jobs_posted: response.data[0].activeJobs,
                  applicants: response.data[0].applicants,
                  offered: response.data[0].offered,
                  filled: response.data[0].filledJobs
              })
          } else {

          }
          
      })

      fetch(config.jobDetails, {
          method: "post",
          headers: {
              "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
              Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body:formData
      })
      .then((response) => response.json())
      .then((response) => {
          if (response.status === 1 && response.data[0].total_vacancy && response.data[0].job_stat_information.active_vacancy) {
              // console.log(response.data, 'response')
              this.setState({
                  active_jobs:response.data[0].total_jobs,
                  openings:response.data[0].total_vacancy,

                  active_vacancy:response.data[0].job_stat_information.active_vacancy
                  // working:response.data[0].working,
                  // absent:response.data[0].absent,
              })
          } else {

          }
          
      })
      this.props.getScheduledCandidates({
        employer_id:localStorage.getItem('emp_id'),
        status_code : 8,
        filter:1,
        industry_type:null,
        job_position:null,
        page_no:0,
        limit:1,
        filter_by :"date",
        interview_date: moment(new Date()).format('MM/DD/YYYY')
      })
    }
    componentDidMount() {
      let removingElament = document.getElementById("custom_app_style");
      console.log(removingElament, 'removingElament')  
      if (removingElament !== null) {
     
          removingElament.remove()
     
      }

      let getElament = document.getElementById("design_app_style");
      
      if (getElament === null) {
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "design_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
      }
      
    }

    render() {
        
  return (
  <div className="container-fluid">
  {/* header Starts here */}
 <Header/>
  {/* header Ends here */}
  {/* Main Content Starts here */}
  <section className="row main-content">
    <div className="container">
      <div className="row">
        <div className="col-12 hdr-row">
          <h1>Overview</h1>
          <Link to = "/create/job-post" className="btn btn-blue">+ Create Job</Link>
        </div>
      </div>
      <div className="row mb-5">
        <div className="col-lg-9 col-md-12">
          <div className="col px-0 mb-md-5 mb-3 n__headcount">
            <h3>Headcount</h3>
            <Link className="stamp green" to = "/employer_posted_job_list/active-jobs"
                  style = {{
                    textDecoration:'none'
                  }}
            >
                <p>Active Jobs</p>
                <span>{this.state.jobs_posted}</span>
            </Link>
            <Link className="stamp purple" to = "/hire-staff/applicants"
                    href="#applicants"
                    style = {{
                      textDecoration:'none'
                    }}
                    >
                <p>Applicants</p>
                <span>{this.state.applicants}</span>
            </Link>
            <Link className="stamp cyan" to = "/hire-staff/offered"
            style = {{
              textDecoration:'none'
            }}
            >
                <p>Offered</p>
                <span>{this.state.offered}</span>
            </Link>
            <Link className="stamp brown" to = "/workers"
            style = {{
              textDecoration:'none'
            }}
            >
                <p>Filled</p>
                <span>{this.state.filled}</span>
            </Link>

            {/* <Link className="stamp purple" to = "/employer_posted_job_list/filled-jobs"
            style = {{
              textDecoration:'none'
            }}
            >
                <p>Filled Jobs</p>
                <span>{this.state.completed}</span>
            </Link>
            <Link className="stamp cyan" to = "/employer_posted_job_list/on-going-jobs"
            style = {{
              textDecoration:'none'
            }}
            >
                <p>Working</p>
                <span>{this.state.working}</span>
            </Link>
            <div className="stamp brown">
              <p>Openings</p>
              <span>{this.state.openings}</span>
            </div>
            <div className="stamp red mr-0">
              <p>Active Openings</p>
              <span>{this.state.active_vacancy}</span>
            </div> */}
          </div>
          <div className="row">
          <RecentJobs/>
            {/* <div className="col-lg-8">
              <div className="hdr-row snippet mt-0">
                <h3 className="mb-0">Recent Jobs</h3>
                <div className="d-flex">
                  <form className="search-form">
                    <input className="form-control" type="text" name placeholder="Search Jobs" />
                    <button className="btn"><img src="/assets/images/app/search-icon.svg" alt="icon" /></button>
                  </form>
                  <button className="btn sort">
                    <img src="/assets/images/app/sort-icon.svg" alt="icon" />
                  </button>
                </div>
              </div>
              <div className="row">
                <div className="col-md-6">
                  <div className="r-job-item">
                    <div className="dropdown more">
                      <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="/assets/images/app/more-btn.svg" />
                      </button>
                      <div className="dropdown-menu" aria-labelledby="more-menu">
                        <ul className="list-unstyled">
                          <li><a href="javascript:;">Edit job</a></li>
                          <li><a href="javascript:;">Share</a></li>
                          <li><a href="javascript:;" className="red">Job Close</a></li>
                        </ul>
                      </div>
                    </div>
                    <h6>Manufacturer</h6>
                    <p>Part-time | per Hour Rm 100</p>
                    <span className="location">
                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                      St Andrews Lane, London, UK
                    </span>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="r-job-item">
                    <div className="dropdown more">
                      <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="/assets/images/app/more-btn.svg" />
                      </button>
                      <div className="dropdown-menu" aria-labelledby="more-menu">
                        <ul className="list-unstyled">
                          <li><a href="javascript:;">Edit job</a></li>
                          <li><a href="javascript:;">Share</a></li>
                          <li><a href="javascript:;" className="red">Job Close</a></li>
                        </ul>
                      </div>
                    </div>
                    <h6>Telemarketing executive</h6>
                    <p>Part-time | per Hour Rm 100</p>
                    <span className="location">
                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                      St Andrews Lane, London, UK
                    </span>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-6">
                  <div className="r-job-item">
                    <div className="dropdown more">
                      <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="/assets/images/app/more-btn.svg" />
                      </button>
                      <div className="dropdown-menu" aria-labelledby="more-menu">
                        <ul className="list-unstyled">
                          <li><a href="javascript:;">Edit job</a></li>
                          <li><a href="javascript:;">Share</a></li>
                          <li><a href="javascript:;" className="red">Job Close</a></li>
                        </ul>
                      </div>
                    </div>
                    <h6>Manufacturer</h6>
                    <p>Part-time | per Hour Rm 100</p>
                    <span className="location">
                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                      St Andrews Lane, London, UK
                    </span>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="r-job-item">
                    <div className="dropdown more">
                      <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="/assets/images/app/more-btn.svg" />
                      </button>
                      <div className="dropdown-menu" aria-labelledby="more-menu">
                        <ul className="list-unstyled">
                          <li><a href="javascript:;">Edit job</a></li>
                          <li><a href="javascript:;">Share</a></li>
                          <li><a href="javascript:;" className="red">Job Close</a></li>
                        </ul>
                      </div>
                    </div>
                    <h6>Telemarketing executive</h6>
                    <p>Part-time | per Hour Rm 100</p>
                    <span className="location">
                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                      St Andrews Lane, London, UK
                    </span>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-6">
                  <div className="r-job-item">
                    <div className="dropdown more">
                      <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="/assets/images/app/more-btn.svg" />
                      </button>
                      <div className="dropdown-menu" aria-labelledby="more-menu">
                        <ul className="list-unstyled">
                          <li><a href="javascript:;">Edit job</a></li>
                          <li><a href="javascript:;">Share</a></li>
                          <li><a href="javascript:;" className="red">Job Close</a></li>
                        </ul>
                      </div>
                    </div>
                    <h6>Manufacturer</h6>
                    <p>Part-time | per Hour Rm 100</p>
                    <span className="location">
                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                      St Andrews Lane, London, UK
                    </span>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="r-job-item">
                    <div className="dropdown more">
                      <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="/assets/images/app/more-btn.svg" />
                      </button>
                      <div className="dropdown-menu" aria-labelledby="more-menu">
                        <ul className="list-unstyled">
                          <li><a href="javascript:;">Edit job</a></li>
                          <li><a href="javascript:;">Share</a></li>
                          <li><a href="javascript:;" className="red">Job Close</a></li>
                        </ul>
                      </div>
                    </div>
                    <h6>Telemarketing executive</h6>
                    <p>Part-time | per Hour Rm 100</p>
                    <span className="location">
                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                      St Andrews Lane, London, UK
                    </span>
                  </div>
                </div>
              </div>
            </div> */}
            <div className="col-lg-4">
              <div className="row">
                <div className="col mb-4">
                  <h3>Ongoing Work</h3>
                  <div className="snippet-box">
                  {
                    this.state.ongoing &&
                    this.state.ongoing.length > 0 ?
                    this.state.ongoing.map((i,k) => {
                        return (
                          <div className="work-item" key = {k}>
                          <div className="avatar"> 
                              <img className="img-fluid" src=
                              {
                                i.employee &&
                                i.employee.profile_url &&
                                i.employee.profile_url !== "null" &&
                                i.employee.profile_url !== null ?
                                i.employee.profile_url :
                                "/assets/images/app/avatar-1.png"
                              }
                              style = {{
                                height : '100%'
                              }}

                               alt="icon" />
                          </div>
                          <div className="w-cont">
                              <div>
                              <span className="user text-truncate">
                                  {i.employee && i.employee.name}
                                  {/* Amanda Reyes */}
                              </span>
                              <span>{i.application_status}</span>
                              </div>
                              {/* <button className="btn btn-blue none"

                              >Re Hire</button> */}
                          </div>
                          </div>
                      )
                    }
                    
                    ):<div className="work-item" >
                    <div className="avatar"> 
                        {/* <img className="img-fluid" src="/assets/images/app/avatar-1.png" alt="icon" /> */}
                    </div>
                    <div className="w-cont">
                        
                        No Workers Yet
                        {/* <span>Hired</span> */}
                        
                        {/* <button className="btn btn-blue none"

                        >Re Hire</button> */}
                    </div>
                    </div>
                  }  
                                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Schedule/>
      </div>
    </div>
  </section>
  {/* Main Content Ends here */}
</div>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    
    return {
        
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getScheduledCandidates : (data) => dispatch(getSchedules(data)),
    }
};

const chat = connect(
    mapStateToProps,
    mapDispatchToProps,
)(EmployeeDashboard);

export default chat;





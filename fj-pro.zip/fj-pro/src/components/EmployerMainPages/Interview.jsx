import React, { useEffect, useState } from "react";
import moment from "moment";
import config from "../../actions/Common/Api_Links"
import * as actions from '../../actions/Employer/Hire';
import $ from "jquery"
import { connect } from 'react-redux'
import Loader from '../Helper/Loader'
import Header from '../Employer/header'
import Alert from "react-bootstrap/Alert";
import DatePicker from "react-datepicker";
function Interviews(props) {
    
    const [state, setState] = useState({
      editDate:'',
        editStartTime:'',
        editEndTime:'',
        scheduleId : '',
        employee_id : '',
        job_id: '',
        status:0,
        loading:false,
        modelMessage:'',
        date: moment(new Date()).format('DD MMMM YYYY')
    })

    useEffect(() => {   
      $(document).ready(function () {
        window.jQuery(".input-group.date")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
        autoclose:true
        // endDate: "+0d",
        })
        .off("change")
       
        window.jQuery(".cal-icon")
        .datepicker({
        format: "dd MM yy"})
      })
      props.getSchedules({
        employer_id:localStorage.getItem('emp_id'),
        status_code : 8,
        filter:0,
        filter_by:null,
        industry_type:null,
        job_position:null,
        page_no:0,
        limit:1,
        interview_date:null
    })
        // require("../../../assets/css/app-style.css");
    }, []);
    useEffect(() => {
        
        let THIS = this
        // if (props.status ===1 || props.status ===2) {
        //     setTimeout(function() {
        //         props.setShow(false)
        //     }, 2000)
        // }
        $(document).ready(function () {
        if (state.status === 1) {
            $("#edit-arrange-interview .alert").html(
                `<strong>Success!</strong> ${state.modelMessage}.`
            );
            $("#edit-arrange-interview .alert")
                .removeClass("alert-danger")
                .addClass("alert-success");
            setTimeout(function () {
                $("#edit-arrange-interview .alert").removeClass("alert-success");
                $("#edit-arrange-interview .alert").html("");
                window.$("#edit-arrange-interview").modal("hide");
                setState({
                    ...state,
                    status: 0,
                    modelMessage:'',
                    editDate:'',
                    editEndTime:'',
                    editStartTime:''
                });
            }, 3000);
              
        } else if (state.status === 2) {
            $("#edit-arrange-interview .alert").html(
                `<strong>Sorry!</strong> ${state.modelMessage}.`
            );
            $("#edit-arrange-interview .alert")
                .removeClass("alert-success")
                .addClass("alert-danger");
            setTimeout(function () {
                $("#edit-arrange-interview .alert").removeClass("alert-danger");
                $("#edit-arrange-interview .alert").html("");
                window.$("#edit-arrange-interview").modal("hide");
                setState({
                    ...state,
                    status: 0,
                    modelMessage:'',
                });
            }, 3000);
        } })

        return () => {
            props.setShow(false)
        }
    })

    function editInterview(){    
       console.log(state, 'state')
        let formData = new URLSearchParams();    //formdata object
        // formData.append("employer_id", data.employer_id)
        // formData.append("status_code", data.status_code)
        formData.append("schedule_id",state.scheduleId)
        formData.append("employee_id",state.employee_id)
        formData.append("job_id",state.job_id)
        formData.append("interview_date",state.editDate)
        formData.append("start_time",state.editStartTime)
        formData.append("end_time",state.editEndTime)
        setState({
            ...state,
            loading:true
        })
        return fetch(config.edit_interview, {
            method: "post",
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
            })
            .then((response) => response.json())
            .then((response) => {
            
                if (response.status == 1) {
                    
                    setState({
                        ...state,
                        loading:false,
                        modelMessage:'Interview updated successfully',
                        status:1
                    })
                } else {
                    setState({
                        ...state,
                        loading:false,
                        modelMessage:response.message,
                        status:2
                    })
                }
            })
            .catch((e) => {
                setState({
                    ...state,
                    loading:false,
                    modelMessage:'Please try again later',
                    status:2
                })
                console.log(e);
            });
    }

   
    function getYesterdaysDate() {
        var date = new Date(state.date)
        
        date.setDate(date.getDate()-1);
        let date1 =  date.getDate() + ' ' + 
        (date.toLocaleString('default', { month: 'long' })) + 
        ' ' + date.getFullYear();
        console.log(date1,'atte')
        let sendDateFormat = 
        ('0'+(date.getMonth()+1)).slice(-2) + '/' + ('0'+ date.getDate()).slice(-2) + '/' + date.getFullYear();

        props.getSchedules({
            employer_id:localStorage.getItem('emp_id'),
            status_code : 8,
            filter:1,
            filter_by:'date',
            industry_type:null,
            job_position:null,
            page_no:0,
            limit:1,
            interview_date:sendDateFormat
        })
        setState({
            ...state,
            date:date1
        })
  }
  function getTomorrowsDate() {
    var date = new Date(state.date);
    date.setDate(date.getDate()+1);
    let date1 =  date.getDate() + ' ' + 
    (date.toLocaleString('default', { month: 'long' })) + 
    ' ' + date.getFullYear();
    let sendDateFormat = 
    ('0'+(date.getMonth()+1)).slice(-2) + '/' + ('0'+ date.getDate()).slice(-2) + '/' + date.getFullYear();
    setState({
        ...state,
        date:date1
    })
    props.getSchedules({
        employer_id:localStorage.getItem('emp_id'),
        status_code : 8,
        filter:1,
        filter_by:'date',
        industry_type:null,
        job_position:null,
        page_no:0,
        limit:1,
        interview_date:sendDateFormat
    })
    }
    const setParams = (i) => {
    
        setState(
        {
            ...state,
            editDate:new Date(i.interview_date),
            editStartTime:new Date(`Aug 28, 2008 ${i.start_time}:00`),
            editEndTime:new Date(`Aug 28, 2008 ${i.end_time}:00`),
            scheduleId:i.id,
            employee_id:i.job_application 
            && i.job_application.employee_id,
            job_id: i.job_application.job_id 
        });
    }
    return (
        
        <div>   
        {/* Main Wrapper Starts here */}
        <div className="container-fluid">
        <Header/>
        {/* Hero Section Starts here */}
        {/* Hero Section Ends here */}
        <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col mb-2">
                    <h1>Scheduled Interviews</h1>
                </div>
                
                  
            <div className="col-12 mb-5 schedule-i-wrap">
        
                    {
                        <Alert
                        show={props.show}
                        variant={props.varient}
                        dismissible
                        onClose={() => props.setShow(false)}
                        >
                        <strong>
                        {
                            props.status === 1 ? "Success!" 
                            : props.status === 2 ? "Error!"
                            :"Info!"
                        }
                        </strong>{" "}
                        {props.showMsg}
                        </Alert>
                    }
                        <div className="table-hdr row mb-0 mb-md-4">
                        <div className="col-12">
                            <div className="date-nav">
                            <a href="javascript:;" className="date-prev"
                            onClick = {() => {
                                getYesterdaysDate()
                                
                            }}
                            >
                                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
                            </a>
                            {/* <span>{state.date}</span> */}
                            <img src="/assets/images/app/calendar-icon.svg" alt="icon" />
                        
                            <input className="cal-icon"
                 
                            onSelect = {(e) => {
                            setState({
                                ...state,
                                date: moment(new Date(e.target.value)).format('DD MMMM YYYY')
                            });  
                            props.getSchedules({
                                employer_id:localStorage.getItem('emp_id'),
                                status_code:8,
                                filter:1,
                                filter_by:'date',
                                // filter_by: null,
                                industry_type:null,
                                job_position:null,
                                page_no:0,
                                limit:1,
                                // interview_date:null,
                                interview_date:moment(new Date(e.target.value)).format('MM/DD/YYYY')
                            })
                            
                        }}
                            
                        value = {state.date}
                        />
                       
                        <a href="javascript:;" className="date-next"
                            onClick = {() => {
                                getTomorrowsDate()
                            }}
                            >
                                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
                            </a>
                            </div>
                             </div>
                            </div>
                            {
                            props.loading ?
                            <div className="empty-job">
                            <Loader/>
                            </div>:
                             <div className="row">
                             {
                                 // console.log(this.props.scheduleList,'scheduleList')
                                props.scheduleList &&
                                props.scheduleList.length > 0 ?
                                props.scheduleList.map((i,k) => {
                                return (
                                 <div className="col-lg-3 col-md-4 col-12" key = {k}>
                                 <div className="r-job-item">
                                 <div className="date-time">
                                    <span>{moment(new Date(i.interview_date)).format('DD MMMM YYYY')}</span>
                                    <span>{moment(i.start_time, "HH:mm").format("hh:mm A")}</span>
                                 </div>
                                 <div className="position-relative px-3">
                                     <div className="dropdown more">
                                     <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                         <img src="/assets/images/app/more-dot.svg" />
                                     </button>
                                     <div className="dropdown-menu" aria-labelledby="more-menu">
                                        <ul className="list-unstyled">
                                        <li><a href="javascript:;"
                                        onClick = {() => {
                                            setParams(i)
                                            
                                            window.$('#edit-arrange-interview').modal('show')
                                        }}
                                        >Edit Interview</a></li>
                                        <li><a href="javascript:;" className="red"
                                        onClick = {() => {
                                             // this.setState({
                                             //     scheduleId:i.id,
                                             //     employee_id:i.job_application 
                                             //     && i.job_application.employee_id,
                                             //     job_id: i.job_application.job_id 
                                             // });
                                            props.cancelInterview({
                                                schedule_id:i.id,
                                                employee_id:i.job_application 
                                                && i.job_application.employee_id,
                                                job_id:i.job_application.job_id 
                                            })
                                         }}
                                         >Cancel Interview</a></li>
                                         </ul>
                                     </div>
                                     </div>
                                     <h6>{i.job_application &&
                                     i.job_application.job &&
                                     i.job_application.job.industry_type
                                     }{" "}{i.job_application &&
                                         i.job_application.job &&
                                         i.job_application.job.job_position}
                                     </h6>
                                     <span className="location">{
                                         i.job_application &&
                                         i.job_application.job &&
                                         i.job_application.job.employer &&
                                         i.job_application.job.employer.company_name
                                     }, {
                                         i.job_application &&
                                         i.job_application.job &&
                                         i.job_application.job.job_location
                                     }</span>
                                 </div>
                                 <div className="hire-candidate px-3">
                                     <div className="avatar">
                                     <img className="img-fluid" 
                                     style = {{
                                         height :'100%'
                                     }}
                                     src=
                                     {i.job_application &&
                                         i.job_application.employee &&
                                         i.job_application.employee.profile_url !== "null" &&
                                         i.job_application.employee.profile_url !== null &&
                                         i.job_application.employee.profile_url !== "" 
                                         ?
                                         i.job_application.employee.profile_url :
                                         "/assets/images/app/avatar-1.png"
                                     }
                                     alt="Staff" />
                                     </div>
                                     <div className="av-cont">
                                     <h6>{i.job_application &&
                                         i.job_application.employee &&
                                         i.job_application.employee.name}</h6>
                                     <span>{
                                         i.job_application &&
                                         i.job_application.job &&
                                         i.job_application.job.job_position
                                         }
                                     </span>
                                     </div>
                                 </div>
                                 </div>
                             </div>
                             )
                             }) : <div className="empty-job">
                             <img src="assets/images/app/undraw-empty.svg" alt="image"/>
                             <p>There's nothing here.</p>
                         </div>
                             }
                             
                             </div>
                             }
                         </div>
                
           
                </div>
            </div>
        </section>

        </div>
        {/* Main Wrapper Ends here */}
        
        {/* Modal Wrapper Starts here */}
        <div className="modal fade custom-modal" id="edit-arrange-interview" tabIndex={-1} role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
            <div className="modal-content">
            <div className="modal-header">
                <h5 className="mt-2 modal-title w-100 justify-content-center">Edit Interview</h5>
                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                </button>
            </div>
            <div className="modal-body px-md-5 px-3">
                <div className="row">
                <form className="form-section col-md-12">
                    <div class="alert" role="alert">
                    
                    </div>
                    <div className="form-group">
                    <label>Date</label>
                    {/* <div className="input-group date mar-t-no"
                    data-date-format="mm/dd/yyyy" 
                    > */}
                    
                    <DatePicker 
                    className="form-control"
                    dateFormat = 'dd/MM/yyyy'
                    placeholderText = "DD/MM/YYYY"
                    minDate={new Date()}
                    onChange={(date) => 
                        {
                            setState({
                            ...state,
                            editDate: date,
                            });  
                        }
                    }
                    name = "date_interview"
                    selected={state.editDate} 
                   />
                        {/* <input type="text" className="form-control" 
                        onSelect = {(e) => {
                        setState({
                        ...state,
                        editDate: e.target.value,
                        });  
                        }}
                        value = {state.editDate}
                        /> */}
                        {/* <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div> */}
                    </div>
                    <div className="row">
                    <div className="form-group col-md-6">
                        <label>Start Time</label>
                        {/* <input type="time" 
                        onChange= {(e) => {
                            setState({
                                ...state,
                                editStartTime:e.target.value,
                            });
                        }}
                        value = {state.editStartTime}
                        className="form-control" 
                        name 
                        /> */}
                        <DatePicker 
                        className="form-control"
                        
                        placeholderText = "HH:MM"
                        selected={state.editStartTime}
                        name = "start_date_time_start"
                        onChange={(date) => {
                            setState({
                                ...state,
                                editStartTime:date,
                            });
                        }}    
                        showTimeSelect
                        showTimeSelectOnly
                        timeIntervals={30}
                        timeCaption="Time"
                        dateFormat="h:mm aa"
                
                        />
                    </div>
                    <div className="form-group col-md-6">
                        <label>End Time</label>
                        {/* <input type="time"
                        onChange= {(e) => {
                            setState({
                                ...state,
                                editEndTime:e.target.value,
                            });
                        }} 
                        value = {state.editEndTime}
                        className="form-control" 
                        name
                        /> */}
                        <DatePicker 
                        className="form-control"
                        placeholderText = "HH:MM"
                        selected={state.editEndTime}
                        name = "start_date_time_start"
                        onChange={(date) => {
                            setState({
                                ...state,
                                editEndTime:date,
                            });
                        }}    
                        showTimeSelect
                        showTimeSelectOnly
                        timeIntervals={30}
                        timeCaption="Time"
                        dateFormat="h:mm aa"
                
                        />
                    </div>
                    </div>
                </form>
                </div>
                <div className="row mt-2 mb-3">
                <div className="col-md-12 text-right">
                    <button className="btn btn-blue"
                    onClick = {() => {
                        editInterview()
                    }}
                    >{state.loading ? "Loading..." : "Edit Interview"}
                    </button>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        </div>
   
    )};

    const mapStateToProps = (state, ownProps) => {
        return {
            scheduleList:state.Hire.scheduleList,
        show:state.Hire.show,
        varient:state.Hire.varient,
        status: state.Hire.status,
        loading : state.Hire.loading,
        showMsg:state.Hire.showMsg,
        }
    };
    
    const mapDispatchToProps = (dispatch, ownProps) => {
       
        return {
            getSchedules : (data) => dispatch(actions.getSchedules(data)),
            setShow : data => dispatch(actions.setShow(data)),
            cancelInterview : (data) => dispatch(actions.cancelInterview(data))
            // saveSalary : (data) => dispatch(actions.saveSalary(data)),
            // rejectRequest : (data) => dispatch(actions.rejectRequest(data)),
            // acceptRequest : (data) => dispatch(actions.acceptRequest(data)),
        }
       
    };

    export default connect(mapStateToProps, mapDispatchToProps)(Interviews); 
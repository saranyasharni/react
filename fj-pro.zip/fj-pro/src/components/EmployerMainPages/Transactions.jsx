import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import Header from "../Employer/header";
import $, { data } from "jquery"
import * as actions from "../../actions/Transactions"
import moment from 'moment';
import history from '../../stores/history'
import Alert from "react-bootstrap/Alert";

class Transactions extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    componentDidMount() {
        
        // let employerId = localStorage.getItem('emp_id')
        this.props.getEmployerTransactions()
        this.props.getEmployerCredits()
        let THIS = this
        $(document).ready(function(){

            let removingElament = document.getElementById("custom_app_style");

            if (removingElament !== null) {
                removingElament.remove()
            }
            const elem2 = document.createElement("link");
            elem2.rel = "stylesheet"
            elem2.type = "text/css"
            elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";

            elem2.id = "design_app_style"
            elem2.async = true;
       
    });
    
       
    }

    componentDidUpdate() {
        let THIS = this        
        if (this.props.status === 1 || this.props.status ===2) {
            setTimeout(function() {
                THIS.props.setShow(false)
            }, 2000)
        }
    }
    
    render() {
        
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col">
                    <h1>
                    <a href="javascript:;" className="back"
                    onClick = {() => {history.goBack()}}
                    >
                        <img src="/assets/images/app/back-arrow.svg" alt="icon" />
                    </a>
                    Transactions
                    </h1>
                    <div>
                    {/* <a href="javascript:;" className="cl-notify">Clear all notifications</a> */}
                    </div>
                </div>
                <div className="col-12">
                    <div className="snippet-box p-3 p-md-5 notifi-encl">
                    <div className="row">
                        {/* <p className="day"><span>Today</span></p> */}
                        {this.props.transactionList &&
                        this.props.transactionList.length > 0 &&
                        this.props.transactionList.map((i,k) => {
                            return (
                                <div className="col-12 my-2" key = {k}
                                //     onClick = {() => {
                                //     this.props.readNotification({
                                //     notification_id: i.id,
                                //     employer_id:localStorage.getItem('emp_id')
                                //     })
                                // }}
                                >
                                <div className={i.status === "unread" ? 
                                "notify-item" : "notify-item read"
                                }
                                >
                                    <div className="icon-wrap">
                                    <img className="img-fluid card-icon" src={process.env.PUBLIC_URL+"/assets/images/app/wallet.png"} alt="icon" />
                                    </div>
                                    <div className="n-cont">
                                    <p className="title text-capitalize">
                                        {i.employee_name}
                                    </p>
                                    <p className = 'text-capitalize'>
                                        {i.job_position}
                                    </p>
                                    
                                    <span className = "show-color-amount">
                                    <i class="fa fa-plus" aria-hidden="true"></i> {" "}
                                        RM{new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.amount_paid)
                                        ? '0.00':i.amount_paid)}
                                    </span>
                                    </div>
                                </div>
                                </div>
                            )
                        })
                        }      
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>

            {/* Main Wrapper Ends here */}
            </>            
            </div>           
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        transactionList :state.Transactions.transactionList,
        creditList :state.Transactions.creditList
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getEmployerTransactions : (data) => dispatch(actions.TransactionLists(data)),        
        getEmployerCredits : (data) => dispatch(actions.CreditLists(data)),        
    }
};

const transactions = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Transactions);

export default transactions;

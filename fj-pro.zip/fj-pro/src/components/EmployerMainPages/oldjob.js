import React, { Component, Fragment } from 'react'
import { Link } from 'react-router-dom';
import $ from "jquery";
import { connect } from 'react-redux'
import Header from '../Employer/header'
import * as actions from '../../actions/Jobs'
import DatePicker from "react-datepicker";
import "./datepicker.css";
// import { Map, GoogleApiWrapper, InfoWindow, Marker, Listing } from 'google-maps-react';
import {getIndustries, getPositions} from "../../actions/Home"
import Alert from "react-bootstrap/Alert";
import CurrencyInput from 'react-currency-input-field';
import moment from "moment"
import MapComponent from "./Map"
// import "react-datepicker/dist/react-datepicker.css";
import history from '../../stores/history';
import Autocomplete from "react-google-autocomplete";
import { Link as ScrollLink, scroller, Element } from "react-scroll";
import autosize from 'autosize'

class CreateJobPost extends Component {
    constructor(props) {
        super(props);  
        this.state = {
            show_position : false,
            errors : [],
            alertStatus : 0,
            show:false,
            variant:"",
            jobPosition:'',
            selectedDate:"",
            lati :'',
            longi:''
        }    
    }
    
    componentWillMount() {
        let path = window.location.pathname.split('/')[1]
        let pathId = window.location.pathname.split('/')[3]
        if (path === 'edit' || path === 'similar') {
            this.props.getJob(pathId, this.props.days_format_array)
        }
        this.props.salaryContribution()
        console.log(this.state.selectedDate, "component mount reload .............")

        $('.add-pointer a').on('click', function() {  
            $('html, body').animate({scrollTop: $(this.hash).offset().top - 20}, 600);
            return false;
        });
    }

    componentDidMount() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
              (position) => {
                this.props.changeInput("lat", position.coords.latitude);
                this.props.changeInput("lon", position.coords.longitude);
                this.setState({
                    lati:position.coords.latitude,
                    longi:position.coords.longitude
                })
                // var map = new google.maps.Map()
                // var geocoder = new google.maps.Geocoder();
              },
              () => {
                // handleLocationError(true, infoWindow, map.getCenter());
              }
            );
          } else {
            // Browser doesn't support Geolocation
            // handleLocationError(false, infoWindow, map.getCenter());
        }
        this.props.getIndustries()
        window.$('#select_currency').prop('disabled', true)
        window.$('#salary_based').prop('disabled', true)
        if (sessionStorage.getItem("Emp_address")) {
            
            this.props.changeInput("location", sessionStorage.getItem("Emp_address"));
        }        
        let removingElament = document.getElementById("custom_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        autosize(document.querySelector('textarea'));
        let THIS = this;
        $(document).ready(function () {
            $(".btn-map").click(function(){
                $("body").addClass("crop");
              });
            
              $(".map-sec .close").click(function(){
                $("body").removeClass("crop");
              });
            // window.$('.add-pointer a').on('click', function() {
            //     console.log(this.hash, 'this.hash')  
            //     window.$('html, body').animate({scrollTop: $(this.hash).offset().top - 20}, 600);
            //     return false;
            // });    
            window.$('[data-toggle="tooltip"]').tooltip({
                html: true
            });

            // window.jQuery('textarea').autosize();
             
            // window.jQuery('#time_pic_start').datetimepicker({
            //     format: 'hh:mm A',
            //     stepping: 30,
            //     icons: {
            //         up: "fa fa-angle-up",
            //         down: "fa fa-angle-down"
            //     }
            // }).on('dp.change', function (e) {  
            //     THIS.props.changeInput("scheduleStartTime", e.target.value);
            //     THIS.setHoursAndDays(2, moment(e.target.value, "hh:mm A").format("HH:mm"), moment(THIS.props.scheduleEndTime, "hh:mm A").format("HH:mm"));
            //     THIS.calculateSalary(e,
            //         moment(THIS.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
            //         moment(THIS.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
            //         moment(THIS.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
            //         moment(THIS.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
            //         THIS.props.salaryBased,
            //         false
            //     );
            //     if ($('#nav_link2').attr('class') === 'nav-item active') {
                    
            //     } else {
            //         $('#nav_link2').addClass('active')
            //     }
            // });    
            // window.jQuery('#time_pic_end').datetimepicker({
            //     format: 'hh:mm A',
            //     stepping: 30,
            //     icons: {
            //         up: "fa fa-angle-up",
            //         down: "fa fa-angle-down"
            //     }
            // }).on('dp.change', function (e) {  
                
            //     THIS.props.changeInput("scheduleEndTime", e.target.value);
            //     THIS.setHoursAndDays(2, moment(THIS.props.scheduleStartTime, "hh:mm A").format("HH:mm"), moment(e.target.value, "hh:mm A").format("HH:mm"));
            //     THIS.calculateSalary(e,
            //         moment(THIS.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
            //         moment(THIS.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
            //         moment(THIS.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
            //         moment(THIS.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
            //         THIS.props.salaryBased,
            //         false
            //     );
            //     if ($('#nav_link2').attr('class') === 'nav-item active') {
                    
            //     } else {
            //         // $('#nav_link2').addClass('active')
            //     }
            // });    
           
            window.$(".selectpicker").selectpicker();
            // window.jQuery(".input-group.start_date")
            // .datepicker({
            // format: "dd/mm/yyyy",
            // todayHighlight: true,
            // autoclose:true
            // // endDate: "+0d",
            // })
            // .off("change")
            
            // .change((e) => {
            //     if ($('#nav_link2').attr('class') === 'nav-item active') {
                                        
            //     } else {
            //         $('#nav_link2').addClass('active')
            //     }
               
            // THIS.props.changeInput("scheduleStartDate", e.target.value);
            // // THIS.props.changeInput("showDateStart", e.target.value);
            // THIS.calculateSalary(e,
            //     moment(THIS.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
            //     moment(THIS.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
            //     moment(THIS.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
            //     moment(THIS.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
            //     THIS.props.salaryBased,
            //     false
            // )
            // THIS.setHoursAndDays(1, moment(e.target.value, "DD/MM/YYYY").format("MM/DD/YYYY"), moment(THIS.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
            // THIS.getDays();
           
            // });

            // window.jQuery(".input-group.end_date")
            // .datepicker({
            // format: "dd/mm/yyyy",
            // todayHighlight: true,
            // autoclose:true
            // // endDate: "+0d",
            // })
            // .off("change")
            // .change((e) => {
            // {
                // if ($('#nav_link2').attr('class') === 'nav-item active') {
                                        
                // } else {
                //     $('#nav_link2').addClass('active')
                // }
                // THIS.props.changeInput("scheduleEndDate", e.target.value);
                
                // THIS.getDays();
                // THIS.calculateSalary(e,
                //     moment(THIS.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                //     moment(THIS.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                //     moment(THIS.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                //     moment(THIS.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                //     THIS.props.salaryBased,
                //     false
                // )
                // THIS.setHoursAndDays(1, moment(THIS.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"), moment(e.target.value, "DD/MM/YYYY").format("MM/DD/YYYY"));
            // } 
        // });
        });
    }
    
    componentDidUpdate() {
        let THIS = this
        $(document).ready(function() {
            window.jQuery('#time_pic_start').datetimepicker({
                format: 'hh:mm A',
                stepping: 30,
                icons: {
                    up: "fa fa-angle-up",
                    down: "fa fa-angle-down"
                }
            }).on('dp.change', function (e) {  
                // THIS.props.changeInput("scheduleStartTime", e.target.value);
                // THIS.setHoursAndDays(2, e.target.value, THIS.props.scheduleEndTime);
                // THIS.calculateSalary(e,
                //     THIS.props.scheduleStartDate,
                //     THIS.props.scheduleStartTime,
                //     THIS.props.scheduleEndDate,
                //     THIS.props.scheduleEndTime,
                //     THIS.props.salaryBased,
                //     false
                // );
                // if ($('#nav_link2').attr('class') === 'nav-item active') {
                    
                // } else {
                //     $('#nav_link2').addClass('active')
                // }
            });  
            window.jQuery('#time_pic_end').datetimepicker({
                format: 'hh:mm A',
                stepping: 30,
                icons: {
                    up: "fa fa-angle-up",
                    down: "fa fa-angle-down"
                }
            }).on('dp.change', function (e) {  
               
                // THIS.props.changeInput("scheduleEndTime", e.target.value);
                // THIS.setHoursAndDays(2, THIS.props.scheduleStartTime, e.target.value);
                // THIS.calculateSalary(e,
                //     THIS.props.scheduleStartDate,
                //     THIS.props.scheduleStartTime,
                //     THIS.props.scheduleEndDate,
                //     THIS.props.scheduleEndTime,
                //     THIS.props.salaryBased,
                //     false
                // );
                // if ($('#nav_link2').attr('class') === 'nav-item active') {
                    
                // } else {
                //     $('#nav_link2').addClass('active')
                // }
            });  
            window.$(".selectpicker").selectpicker('refresh');
        })
        
        
        // if (THIS.props.job_created_status === 1
        // || THIS.props.job_created_status ===2
        // || THIS.props.job_created_status ===3
        // ) {
        //     setTimeout(function(){
        //         THIS.props.setShow(false)
        //     }, 4000)
        // }
        // if (THIS.state.alertStatus ===1) {
        //     setTimeout(function(){
        //         THIS.setState({
        //             show:false,
        //             varient:"",
        //             alertStatus:0,
        //             errors:[]
        //         })
        //     }, 4000)
           
        // }
        let path = window.location.pathname.split('/')[1]
        if (path === 'edit' || path === 'similar') {
        
            $('#nav_link1 span').addClass('n__filled-active')
            $('#nav_link2 span').addClass('n__filled-active')
            $('#nav_link3 span').addClass('n__filled-active')
            $('#nav_link4 span').addClass('n__filled-active')
            $('#nav_link5 span').addClass('n__filled-active')
        }
        // if (this.state.errors.amount === '' && this.state.errors.jobPosition === '' && this.state.errors.vacancy === '') {
        //     // console.log("industry")
        //     $('#nav_link1').addClass('active')
        // } else {
        //     $('#nav_link1').removeClass('active')
        // }

    }

    componentWillUnmount () {
        if (this.props.job_created_status === 1
            || this.props.job_created_status ===2
            || this.props.job_created_status ===3
        ) {
            // setTimeout(function(){
                this.props.setShow(false)
            // }, 4000)
        } if (this.state.alertStatus ===1) {
            // setTimeout(function(){
            this.setState({
                show:false,
                varient:"",
                alertStatus:0,
                errors:[]
            })
            // }, 4000)
        }
    }
    getDays() {
        if (this.props.scheduleStartDate !== '' && this.props.scheduleEndDate !== '') {
            // console.log(this.props.scheduleStartDate, 'this.props.scheduleStartDate')
            var start_date = new Date(moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
            // console.log(start_date, 'start_date')
            var end_date = new Date(moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
            var day = 1000*60*60*24;
            var diff = (end_date.getTime()- start_date.getTime())/day;
            var dateArr = []
            for (var i=0; i<=diff; i++) {
                var xx = start_date.getTime()+day*i;
                var date_day = new Date(xx).toLocaleString('en-us', {weekday:'short'})
                dateArr.push(date_day);
            }
            var newDayArray = []
            
            this.props.days_format_array.length > 0 && this.props.days_format_array.map(o => {
                if (dateArr.includes(o.day_name) === true) {
                    newDayArray.push({
                        class:'',
                        day_name:o.day_name
                    })
                } else {
                    newDayArray.push({
                        class:'in-active',
                        day_name:o.day_name
                    })
                }
                
            })
            this.props.setSchedule(
                newDayArray
            )
        }
    }
    
    setHoursAndDays(dayOrHour, start, end) {
        // console.log("start and end" , start, end);
        let errors = this.props.errors;
        if (dayOrHour === 1) {
            var new_date1 = new Date(start); 
            var new_date2 = new Date(end); 
            var Difference_In_Time = new_date2.getTime() - new_date1.getTime(); 
            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24) + 1; 
            // console.log(Difference_In_Days, 'Difference_In_Days')
            this.props.changeInput("number_of_days",
                Difference_In_Days
            )
        } else {
            var converted_startTime = moment(start, "HH:mm");
            var converted_endTime = moment(end, "HH:mm");
            var duration = moment.duration(converted_endTime.diff(converted_startTime));
            var hours = parseInt(duration.asHours());
            if(converted_startTime > converted_endTime){
                
                errors.scheduleStartTime = "Start Time must be less than the End Time";
            } else {
                errors.scheduleStartTime = "";
            }
            this.props.updateErrors(errors);
            
            if (hours < 4) {
                errors.scheduleEndTime = "Hours should be minimum 4 hrs";
                this.props.updateErrors(errors);
            } else {
                errors.scheduleEndTime = "";
                this.props.updateErrors(errors);
            }
            var minutes = parseInt(duration.asMinutes())-hours*60;
            let hours_minutes = hours + '.' +minutes
            this.props.changeInput("number_of_hours",hours_minutes)
    
        }
    }
    calculateSalary(inputSal, startDate, startTime, endDate, endTime, salaryBase, check) {
        // console.log("start and end time" , startDate, endDate, startTime, endTime);
        let dynamicAdminFee = 0
        
        if (this.props.salaryContributions 
            && this.props.salaryContributions.adminFee 
            && this.props.salaryContributions.adminFee.admin_fee
            && this.props.salaryContributions.adminFee.admin_fee.admin_fee
            && this.props.salaryContributions.adminFee.admin_fee.admin_fee !== '0' &&
            this.props.salaryContributions.adminFee.admin_fee.admin_fee !== 'null'
            ) {
            
            dynamicAdminFee = parseInt(this.props.salaryContributions.adminFee.admin_fee.admin_fee)
        }
        console.log(startDate, startTime, endDate, endTime, salaryBase, 'daaataaasss')
        let input = check ? inputSal: this.props.amount
        // console.log(input, 'inputval')
        let salary = Number(input).toFixed(2)            
        let totalSalary  = 0.00
        if (salaryBase === 'Per Hour' || salaryBase === 'Per Day') {
            var converted_startTime=moment(startTime, "HH:mm");
            var converted_endTime=moment(endTime, "HH:mm");
            var duration = moment.duration(converted_endTime.diff(converted_startTime));
            var hours = parseInt(duration.asHours());
            var minutes = parseInt(duration.asMinutes())-hours*60;
            let salaryPerMinutes = '';
            if (minutes !== 0) {
                if (minutes <= 15 &&  minutes > 0) {
                    salaryPerMinutes = salary*(1/4)
                } else if (minutes <= 30 && minutes >= 16) {        
                    salaryPerMinutes = salary*(1/2).toFixed(2)
                } else if (minutes >= 31 && minutes <= 45) {
                    salaryPerMinutes = salary*(3/4).toFixed(2)
                } else if (minutes >= 46 && minutes <= 59) {
                    salaryPerMinutes = salary*(3/5).toFixed(2)
                } else {
                    salaryPerMinutes = 0.00    
                }
            } else {
                salaryPerMinutes = 0.00
            }
            // console.log(salaryPerMinutes, 'salaryPerMinutes')
            let salaryPerHour = parseInt((hours * salary).toFixed(2)) + parseInt(salaryPerMinutes) ; 
            // console.log(salaryPerHour, 'salaryPerHour')
            var new_date1 = new Date(startDate); 
            var new_date2 = new Date(endDate); 
            // To calculate the time difference of two dates 
            var Difference_In_Time = new_date2.getTime() - new_date1.getTime(); 
            // To calculate the no. of days between two dates 
            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24); 
            // console.log(Difference_In_Days, 'Difference_In_Days')
            if (salaryBase === 'Per Day') {
                totalSalary = ((Difference_In_Days+1) * salary).toFixed(2)
            } else {
                totalSalary = ((Difference_In_Days+1) * salaryPerHour).toFixed(2)
            }
                  
        } else if (salaryBase === 'Week' || salaryBase === 'Month') {
            let salaryPerDay = 0.00;
            let start_date = moment(new Date(startDate)).format('YYYY-MM-DD')
            let end_date = moment(new Date(endDate)).format('YYYY-MM-DD')
            let salaryPerBased = 0.00;
            // let curr_Day = moment(endDate).format('YYYY-MM-DD')
            // console.log(end_date)
            var currDay = moment(start_date);
            var finishDay = moment(end_date);
            var diff = moment.duration(finishDay.diff(currDay));
            let months = diff.months()
            let weeks = Math.floor(diff.asWeeks())
            let day = diff.days()%7
            
            if (salaryBase === 'Week') {
                salaryPerDay = (salary/7 * day).toFixed(2)
                // console.log(salaryPerDay, 'salaryPerDay')
                salaryPerBased = (salary * weeks).toFixed(2)
                // console.log(salaryPerBased, 'salaryPerBased')
            } else {
                salaryPerDay = (salary/30 * day).toFixed(2)
                // console.log(salaryPerDay, 'salaryPerDay')
                if (months !== 0) {
                    salaryPerBased = (salary * months).toFixed(2)
                    // console.log(salaryPerBased, 'salaryPerBased')
                } 
            }
            
            totalSalary = parseInt(salaryPerBased) + parseInt(salaryPerDay)          
            // console.log(totalSalary, 'totalSalary')
            // console.log(salaryPerBased + salaryPerDay, 'salaryPerBased')
            // console.log(diff.months() + " months, " + diff.weeks() + " weeks, " + diff.days()%7 + " days.");
            // console.log(Math.floor(diff.asWeeks()) + " weeks, " + diff.days()%7 + " days.");
        } else {
               
        }
        let below_sixty_employer_paid_Salary = 0.00;
        let above_sixty_employee_reduced_Salary = 0.00;
        let below_sixty_employer_socso = 0.00;
        let below_sixty_employer_eis = 0.00;
        let below_sixty_employee_reduced_Salary = 0.00;
        let below_sixty_fjAdminFee = 0.00;
        let above_sixty_employer_epf = 0.00;
        let below_sixty_employer_epf = 0.00;
        let above_sixty_employer_paid_Salary = 0.00;
        let above_sixty_fjAdminFee = 0.00;
        let below_sixty_employee_socso= 0.00;
        let below_sixty_employee_eis = 0.00;
        let below_sixty_employee_epf = 0.00;
        if (input <= 5000) {
            if (this.props.salaryContributions &&
                this.props.salaryContributions.contributions &&
                this.props.salaryContributions.contributions.length > 0 &&
                this.props.salaryContributions.contributions[0].employer_epf &&
                this.props.salaryContributions.contributions[0].employee_epf
                ) {
                    below_sixty_employer_epf =  (totalSalary * (parseInt(this.props.
                    salaryContributions.contributions[0].employer_epf)/100)).toFixed(2)
                    below_sixty_employee_epf =  (totalSalary * (parseInt(this.props.
                    salaryContributions.contributions[0].employee_epf)/100)).toFixed(2)
                    
            } else {
                below_sixty_employer_epf =  (totalSalary * (13/100)).toFixed(2)
                below_sixty_employee_epf =  (totalSalary * (9/100)).toFixed(2)
                
            }
            if (this.props.salaryContributions &&
            this.props.salaryContributions.contributions &&
            this.props.salaryContributions.contributions.length > 0 &&
            this.props.salaryContributions.contributions[1].employer_epf
            ) {
                above_sixty_employer_epf =  (totalSalary * (parseInt(this.props.
                salaryContributions.contributions[1].employer_epf)/100)).toFixed(2)
            } else {
                above_sixty_employer_epf =  (totalSalary * (4/100)).toFixed(2)
            }
            
            // above_sixty_employee_epf =  (totalSalary * (11/100)).toFixed(2)
        } else {
            if (this.props.salaryContributions &&
                this.props.salaryContributions.contributions &&
                this.props.salaryContributions.contributions.length > 0 &&
                this.props.salaryContributions.contributions[2].employer_epf
                ) {
                    below_sixty_employer_epf =  (totalSalary * (parseInt(this.props.
                    salaryContributions.contributions[2].employer_epf)/100)).toFixed(2)
                    below_sixty_employee_epf =  (totalSalary * (parseInt(this.props.
                    salaryContributions.contributions[2].employee_epf)/100)).toFixed(2)
            } else {
                below_sixty_employer_epf =  (totalSalary * (12/100)).toFixed(2)
                below_sixty_employee_epf =  (totalSalary * (11/100)).toFixed(2)
            }
            
        }
        if (this.props.salaryContributions &&
            this.props.salaryContributions.contributions &&
            this.props.salaryContributions.contributions.length > 0 &&
            this.props.salaryContributions.contributions[2].employer_eis &&
            this.props.salaryContributions.contributions[2].employee_eis &&
            this.props.salaryContributions.contributions[2].employer_socso &&
            this.props.salaryContributions.contributions[2].employee_socso) {
            below_sixty_employer_socso = (totalSalary * (parseFloat(
                this.props.salaryContributions.contributions[2].employer_socso
            )/100)).toFixed(2)
            
            below_sixty_employer_eis = (totalSalary * (parseFloat(
                this.props.salaryContributions.contributions[2].employer_eis
            )/100)).toFixed(2)
            below_sixty_employee_socso = (totalSalary * (parseFloat(
                this.props.salaryContributions.contributions[2].employee_socso
            )/100)).toFixed(2)
            below_sixty_employee_eis = (totalSalary * (parseFloat(
                this.props.salaryContributions.contributions[2].employee_eis
            )/100)).toFixed(2)
        } else {
            below_sixty_employer_socso = (totalSalary * (1.75/100)).toFixed(2)
            below_sixty_employer_eis = (totalSalary * (0.2/100)).toFixed(2)
            below_sixty_employee_socso = (totalSalary * (0.5/100)).toFixed(2)
            below_sixty_employee_eis = (totalSalary * (0.2/100)).toFixed(2)
        }
        
        below_sixty_employer_paid_Salary = (Number(totalSalary) + 
        Number(below_sixty_employer_epf) + Number(below_sixty_employer_socso) + Number(below_sixty_employer_eis)).toFixed(2)
        below_sixty_employee_reduced_Salary = (Number(totalSalary) -
        Number(below_sixty_employee_epf) - Number(below_sixty_employee_socso) -
        Number(below_sixty_employee_eis)).toFixed(2) 
        if (dynamicAdminFee !== 0) {
            let fjadmin = (dynamicAdminFee/100).toFixed(2)
            below_sixty_fjAdminFee = (below_sixty_employer_paid_Salary * fjadmin).toFixed(2)
        } else {
            below_sixty_fjAdminFee = (below_sixty_employer_paid_Salary * (10/100)).toFixed(2)
        }
        
        above_sixty_employer_epf =  (totalSalary * (4/100)).toFixed(2)
        above_sixty_employee_reduced_Salary = parseInt(totalSalary).toFixed(2)
        above_sixty_employer_paid_Salary = (Number(totalSalary) + 
        Number(above_sixty_employer_epf)).toFixed(2)
        if (dynamicAdminFee !== 0) {
            let fjadmin = (dynamicAdminFee/100).toFixed(2)
            above_sixty_fjAdminFee = (above_sixty_employer_paid_Salary * fjadmin).toFixed(2)   
        } else {
            above_sixty_fjAdminFee = (above_sixty_employer_paid_Salary * (10/100)).toFixed(2)   
        }

        this.props.changeInput("aboveSixtySalary", {
            employer_epf:above_sixty_employer_epf,
            employer_socso:"0.00", 
            employer_eis:"0.00",
            actual_salary_paid_by_employer:above_sixty_employer_paid_Salary,
            total_salary_base_by_employer:totalSalary,
            employee_epf:"0.00",
            employee_socso:"0.00",
            employee_eis:"0.00",
            reduced_salary_for_employee:above_sixty_employee_reduced_Salary,
            fj_admin_fee:above_sixty_fjAdminFee,
        })
        this.props.changeInput("belowSixtySalary",{     
            employer_epf:below_sixty_employer_epf,
            employer_socso:below_sixty_employer_socso,
            employer_eis:below_sixty_employer_eis,
            actual_salary_paid_by_employer:below_sixty_employer_paid_Salary,
            total_salary_base_by_employer: totalSalary,
            employee_epf:below_sixty_employee_epf,
            employee_socso : below_sixty_employee_socso,
            employee_eis:below_sixty_employee_eis,
            reduced_salary_for_employee:below_sixty_employee_reduced_Salary,
            fj_admin_fee: below_sixty_fjAdminFee,
            // totalSalary:totalSalary
        }
            
        )
    }

    handleChange(event, elname) { 

        let errors = this.props.errors;
        let valid = true;
        let value, name;
        // if (event.target === undefined) {
        //     name = elname
        //     value = event;
        // } else {
        //     value = event.target.value
        //     name = event.target.name
        // }
        console.log(elname, event, 'elname - value ..............................')
        if(elname === 'start_date_one' || 
           elname === 'start_date_end' ||
           elname === 'start_date_time_start' ||
           elname === 'start_date_time_end' || elname === 'amount'){
            name = elname;
            value = event
            console.log(name, value, "name - value ......................................")
        } else {
            value = event.target.value
            name = event.target.name
        }
    
        
        this.setState({
            [name]: value
        });
        
        switch (name) {
            
            case 'select_industry':
                if (value.length === null) {
                    errors.industry_new = 'Cannot be empty'
                } else {
                    errors.industry_new = ''
                }
                this.props.updateErrors(errors);
                console.log(this.props.jobPosition, typeof(this.props.jobPosition),"posi ****************")
                console.log(this.props.industry_new, "indus ****************")
                if ((value !== null && value !=='' && value.length!== 0) && (isNaN(this.props.jobPosition) &&  this.props.jobPosition!== '') && errors.vacancy === '') {
                    console.log("industry")
                    $('#nav_link1 span').addClass('n__filled-active')
                } else {
                    $('#nav_link1 span').removeClass('n__filled-active')
                }
                
            break;
            case 'jobPosition':

                if (value.length === null) {
                    errors.jobPosition = 'Cannot be empty'
                } else {    
                    errors.jobPosition = ''
                }
    
                if (errors.industry_new === '' && (value !== null && value !=='' && value.length!== 0) && errors.vacancy === '') {
                    console.log("posi")
                    $('#nav_link1 span').addClass('n__filled-active')
                } else {
                    $('#nav_link1 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
            case 'vacancy':

                errors.vacancy = (value.length === null || value.length === 0)? 'Cannot be empty': '';
                if (errors.industry_new === '' && errors.jobPosition === '' && (value !== null && value !=='' && value.length!== 0)) {
                    $('#nav_link1 span').addClass('n__filled-active')
                } else {
                    $('#nav_link1 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
            case 'start_date_one':

                if (value.length === null) {
                    errors.scheduleStartDate = 'Cannot be empty'
                } else {
                    errors.scheduleStartDate = ''
                }
                console.log(value, value.length, errors.scheduleEndDate, errors.scheduleEndTime, errors.scheduleStartTime, "start date ..........................")
                if ((value !== null && value !=='' && value.length!== 0) && errors.scheduleEndDate === '' && errors.scheduleEndTime === '' && errors.scheduleStartTime === '') {
                    $('#nav_link2 span').addClass('n__filled-active')
                } else {
                    $('#nav_link2 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
            case 'start_date_end':

                if (value.length === null) {
                    errors.scheduleEndDate = 'Cannot be empty'
                } else {
                    errors.scheduleEndDate = ''
                }
                console.log(value, value.length, errors.scheduleStartDate  , errors.scheduleEndTime  , errors.scheduleStartTime , "date end ......................")
                console.log(this.props.scheduleEndTime, "props end time ..................");
                if ((value !== null && value !=='' && value.length!== 0) && errors.scheduleStartDate === '' && errors.scheduleEndTime === '' && errors.scheduleStartTime === '') {
                    $('#nav_link2 span').addClass('n__filled-active')
                } else {
                    $('#nav_link2 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
            case 'start_date_time_start':

                if (value.length === null) {
                    errors.scheduleStartTime = 'Cannot be empty'
                } else {
                    errors.scheduleStartTime = ''
                }
                console.log(value, value.length, errors.scheduleStartDate, errors.scheduleEndTime, errors.scheduleEndDate, "start time ....................")
                if ((value !== null && value !=='' && value.length!== 0) && errors.scheduleStartDate === '' && errors.scheduleEndTime === '' && errors.scheduleEndDate === '') {
                
                    $('#nav_link2 span').addClass('n__filled-active')
                } else {
                    $('#nav_link2 span').removeClass('n__filled-active')
                }
               
                this.props.updateErrors(errors);
            break;
            case 'start_date_time_end':

                
                if (value.length === null) {
                    errors.scheduleEndTime = 'Cannot be empty'
                } else {
                    errors.scheduleEndTime = ''
                }
                console.log(value, value.length, errors.scheduleStartDate, errors.scheduleStartTime, errors.scheduleEndDate, "end time ....................")
        
                if ((value !== null && value !=='' && value.length!== 0) && errors.scheduleStartDate === '' && errors.scheduleStartTime === '' && errors.scheduleEndDate === '') {
                
                    $('#nav_link2 span').addClass('n__filled-active')
                } else {
                    $('#nav_link2 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
            
            case 'job-title':

                if(value.length > 0) {
                    errors.jobTitle = ""
                } else {
                    errors.jobTitle = 'Cannot be empty'
                }
                console.log(errors.jobDesc , errors.amount , value )
                if (errors.jobDesc === '' && errors.amount === '' && (value !== null && value !=='' && value.length!== 0)) {
                    $('#nav_link3 span').addClass('n__filled-active')
                } else {
                    $('#nav_link3 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
    
            case 'job-desc':

                if(value.length > 0) {
                    errors.jobDesc = ""
                } else {
                    errors.jobDesc = 'Cannot be empty'
                }
                console.log(errors.jobTitle , errors.amount , value)
                if (errors.jobTitle === '' && errors.amount === '' && (value !== null && value !=='' && value.length!== 0)) {
                    $('#nav_link3 span').addClass('n__filled-active')
                } else {
                    $('#nav_link3 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;

            case 'amount':
                console.log(value);
                if(value.length > 0) {
                    errors.amount = ""
                } else {
                    errors.amount = 'Cannot be empty'
                }
             
                console.log(errors.jobDesc , errors.jobTitle , value, value.length)
                console.log(errors.jobDesc === '' && errors.jobTitle === '' && (value !== null && value !=='' && value.length!== 0));
                if (errors.jobDesc === '' && errors.jobTitle === '' && (value !== null && value !=='' && value.length!== 0)) {
                    console.log("condition true ...................")
                    $('#nav_link3 span').addClass('n__filled-active')
                } else {
                   
                    $('#nav_link3 span').removeClass('n__filled-active')
                }
                
                // errors.location = (value.length >= 400)? 'Please keep your description within 400 characters with spaces': '';
                this.props.updateErrors(errors);
            break;

            case 'gender':

                console.log(value, "gender ................");
                if(value.length > 0) {
                    errors.gender  = "";
                } else {
                    errors.gender = "Cannot be empty"
                }
                if (value !== null && value !=='' && value.length!== 0) {
                    $('#nav_link4 span').addClass('n__filled-active')
                } else {
                   
                    $('#nav_link4 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
           
    
            case 'location':
            

                if(value.length > 0) {
                    errors.location = ""
                } else {
                    errors.location = 'Cannot be empty'
                }
                if (value !== null && value !=='' && value.length!== 0) {
                    $('#nav_link5 span').addClass('n__filled-active')
                } else {
                    $('#nav_link5 span').removeClass('n__filled-active')
                }
                
                this.props.updateErrors(errors);
            break;
      
            
            default:
                this.props.updateErrors(errors);
            break;
            }
        }

    async validateForm(field_name) {
        await this.props.resetForm({
          errors: {},
        });
        let valid = true;
        let errors = this.props.errors;

        if (this.props.industry_new === "") {
            valid = false;
            errors.industry_new = "Cannot be Empty";
            this.setState({
              errors:[...this.state.errors, "Industry name cannot be empty"]
            })
            scroller.scrollTo('step-1', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.jobPosition === "") {
            valid = false;
            errors.jobPosition = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Job Position cannot be empty"]
            })
            scroller.scrollTo('step-1', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.vacancy === "") {
            valid = false;
            errors.vacancy = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Vacancy cannot be empty"]
            })
             scroller.scrollTo('step-1', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.jobTitle === "") {
            valid = false;
            errors.jobTitle = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Job Title cannot be empty"]
            })
            scroller.scrollTo('step-3', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.jobDesc === "") {
            valid = false;
            errors.jobDesc = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Job description cannot be empty"]
            })
            scroller.scrollTo('step-3', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.jobDesc !== "" && this.props.jobDesc.length > 500) {
            valid = false;
            errors.jobDesc = "Job description should be less than 500 characters";
            this.setState({
                errors:[...this.state.errors, "Job description should be less than 500 characters"]
            })
            scroller.scrollTo('step-3', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        // if (this.props.currency == "") {
        //     valid = false;
        //     errors.currency = "Cannot be Empty";
        // }
        if (this.props.amount === "" || isNaN(this.props.amount)) {
            valid = false;
            errors.amount = "Cannot be Empty";
            
            this.setState({
                errors:[...this.state.errors, "Amount cannot be empty"]
            })
            scroller.scrollTo('step-3', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.gender === "") {
            valid = false;
            errors.gender = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Gender cannot be empty"]
            })
            scroller.scrollTo('step-4', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        
        if (this.props.scheduleStartDate == "") {
            valid = false;
            errors.scheduleStartDate = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Job Start Date cannot be empty"]
            })
            scroller.scrollTo('step-2', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.scheduleStartTime == "") {
            valid = false;
            errors.scheduleStartTime = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Job Start Time cannot be empty"]
            })
            scroller.scrollTo('step-2', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.scheduleEndDate == "") {
            valid = false;
            errors.scheduleEndDate = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, "Job End Date cannot be empty"]
            })
            scroller.scrollTo('step-2', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }

        let path = window.location.pathname.split('/')[1]
        if (path !== 'edit' && this.props.scheduleStartDate) {
            var day = new Date();
            var nextDay = new Date(day);
            nextDay.setDate(day.getDate()+1);
            if (new Date(moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY")) > nextDay) {
                // alert(nextDay); // May 01 2000   
            } else {
                valid = false
                this.setState({
                    errors:[...this.state.errors, `Start Date must be greater than 
                    ${moment(new Date(nextDay)).format("MMMM Do YYYY")}`]
                })
                errors.scheduleEndDate = `Start Date must be greater than 
                ${moment(new Date(nextDay)).format("MMMM Do YYYY")}`;
                scroller.scrollTo('step-2', {duration: 1500,
                    delay: 100,
                    smooth: 'easeInOutQuint'})
            }
            
        }
        if (this.props.scheduleEndTime == "") {
            valid = false;
            errors.scheduleEndTime = "Cannot be Empty";
            this.setState({
                errors:[...this.state.errors, `End Time Cannot be Empty`]
            })
            scroller.scrollTo('step-2', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
        if (this.props.scheduleStartTime !== "" && this.props.scheduleEndTime !== "") {
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();
            today = mm + '/' + dd + '/' + yyyy;
            let start_time = new Date(today +' '+ this.props.scheduleStartTime)
            let end_time = new Date(today +' '+ this.props.scheduleEndTime)
            if (end_time.getTime() <= start_time.getTime()) {
                errors.scheduleEndTime = "End time should be greater than the start time";
                this.setState({
                    errors:[...this.state.errors, `End time should be greater than the start time`]
                })
                valid = false;
                scroller.scrollTo('step-2', {duration: 1500,
                    delay: 100,
                    smooth: 'easeInOutQuint'})
            }
        }
        
        if (this.props.location == "") {
            valid = false;
            this.setState({
                errors:[...this.state.errors, `Location Cannot be Empty`]
            })
            errors.location = "Cannot be Empty";
            scroller.scrollTo('step-5', {duration: 1500,
                delay: 100,
                smooth: 'easeInOutQuint'})
        }
       
        this.props.updateErrors(errors);
       if (!valid) {
           this.setState({
               show:true,
               varient:"danger",
               alertStatus:1
           })
       }
        return valid;
    }

    async createjobpost() {

        console.log(this.props.lat, "create job ..................."); 
        console.log(this.props.lon,  "create job ..................."); 
        console.log(this.props.amount, 'amou')
        if (await this.validateForm()) {
            let salary_base_changed =""
            let path = window.location.pathname.split('/')[1]
            if (this.props.salaryBased  === 'Per Hour') { 
                salary_base_changed = 'per-hour'
            } else if (this.props.salaryBased  === 'Per Day') {            
                salary_base_changed = 'per-day'
            } else if (this.props.salaryBased  === 'Week') {              
                salary_base_changed = 'per-week'
            } else {            
                salary_base_changed = 'per-month'
            }
            
            let pathId = window.location.pathname.split('/')[3]
            if (path === 'edit') {
                this.props.editJob({
                jobId : pathId,
                industry:this.props.industry,
                show_position:this.state.show_position,
                industry_type_id:this.props.industry_new,
                jobPosition:this.state.show_position ? 
                    this.state.jobPosition :this.props.jobPosition,
                epf:this.state.epf,
                socso:this.state.socso,
                totalSalary:this.state.totalSalary,
                fjAdminFee:this.state.fjAdminFee,
                vacancy:this.props.vacancy,
                jobTitle:this.props.jobTitle,
                jobDesc:this.props.jobDesc,
                jobType:this.props.jobType,
                salaryBased:salary_base_changed,
                currency:this.props.currency,
                amount:this.props.amount,
                lat:this.props.lat,
                lon:this.props.lon,
                gender:this.props.gender,
                save_as_draft:0,
                other_reqs:[{
                    'requirement':this.props.requirements_work_experience},
                    {'requirement':this.props.requirements_language},
                    {'requirement':this.props.requirements_age_limit}],
                number_of_hours:this.props.number_of_hours,
                number_of_days:this.props.number_of_days,
                salary_detail:[{
                    "salary_for":"below 60",
                    "employee_epf":this.props.belowSixtySalary.employee_epf,
                    "employee_socso":this.props.belowSixtySalary.employee_socso,
                    "employee_eis":this.props.belowSixtySalary.employee_eis,
                    "actual_salary_paid_by_employer":
                    this.props.belowSixtySalary.actual_salary_paid_by_employer,
                    "total_salary_base_by_employer":
                    this.props.belowSixtySalary.total_salary_base_by_employer,
                    "employer_epf":this.props.belowSixtySalary.employer_epf,
                    "employer_socso":this.props.belowSixtySalary.employer_socso,
                    "employer_eis":this.props.belowSixtySalary.employer_eis,
                    "reduced_salary_for_employee":this.props.belowSixtySalary.reduced_salary_for_employee,
                    "fj_admin_fee":this.props.belowSixtySalary.fj_admin_fee,
                    "totalSalary":this.props.belowSixtySalary.totalSalary
                },{
                    "salary_for":"above 60",
                    "total_salary":this.props.aboveSixtySalary.totalSalary,
                    "employer_epf":this.props.aboveSixtySalary.employer_epf ,
                    "employer_socso":this.props.aboveSixtySalary.employer_socso ,
                    "employer_eis":this.props.aboveSixtySalary.employer_eis,
                    "actual_salary_paid_by_employer":this.props.aboveSixtySalary.actual_salary_paid_by_employer,
                    "total_salary_base_by_employer":this.props.aboveSixtySalary.total_salary_base_by_employer,
                    "employee_epf":this.props.aboveSixtySalary.employee_epf,
                    "employee_socso":this.props.aboveSixtySalary.employee_socso,
                    "employee_eis":this.props.aboveSixtySalary.employee_eis,
                    "reduced_salary_for_employee":this.props.aboveSixtySalary.reduced_salary_for_employee,
                    "fj_admin_fee":this.props.aboveSixtySalary.fj_admin_fee,
                }
                ],
                scheduleStartDate:moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                scheduleStartTime:moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                scheduleEndDate:moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                scheduleEndTime:moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                shifts: [{
                    start_time:this.props.shiftBreakStart,
                    end_time:this.props.shiftBreakEnd,
                }],
                location: [
                    {"location":this.props.location}
                ]
                })
            } else {
               
                this.props.createJob({
                    
                    jobPosition:this.state.show_position ? 
                    this.state.jobPosition :this.props.jobPosition,
                    industry:this.props.industry,
                    industry_type_id:this.props.industry_new,
                    vacancy:this.props.vacancy,
                    jobTitle:this.props.jobTitle,
                    jobDesc:this.props.jobDesc,
                    jobType:this.props.jobType,
                    show_position:this.state.show_position,
                    salaryBased:salary_base_changed,
                    currency:this.props.currency,
                    epf:this.props.epf,
                    socso:this.state.socso,
                    totalSalary:this.state.totalSalary,
                    fjAdminFee:this.state.fjAdminFee,
                    amount:this.props.amount,
                    save_as_draft:0,
                    gender:this.props.gender,
                    lat:this.props.marker.lat,
                    lon:this.props.marker.lon,
                    other_reqs:[{
                        'requirement':this.props.requirements_work_experience},
                        {'requirement':this.props.requirements_language},
                        {'requirement':this.props.requirements_age_limit
                    }],
                    number_of_hours:this.props.number_of_hours,
                    number_of_days:this.props.number_of_days,
                    salary_detail:[{
                        "salary_for":"below 60",
                        "employee_epf":this.props.belowSixtySalary.employee_epf,
                        "employee_socso":this.props.belowSixtySalary.employee_socso,
                        "employee_eis":this.props.belowSixtySalary.employee_eis,
                        "actual_salary_paid_by_employer":
                        this.props.belowSixtySalary.actual_salary_paid_by_employer,
                        "total_salary_base_by_employer":
                        this.props.belowSixtySalary.total_salary_base_by_employer,
                        "employer_epf":this.props.belowSixtySalary.employer_epf,
                        "employer_socso":this.props.belowSixtySalary.employer_socso,
                        "employer_eis":this.props.belowSixtySalary.employer_eis,
                        "reduced_salary_for_employee":this.props.belowSixtySalary.reduced_salary_for_employee,
                        "fj_admin_fee":this.props.belowSixtySalary.fj_admin_fee,
                        "totalSalary":this.props.belowSixtySalary.totalSalary
                    },{
                    "salary_for":"above 60",
                    "total_salary":this.props.aboveSixtySalary.totalSalary,
                    "employer_epf":this.props.aboveSixtySalary.employer_epf ,
                    "employer_socso":this.props.aboveSixtySalary.employer_socso ,
                    "employer_eis":this.props.aboveSixtySalary.employer_eis,
                    "actual_salary_paid_by_employer":this.props.aboveSixtySalary.actual_salary_paid_by_employer,
                    "total_salary_base_by_employer":this.props.aboveSixtySalary.total_salary_base_by_employer,
                    "employee_epf":this.props.aboveSixtySalary.employee_epf,
                    "employee_socso":this.props.aboveSixtySalary.employee_socso,
                    "employee_eis":this.props.aboveSixtySalary.employee_eis,
                    "reduced_salary_for_employee":this.props.aboveSixtySalary.reduced_salary_for_employee,
                    "fj_admin_fee":this.props.aboveSixtySalary.fj_admin_fee,
                    }
                    ],
                    scheduleStartDate:moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                    scheduleStartTime:moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                    scheduleEndDate:moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                    scheduleEndTime:moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                    shifts: [{
                        start_time:this.props.shiftBreakStart,
                        end_time:this.props.shiftBreakEnd,
                    }],
                    location: [
                        {"location":this.props.location}
                    ]
                    
                })
            }
        }
        
        
    }
    createDraftpost() {
    
            let salary_base_changed =""
            let path = window.location.pathname.split('/')[1]
            if (this.props.salaryBased  === 'Per Hour') {
                
                salary_base_changed = 'per-hour'
            } else if (this.props.salaryBased  === 'Per Day') {
                
                salary_base_changed = 'per-day'
            } else if (this.props.salaryBased  === 'Week') {
                
                salary_base_changed = 'per-week'
            } else {
                
                salary_base_changed = 'per-month'
            }
            
            let pathId = window.location.pathname.split('/')[3]
            if (path === 'edit') {
                this.props.editJob({
                jobId : pathId,
                save_as_draft:1,
                industry:this.props.industry,
                industry_type_id:this.props.industry_new,
                jobPosition:this.state.show_position ? 
                    this.state.jobPosition :this.props.jobPosition,
                epf:this.state.epf,
                socso:this.state.socso,
                totalSalary:this.state.totalSalary,
                fjAdminFee:this.state.fjAdminFee,
                vacancy:this.props.vacancy,
                show_position:this.state.show_position,
                jobTitle:this.props.jobTitle,
                jobDesc:this.props.jobDesc,
                jobType:this.props.jobType,
                salaryBased:salary_base_changed,
                currency:this.props.currency,
                amount:this.props.amount,
                lat:this.props.marker.lat,
                lon:this.props.marker.lon,
                gender:this.props.gender,
                other_reqs:[{
                    'requirement':this.props.requirements_work_experience},
                    {'requirement':this.props.requirements_language},
                    {'requirement':this.props.requirements_age_limit}],
                number_of_hours:this.props.number_of_hours,
                number_of_days:this.props.number_of_days,
                salary_detail:[{
                    "salary_for":"below 60",
                    "employee_epf":this.props.belowSixtySalary.employee_epf,
                    "employee_socso":this.props.belowSixtySalary.employee_socso,
                    "employee_eis":this.props.belowSixtySalary.employee_eis,
                    "actual_salary_paid_by_employer":
                    this.props.belowSixtySalary.actual_salary_paid_by_employer,
                    "total_salary_base_by_employer":
                    this.props.belowSixtySalary.total_salary_base_by_employer,
                    "employer_epf":this.props.belowSixtySalary.employer_epf,
                    "employer_socso":this.props.belowSixtySalary.employer_socso,
                    "employer_eis":this.props.belowSixtySalary.employer_eis,
                    "reduced_salary_for_employee":this.props.belowSixtySalary.reduced_salary_for_employee,
                    "fj_admin_fee":this.props.belowSixtySalary.fj_admin_fee,
                    "totalSalary":this.props.belowSixtySalary.totalSalary
                },{
                    "salary_for":"above 60",
                    "total_salary":this.props.aboveSixtySalary.totalSalary,
                    "employer_epf":this.props.aboveSixtySalary.employer_epf ,
                    "employer_socso":this.props.aboveSixtySalary.employer_socso ,
                    "employer_eis":this.props.aboveSixtySalary.employer_eis,
                    "actual_salary_paid_by_employer":this.props.aboveSixtySalary.actual_salary_paid_by_employer,
                    "total_salary_base_by_employer":this.props.aboveSixtySalary.total_salary_base_by_employer,
                    "employee_epf":this.props.aboveSixtySalary.employee_epf,
                    "employee_socso":this.props.aboveSixtySalary.employee_socso,
                    "employee_eis":this.props.aboveSixtySalary.employee_eis,
                    "reduced_salary_for_employee":this.props.aboveSixtySalary.reduced_salary_for_employee,
                    "fj_admin_fee":this.props.aboveSixtySalary.fj_admin_fee,
                }
                ],
                scheduleStartDate:moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                scheduleStartTime:moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                scheduleEndDate:moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                scheduleEndTime:moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                shifts: [{
                    start_time:this.props.shiftBreakStart,
                    end_time:this.props.shiftBreakEnd,
                }],
                location: [
                    {"location":this.props.location}
                ]
                })
            } else {
                this.props.createJob({
                    jobPosition:this.state.show_position ? 
                    this.state.jobPosition :this.props.jobPosition,
                    industry:this.props.industry,
                    industry_type_id:this.props.industry_new,
                    vacancy:this.props.vacancy,
                    jobTitle:this.props.jobTitle,
                    jobDesc:this.props.jobDesc,
                    jobType:this.props.jobType,
                    salaryBased:salary_base_changed,
                    show_position:this.state.show_position,
                    save_as_draft:1,
                    currency:this.props.currency,
                    epf:this.props.epf,
                    socso:this.state.socso,
                    totalSalary:this.state.totalSalary,
                    fjAdminFee:this.state.fjAdminFee,
                    amount:this.props.amount,
                    gender:this.props.gender,
                    lat:this.props.marker.lat,
                    lon:this.props.marker.lon,
                    other_reqs:[{
                        'requirement':this.props.requirements_work_experience},
                        {'requirement':this.props.requirements_language},
                        {'requirement':this.props.requirements_age_limit
                    }],
                    number_of_hours:this.props.number_of_hours,
                    number_of_days:this.props.number_of_days,
                    salary_detail:[{
                        "salary_for":"below 60",
                        "employee_epf":this.props.belowSixtySalary.employee_epf,
                        "employee_socso":this.props.belowSixtySalary.employee_socso,
                        "employee_eis":this.props.belowSixtySalary.employee_eis,
                        "actual_salary_paid_by_employer":
                        this.props.belowSixtySalary.actual_salary_paid_by_employer,
                        "total_salary_base_by_employer":
                        this.props.belowSixtySalary.total_salary_base_by_employer,
                        "employer_epf":this.props.belowSixtySalary.employer_epf,
                        "employer_socso":this.props.belowSixtySalary.employer_socso,
                        "employer_eis":this.props.belowSixtySalary.employer_eis,
                        "reduced_salary_for_employee":this.props.belowSixtySalary.reduced_salary_for_employee,
                        "fj_admin_fee":this.props.belowSixtySalary.fj_admin_fee,
                        "totalSalary":this.props.belowSixtySalary.totalSalary
                    },{
                    "salary_for":"above 60",
                    "total_salary":this.props.aboveSixtySalary.totalSalary,
                    "employer_epf":this.props.aboveSixtySalary.employer_epf ,
                    "employer_socso":this.props.aboveSixtySalary.employer_socso ,
                    "employer_eis":this.props.aboveSixtySalary.employer_eis,
                    "actual_salary_paid_by_employer":this.props.aboveSixtySalary.actual_salary_paid_by_employer,
                    "total_salary_base_by_employer":this.props.aboveSixtySalary.total_salary_base_by_employer,
                    "employee_epf":this.props.aboveSixtySalary.employee_epf,
                    "employee_socso":this.props.aboveSixtySalary.employee_socso,
                    "employee_eis":this.props.aboveSixtySalary.employee_eis,
                    "reduced_salary_for_employee":this.props.aboveSixtySalary.reduced_salary_for_employee,
                    "fj_admin_fee":this.props.aboveSixtySalary.fj_admin_fee,
                    }
                    ],
                    scheduleStartDate:moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                    scheduleStartTime:moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                    scheduleEndDate:moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                    scheduleEndTime:moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                    shifts: [{
                        start_time:this.props.shiftBreakStart,
                        end_time:this.props.shiftBreakEnd,
                    }],
                    location: [
                        {"location":this.props.location}
                    ]
                    
                })
            }
        }
    render() {
        var url_path = window.location.pathname.split('/')[1] 
        var errors = this.props.errors;
        
        
        return (
            <>
            <div className="container-fluid">
            <Header />            
            {
            
            /* Main Content Starts here */}
            <section className="row main-content">
            
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col">
                    <h1>
                    <Link to = "#" className="back" 
                          onClick={() => { 
                              history.goBack();
                            this.props.resetForm({
                                errors: {},
                                industry:'',
                                industry_new:'',
                                jobPosition:'',
                                vacancy:'',
                                jobTitle:'',
                                jobDesc:'',
                                jobType:'',
                                salaryBased:'',
                                currency:'',
                                amount:'',
                                showAmount:'',
                                gender:'',
                                requirements_work_experience:'',
                                requirements_language:'',
                                requirements_age_limit:'',
                                scheduleStartDate:'',
                                scheduleStartTime:'',
                                scheduleEndDate:'',
                                scheduleEndTime:'',
                                shiftBreakStart:'',
                                shiftBreakEnd:'',
                                location:'',
                                aboveSixtySalary:0,
                                belowSixtySalary:0
                                });
                            }}>
                        <img src="/assets/images/app/back-arrow.svg" alt="icon" />
                    </Link>
                    {url_path === 'edit' ? 'Edit Job' : 'Post Job'} 
                    </h1>
                    {/* <div>
                    <Link to = "/employer_posted_job_list">
                    <button

                    className="btn btn-gray mr-2"
                    onClick = {() => {
                        
                        this.props.resetForm({
                        errors: {},
                        industry:'',
                        industry_new:'',
                        jobPosition:'',
                        vacancy:'',
                        jobTitle:'',
                        jobDesc:'',
                        jobType:'',
                        salaryBased:'',
                        currency:'',
                        amount:'',
                        gender:'',
                        requirements_work_experience:'',
                        requirements_language:'',
                        requirements_age_limit:'',
                        scheduleStartDate:'',
                        scheduleStartTime:'',
                        scheduleEndDate:'',
                        scheduleEndTime:'',
                        shiftBreakStart:'',
                        shiftBreakEnd:'',
                        location:'',
                        });
                    }
                    }
                    >
                      
                        Cancel
                        
                    </button>
                    </Link>
                    <a href="javascript:;" 
                    className="btn btn-blue"
                    disabled = {this.props.loading ? true : false}
                    onClick = {() => {this.createjobpost()}}
                    >
                        {this.props.loading ? "Loading..." :
                        url_path === 'edit' ? 'Save Job':'Create Job'
                        }
                    </a>
                    </div> */}
                </div>
                <div className="col-12">
                    <Alert
                    show={this.props.show}
                    variant={this.props.varient}
                    dismissible
                    onClose={() => this.props.setShow(false)}
                    >
                    <strong>
                        {this.props.job_created_status === 1
                        ? "Success!"
                        : "Error!"}
                    </strong>{" "}
                    {this.props.showMsg}
                    </Alert>
                    <Alert
                    show={this.state.show}
                    variant={this.state.varient}
                    dismissible
                    onClose={() => this.setState({
                        show:false,
                        varient:"",
                        alertStatus:0,
                        errors:[]
                    })}
                    >
                    <strong>
                        {this.state.alertStatus === 1
                        && "Sorry!"
                        }
                    </strong>{" "}
                    {this.state.errors && this.state.errors.length > 0 &&
                    this.state.errors[0]
                    }
                    </Alert>
                    <div className="snippet-box p-3 p-md-5 form-section">
                    <ul className="nav nav-pills add-pointer d-none" role="tablist" >
                        <li className="nav-item">
                        <ScrollLink className="nav-link n__steps-button" 
                        activeClass="active" 
                        id = "nav_link1" 
                        data-toggle="pill"
                        onSetActive={this.handleSetActive}
                        onSetInactive={this.handleSetInactive}
                        to="step-1"
                        spy={true} 
                        smooth={true}
                        role="tab" aria-selected="true"><span>1</span></ScrollLink>
                        </li>
                        <li className="nav-item">
                        <ScrollLink className="nav-link n__steps-button" 
                                    id = "nav_link2" 
                                    data-toggle="pill" 
                                    to="step-2"
                                    spy={true} 
                                    smooth={true} 
                                    role="tab" aria-selected="false"><span>2</span></ScrollLink>
                        </li>
                        <li className="nav-item">
                        <ScrollLink className="nav-link n__steps-button" id = "nav_link3" data-toggle="pill" to="step-3"
                        spy={true} 
                        smooth={true} role="tab" aria-selected="false"><span>3</span></ScrollLink>
                        </li>
                        <li className="nav-item">
                        <ScrollLink className="nav-link n__steps-button" id = "nav_link4" data-toggle="pill" to="step-4"
                        spy={true} 
                        smooth={true} role="tab" aria-selected="false"><span>4</span></ScrollLink>
                        </li>
                        <li className="nav-item">
                        <ScrollLink className="nav-link n__steps-button" id = "nav_link5" data-toggle="pill" to="step-5"
                        spy={true} 
                        smooth={true} role="tab" aria-selected="false"><span>5</span></ScrollLink>
                        </li>
                    </ul>
                    <div className="tab-content">
                        <div className="tab-pane fade show active" id="step-1" role="tabpanel">
                        {
                            window.location.pathname.split('/')[1] === 'similar'?
                            <p className = "text-danger center"
                            style = {{
                                textAlign : 'center',
                                opacity :'inherit'
                            }}
                            >Please update the start date and end date of the job
                        </p> :
                         <p>Request workers by telling us who you need, your job requirements, and schedules.
                         <br/>
                         We send pre-vetted workers directly to your business
                     </p>     
                        }
                       
                        <form className="custom-form row">
                            <div className="col-12 form-legend mt-2 mb-4" id="step-1" >
                            <Element name="step-1">
                            <span className="subtitle">Create Job</span>
                            <label className="col-12 px-0 mt-2">Choose a job position and set how many Workers you need.</label>
                            <div className="row mt-1">
                                <div className="col-md-4">
                                <label>Select Functions</label>
                                <select
                                className={this.props.errors.industry_new &&
                                    this.props.errors.industry_new.length >0 ?
                                    "form-control selectpicker":
                                    "form-control selectpicker"
                                }
                                id = {`select_industry`}
                                data-live-search="true"    
                                name= "select_industry"
                                title = "Choose Industry"
                                value = {this.props.industry_new}
                                onChange = {(e) => {
                                    
                                    this.props.changeInput("industry_new", 
                                    e.target.value);
                                    this.handleChange(e, 'industry_new')
                                    
                                    this.props.changeInput("industry", 
                                    $('#select_industry').find("option:selected").text());
                                    this.props.getPositions(e.target.value)
                                    
                                }}
                                >
                                    
                                    {this.props.industries &&
                                    this.props.industries.length > 0 &&
                                    this.props.industries.map((i,k) => {
                                        return <option
                                        key = {k}
                                        // id = {i.id}
                                        value = {i.id}>{i.industry_type}</option>
                                        
                                    })}
                                </select>
                                {this.props.errors.industry_new &&
                                this.props.errors.industry_new.length > 0 ? (
                                <small className="text-danger">
                                    {this.props.errors.industry_new}
                                </small>
                                ) : (
                                ""
                                )}
                                </div>
                                <div className="col-md-4">
                                <label>Job Position</label>
                                <select name="category" 
                                className={this.props.errors.jobPosition &&
                                    this.props.errors.jobPosition.length > 0 ?
                                    "form-control selectpicker ":
                                    "form-control selectpicker"
                                }
                                
                                name = "jobPosition"
                                data-live-search="true"    
                                title = "Choose Position"
                                value = {this.props.jobPosition}
                                onChange = {(e) => {
                                    console.log(e.target.value,'e.target.value')
                                    if (e.target.value.trim() === 'Others' || 
                                    e.target.value.trim() === 'others'
                                    ) {
                                        
                                        this.setState({
                                            show_position : true,
                                            jobPosition:""
                                        })
                                        this.props.changeInput("jobPosition", e.target.value);
                                    } else {
                                        this.setState({
                                            show_position : false,
                                            jobPosition:''
                                        })
                                        this.props.changeInput("jobPosition", e.target.value);
                                    this.handleChange(e, 'jobPosition');
                                    }
                                    
                                }}
                                >
                                    {

                                    this.props.positions &&
                                    
                                    this.props.positions.map((i,k) => {
                                        return <option
                                        key = {k}
                                        value = {i}>{i}</option>
                                        
                                    })
                                    }
                                </select>
                                <input
                                placeholder = "Enter Position"
                                className = {this.state.show_position ? "form-control mt-2":
                                "form-control d-none mt-2"}
                                onChange = {(e) => {
                                    this.setState({
                                        jobPosition:e.target.value
                                    });
                                    this.handleChange(e, 'new_jobPosition');
                                }}
                                value = {this.state.jobPosition}
                                >
                                </input>
                                {this.props.errors.jobPosition &&
                                this.props.errors.jobPosition.length > 0 ? (
                                <small className="text-danger">
                                    {this.props.errors.jobPosition}
                                </small>
                                ) : (
                                ""
                                )}
                                </div>
                                <div className="col-md-4">
                                <label>Number of Vacancies</label>
                                <input type="text" 
                                className={this.props.errors.vacancy &&
                                    this.props.errors.vacancy.length > 0 ?
                                    "form-control border-danger":
                                    "form-control"}
                                value = {this.props.vacancy}
                                name = "vacancy"
                                onChange = {(e) => {
                                    this.props.changeInput("vacancy", e.target.value); 
                                    this.handleChange(e, 'vacancy');
                                    if (this.props.industry !== '' 
                                    && e.target.value !== ''
                                    && this.props.jobPosition !== '') {
                                       
                                        // $('#nav_link1').addClass('active')
                                    }
                                }}
                                placeholder={10}
                                />
                                {this.props.errors.vacancy &&
                                this.props.errors.vacancy.length > 0 ? (
                                <small className="text-danger">
                                    {this.props.errors.vacancy}
                                </small>
                                ) : (
                                ""
                                )}
                                </div>
                            </div>
                            </Element>
                            </div>
                            
                            <div className="col-lg-8 col-md-12 form-legend mb-4" id="step-2">
                            <Element name="step-2">
                            <span className="subtitle">Schedule</span>
                            <label className="col-12 px-0 mt-2">When do you need Workers?</label>
                            <div className="row mt-1">
                                <div className="col-md-6 form-group mb-1">
                                <label>Start On</label>
                                <DatePicker 
                                className={
                                    this.props.errors.scheduleStartDate &&
                                    this.props.errors.scheduleStartDate.length > 0 ? 
                                    "form-control border-danger" :"form-control" 
                                }
                                dateFormat = 'dd/MM/yyyy'
                                placeholderText = "DD/MM/YYYY"
                                minDate={new Date()}
                                name = "start_date_one"
                                selected={this.props.scheduleStartDate} 
                                onChange={(date) => {

                                this.props.changeInput("scheduleStartDate", date);
                                this.props.changeInput("scheduleEndDate", date);
                                if (date === null || date === '') {
                                    errors.scheduleStartDate = 'Cannot be empty';
                                    this.props.updateErrors(errors);
                                } else {
                                    errors.scheduleStartDate = '';
                                    this.props.updateErrors(errors);
                                }
                                this.handleChange(date, 'start_date_one');
                                this.handleChange(this.props.scheduleEndDate ? this.props.scheduleEndDate : date, 'start_date_end');
                                // this.props.changeInput("showDateStart", e.target.value);
                                this.calculateSalary(date,
                                    moment(date, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                    moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                                    moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                    moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                                    this.props.salaryBased,
                                    false
                                )
                                this.setHoursAndDays(1, moment(date, "DD/MM/YYYY").format("MM/DD/YYYY"), moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
                                this.getDays();
                               
                                }} 
                                />
                                {/* <div className="input-group date start_date mar-t-no" data-date-format="dd/mm/yyyy">
                                    <input type="text" className={
                                    this.props.errors.scheduleStartDate &&
                                    this.props.errors.scheduleStartDate.length > 0 ? 
                                    "form-control border-danger" :"form-control" 
                                    }
                                    onSelect = {(e) => {
                                        if (e.target.value) {
                                           
                                            if (new Date(moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY")) <= new Date(moment(e.target.value, "DD/MM/YYYY").format("MM/DD/YYYY"))) {
                                                errors.scheduleEndDate = "End Date must be greater than the Start Date";
                                            } else {
                                                errors.scheduleEndDate = "";
                                            }
                                            this.props.updateErrors(errors);
                                        }
                                    }}
                                    value = {this.props.scheduleStartDate}
                                    />
                                    <div className={this.props.errors.scheduleStartDate &&
                                    this.props.errors.scheduleStartDate.length > 0 ? 
                                    "input-group-addon border-danger" :"input-group-addon"} >
                                    <img src="/assets/images/calendar-icon.svg" alt="icon" />
                                    </div>
                                </div> */}
                                {this.props.errors.scheduleStartDate &&
                                    this.props.errors.scheduleStartDate.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.scheduleStartDate}
                                    </small>
                                    ) : (
                                    ""
                                )}
                                </div>
                                <div className="col-md-6 form-group mb-1">
                                <label>Start Time</label>
                                <DatePicker 
                                className={this.props.errors.scheduleStartTime &&
                                    this.props.errors.scheduleStartTime.length > 0 ? 
                                    "form-control time-picker border-danger" :"form-control time-picker"
                                }
                                placeholderText = "HH:MM"
                                selected={this.props.scheduleStartTime}
                                name = "start_date_time_start"
                                onChange={(date) => {
                                    if (date === null || date === '') {
                                        errors.scheduleStartTime = 'Cannot be empty';
                                        this.props.updateErrors(errors);
                                    } else {
                                        errors.scheduleStartTime = '';
                                        this.props.updateErrors(errors);
                                    }
                                    this.handleChange(date, 'start_date_time_start');
                                    this.props.changeInput("scheduleStartTime", date);
                                    this.setHoursAndDays(2, moment(date, "hh:mm A").format("HH:mm"), moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"));
                                    this.calculateSalary(date,
                                        moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                        moment(date, "hh:mm A").format("HH:mm"),
                                        moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                        moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                                        this.props.salaryBased,
                                        false
                                    );
                                    // if ($('#nav_link2').attr('class') === 'nav-item active') {
                                        
                                    // } else {
                                    //     $('#nav_link2').addClass('active')
                                    // }
                                }}
                               
                                showTimeSelect
                                showTimeSelectOnly
                                timeIntervals={30}
                                timeCaption="Time"
                                dateFormat="h:mm aa"
                                
                                />
                                {/* <div className="input-group time mar-t-no">
                                <input type="text" 
                                className={this.props.errors.scheduleStartTime &&
                                    this.props.errors.scheduleStartTime.length > 0 ? 
                                    "form-control time-picker border-danger" :"form-control time-picker"
                                }
                           
                                id = "time_pic_start"
                                    value = {this.props.scheduleStartTime}
                                />
                                <div className="input-group-addon">
                                    <img src={process.env.PUBLIC_URL+"/assets/images/app/clock-icon.svg"} alt="icon" 
                                />
                                </div>
                                </div> */}
                                {this.props.errors.scheduleStartTime &&
                                    this.props.errors.scheduleStartTime.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.scheduleStartTime}
                                    </small>
                                    ) : (
                                    ""
                                )}
                                </div>
                            </div>
                            <div className="row mt-1">
                                <div className="col-md-6 form-group">
                                <label>End On</label>
                                {/* <div className="input-group date end_date mar-t-no" data-date-format="dd/mm/yyyy"
                                id = "to_date"
                                > */}
                                <DatePicker 
                                className={
                                this.props.errors.scheduleEndDate &&
                                this.props.errors.scheduleEndDate.length > 0 ? 
                                "form-control border-danger" :"form-control"
                                }
                                name = "start_date_end"
                                dateFormat = 'dd/MM/yyyy'
                                placeholderText = "DD/MM/YYYY"
                                disabled = {this.props.scheduleStartDate === '' ? true:
                                false}
                                selected={this.props.scheduleEndDate ? this.props.scheduleEndDate:this.props.scheduleStartDate} 
                                minDate={this.props.scheduleStartDate}
                                onChange={(date) => {
                                    if (date === null || date === '') {
                                        errors.scheduleEndDate = 'Cannot be empty';
                                        this.props.updateErrors(errors);
                                    } else {
                                        errors.scheduleEndDate = '';
                                        this.props.updateErrors(errors);
                                    }
                                    this.handleChange(date, 'start_date_end');
                                    this.props.changeInput("scheduleEndDate", date);
                                    // this.props.changeInput("showDateStart", e.target.value);
                                    this.calculateSalary(date,
                                        moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                        moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                                        moment(date, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                        moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                                        this.props.salaryBased,
                                        false
                                    )
                                this.setHoursAndDays(1, moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"), moment(date, "DD/MM/YYYY").format("MM/DD/YYYY"));
                                this.getDays();
                               
                                }} 
                                />
                                    {/* <input type="text" 
                                    className={
                                        this.props.errors.scheduleEndDate &&
                                    this.props.errors.scheduleEndDate.length > 0 ? 
                                    "form-control border-danger" :"form-control"
                                    }
                                    
                                    value = {this.props.scheduleEndDate}
                                    onSelect = {(e) => {
                                        if (e.target.value) {
                                            if (new Date(moment(e.target.value, "DD/MM/YYYY").format("MM/DD/YYYY")) <= new Date(moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"))) {
                                               
                                                errors.scheduleEndDate = "End Date must be greater than the Start Date";
                                            } else {
                                                errors.scheduleEndDate = "";
                                            }
                                            this.props.updateErrors(errors);                              
                                        }                                        
                                    }}
                                     /> */}
                                    {/* <div className={    this.props.errors.scheduleEndDate &&
                                    this.props.errors.scheduleEndDate.length > 0 ? 
                                    "input-group-addon border-danger" :"input-group-addon"}>
                                    <img src="/assets/images/calendar-icon.svg" alt="icon" />
                                    </div>
                                    
                                </div> */}
                                {this.props.errors.scheduleEndDate &&
                                    this.props.errors.scheduleEndDate.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.scheduleEndDate}
                                    </small>
                                    ) : (
                                    ""
                                )}
                                </div>
                                <div className="col-md-6 form-group">
                                <label>End Time</label>
                                <DatePicker 
                                className={this.props.errors.scheduleEndTime &&
                                    this.props.errors.scheduleEndTime.length > 0 ? 
                                    "form-control border-danger" :"form-control"}
                                placeholderText = "HH:MM"
                                name = "start_date_time_end"
                                selected={this.props.scheduleEndTime}
                                disabled = {this.props.scheduleStartTime === '' ? true:
                                false}
                                onChange={(date) => {
                                    if (date === null || date === '') {
                                        errors.scheduleEndTime = 'Cannot be empty';
                                        this.props.updateErrors(errors);
                                    } else {
                                        errors.scheduleEndTime = '';
                                        this.props.updateErrors(errors);
                                    }
                                    this.handleChange(date, 'start_date_time_end');
                                    this.props.changeInput("scheduleEndTime", date);
                                    this.setHoursAndDays(2, moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"), moment(date, "hh:mm A").format("HH:mm"));
                                    this.calculateSalary(date,
                                        moment(this.props.scheduleStartDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                        moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                                        moment(this.props.scheduleEndDate, "DD/MM/YYYY").format("MM/DD/YYYY"),
                                        moment(date, "hh:mm A").format("HH:mm"),
                                        this.props.salaryBased,
                                        false
                                    );
                                    // if ($('#nav_link2').attr('class') === 'nav-item active') {
                                        
                                    // } else {
                                    //     $('#nav_link2').addClass('active')
                                    // }
                                }}

                                showTimeSelect
                                showTimeSelectOnly
                                timeIntervals={30}
                                timeCaption="Time"
                                dateFormat="h:mm aa"
                                />
                                {/* <div className="input-group time mar-t-no">
                                <input 
                                type="text" 
                                className={this.props.errors.scheduleEndTime &&
                                    this.props.errors.scheduleEndTime.length > 0 ? 
                                    "form-control border-danger" :"form-control"}
                                id = "time_pic_end"
                                value = {this.props.scheduleEndTime}
                                onBlur = {(e) => {
                                    var stt = new Date("May 26, 2016 " + this.props.scheduleStartTime);
                                    stt = stt.getTime();
                                    
                                    var endt= new Date("May 26, 2016 " + e.target.value);
                                    endt = endt.getTime();
                                    
                                    if(stt > endt){
                                        errors.scheduleStartTime = "Start Time must be less than the End Time";
                                    } else {
                                        errors.scheduleStartTime = "";
                                    }
                                    this.props.updateErrors(errors);
                                }}
                                name
                                 />
                                <div className="input-group-addon">
                                    <img src={process.env.PUBLIC_URL+"/assets/images/app/clock-icon.svg"} alt="icon" 
                                    />
                                </div>
                                </div> */}
                             
                                 {this.props.errors.scheduleEndTime &&
                                    this.props.errors.scheduleEndTime.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.scheduleEndTime}
                                    </small>
                                    ) : (
                                    ""
                                )}
                                </div>
                               
                            </div>
                            </Element>
                            </div>
                            <div className="col-12 form-legend mt-1 mb-4" id="step-3">

                            <Element name="step-3">
                            <span className="subtitle">Job Details</span>
                            <label className="col-12 px-0 mt-2">Tell us about the job and your requirements.</label>
                            <div className="row mt-1">
                                <div className="col-lg-8 col-md-12 form-group">
                                <label>Job Title</label>
                                <input type="text" 
                                className={
                                    this.props.errors.jobTitle &&
                                    this.props.errors.jobTitle.length > 0 ?
                                    "form-control border-danger" :"form-control" 
                                }
                                placeholder={this.props.jobPosition}
                                name = "job-title"
                                value = {this.props.jobTitle}
                                onChange = {(e) => {
                                    this.handleChange(e, 'job-title');
                                    // if ($('#nav_link3').attr('class') === 'nav-item active') {
                                    //     $('#nav_link3').addClass('active')
                                    // } else {
                                        
                                    //     $('#nav_link3').addClass('active')
                                    // }
                                    this.props.changeInput("jobTitle", e.target.value);
                                    
                                }}
                                />
                                {this.props.errors.jobTitle &&
                                this.props.errors.jobTitle.length > 0 ? (
                                <small className="text-danger">
                                    {this.props.errors.jobTitle}
                                </small>
                                ) : (
                                ""
                                )}
                                <i className="info-icon" data-toggle="tooltip" title="
                                <p className='mb-2'>Here are some good examples:</p>
                                <ul>
                                <li>Picker and Packer needed at Jakarta Warehouse</li>
                                <li>Server needed at private function</li>
                                </ul>
                                ">
                                <img src="/assets/images/app/info-icon.svg" alt="icon" />
                                </i>
                                </div>
                                <div className="col-lg-8 col-md-12 form-group">
                                <label>Job Description(Only 500 characters are allowed)</label>
                                <textarea className={ this.props.errors.jobDesc &&
                                    this.props.errors.jobDesc.length > 0 ?
                                    "form-control border-danger" :"form-control" } 
                                value = {this.props.jobDesc}
                                id="job_desc"
                                name="job-desc"
                                onChange = {(e) => {
                                    let errors = this.props.errors;
                                  
                                    // if ($('#nav_link3').attr('class') === 'nav-item active') {
                                        
                                    // } else {
                                    //     $('#nav_link3').addClass('active')
                                    // }
                                    this.handleChange(e, 'job-desc')
                                    this.props.changeInput("jobDesc", e.target.value);
                                }}
                                placeholder={"Whether you need workers for your warehouse or delivery drivers for your fleet, Flexijobs can help. Switch to our end-to-end staffing platform and quickly find qualified workers tailored to your needs."} />
                                <div className="n__desc-error">
                                
                                {this.props.errors.jobDesc &&
                                this.props.errors.jobDesc.length > 0 ? (
                                <small className="text-danger">
                                    {this.props.errors.jobDesc}
                                </small>
                                ) : (
                                ""
                                )}<small
                                className = ""
                                >
                                ({this.props.jobDesc.length+"/500"})
                                </small></div>
                                <i className="info-icon" data-toggle="tooltip" title="
                                <p class='mb-2'>A good description includes:</p>
                                <ul>
                                <li>What a Worker needs to do</li>
                                <li>The type of Worker you’re looking for</li>
                                <li>Anything unique about the job or your company</li>
                                <li>Additional benefits you are offering Flexijobs</li>
                                </ul>
                                ">
                                <img src="/assets/images/app/info-icon.svg" alt="icon" />
                                </i>
                                </div>
                                {/* <div className="col-lg-8 col-md-12 form-group">
                                <label>Job Type</label>
                                <div className="col">
                                    <div className="row">
                                    <div className="mr-3">
                                        <label className="input">
                                        <input type="radio" 
                                        checked = {this.props.jobType === 'Part-Time' 
                                        ? true : false}
                                        value = {this.props.jobType}
                                        name = "job-type"
                                        onChange = {(e) => {
                                            // if ($('#nav_link3').attr('class') === 'nav-item active') {
                                        
                                            // } else {
                                            //     $('#nav_link3').addClass('active')
                                            // }
                                            this.props.changeInput("jobType", 'Part-Time');
                                        }}
                                        name="job-type" />
                                       
                                        Part-Time (Minimum 4 Hours)
                                        </label>
                                    </div>
                                    <div>
                                    <label className="input">
                                        <input type="radio" 
                                        name="job-type"
                                        checked = {this.props.jobType === 'Temp-Job' 
                                        ? true : false}
                                        value = {this.props.jobType}
                                        onChange = {(e) => {
                                           
                                            this.props.changeInput("jobType", 'Temp-Job');
                                        }} />
                                       
                                        Temp Job (More Then 1 Day)
                                        </label>
                                    </div>
                                    {this.props.errors.jobType &&
                                        this.props.errors.jobType.length > 0 ? (
                                        <small className="text-danger">
                                            {this.props.errors.jobType}
                                        </small>
                                        ) : (
                                        ""
                                    )}
                                    </div>
                                </div>
                                </div> */}
                                {/* <div className="col-lg-8 col-md-12 form-group">
                                <div className="row">
                                    <div className="col-md-6">
                                    <label>Salary Based</label>
                                    <select 
                                    className="form-control selectpicker"
                                    id = "salary_based"
                                    value = {this.props.salaryBased}
                                    onChange = {(e) => {
                                        if ($('#nav_link3').attr('class') === 'nav-item active') {
                                        
                                        } else {
                                            $('#nav_link3').addClass('active')
                                        }
                                        this.props.changeInput("salaryBased", e.target.value);
                                        this.calculateSalary(e,
                                            this.props.scheduleStartDate,
                                            this.props.scheduleStartTime,
                                            this.props.scheduleEndDate,
                                            this.props.scheduleEndTime,
                                            this.props.salaryBased, 
                                            false
                                        )
                                    }}
                                    >   
                                        <option value = "Per Hour">Per Hour</option>
                                        <option value = "Per Day">Per Day</option>
                                        <option value = "Week">Week</option>
                                        <option value = "Month">Month</option>
                                    </select>
                                    {this.props.errors.salaryBased &&
                                    this.props.errors.salaryBased.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.salaryBased}
                                    </small>
                                    ) : (
                                    ""
                                    )}
                                    </div>
                                    </div>
                                    <label className="mt-2 mb-0">Base wage and allowance will be paid automatically to workers at each payment cycle. Tax and social security deductions will only be calculated on the base wage.</label>
                                    </div> */}
                                    <div className="col-lg-8 col-md-12 form-group">
                                    <div className="row">
                                    {/* <div className="col-md-3">
                                    <label>Currency</label>
                                    <select 
                                    className="form-control selectpicker"
                                    id = "select_currency"
                                    value = {this.props.currency}
                                    onChange = {(e) => {
                                        if ($('#nav_link3').attr('class') === 'nav-item active') {
                                        
                                        } else {
                                            $('#nav_link3').addClass('active')
                                        }
                                        this.props.changeInput("currency", e.target.value);
                                    }}
                                    >
                                    
                                        <option value = "RM">RM</option>
                                        <option value = "SGD">SGD</option>
                                        <option value = "USD">USD</option>
                                        <option value = "CAD">CAD</option>
                                    </select>
                                    {this.props.errors.currency &&
                                    this.props.errors.currency.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.currency}
                                    </small>
                                    ) : (
                                    ""
                                    )}
                                    </div> */}
                                   
                                <div className="col-md-6">
                                    <label>Amount</label>
                                    <CurrencyInput
                                    id="input-example"
                                    name="amount"
                                    className={ this.props.errors.amount &&
                                        this.props.errors.amount.length > 0 ?
                                        "form-control border-danger" :"form-control" }
                                    value = {this.props.showAmount}
                                    onValueChange={(value, name) => {
                                        console.log("onvalue change", value);
                                        this.handleChange(value !== undefined ? value : '', name);
                                        this.props.changeInput("amount", value);
                                        this.props.changeInput("showAmount", value)
                                        this.calculateSalary(value,
                                            moment(this.props.scheduleStartDate,"DD/MM/YYYY").format("MM/DD/YYYY"),
                                            moment(this.props.scheduleStartTime, "hh:mm A").format("HH:mm"),
                                            moment(this.props.scheduleEndDate,"DD/MM/YYYY").format("MM/DD/YYYY"),
                                            moment(this.props.scheduleEndTime, "hh:mm A").format("HH:mm"),
                                            this.props.salaryBased,
                                            true
                                        )   
                                    }
                                    }
                                    />
                                    {/* <input type="text" 
                                    className="form-control" 
                                    placeholder={100} name 
                                    value = {this.props.showAmount}
                                    onChange = {(e) => {{
                                        if ($('#nav_link3').attr('class') === 'nav-item active') {
                                        
                                        } else {
                                            $('#nav_link3').addClass('active')
                                        }
                                        this.props.changeInput("amount", e.target.value);
                                        this.props.changeInput("showAmount", e.target.value)
                                        this.calculateSalary(e,
                                            this.props.scheduleStartDate,
                                            this.props.scheduleStartTime,
                                            this.props.scheduleEndDate,
                                            this.props.scheduleEndTime,
                                            this.props.salaryBased,
                                            true
                                        )
                                    }}}
                                    /> */}
                                     {this.props.errors.amount &&
                                    this.props.errors.amount.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.amount}
                                    </small>
                                    ) : (
                                    ""
                                    )}
                                </div>
                                </div>
                                <div className="row mt-3">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <h4 className="salary-title">Salary Calculation</h4>
                                    <table className="salary-table">
                                    <tbody>
                                        <tr>
                                        <td>Total Salary</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(this.props.belowSixtySalary.total_salary_base_by_employer)? '0.00':this.props.belowSixtySalary.total_salary_base_by_employer)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>EPF</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(this.props.belowSixtySalary.employer_epf)? '0.00':this.props.belowSixtySalary.employer_epf)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>SOCSO</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(this.props.belowSixtySalary.employer_socso)? '0.00':this.props.belowSixtySalary.employer_socso)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>EIS</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(this.props.belowSixtySalary.employer_eis)? '0.00':this.props.belowSixtySalary.employer_eis)
                                            }
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                        <td>Flexi job Admin Fee</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(this.props.belowSixtySalary.fj_admin_fee)? '0.00':this.props.belowSixtySalary.fj_admin_fee)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>Total Cost</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(this.props.belowSixtySalary.actual_salary_paid_by_employer)? '0.00':Number(this.props.belowSixtySalary.actual_salary_paid_by_employer)+Number(this.props.belowSixtySalary.fj_admin_fee))
                                            }
                                            </td>
                                        </tr>
                                       
                                        {/* <tr>
                                        <td>Employee Epf</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            this.props.belowSixtySalary.employee_epf
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>Employee Socso</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            this.props.belowSixtySalary.employee_socso
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>Employee Eis</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            this.props.belowSixtySalary.employee_eis
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>Reduced Salary For Employee</td>
                                        <td>RM 
                                            {
                                            this.props.belowSixtySalary && 
                                            this.props.belowSixtySalary.reduced_salary_for_employee
                                            }
                                            </td>
                                        </tr> */}
                                     
                                    </tbody></table>
                                </div>
                                {/* <div className="col-md-6">
                                    <h4 className="salary-title">Above 60</h4>
                                    <table className="salary-table">
                                    <tbody><tr>
                                        <td>EPF</td>
                                        <td>RM 
                                            {
                                            this.props.aboveSixtySalary &&
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal'}).format(isNaN(this.props.aboveSixtySalary.employer_epf) ? '0.00':this.props.aboveSixtySalary.employer_epf)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>SOCSO</td>
                                        <td>RM 
                                            {
                                            this.props.aboveSixtySalary &&
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal'}).format(isNaN(this.props.aboveSixtySalary.employer_socso)? '0.00':this.props.aboveSixtySalary.employer_socso)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>EIS</td>
                                        <td>RM 
                                            {
                                            this.props.aboveSixtySalary &&
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal'}).format(isNaN(this.props.aboveSixtySalary.employer_eis)? '0.00':this.props.aboveSixtySalary.employer_eis)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>Total Salary</td>
                                        <td>RM 
                                            {
                                            this.props.aboveSixtySalary &&
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal'}).format(isNaN(this.props.aboveSixtySalary.total_salary_base_by_employer)? '0.00':this.props.aboveSixtySalary.total_salary_base_by_employer)
                                            }
                                            </td>
                                        </tr>
                                        <tr>
                                        <td>Total Salary with Tax</td>
                                        <td>RM 
                                            {
                                                
                                            this.props.aboveSixtySalary &&
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal'}).format(isNaN(this.props.aboveSixtySalary.actual_salary_paid_by_employer)? '0.00':this.props.aboveSixtySalary.actual_salary_paid_by_employer)
                                            }
                                            </td>
                                        </tr>
                                   
                                        <tr>
                                        <td>Flexi job Admin Fee</td>
                                        <td>RM 
                                            {
                                            this.props.aboveSixtySalary &&
                                            
                                            new Intl.NumberFormat('en-US', {style: 'decimal'}).format(isNaN(this.props.aboveSixtySalary.fj_admin_fee)? '0.00':this.props.aboveSixtySalary.fj_admin_fee)
                                            }
                                            </td>
                                        </tr>
                                    </tbody>
                                    </table>
                                </div> */}
                                </div>
                                </div>
                               
                            <div className="col-12">
                                <div className="row">
                                {/* <div className="col-lg-4 col-md-12 form-group mb-2 mb-md-0">
                                    <label>Experience</label>
                                    <label className="input mt-0 mb-2">
                                    <input type="checkbox" 
                                    name="ot-req" 
                                    onChange = {(e) => {
                                        this.props.changeInput("experience", 'Beginner (0-3 Years)');
                                    }}
                                    />
                                    Beginner (0-3 Years)
                                    </label>
                                    <label className="input mb-2">
                                    <input type="checkbox" name="ot-req"
                                    onChange = {(e) => {
                                        this.props.changeInput("experience", 'Entry-Level (3-5 Years)');
                                    }}
                                    />
                                    Entry-Level (3-5 Years)
                                    </label>
                                    <label className="input">
                                    <input type="checkbox" name="ot-req" />
                                    Intermediate (5-7 Years)
                                    </label>
                                    <label className="input">
                                    <input type="checkbox" name="ot-req" />
                                    Mid-Level (7-10 Years)
                                    </label>
                                    <label className="input">
                                    <input type="checkbox" name="ot-req" />
                                    Senior-Level (&gt; 10 Years)
                                    </label>
                                </div> */}
                                
                                </div>
                                </div>   
                    </div>
                    </Element>
                    </div>

                    <div className="col-lg-8 col-md-12 form-legend mt-1" id="step-4">
                        <Element name="step-4">
                                <span className="subtitle">Additional Requirements</span>
                                <div className="row mt-2">
                               
                                <div className="col-md-6 form-group ">
                                    <label>Gender</label>
                                    <select 
                                    className={this.props.errors.gender &&
                                        this.props.errors.gender.length > 0 ?
                                        "form-control selectpicker border-danger" :"form-control selectpicker" }
                                    data-live-search="true"    
                                    title = "Choose Position"
                                    id = "select_gender"
                                    name = "gender"
                                    value = {this.props.gender}
                                    onChange = {(e) => {
                               
                                        this.handleChange(e, 'gender')
                                        this.props.changeInput("gender", e.target.value);
                                    }}
                                    >
                               
                                    
                                    <option value = "Male">Male</option>
                                    <option value = "Female">Female</option>
                                    <option value = "Male and Female">Either/or</option>
                                    
                                    </select>
                                    {this.props.errors.gender &&
                                    this.props.errors.gender.length > 0 ? (
                                    <small className="text-danger">
                                        {this.props.errors.gender}
                                    </small>
                                    ) : (
                                    ""
                                    )}
                                </div>
                                
                            </div>
                            {/* <div className="row mt-2">
                            <div className="col-md-6 form-group mb-0">
                                    <label>Additional Requirements (Optional)</label>
                                    <input type="text" 
                                        className="form-control" 
                                        
                                        value = {this.props.requirements_work_experience}
                                        onChange = {(e) => {
                                            // if ($('#nav_link4').attr('class') === 'nav-item active') {
                                                    
                                            // } else {
                                            //     $('#nav_link4').addClass('active')
                                            // }
                                            this.props.changeInput("requirements_work_experience", e.target.value);
                                        }}
                                        placeholder = "Relevent Work Experience Needed"
                                        name 
                                    />
                                
                                </div>
                            </div> */}
                            {/* <div className="row">
                                <div className="form-group col-md-6">
                                <label className="input mt-0 mb-2">
                                    <input type="checkbox" name="ot-req" />
                                    I am a Person With Disability
                                </label>
                                <input placeholder="Describe Disability" type="text" name className="form-control" />
                                </div>
                            </div> */}
                            </Element>
                        </div>
                       
                        <div className="col-lg-8 col-md-12 form-legend mt-2 mb-4" id="step-5">
                        <Element name="step-5">
                        <span className="subtitle add mb-2">
                            Location
                            {/* <a href="javascript:;" className="add-btn">
                            <img src="/assets/images/app/circle-add-btn.svg" alt="icon" />
                            </a> */}
                        </span>
                        {/* <label className="col-12 px-0 mt-2">Select your business location or create a new location</label> */}
                        <div className="row mt-2">
                            <div className="col-md-12">
                            {/* <label>Location</label> */}
                            {/* <Map google={this.props.google}
                            onReady={this.fetchPlaces}
                            visible={false}>
                                <Listing places={this.state.places} />
                            </Map> */}
                            {/* <input type="text" 
                            name = "location"
                            
                            className={this.props.errors.location &&
                                this.props.errors.location.length > 0 ? 
                                "form-control btn-map border-danger":"form-control btn-map"
                            } 
                            value = {this.props.location}
                            onChange = {(e) => {
                                this.handleChange(e, 'location')
                            
                                this.props.changeInput("location", e.target.value);
                                
                            }}
                            name = 'location'
                            placeholder="45 Jalan Tun Ismail, 50480 Kuala Lumpur…" /> */}
                            <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className={this.props.errors.location &&
                                this.props.errors.location.length > 0 ? 
                                "form-control btn-map border-danger":"form-control btn-map"
                            } 
                            onChange = {(e) => {
                                
                                this.props.changeInput("location", e.target.value);
                                console.log(e.target.value)
                            }}
                            value = {this.props.location}
                            onPlaceSelected={(place) => {
                                // console.log(place.geometry.location);
                                
                                this.setState({
                                    lati:place && place.geometry && place.geometry.location.lat(),
                                    longi:place && place.geometry && place.geometry.location.lng()
                                })
                                this.props.changeInput("lat", place && place.geometry && place.geometry.location.lat() !== '' ? place && place.geometry && place.geometry.location.lat() : this.props.lat);
                                this.props.changeInput("lon", place && place.geometry && place.geometry.location.lng() !== '' ? place && place.geometry && place.geometry.location.lng() : this.props.lon);
                                this.props.changeInput("location", place.formatted_address);
                            }}
                            options={{
                                types: ['address'],
                                // componentRestrictions: { country: "ru" },
                            }}
                            // defaultValue={this.props.location}
                            />
                            {this.props.errors.location &&
                                this.props.errors.location.length > 0 ? (
                                <small className="text-danger">
                                    {this.props.errors.location}
                                </small>
                                ) : (
                                ""
                            )}
                            </div>
                            </div>
                            </Element>
                            </div>
                        </form>
                        </div>
                    </div>
                    <div className="n__create-job-buttons">

                    <a href="javascript:;" 
                    className="btn btn-blue mr-2"
                    disabled = {this.props.loading ? true : false}
                    onClick = {() => {this.createjobpost()}}
                    >
                        {this.props.loading ? "Loading..." :
                        url_path === 'edit' ? 'Save Job':'Post Job'
                        }
                    </a>
                    <a href="javascript:;" 
                    style = {{
                        background:'#d99e32'
                    }}
                    className="btn btn-blue mr-2"
                    disabled = {this.props.loading ? true : false}
                    onClick = {() => {this.createDraftpost()}}
                    >
                        {
                        // this.props.draftLoading ? "Loading..." :
                         'Draft'
                        } 
                    </a>
                    <Link to = "/employer_posted_job_list/active">
                    <button
                    className="btn btn-gray mr-2"
                    onClick = {() => {
                        
                        this.props.resetForm({
                        errors: {},
                        industry:'',
                        industry_new: '',
                        jobPosition:'',
                        vacancy:'',
                        jobTitle:'',
                        jobDesc:'',
                        jobType:'',
                        salaryBased:'',
                        currency:'',
                        amount:'',
                        showAmount:'',
                        gender:'',
                        requirements_work_experience:'',
                        requirements_language:'',
                        requirements_age_limit:'',
                        scheduleStartDate:'',
                        scheduleStartTime:'',
                        scheduleEndDate:'',
                        scheduleEndTime:'',
                        shiftBreakStart:'',
                        shiftBreakEnd:'',
                        location:'',
                        aboveSixtySalary:0,
                        belowSixtySalary:0
                        });
                    }
                    }
                    >
                        Cancel  
                    </button>
                    </Link>
                    </div>
                    {/* <div className="n__scroll-to-top-container">
                        <button className="btn btn-gray n__scroll-to-top-button">top</button>
                    </div> */}
                    </div>
                    
                </div>
                <MapComponent
                lat = {this.state.lati}
                lon = {this.state.longi}
                />
               
                </div>
            </div>
           
            </section>
          
            
            {/* Main Content Ends here */}

            </div>
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        industry:state.Jobs.industry,
        jobPosition:state.Jobs.jobPosition,
        vacancy:state.Jobs.vacancy,
        jobTitle:state.Jobs.jobTitle,
        jobDesc:state.Jobs.jobDesc,
        jobType:state.Jobs.jobType,
        salaryBased:state.Jobs.salaryBased,
        currency:state.Jobs.currency,
        amount:state.Jobs.amount,
        gender:state.Jobs.gender,
        experience:state.Jobs.experience,
        marker:state.Jobs.marker,
        lat:state.Jobs.lat,
        lon:state.Jobs.lon,
        requirements_age_limit:state.Jobs.requirements_age_limit,
        requirements_work_experience:state.Jobs.requirements_work_experience,
        requirements_language:state.Jobs.requirements_language,
        otherRequirements:state.Jobs.otherRequirements,
        scheduleStartDate:state.Jobs.scheduleStartDate,
        showDateStart:state.Jobs.showDateStart,
        showDateEnd:state.Jobs.showDateEnd,
        scheduleStartTime:state.Jobs.scheduleStartTime,
        scheduleEndDate:state.Jobs.scheduleEndDate,
        scheduleEndTime:state.Jobs.scheduleEndTime,
        shiftBreakStart:state.Jobs.shiftBreakStart,
        shiftBreakEnd:state.Jobs.shiftBreakEnd,
        location:state.Jobs.location,
        errors:state.Jobs.errors,
        draftLoading:state.Jobs.draftLoading,
        job_created_status:state.Jobs.job_created_status,
        show:state.Jobs.show,
        varient:state.Jobs.varient,
        showMsg:state.Jobs.showMsg,
        days_format_array:state.Jobs.days_format_array,
        number_of_days:state.Jobs.number_of_days,
        number_of_hours:state.Jobs.number_of_hours,
        aboveSixtySalary:state.Jobs.aboveSixtySalary,
        belowSixtySalary:state.Jobs.belowSixtySalary,
        salaryContributions:state.Jobs.salaryContributions,
        loading :state.Jobs.loading,
        positions : state.Home.positions,
        industries : state.Home.industries,
        industry_new: state.Jobs.industry_new,
        industries_id : state.Jobs.industries_id,
        showAmount : state.Jobs.showAmount
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getIndustries : () => dispatch(getIndustries()),
        getPositions : data => dispatch(getPositions(data)),
        changeInput: (f,v) => dispatch(actions.updateInput(f,v)),
        salaryContribution : () => dispatch(actions.salaryContribution()),
        createJob: (data) => dispatch(actions.createJob(data)),
        updateErrors: (data) => dispatch(actions.updateErrors(data)),
        resetForm: (data) => dispatch(actions.resetForm(data)),
        setShow: (data) => dispatch(actions.setShow(data)),
        getJob: (data, days_arr) => dispatch(actions.getJobById(data, days_arr)),
        setSchedule: (data) => dispatch(actions.setSchedule(data)),
        editJob: (data) => dispatch(actions.editJob(data))
    }
};

const createjobpost = connect(
    mapStateToProps,
    mapDispatchToProps,
)(CreateJobPost);

export default createjobpost;


import React, { useEffect, useState } from "react";
import Header from "../Employer/header";
import { connect } from 'react-redux';
import { MyCompanyPage, MyComapanyValues, EditComapanyValues, UploadComapanyProfile } from "../../actions/myCompanyHire";
import Alert from "react-bootstrap/Alert";
import { Link } from "react-router-dom";
import Autocomplete from "react-google-autocomplete";
function MyCompany(props) {
  // const[errors, setErrors] = useState({
  //   url:""
  // })
  useEffect(() => {
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    // const elem2 = document.createElement("link");
    // elem2.rel = "stylesheet"
    // elem2.type = "text/css"
    // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    // elem2.id = "design_app_style"
    // elem2.async = true;
    // document.head.appendChild(elem2);
    
    props.defaultSetValues();
  }, []);
  useEffect(() => {
    console.log(props.certificate, 'props.certificate')
    
   
    if (props.varient ==='success' || props.variant === 'danger') {
      // setTimeout(function(){
      //   props.setFieldValues('show_alert', false)
      // }, 2000)
    }
  })
  const copyFunc = (e) => {
    
    if (e.target.checked == true) {
      props.setFieldValues('billing_adderess', props.address);
      props.setFieldValues('billing_adderess_line1', props.addressLine1);
      props.setFieldValues('billing_adderess_city', props.address_city);
      props.setFieldValues('billing_adderess_pincode', props.address_pincode);
      props.setFieldValues('same_as_billing_address', e.target.checked)
    } else {
      props.setFieldValues('billing_adderess', props.billing_adderess);
      props.setFieldValues('billing_adderess_line1', props.billing_adderess_line1);
      props.setFieldValues('billing_adderess_city', props.billing_adderess_city);
      props.setFieldValues('billing_adderess_pincode', props.billing_adderess_pincode);
      props.setFieldValues('same_as_billing_address', e.target.checked)
    }
  };
 
  const saveFunc = () => {
   
    let input = {
      employer_id: localStorage.getItem('emp_id'),
      mobile: props.mobile,
      landline: props.landline,
      company_name: props.company_name,
      about_company: props.about_company,
      mailing_address_2:props.addressLine1,
      mailing_address_city:props.address_city,
      mailing_address_state:props.address_pincode,
      mailing_address: props.address,
      billing_address: props.billing_adderess ? props.billing_adderess: props.address,
      billing_address_2:props.billing_adderess ? props.addressLine1 : props.billing_adderess_line1,
      billing_address_city:props.billing_adderess ? props.address_city: props.billing_adderess_city,
      billing_address_state:props.billing_adderess ? props.address_pincode: props.billing_adderess_pincode,
      location: props.location,
      no_of_employees: props.no_of_employees,
      business_type: props.business_type,
      company_reg_id: props.company_no,
      profile_url: props.profile_pic,
      same_as_billing_address:props.same_as_billing_address ? 1: 0,
      certificates:props.certificate.length > 0 ? 
      JSON.stringify(props.certificate): JSON.stringify(""),
    };
    props.sendValues(input);

  };

  const profileUpload = (e) => {
    props.addImg("prof", e.target.files[0])
  };

  const setPlaces = (place, check) => {
    if (check === 'mailing') {
      if ( place.formatted_address &&  place.formatted_address.length > 0) {
        props.setFieldValues("address", place.formatted_address);
        let length = place.address_components &&
        place.address_components.length > 0 ?
        place.address_components.length-1 :""
        props.setFieldValues("addressLine1", place.address_components && place.address_components.length >0 &&
        place.address_components[1].long_name
        )
        props.setFieldValues("address_city", place.address_components && place.address_components.length >0 &&place.address_components[length-2].long_name)
        
        if (place.address_components && place.address_components.length >0 && place.address_components[length].types[0] ==="postal_code") {
          props.setFieldValues("address_pincode", parseInt(place.address_components[length].long_name))
        } else {
          props.setFieldValues("address_pincode", "")
        }
        sessionStorage.setItem('Emp_address', place.formatted_address)
        sessionStorage.setItem('Emp_address_city', place.address_components[length-2].long_name)
        sessionStorage.setItem('Emp_address_postal_code', parseInt(place.address_components[length].long_name))
      } else {
        props.setFieldValues("address", "")  
        props.setFieldValues("addressLine1", "")
        props.setFieldValues("address_city", "") 
        props.setFieldValues("address_pincode", "")
      }
     
    } else if (check === 'billing') {
      if ( place.formatted_address &&  place.formatted_address.length >0) {
        props.setFieldValues("billing_address", place.formatted_address);
        let length = place.address_components &&
        place.address_components.length > 0 ?
        place.address_components.length-1 :""
        props.setFieldValues("billing_adderess_line1", place.address_components && place.address_components.length >0 &&
        place.address_components[1].long_name
        )
        props.setFieldValues("billing_adderess_city", place.address_components && place.address_components.length >0 &&place.address_components[length-2].long_name)
        
        if (place.address_components && place.address_components.length >0 && place.address_components[length].types[0] ==="postal_code") {
          props.setFieldValues("billing_adderess_pincode", parseInt(place.address_components[length].long_name))
        } else {
          props.setFieldValues("billing_adderess_pincode", "")
        }
      } else {
        props.setFieldValues("billing_address", "");
        props.setFieldValues("billing_adderess_line1", "");     
        props.setFieldValues("billing_adderess_city", "");
        props.setFieldValues("billing_adderess_pincode", "");
      }
     
    }
  }

  return (
    <div>
      <div className="container-fluid">
   
        {/* header Starts here */}
        <Header />
        {/* header Ends here */}
        {/* Main Content Starts here */}

        <section className="row main-content">
          
          <div className="container">
            <div className="row">
           
              <div className="col-12 hdr-row">
                
                <h1>My Company</h1>
                {/* <div>
                  <button className="btn btn-blue" onClick={saveFunc}>Save</button>
                </div> */}
              </div>
              <div className="col-12">
              {/* {
            <Alert
              show={props.show_alert}
              variant={props.varient}
              dismissible
              onClose={() => props.setFieldValues('show_alert', false)}
            >
              <strong>
                {props.varient == "success"
                  ? "Success!"
                  : "Error!"}
              </strong>{" "}
              {props.showMsg}
            </Alert>} */}
                <div className="snippet-box p-3 p-md-5 form-section">
                  <form className="custom-form row">
                    <div className="col-6 form-legend mt-2 mb-4">
                      <span className="subtitle">Company Logo</span>
                      <label className="col-12 px-0 mt-2">Choose a Upload Company Logo</label>
                      <div className="row mt-1">
                        <div className="col-md-4">
                          <div className="company-logo">
                            <img className="img-fluid" src={props.profile_pic ? props.profile_pic : "/assets/images/app/profile-default.png"} 
                              style = {
                                {
                                  height :'110px',
                                  width :'110px',
                                  overflow:'hidden'
                                }
                              }
                            />
                            <a href="javascript:;" className="change">
                              <label for="myfile">
                                <img className="img-fluid" src="/assets/images/app/camera-icon.svg" alt="icon"
                              
                                 />
                                <input type="file" id="myfile" 
                                accept = "image/*"
                                name="myfile" style={{ display: "none" }} onChange={profileUpload}></input>
                              </label>
                            </a>
                          </div>
                        </div>
                      </div>
                      <span
                        style = {{
                            position:'absolute',
                            bottom: '-23px',
                            left:'17px',
                            fontSize:'12px',
                            color:'red'
                        }}
                        >Image Size should be(500x500)</span>
                    </div>
                 
                    <div className="col-3 form-legend mt-2 mb-4">
                    <Link to = {'/credits'} className="change n__transaction-button">
                    {/* <i class="fa fa-exchange" aria-hidden="true"></i>  */}
                    Transaction History
                    </Link>
                      
                    </div>
                    <div className="col-xl-10 col-lg-12 form-legend mt-3 mb-4">
                      <span className="subtitle">Company Details</span>
                      <div className="row mt-3">
                        <div className="col-md-6 form-group">
                          <label>Company Name</label>
                         
                          <input type="text" className="form-control" value={props.company_name} onChange={(e) => props.setFieldValues('company_name', e.target.value)} name />
                        </div>
                        {/* <div className="col-md-6 form-group pin-formgroup">
                          <label>Location</label>
                          <input type="text" className="form-control" value={props.location} onChange={(e) => props.setFieldValues('location', e.target.value)} placeholder="Ex St Andrews Lane, London, UK" name />
                          <button className="btn btn-pin"
                          style = {{
                            cursor:'text'
                          }}
                          type = "button"
                          >
                            <img className="img-fluid" 
                            
                            src="/assets/images/app/location-pin-blue.svg" />
                          </button>
                        </div> */}
                      </div>
                      <div className="row">
                        <div className="col-md-6 form-group parellel">
                          <label>About your company</label>
                          <textarea className="form-control" value={props.about_company} onChange={(e) => props.setFieldValues('about_company', e.target.value)} placeholder="For example, Nissi Fresh started in 1990. We have been a top brand for fresh produce for over 30 years." placeholder={""} />
                        </div>
                        <div className="col-md-6 form-group">
                          <label>Number of Employees</label>
                          <select className="form-control" onChange={(e) => props.setFieldValues('no_of_employees', e.target.value)} value={props.no_of_employees}>
                            <option value="">Select One</option>
                            <option value="0-50">0-50 employees</option>
                            <option value="51-100">51-100 employees</option>
                            <option value="101-250">101-250 employees</option>
                            <option value="more than 250">More than 250 employees</option>
                          </select>
                          <label className="mt-3">Business Type</label>
                          <select className="form-control" onChange={(e) => props.setFieldValues('business_type', e.target.value)} value={props.business_type}>
                            <option value="">Select One</option>
                            <option value = "Sole partnership">Sole partnership</option>
                            <option value = "Partnership">Partnership </option>
                            <option value= "Limited Liability Partnership, also known as LLP">Limited Liability Partnership, also known as LLP </option>
                            <option value = "Private Limited Company (Sendirian Berhad)">Private Limited Company (Sendirian Berhad)</option>
                            <option value = "Public Limited Company(Berhad)">Public Limited Company(Berhad) </option>
                          </select>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6 form-group">
                          <label>Company Registration Number
                          
                          </label>
                          {/* <span className ="hightlight-color"> *</span> */}
                          <input className="form-control" type="text" value={props.company_no} onChange={(e) => {

                            props.setFieldValues('company_no', e.target.value)
                          }} name />
                        </div>
                        <div className="col-md-6 form-group">
                          <div className="row">
                          <div className="col-xl-6 col-lg-12 col-md-12">
                              <div className="form-group mb-0">
                                <label>Contact Number Land Line
                                
                                </label>
                                {/* <span className ="hightlight-color"> *</span> */}
                                <input type="text" className="form-control" value={props.landline} onChange={(e) => { props.setFieldValues('landline', e.target.value) }} placeholder="3-2303 1296" />
                              </div>
                            </div>
                          <div className="col-xl-6 col-lg-12 col-md-12 pl-3 mt-2 mt-xl-0 pl-xl-0">
                              <div className="form-group mb-0">
                                <label>Mobile Number </label>
                                {/* <span className ="hightlight-color"> *</span> */}
                                <div className="form-group">
                                 
                                  <input type="text" value={props.mobile} onChange={(e) => { if (!Number(e.target.value)) { return; } else { props.setFieldValues('mobile', e.target.value) } }} className="form-control" name placeholder="17-661 0472" 
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Mailing Address Line 1</label>
                            {/* <input type="text" className="form-control" onChange={(e) => props.setFieldValues('address', e.target.value)} value={props.address} placeholder="45 Jalan Tun Ismail, 50480 Kuala Lumpur, Malaysia" name /> */}
                            <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className="form-control"
                            value = {props.address} 
                            onChange={(e) => {
                              props.setFieldValues('address', e.target.value);
                            }}
                            onPlaceSelected={(place) => {
                              setPlaces(place, 'mailing')
                            }}
                            options={{
                              types: ['address'],
                                // componentRestrictions: { country: "ru" },
                            }}
                            // defaultValue={this.props.mailing_address}
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                        <div className="form-group">
                            <label>Mailing Address Line2 </label>
                            <input type="text" className="form-control" onChange={(e) => props.setFieldValues('addressLine1', e.target.value)} value={props.addressLine1}
                            name />
                          </div>
                        
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>City/State</label>
                            <input type="text" className="form-control" onChange={(e) => props.setFieldValues('address_city', e.target.value)} value={props.address_city} 
                            name />
                          </div>
                          <div className="form-group mb-2">
                            <label className="checkbox-label">
                              <input type="checkbox" name="address" 
                              checked = {props.same_as_billing_address}
                              onClick={(e) => { copyFunc(e) }} />
                              Same as my Mailing Address
                            </label>
                          </div>
                        </div>
                        <div className="col-md-6">
                        <div className="form-group">
                         
                            <label>Pincode</label>
                            <input type="text" 
                            value={isNaN(props.address_pincode) ? "" : props.address_pincode}
                            className="form-control"
                             onChange={(e) => {
                               
                              // const re = /^[0-9\b]+$/;
                              //   if (
                              //     e.target.value === "" ||
                              //     re.test(e.target.value)
                              //   ) {
                                  
                                  props.setFieldValues(
                                    "address_pincode",
                                    e.target.value
                                  );
                                // } 
                              
                            }}
                            //  onChange={
                            //   (e) => {const re = /^[0-9\b]+$/;
                            //   if (
                            //     e.target.value === "" ||
                            //     re.test(e.target.value)
                            //   ) {
                            //   props.setFieldValues('address_pincode', e.target.value)}}}
                                name />
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Billing Address Line1</label>
                            {/* <input type="text" 
                            className="form-control" 
                            onChange={(e) => props.setFieldValues('billing_adderess', e.target.value)} 
                            value={
                              props.same_as_billing_address ? props.address:
                              props.billing_adderess} 
                             name /> */}
                                <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className="form-control"
                            value = {  props.same_as_billing_address ? props.address:
                              props.billing_adderess} 
                            onChange={(e) => {
                              props.setFieldValues('billing_adderess', e.target.value);
                            }}
                            onPlaceSelected={(place) => {
                              setPlaces(place, 'billing')
                            }}
                            options={{
                              types: ['address'],
                                // componentRestrictions: { country: "ru" },
                            }}
                            // defaultValue={this.props.mailing_address}
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                        <div className="form-group">
                          <label>Billing Address Line2</label>
                          <input type="text" className="form-control" onChange={(e) => props.setFieldValues('billing_adderess_line1', e.target.value)} value={props.same_as_billing_address ?props.addressLine1: props.billing_adderess_line1} 
                            name />
                        </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>City/State </label>
                            <input type="text" className="form-control" onChange={(e) => props.setFieldValues('billing_adderess_city', e.target.value)} value={
                              props.same_as_billing_address ? props.address_city:
                              props.billing_adderess_city}  name />
                          </div>
                          <label
                          className = {
                            props.certificate.length === 0 ?
                            "text-danger":
                            ""
                          }
                          >
                            Certificate Upload
                            
                            <a className="btn add-btn">
                              <label for="cerfile">
                                <img className="img-fluid" src="/assets/images/app/circle-add-btn.svg" alt="icon" />
                               
                                <input type="file" id="cerfile" style={{ display: "none" }}
                                accept="application/pdf"
                                 onChange={(e) => {
                                  
                                  props.addImg("certi", e.target.files[0])
                                }  
                                }></input>
                              </label>
                            </a>
                            
                            {/* <span className="text-danger">Only pdf files accepted</span> */}
                          </label>
                          <span className ="hightlight-color"> *</span>
                          <div className={
                            props.certificate.length === 0 ?
                            "upload-doc-thumb form-control border-danger":
                            "upload-doc-thumb form-control"
                          }
                          
                          id = "testScroll"
                          >
                            {props.certificate &&
                            props.certificate.length > 0 &&
                            // props.certificate[0].url !== '' &&
                            props.certificate.map((img, k) => {
                              return (
                                <iframe style={{ overflow: "hidden",
                                  width : '400px'
                                }} seamless="seamless" 
                                className="img-fluid" src={img.url} alt="Thumb" 
                                key = {k}
                                />
                              )
                            })}
                          </div>
                          
                        </div>
                        <div className="col-md-6">
                        <div className="form-group">
                          <label>Pincode</label>
                          <input type="text" className="form-control" 
                          onChange={(e) => props.setFieldValues('billing_adderess_pincode', e.target.value)} value={
                            props.same_as_billing_address ? props.address_pincode:
                            props.billing_adderess_pincode} 
                          name />
                        </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  {
            <Alert
              show={props.show_alert}
              variant={props.varient}
              dismissible
              onClose={() => props.setFieldValues('show_alert', false)}
            >
              <strong>
                {props.varient == "success"
                  ? "Success!"
                  : "Error!"}
              </strong>{" "}
              {props.showMsg}
            </Alert>}
                  <div className="n__create-job-buttons">
                  <button className="btn btn-blue" onClick={saveFunc}>Save</button>
                </div>
                </div>
                
              </div>
            </div>
          </div>
        </section>
        {/* Main Content Ends here */}
      </div>
      {/* Main Wrapper Ends here */}
      {/* Script Starts here */}
      {/* Script Ends here */}
    </div>
  )
};


const mapStateToProps = (state, ownProps) => {
  const {
    company_name,
    location,
    about_company,
    no_of_employees,
    business_type,
    company_no,
    landline,
    code,
    mobile,
    address,
    billing_adderess,
    certificate,
    profile_pic,
    addressLine1,
    address_city,
    address_pincode,
    billing_adderess_line1,
    billing_adderess_city,
    billing_adderess_pincode,
    copy_address,
    varient,
    show_alert,
    showMsg,
    same_as_billing_address
  } = state.ProfileCompany;
  return {
    company_name,
    location,
    about_company,
    no_of_employees,
    business_type,
    company_no,
    landline,
    code,
    mobile,
    address,
    billing_adderess,
    certificate,
    addressLine1,
    address_city,
    address_pincode,
    billing_adderess_line1,
    billing_adderess_city,
    billing_adderess_pincode,
    profile_pic,
    copy_address,
    varient,
    show_alert,
    same_as_billing_address,
    showMsg,
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {

    setFieldValues: (f, v) => dispatch(MyCompanyPage(f, v)),
    defaultSetValues: () => dispatch(MyComapanyValues()),
    sendValues: (input) => dispatch(EditComapanyValues(input)),
    addImg: (type, input) => dispatch(UploadComapanyProfile(type, input)),

  }
};

export default connect(mapStateToProps, mapDispatchToProps)(MyCompany);


import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
// import $ from 'jquery';
// import { Link } from "react-router-dom";
import Header from "../Employer/header";
import * as actions from '../../actions/Employer/Workers';
import {salaryContribution} from "../../actions/Jobs";

import EditWorker from '../Employer/Workers/EditWorkerModel';
import RequestModal from '../Employer/Workers/RequestModal';
import Attendance from '../Employer/Workers/Attendance'
import Requests from '../Employer/Workers/RequestsList'
import Alert from "react-bootstrap/Alert";
import Loader from "../Helper/Loader"

class Workers extends Component {
  
    constructor(props) {
        super(props);
        this.state = {
          filter:0,
          filter_by:null,
          filter_term:null,
          employeeId:'',
          work_id:''
        }
    }

    componentDidMount() {
      window.$(document).ready(function () {
        window.$(".selectpicker").selectpicker();
      })
      let removingElament = document.getElementById("custom_app_style");
      // console.log(removingElament, 'removingElament')  
      if (removingElament !== null) {
        removingElament.remove()
      }

	    let employer_id = localStorage.getItem('emp_id')
      this.props.salaryContribution();
      this.props.getAllWorkers({
          employer_id:employer_id,
          filter:this.state.filter,
          filter_by:this.state.filter_by,
          filter_term:this.state.filter_term
      })        
		  this.props.setLoading(true)
     
        // this.props.getLateRequests({
        //   employer_id:employer_id,
        //   page_no : 0,
        //   limit : 10  
        // })        
      // const elem2 = document.createElement("link");
      // elem2.rel = "stylesheet"
      // elem2.type = "text/css"
      // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
      // // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
      // elem2.id = "custom_app_style"
      // elem2.async = true;
      // document.head.appendChild(elem2);
  }

  componentDidUpdate() {
    window.$(document).ready(function () {
      window.$(".selectpicker").selectpicker('refresh');
    })
    let THIS = this
    // if (this.props.status === 1 
    //   ||this.props.status === 2 
    //   ||this.props.status === 3) {
    //   setTimeout(function() {
    //     THIS.props.setShow(false)
    //   }, 2000)
    // }
  }

	componentWillUnmount() {
		this.props.setLoading(false)
    if (this.props.status === 1 
      ||this.props.status === 2 
      ||this.props.status === 3) {
      // setTimeout(function() {
        this.props.setShow(false)
      // }, 2000)
    }
	}
    
    render() {
      let employer_id = localStorage.getItem('emp_id')
        return (
            <>
            <div className="container-fluid">
            {/* {console.log(this.props.workerDetails, 'opopopop')} */}
            <Header />
              {/* Main Content Starts here */}
              <section className="row main-content">
              <div className="container">
                
                <div className="row">
                <div className="col-12 hdr-row ff-col">
                <ul className="nav nav-tabs">
                <li>
                  <a className="active px-4" data-toggle="tab" href="#manage-employee">
                    Manage Employee
                  </a>
                </li>
                <li>
                  <a className="px-4" data-toggle="tab" href="#attendance">Attendance</a>
                </li>
                <li>
                  <a className="px-4" data-toggle="tab" href="#requests">Requests</a>
                </li>
              </ul>
              </div>
              <div className="col-12">
                <div className="tab-content">
                {
                  
                  <Alert
                  show={this.props.show}
                  variant={this.props.varient}
                  dismissible
                  onClose={() => this.props.setShow(false)}
                  >
                  <strong>
                  {
                    // console.log(this.props.status, 'this.props.status'),
                      this.props.status === 1 ? "Success!" 
                      : this.props.status === 2 ? "Error!"
                      :""
                      
                  }
                  </strong>{" "}
                  {this.props.showMsg}
                  </Alert>
                  }
                  <div id="manage-employee" className="col-12 tab-pane fade in show active">
                  <form className="custom-form row five-col form-section my-3">
                  <div className="form-group col-md-3">
                  <label>Search By</label>
                  <select className="form-control selectpicker"
                  data-live-search="true"    
                  title = "Choose One"
                      value = {this.state.filter_by}
                      onChange = {(e) => {
                        this.setState({
                          filter_by:e.target.value,
                        })
                      //   this.props.getAllWorkers({
                      //     employer_id:employer_id,
                      //     filter:1,
                      //     filter_by:e.target.value,
                      //     filter_term:this.state.filter_term
                      // })        
                      }}
                      >
                      
                      <option value = "name">Employee Name</option>
                      <option value = "role">Role</option>
                      <option value = "place"> Place</option>
                      <option value = "work_type">Work Type</option>
                      <option value = "work_status">Working Status</option>
                  </select>
                  </div>
                  <div className="form-group col-md-3">
                  {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
                  <label>Search Term </label>
                  <input className="form-control" 
                  value = {this.state.filter_term}
                  onChange = {(e) => {
                    this.setState({
                      filter_term:e.target.value
                    })
                    this.props.getAllWorkers({
                      employer_id:employer_id,
                      filter:1,
                      filter_by:this.state.filter_by,
                      filter_term:e.target.value
                  }) }}   
                  placeholder = "Ex:manager"
                  ></input>
                  </div>
                  <div className="form-group col-md-3"
                  style = {{
                    marginTop : "30px"
                  }}
                  >
                  {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
                  <button type = "button" className="btn btn-blue"
                  onClick = {(e) => {
                    window.jQuery('.form-control').val('');
                    this.setState({
                      filter:0,
                      filter_by:null,
                      filter_term:null
                    })
                    this.props.getAllWorkers({
                      employer_id:employer_id,
                      filter:0,
                      filter_by:null,
                      filter_term:null
                  })}}   
                  >
                    Reset All 
                  </button>
                  
                  </div>
          </form>
        
          <div className="row">
					{
					this.props.loading ? 
					<div className="empty-job">
					<Loader/>
					</div>:
					
					<div className="snippet-box min-h-vh">
					<div className="table-responsive" style = {{
            height:'100%'
          }}>
						<table className="emp-table w-nowrap">
						<thead>
							<tr>
							<th>ID</th>
							<th>Employee Name</th>
							<th>Role</th>
							<th>Place</th>
							<th>Work Type</th>
							<th>Working Status</th>
							<th>Worked Hours</th>
							{/* <th>Extra Work Hr</th> */}
							<th>Salary</th>
							<th>&nbsp;</th>
							</tr>
						</thead>
						<tbody>
						{
						
						this.props.currentWorkers &&
            this.props.currentWorkers.length > 0 &&
						this.props.currentWorkers.map((i,k) => {
						return (
						<tr key = {k}>
							<td>
							{i.company_worker_uid}
							{/* EM_01 */}
							</td>
							<td>
							<div className="avatar">
							<div className="av-img">
							<img className="img-fluid" src=
							{!i.profile_url ||
								i.profile_url === "null"||
								i.profile_url === null
								?"/assets/images/app/avatar-1.png": 
								i.profile_url 
								
							}
							alt="username"
							/>
							</div>
							<span> {i.employee_name} </span>
							<div className="r-job-item">
							<div className="dropdown more">
								<button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<img src="/assets/images/app/more-btn.svg" />
								</button>
								<div className="dropdown-menu" aria-labelledby="more-menu">
								<ul className="list-unstyled">
									<li><a href="javascript:;" data-toggle="modal" data-target="#editwrk-modal"
									onClick = {(e) => {
									this.props.editSalary({
										worker_id : i.id,
										employee_id: i.employeeId
									});
									this.props.handelModel(true)
									}}
									> Send Request</a>
                  </li>
									{/* <li
                  onClick = {(e) => {

                    this.props.setRequestModal(true);
                    this.setState({
                      employeeId:i.employeeId,
                      work_id:i.id
                    })
                  }}
                  ><a href="javascript:;" 
                  className="red" 
                  >
                  Extend Work Request</a></li> */}
								</ul>
								</div>
							</div>
							</div>
						</div>
							</td>
							<td>
							{i.role}
							</td>
							<td>
							{/* Seven Mart |  */}
							<span className="gray">
								{/* St Andrews Lane, London, UK */}
								{i.place}
							</span>
							</td>
							<td>
							{i.work_type}
							</td>
							<td>
							<span className={
								i.work_status === 'working' ? 'green' 
								:i.work_status === 'over-time' ? 'green'
								:i.work_status === 'completed' ? 'orange'
								: i.work_status === 'on-board' ? 'red':
								'green'
							}
							>
							{i.work_status}
							</span>
							</td>
							<td>{i.hours_worked ? i.hours_worked : 0}</td>
							{/* <td>{i.extra_hours_worked ? i.extra_hours_worked: '0'}</td> */}
							<td>{i.final_salary === null ?
							 new Intl.NumberFormat('en-US', 
               {style: 'decimal', minimumFractionDigits: 2}).
               format(isNaN(i.total_salary)
               ? '0.00':i.total_salary) :
               new Intl.NumberFormat('en-US', 
               {style: 'decimal', minimumFractionDigits: 2}).
               format(isNaN(i.final_salary)
               ? '0.00':i.final_salary) 
                }
							</td>
							<td><button 
							onClick = {() => {
							this.props.completeProject({
								work_id:i.id
							})
							}
							}
							className="btn btn-blue">End Project</button></td>
						</tr>
						)
						})
						
						}
					</tbody>
					</table>
                    </div>
                    </div>
					}
                    </div>
					
                  </div>
                  <div id="attendance" className="col-12 tab-pane fade in">
                  <Attendance />
                  </div>
                  <div id="requests" className="col-12 tab-pane fade in">
                  <Requests/>
                  </div>
                </div>
              </div>
            </div>
            

          </div>
        </section>
        </div>
        <EditWorker
          workerProfile = {this.props.workerDetails}
        />
        <RequestModal
        employeeId = {this.state.employeeId}
        work_id = {this.state.work_id}
        />
        {/* Main Content Ends here */}

        </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
  return {
    currentWorkers:state.Workers.currentWorkers,
    workerDetails:state.Workers.workerDetails,
    loading:state.Workers.loading,
    show:state.Workers.show,
    varient:state.Workers.varient,
    status: state.Workers.status,
    showMsg:state.Workers.showMsg,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getAllWorkers: (data) => dispatch(actions.getWorkers(data)),
        editSalary : (data) => dispatch(actions.editSalary(data)),
        handelModel : (data) => dispatch(actions.handelModel(data)),
        setShow : data => dispatch(actions.setShow(data)),
        setSuccess : data => dispatch(actions.setSuccess(data)),
        getRequests : data => dispatch(actions.getRequests(data)),
        // getLateRequests : (data) => dispatch(actions.getLateRequests(data)),
		    setLoading : data => dispatch(actions.setLoading(data)),
        salaryContribution : () => dispatch(salaryContribution()),
        completeProject : data => dispatch(actions.completeProject(data)),
        setRequestModal : data => dispatch(actions.setRequestModal(data))
    }
};

const workers = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Workers);

export default workers;

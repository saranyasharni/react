import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
// import * as actions from "../../../../actions/Employer/Hire";
import $ from 'jquery';
import {Link} from "react-router-dom";
function HireCandidate(props) {
    // const [formFields, setFormFields] = useState({
    //     position:'',
    //     industry_type:'',
    //     errors: {}
    // })

    useEffect(() => {

    }, []);

    return (
        <>
          <div className="modal fade custom-modal" id="notify-employer-model" tabIndex={-1} role="dialog" aria-hidden="true">
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                <div className="modal-header">
                    <h5 className="mt-2 modal-title w-100 justify-content-center">Update Profile</h5>
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close"
                    >
                    <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                    </button>
                </div>
                <div className="modal-body px-md-5 px-3">
                    <div className="row">
                    <div className="col-md-12">
                        <p className="fs-14 dark ">Please update your <strong>Proof of documents</strong> to start hiring.</p>
                        <div className="row mt-2 mb-">
                    <div className="col-md-12 text-right">
                        <Link className="btn btn-blue"
                        to = "/my_company"
                        onClick = {() => window.$('#notify-employer-model').modal('hide')}
                        >Profile</Link>
                    </div>
                    </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>

          </>
    )
};

const mapStateToProps = (state, ownProps) => {
    return {
      
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
      
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(HireCandidate);
import React, { useEffect } from "react";
import Head from "../EmployerMainPages/postedJobs";
import { connect } from 'react-redux';
import Share from "./Modals/shareModal";
import { PostedJob, postedJobList,postedJobDetail,ClosedJob,postedClosedJobList } from "../../actions/EmployerPostedJob";
import history from "../../stores/history";
import {Link} from "react-router-dom"
import moment from 'moment';

function PostedjobGrid(props) {

    useEffect(() => {
        // require("../../assets/css/app-style.css");
        let removingElament = document.getElementById("custom_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        // const elem2 = document.createElement("link");
        // elem2.rel = "stylesheet"
        // elem2.type = "text/css"
        // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
        // // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        // elem2.id = "design_app_style"
        // elem2.async = true;
        // document.head.appendChild(elem2);

        let input ={
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:"null",
            filter_term:"null",
            status_code:'1',
            page_no : '0',
            limit : '50'
        };
        let inputClosed = {
            employer_id:localStorage.getItem('emp_id'),
            filter:"0",
            filter_name:"null",
            filter_term:"null",
            status_code:'3',
            page_no : '0',
            limit : '50'
        };
        if (props.status == "active") {
            props.postedJobListAction(input);
            props.closedJobListAction(inputClosed);
        }
    }, []);

    const sendFunc = (val) => {
        props.setFieldValues('job_id', val)
        history.push(`/employer_posted_job_details/${val}`)
    };


    return (
        <React.Fragment>

            <div className="col-12">
                <div className="tab-content">
                    <div id="active" className="tab-pane fade in show active">
                    <div className="row">
                            {(() => {
                                if (props.job_grid.length >0) {
                                    return(
                                    props.job_grid.map((val) => {
                                        let stat_date = moment(new Date(val.start_date)).format("ddd DD")
                                        // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                                        // let start_date_val = stat_date.getDate()
                                        let end_date = moment(new Date(val.end_date)).format("ddd DD")
                                        // console.log()
                                      
                                        return (
                                            
                                            <div className="col-xl-3 col-lg-4 col-sm-6 col-12">
                                                <div className="job-snippet">
                                                    <div className="img-wrap" onClick={() => { sendFunc(val.id) }}>
                                                    <img className="img-fluid" src= {localStorage.getItem('profile_url') !== "null"
                                 ? localStorage.getItem('profile_url') :process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"}
                                 
                                alt="img" />
                                                        
                                                        <span className="date badge">{stat_date} - {" "} {end_date}                
                                                        </span>
                                                    </div>
                                                    <div className="r-job-item">
                                                        <div className="dropdown more">
                                                            <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <img src="/assets/images/app/more-btn.svg" />
                                                            </button>
                                                            <div className="dropdown-menu" aria-labelledby="more-menu">
                                                                <ul className="list-unstyled">
                                                                    <li>
                                                                    <Link to =  {`/edit/job-post/${val.id}`}>Edit job</Link>
                                                                    </li>
                                                                    <li><a href="javascript:;" onClick={() => { props.setFieldValues("share_show", true)
                                                                props.detailsCall(val.id) }}>Share</a></li>
                                                                    <li><a href="javascript:;" className="red" onClick={()=>{props.closedListCall({job_id :val.id,
                                                                    status_code:2
                                                                    })}}>Delete Job</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <h6
                                                         onClick={() => { sendFunc(val.id) }}
                                                        className="text-truncate"
                                                        >{val.industry_type}</h6>
                                                        <span className="job-type text-truncate"
                                                         onClick={() => { sendFunc(val.id) }}
                                                        >{val.job_title}/{val.job_position}</span>
                                                        <span
                                                         onClick={() => { sendFunc(val.id) }}
                                                         className="location text-truncate d-block">
                                                            <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                                            {val.job_location} 
                                                        </span>
                                                        <p className="text-truncate"
                                                         onClick={() => { sendFunc(val.id) }}
                                                        >{'Part-Time'} | {val.salary_based} {val.currency} {new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}</p>
                                                    </div>
                                                </div>
                                            
                                            </div>
                                        )
                                    })
                                    )} else {
                                    return (
                                        <div className="empty-job" >
                                            <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                                            <p>There's nothing here.</p>
                                        </div>
                                    )
                                }
                            })()}

                       </div> 
                    </div>
                    
                    <div id="closed" className="tab-pane fade">
                    <div className="row">
                            {(() => {
                                if (props.closed_job.length >0) {
                                    return(
                                    props.closed_job.map((val) => {
                                        let stat_date = moment(new Date(val.start_date)).format("ddd DD")
                                        // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                                        // let start_date_val = stat_date.getDate()
                                        let end_date = moment(new Date(val.end_date)).format("ddd DD")
                                        return (
                                            
                                            <div className="col-xl-3 col-lg-4 col-sm-6 col-12">
                                                <div className="job-snippet closed">
                                                    <div className="img-wrap" onClick={() => { sendFunc(val.id) }}>
                                                    <img className="img-fluid" src= {localStorage.getItem('profile_url') !== "null"
                               
                               ? localStorage.getItem('profile_url') :process.env.PUBLIC_URL+"assets/images/app/profile-horizontal.png"}
                               
                              alt="img" />
                                                        <span className="date badge">{stat_date} - {end_date}</span>
                                                    </div>
                                                    <div className="r-job-item">
                                                        <div className="dropdown more">
                                                            <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <img src="/assets/images/app/more-btn.svg" />
                                                            </button>
                                                            <div className="dropdown-menu" aria-labelledby="more-menu">
                                                                <ul className="list-unstyled">
                                                                    <li>
                                                                    <Link to =  {`/similar/job-post/${val.id}`}>
                                                                    Create Similar job
                                                                    </Link>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;" onClick={() => { props.setFieldValues("share_show", true)
                                                                props.detailsCall(val.id) }}>Share</a></li>
                                                                <li>
                                                                <a href="javascript:;" 
                                                                className="red"
                                                                onClick={()=>{props.closedListCall({
                                                                    job_id :val.id,
                                                                    status_code:2
                                                                    })}} >Delete Job</a>
                                                                </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <h6
                                                        
                                                        className="text-truncate"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >{val.industry_type}</h6>
                                                        <span className="job-type text-truncate"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >{val.job_title}/{val.job_position}</span>
                                                        <span className="location 
                                                        text-truncate d-block"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >
                                                            <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                                            {val.job_description}
                                                        </span>
                                                        <p className="text-truncate"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >{'Part-Time'} | {val.salary_based} {val.currency} {new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        )
                                    })
                                    )} else {
                                    return (
                                        <div className="empty-job">
                                            <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                                            <p>There's nothing here.</p>
                                        </div>
                                    )
                                }
                            })()}

                       </div>   
                    </div>
                    <div id="drafted" className="tab-pane fade in show ">
                    <div className="row">
                            {(() => {
                                if (props.drafted_jobs.length >0) {
                                    return(
                                    props.drafted_jobs.map((val) => {
                                        let stat_date = moment(new Date(val.start_date)).format("ddd DD")
                                        // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                                        // let start_date_val = stat_date.getDate()
                                        let end_date = moment(new Date(val.end_date)).format("ddd DD")
                                        // console.log()
                                      
                                        return (
                                            
                                            <div className="col-xl-3 col-lg-4 col-sm-6 col-12">
                                                <div className="job-snippet">
                                                    <div className="img-wrap" onClick={() => { sendFunc(val.id) }}>
                                                    <img className="img-fluid" src= {localStorage.getItem('profile_url') !== "null"
                                 ? localStorage.getItem('profile_url') :process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"}
                                 
                                alt="img" />
                                                        <span className="date badge">{stat_date} - {" "} {end_date}                
                                                       
                                                        
                                                        </span>
                                                    </div>
                                                    <div className="r-job-item">
                                                        <div className="dropdown more">
                                                            <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <img src="/assets/images/app/more-btn.svg" />
                                                            </button>
                                                            <div className="dropdown-menu" aria-labelledby="more-menu">
                                                                <ul className="list-unstyled">
                                                                    <li>
                                                                    <Link to =  {`/edit/job-post/${val.id}`}>Edit job</Link>
                                                                    </li>
                                                                    <li><a href="javascript:;" onClick={() => { props.setFieldValues("share_show", true)
                                                                props.detailsCall(val.id) }}>Share</a></li>
                                                                    <li><a href="javascript:;" className="red" onClick={()=>{props.closedListCall({job_id :val.id,
                                                                    status_code:2
                                                                    })}}>Delete Job</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <h6
                                                        onClick={() => { sendFunc(val.id) }}
                                                        className="text-truncate"
                                                        >{val.industry_type}</h6>
                                                        <span className="job-type text-truncate"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >{val.job_title}/{val.job_position}</span>
                                                        <span className="location text-truncate d-block"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >
                                                            <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                                            {val.job_location} 
                                                        </span>
                                                        <p className="text-truncate"
                                                        onClick={() => { sendFunc(val.id) }}
                                                        >{'Part-Time'} | {val.salary_based} {val.currency} {new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}</p>
                                                    </div>
                                                </div>
                                            
                                            </div>
                                        )
                                    })
                                    )} else {
                                    return (
                                        <div className="empty-job" >
                                            <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                                            <p>There's nothing here.</p>
                                        </div>
                                    )
                                }
                            })()}

                       </div> 
                    </div>
                </div>
            </div>
            <Share />

            {/* Main Wrapper Ends here */}
            {/* Script Starts here */}
            {/* Script Ends here */}
        </React.Fragment>

    )
};


const mapStateToProps = (state, ownProps) => {
    return {
        job_grid: state.Postedjob.job_list,
        closed_job:state.Postedjob.closed_jobs_list,
        status:state.Postedjob.active_status,
        drafted_jobs:state.Postedjob.drafted_jobs,
        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        setFieldValues: (f, v) => dispatch(PostedJob(f, v)),
        postedJobListAction: (input) => dispatch(postedJobList(input)),
        detailsCall: (id) => dispatch(postedJobDetail(id)),
        closedJobListAction: (input) => dispatch(postedClosedJobList(input)),
        closedListCall: (id) => dispatch(ClosedJob(id)),
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(PostedjobGrid);


import React, { useEffect,useState } from "react";
import Header from "./header";
import Head from "../EmployerMainPages/postedJobs";
import ShortList from "./Modals/shortListModel";
import Views from "./Modals/viewsModel";
import Applicant from "./Modals/applicantModel";
import Share from "./Modals/shareModal";
import { connect } from 'react-redux';
import { PostedJob, postedJobList, View, Shortlisted, ApplicantList, postedJobDetail,ClosedJob,postedClosedJobList } from "../../actions/EmployerPostedJob";
import history from "../../stores/history";
import {Link} from "react-router-dom";
import moment from 'moment';
import Loader from '../Helper/Loader';

function JobList(props) {
  const[state, setState] = useState('show active')

  useEffect(() => {  
    let filter = '0';
    let filter_name = 'null';
    let filter_term = 'null';
    let status_code = '1'
    if (window.location.pathname.split('/')[2] === 'active-jobs') {
      filter = '1';
      filter_name = 'list';
      filter_term = 'active-jobs';
      status_code = '0'
    } else if (window.location.pathname.split('/')[2] === 'on-going-jobs') {
      filter = '1';
      filter_name = 'list';
      filter_term = 'on-going-jobs'
      status_code = '0'
    } else if (window.location.pathname.split('/')[2] === 'filled-jobs') {
      filter = '1';
      filter_name = 'list';
      filter_term = 'filled-jobs'
      status_code = '0'
    } else {
      filter = '0';
      filter_name = 'null';
      filter_term = 'null'
      status_code = '1'
    }
    // require("../../assets/css/app-style.css");
  let input = {
      employer_id:localStorage.getItem('emp_id'),
      filter:filter,
      filter_name:filter_name,
      filter_term:filter_term,
      status_code:status_code,
      page_no : '0',
      limit : '50'
  };

  let inputClosed = {
    employer_id:localStorage.getItem('emp_id'),
    filter:"0",
    filter_name:'null',
    filter_term:'null',
    status_code:'3',
    page_no : '0',
      limit : '50'
  };

  if (props.status == "active") {
      props.postedJobListAction(input);
      props.closedJobListAction(inputClosed);
    };
  }, []);
  const sendFunc = (val) => {
 
    props.setFieldValues('job_id', val)
    history.push(`/employer_posted_job_details/${val}`)
  };
  return (
    <React.Fragment>
      {
        props.loading ?   <div className="empty-job">
        <Loader />
        </div> :
          <div className="col-12 pb-4">
          <div className="tab-content">
            <div id="active" 
            className={`tab-pane fade in ${window.location.pathname.split('/')[2] === 'drafted'? '':"show active"}`}>

              <div className="row job-list">
  
                {
                  console.log(props.job_list, 'props.job_list'),
                (() => {
                  if (props.job_list.length >0) {
                    return (
                      props.job_list.map((val) => {
                        let stat_date = moment(new Date(val.start_date)).format("ddd DD")
                        // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                        // let start_date_val = stat_date.getDate()
                        let end_date = moment(new Date(val.end_date)).format("ddd DD")
                        return (
                          <div className="col-12" >
                            <div className="job-snippet">
                              <div className="img-wrap" onClick={() => { sendFunc(val.id) }}>
                              <img className="img-fluid" src= {localStorage.getItem('profile_url') !== "null"
                                 ? localStorage.getItem('profile_url') :process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"}
                                 
                                alt="img" />
                                <span className="date badge">{stat_date} - {end_date}</span>
                              </div>
                              <div className="r-job-item">
                                <div className="dropdown more">
                                  <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                  </button>
                                  <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                      <li><Link to =  {`/edit/job-post/${val.id}`}>Edit job</Link></li>
                                      <li>
                                        <a href="javascript:;" onClick={() => {
                                        props.setFieldValues("share_show", true)
                                        props.detailsCall(val.id)
                                      }}>
                                        Share
                                        </a>
                                      </li>
                                      <li>
                                        <a href="javascript:;" className="red" onClick={()=>{props.closedListCall({
                                            job_id :val.id,
                                            status_code:2
                                            })}} >Delete Job</a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="row" 
                                     onClick={() => { sendFunc(val.id) }}
                                >
                                  <div className="col-md-3">
                                    <span className="date badge d-inline-block d-lg-none">
                                    {stat_date} - {end_date}
                                      </span>
                                    <h6
                                    className="text-truncate"
                                    >{val.industry_type}</h6>
                                    <span className="job-type text-truncate">{val.job_title}/{val.job_position}</span>
                                    <span className="location text-truncate d-block">
                                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                      {val.job_location}
                                    </span>
                                    <p className="text-truncate">
                                      {/* {val.job_type} |  */}
                                    {val.salary_based} {val.currency} {new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}</p>
                                  </div>
                                  <div className="col-md-7 btn-wrap">
                                    <button className="btn btn-gray-light"
                                    style = {{
                                      cursor:'text'
                                    }}
                                    onClick={(e)=>{ e.stopPropagation();}}
                                    >
                                    Total Vacancies
                                    
                                      <span>{val.job_stat_information.total_vacancies}</span>
                                    </button>
                                    <button className="btn btn-gray-light"
                                    style = {{
                                      cursor:'text'
                                    }}
                                    onClick={(e)=>{ e.stopPropagation();}}
                                    >
                                    Active Vacancies
                                      <span>{val.job_stat_information.active_vacancies}</span>
                                    </button>
                                    <button className="btn btn-gray-light"
                                    onClick={(e)=>{ e.stopPropagation();
                                                  props.setFieldValues("views_show",true)
                                                  props.showViewers(val.id)}}
                                    >
                                    Total Views
                                      <span>{val.job_stat_information.total_views}</span>
                                    </button>
                                    <button className="btn btn-gray-light"
                                    style = {{
                                      cursor:'text'
                                    }}
                                    onClick={(e)=>{ e.stopPropagation();}}
                                    >
                                    Filled Jobs
                                      <span>{val.job_stat_information.jobs_filled}</span>
                                    </button>
                                    {/* <button className="btn btn-gray-light">
                                    Applications
                                      <span>{val.job_stat_information.active_vacancies}</span>
                                    </button> */}
                                    {/* <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("views_show", true)
                                      props.showViewers(val.id)
                                    }}>
                                      Total No of Views
                                      <span>{val.job_stat_information.total_views}</span>
                                    </button> */}
                                    <button className="btn btn-gray-light" onClick={(e) => {
                                      e.stopPropagation();
                                      props.setFieldValues("applicant_show", true)
                                      props.showApplicant(val.id)
                                    }}>
                                      Applications
                                      <span>{val.job_stat_information.job_applicants}</span>
                                    </button>
                                    <button className="btn btn-gray-light" onClick={(e) => {
                                       e.stopPropagation();
                                      props.setFieldValues("shortlist_show", true)
                                      props.showShortList(val.id)
                                    }}>
                                      Shortlisted
                                      <span>{val.job_stat_information.shortlisted}</span>
                                    </button>
                                  </div>
                                  {
                                    val.expiration_date !== 0 &&
                                    <div className="col-md-2">
                                    <p className="expire">{isNaN(val.expiration_date) ? '': `Job Expires in ${val.expiration_date} ${val.expiration_date === 1 ? 'day':'days'}`}</p>
                                  </div>  
                                  }
                                  
                                </div>
                              </div>
                            </div>
                          </div>
                        )
                      })
                    )
                  } else {
                    return (
                      <div className="empty-job">
                        <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                        <p>There's nothing here.</p>
                      </div>
                    )
                  }
                })()}
  
              </div>
            </div>
            <div id="closed" className="tab-pane fade">
              <div className="row job-list">
  
                {(() => {
                  if (props.closed_job.length >0) {
                    return (
                      props.closed_job.map((val, k) => {
                        let stat_date = moment(new Date(val.start_date)).format("ddd DD")
                        // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                        // let start_date_val = stat_date.getDate()
                        let end_date = moment(new Date(val.end_date)).format("ddd DD")
                        return (
                          <div className="col-12" key = {k}>
                            <div className="job-snippet closed">
                              <div className="img-wrap" onClick={() => { sendFunc(val.id) }}>
                              <img className="img-fluid" src= {localStorage.getItem('profile_url') !== "null"
                               
                                 ? localStorage.getItem('profile_url') :process.env.PUBLIC_URL+"assets/images/app/profile-horizontal.png"}
                                 
                                alt="img" />
                                <span className="date badge">{stat_date} - {end_date}</span>
                              </div>
                              <div className="r-job-item">
                                <div className="dropdown more">
                                  <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                  </button>
                                  <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                      <li>
                                      <Link to =  {`/similar/job-post/${val.id}`}>Create Similar job</Link>
                                        </li>
                                      <li><a href="javascript:;" onClick={() => {
                                        props.setFieldValues("share_show", true)
                                        props.detailsCall(val.id)
                                      }}>Share</a></li>
                                       <li>
                                        <a href="javascript:;" className="red" onClick={()=>{props.closedListCall({
                                            job_id :val.id,
                                            status_code:2
                                        })}} >Delete Job</a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="row" 
                                onClick = { () => sendFunc(val.id) }
                                >
                                  <div className="col-md-3">
                                    {/* <span className="date badge d-inline-block d-lg-none">Thu 16 - Sun 20</span> */}
                                    <h6
                                    className="text-truncate"
                                    >{val.industry_type}</h6>
                                    <span className="job-type text-truncate">{val.job_title}/{val.job_position}</span>
                                    <span className="location text-truncate d-block">
                                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                       {val.job_location} 
                                    </span>
                                    <p className="text-truncate">{
                                    // val.job_type} |
                                     val.salary_based} {val.currency} {new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}</p>
                                  </div>
                                  <div className="col-md-7 btn-wrap">
                                    <button className="btn btn-gray-light" 
                                    onClick={(e)=>{ e.stopPropagation();}}>
                                    Total No of Jobs
                                      <span>{val.job_stat_information.total_vacancies}</span>
                                    </button>
                                    <button className="btn btn-gray-light" 
                                    onClick={(e)=>{ e.stopPropagation();}}>
                                    Filled Jobs
                                      <span>{val.job_stat_information.jobs_filled}</span>
                                    </button>
                                    {/* <button className="btn btn-gray-light">
                                    Applications
                                      <span>{val.job_stat_information.active_vacancies}</span>
                                    </button> */}
                                    {/* <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("views_show", true)
                                      props.showViewers(val.id)
                                    }}>
                                      Total No of Views
                                      <span>{val.job_stat_information.total_views}</span>
                                    </button> */}
                                    <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("applicant_show", true)
                                      props.showApplicant(val.id)
                                    }}>
                                      Applications
                                      <span>{val.job_stat_information.job_applicants}</span>
                                    </button>
                                    <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("shortlist_show", true)
                                      props.showShortList(val.id)
                                    }}>
                                      Shortlisted
                                      <span>{val.job_stat_information.shortlisted}</span>
                                    </button>
                                  </div>
                                  <div className="col-md-2">
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )
                      })
                    )
                  } else {
                    return (
                      <div className="empty-job">
                        <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                        <p>There's nothing here.</p>
                      </div>
                    )
                  }
                })()}
              </div>
            </div>
            <div id="drafted" 
            className={`tab-pane fade ${window.location.pathname.split('/')[2] === 'drafted'? 'in show active':""}`}>
            
              <div className="row job-list">
  
                {(() => {
                  if (props.drafted_jobs.length >0) {
                    return (
                      props.drafted_jobs.map((val, k) => {
                        let stat_date = moment(new Date(val.start_date)).format("ddd DD")
                        // let start_day_name = stat_date.toLocaleDateString('en-us', { weekday: 'short' });
                        // let start_date_val = stat_date.getDate()
                        let end_date = moment(new Date(val.end_date)).format("ddd DD")
                        return (
                          <div className="col-12" key = {k}>
                            <div className="job-snippet">
                              <div className="img-wrap" onClick={() => { sendFunc(val.id) }}>
                              <img className="img-fluid" src= {localStorage.getItem('profile_url') !== "null"
                                 ? localStorage.getItem('profile_url') :process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"}
                                 
                                alt="img" />

                                {/* <span className="date badge">{stat_date} - {end_date}</span> */}
                              </div>
                              <div className="r-job-item">
                                <div className="dropdown more">
                                  <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                  </button>
                                  <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                      {/* <li>
                                      <Link to =  {`/similar/job-post/${val.id}`}>Create Similar job</Link>
                                        </li> */}
                                           <li><Link to =  {`/edit/job-post/${val.id}`}>Edit job</Link></li>
                                      <li><a href="javascript:;" onClick={() => {
                                        props.setFieldValues("share_show", true)
                                        props.detailsCall(val.id)
                                      }}>Share</a></li>
                                       <li>
                                        <a href="javascript:;" className="red" onClick={()=>{props.closedListCall({
                                            job_id :val.id,
                                            status_code:2
                                            })}} >Delete Job</a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="row" 
                                onClick={() => { sendFunc(val.id) }}
                                >
                                  <div className="col-md-3">
                                    {/* <span className="date badge d-inline-block d-lg-none">Thu 16 - Sun 20</span> */}
                                    <h6
                                    className="text-truncate"
                                    >{val.industry_type ? val.industry_type:''}</h6>
                                    {val.job_title && val.job_position &&
                                    <span className="job-type text-truncate">{val.job_title}/{val.job_position}</span>
                                    }
                                    {
                                      val.job_location &&
                                      <span className="location text-truncate d-block">
                                      <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                       {val.job_location} 
                                    </span>
                                    }
                                    {val.salary_based &&
                                    <p className="text-truncate">
                                      {/* {
                                      val.job_type ? val.job_type:'select type'} | */}
                                       {val.salary_based} {val.currency} {new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(val.amount)? '0.00':val.amount)}</p>
                                    }
                                    
                                  </div>
                                  <div className="col-md-7 btn-wrap">
                                    {/* <button className="btn btn-gray-light">
                                    Total No of Jobs
                                      <span>{val.job_stat_information.total_vacancies}</span>
                                    </button>
                                    <button className="btn btn-gray-light">
                                    Filled Jobs
                                      <span>{val.job_stat_information.jobs_filled}</span>
                                    </button> */}
                                    {/* <button className="btn btn-gray-light">
                                    Applications
                                      <span>{val.job_stat_information.active_vacancies}</span>
                                    </button> */}
                                    {/* <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("views_show", true)
                                      props.showViewers(val.id)
                                    }}>
                                      Total No of Views
                                      <span>{val.job_stat_information.total_views}</span>
                                    </button> */}
                                    {/* <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("applicant_show", true)
                                      props.showApplicant(val.id)
                                    }}>
                                      Applications
                                      <span>{val.job_stat_information.job_applicants}</span>
                                    </button>
                                    <button className="btn btn-gray-light" onClick={() => {
                                      props.setFieldValues("shortlist_show", true)
                                      props.showShortList(val.id)
                                    }}>
                                      Shortlisted
                                      <span>{val.job_stat_information.shortlisted}</span>
                                    </button> */}
                                  </div>
                                  <div className="col-md-2">
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )
                      })
                    )
                  } else {
                    return (
                      <div className="empty-job">
                        <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                        <p>There's nothing here.</p>
                      </div>
                    )
                  }
                })()}
              </div>
            </div>
          </div>
          </div>
      }
    
        {/* Main Wrapper Ends here */}
        {/* Modal Wrapper Starts here */}

        <ShortList />
        <Views />
        <Applicant />
        <Share />

        {/* Modal Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
      </React.Fragment>
  )
};

const mapStateToProps = (state, ownProps) => {
  return {
        job_list: state.Postedjob.job_list,
        closed_job:state.Postedjob.closed_jobs_list,
        drafted_jobs:state.Postedjob.drafted_jobs,
        status:state.Postedjob.active_status,
        loading : state.Hire.loading
    // categories: state.Home.categories
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setFieldValues: (f, v) => dispatch(PostedJob(f, v)),
    postedJobListAction: (input) => dispatch(postedJobList(input)),
    showApplicant: (id) => dispatch(ApplicantList(id)),
    showShortList: (id) => dispatch(Shortlisted(id)),
    showViewers: (id) => dispatch(View(id)),
    detailsCall: (id) => dispatch(postedJobDetail(id)),
    closedJobListAction: (input) => dispatch(postedClosedJobList(input)),
    closedListCall: (id) => dispatch(ClosedJob(id)),
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(JobList);
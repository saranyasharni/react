import React, { useEffect } from "react";
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import { PostedJob } from "../../actions/EmployerPostedJob";
import jQuery from "jquery";
import { getEmployerNotification, viewEmployerNotification } from "../../actions/Notifications";
import moment from "moment"

function Header(props) {
    useEffect(() => {
      let removingElament = document.getElementById("custom_app_style");
      // console.log(removingElament, 'removingElament')  
      if (removingElament !== null) {
        removingElament.remove()
      }
      // const elem2 = document.createElement("link");
      // elem2.rel = "stylesheet"
      // elem2.type = "text/css"
      // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
      // // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
      // elem2.id = "design_app_style"
      // elem2.async = true;
      // document.head.appendChild(elem2);
      props.getEmployerNotification({
        employer_id : localStorage.getItem('emp_id')
      })
      }, []);

      if(window.location.pathname.split('/')[2] === 'dashboard') {
        jQuery('#dashboard').addClass('active');
      } 
      if(window.location.pathname.split('/')[1] === 'employer_posted_job_list'){
        jQuery('#posted_jobs').addClass('active');
      }
      if(window.location.pathname.split('/')[1] === 'hire-staff'){
        jQuery('#hire_staff').addClass('active');
      }
      if(window.location.pathname.split('/')[1] === 'workers'){
        jQuery('#workers').addClass('active');
      }
      if(window.location.pathname.split('/')[1] === 'interviews'){
        jQuery('#interviews').addClass('active');
      }
      if(window.location.pathname.split('/')[1] === 'my_company'){
        jQuery('#my_company').addClass('active');
      }
      console.log(window.location.pathname.split('/')[1], "path ..................");
    return (
        <header className="row px-3">
        <div className="col-lg-9 col-md-10 col-6 hdr-lft">
          <a href="javascript:;" className="lft-btn">
            <img src="/assets/images/app/hdr-lft-icon.svg" alt="icon" />
          </a>
          <nav className="navbar navbar-expand-md">
            <div className="collapse navbar-collapse" id="app-hdr-nav">
              <ul className="navbar-nav">
                <li className="nav-item" id="dashboard">
                  <Link className="nav-link" to = '/employer/dashboard'
                  onClick = {(e) => {
                    // console.log(jQuery(e.target).closest('li').addClass('active'), 'isthatcominf')
                   
                    // jQuery('.nav-item').removeClass('active')
                    jQuery(e.target).closest('li').addClass('active')
                  }

                  }
                  >
                    Dashboard
                  </Link>
                </li>
                <li className="nav-item" id="posted_jobs">
                  <Link className="nav-link" 
                  
                  to = "/employer_posted_job_list/active"
                  // onClick = {(e) => {
                  //   jQuery(e.target).closest('li').addClass('active')
                  //   jQuery('.nav-item').removeClass('active')
                  // }

                  // }
                  >
                  Posted Jobs
                  </Link>
                </li>
                {/* <li className="nav-item">
                  <Link className="nav-link" 
                  to = "/employer/chat"
                  onClick = {(e) => {
                    jQuery(e.target).closest('li').addClass('active')
                    jQuery('.nav-item').removeClass('active')
                  }

                  }
                  >Chats</Link>
                </li> */}
                <li className="nav-item" id = "hire_staff">
                  <Link className="nav-link" 
                  
                    onClick = {(e) => {
                      jQuery(e.target).closest('li').addClass('active')
                      jQuery('.nav-item').removeClass('active')
                    }
                  }
                  to = "/hire-staff"
                  >
                   Hire Staff
                  </Link>
                </li>
                <li className="nav-item" id="workers">
                  <Link className="nav-link" 
                  
                  to = "/workers"
                  onClick = {(e) => {
                    jQuery(e.target).closest('li').addClass('active')
                    jQuery('.nav-item').removeClass('active')
                  }

                  }
                  >Workers</Link>
                </li>
                <li className="nav-item" 
                id="interviews"
                >
                  <Link className="nav-link" 
                  // href="javascript:;"
                  
                  to = "/interviews"
                  onClick = {(e) => {
                    jQuery(e.target).closest('li').addClass('active')
                    jQuery('.nav-item').removeClass('active')
                  }

                  }
                  >Interviews</Link>
                </li>
                <li className="nav-item" id="my_company"
                
                onClick = {(e) => {
                  jQuery(e.target).closest('li').addClass('active')
                  jQuery('.nav-item').removeClass('active')
                }

                }
                >
                <Link className="nav-link" to="/my_company">
                  My Company
                </Link>
                </li>
                {/* <li className="nav-item">
                  <a className="nav-link" href="javascript:;"
                  onClick = {(e) => {
                    jQuery(e.target).closest('li').addClass('active')
                    jQuery('.nav-item').removeClass('active')
                  }

                  }
                  >Recruitment
                  </a>
                </li> */}
                
              </ul>
            </div>
          </nav>
        </div>
        <div className="col-lg-3 col-md-2 col-6 hdr-rgt">
          <div className="notify-drop">
            <span className={props.employeeNotifications &&
            props.employeeNotifications.unviewedCount === 0 ?
            '' : "count"}
            >{props.employeeNotifications &&
            props.employeeNotifications.unviewedCount === 0 ?
            '' : props.employeeNotifications.unviewedCount
          }</span>
            <button className="btn">
              <img src="/assets/images/app/notification-icon.svg" alt="icon" />
            </button>
            {props.employeeNotifications.notifications &&
            props.employeeNotifications.notifications.length > 0 &&
            <div className="dd-menu">
              <p className="lead">Notification</p>
              <p className="day"><span>Today</span></p>
              {
                props.employeeNotifications &&
              props.employeeNotifications.notifications &&
              props.employeeNotifications.notifications.length > 0 &&
            props.employeeNotifications.notifications.slice(0,4).map((i,k) => {
              return(
                <Link className="notify-item mb-2" key = {k}
                style = {{textDecoration:'none'}}
                to = {"/employer-notifi-cations"}
                onClick = {() => {
                  
                  props.viewEmployerNotification()
                }}
                >
                <div className="icon-wrap">
                  <img
                    className="img-fluid"
                    src="/assets/images/app/notify-orange.svg"
                    alt="icon"
                  />
                </div>
                
                <div className="n-cont">
                  <p>{i.notification_title}</p>
                  <span>{moment.utc((i.createdAt)).fromNow()}</span>
                </div>
              </Link>
              )
            })
            }
            <div className="w-100 text-right">
              {
                props.employeeNotifications.notifications &&
                props.employeeNotifications.notifications.length > 0 &&
                <Link 
              to = {"/employer-notifi-cations"}
              onClick = {() => {
                  
                props.viewEmployerNotification()
              }}
             className="cl-notify fs-12">View All</Link>
              }
            
          </div>
              {/* <div className="notify-item">
                <div className="icon-wrap">
                  <img className="img-fluid" src="/assets/images/app/notify-orange.svg" alt="icon" />
                </div>
                <div className="n-cont">
                  <p>Thank you for joining to Job Flex</p>
                  <span>25Mins Ago</span>
                </div>
              </div> */}
            </div>
            }
          </div>
          <div className="dropdown profile-drop">
            <button className="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img className="logo-icon" 
              style = {{height:'35px'}}
              src=
              {
                localStorage.getItem('profile_url') !== 'null' ? localStorage.getItem('profile_url') :
                 process.env.PUBLIC_URL+"/assets/images/app/profile-icon.svg"}
              // "/assets/images/app/logo-icon.png" 
              />
            </button>
            <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <div className="dd-top">
                <button className="btn btn-gray" 
                onClick = {() => {
                  // localStorage.clear()
                  localStorage.removeItem('profile_url');
                localStorage.removeItem('email');
                localStorage.removeItem('user_name');
                localStorage.removeItem('emp_id');
                localStorage.removeItem('chat_room_id');
                localStorage.removeItem('notify_employer_model');
                localStorage.removeItem('account_type_paid');
                sessionStorage.removeItem('Emp_address');
                sessionStorage.removeItem('Emp_address_city');
                sessionStorage.removeItem('Emp_address_postal_code');
                  window.location.href = '/'
                }}
                >
                <img src="/assets/images/app/logout-icon.svg" alt="icon" 

                />
                  Sign Out
                </button>
                <span>
                <Link
              to = "/my_company"
              style = {{color: '#3267d9',
              textDecoration : 'none'
            }}>
                  <img src="/assets/images/app/profile-icon.svg" alt="icon" />
                  Profile
                  </Link>
                </span>
              </div>
              <div className="p-cont">
                <p className="lead">{localStorage.getItem('user_name')}</p>
                <span>{localStorage.getItem('email')}</span>
              </div>
            </div>
          </div>
          <button className="navbar-toggler nav-res" type="button" data-toggle="collapse" data-target="#app-hdr-nav">
            <span>&nbsp;</span>
            <span>&nbsp;</span>
            <span>&nbsp;</span>
          </button>
        </div>
      </header>
)
}


const mapStateToProps = (state, ownProps) => {
    return {
        show: state.Home.show_login,
        profile_url : state.ProfileCompany.profile_pic,
        employeeNotifications :state.Notifications.employeeNotifications
        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
      setFieldValues: (f, v) => dispatch(PostedJob(f, v)),
      getEmployerNotification : (data) => dispatch(getEmployerNotification(data)),
      viewEmployerNotification : () => dispatch(viewEmployerNotification())
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
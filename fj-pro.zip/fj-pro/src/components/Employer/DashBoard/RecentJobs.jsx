import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import * as actions from '../../../actions/EmployerPostedJob';
import config from '../../../actions/Common/Api_Links';
import history from '../../../stores/history';
class RecentJobs extends Component {
    constructor(props) {
        super(props);
        this.state = {
            filter:0,
            filter_name:null,
            filter_term:null,
            page_no:0,
            limit:6,
            recentjobs:[],
            sort : false
        }
    }

    componentDidMount() {
        this.getRecentJobs({
            filter:this.state.filter,
            filter_name:this.state.filter_name,
            filter_term:this.state.filter_term,
            page_no:this.state.page_no,
            limit:this.state.limit
        })
    }

    async setSearchAndSort (val,term, name) {
        // console.log(val)
        // console.log(term)
        // console.log(name)
        
        if (name === 'sort') {
            this.setState({
                filter:term,
                filter_name:name,
                sort:!this.state.sort
                // filter_term:val,
            })
        } else {
            this.setState({
                filter:term,
                filter_name:name,
                filter_term:val,
            })
        }
        if (val === '') {
            val = null;
            name= null;
            term = 0;
        }
        await this.getRecentJobs({
            filter:term,
            filter_name:name,
            filter_term:val,
            page_no:this.state.page_no,
            limit:this.state.limit
        })
    }

    getRecentJobs(data) {

        let formData = new URLSearchParams();    //formdata object
        formData.append("employer_id",localStorage.getItem('emp_id'))
        formData.append("filter",data.filter)
        formData.append("filter_name",data.filter_name)
        formData.append("filter_term",data.filter_term)
        formData.append("page_no",data.page_no)
        formData.append("limit",data.limit)

        fetch(config.getRecentJobs, {
            method: "post",
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                this.setState({
                    recentjobs : response.data
                })
            } else {
                
            }
           
        })
    }
    render() {
        
        return (
        <div className="col-lg-8">
            <div className="hdr-row snippet mt-0">
                <h3 className="mb-0">Recent Jobs</h3>
                <div className="d-flex">
                <form className="search-form">
                    <input 
                    className="form-control" 
                    type="text" 
                    name 
                    value = {this.state.filter_term}
                    onChange = {(e) => {
                        this.setSearchAndSort(e.target.value, 1, 'search')}
                    }
                    placeholder="Search Jobs" />
                    <button className="btn">
                        <img src="/assets/images/app/search-icon.svg" alt="icon"
                        
                        />

                    </button>
                </form>
                <button className="btn sort">
                    {
                        this.state.sort ?
                        (
                            <img src={process.env.PUBLIC_URL+"/assets/images/app/sort-icon.svg"}
                            alt="icon" 
                            onClick = {(e) => this.setSearchAndSort(2, 1, 'sort')}
                        />
                        ): (
                            <img src={process.env.PUBLIC_URL+"/assets/images/app/desc-sort-icon.svg"} 
                            alt="icon" 
                            onClick = {(e) => this.setSearchAndSort(1, 1, 'sort')}
                            />
                        )
                    }
                </button>
                </div>
            </div>
            <div className="row">
                {
                    this.state.recentjobs &&
                    this.state.recentjobs.length > 0 ?
                    this.state.recentjobs.slice(0, 2).map((i, k) => {
                        return (
                            
                            <div className="col-md-6" key = {k}>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    <li><Link to = {`/edit/job-post/${i.id}`}>Edit job</Link></li>
                                    {/* <li><a href="javascript:;">Share</a></li> */}
                                    {/* <li><a 
                                    href="javascript:;" 
                                    onClick = {() => {
                                        history.push(`/employer_posted_job_details/${i.id}`)
                                   
                                    }}
                                    className="red">View Job</a></li> */}
                                    </ul>
                                </div>
                                </div>
                                <h6
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >{i.job_position}</h6>
                                <p
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >{'Per-Hour'} {i.currency} 
                                {new Intl.NumberFormat('en-US', 
                                       {style: 'decimal', minimumFractionDigits: 2}).
                                       format(isNaN(i.amount)
                                       ? '0.00':i.amount)
                                }
                                </p>
                                <span className="location"
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job_location}
                                </span>
                            </div>
                            </div>
                            
                        )
                    }): (
                        <>
                        <div className = "row"
                        style = {{
                            
                            textAlign: 'center',
                            marginLeft: '148px',
                            marginTop: '100px'

                        }}
                        >
                        <h3>No jobs yet</h3>
                        </div>
                        </>
                    )
               
                }
            
            </div>
            <div className="row">
                {
                    this.state.recentjobs &&
                    this.state.recentjobs.length > 0 &&
                    this.state.recentjobs.slice(2, 4).map((i, k) => {
                        return (
                           
                            <div className="col-md-6" key = {k}>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    <li><Link to = {`/edit/job-post/${i.id}`}>Edit job</Link></li>
                                    {/* <li><a href="javascript:;">Share</a></li> */}
                                    {/* <li><a 
                                    href="javascript:;" 
                                    onClick = {() => {
                                        history.push(`/employer_posted_job_details/${i.id}`)
                                      
                                        }}
                                    className="red">View Job</a></li> */}
                                    </ul>
                                </div>
                                </div>
                                <h6
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >{i.job_position}</h6>
                                <p
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >{'Per-Hour'} {i.currency} {
                                new Intl.NumberFormat('en-US', 
                                {style: 'decimal', minimumFractionDigits: 2}).
                                format(isNaN(i.amount)
                                ? '0.00':i.amount)
                                
                                }</p>
                                <span className="location" onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}>
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job_location}
                                </span>
                            </div>
                            </div>
                            
                        )
                    })
               
                }
            
            </div>
            <div className="row">
                {
                    this.state.recentjobs &&
                    this.state.recentjobs.length > 0 &&
                    this.state.recentjobs.slice(4, 6).map((i, k) => {
                        return (
                            
                            <div className="col-md-6" key = {k}>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    <li><Link to = {`/edit/job-post/${i.id}`}>Edit job</Link></li>
                                    {/* <li><a href="javascript:;">Share</a></li> */}
                                    {/* <li><a 
                                    href="javascript:;" 
                                    onClick = {() => {
                                        history.push(`/employer_posted_job_details/${i.id}`)
                                    
                                    }}
                                    className="red">Job Close</a></li> */}
                                    </ul>
                                </div>
                                </div>
                                <h6 className="n__pointer"
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                > {i.job_position}</h6>
                                <p className="n__pointer"
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >{'Per-Hour'} {i.currency} {i.amount}</p>
                                <span className="location n__pointer"
                                onClick = {() => history.push(`/employer_posted_job_details/${i.id}`)}
                                >
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job_location}
                                </span>
                            </div>
                            </div>
                            
                        )
                    })
               
                }
            
            </div>
            </div>
        
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    
    return {
        
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        ClosedJob : (data) => dispatch(actions.ClosedJob(data))   
    }
};

const recentjobs = connect(
    mapStateToProps,
    mapDispatchToProps,
)(RecentJobs);

export default recentjobs;





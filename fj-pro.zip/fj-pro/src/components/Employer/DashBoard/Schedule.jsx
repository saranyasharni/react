import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import moment from "moment";
// import { Link } from "react-router-dom";
// import * as actions from '../../../actions/Employer/Chat';
// import config from '../../../actions/Common/Api_Links'
const result_arr = [{
    time:'',
    position_name:'',
    interview_time:''
}]
class Schedule extends Component {
    constructor(props) {
        super(props);
        this.state = {
            scheduleDate : [],
            time: moment().format("dddd, Do MMMM, YYYY"),
            events: [],
        }
    }
    
    componentWillMount() {
        function parseTime(s) {
            return parseInt(s * 60);
        }
          
        function getEndTime(s) {
            // console.log(s, 'oioiyyuttyryt')
            let convet_min = s*60
            return parseInt(convet_min + (60*8));
        }

        function convertHours(mins) {
            var hour = Math.floor(mins/60);
            // var mins = mins%60;
            // var mid='PM';
           if (hour>24) {
                let show_hour=hour%24;
                if (show_hour === 0) {
                    hour = 12
                    // mid='AM';
                } else {
                    hour=show_hour;
                    // mid='PM';
                }
            }
            // var converted = hour+' '+mid;
            // return converted;
            return('0' + hour).slice(-2)
        }
    
        function calculate_time_slot(start_time, end_time, interval) {
            var i, formatted_time;
            var time_slots = new Array();
            // console.log(start_time, 'strart_ime')
            // console.log(end_time, 'end_time')
            for (var i=start_time; i<=end_time; i = i+interval) {
              formatted_time = convertHours(i);
              time_slots.push(formatted_time);
            }
            return time_slots;
        }

        var hours = new Date().getHours();
        
        var start_time = parseTime(hours),
            end_time = getEndTime(hours),
            interval = 60;
    
        var times_ara = calculate_time_slot(start_time, end_time, interval );
        this.setState({
            scheduleDate:times_ara
        })
        // console.log(times_ara, 'timerr');
    }

    componentDidUpdate() {
        if (this.props.scheduleList && this.props.scheduleList.length > 0) {
            if (this.state.scheduleDate) {
              
                this.state.scheduleDate.map((i,k) => {
                   
                    let start = i + ":" +"00"
                    let end = i + ":" +"59"
        
                    this.props.scheduleList.map((m,n) => {
                        // console.log(m.start_time, 'start')
                        // console.log(start)
                        // console.log(end, 'end')  
                        m.start_time = '21:00'
                        var today = new Date();
                        var dd = String(today.getDate()).padStart(2, '0');
                        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                        var yyyy = today.getFullYear();

                        today = mm + '/' + dd + '/' + yyyy;
                        
                        
                        let comparing_date = new Date(today +' '+ m.start_time);
                        let start_date = new Date(today +' '+ start)
                        let end_date = new Date(today +' '+ end)
                        // let date2 = new Date(todaysJob.login_date + ' ' + job.end_time);
                        
                        if ((comparing_date.getTime() >= start_date.getTime())&&(comparing_date.getTime()<=end_date.getTime())) {
                            // let result = [...result_arr]
                            // result[k].time = start
                            // result[k].position_name = m.job_application.job.job_position
                            // result[k].interview_time = m.start_time + ' - ' +m.end_time
                        } else {
                            // let result = [...result_arr]
                            // console.log(k, 'kill')
                            // result[k].time = "null"
                            // result[k].position_name = "null"
                            // result[k].interview_time = "null"
                        }
                    })
                   
                })
               
                // console.log(result_arr,'result_arr')
                // if (result_arr[0].time) {
                //     this.setState({
                //         events:result_arr
                //     })
                // } else {
                //     this.setState({
                //         events:result_arr
                //     })
                // }
            }
        }   
        // console.log(this.props.scheduleList,'scheduleList')
    }
    
    render() {
        
        return (
            
            <div className="col-lg-3 col-md-12">
                {/* {console.log(this.state.scheduleDate, 'this.state.scheduleDate')} */}
            <div className="col px-0">
            <h3>
                {this.state.time}
                {/* Thursday, 26 Oct, 2020 */}
            </h3>
            <div className="snippet-box time-list">
                {
                    this.props.scheduleList && 
                    this.props.scheduleList.length ?
                    this.props.scheduleList.slice(0,6).map((i,k) => {
                        // let daysNow = new Date()
                        // let start = moment(i.interview_date+' '+ i.start_time)
                        // let start_intrviw_time = moment(start).format("h:mm a");
                    return (
                      
                    <div className="time-list-item" key = {k}>
                      <div className="time-box">
                          {i.start_time
                          } 
                      </div>
                      <div className="t-cont">
                          <p className="text-truncate">{i.job_application &&
                          i.job_application.job &&
                          i.job_application.job.job_position
                          } Interview</p>
                          <span className="text-truncate">
                            {
                          i.start_time
                          }- {i.end_time}</span>
                      </div>
                      </div>
                      )  
                    })
                    :"No Interviews today"
                }
                
                {/* <div className="time-list-item">
                <div className="time-box">
                    7 
                </div>
                <div className="t-cont empty" />
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    8 
                </div>
                <div className="t-cont empty" />
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    9 
                </div>
                <div className="t-cont">
                    <p className="text-truncate">Purchase manager Interview</p>
                    <span className="text-truncate">4 Canditaties 8:30 AM - 9:30 AM</span>
                </div>
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    10 
                </div>
                <div className="t-cont empty" />
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    11 
                </div>
                <div className="t-cont empty" />
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    12 
                </div>
                <div className="t-cont empty" />
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    1 
                </div>
                <div className="t-cont empty" />
                </div>
                <div className="time-list-item">
                <div className="time-box">
                    2 
                </div>
                <div className="t-cont empty" />
                </div> */}
            </div>
            </div>
            </div>     
            
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    // console.log(state, 'stateval')
    return {
        // scheduleList:state.Hire.scheduleList,   
        scheduleList:state.Hire.scheduleList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
    }
};

const schedule = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Schedule);

export default schedule;





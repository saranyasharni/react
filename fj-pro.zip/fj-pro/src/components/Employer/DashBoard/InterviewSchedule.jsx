import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../actions/Employer/Hire";
import $ from 'jquery';

function InterviewSchedule(props) {
    const [formFields, setFormFields] = useState({
        date:'',
        start_time:'',
        end_time:'',
        position :'',
        industry_type:"F&B",
        errors: {}
    })

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();
            window.$(".input-group.start_date").datepicker({
                format: "mm/dd/yyyy",
                todayHighlight: true,
                autoclose:true
                // endDate: "+0d",
                }).off("change")
                .change((e) => {{
                    setFormFields({
                        ...formFields,
                        date: e.target.value
                    }); 
                }});
        })
    });

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();
            window.$(".input-group.start_date")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
        })
    }, []);

    const updateErrors = errors => {
        setFormFields({
          ...formFields, 
          errors: { ...formFields.errors, ...errors }
        });
    };

    const validation = async (e) => {
        let errors = formFields.errors;
        let valid = true;

        if (formFields.date === '') {
            errors.date = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        if (formFields.start_time === '') {
           
            errors.start_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        if (formFields.end_time === '') {

            errors.end_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        updateErrors(errors);
        return valid;
    } 

    const submitScheduleInterview = async(e) => {
        // console.log(formFields.errors, 'formFields.errors')
        e.preventDefault();
        const result = await validation();
        if (result) {
            props.scheduleInterview({
                application_id:props.modelSchedule.application_id,
                employee_id: props.modelSchedule.employee_id,
                job_id : props.modelSchedule.job_id === null 
                ? formFields.position : props.modelSchedule.job_id,
                employer_id: localStorage.getItem('emp_id'),
                status_code: 8,
                interview_date: formFields.date,
                start_time: formFields.start_time,
                end_time: formFields.end_time,
                request : props.modelSchedule.request
            })
        } 
    }
    
    return (
        <Modal 
        // show={props.modelSchedule.show} 
            className="modal fade custom-modal"
            // style={{ "paddingRight": 17 }} 
            onHide={(e) => props.setShowModel({
                employee_id :props.modelSchedule.employee_id,
                application_id : props.modelSchedule.application_id,
                show: false,
                job_id : props.modelSchedule.job_id,
                show_status: props.modelSchedule.show_status,
                request:props.modelSchedule.request,
            })}
            id="arrange-interview"
            tabindex="-1" role="dialog" 
            aria-hidden="true"
            centered
        > 
        <div className="modal-content">
        <div className="modal-header">
        <h5 className="mt-2 modal-title w-100 justify-content-center">Arrange Interview</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
          <img className="img-fluid" src="images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3">
        <div className="row">
          <form className="form-section col-md-12">
            <div className="form-group">
              <label>Date</label>
              <div className="input-group date mar-t-no" data-date-format="dd/mm/yyyy">
                <input type="text" className="form-control" />
                <div className="input-group-addon">
                  <img src="images/calendar-icon.svg" alt="icon" />
                </div>
              </div>
            </div>
            <div className="row">
              <div className="form-group col-md-6">
                <label>Start Time</label>
                <input type="time" className="form-control" name />
              </div>
              <div className="form-group col-md-6">
                <label>End Time</label>
                <input type="time" className="form-control" name />
              </div>
            </div>
          </form>
        </div>
        <div className="row mt-2 mb-3">
          <div className="col-md-12 text-right">
            <button className="btn btn-blue">Arrange Interview</button>
          </div>
        </div>
        </div>
        </div>
    
    </Modal>
    )
};

const mapStateToProps = (state, ownProps) => {
    return {
        
        positions:state.Hire.positions,
        
        modelSchedule:state.Hire.modelSchedule
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setShowModel: (data, show, request) => 
        dispatch(actions.setShowModel(data, show, request)),
       
        getAllPositions: (data) => dispatch(actions.getAllPositions(data)),
        scheduleInterview : (data) => dispatch(actions.scheduleInterview(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(InterviewSchedule);
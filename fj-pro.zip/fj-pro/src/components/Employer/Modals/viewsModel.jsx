import React, { useEffect } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import { PostedJob, View } from "../../../actions/EmployerPostedJob";
import history from "../../../stores/history";
import { MyComapanyValues } from "../../../actions/myCompanyHire";


function Views(props) {
  useEffect(() => {
    // require("../../../assets/css/app-style.css");
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    // const elem2 = document.createElement("link");
    // elem2.rel = "stylesheet"
    // elem2.type = "text/css"
    // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    // elem2.id = "design_app_style"
    // elem2.async = true;
    // document.head.appendChild(elem2);

  }, []);
  return (
    <Modal show={props.show} className="custom-modal"
      style={{ "paddingRight": 17 }} 
      onHide={() => props.setFieldValues('views_show', false)}
      tabindex="-1" role="dialog" aria-hidden="true"
      centered>
      {/* // <div className="modal fade custom-modal" id="views-modal" tabIndex={-1} role="dialog" aria-hidden="true">
        //   <div className="modal-dialog modal-dialog-centered" role="document">
        //     <div className="modal-content"> */}
      <div className="modal-header">
        <h5 className="modal-title">
          <img src="/assets/images/app/user-icon.png" alt="icon" />
                  Views
                </h5>
        <button type="button" className="close" onClick={() => props.setFieldValues('views_show', false)}>
          <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body">
        <div className="col-12">
          <div className="row">
            <div className="card-encl">
              {
                props.view_list.length >0 ? (
                     
                  props.view_list.map((lis, k) => {
                    
                    return (
                      <div className="card-row" key = {k}>
                        <div className="card-left">
                          <div className="avatar">
                            <img className="img-fluid" src="/assets/images/app/avatar-1.png" alt="Username" />
                          </div>
                        </div>
                        <div className="card-right">
                          <div>
                            <p className="lead">{lis.employee.name}</p>
                            <span className="sub">{lis.job.job_title}</span>
                          </div>
                          <a href="javascript:;" className="btn btn-blue"
                          onClick={()=>{
                          props.setFieldValues('views_show', false);
                          history.push(`/view-profile/0/${lis.employee.id}/search-employee`)
                          props.MyComapanyValues("prof",lis.employee.id)}}>Profile</a>
                        </div>
                      </div>
                    )
                  })
                  ) :(
                    
                    <div className="nodata">
                      <img src="/assets/images/app/undraw-empty-modal.svg" alt="icon" />
                      <p>No data</p>
                    </div>
                  )

                }
              
            </div>
          </div>
        </div>
      </div>

    </Modal>
  )
}

const mapStateToProps = (state, ownProps) => {
  return {
    show: state.Postedjob.views_show,
    job_id: state.Postedjob.job_id,
    view_list: state.Postedjob.view_list,
    // categories: state.Home.categories
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setFieldValues: (f, v) => dispatch(PostedJob(f, v)),
    MyComapanyValues:(val,id)=>dispatch(MyComapanyValues(val,id)),

  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Views);
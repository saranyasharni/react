import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../../actions/Employer/Hire";
import $ from 'jquery';
import moment from 'moment';
import DatePicker from "react-datepicker";
function InterviewScheduleModel(props) {
    
    const [formFields, setFormFields] = useState({
        date:'',
        start_time:'',
        end_time:'',
        position :'',
        interview_methode:'',
        interview_detail:'',
        industry_type:"",
        errors: {}
    })
    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();
        //     window.$(".input-group.date")
        //     .datepicker({
        //     format: "dd/mm/yyyy",
        //     todayHighlight: true,
        //     autoclose:true
        //     // endDate: "+0d",
        //     })
        //     window.$('.time-picker').datetimepicker({
        //         format: 'hh:mm A',
        //         stepping: 30,
        //         icons: {
        //             up: "fa fa-angle-up",
        //             down: "fa fa-angle-down"
        //         }
        // }).on('dp.change', function (e) {  
            
        // });      
        })
    }, []);

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        // if (props.hire_status === 1 || props.hire_status === 2) {
        //     emptyValues()
        // }
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker('refresh');
            // window.$(".input-group.date").datepicker({
            //     format: "dd/mm/yyyy",
            //     todayHighlight: true,
            //     autoclose: true
            //     // endDate: "+0d",
            //     }).off("change")
            //     .change((e) => {{
            //         setFormFields({
            //             ...formFields,
            //             date: e.target.value
            //         }); 
            //     }});
            // window.$('.time-picker').datetimepicker({
            //         format: 'hh:mm A',
            //         stepping: 30,
            //         icons: {
            //             up: "fa fa-angle-up",
            //             down: "fa fa-angle-down"
            //         }
            // }).on('dp.change', function (e) {  
                
            // });    
        })
    });
    const updateErrors = errors => {
        setFormFields({
          ...formFields, 
          errors: { ...formFields.errors, ...errors }
        });
    };
    const emptyValues = () => {
        setFormFields({
            ...formFields,
            start_time:"",
            date: "",
            end_time: "",
            position :'',
            industry_type:"",
            errors:{}
        }); 
    }
    const validation = async (e) => {
        let errors = formFields.errors;
        let valid = true;

        if (formFields.date === '') {
            errors.date = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }
        var day = new Date();
        var nextDay = new Date(day);
        nextDay.setDate(day.getDate()-1);
        if (new Date(formFields.date) < nextDay) {
            errors.date =  `Past days are not allowed to schedule `
            updateErrors(errors);
            valid = false; 
        } 

        if (formFields.start_time === '') {
           
            errors.start_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        if (formFields.end_time === '') {

            errors.end_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        updateErrors(errors);
        return valid;
    } 

    const submitScheduleInterview = async(e) => {
        // console.log(formFields.errors, 'formFields.errors')
        e.preventDefault();
        const result = await validation();
        
        if (result) {
            props.scheduleInterview({
                application_id:props.modelSchedule.application_id,
                employee_id: props.modelSchedule.employee_id,
                job_id : props.modelSchedule.job_id === null 
                ? formFields.position : props.modelSchedule.job_id,
                interview_method: formFields.interview_methode,
                interview_details: formFields.interview_detail,
                // job_id : props.modelSchedule.job_id === null 
                // ? $('#interview_position').find("option:selected").text() : props.modelSchedule.job_id,
                employer_id: localStorage.getItem('emp_id'),
                status_code: 8,
                interview_date: moment(formFields.date, "DD/MM/YYYY").format("MM/DD/YYYY"),
                start_time: moment(formFields.start_time, "hh:mm A").format("HH:mm"),
                end_time: moment(formFields.end_time, "hh:mm A").format("HH:mm"),
                request : props.modelSchedule.request
            })
            setTimeout(function(){
                emptyValues()
            },1000)
            
        } 
    }
    
    return (
    <Modal className="modal fade custom-modal" 
    id="arrange-interview" tabIndex={-1} role="dialog" aria-hidden="true"
    centered
    onHide={() => props.setShowModel({
      employee_id :props.modelSchedule.employee_id,
      application_id : props.modelSchedule.application_id,
      show: false,
      job_id : props.modelSchedule.job_id,
      show_status: props.modelSchedule.show_status,
      request:props.modelSchedule.request,
    })}
    show={props.modelSchedule.show} 
    
    >
    {/* <div className="modal-dialog modal-dialog-centered" role="document"> */}
    <div className="modal-content">

      <div className="modal-header">
        <h5 className="mt-2 modal-title w-100 justify-content-center">Arrange Interview</h5>
        <button type="button" className="close" 
        data-dismiss="modal" aria-label="Close"
        onClick={() => {
            
            setFormFields({
                ...formFields,
                start_time:"",
                date: "",
                end_time: "",
                errors:{}
            }); 
            props.setShowModel({
            employee_id :props.modelSchedule.employee_id,
            application_id : props.modelSchedule.application_id,
            show: false,
            job_id : props.modelSchedule.job_id,
            show_status: props.modelSchedule.show_status,
            request:props.modelSchedule.request,
          })}}
        >
          <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3">
        <div className="row">
          <form className="form-section col-md-12"> 
          { 
            props.modelSchedule &&
            props.modelSchedule.show_status === 'show' &&
            <div className="form-group">
            <label>Select Category</label>
            <select className="form-control selectpicker"
            id = "short_select_industry"
            data-live-search="true"    
            title = "Choose Category"
            value = {formFields.industry_type}
            onChange = {(e) => {
                
                setFormFields({
                    ...formFields,
                    industry_type: e.target.value
                });
                
                props.getAllPositions
                ({
                industry_type: e.target.value
                });
            
            }}
            >
            {
                props.industries &&
                props.industries.length > 0 &&
                props.industries.map((i,k) => {
                return <option
                key = {k}
                value = {i.industry_type}>{i.industry_type}</option>
                
                })
            }
            {/* <option value = "Events & Promotions">Events &amp; Promotions</option>
            <option value = "F&B">F&amp;B</option>
            <option value = "Hospitality"> Hospitality</option>
            <option value = "Logistics">Logistics</option> */}
        </select>
   
        </div>                     
        }
        {
            props.modelSchedule &&
            props.modelSchedule.show_status === 'show' &&
            <div className=" form-group">
            <label>Select Position</label>
            <select className="form-control selectpicker"
            id = "interview_position"
            data-live-search="true"    
            title = "Choose Position"
            value = {formFields.position}
            onChange = { (e) => 
                setFormFields({
                    ...formFields,
                    position: e.target.value
                })
            }
            >
            {
                props.positions && 
                props.positions.length > 0 &&
                props.positions.map((i,k) => {
                    return (
                        <option 
                        key = {k}
                        value = {i.id}>
                        {i.job_position}
                        </option>         
                    )
                })
            }
                
            </select>
            {/* {formFields.errors.date &&
                formFields.errors.date.length > 0 ? (
                <small className="text-danger">
                    {formFields.errors.date}
                </small>
                ) : (
                ""
            )} */}
            </div>                     

            }
                  
            <div className="form-group">
                <label>Date</label>
                {/* <div className="input-group date mar-t-no" data-date-format="dd/mm/yyyy"> */}
                {/* <input type="text" className="form-control" 
                value = {formFields.date}
                /> */}
                 <DatePicker 
                    className="form-control"
                    dateFormat = 'dd/MM/yyyy'
                    placeholderText = "DD/MM/YYYY"
                    minDate={new Date()}
                    onChange={(date) => {
                        setFormFields({
                            ...formFields,
                            date: date
                        }); 
                    }}
                    name = "date_interview"
                    selected={formFields.date} 
                />
                {/* <div className="input-group-addon">
                  <img src="/assets/images/calendar-icon.svg" alt="icon" />
                </div> */}
              {/* </div> */}
              {formFields.errors.date &&
                formFields.errors.date.length > 0 ? (
                <small className="text-danger">
                    {formFields.errors.date}
                </small>
                ) : (
                ""
              )}
            </div>
            <div className="row">
              <div className="form-group col-md-6">
                <label>Start Time</label>
                <DatePicker 
                    className="form-control"
                    
                    placeholderText = "HH:MM"
                    selected={formFields.start_time}
                    name = "start_date_time_start"
                    onChange={(date) => {
                        setFormFields({
                            ...formFields,
                            start_time: date
                        }); 
                    }}    
                    showTimeSelect
                    showTimeSelectOnly
                    timeIntervals={30}
                    timeCaption="Time"
                    dateFormat="h:mm aa"
                
                />
                {/* <input type="text" className="form-control time-picker"
                onBlur = {(e) => {
                    setFormFields({
                        ...formFields,
                        start_time: e.target.value
                    }); 
                }}
                value = {formFields.start_time}
                /> */}
                
                {formFields.errors.start_time &&
                    formFields.errors.start_time.length > 0 ? (
                    <small className="text-danger">
                        {formFields.errors.start_time}
                    </small>
                    ) : (
                    ""
                )}
              </div>
              <div className="form-group col-md-6">
                <label>End Time</label>
                <DatePicker 
                    className="form-control"
                    placeholderText = "HH:MM"
                    selected={formFields.end_time}
                    name = "start_date_time_start"
                    onChange={(date) => {
                        setFormFields({
                            ...formFields,
                            end_time:date
                        });
                    }}    
                    showTimeSelect
                    showTimeSelectOnly
                    timeIntervals={30}
                    timeCaption="Time"
                    dateFormat="h:mm aa"
                />
                {formFields.errors.end_time &&
                    formFields.errors.end_time.length > 0 ? (
                    <small className="text-danger">
                        {formFields.errors.end_time}
                    </small>
                    ) : (
                    ""
                )}
              </div>
            </div>
            <div className="row">
              <div className="form-group col-md-6">
                <label>Interview Method</label>
                <select className="form-control selectpicker"
                id = "interview_method"
                data-live-search="true"    
                title = "Choose Method"
                value = {formFields.interview_methode}
                onChange = { (e) => 
                    setFormFields({
                        ...formFields,
                        interview_methode: e.target.value
                    })
                }
                >
                <option 
                value = "WhatsApp">
                WhatsApp 
                </option>
                <option 
                value = "Face to face">
                Face to face 
                </option>         
            </select>  
              
              </div>
              <div className="form-group col-md-6">
                <label>Details</label>
                <input type="text" 
                className="form-control time-picker" 
                value = {formFields.interview_detail}
                onChange = {(e) => {
                    setFormFields({
                        ...formFields,
                        interview_detail: e.target.value
                    });
                }}
                name = "interview_detail"
                />
             
              </div>
            </div>
          </form>
        </div>
        <div className="row mt-2 mb-3">
            <div className="col-md-12 text-right">
            <button className="btn btn-blue"
            disabled = {props.btnLoading ? true:false}
            onClick={
              submitScheduleInterview
              // console.log(formFields.start_time, 'formFields.start_time');
              // console.log(formFields.end_time, 'formFields.start_time');
              // console.log(formFields.date, 'formFields.date')
            } 
            >
            {
            props.btnLoading ? 'Loading...':'Arrange Interview'}
            </button>
          </div>
        </div>
      </div>
    </div>
    {/* </div> */}
    </Modal>
    )
};

const mapStateToProps = (state, ownProps) => {
    return {
        industries : state.Home.industries,
        positions:state.Hire.positions,
        btnLoading:state.Hire.btnLoading,
        modelSchedule:state.Hire.modelSchedule,
        hire_status: state.Hire.hire_status
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        // setShowModel: (data, show, request) => 
        // dispatch(actions.setShowModel(data, show, request)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        getAllPositions: (data) => dispatch(actions.getAllPositions(data)),
        scheduleInterview : (data) => dispatch(actions.scheduleInterview(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(InterviewScheduleModel);
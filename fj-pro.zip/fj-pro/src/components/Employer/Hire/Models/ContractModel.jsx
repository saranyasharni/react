import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../../actions/Employer/Hire";
import $ from 'jquery';
import Dropzone from "react-dropzone";
import config from "../../../../actions/Common/Api_Links";

function ContractModel(props) {
    
    const [state, setState] = useState({
        loading:false,
        upload_url:""
    })
    
    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
        window.$(".input-group.start_date")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
            autoclose:true
        // endDate: "+0d",
        })
    })
    }, []);

    useEffect(() => {
        
        if (props.hired_status === 1) {
            // props.setContractModal(false);
            // window.$('#send-contract').modal('show')
            // setTimeout(function () {
            //     // window.location.reload()
            // }, 2000);
        } else if (props.hired_status === 2) {
            
            $("#hiring-candi-modal .alert").html(
                `<strong>Sorry!</strong> ${props.hired_status_msg}.`
              );
              $("#hiring-candi-modal .alert")
                .removeClass("alert-success")
                .addClass("alert-danger");
                props.setHiredStatus(0, '');
              setTimeout(function () {
                $("#hiring-candi-modal .alert").removeClass("alert-danger");
                $("#hiring-candi-modal .alert").html("");
                
              }, 2000);
        }
    })

    const  handleDropzone = (files) => {
    
        if (files) {
            let formData = new FormData();
            formData.append('upload_file', files[0]);
            setState({
                ...state,
                loading:true
            })
            fetch(config.uploadProfilePic, {
            method: "post",
            headers: {
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: formData,
            })
            .then((response) => response.json())
            .then((response) => {
            if (response.status == 1) {
                setState({
                    ...state,
                    loading:false,
                    upload_url:response.file_links_data[0].original_data
                })
                
                
            } else {
                setState({
                    ...state,
                    loading:false,
                    upload_url:response.file_links_data[0].original_data
                })
                props.setSuccess(2, 'Please Upload after some time')
            }
            })
            .catch((e) => {
                setState({
                    ...state,
                    loading:false,
                })
                props.setSuccess(2, 'Please try again')
            
            });
        }
    }
    return (
        <>
        <Modal show={props.showContractModel} 
            className="modal fade custom-modal"
            onHide={() => {{
                props.setContractModal(true)
            }}} 
            className="modal fade custom-modal" 
            id="send-contract" 
            tabIndex={-1} 
            role="dialog" 
            aria-hidden="true">
            {/* <div className="modal-dialog modal-dialog-centered" role="document"> */}
                <div className="modal-content">
                <div className="modal-header">
                    <h5 className="mt-2 modal-title w-100 justify-content-center">Send Contract</h5>
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close"
                    onClick = {() => {
                        props.setContractModal(false)
                    }}
                    >
                    <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                    </button>
                </div>
                <div className="modal-body px-md-5 px-3">
                    <div className="row">
                    <div className="col-md-12">
                        <p className="fs-14 dark">Job contract has been sent to candidate. After confirmed, the selected candidate can immediately begin working.</p>
                    </div>
                    </div>
                </div>
                </div>
            {/* </div> */}
        </Modal> 
        

        {/* <Modal show={props.showContractModel} 
            className="modal fade custom-modal"
            onHide={() => {{
                props.setContractModal(true)
            }}}
            id="hiring-candi-modal" 
            tabIndex={-1} 
            role="dialog" 
            aria-hidden="true"
            centered
        >
                
        <div className="modal-content">
        <div className="modal-header">
            <h5 className="mt-2 modal-title w-100 justify-content-center">Hire Candidate</h5>
            <button type="button" className="close" data-dismiss="modal" aria-label="Close"
            onClick={() => {{
                props.setContractModal(false)
            }}}
            >
            <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
            </button>
        </div>
        <div className="modal-body px-md-5 px-3">
            <div className="row">
            <div className="col-md-12">
                <p className="fs-14 dark">You have paid for the salary. Insert the job contract to send it to the employee.</p>
            </div>
            <form className="form-section col-md-12">
            <div className="alert" role="alert">  </div>
                <div className="form-group">
                <label>Upload Proof of Business Document</label>
                <Dropzone
                    onDrop={(acceptedFiles) => {
                    var infoArea = document.getElementById( 'file-upload-filename');
                    var fileName =  acceptedFiles[0].name;
                    infoArea.textContent =  fileName;
                    handleDropzone(acceptedFiles);
                    }}
                >
                    {({ getRootProps, getInputProps }) => (
                    <div
                        className="upload-wizard fill"
                        style={{ outline: "none" }}
                        {...getRootProps()}
                    >
                    
                        <input
                        {...getInputProps()}
                        id="resume_upload"
                        type="file"
                        style={{ display: "none" }}
                        ></input>
                        
                        <span>
                        Upload Proof of Business Document
                        <br /> or
                        </span>
                        <a href="javascript:;">Browse File</a>
                        <strong  id="file-upload-filename" />
                        <strong>
                        {
                            
                        state.loading ? "Uploading..." : ""}
                        </strong>
                    </div>
                    )}
                </Dropzone>
                {/* <div className="upload-wizard fill">
                    <input 
                    type= "file"
                    id = "input_hidden"
                    style={{ display: "none" }} 
                    />
                    <span
                    onClick={() => $('#input_hidden').click()} 
                    >Upload your document here</span>
                </div> 
                </div>
            </form>
            </div>
            <div className="row mt-2 mb-3">
            <div className="col-md-12 text-right">
                <button className="btn btn-blue"
                onClick = {() => {
                    props.hireEmployee({
                        employee_id:props.scheduledInfo.employee_id,
                        job_id:props.scheduledInfo.job_id,
                        status_code:3,
                        url:state.upload_url
                    })    
                }}
                >Send Contract</button>
            </div>
            </div>
            </div>
            
            </div>

          </Modal> */}

          {/* <div className="modal fade custom-modal" id="send-contract" tabIndex={-1} role="dialog" aria-hidden="true">
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                <div className="modal-header">
                    <h5 className="mt-2 modal-title w-100 justify-content-center">Send Contract</h5>
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close"
                    onClick = {() => {
                        props.setContractModal(false)
                    }}
                    >
                    <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                    </button>
                </div>
                <div className="modal-body px-md-5 px-3">
                    <div className="row">
                    <div className="col-md-12">
                        <p className="fs-14 dark">Job contract has been sent to candidate. After confirmed, the selected candidate can immediately begin working.</p>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div> */}

        </>
    )
};

const mapStateToProps = (state, ownProps) => {
    return {
        hired_status: state.Hire.hired_status,
        hired_status_msg : state.Hire.hired_status_msg ,
        showContractModel : state.Hire.showContractModel
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setContractModal : (data) => dispatch(actions.setContractModal(data)),
        hireEmployee : (data) => dispatch(actions.hireEmployee(data)),
        setHiredStatus : data => dispatch(actions.setHiredStatus(data)),
        setSuccess : (data) => dispatch(actions.setSuccess(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ContractModel);
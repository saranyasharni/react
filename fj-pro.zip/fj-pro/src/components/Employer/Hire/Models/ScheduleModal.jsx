import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../../actions/Employer/Hire";
import $, { error } from 'jquery';

function ShortListModel(props) {
    const [formFields, setFormFields] = useState({
        date:'',
        start_time:'',
        end_time:'',
        position :'',
        industry_type:"",
        errors: {}
    })

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();
            window.$(".input-group.date")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
        })
    }, []);

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker('refresh');
            window.$(".input-group.date").datepicker({
                format: "mm/dd/yyyy",
                todayHighlight: true,
                autoclose:true
                // endDate: "+0d",
                }).off("change")
                .change((e) => {{
                    setFormFields({
                        ...formFields,
                        date: e.target.value
                    }); 
                }});
        })
    });

    
    const updateErrors = errors => {
        
        console.log(errors, 'errors')
        setFormFields({
          ...formFields, 
          errors: { ...formFields.errors, ...errors }
        });
    };

    const validation = async (e) => {
        let errors = formFields.errors;
        let valid = true;

        if (formFields.date === '') {
            errors.date = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }
        var day = new Date();
        var nextDay = new Date(day);
        nextDay.setDate(day.getDate()-1);
        if (new Date(formFields.date) < nextDay) {
            errors.date =  `Past days are not allowed to schedule `
            updateErrors(errors);
            valid = false; 
        } 

        if (formFields.start_time === '') {
           
            errors.start_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        if (formFields.end_time === '') {

            errors.end_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        updateErrors(errors);
        return valid;
    } 

    const submitScheduleInterview = async(e) => {
        // console.log(formFields.errors, 'formFields.errors')
        e.preventDefault();
        const result = await validation();
        
        if (result) {
            props.scheduleInterview({
                application_id:props.scheduleModels.application_id,
                employee_id: props.scheduleModels.employee_id,
                job_id : props.scheduleModels.job_id === null 
                ? formFields.position : props.scheduleModels.job_id,
                // job_id : props.scheduleModels.job_id === null 
                // ? $('#interview_position').find("option:selected").text() : props.scheduleModels.job_id,
                employer_id: localStorage.getItem('emp_id'),
                status_code: 8,
                interview_date: formFields.date,
                start_time: formFields.start_time,
                end_time: formFields.end_time,
                request : props.scheduleModels.request
            })
        } 
    }
    
    return (
    <Modal className="modal fade custom-modal"
    
    show={props.scheduleModels.show} 
     id="arranging-interviews" tabIndex={-1} role="dialog" aria-hidden="true"
     onHide = {(e) => {
        props.scheduleModel({
            employee_id :props.scheduleModel.employee_id,
        application_id : props.scheduleModel.application_id,
        show: false,
        job_id : props.scheduleModel.job_id,
        show_status: props.scheduleModel.show_status,
        request:props.scheduleModel.request,
        })
    }}
    >
     
    {/* <div className="modal-dialog modal-dialog-centered" role="document"> */}
    <div className="modal-content">
      <div className="modal-header">
        <h5 className="mt-2 modal-title w-100 justify-content-center">Arrange Interview</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close"
        onClick = {(e) => {{
            // updateErrors({
            //     date: "",
            //     end_time: "",
            //     start_time : ""
            // });
            setFormFields({
                ...formFields,
                start_time:"",
                date: "",
                end_time: "",
                errors:{}
            }); 
            
            props.scheduleModel({
            employee_id :props.scheduleModel.employee_id,
            application_id : props.scheduleModel.application_id,
            show: false,
            job_id : props.scheduleModel.job_id,
            show_status: props.scheduleModel.show_status,
            request:props.scheduleModel.request,
            })
        }}}
        >
          <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3">
        <div className="row">
        <form className="form-section col-md-12"> 
          {
              
                    props.scheduleModels &&
                    props.scheduleModels.show_status === 'show' &&
                    <div className="form-group">
                    <label>Select Category</label>
                    <select className="form-control selectpicker"
                    id = "short_select_industry"
                    data-live-search="true"    
                    title = "Choose Category"
                    value = {formFields.industry_type}
                    onChange = {(e) => {
                        
                        setFormFields({
                            ...formFields,
                            industry_type: e.target.value
                        });
                        
                        props.getAllPositions
                        ({
                        industry_type: e.target.value
                        });
                    
                    }}
                        >
                    {/* <option value = "">Choose Industry</option> */}
                    {
                // console.log(this.props.industries, 'industries'),
                        props.industries &&
                        props.industries.length > 0 &&
                        props.industries.map((i,k) => {
                        return <option
                        key = {k}
                        value = {i.industry_type}>{i.industry_type}</option>
                        
                        })
                    }
                    {/* <option value = "Events & Promotions">Events &amp; Promotions</option>
                    <option value = "F&B">F&amp;B</option>
                    <option value = "Hospitality"> Hospitality</option>
                    <option value = "Logistics">Logistics</option> */}
                </select>
                        {/* {formFields.errors.date &&
                            formFields.errors.date.length > 0 ? (
                            <small className="text-danger">
                                {formFields.errors.date}
                            </small>
                            ) : (
                            ""
                        )} */}
                        </div>                     

                    }
                  {
                        props.scheduleModels &&
                        props.scheduleModels.show_status === 'show' &&
                        <div className=" form-group">
                        <label>Select Position</label>
                        <select className="form-control selectpicker"
                        id = "interview_position"
                        data-live-search="true"    
                        title = "Choose Position"
                        value = {formFields.position}
                        onChange = { (e) => 
                            setFormFields({
                                ...formFields,
                                position: e.target.value
                            })
                        }
                        >
                            {/* <option 
                                
                                value = {""}>
                                
                                </option>          */}
                        {
                            props.positions && 
                            props.positions.length > 0 &&
                            props.positions.map((i,k) => {
                                return (
                                    <option 
                                    key = {k}
                                    value = {i.id}>
                                    {i.job_position}
                                    </option>         
                                )
                            })
                        }
                            
                        </select>
                        {/* {formFields.errors.date &&
                            formFields.errors.date.length > 0 ? (
                            <small className="text-danger">
                                {formFields.errors.date}
                            </small>
                            ) : (
                            ""
                        )} */}
                        </div>                     

                    }
                  
            <div className="form-group">
                <label>Date</label>
                <div className="input-group date mar-t-no" data-date-format="dd/mm/yyyy">
                <input type="text" className="form-control" 
                value = {formFields.date}
                />
                <div className="input-group-addon">
                  <img src="/assets/images/calendar-icon.svg" alt="icon" />
                </div>
              </div>
              {formFields.errors.date &&
                formFields.errors.date.length > 0 ? (
                <small className="text-danger">
                    {formFields.errors.date}
                </small>
                ) : (
                ""
              )}
            </div>
            <div className="row">
              <div className="form-group col-md-6">
                <label>Start Time</label>
                <input type="time" 
                className="form-control" 
                value = {formFields.start_time}
                onChange = {(e) => {
                    setFormFields({
                        ...formFields,
                        start_time: e.target.value
                    }); 
                }}
                name = "start_time"
                />
                {formFields.errors.start_time &&
                    formFields.errors.start_time.length > 0 ? (
                    <small className="text-danger">
                        {formFields.errors.start_time}
                    </small>
                    ) : (
                    ""
                )}
              </div>
              <div className="form-group col-md-6">
                <label>End Time</label>
                <input type="time" 
                className="form-control" 
                value = {formFields.end_time}
                onChange = {(e) => {
                    setFormFields({
                        ...formFields,
                        end_time: e.target.value
                    });
                }}
                name = "end_time"
                />
                {formFields.errors.end_time &&
                    formFields.errors.end_time.length > 0 ? (
                    <small className="text-danger">
                        {formFields.errors.end_time}
                    </small>
                    ) : (
                    ""
                )}
              </div>
            </div>
          </form>
        </div>
        <div className="row mt-2 mb-3">
        <div className="col-md-12 text-right">
            <button className="btn btn-blue"
             disabled = {props.btnLoading ? true:false}
            onClick={
              submitScheduleInterview
              // console.log(formFields.start_time, 'formFields.start_time');
              // console.log(formFields.end_time, 'formFields.start_time');
              // console.log(formFields.date, 'formFields.date')
            } 
            >
                {
                props.btnLoading ? 'Loading...':'Arrange Interview'}
                </button>
          </div>
        </div>
      </div>
    </div>
  {/* </div> */}
</Modal> 
)
};

const mapStateToProps = (state, ownProps) => {
    return {
        
        positions:state.Hire.positions,
        btnLoading:state.Hire.btnLoading,
        industries : state.Home.industries,
        scheduleModels:state.Hire.scheduleModels
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data)),
        getAllPositions: (data) => dispatch(actions.getAllPositions(data)),
        scheduleModel : (data) => dispatch(actions.scheduleModelsetUp(data)),
        scheduleInterview : (data) => dispatch(actions.scheduleInterview(data)),
        shortListInterview : (data) => dispatch(actions.shortListEmployee(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ShortListModel);
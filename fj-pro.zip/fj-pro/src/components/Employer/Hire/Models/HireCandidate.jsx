import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../../actions/Employer/Hire";
import $ from 'jquery';
import StripeCheckout from 'react-stripe-checkout';
import Loader from '../../../Helper/Loader'
function HireCandidate(props) {
    const [formFields, setFormFields] = useState({
        position:'',
        show: false,
        payment_type : 'card',
        industry_type:'',
        errors: {},
        totalCost : ""
    })

    useEffect(() => {
      
      $(document).ready(function () {
        window.$(".selectpicker").selectpicker();
        props.getCreditAmount()
        window.$(".input-group.start_date")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
            autoclose:true
        // endDate: "+0d",
        })
      })
    }, []);

    useEffect(() => {
      $(document).ready(function () {
        window.$(".selectpicker").selectpicker('refersh');
      })
      if (props.hired_status === 1) {
        props.hireCandidateModal(false)
        
        props.setContractModal(true);

        // window.$('#send-contract').modal('show');
        
        $("#hire-candi-modal .alert").html(
          `<strong>Success!</strong> ${props.hired_status_msg}.`
        );

        $("#hire-candi-modal .alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
          props.setHiredStatus(0, '');
          setTimeout(function () {
          props.hireCandidateModal(false);    
          props.getScheduledCandidates({
          employer_id:localStorage.getItem('emp_id'),
          status_code : 8,
          filter:0,
          industry_type:null,
          job_position:null,
          page_no:0,
          limit:15,
          filter_by: null,
          interview_date: null
          })
          props.getAllUnappliedEmployees({
            employer_id:localStorage.getItem('emp_id'),
            filter:0,
            position:null,
            location:null,
            search_term : null,
            industry_type : null,
            experience:null,
            lat:'11.0176',
            lon:'76.9674',
            page_no:0,
            limit:16
          }, false)
          $("#hire-candi-modal .alert").removeClass("alert-success");
          $("#hire-candi-modal .alert").html("");
        }, 3000);

      } else if (props.hired_status === 2) {

          $("#hire-candi-modal .alert").html(
              `<strong>Sorry!</strong> ${props.hired_status_msg}.`
          );
          $("#hire-candi-modal .alert")
            .removeClass("alert-success")
            .addClass("alert-danger");
            props.setHiredStatus(0, '');
          setTimeout(function () {
            $("#hire-candi-modal .alert").removeClass("alert-danger");
            $("#hire-candi-modal .alert").html("");
              
          }, 3000);
      }
  })

  const showScrollBar = () => {
    
    $('body').css('overflow', '')
  }

  const updateErrors = errors => {
    setFormFields({
      ...formFields, 
      errors: { ...formFields.errors, ...errors }
    });
  };

  const handleErrors = (type) => {
    let errors = formFields.errors;
    let valid = true;
    
    if (type === 'position') {
      if (formFields.position !== '') {
        errors.position = 'Cannot be empty'
        updateErrors(errors);
        valid = false;
      }
    }
     
    if (type === 'industry') {
      if (formFields.industry_type !== '') {
        errors.industry_type = 'Cannot be empty'
        updateErrors(errors);
        valid = false;
      }
    }
    if (valid) {
      setFormFields({
        ...formFields, 
        show:!formFields.show
      })
    }
    
    }

    const onToken = (e) => { 
    let actualAmount = props.candidateDetail 
    && props.candidateDetail.candidateDetails &&
    props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
    Number(props.candidateDetail.candidateDetails.job_salaries[0].actual_salary_paid_by_employer)
    let walletAmount = Number(props.walletAmount)
    
      if (formFields.payment_type === 'credit' && (walletAmount < actualAmount )) {
        props.setHiredStatus(2, 'Not enough amount, Please pay with card.');
      } else {
        props.hireEmployee({
          employee_id:props.candidateDetail 
          && props.candidateDetail.employee
          && props.candidateDetail.employee.id,
          job_id:props.candidateDetail 
          && props.candidateDetail.candidateDetails
          && props.candidateDetail.candidateDetails.id,
          from_credits:formFields.payment_type === 'credit' ? '1' :'0',
          status_code:3,
          request : props.showJobHire ? '1' : '0', 
          url:""
        })    
  
      }
      
    }

    return (
        <>
        <Modal 
        show={props.showHireModel} 
            className="modal fade custom-modal"
            onHide={() => {{
              props.hireCandidateModal(false);
              props.setCandidate([]);
              showScrollBar();
            }}}
            id="hire-candi-modal" tabIndex={-1} role="dialog" aria-hidden="true"
            centered
            >
            
            {/* <div className="modal-dialog modal-dialog-centered" role="document"> */}
            {/* {console.log(props.walletAmount, 'walletAmount')} */}
            {
              
              // !props.modelLoading ? <Loader

              // /> :
            <div className="modal-content"
            
            >
              <div className="modal-header">
                <h5 className="modal-title w-100 justify-content-center"> Candidate</h5>
                <button type="button" className="close" data-dismiss="modal" aria-label="Close"
                onClick={() => {props.hireCandidateModal(false);
                  props.setCandidate([]);
                }}
                >
                  <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                </button>
              </div>
              <div className="modal-body rplce-candidate">
                <div className="row">
                <div className="alert" role="alert">  </div>
                  {
                    // console.log(formFields, 'formvalues'),
                    props.showJobHire &&
                    <form className="form-section col-md-12">
                    <div className="form-group ">
                    <label>Select Category</label>
                    <select className="form-control selectpicker"
                    id = "short_select_industry"
                    data-live-search="true"    
                    title = "Choose Category"
                    value = {formFields.industry_type}
                    onChange = {(e) => {
                      // handleErrors('industry')
                      // console.log($('#short_select_industry').find("option:selected").text(), '$("#select_industry:selected").text()')
                      setFormFields({
                          ...formFields,
                          industry_type: e.target.value
                      });
                      
                      props.getAllPositions({
                          industry_type:e.target.value
                      });
                    
                    }}
                    >
                    
                    {
                // console.log(this.props.industries, 'industries'),
                        props.industries &&
                        props.industries.length > 0 &&
                        props.industries.map((i,k) => {
                        return <option
                        key = {k}
                        value = {i.industry_type}>{i.industry_type}</option>
                        
                        })
                    }
                    </select>
                    {/* {formFields.errors.industry_type &&
                        formFields.errors.industry_type.length > 0 ? (
                        <small className="text-danger">
                            {formFields.errors.industry_type}
                        </small>
                        ) : (
                        ""
                    )} */}
                    </div>   
                    <div className="form-group">
                    <label>Select Position</label>
                    <select className="form-control selectpicker"
                    id = "short_select_position"
                    data-live-search="true"    
                    title = "Choose Position"
                    value = {props.position}
                    onChange = { (e) => {
                      setFormFields({
                        ...formFields,
                        position: e.target.value
                      });
                      handleErrors('position')
                      props.getCandidateDetails({
                        job_id:e.target.value,
                        employee_id : props.hire_emp_id
                      })         
                    }

                    }
                    >
                 
                    {
                        props.positions && 
                        props.positions.length > 0 &&
                        props.positions.map((i,k) => {
                            
                            return (
                                
                                <option 
                                key = {k}
                                value = {i.id}>
                                {i.job_position}
                                </option>         
                            )
                        })
                    }
                        
                    </select>
                    {/* {formFields.errors.position &&
                        formFields.errors.position.length > 0 ? (
                        <small className="text-danger">
                            {formFields.errors.position}
                        </small>
                        ) : (
                        ""
                    )} */}
                    </div>  
                
                  </form>
                  }
                
                  <div className="col-md-12 mb-3">
                  <form className="form-section">
                    <div className="form-group">
                   <div className = "row">
                  <div className="col-6 ">
                    <label className="input">
                        <input type="radio" name="work"
                        value = "credit"
                        checked = {formFields.payment_type === 'credit'}
                        onChange={() => {
                          // handleErrors('credit')
                          setFormFields({
                            ...formFields,
                            payment_type : 'credit'
                          });
                          
                        }}
                        />
                        Pay from credit 
                    </label>
                    </div>
                    <div className="col-6 ">
                    <label className="input">
                        <input type="radio" name="work"
                        value = "card"
                        checked = {formFields.payment_type === 'card'}
                        onChange={() => {
                          setFormFields({
                            ...formFields,
                            payment_type : 'card'
                          });
                          
                        }}
                         />
                        Pay from Card
                    </label>
                    </div>
                     
                    </div>
                    </div>
                    </form>
                    <div className="hire-candidate">
                      <div className="avatar">
                        <img className="img-fluid" 
                        style = {{height:'100%',width:'100%'}}
                        src={props.profile_url !== null &&
                        props.profile_url !== "null" &&
                        props.profile_url !== ""?
                        props.profile_url :
                        "/assets/images/app/profile-default.png"
                         } alt="Staff" />
                      </div>
                      <div>
                        <h6>{props.candidateDetail 
                        &&
                        props.candidateDetail.employee
                        && props.candidateDetail.employee.name
                        }</h6>
                        <span>{
                          props.candidateDetail 
                          && props.candidateDetail
                          && props.candidateDetail.employee
                          && props.candidateDetail.employee.city
                        }</span>
                      </div>
                    </div>
                  </div>
                  {/* <div className="col-md-6 mt-0">
                    <div className="job-desc contact">
                      <div className="col-12 px-0">
                        
                        <p>
                          <img src="/assets/images/app/ic-email.svg" alt="icon" />
                          <a href="mailto:amanda.reyes99@gmail.com">amanda.reyes99@gmail.com</a>
                        </p>
                        <p>
                          <img src="/assets/images/app/ic-gps-pin.svg" alt="icon" />
                          St Andrews Lane, London, UK
                        </p>
                        <p>
                          <img src="/assets/images/app/ic-phone.svg" alt="icon" />
                          <a href="tel:(499)-430-5810">(499)-430-5810</a>
                        </p>
                      </div>
                    </div>
                  </div> */}
                  {/* <div className="col-md-6 cal-cont mt-3 mt-md-0">
                    <div className="row mb-2">
                      <span className="dark col-md-6 col-6">Experience</span>
                      <span className="col-md-6 col-6">2 Years</span>
                    </div>
                    <div className="row mb-2">
                      <span className="dark col-md-6 col-6">Languages</span>
                      <span className="col-md-6 col-6">English -Beginner</span>
                    </div>
                  </div>    */}
                 
                </div>
                <div className="row mt-1">
                  <h5 className="col-12 mb-3">Salary Calculation</h5>
                  <div className="col-md-6 cal-cont">
                    <div className="row mb-2">
                      <span className="dark col-md-7 col-7">{
                        props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        
                        && props.candidateDetail.candidateDetails.salary_based ?
                        props.candidateDetail.candidateDetails.salary_based :'Hourly Rate'
                      }</span>
                      <span className="col-md-5 col-5">RM {
                         props.candidateDetail 
                         && props.candidateDetail.candidateDetails
                         && props.candidateDetail.candidateDetails.amount
                         &&  props.candidateDetail.candidateDetails.amount ?
                         props.candidateDetail.candidateDetails.amount :'0.00'
                      }</span>
                    </div>
                    <div className="row mb-2">
                      <span className="dark col-md-7 col-7">Number of Hour</span>
                      <span className="col-md-5 col-5"> {props.candidateDetail 
                          && props.candidateDetail.candidateDetails
                          && props.candidateDetail.candidateDetails.number_of_hours ?
                          props.candidateDetail.candidateDetails.number_of_hours :'0:00'
                          }Hrs</span>
                    </div>
                    <div className="row mb-3">
                      <span className="dark col-md-7 col-7">Number of Days</span>
                      <span className="col-md-5 col-5">{props.candidateDetail 
                          && props.candidateDetail.candidateDetails
                          && props.candidateDetail.candidateDetails.number_of_days ?
                          props.candidateDetail.candidateDetails.number_of_days :
                          '0 ' 
                          } Days
                      </span>
                    </div>
                    <div className="row mb-2">
                      <span className="dark col-md-7 col-7">Total Salary  Pay</span>
                      <span className="col-md-5 col-5">RM {
                        props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        && props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                        props.candidateDetail.candidateDetails.job_salaries[0].total_salary_base_by_employer &&
                        new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(props.candidateDetail.candidateDetails.job_salaries[0].total_salary_base_by_employer)? '0.00':props.candidateDetail.candidateDetails.job_salaries[0].total_salary_base_by_employer)
                        }</span>
                    </div>
                    <div className="row mb-3">
                      <span className="dark col-md-7 col-7">FlexiJobs Fee</span>
                      <span className="col-md-5 col-5">RM {
                        props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        && props.candidateDetail.candidateDetails.job_salaries
                        && props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                        props.candidateDetail.candidateDetails.job_salaries[0].fj_admin_fee ?
                        new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(props.candidateDetail.candidateDetails.job_salaries[0].fj_admin_fee)? '0.00':props.candidateDetail.candidateDetails.job_salaries[0].fj_admin_fee)
                        :
                        '0:00'
                        }</span>
                    </div>
                  </div>
                  <div className="col-md-6 cal-cont">
                    <div className="row mb-2">
                      <span className="dark col-md-7 col-7">EPF(13%) </span>
                      <span className="col-md-5 col-5">RM{
                        props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        && props.candidateDetail.candidateDetails.job_salaries &&
                        props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                        new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(props.candidateDetail.candidateDetails.job_salaries[0].employer_epf)? '0.00':props.candidateDetail.candidateDetails.job_salaries[0].employer_epf)
                      }</span>
                    </div>
                    <div className="row mb-1 mb-md-5">
                      <span className="dark col-md-7 col-7">Socso(0.15%) </span>
                      <span className="col-md-5 col-5">RM{props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        && props.candidateDetail.candidateDetails.job_salaries &&
                        props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                        new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(props.candidateDetail.candidateDetails.job_salaries[0].employer_socso)? '0.00':props.candidateDetail.candidateDetails.job_salaries[0].employer_socso)
                        }</span>
                    </div>
                    <div className="row mb-1 mb-md-5">
                      <span className="dark col-md-7 col-7">EIS(0.2%) </span>
                      <span className="col-md-5 col-5">RM{props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        && props.candidateDetail.candidateDetails.job_salaries &&
                        props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                        new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(props.candidateDetail.candidateDetails.job_salaries[0].employer_eis)? '0.00':props.candidateDetail.candidateDetails.job_salaries[0].employer_eis)
                        }</span>
                    </div>
                    <div className="row total-cal">
                      <span className="dark col-md-7 col-7">Total Cost</span>
                      <span className="col-md-5 col-5">RM {
                        
                      props.candidateDetail 
                        && props.candidateDetail.candidateDetails
                        && props.candidateDetail.candidateDetails.job_salaries &&
                        props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                        new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(Number(props.candidateDetail.candidateDetails.job_salaries[0].actual_salary_paid_by_employer) + Number(props.candidateDetail.candidateDetails.job_salaries[0].fj_admin_fee))? '0.00':Number(props.candidateDetail.candidateDetails.job_salaries[0].actual_salary_paid_by_employer) + Number(props.candidateDetail.candidateDetails.job_salaries[0].fj_admin_fee))
                        }
                        </span>
                    </div>
                  </div>
                </div>
                <form className="row form-section mt-4 mt-md-2">
                  {/* <div className="col-md-12 form-group">
                    <label>Upload Proof of Business Document</label>
                    <div className="upload-wizard fill">
                      <span>Upload or drag document here</span>
                    </div>
                  </div> */}
                  <div className="col-md-12 form-group text-right mt-2">
                    {formFields.payment_type === 'card' ?
                    <StripeCheckout
                    amount={props.candidateDetail 
                    && props.candidateDetail.candidateDetails &&
                    props.candidateDetail.candidateDetails.job_salaries.length > 0 &&
                    Number(props.candidateDetail.candidateDetails.job_salaries[0].actual_salary_paid_by_employer)}
                    billingAddress
                    shippingAddress
                    name="Pay Salary now." // the pop-in header title
                    closed = {showScrollBar}
                
                    stripeKey="pk_test_51IknhvSBf2Rw9k3F4KyXJRX7iOyoztpzn5yAUWLLSvs7uBj9FQdB488ke7aevqLUyaasz0u5yUY6zQ9Rtljb0xKJ00TPVSUNBE"
                    token={onToken}
                >
                 <button className="btn btn-blue"
                 type = "button"
                
                //  onClick = {() => {
                   
                //    props.hireCandidateModal(false)

                //  }}
                 >Proceed Payment</button>
                 </StripeCheckout> :
                 
                 <button className="btn btn-blue"
                 disabled = {props.modelLoading ? true: false}
                 type = "button"
                 onClick = {
                 onToken
                 }
                 >Proceed Payment</button>
                    }
                  
                  </div>
                </form>
              </div>
            </div>
             }
          {/* </div> */}
          </Modal>   

          <div className="modal fade custom-modal" id="send-contract" tabIndex={-1} role="dialog" aria-hidden="true">
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                <div className="modal-header">
                    <h5 className="mt-2 modal-title w-100 justify-content-center">Send Contract</h5>
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close"
                    // onClick = {() => {
                    //     props.setContractModal(false)
                    // }}
                    >
                    <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                    </button>
                </div>
                <div className="modal-body px-md-5 px-3">
                    <div className="row">
                    <div className="col-md-12">
                        <p className="fs-14 dark">Job contract has been sent to candidate. After confirmed, the selected candidate can immediately begin working.</p>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>

          </>
    )
};

const mapStateToProps = (state, ownProps) => {
    return {
      showHireModel:state.Hire.showHireModel,
      showJobHire:state.Hire.showJobHire,
      profile_url:state.Hire.profile_url,
      candidateDetail : state.Hire.candidateDetail,
      modelLoading : state.Hire.modelLoading,
      hired_status: state.Hire.hired_status,
      hired_status_msg : state.Hire.hired_status_msg ,
      industries : state.Home.industries,
      positions:state.Hire.positions,
      hire_emp_id : state.Hire.hire_emp_id,
      walletAmount : state.Hire.walletAmount,
      salaryContributions:state.Jobs.salaryContributions,
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
      hireCandidateModal : data => dispatch(actions.hireCandidateModal(data)),
      setContractModal : data => dispatch(actions.setContractModal(data)) ,
      getAllUnappliedEmployees: (data, val) => dispatch(actions.getAllUnappliedEmployees(data, val)),
      getCreditAmount : () => dispatch(actions.getCreditAmount()),
      getScheduledCandidates : (data) => dispatch(actions.getSchedules(data)),
      hireEmployee : (data) => dispatch(actions.hireEmployee(data)),
      getAllPositions: (data) => dispatch(actions.getAllPositions(data)),
      getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data)),
      setCandidate : (data) => dispatch(actions.setCandidate(data)),
      setHiredStatus : (data, msg) => dispatch(actions.setHiredStatus(data,msg)),
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(HireCandidate);
import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../actions/Employer/Hire";
import $ from 'jquery';

function ShortListModel(props) {
    const [formFields, setFormFields] = useState({
        position:'',
        industry_type:'',
        errors: {}
    })

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
            window.$('.selectpicker').selectpicker('refresh')
            window.$(".input-group.start_date")
                .datepicker({
                format: "mm/dd/yyyy",
                todayHighlight: true,
                autoclose:true
                // endDate: "+0d",
                })
                .off("change")
                .change((e) => {{
                    setFormFields({
                        ...formFields,
                        date: e.target.value
                    }); 
                } });
        })
    });

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();
            window.$(".input-group.start_date")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
                autoclose:true
            // endDate: "+0d",
            })
        })
    }, []);

    const updateErrors = errors => {
        setFormFields({
          ...formFields, 
          errors: { ...formFields.errors, ...errors }
        });
    };

    const validation = async (e) => {
        let errors = formFields.errors;
        let valid = true;

        if (formFields.position === '') {
            errors.position = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        updateErrors(errors);
        return valid;
    } 

    const submitShortlist = async(e) => {
        // console.log(formFields.errors, 'formFields.errors')
        e.preventDefault();
        const result = await validation();
       
        if (result) {
            console.log(result, "result ..........................");
            console.log( props.modelShortList, "submit .................................");
            props.shortListInterview({
                application_id: props.modelShortList.application_id,
                employee_id: props.modelShortList.employee_id,
                job_id : props.modelShortList.job_id === null 
                ?formFields.position : props.modelShortList.job_id,
                status_code: 2,
                request : props.modelShortList.request
            })
        } 
    }
    
    return (
    <Modal 
    show={props.modelShortList.show} 
    id="shortlist-candidate" tabIndex={-1}
    className="modal fade custom-modal"
            // style={{ "paddingRight": 17 }} 
    onHide={() =>   props.setShortListModel({
        application_id: props.modelShortList.application_id,
        employee_id: props.modelShortList.employee_id,
        job_id : props.modelShortList.job_id,
        show:false,
        status_code: 2,
        show_status: props.modelShortList.show_status,
        request : props.modelShortList.request
    })}
    role="dialog" 
    aria-hidden="true"
    centered 
    >
    
    <div className="modal-content">
      <div className="modal-header">
         
        <h5 className="mt-2 modal-title w-100 justify-content-center">Shortlist Candidate For..</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close"
        onClick={() =>   props.setShortListModel({
            application_id: props.modelShortList.application_id,
            employee_id: props.modelShortList.employee_id,
            job_id : props.modelShortList.job_id,
            show:false,
            status_code: 2,
            show_status: props.modelShortList.show_status,
            request : props.modelShortList.request
        })}
        >
          <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3">
        <div className="row">
          <form className="form-section col-md-12">
          <div className="form-group">
                    <label>Select Category</label>
                    <select className="form-control selectpicker"
                    id = "short_select_industry"
                    value = {formFields.industry_type}
                    onChange = {(e) => {
                        // console.log($('#short_select_industry').find("option:selected").text(), '$("#select_industry:selected").text()')
                        setFormFields({
                            ...formFields,
                            industry_type: e.target.value
                        });
                        
                        props.getAllPositions({
                            industry_type:e.target.value
                        });
                    
                    }}
                    >
                    <option value = "">Choose Industry</option>
                    {
                // console.log(this.props.industries, 'industries'),
                        props.industries &&
                        props.industries.length > 0 &&
                        props.industries.map((i,k) => {
                        return <option
                        key = {k}
                        value = {i.industry_type}>{i.industry_type}</option>
                        
                        })
                    }
                    </select>
                    {/* {formFields.errors.date &&
                        formFields.errors.date.length > 0 ? (
                        <small className="text-danger">
                            {formFields.errors.date}
                        </small>
                        ) : (
                        ""
                    )} */}
                    </div>   
                    <div className="form-group">
                    <label>Select Position</label>
                    <select className="form-control selectpicker"
                    id = "short_select_position"
                    value = {props.position}
                    onChange = { (e) => 
                        setFormFields({
                            ...formFields,
                            position: e.target.value
                        })
                    }
                    >
                    <option 
                    
                    value = {""}>
                    Choose one
                    </option>         
                    {
                        props.positions && 
                        props.positions.length > 0 &&
                        props.positions.map((i,k) => {
                            
                            return (
                                
                                <option 
                                key = {k}
                                value = {i.id}>
                                {i.job_position}
                                </option>         
                            )
                        })
                    }
                        
                    </select>
                    {/* {formFields.errors.date &&
                        formFields.errors.date.length > 0 ? (
                        <small className="text-danger">
                            {formFields.errors.date}
                        </small>
                        ) : (
                        ""
                    )} */}
                    </div>  
          </form>
        </div>
        <div className="row mt-2 mb-3">
          <div className="col-md-12 text-right"
          >
            <button className="btn btn-blue"
             disabled = {props.btnLoading ? true:false}
            onClick={
                    submitShortlist
                // console.log(formFields.start_time, 'formFields.start_time');
                // console.log(formFields.end_time, 'formFields.start_time');
                // console.log(formFields.date, 'formFields.date')
            } 
            >{props.btnLoading ? 'Loading...':'Shortlist'}</button>
          </div>
        </div>
      </div>
    </div>
  
</Modal>

)
};

const mapStateToProps = (state, ownProps) => {
    return {
        modelShortList: state.Hire.modelShortList,
        positions:state.Hire.positions,
        btnLoading:state.Hire.btnLoading,
        industries : state.Home.industries,
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setShortListModel: (data) => dispatch(actions.setShortListModel(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        getAllPositions: (data) => dispatch(actions.getAllPositions(data)),
        scheduleInterview : (data) => dispatch(actions.scheduleInterview(data)),
        shortListInterview : (data) => dispatch(actions.shortListEmployee(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ShortListModel);
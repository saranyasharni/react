import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import * as actions from '../../../../actions/Employer/Hire'
import $ from 'jquery';
import { useParams } from 'react-router-dom';

function HiredSearch(props) {        

    const[state, setState] = useState({
        job_position: "null",
        location : null,
        filter : "0",
        experience : null,
        industry_type : "null",
        search_term : null,
        limit:"15",
        page_no :"0"
    })
    const params = useParams()    
    useEffect(() => {
        
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();  
            
        })
        
    }, [])
    useEffect(() => {
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker('refresh');
        })
    })
    return (
        <>
        <form className="custom-form row five-col form-section my-3">
        <div className="form-group col-md-3">
        <label>Category</label>
        <select className="form-control selectpicker"
        data-live-search="true"    
        title = "Choose Category"
            id = "hiredser_select_industry"
            value = {state.industry_type}
            onChange = {(e) => {
                setState({
                    ...state,
                    industry_type:e.target.value
                });
                props.getOnePosition({
                    industry_type:e.target.value
                });
                if (props.apiCall === 4) {
                    props.getHiredCandidates({
                        employer_id:localStorage.getItem('emp_id'),
                        status_code:"3",
                        filter : 1,
                        industry_type : e.target.value,
                        job_position : state.job_position,
                        page_no: state.page_no,
                        limit : state.limit
                    })
                } else if (props.apiCall === 3) {
                    props.getScheduledCandidates({
                        employer_id:localStorage.getItem('emp_id'),
                        status_code:"8",
                        filter:1,
                        filter_by:'position',
                        interview_date: null,
                        industry_type : e.target.value,
                        job_position:state.job_position,
                        page_no:state.page_no,
                        limit:state.limit
                    })
                } else if (props.apiCall === 2) {
                    
                    props.getShortListedEmployees({
                        employer_id:localStorage.getItem('emp_id'),
                        status_code:"2",
                        filter : "1",
                        industry_type : e.target.value,
                        job_position : state.job_position,
                        page_no: state.page_no,
                        limit : state.limit
                    })
            
                } else if (props.apiCall === 1) {
                    props.getAllEmployees({
                        
                        employer_id:localStorage.getItem('emp_id'),
                        filter:1,
                        position:null,
                        location:null,
                        status_code: 1,
                        industry_type : e.target.value,
                        experience:null,
                        page_no: state.page_no,
                        limit : state.limit

                    })
                } else if (props.apiCall === 5) {
                    props.getRejectedCandidates({
                        employer_id:localStorage.getItem('emp_id'),
                        status_code:"9",
                        filter : 1,
                        industry_type : e.target.value,
                        job_position : state.job_position,
                        page_no: state.page_no,
                        limit : state.limit
                    })

                } else {
                    return;
                }
                
            }}
            >
            
            {
                // console.log(this.props.industries, 'industries'),
                props.industries &&
                props.industries.length > 0 &&
                props.industries.map((i,k) => {
                return <option
                key = {k}
                value = {i.industry_type}>{i.industry_type}</option>
                
                })
            }
        </select>
        </div>
        <div className="form-group col-md-3">
        {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
        <label>Position</label>
        <select className="form-control lft-ico selectpicker"
        data-live-search="true"    
        title = "Choose Position"
        
        value = {state.position}
        onChange = {(e) => {
            setState({
                ...state,
                position : e.target.value
            });
            
            if (props.apiCall === 4) {
                props.getHiredCandidates({
                    employer_id:localStorage.getItem('emp_id'),
                    status_code:"3",
                    filter : 1,
                    industry_type :state.industry_type,
                    job_position : e.target.value,
                    page_no: state.page_no,
                    limit : state.limit
                })
            } else if (props.apiCall === 3) {
                
                props.getScheduledCandidates({
                    employer_id:localStorage.getItem('emp_id'),
                    status_code:"8",
                    filter:1,
                    filter_by : "position",
                    interview_date: null,
                    industry_type :state.industry_type,
                    job_position : e.target.value,
                    page_no:state.page_no,
                    limit:state.limit
                })
            } else if (props.apiCall === 2) {
                
                props.getShortListedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    status_code:"2",
                    filter : "1",
                    industry_type :state.industry_type,
                    job_position : e.target.value,
                    page_no: state.page_no,
                    limit : state.limit
        
                })
        
            } else if (props.apiCall === 1) {
                props.getAllEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:1,
                    
                    location:null,
                    status_code: 1,
                    industry_type :state.industry_type,
                    position : e.target.value,
                    experience:null,page_no: state.page_no,
                    limit : state.limit

                })
            } else if (props.apiCall === 5) {
                props.getRejectedCandidates({
                    employer_id:localStorage.getItem('emp_id'),
                    status_code:"9",
                    filter : 1,
                    industry_type :state.industry_type,
                    job_position : e.target.value,
                    page_no: state.page_no,
                    limit : state.limit
                })

            } else {
                return;
            }
           
        }}
        >
        {
            props.listOnePosition.length > 0 && 
            props.listOnePosition.map((i,k) => {
                
                return <option
                    key = {k}
                    value = {i}
                    >
                        {i}
                </option>
            })
        }
        </select>
        </div>
        <div className="form-group text-right text-md-left col-md-3 mt-md-4 pt-md-2"
        >  
        <button type = "button" className="btn btn-blue"
                onClick = {(e) => {
                    window.jQuery('.form-control').val('');
                  
                    setState({
                    ...state, 
                    experience:null,
                    job_position : null,
                    industry_type: "null",
                    location:null,
                    search_term : null,
                    });
                    if (props.apiCall === 4) {
                        props.getHiredCandidates({
                            employer_id:localStorage.getItem('emp_id'),
                            status_code:"3",
                            filter : 0,
                            industry_type :null,
                            job_position : null,
                            page_no: state.page_no,
                            limit : state.limit
                        })
                    } else if (props.apiCall === 3) {
                        
                        props.getScheduledCandidates({
                            employer_id:localStorage.getItem('emp_id'),
                            status_code:"8",
                            filter:0,
                            filter_by : "position",
                            interview_date: null,
                            industry_type :null,
                            job_position : null,
                            page_no:state.page_no,
                            limit:state.limit
                        })
                    } else if (props.apiCall === 2) {
                        props.getShortListedEmployees({
                            employer_id:localStorage.getItem('emp_id'),
                            status_code:"2",
                            filter : "0",
                            industry_type :"null",
                            job_position : "null",
                            page_no: state.page_no,
                            limit : state.limit
                
                        })
                
                    } else if (props.apiCall === 1) {
                        props.getAllEmployees({
                            employer_id:localStorage.getItem('emp_id'),
                            filter:0,
                            
                            location:null,
                            status_code: 1,
                            industry_type :null,
                            job_position : null,
                            experience:null,
                            page_no: state.page_no,
                            limit : state.limit
        
                        })
                    } else if (props.apiCall === 5) {
                        props.getRejectedCandidates({
                            employer_id:localStorage.getItem('emp_id'),
                            status_code:"9",
                            filter : 0,
                            industry_type :null,
                            job_position : null,
                            page_no: state.page_no,
                            limit : state.limit
                        })
        
                    } else {
                        return;
                    }
                    
                }}
                >Reset All</button>
        </div>
        </form>
        </>
    )
}

const mapStateToProps = (state, ownProps) => {
    return {
        listOnePosition:state.Hire.listOnePosition,
        apiCall:state.Hire.apiCall,
        industries : state.Home.industries,
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getHiredCandidates : (data) => dispatch(actions.getAllWorkers(data)),
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),
        getAllEmployees: (data) => dispatch(actions.getAllEmployees(data)),
        getScheduledCandidates : (data) => dispatch(actions.getSchedules(data)),
        getRejectedCandidates : (data) => dispatch(actions.getRejected(data)),
        getShortListedEmployees : (data) => dispatch(actions.getShortlistedEmployees(data))

    }
};

export default connect(mapStateToProps, mapDispatchToProps)(HiredSearch);
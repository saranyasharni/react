import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import * as actions from '../../../../actions/Employer/Hire'
import * as FilterActions from '../../../../actions/Employer/Filters'
import Autocomplete from "react-google-autocomplete";
import $ from "jquery"

function ShortlistSearch(props) {        
    // const[state, setState] = useState({
        
    // })  
    useEffect(() => {
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker();
        })
        
    }, [])
    useEffect(() => {
        $(document).ready(function () {
            window.$(".selectpicker").selectpicker('refresh');
        })
    })
    return (
        <>
        
        <form className="custom-form row five-col form-section my-3">
        <div className="form-group col-lg-2 col-md-6">
        <label>Category</label>
        <select className="form-control selectpicker"
        data-live-search="true"    
        title = "Choose Category"
        id = "select_industry"
        value = {props.industry_type}
        onChange = {(e) => {
            // alert()
            props.setSearchEmployeeFilter(
                "industry_type",e.target.value
            );
            props.setSearchEmployeeFilter(
                "filter",1
            );
            props.updatePageNumber(0)  
            props.getOnePosition({
                industry_type:e.target.value
            });
            props.getAllUnappliedEmployees({
                employer_id:localStorage.getItem('emp_id'),
                filter:1,
                is_vaccinated:props.is_vaccinated,
                position:props.position,
                location:props.location,
                search_term : props.search_term,
                industry_type:e.target.value,
                experience:props.experience,
                lat:null,
                lon:null,
                limit:props.limit,
                page_no :0
            }, false)
        }}
        >
            {/* <option value = "">Choose Category</option> */}
            {
                props.industries &&
                props.industries.length > 0 &&
                props.industries.map((i,k) => {
                return <option
                key = {k}
                value = {i.industry_type}>{i.industry_type}</option>
                })
            }
        </select>
           
        </div>
        <div className="form-group col-lg-2 col-md-6">
        {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
        <label>Position</label>
        <select className="form-control selectpicker"
        data-live-search="true"    
        title = "Choose Position"
         id = "select_position"
        value = {props.position}
        onChange = {(e) => {
            props.setSearchEmployeeFilter(
                
                "filter",1
            );
            props.setSearchEmployeeFilter(
                "position",e.target.value
            );
            props.updatePageNumber(0)  
            props.getAllUnappliedEmployees({
                employer_id:localStorage.getItem('emp_id'),
                filter:1,
                position:e.target.value,
                is_vaccinated:props.is_vaccinated,
                location:props.location,
                search_term : props.search_term,
                industry_type:props.industry_type,
                experience:props.experience,
                lat:props.lat,
                lon:props.lon,
                limit:props.limit,
                page_no :0
            },false)
        }}
        >
            
            {
                // console.log(props.listOnePosition, 'props.listOnePosition'),
                props.listOnePosition.length > 0 && 
                props.listOnePosition.map((i,k) => {
                    
                    return <option
                        key = {k}
                        value = {i}
                        >
                        {i}
                    </option>
                })
                
            }
           
            {/* <option>system operator</option>
            <option>Waiter</option>
            <option>Waitress</option>
            <option>Sales Man</option> */}
        </select>
        </div>
            <div className="form-group col-lg-2 col-md-6">
            {/* <img className="inside-input" src="/assets/images/app/location-pin-icon.svg" alt="icon" /> */}
            <label>Location</label>
            {/* <input
            className="form-control lft-ico"
            onChange = {(e) => {
                props.setSearchEmployeeFilter(
                    "location" , e.target.value
                );
                props.setSearchEmployeeFilter(
                    "filter",1
                );
                props.updatePageNumber(0)  
                props.getAllUnappliedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:1,
                    position:props.position,
                    location:e.target.value,
                    search_term : props.search_term,
                    industry_type:props.industry_type,
                    experience:props.experience,
                    lat:props.lat,
                    lon:props.lon,
                    limit:props.limit,
                    page_no :0
                },false)
            }}
            value = {props.location}
            placeholder = "Singapore"
            >
            </input> */}
            <Autocomplete
            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
            className="form-control lft-ico"
            value = {props.location}
            onChange = {(e) => {
                props.setSearchEmployeeFilter(
                    "location" , e.target.value
                );
                props.setSearchEmployeeFilter(
                    "filter",1
                );
                props.updatePageNumber(0)  
                props.getAllUnappliedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:1,
                    position:props.position,
                    is_vaccinated:props.is_vaccinated,
                    location:e.target.value,
                    search_term : props.search_term,
                    industry_type:props.industry_type,
                    experience:props.experience,
                    lat:props.lat,
                    lon:props.lon,
                    limit:props.limit,
                    page_no :1
                },false)
            }}
            onPlaceSelected={(place) => {
                
                props.setSearchEmployeeFilter("lat", 
                place.geometry.location.lat() !== '' ? place.geometry.location.lat() : props.lat);
                props.setSearchEmployeeFilter("lon", 
                place.geometry.location.lng() !== '' ? place.geometry.location.lng() : props.lon);
                props.setSearchEmployeeFilter("location", place.formatted_address &&
                place.formatted_address
                );
                // props.setSearchEmployeeFilter(
                //     "location" , e.target.value
                // );
                props.setSearchEmployeeFilter(
                    "filter",1
                );
                props.updatePageNumber(0)  
                props.getAllUnappliedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:1,
                    position:props.position,
                    is_vaccinated:props.is_vaccinated,
                    location:place.formatted_address && place.formatted_address,
                    search_term : props.search_term,
                    industry_type:props.industry_type,
                    experience:props.experience,
                    lat:props.lat,
                    lon:props.lon,
                    limit:props.limit,
                    page_no :0
                },false)
            
            }}
            options={{
                types: ['address'],
                // componentRestrictions: { country: "ru" },
            }}
            // defaultValue={props.location}
            />
            {/* <select className="form-control selectpicker_loca lft-ico "
            value = {props.location}
            onChange = {(e) => {
                
            }}
            >
                <option>Choose Location</option>
                <option value = "Coimbatore">Coimbatore</option>
                <option value = "Chennai">Chennai</option>
                <option value = "Salem">Salem</option>
                <option>Address line 4</option>
            </select> */}
            </div>
            <div className="form-group col-lg-2 col-md-6">
            <label>Skills</label>
            <select className="form-control selectpicker"
            data-live-search="true"    
            title = "Choose Skill"
              value = {props.search_term}
              onChange = {(e) => {
                  props.setSearchEmployeeFilter(
                  "search_term",e.target.value  
                  );
                  props.setSearchEmployeeFilter(
                      "filter",1
                  );
                  props.updatePageNumber(0)  
                  props.getAllUnappliedEmployees({
                      employer_id:localStorage.getItem('emp_id'),
                      filter:1,
                      is_vaccinated:props.is_vaccinated,
                      position:props.position,
                      location:props.location,
                      search_term : e.target.value,
                      industry_type:props.industry_type,
                      experience:props.experience,
                      lat:props.lat,
                      lon:props.lon,
                      limit:props.limit,
                      page_no :0
                  },false)
              }}
              >
              
              {
                props.skills &&
                props.skills.length &&
                props.skills.map((i,k) => {
                  return <option
                  key = {k}
                  >{i}</option>
                })

              }
      
              {/* <option>Customer Service</option>
              <option>Teamwork</option>
              <option>Verbal Communication</option>
              <option>Time management</option> */}

              </select>
            {/* <input type="text" className="form-control"
                value = {props.search_term}
                onChange = {(e) => {
                    props.setSearchEmployeeFilter(
                    "search_term",e.target.value  
                    );
                    props.setSearchEmployeeFilter(
                        "filter",1
                    );
                    props.updatePageNumber(0)  
                    props.getAllUnappliedEmployees({
                        employer_id:localStorage.getItem('emp_id'),
                        filter:1,
                        position:props.position,
                        location:props.location,
                        search_term : e.target.value,
                        industry_type:props.industry_type,
                        experience:props.experience,
                        lat:props.lat,
                        lon:props.lon,
                        limit:props.limit,
                        page_no :0
                    },false)
                }}
                placeholder="Example:Team Work..." name = "skill_sets"
            /> */}
            </div>
            <div className="form-group col-lg-2 col-md-6">
            <label>Experience</label>
                {/* {console.log(props.experience, 'props.experience')} */}
                <select className="form-control selectpicker"
                data-live-search="true"    
                title = "Choose Experience"
            value = {props.experience}
            onChange = {(e) => {
                props.setSearchEmployeeFilter(
                 
                "experience",e.target.value  
                );
                props.setSearchEmployeeFilter(
                    "filter",1
                );
                props.updatePageNumber(0)  
                props.getAllUnappliedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:1,
                    is_vaccinated:props.is_vaccinated,
                    position:props.position,
                    location:props.location,
                    search_term : props.search_term,
                    industry_type:props.industry_type,
                    experience:e.target.value,
                    lat:props.lat,
                    lon:props.lon,
                    limit:props.limit,
                    page_no :0
                },false)
            }}
            >
                {/* <option value = "">Choose Experience</option> */}
                <option value = "0 - 1 year">0 - 1 year</option>
                <option value = "1 - 2 year">1 - 2 years</option>
                <option value = "2 - 3 year">2 - 3 years</option>
                <option value = "3 - 4 years">3 - 4 years</option>
                <option value = "5+ years">5+ years</option>
            </select>
            
            </div>
            <div className="col-12 text-right mb-3">
            <div className="row">
                <div className="col-md-6">
                <label className="input">
                <input 
                type="checkbox" name="ot-req" 
                checked = {props.is_vaccinated}
                onChange = {(e) => {
                    props.setSearchEmployeeFilter(
                        "is_vaccinated",!props.is_vaccinated
                    );
                    props.getAllUnappliedEmployees({
                        employer_id:localStorage.getItem('emp_id'),
                        filter:1,
                        is_vaccinated:!props.is_vaccinated,
                        position:props.position,
                        location:props.location,
                        search_term : props.search_term,
                        industry_type:props.industry_type,
                        experience:props.experience,
                        lat:null,
                        lon:null,
                        limit:props.limit,
                        page_no :0
                    }, false)
                    
                }}
                />
                vacinated
            </label>
                </div>
                <div className="col-md-6">
                <button type = "button" className="btn btn-blue"
                onClick = {(e) => {
                    window.jQuery('.form-control').val('');
                    props.setSearchEmployeeFilter("industry_type",null);
                    props.setSearchEmployeeFilter("position",null);
                    props.setSearchEmployeeFilter("location",null);
                    props.setSearchEmployeeFilter("search_term",null);
                    props.setSearchEmployeeFilter("experience",null);
                    props.setSearchEmployeeFilter(
                        "filter",1
                    );
                    props.updatePageNumber(0)  
                    props.getAllUnappliedEmployees({
                        employer_id:localStorage.getItem('emp_id'),
                        filter:0,
                        position:null,
                        is_vaccinated:props.is_vaccinated,
                        location:null,
                        search_term :null,
                        industry_type:null,
                        experience:null,
                        lat:props.lat,
                        lon:props.lon,
                        limit:props.limit,
                        page_no :0
                    },false)
                }}
                >Reset All</button>
                </div>
            </div>
            </div>
        </form>
        </>
    )
}

const mapStateToProps = (state, ownProps) => {
    return {
        skills: state.Home.skills,
        listOnePosition:state.Hire.listOnePosition,
        position:state.Filters.position,
        location :state.Filters.location ,
        filter :state.Filters.filter ,
        industry_type :state.Filters.industry_type ,
        experience :state.Filters.experience ,
        search_term :state.Filters.search_term ,
        limit:state.Hire.limit,
        page_no :state.Hire.page_no ,
        lat:state.Filters.lat,
        lon:state.Filters.lon,
        industries : state.Home.industries,
        is_vaccinated : state.Filters.is_vaccinated
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        updatePageNumber : (data) => dispatch(actions.updatePageNumber(data)),
        setSearchEmployeeFilter : (f,v) => dispatch(FilterActions.setSearchEmployeeFilter(f,v)),
        getShortListedEmployees : (data) => dispatch(actions.getShortlistedEmployees(data)),
        getAllEmployees : (data) => dispatch(actions.getAllEmployees(data)),
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),
        getAllUnappliedEmployees  :(data) => dispatch(actions.getAllUnappliedEmployees (data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ShortlistSearch);
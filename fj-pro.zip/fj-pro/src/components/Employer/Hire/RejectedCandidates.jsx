import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import Loader from "../../Helper/Loader";
// import Shedule from './InterviewSchedule';
import * as actions from '../../../actions/Employer/Hire';
import { Link } from "react-router-dom";
import history from "../../../stores/history";

function RejectedCandidates(props) {    
    const[state, setState] = useState({
        position: null,
        location : null,
        filter : 0,
        experience : null,
        industry_type : "F&B",
        search_term : null
    })
    // console.log(props.rejectedList, 'props.rejectedList')
    return (
        <>
        
        <div className="row">
        {
        !props.loading ? (
            <>
                {
                    props.rejectedList && 
                    props.rejectedList.length > 0 ?
                    props.rejectedList.map((i,k) => {
                        return (
                            
                            <div className="col-md-4 col-lg-4 col-xl-3" key = {k}> 
                            <div className="job-snippet profile-snippet">
                            <Link className="img-wrap"
                            to = {`view-profile/${i.id}/${i.employee. id}/rejected`}
                            >
                            <img className="img-fluid" 
                            src={
                                !i.employee.profile_url || i.employee.profile_url === "null"
                                || i.employee.profile_url === null
                                ? 
                                "/assets/images/app/profile-default.png" :i.employee.profile_url
                            } 
                            // alt="img" 
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                            />
                                {/* <a href="javascript:;" 
                                className={`favorite ${i.bookmarked && i.bookmarked  === '1' ? 'saved':''}`}
                                 onClick = {(e) => {
                                  props.bookMark({
                                        'application_id':i.id,
                                        'bookmarked':i.bookmarked === '1' ? '0':'1',
                                        'api_call':0
                                    })
                                 }}
                                >
                                <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                                </a> */}
                            </Link>
                            <div className="r-job-item">
                                {/* <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    <li>
                                    <Link to = {`view-profile/${i.id}/${i.employee.id}`}>View Profile</Link>
                                    </li>
                                    <li><a href="javascript:;"
                                    onClick = {(e) => {
                                                
                                        props.shortListEmployee({
                                            employee_id:i.employee.id,
                                            job_id:i.job.id,
                                            application_id:i.id
                                            // job_id:i.id
                                        })
                                    }}
                                    >Shortlist</a></li>
                                    <li>
                                    <a href="javascript:;" className="red"
                                    onClick = {() => {
                                        props.declineEmployee({
                                            id : i.id
                                        })
                                    }}
                                    >Reject
                                    </a>
                                    </li>
                                    </ul>
                                </div>
                                </div> */}
                                <h6
                                onClick = {() => {
                                    history.push(`view-profile/${i.id}/${i.employee. id}/rejected`)
                                }}
                                >{i.employee.name}</h6>
                                <span className="job-type text-truncate"
                                onClick = {() => {
                                    history.push(`view-profile/${i.id}/${i.employee. id}/rejected`)
                                }}
                                >
                                {i.job.job_type} | {i.job.job_position}</span>
                                <span className="location text-truncate d-block"
                                onClick = {() => {
                                    history.push(`view-profile/${i.id}/${i.employee. id}/rejected`)
                                }}
                                >
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job.job_location}
                                </span>
                                <Link to = {`view-profile/${i.id}/${i.employee. id}/rejected`}>
                                <button className="btn btn-blue get_scheduled_details"
                                
                                // data-id = {i.id}
                                // data-empid = {i.employee.id}
                                // data-jobid = {i.job.id}
                                // onClick = {() => {props.hireEmployee({
                                //     employee_id:i.employee.id,
                                //     job_id:i.job.id
                                // })}}
                                // onClick = {() => {
                                //     props.setShowModel(true);
                                // }
                                // }
                                >
                                   View Profile
                                </button>
                                </Link>
                                
                            </div>
                            </div>
                            </div>
                        
                        )
                    }) : (
                        <>
                        <div className="empty-job">
                            <img src="/assets/images/app/undraw-empty.svg" alt="image"/>
                            <p>There's nothing here.</p>
                        </div>
                        </>
                    )
            
                }    
            </>
        ) : (
            <>
            <div className="empty-job">
                <Loader />
            </div>
            </>
        )
    
        }
        </div>
        {/* <Shedule /> */}
        </>
    )
}


const mapStateToProps = (state, ownProps) => {
    return {
        rejectedList:state.Hire.rejectedList,
        show:state.Hire.show,
        varient:state.Hire.varient,
        showMsg:state.Hire.showMsg,
        hire_status:state.Hire.hire_status,
        listOnePosition : state.Hire.listOnePosition,
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getRejectedCandidates : (data) => dispatch(actions.getRejected(data)),
        shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        setShow: (data) => dispatch(actions.setShow(data)),   
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),
        declineEmployee: (data) => dispatch(actions.declineEmployee(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        bookMark:(data) => dispatch(actions.bookMark(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        scheduleInterview:(data) => dispatch(actions.scheduleInterview(data))

    }
};

export default connect(mapStateToProps, mapDispatchToProps)(RejectedCandidates);
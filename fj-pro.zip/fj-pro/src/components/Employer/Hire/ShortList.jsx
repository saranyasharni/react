import React, { useEffect, useState} from "react";
import { connect } from 'react-redux';
import Loader from "../../Helper/Loader";
import Shedule from './Models/InterviewScheduleModal';
import * as actions from '../../../actions/Employer/Hire';
import { Link } from "react-router-dom";
import $ from 'jquery';
import history from "../../../stores/history";
import ShortListModel from "./ShortListModel";

function ShortLists(props) {    
  
  
    return (
        
        <>
        {/* <SearchSection /> */}
        <div className="row">
        {
        !props.loading ? (
            <>
                {
                    props.shortListedEmployees && 
                    props.shortListedEmployees.length > 0 ?
                    props.shortListedEmployees.map((i,k) => {
                        return (
                            <>
                            <div className="col-md-4 col-lg-4 col-xl-3" key = {k}> 
                            <div className="job-snippet profile-snippet">
                            <Link className="img-wrap" 
                            to ={`view-profile/${i.id}/${i.employee.id}/shortlisted`}
                            >
                            <img className="img-fluid" 
                            src={!i.employee.profile_url || i.employee.profile_url === "null"? "/assets/images/app/profile-default.png" :i.employee.profile_url
                            } 
                            // alt="img" 
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                            />
                                {/* <a href="javascript:;" className={`favorite ${i.bookmarked  === '1' ? 'saved':''}`}
                                 onClick = {(e) => {
                                  props.bookMark({
                                        'application_id':i.id,
                                        'bookmarked':i.bookmarked === '1' ? '0':'1',
                                        'api_call':0
                                    })
                                 }}
                                >
                                <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                                </a> */}
                            </Link>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    <li>
                                    <Link to = 
                                    {`view-profile/${i.id}/${i.employee.id}/shortlisted`}>
                                        View Profile</Link>
                                    </li>
                                    <li><a href="javascript:;"
                                    onClick = {(e) => {
                                                
                                        if (localStorage.notify_employer_model === "1") {
                                            window.$('#notify-employer-model').modal('show')
                                        } else {
                                            
                                            props.hireCandidateModal(true, true, i.id, 
                                                i.employee.profile_url)
                                            props.getCandidateDetails({
                                                job_id:i.job.id,
                                                employee_id : i.employee.id
                                            });         
                                        }
                                    }}
                                    >Hire</a></li>
                                    <li><a href="javascript:;"
                                    onClick = {(e) => {
                                                
                                        props.setShortListModel({
                                            application_id: 'null',
                                            employee_id: i.employee.id,
                                            job_id : null,
                                            show:true,
                                            status_code: 2,
                                            show_status: 'show',
                                            request : 1
                                        });
                                    }}
                                    >Reshortlist</a></li>
                                    <li>
                                    <a href="javascript:;" className="red"
                                    onClick = {() => {
                                        props.rejectCandidate({
                                            application_id:i.id,
                                            status_code:9
                                        })
                                        // props.declineEmployee({
                                        //     id : i.id
                                        // })
                                    }}
                                    >Reject
                                    </a>
                                    </li>
                                    </ul>
                                </div>
                                </div>
                                <h6
                                onClick = {() => { 
                                    history.push(`view-profile/${i.id}/${i.employee.id}/shortlisted`)
                                }}
                                >{i.employee.name}</h6>
                                <span className="job-type text-truncate"
                                onClick = {() => {
                                    history.push(`view-profile/${i.id}/${i.employee.id}/shortlisted`)
                                }}
                                >
                                {i.job.job_type} | {i.job.job_position}</span>
                                <span className="location text-truncate d-block"
                                onClick = {() => {
                                    history.push(`view-profile/${i.id}/${i.employee.id}/shortlisted`)
                                }}
                                >
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job.job_location}
                                </span>
                                <button className="btn btn-blue get_scheduled_details"
                                
                                data-id = {i.id}
                                data-empid = {i.employee.id}
                                data-jobid = {i.job.id}
                                // onClick = {() => {props.hireEmployee({
                                //     employee_id:i.employee.id,
                                //     job_id:i.job.id
                                // })}}
                                onClick = {() => {
                                    props.setShowModel({
                                    employee_id : i.employee.id,
                                    application_id : i.id,
                                    show: true,
                                    job_id : i.job.id,
                                    show_status: 'hide',
                                    request:0
                                    });
                                }
                                }
                                >
                                    Schedule Interview
                                </button>
                            </div>
                            </div>
                            </div>
                        </>
                        )
                    }) : (
                        <>
                        <div className="empty-job">
                            <img src="/assets/images/app/undraw-empty.svg" alt="image"/>
                            <p>There's nothing here.</p>
                        </div>
                        </>
                    )
            
                }    
            </>
        ) : (
            <>
            <div className="empty-job">
                <Loader />
            </div>
            </>
        )
    
        }
        </div>
        <ShortListModel />
        <Shedule />
        </>
    )
}


const mapStateToProps = (state, ownProps) => {
    return {
        shortListedEmployees:state.Hire.shortListedEmployees,
        show:state.Hire.show,
        varient:state.Hire.varient,
        
        showMsg:state.Hire.showMsg,
        hire_status:state.Hire.hire_status
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        setShow: (data) => dispatch(actions.setShow(data)),   
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        declineEmployee: (data) => dispatch(actions.declineEmployee(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        bookMark:(data) => dispatch(actions.bookMark(data)),
        getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data)),
        rejectCandidate : (data) => dispatch(actions.rejectCandidate(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        scheduleInterview:(data) => dispatch(actions.scheduleInterview(data)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ShortLists);
import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import * as actions from '../../../actions/Employer/Hire'

function StaffSearch(props) {    
    const[state, setState] = useState({
        position: null,
        location : null,
        filter : 0,
        experience : null,
        industry_type : "F&B",
        search_term : null,
        page_no :0,
        limit :15
    })

    // useEffect (() => {
    //     // alert()
    //     props.getOnePosition({
    //         industry_type:'F&B'
    //     })
    // }, [])

    return (
        <>
        
        <form className="custom-form row five-col form-section my-3">
        <div className="form-group col-md-3">
        <label>Position</label>
        <select className="form-control"
            value = {state.industry_type}
            onChange = {(e) => {
                setState({
                    ...state,
                    industry_type:e.target.value
                });
                props.getOnePosition({
                    industry_type:e.target.value
                });
                props.getAllEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:1,
                    job_position:state.position,
                    industry_type : state.industry_type,
                    status_code:1,
                    page_no :state.page_no,
                    limit :state.limit
                })
            }}
            >
        
            <option value = "">Choose Category</option>
            <option value = "Events & Promotions">Events &amp; Promotions</option>
            <option value = "F&B">F&amp;B</option>
            <option value = "Hospitality"> Hospitality</option>
            <option value = "Logistics">Logistics</option>
        </select>
        </div>
        <div className="form-group col-md-3">
        {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
        <label >Category</label>
        <select className="form-control lft-ico"
        value = {state.position}
        onChange = {(e) => {
            setState({
                ...state,
                position : e.target.value
            });
            props.getAllEmployees({
                employer_id:localStorage.getItem('emp_id'),
                filter:1,
                job_position:state.position,
                industry_type : state.industry_type,
                status_code:1,
                page_no :state.page_no,
                limit :state.limit
            });
        }}
        >
            <option value = "">Select Position</option>
            {
                props.listOnePosition.length > 0 && 
                props.listOnePosition.map((i,k) => {
                    
                    return <option
                        key = {k}
                        value = {i}
                        >
                         {i}
                    </option>
                })
            }
        </select>
        </div>
        </form>
        
        </>
    )
}

const mapStateToProps = (state, ownProps) => {
    return {
        listOnePosition:state.Hire.listOnePosition,
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getAllEmployees : (data) => dispatch(actions.getAllEmployees(data)),
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),

    }
};

export default connect(mapStateToProps, mapDispatchToProps)(StaffSearch);
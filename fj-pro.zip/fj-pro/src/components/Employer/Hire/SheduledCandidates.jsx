import React, { useEffect , useState} from "react";
import { connect } from 'react-redux';
import Loader from "../../Helper/Loader";
import HireModal from './Models/HireCandidate';
import ContractModel from './Models/ContractModel';
import * as actions from '../../../actions/Employer/Hire';
import { Link } from "react-router-dom";
import history from "../../../stores/history";
import ShortListModel from "./ShortListModel";

function ShortLists(props) {    
    const[state, setState] = useState({
        position:"waiter" ,
        filter : 0,
        industry_type :"F&B",
        experience : "0 - 1 year",
        search_term : null,
        job_id : '',
        employee_id:'',
        status_code:''
    })  
    return (
        <>    
        <div className="row">
        {
            // console.log(props.scheduleList, 'props.scheduleList'),
        !props.loading ? (
            <>
                {
                    props.scheduleList && 
                    props.scheduleList.length > 0 ?
                    props.scheduleList.map((i,k) => {
                        return (
                            <>
                            <div className="col-md-4 col-lg-4 col-xl-3" key = {k}> 
                            <div className="job-snippet profile-snippet">
                            <Link className="img-wrap"
                            to ={`view-profile/schedule/${i.id}/${i.job_application.employee.id}`}
                            >
                            <img className="img-fluid" 
                            src={
                                i.job_application &&
                                i.job_application.employee && 
                                i.job_application.employee.profile_url &&
                                i.job_application.employee.profile_url !== "null" ?
                                i.job_application.employee.profile_url : 

                                 "/assets/images/app/profile-default.png" 
                            } 
                            // alt="img" 
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                            />
                            <a href="javascript:;" 
                                // className={`favorite ${i.bookmarked  === '1' ? 'saved':''}`}
                                 onClick = {(e) => {
                                  props.bookMark({
                                        'application_id':i.id,
                                        'bookmarked':i.bookmarked === '1' ? '0':'1',
                                        'api_call':0
                                    })
                                 }}
                                >
                                <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                                </a>
                            </Link>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    {/* <li>
                                    <Link to = {`view-profile/${i.id}/${i.job_application.employee.id}`}>View Profile</Link>
                                    </li> */}
                                    <li><a href="javascript:;"
                                    onClick = {(e) => {
                                        if (localStorage.notify_employer_model === "1") {
                                            window.$('#notify-employer-model').modal('show')
                                        } else {
                                            props.hireCandidateModal(true, true,
                                                 i.id, i.job_application.employee.profile_url)
                                        setState({
                                            ...state, 
                                            employee_id:i.job_application.employee.id,
                                            job_id:i.job_application.job.id,
                                            status_code:3
                                        });
                                        props.getCandidateDetails({
                                            job_id:i.job_application.job.id,
                                            employee_id : i.job_application.employee.id
                                        })         
                                        }
                                    }}
                                    >Hire Candidate</a></li>
                                    <li><a href="javascript:;"
                                    onClick = {(e) => {
                                        props.setShortListModel({
                                            application_id: 'null',
                                            employee_id: i.job_application.employee.id,
                                            job_id : null,
                                            show:true,
                                            status_code: 2,
                                            show_status: 'show',
                                            request : 1
                                        });
                                    }}
                                    >Reshortlist</a></li>
                                    <li>
                                    <a href="javascript:;" className="red"
                                    onClick = {() => {
                                        props.rejectCandidate({
                                            application_id:i.job_application.id,
                                            status_code:9
                                        })
                                    }}
                                    >Reject Candidate
                                    </a>
                                    </li>
                                    </ul>
                                </div>
                                </div>
                                <h6
                                onClick = {() => {
                                    history.push(`view-profile/schedule/${i.id}/${i.job_application.employee.id}`)
                                }}
                                >{i.job_application.employee.name}</h6>
                                <span className="job-type text-truncate"
                                onClick = {() => {
                                    history.push(`view-profile/schedule/${i.id}/${i.job_application.employee.id}`)
                                }}
                                >
                                {i.job_application.job.job_type} | {i.job_application.job.job_position}</span>
                                <span className="location text-truncate d-block"
                                onClick = {() => {
                                    history.push(`view-profile/schedule/${i.id}/${i.job_application.employee.id}`)
                                }}
                                >
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job_application.job.job_location}
                                </span>
                                <Link
                                to = {`view-profile/schedule/${i.id}/${i.job_application.employee.id}`}
                                >
                                <button className="btn btn-blue get_scheduled_details"
                                data-id = {i.id}
                                data-empid = {i.job_application.employee.id}
                                data-jobid = {i.job_application.job.id}
                                // onClick = {() => {props.hireEmployee({
                                //     employee_id:i.employee.id,
                                //     job_id:i.job.id
                                // })}}
                                // onClick = {() => {
                                //     props.setShowModel(true);
                                // }
                                
                                // }
                                >
                                    View Profile
                                </button>
                                </Link>
                            </div>
                            </div>
                            </div>
                        </>
                        )
                    }) : (
                        <>
                        <div className="empty-job">
                            <img src="/assets/images/app/undraw-empty.svg" alt="image"/>
                            <p>There's nothing here.</p>
                        </div>
                        </>
                    )
            
                }    
            </>
        ) : (
            <>
            <div className="empty-job">
                <Loader />
            </div>
            </>
        )
    
        }
        </div>
        <ShortListModel />
        <HireModal
        scheduledInfo = {state}
        />
        <ContractModel
         scheduledInfo = {state}
        />
        
        {/* <Shedule /> */}
        </>
    )
}


const mapStateToProps = (state, ownProps) => {
    return {
        scheduleList:state.Hire.scheduleList,
        listOnePosition:state.Hire.listOnePosition,
        show:state.Hire.show,
        varient:state.Hire.varient,
        showMsg:state.Hire.showMsg,
        hire_status:state.Hire.hire_status,

    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setShow: (data) => dispatch(actions.setShow(data)),   
        bookMark:(data) => dispatch(actions.bookMark(data)),
        getScheduledCandidates : (data) => dispatch(actions.getSchedules(data)),
        getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        rejectCandidate : (data) => dispatch(actions.rejectCandidate(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ShortLists);
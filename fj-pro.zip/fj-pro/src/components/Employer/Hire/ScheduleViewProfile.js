import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import Header from "../header";
import config from '../../../actions/Common/Api_Links';
import * as actions from "../../../actions/Employer/Hire";
import Alert from "react-bootstrap/Alert";
import $ from 'jquery';
import history from "../../../stores/history"
import moment from "moment"
import {Link} from "react-router-dom";
import HireModal from './Models/HireCandidate';
import ContractModel from './Models/ContractModel';
import PaymentModel from "./PaymentModel";
import Loader from '../../Helper/Loader'
import Notify from "../../NotifyEmployer"
function ScheduleViewProfile(props) {  
    const [profileInfo, setProfileInfo] = useState([])
    const [profileUrl, setProfileUrl] = useState("")
    const [loading, setLoading] = useState(false)
    const [state, setState] = useState({
        job_id : '',
        employee_id:'',
        status_code:'',
    })
    // var jobId =  profileInfo.job_application &&
    //         profileInfo.job_application.length > 0 
    //         ? profileInfo.job_application[0].job_id
    //     :''
        
    useEffect(() => {
        let profile_id = window.location.pathname.split('/')[3]
        // let employee_id = window.location.pathname.split('/')[4]
        var convertData = {
            'schedule_id':profile_id,
            // 'employee_id':employee_id         
        }
        let sendData = JSON.stringify(convertData)
        setLoading(true)
        fetch(
            config.viewScheduleProfile, {
                method: "post",
                headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                },
                body:sendData
            }
          )
            .then((response) => response.json())
            .then((data) => {
                // console.log(data, 'responsedata')
                if (data.data && data.data.job_application
                    && data.data.job_application.employee
                    && data.data.job_application.employee.profile_url !== "null" 
                    && data.data.job_application.employee.profile_url !== null 
                        ) {
                            setProfileUrl(data.data.job_application.employee.profile_url)
                        }
                if (localStorage.account_type_paid === '2') {
                    
                    props.showContact(1)
                } else if (data.data.contact_viewed === 1) {
                    
                    props.showContact(1)
                } else {
                    
                    props.showContact(2)
                }
                setProfileInfo(data.data)
                setLoading(false)
            })
            .catch((e) => {
                setLoading(false)
                console.log(e)
            })
    }, [])  
    useEffect (() => {

        // if (props.hire_status === 1 || props.hire_status ===2 || props.hire_status ===3) {
        //     setTimeout(function(){
        //         props.setShow(false)
        //     }, 2000)
        // }
        return () => {
            props.setShow(false)
        }
    },[])

    return (
        <>
        <div className="container-fluid">
        
        <Header />
        <section className="row main-content">
        <div className="container">
        {loading ? <Loader
        marginTop = '229px'
        marginLeft = '491px'
        /> :
            <div className="row">
            <div className="col-12 hdr-row ff-col">
                <h1>
                <Link 
                // to = onClick
                onClick = {() => {history.goBack()}}
                className="back">
                <img src="/assets/images/app/back-arrow.svg" alt="icon" />
                </Link>
                Profile
                </h1>
                <div>
                <button className="btn btn-red min-w mr-2" 
                 disabled = {props.btnLoading ? true : false}
                onClick = {() => {
                    
                    let application_id =  profileInfo.job_application &&
                    profileInfo
                    ? profileInfo.applicationId
                    :''
                    props.rejectCandidate({
                        application_id:application_id,
                        status_code:9
                    })
                }}    
                >{props.btnLoading ? 'Loading...' : 'Reject'}
                </button>
                <a href="javascript:;" 
                className="btn btn-blue min-w"
                
                onClick = {(e) => {
                    let jobId =  profileInfo.job_application &&
                    profileInfo.job_application 
                    ? profileInfo.job_application.job_id
                    :''
                    if (localStorage.notify_employer_model === "1") {
                        
                        window.$('#notify-employer-model').modal('show')
                    } else {
                        props.hireCandidateModal(true,true,profileInfo.employeeId,profileUrl)
                        setState({
                            ...state, 
                            employee_id:profileInfo.employeeId,
                            job_id:jobId,
                            status_code:3
                        });
                        props.getCandidateDetails({
                            job_id:jobId,
                            employee_id : profileInfo.employeeId
                        })
                    
                    }
                    
                    // if ($(e.target).text() === 'Hired') {
                    //     return;
                    // } else {
                    //     props.hireEmployee({
                    //         employee_id:profileInfo.job_application.employee.id,
                    //         job_id:jobId,
                    //         status_code:3
                    //     })    
                    // }
                    }
                }
                >
                    {props.hire_status === 1 ? 'Hired' : 'Hire'}
                </a>
                </div>
            </div>
            <div className="col-12 mb-5">
                {
                <Alert
                show={props.show}
                variant={props.varient}
                dismissible
                onClose={() => props.setShow(false)}
                >
                <strong>
                    {props.hire_status === 1 ? "Success!" 
                    : props.hire_status === 2 ? "Error!"
                    :"Info"
                    }
                </strong>{" "}
                {props.showMsg}
                </Alert>
                }
                <div className="snippet-box p-4 job-detail">
                <div className="row">
                    <div className="col-md-4 lft-col">
                    <div className="img-wrap mb-4 bdr-rad-btm-0">
                    <img className="img-fluid" src={
                            profileUrl !== "" ? profileUrl :
                            "/assets/images/app/profile-default.png"
                        }
                         alt="image" />
                    </div>
                    <div className="row job-desc mb-4">
                    <div className="col-12">
                    <h4 className="mb-3">Skills</h4>
                    <div className="row mb-2">
                        <div className="col-md-5">
                        <p>Experience</p>
                        </div>
                        <div className="col-md-7">
                        <span>2 Years</span>
                        </div>
                    </div>
                    {
                    profileInfo.job_application &&
                    profileInfo.job_application.employee.languages &&
                    profileInfo.job_application.employee.languages !== undefined &&
                    profileInfo.job_application.employee.languages.lenght > 0 &&
                    <div className="row mb-2">
                        <div className="col-md-5">
                        <p>Job Details
                        </p>
                        </div>
                        {
                            profileInfo.job_application.employee.languages.length > 0 &&
                            profileInfo.job_application.employee.languages.map((i, k) => {
                                return (
                                    <>
                                    <div className="col-md-7" key = {k}>
                                    <span>{i.language} - {i.spoken}</span>
                                    </div>
                                    </>
                                )
                            })
                        }
                    </div>
                    }
                       
                    </div>
                    </div>
                    
                    <div className="row job-desc mt-4">
                    { 
                        profileInfo.employee &&
                        profileInfo.job_application &&
                        profileInfo.job_application.employee.employee_skills && 
                        profileInfo.job_application.employee.employee_skills.length > 0 && 
                        <div className="col-12 col-lg-9">
                        <h4 className="mb-3">Skills</h4>
                        {
                            profileInfo.job_application.employee.employee_skills.map((i,k) => {

                                let stat_date = i.start_date ? moment(new Date(i.start_date)).format("MMM  YYYY"): "";
                                let end_date = i.end_date ? moment(new Date(i.end_date)).format("MMM  YYYY"): "";
                                return (
                                    <div className="exp-encl mb-3" key = {k}>
                                    <span className="exp-title">
                                    <span>{i.skill_name}</span>
                                    <span>
                                        {/* {i.experience} */}
                                    </span>
                                    </span>
                                    
                                </div>
                                )
                            })
                        }
                       
                        </div>
                        }
                    </div>
                    <div className="row job-desc contact mb-4">
                            <div className="col-12"
                            // style = {{background:"bisque"}}
                           
                            >
                            <div className="contact-hide-wrap">
                            {
                            props.profileContactStatus !== 1
                            ? 
                            <div className="content-hidden">
                                Contact Details Locked
                            </div> : ''
                            }
                            <h4 className="mb-2">Contact Details</h4>
                            <p>
                            <img src="/assets/images/app/ic-email.svg" alt="icon" />
                            <a href="mailto:amanda.reyes99@gmail.com">
                                {profileInfo.job_application
                                && profileInfo.job_application
                                && profileInfo.job_application.employee
                                && profileInfo.job_application.employee
                                .email}
                            </a>
                            </p>
                            <p>
                                <img src="/assets/images/app/ic-gps-pin.svg" alt="icon" />
                                {profileInfo.job_application
                                && profileInfo.job_application
                                && profileInfo.job_application.employee
                                && profileInfo.job_application.employee
                                .address}
                            </p>
                            <p className="mb-0">
                                <img src="/assets/images/app/ic-phone.svg" alt="icon" />
                                <a href="tel:(499)-430-5810">
                                {profileInfo.job_application
                                && profileInfo.job_application
                                && profileInfo.job_application.employee
                                && profileInfo.job_application.employee
                                .mobile}
                                </a>
                            </p>
                            </div>
                            </div>
                            
                        </div>
                    
                        {
                        props.profileContactStatus !== 1
                        ? <button className="btn btn-blue"
                        onClick = {() => {
                            props.viewContact({
                                employee_id:profileInfo.id,
                                employer_id:localStorage.getItem('emp_id'),
                                account_type:1
                            })
                        }}
                      >View Contact Details</button>:""
                    }
                    </div>
                    <div className="col-md-8 rgt-col mt-4 mt-md-0">
                        <div className="row job-desc">
                            <div className="col-12">
                            <h4 className="mb-3">Profile Info</h4>
                            <h2 className="mb-1">
                                {/* Carmen Sullivan */}
                                {profileInfo.job_application &&
                        profileInfo.job_application.employee &&
                        profileInfo.job_application.employee.name}
                            </h2>
                            {/* <span className="designation dark">Part- time | Account Admin</span> */}
                            </div>
                        </div>
                        <div className="row job-desc mt-4">
                            <div className="col-12 col-lg-9">
                            <h4 className="mb-3">Job Details</h4>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Job Title</p>
                                </div>
                                <div className="col-md-9">
                                <p>{
                               profileInfo.job_application &&
                               profileInfo.job_application.job 
                               ? profileInfo.job_application.job.job_position
                               :''
                                  }</p>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Company</p>
                                </div>
                                <div className="col-md-9">
                                <p> {
                                profileInfo.job_application &&
                                profileInfo.job_application.job&&
                                 profileInfo.job_application.job.employer.company_name ?profileInfo.job_application.job.employer.company_name
                                :''
                            }</p>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Job Type</p>
                                </div>
                                <div className="col-md-9">
                                <p>{
                              profileInfo.job_application &&
                              profileInfo.job_application.job 
                              ? profileInfo.job_application.job.job_type
                              :''
                            } 
                            </p>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Salary Base</p>
                                </div>
                                <div class="col-md-9">
                            <p>{
                            profileInfo.job_application &&
                            profileInfo.job_application.job && 
                            profileInfo.job_application.job.salary_based

                            } </p>
                            </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Salary</p>
                                </div>
                                <div class="col-md-9">
                            <p>RM { profileInfo.job_application &&
                                profileInfo.job_application.job && 
                                profileInfo.job_application.job.amount }
                            </p>
                            </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Start Date</p>
                                </div>
                                <div class="col-md-9">
                            <p> { profileInfo.job_application &&
                                profileInfo.job_application.job && 
                                moment(new Date(profileInfo.job_application.job.start_date))
                                .format("DD MMMM YYYY") }
                            </p>
                            </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>End Date</p>
                                </div>
                                <div class="col-md-9">
                            <p>{ profileInfo.job_application &&
                                profileInfo.job_application.job && 
                                moment(new Date(profileInfo.job_application.job.end_date))
                                .format("DD MMMM YYYY") }
                            </p>
                            </div>
                            </div>
                            </div>
                        </div>
                        <div className="row job-desc mt-4">
                            <div className="col-12 col-lg-9">
                            <h4 className="mb-3">Interview Schedule</h4>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Interview Date</p>
                                </div>
                                <div className="col-md-9">
                                <p>{moment(new Date(profileInfo.interview_date)).format(' DD MMMM YYYY')}</p>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Interview Time</p>
                                </div> 
                                <div className="col-md-9">
                                <p>{profileInfo.start_time} - {profileInfo.end_time}</p>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-12">
                                <span className="o-7">
                                    Interview scheduled  on {moment(new Date(profileInfo.interview_date)).format(' DD MMMM YYYY')} {profileInfo.start_time} - {profileInfo.end_time}
                                </span>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                </div>
                </div>
            </div>
            </div>
            }
        </div>
                            
        </section>
        </div>
        <HireModal
        scheduledInfo = {state}
        />
        <ContractModel
         scheduledInfo = {state}
        />
        <Notify/>
        <PaymentModel/>
        </>
    )
}

const mapStateToProps = (state, ownProps) => {
    return {
        show:state.Hire.show,
        varient:state.Hire.varient,
        showMsg:state.Hire.showMsg,
        hire_status:state.Hire.hire_status,
        btnLoading:state.Hire.btnLoading,
        disable:state.Hire.disable,
        profileContactStatus:state.Hire.profileContactStatus,
       
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        // shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        viewContact:(data) => dispatch(actions.viewContact(data)),
        showContact:(data) => dispatch(actions.showContact(data)),
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        rejectCandidate : (data) => dispatch(actions.rejectCandidate(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        setShow: (data) => dispatch(actions.setShow(data)),
        getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleViewProfile);
import React, { useEffect, useState } from "react";
import { connect } from 'react-redux';
import * as actions from '../../../actions/Employer/Hire'
import history from "../../../stores/history";
import ShortListModel from './ShortListModel';
import ScheduleInterview from './Models/ScheduleModal'
import Loader from '../../Helper/Loader';
import Notify from "../../NotifyEmployer"
// import { Link } from "react-router-dom";
import jQuery, { data } from "jquery";

function SerchEmployee(props) {        
    useEffect (() => {
        jQuery(document).ready(function (){
            // jQuery(".selectpicker_loca").change(function(){
            //     jQuery("body").addClass("crop");
            // });
            
            // jQuery(".map-sec .close").click(function(){
            //     jQuery("body").removeClass("crop");
            // });
        })        
        props.getOnePosition({
            industry_type:'F&B'
        })
    }, [])
    useEffect(() => {
       
        if (props.extra_loading_status === 1) {
            
            jQuery('.search_emp .alert').html('<strong>No More Profiles</strong>');
            jQuery('.search_emp .alert').removeClass('alert-success').addClass('alert-danger')
           
            setTimeout(function () {
                props.setExtraLoadingStatus(0);
                jQuery(".search_emp .alert").removeClass('alert-danger');
                jQuery('.search_emp .alert').html('');
            }, 2000);
        }
        
    })

    return (
            <div className="row search_emp">
            {
                props.loading ? 
                    <div className="empty-job">
                    <Loader />
                    {/* <img src="/assets/images/loader.gif" alt="icon" /> */}
                    
                    </div>
                    :
                    props.UnEmployeesLists 
                    && props.UnEmployeesLists.length > 0 
                    ? props.UnEmployeesLists.map((i,k) => { 
                    
                    return (
                        
                        <div className="col-md-4 col-lg-3" 
                        key ={k}
                        >
                        <div className="job-snippet profile-snippet"
                         
                        >
                        <div className="img-wrap"
                        onClick = {() => {
                            props.showContact(0)
                            history.push(`/view-profile/0/${i.id}/search-employee`)
                            }
                        }
                        >
                            <img className="img-fluid" 
                            alt="img" 
                            src={!i.profile_url 
                                || i.profile_url === "null"
                                ||i.profile_url === null
                                ? "/assets/images/app/profile-default.png" 
                                :i.profile_url
                            } 
                            
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                            />
                            {/* <a href="javascript:;" className="favorite">
                            <img src="/assets/images/app/heart-icon.svg" alt="icon" />
                            </a> */}
                        </div>
                        <div className="r-job-item">
                        <div className="dropdown more">
                        <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="/assets/images/app/more-btn.svg" />
                        </button>
                        <div className="dropdown-menu" aria-labelledby="more-menu">
                            <ul className="list-unstyled">
                            <li><a href = "javascript:;" 
                            onClick = {() => {    
                                
                                if (localStorage.notify_employer_model === "1") {
                                    window.$('#notify-employer-model').modal('show')
                                } else {
                                    
                                    props.hireCandidateModal(true, true, i.id, i.profile_url)
                                }
                                
                            }}
                            >
                                Hire
                            </a></li>
                            <li>
                            <a href="javascript:;"
                            id = "Shortlist_childs"
                            data_id = {i.id}
                            // employee_id = {i.employee && i.employee.id}
                            onClick = {(e) => {
                                
                                props.setShortListModel({
                                application_id: 'null',
                                employee_id: i.id,
                                job_id : null,
                                show:true,
                                status_code: 2,
                                show_status: 'show',
                                request : 1
                            });
                                // props.shortListEmployee({
                                //     employee_id:i.employee.id,
                                //     job_id:i.job.id
                                // })
                            }}
                            >Shortlist
                            </a>
                            {/* <a href="javascript:;"
                            id = "Shortlist_childs"
                            data_id = {i.id}
                            // employee_id = {i.employee && i.employee.id}
                            onClick = {(e) => {
                                
                                // window.$('#arranging-interviews').modal('show')
                                props.scheduleModel({
                                    employee_id : i.id,
                                    application_id : "null",
                                    show: true,
                                    job_id : null,
                                    show_status: 'show',
                                    request:1
                                })
                            }}
                            >Shortlist
                            </a> */}
                            </li>
                            <li>
                            <a href="javascript:;"
                            data-id = "null"
                            data-empid = {i.id}
                            onClick = {() => { 
                                props.setShowModel({
                                    employee_id : i.id,
                                    application_id : "null",
                                    show: true,
                                    job_id : null,
                                    show_status: 'show',
                                    request:1
                                });
                            }}
                            >   Schedule Interview </a>
                            </li>
                            </ul>
                        </div>
                        </div>
                        <h6
                        onClick = {() => {
                            props.showContact(0)
                            history.push(`/view-profile/0/${i.id}/search-employee`)
                            }
                        }
                        >{i.name}</h6>
                        <span className="job-type text-truncate"
                         onClick = {() => {
                            props.showContact(0)
                            history.push(`/view-profile/0/${i.id}/search-employee`)
                            }
                        }
                        >
                            {i.gender} | {i.years_of_experience ? i.years_of_experience : '0 years' }
                        </span>
                        <span className="location text-truncate d-block"
                         onClick = {() => {
                            props.showContact(0)
                            history.push(`/view-profile/0/${i.id}/search-employee`)
                            }
                        }
                        >
                        <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                        {i.address}
                        </span>
                        <button className="btn btn-blue" 
                        // data-toggle="modal" 
                        onClick = {() => {
                            props.showContact(0)
                            history.push(`/view-profile/0/${i.id}/search-employee`)
                            }
                        }
                        // data-target="#rehire-modal"
                        >View Profile
                        </button>
                        </div>
                        </div>
                        </div>
                        
                    )
                }) 
                : 
              
                <div className="empty-job">
                    <img src="assets/images/app/undraw-empty.svg" alt="image"/>
                    <p>There's nothing here.</p>
                </div>

            }

            {
                !props.loading && props.UnEmployeesLists.length > 0 &&
                <div className={`col-12 text-center my-5 ${props.UnEmployeesLists.length > 0 
                    ? 'd-block': 'd-none'}`}
                >
                    <div className="alert" role="alert">

                    </div>
                   <button className="btn btn-blue px-5 load_more_btn"
                   disabled = {props.extraLoading ? true : false}
                   onClick = {() => {
                    props.updatePageNumber(props.page_no+1)  
                    props.getAllUnappliedEmployees({
                        employer_id:localStorage.getItem('emp_id'),
                        filter:props.filter,
                        position:props.position,
                        location:props.location,
                        search_term : props.search_term,
                        experience:props.experience,
                        industry_type: props.industry_type,
                        lat:props.lat,
                        lon:props.lon,
                        page_no:props.page_no+1,
                        limit:props.limit
                    }, true)
                    }}
                   >
                    {
                        props.extraLoading ? 'Loading...' : 'Load More'
                    }
                    </button>
               </div>
            }
            
            <ShortListModel/>
            <ScheduleInterview/>    
            {/* <Notify/> */}
            

            </div>

    )
}


const mapStateToProps = (state, ownProps) => {
    return {
        UnEmployeesLists: state.Hire.UnEmployeesLists,
        listOnePosition:state.Hire.listOnePosition,
        employeeLists:state.Hire.employeeLists,
        loading:state.Hire.loading,
        page_no : state.Hire.page_no,
        show:state.Hire.show,
        varient:state.Hire.varient,
        showMsg:state.Hire.showMsg,
        extraLoading: state.Hire.extraLoading,
        hire_status:state.Hire.hire_status,
        position:state.Filters.position,
        location :state.Filters.location ,
        filter :state.Filters.filter ,
        industry_type :state.Filters.industry_type ,
        experience :state.Filters.experience ,
        search_term :state.Filters.search_term ,
        limit:state.Hire.limit,
        lat:state.Filters.lat,
        lon:state.Filters.lon,
        extra_loading_status:state.Hire.extra_loading_status
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getAllUnappliedEmployees : (data, val) => dispatch(actions.getAllUnappliedEmployees(data, val)),
        getShortListedEmployees : (data) => dispatch(actions.getShortlistedEmployees(data)),
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        getAllPositions : () => dispatch(actions.getAllPositions()),
        showContact:(data) => dispatch(actions.showContact(data)),
        shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        setShow: (data) => dispatch(actions.setShow(data)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        declineEmployee: (data) => dispatch(actions.declineEmployee(data)),
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)) ,
        updatePageNumber : (data) => dispatch(actions.updatePageNumber(data)),
        setExtraLoadingStatus :(data) => dispatch(actions.setExtraLoadingStatus(data)),
        scheduleModel : data => dispatch(actions.scheduleModelsetUp(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(SerchEmployee);
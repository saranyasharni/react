import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../actions/Employer/Hire";
import $ from 'jquery';
import StripeCheckout from 'react-stripe-checkout';

function PaymentModel(props) {
    const [formFields, setFormFields] = useState({
        position:'',
        industry_type:'F&B',
        errors: {}
    })

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
            window.$('.selectpicker').selectpicker()
            window.$(".input-group.start_date")
                .datepicker({
                format: "mm/dd/yyyy",
                todayHighlight: true,
                autoclose:true
                // endDate: "+0d",
                })
                .off("change")
                .change((e) => {{
                    setFormFields({
                        ...formFields,
                        date: e.target.value
                    }); 
                } });
        })
    });

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
        window.$(".input-group.start_date")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
            autoclose:true
        // endDate: "+0d",
        })
    })
    }, []);

    const updateErrors = errors => {
        setFormFields({
          ...formFields, 
          errors: { ...formFields.errors, ...errors }
        });
    };

    const validation = async (e) => {
        let errors = formFields.errors;
        let valid = true;

        if (formFields.position === '') {
            errors.position = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }

        updateErrors(errors);
        return valid;
    } 

    const onToken = () => {
      props.upgradeAccount()   
    }

    const showScrollBar =() => {
      $('body').css('overflow', '')
    }
    
    return (
    <Modal show={props.modelPaymentShow} 
        className="modal fade custom-modal"
        onHide={() =>   props.setPaymentModel(false)}
        tabIndex={-1} role="dialog" 
        aria-hidden="true"
        id="confirm-payment"
        centered
    >
           
    {/* <div className="modal-dialog modal-dialog-centered" role="document"> */}
    <div className="modal-content">
      <div className="modal-header">
        <h5 className="mt-2 modal-title w-100 justify-content-center">Confirm Payment</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close"
        onClick = {() => {props.setPaymentModel(false)}}
        >
          <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3">
        <div className="row">
          <div className="col-md-12">
            <p className="fs-14 dark">Do you confirm to pay $ 10.00 to see more contact details?</p>
          </div>
        </div>
        <div className="row mt-2 mb-3">
          <div className="col-md-12 text-right">
          <StripeCheckout
                       amount={'10'}
                       billingAddress
                       shippingAddress
                       closed = {showScrollBar}
                       name="Upgrade now." // the pop-in header title
                       // description="Big Data Stuff" // the pop-in header subtitle
                       // className="btn btn-orange" 
                    //    style = {{marginLeft:'900px'}}
                       // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                       // description="Awesome Product"
                       // image="assets/images/logo-small.png"
                       stripeKey="pk_test_51IknhvSBf2Rw9k3F4KyXJRX7iOyoztpzn5yAUWLLSvs7uBj9FQdB488ke7aevqLUyaasz0u5yUY6zQ9Rtljb0xKJ00TPVSUNBE"
                       token={onToken}
                   >
              <button className="btn btn-blue"
              onClick = {() => {
                props.setPaymentModel(false)
              }}
              >Confirm Pay</button>
                </StripeCheckout> 
            
          </div>
        </div>
      </div>
    </div>
  {/* </div> */}


        </Modal>
    )
};

const mapStateToProps = (state, ownProps) => {
    return {
        modelPaymentShow: state.Hire.modelPaymentShow,
        
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        setPaymentModel: (data) => dispatch(actions.setPaymentModel(data)),
        upgradeAccount : () => dispatch(actions.upgradeAccount())
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentModel);
import React from "react";
import { connect } from 'react-redux'
import * as actions from '../../../../actions/Employer/Hire'
import history from "../../../../stores/history";
import ShortListModel from '../ShortListModel';
import ScheduleInterview from '../Models/InterviewScheduleModal'
import jQuery from "jquery";
import Notify from "../../../NotifyEmployer"
class SearchEmpList extends React.Component{
    constructor(props) {
        super(props);
    }
    componentDidUpdate() {
        let THIS = this
        if (THIS.props.extra_loading_status === 1) {
            jQuery('.search_emp .alert').html('<strong>No More Profiles</strong>');
            jQuery('.search_emp .alert').removeClass('alert-success').addClass('alert-danger')
           
            setTimeout(function () {
                THIS.props.setExtraLoadingStatus(0);
                jQuery(".search_emp .alert").removeClass('alert-danger');
                jQuery('.search_emp .alert').html('');
            }, 2000);
        }
    }

    render() {
        return(
            <>
           
            <div className="row job-list search_emp">
                { this.props.UnEmployeesLists &&
                    this.props.UnEmployeesLists.length > 0 ?
                    this.props.UnEmployeesLists.map((i, k) => {
                        return (
                            <div className="col-12" key = {k}>
                            <div className="job-snippet">
                            <div className="img-wrap"
                              onClick = {() => {
                                history.push(`/view-profile/0/${i.id}/search-employee`)
                            }}
                            >
                            <img className="img-fluid" 
                            alt="img" 
                            src={
                                !i.profile_url 
                                || i.profile_url === "null"
                                ||i.profile_url === null
                                ? process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                :i.profile_url
                            } 
                            
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                            />
                                {/* <img className="img-fluid" src="/assets/images/app/job-snip-img.jpg" alt="img" /> */}
                                {/* <span className="date badge">Thu 16 - Sun 20</span> */}
                            </div>
                            <div className="r-job-item">
                                <div className="dropdown more">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                    <ul className="list-unstyled">
                                    <li><a href="javascript:;"
                                    onClick = {() => {
                                        history.push(`/view-profile/0/${i.id}/search-employee`)
                                    }}
                                    >View Profile</a></li>
                                     <li><a href = "javascript:;" 
                                    onClick = {() => {    
                                        if (localStorage.notify_employer_model === "1") {
                                            window.jQuery('#notify-employer-model').modal('show')
                                        } else {
                                            this.props.hireCandidateModal(true, true, i.id, i.profile_url )
                                        }
                                     
                                    }}
                                    >
                                    Hire
                                    </a></li>
                                    <li><a 
                                    href="javascript:;"
                                    onClick = {(e) => {
                                        
                                        this.props.setShortListModel({
                                            application_id: 'null',
                                            employee_id: i.id,
                                            job_id : null,
                                            show:true,
                                            status_code: 2,
                                            show_status: 'show',
                                            request : 1
                                        })
                                    }}
                                    >Shortlist</a></li>
                                    <li><a href="javascript:;"
                                    onClick = {() => {
                                        this.props.setShowModel({
                                            employee_id : i.id,
                                            application_id : "null",
                                            show: true,
                                            job_id : null,
                                            show_status: 'show',
                                            request:1
                                        });
                                    }}
                                    >Schedule Interview</a></li>
                                    
                                    </ul>
                                </div>
                                </div>
                                <div className="row"
                                onClick = {() => {
                                    history.push(`/view-profile/0/${i.id}/search-employee`)
                                }}
                                >
                                <div className="col-md-3">
                                    {/* <span className="date badge d-inline-block d-lg-none">Thu 16 - Sun 20</span> */}
                                    <h6>{i.name}</h6>
                                    <span className="job-type text-truncate">{i.gender}</span>
                                    <span className="location text-truncate d-block">
                                    <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                    {i.address}
                                    </span>
                                    <p className="text-truncate">Experience | {i.years_of_experience ? i.years_of_experience : '0 years' }</p>
                                </div>
                                <div className="col-md-7 btn-wrap invisible">
                                    <button className="btn btn-gray-light">
                                    Total no of Vacancies
                                    <span>28</span>
                                    </button>
                                    <button className="btn btn-gray-light">
                                    Total Jobs Filled
                                    <span>5</span>
                                    </button>
                                    <button className="btn btn-gray-light">
                                    Active Vacancies
                                    <span>2</span>
                                    </button>
                                    <button className="btn btn-gray-light" data-toggle="modal" data-target="#views-modal">
                                    Total No of Views
                                    <span>340</span>
                                    </button>
                                    <button data-toggle="modal" data-target="#applicants-modal" className="btn btn-gray-light">
                                    No of Applicants
                                    <span>30</span>
                                    </button>
                                    <button className="btn btn-gray-light" data-toggle="modal" data-target="#shortlist-modal">
                                    No of Shortlisted
                                    <span>20</span>
                                    </button>
                                </div>
                                {/* <div className="col-md-2">
                                    <p className="expire">Job Expires in 10 days</p>
                                </div> */}
                                </div>
                            </div>
                            </div>
                 
                        </div>
                        
                        )
                    }) : 
                <div className="empty-job">
                    <img src="assets/images/app/undraw-empty.svg" alt="image"/>
                    <p>There's nothing here.</p>
                </div>   
                }
            {
                this.props.UnEmployeesLists.length > 0 &&
                <div className={`col-12 text-center my-5 
                ${this.props.UnEmployeesLists.length > 0 
                ? 'd-block': 'd-none'}`}
                >
                <div className="alert" role="alert">

                </div>
                {
                    console.log('extraLoading', this.props.extraLoading)
                }
                <button className="btn btn-blue px-5 load_more_btn"
                disabled = {this.props.extraLoading ? true : false}
                onClick = {() => {
                this.props.updatePageNumber(this.props.page_no+1)  
                this.props.getAllUnappliedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:this.props.filter,
                    position:this.props.position,
                    location:this.props.location,
                    search_term : this.props.search_term,
                    experience:this.props.experience,
                    industry_type: this.props.industry_type,
                    lat:this.props.lat,
                    lon:this.props.lon,
                    page_no:this.props.page_no+1,
                    limit:this.props.limit
                }, true)
                }}
                >{
                
                this.props.extraLoading ? 'Loading...' : 'Load More'}
                </button>
               </div>
            }
            
            </div>
            <ShortListModel 

        />
        <Notify/>
        <ScheduleInterview />
        </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        UnEmployeesLists: state.Hire.UnEmployeesLists,
        listOnePosition:state.Hire.listOnePosition,
        position:state.Filters.position,
        location :state.Filters.location ,
        filter :state.Filters.filter ,
        industry_type :state.Filters.industry_type ,
        experience :state.Filters.experience ,
        search_term :state.Filters.search_term ,
        limit:state.Hire.limit,
        lat:state.Filters.lat,
        lon:state.Filters.lon,
        page_no : state.Hire.page_no,
        extra_loading_status:state.Hire.extra_loading_status,
        extraLoading: state.Hire.extraLoading,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        updatePageNumber : (data) => dispatch(actions.updatePageNumber(data)),
        getAllUnappliedEmployees : (data, val) => 
        dispatch(actions.getAllUnappliedEmployees(data, val)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data)),
        getOnePosition: (data) => dispatch(actions.getOnePosition(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        setExtraLoadingStatus :(data) => dispatch(actions.setExtraLoadingStatus(data))
    }
};

const searchEmplist = connect(
    mapStateToProps,
    mapDispatchToProps,
)(SearchEmpList);

export default searchEmplist;
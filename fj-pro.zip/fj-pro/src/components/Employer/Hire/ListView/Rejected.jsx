import React from "react";
import { connect } from 'react-redux'
import { Link } from "react-router-dom";

class SearchEmpList extends React.Component{
    constructor(props) {
        super(props)
    }

    componentDidMount() {

    };

    render() {
        return(
            <div className="row job-list">
            {
                this.props.rejectedList &&
                this.props.rejectedList.map((i, k) => {
                    return (
                        <div className="col-12" key = {k}>
                        <div className="job-snippet">
                        <Link className="img-wrap"
                        to =  {`view-profile/${i.id}/${i.employee. id}/rejected`}
                        >
                        <img className="img-fluid" 
                            alt="img" 
                            src={
                                !i.profile_url 
                                || i.profile_url === "null"
                                ||i.profile_url === null
                                ? process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                :i.profile_url
                            } 
                            
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                            />
                            {/* <span className="date badge">Thu 16 - Sun 20</span> */}
                        </Link>
                        <div className="r-job-item">
                            <div className="dropdown more">
                            <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="/assets/images/app/more-btn.svg" />
                            </button>
                            <div className="dropdown-menu" aria-labelledby="more-menu">
                                <ul className="list-unstyled">
                                    <li><Link to = {`view-profile/${i.id}/${i.employee. id}/rejected`}>
                                        View Profile
                                        </Link></li>
                                    {/* <li><a href="javascript:;">Shortlist</a></li>
                                    <li><a href="javascript:;">Schedule Interview</a></li>
                                    <li><a href="javascript:;" className="red">Reject</a></li> */}
                                </ul>
                            </div>
                            </div>
                            <Link className="row"
                            to =  {`view-profile/${i.id}/${i.employee. id}/rejected`}
                            style = {{
                                textDecoration:'none'
                              }}
                            >
                            <div className="col-md-3">
                                {/* <span className="date badge d-inline-block d-lg-none">Thu 16 - Sun 20</span> */}
                                <h6>{i.employee && i.employee.name}</h6>
                                <span className="job-type text-truncate">
                                    {i.job && i.job.job_position}
                                </span>
                                <span className="location text-truncate d-block">
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job && i.job.job_location}
                                </span>
                                <p className="text-truncate">{i.job &&
                                i.job.job_type
                                } | {i.job && i.job.job_title}</p>
                            </div>
                            <div className="col-md-7 btn-wrap invisible">
                                <button className="btn btn-gray-light">
                                Total no of Vacancies
                                <span>28</span>
                                </button>
                                <button className="btn btn-gray-light">
                                Total Jobs Filled
                                <span>5</span>
                                </button>
                                <button className="btn btn-gray-light">
                                Active Vacancies
                                <span>2</span>
                                </button>
                                <button className="btn btn-gray-light" data-toggle="modal" data-target="#views-modal">
                                Total No of Views
                                <span>340</span>
                                </button>
                                <button data-toggle="modal" data-target="#applicants-modal" className="btn btn-gray-light">
                                No of Applicants
                                <span>30</span>
                                </button>
                                <button className="btn btn-gray-light" data-toggle="modal" data-target="#shortlist-modal">
                                No of Shortlisted
                                <span>20</span>
                                </button>
                            </div>
                            {/* <div className="col-md-2">
                                <p className="expire">Job Expires in 10 days</p>
                            </div> */}
                            </Link>
                        </div>
                        </div>
                    </div>
                    )
                })
            }
            </div>

        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        rejectedList:state.Hire.rejectedList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        
    }
};

const searchEmplist = connect(
    mapStateToProps,
    mapDispatchToProps,
)(SearchEmpList);

export default searchEmplist;
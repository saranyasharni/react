import React from "react";
import { connect } from 'react-redux'
import * as actions from '../../../../actions/Employer/Hire';
import { Link } from "react-router-dom";
import HireModal from '../Models/HireCandidate';
import ContractModel from '../Models/ContractModel';
import Notify from "../../../NotifyEmployer"
class SearchEmpList extends React.Component{
    constructor(props) {
        super(props)
        this.state = {
            job_id : '',
            employee_id:'',
            status_code:''
        }

    }

    componentDidMount() {

    };

    render() {
        return(
            <div className="row job-list">
                {
                    this.props.scheduleList &&
                    this.props.scheduleList.map((i, k) => {
                    return (<div className="col-12" key = {k}>
                    <div className="job-snippet">
                    <Link className="img-wrap"
                    to = {`view-profile/schedule/${i.id}/${i.job_application.employee.id}`}
                    >
                    <img className="img-fluid" 
                        alt="img" 
                        src={
                            i.job_application &&
                            i.job_application.employee && 
                            i.job_application.employee.profile_url &&
                            i.job_application.employee.profile_url !== "null" ?
                            i.job_application.employee.profile_url : 
                            process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                        } 
                        
                        // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                        />
                        {/* <span className="date badge">Thu 16 - Sun 20</span> */}
                    </Link>
                    <div className="r-job-item">
                        <div className="dropdown more">
                        <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="/assets/images/app/more-btn.svg" />
                        </button>
                        <div className="dropdown-menu" aria-labelledby="more-menu">
                            <ul className="list-unstyled">
                                <li>  <Link
                                to = {`view-profile/schedule/${i.id}/${i.job_application.employee.id}`}
                                >View Profile</Link></li>
                                <li><a href="javascript:;"
                                onClick = {() => {
                                    if (localStorage.notify_employer_model === "1") {
                                        window.$('#notify-employer-model').modal('show')
                                    } else {
                                    this.props.hireCandidateModal(true)
                                    this.setState({
                                        employee_id:i.job_application.employee.id,
                                        job_id:i.job_application.job.id,
                                        status_code:3
                                    });
                                    this.props.getCandidateDetails({
                                        job_id:i.job_application.job.id,
                                        employee_id : i.job_application.employee.id
                                    })     }    
                                    // this.props.hireEmployee({
                                    //     employee_id:i.job_application.employee.id,
                                    //     job_id:i.job_application.job.id,
                                    //     status_code:3
                                    // })    
                                }}
                                >Hire Candidate</a></li>
                                <li><a href="javascript:;" className="red"
                                onClick = {() => {
                                    this.props.rejectCandidate({
                                        application_id:i.job_application.id,
                                        status_code:9
                                    })
                                }}
                                >Reject Candidate</a></li>
                            </ul>
                        </div>
                        </div>
                        <Link className="row"
                        to = {`view-profile/schedule/${i.id}/${i.job_application.employee.id}`}
                        style = {{
                            textDecoration:'none'
                          }}
                        >
                        <div className="col-md-3">
                            {/* <span className="date badge d-inline-block d-lg-none">Thu 16 - Sun 20</span> */}
                            <h6>{i.job_application &&
                            i.job_application.employee &&
                            i.job_application.employee.name
                            }</h6>
                            <span className="job-type text-truncate">{
                                i.job_application &&
                                i.job_application.job &&
                                i.job_application.job.industry_type
                            }</span>
                            <span className="location text-truncate d-block">
                            <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                            {
                                i.job_application &&
                                i.job_application.job &&
                                i.job_application.job.job_location
                            }
                            </span>
                            <p className="text-truncate">{i.job_application &&
                                i.job_application.job &&
                                i.job_application.job.job_type} | {
                                i.job_application &&
                                i.job_application.job &&
                                i.job_application.job.job_position
                                }</p>
                        </div>
                        <div className="col-md-7 btn-wrap invisible">
                            <button className="btn btn-gray-light">
                            Total no of Vacancies
                            <span>28</span>
                            </button>
                            <button className="btn btn-gray-light">
                            Total Jobs Filled
                            <span>5</span>
                            </button>
                            <button className="btn btn-gray-light">
                            Active Vacancies
                            <span>2</span>
                            </button>
                            <button className="btn btn-gray-light" data-toggle="modal" data-target="#views-modal">
                            Total No of Views
                            <span>340</span>
                            </button>
                            <button data-toggle="modal" data-target="#applicants-modal" className="btn btn-gray-light">
                            No of Applicants
                            <span>30</span>
                            </button>
                            <button className="btn btn-gray-light" data-toggle="modal" data-target="#shortlist-modal">
                            No of Shortlisted
                            <span>20</span>
                            </button>
                        </div>
                        {/* <div className="col-md-2">
                            <p className="expire">Job Expires in 10 days</p>
                        </div> */}
                        </Link>
                    </div>
                    </div>
                </div>

                        )
                    })
                    
                }
                <Notify/>
             <HireModal
        scheduledInfo = {this.state}
        />
        <ContractModel
         scheduledInfo = {this.state}
        />
            
            </div>

        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        scheduleList:state.Hire.scheduleList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        rejectCandidate : (data) => dispatch(actions.rejectCandidate(data)),
        hireEmployee: (data) => dispatch(actions.hireEmployee(data)),
        hireCandidateModal : data => dispatch(actions.hireCandidateModal(data)),
        getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data)),
    }
};

const searchEmplist = connect(
    mapStateToProps,
    mapDispatchToProps,
)(SearchEmpList);

export default searchEmplist;
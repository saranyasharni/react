import React from "react";
import { connect } from 'react-redux'
import * as actions from '../../../../actions/Employer/Hire';
import { Link } from "react-router-dom";
import Notify from "../../../NotifyEmployer";
import ShortListModel from "../ShortListModel";

class SearchEmpList extends React.Component{
    constructor(props) {
        super(props)
    }

    componentDidMount() {

    };

    render() {
        return(
            <div className="row job-list">
            {
                this.props.employeeLists &&
                this.props.employeeLists.map((i, k) => {
                    return (
                        <div className="col-12" key = {k}>
                        <div className="job-snippet">
                        <Link className="img-wrap"
                        to = {`view-profile/${i.id}/${i.employee.id}/applicants`}
                        >
                        <img className="img-fluid" 
                            src={!i.employee.profile_url 
                                || i.employee.profile_url === "null"
                                || i.employee.profile_url === null
                                ? process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"
                                 :i.employee.profile_url
                            } 
                            // alt="img" 
                            // src="/assets/images/app/avatar-thumb-1.jpg" alt="img" 
                        />
                            {/* <span className="date badge">Thu 16 - Sun 20</span> */}
                        </Link>
                        <div className="r-job-item">
                            <div className="dropdown more">
                            <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="/assets/images/app/more-btn.svg" />
                            </button>
                            <div className="dropdown-menu" aria-labelledby="more-menu">
                                <ul className="list-unstyled">
                                <li><Link to = {`view-profile/${i.id}/${i.employee.id}/applicants`}>View Profile</Link></li>
                                <li><a href="javascript:;"
                                onClick = {() => {
                                    if (localStorage.notify_employer_model === "1") {
                                        window.$('#notify-employer-model').modal('show')
                                    } else {
                                        this.props.hireCandidateModal(true, true, i.id, i.employee.profile_url)
                                        this.props.getCandidateDetails({
                                            job_id:i.job.id,
                                            employee_id : i.employee.id
                                        });         
                                    }
                                }
                                }
                                >Hire</a></li>
                                <li><a href="javascript:;"
                                onClick = {() => {
                                    this.props.shortListEmployee({
                                        employee_id:i.employee.id,
                                        job_id:i.job.id,
                                        application_id:i.id,                
                                        status_code: 2,
                                        request : 0
                                    })
                                }
                                }
                                >Shortlist</a></li>
                                <li><a href="javascript:;"
                                onClick = {() => {
                                    this.props.setShortListModel({
                                        application_id: 'null',
                                        employee_id: i.employee.id,
                                        job_id : null,
                                        show:true,
                                        status_code: 2,
                                        show_status: 'show',
                                        request : 1
                                    });
                                }
                                }
                                >Reshortlist</a></li>
                                <li><a href="javascript:;"
                                 onClick = {() => {
                                    // this.props.setShowModel(true);
                                    this.props.setShowModel({
                                        employee_id : i.employee.id,
                                        application_id : i.id,
                                        show: true,
                                        job_id : i.job.id,
                                        show_status: 'hide',
                                        request:0
                                    });
                                }}
                                >Schedule Interview</a></li>
                                <li><a href="javascript:;" className="red"
                                onClick = {(e) => {
                                    this.props.rejectCandidate({
                                        application_id:i.id,
                                        status_code:9
                                    })
                                    // this.props.declineEmployee({
                                    //     id : i.id
                                    // })
                                }}
                                >Reject</a></li>
                                </ul>
                            </div>
                            </div>
                            <Link className="row"
                            to = {`view-profile/${i.id}/${i.employee.id}/applicants`}
                            style = {{
                                textDecoration:'none'
                            }}
                            >
                            <div className="col-md-3">
                                {/* <span className="date badge d-inline-block d-lg-none">Thu 16 - Sun 20</span> */}
                                <h6>{i.employee && i.employee.name}</h6>
                                <span className="job-type text-truncate">
                                    {i.job && i.job.job_position}
                                </span>
                                <span className="location text-truncate d-block">
                                <img src="/assets/images/app/location-pin-icon.svg" alt="icon" />
                                {i.job && i.job.job_location}
                                </span>
                                <p className="text-truncate">{i.job &&
                                i.job.job_type
                                } | {i.job && i.job.job_title}</p>
                            </div>
                            <div className="col-md-7 btn-wrap invisible">
                                <button className="btn btn-gray-light">
                                Total no of Vacancies
                                <span>28</span>
                                </button>
                                <button className="btn btn-gray-light">
                                Total Jobs Filled
                                <span>5</span>
                                </button>
                                <button className="btn btn-gray-light">
                                Active Vacancies
                                <span>2</span>
                                </button>
                                <button className="btn btn-gray-light" data-toggle="modal" data-target="#views-modal">
                                Total No of Views
                                <span>340</span>
                                </button>
                                <button data-toggle="modal" data-target="#applicants-modal" className="btn btn-gray-light">
                                No of Applicants
                                <span>30</span>
                                </button>
                                <button className="btn btn-gray-light" data-toggle="modal" data-target="#shortlist-modal">
                                No of Shortlisted
                                <span>20</span>
                                </button>
                            </div>
                            {/* <div className="col-md-2">
                                <p className="expire">Job Expires in 10 days</p>
                            </div> */}
                            </Link>
                        </div>
                        </div>
                    </div>
                    )
                })
            }
            <ShortListModel/>
            <Notify/>
          
            </div>

        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        employeeLists:state.Hire.employeeLists,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        hireCandidateModal : (data, show, emp_id, profile_url) => 
        dispatch(actions.hireCandidateModal(data, show, emp_id, profile_url)),
        shortListEmployee: (data) => dispatch(actions.shortListEmployee(data)),
        declineEmployee: (data) => dispatch(actions.declineEmployee(data)),
        setShowModel: (data) => dispatch(actions.setShowModel(data)),
        rejectCandidate : (data) => dispatch(actions.rejectCandidate(data)),
        getCandidateDetails : (data) => dispatch(actions.getCandidateDetails(data)),
        setShortListModel: (data) => dispatch(actions.setShortListModel(data))
    }
};

const searchEmplist = connect(
    mapStateToProps,
    mapDispatchToProps,
)(SearchEmpList);

export default searchEmplist;
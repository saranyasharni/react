import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../actions/Employer/Hire";
import $ from 'jquery';

function PaymentModel(props) {
    return (
    <div className="container-fluid">
        {/* Main Content Starts here */}
        <section className="row main-content">
            <div className="container payment-container py-3 py-md-5">
            <div className="snippet-box my-2">
                <h2>Payment</h2>
                <div className="payment-detail">
                <p className="lead">Payment Detail</p>
                <table className="border-0 mb-4 mb-md-5">
                    <tbody><tr>
                        <td>Total Salary Pay</td>
                        <td>RM 100</td>
                    </tr>
                    <tr>
                        <td>FlexJobs Fee</td>
                        <td>RM 10</td>
                    </tr>
                    <tr>
                        <td>Total</td>
                        <td>RM 110</td>
                    </tr>
                    </tbody></table>
                <p className="lead">Payment Method</p>
                <div className="method-snippet mt-1 mb-2">
                    <input type="radio" name="cc" className="form-control radio" />
                    <div className="ms-cont">
                    <p className="f-500">Credit Card</p>
                    <p className="mb-0">Pay with Visa, MasterCard, Maestro, and many other credit and debit cards</p>
                    </div>
                    <div className="ms-icon">
                    <img src="images/app/visa.png" alt="icon" />
                    <img src="images/app/master-card.png" alt="icon" />
                    <img src="images/app/mastero.png" alt="icon" />
                    </div>
                </div>
                <div className="method-snippet">
                    <input type="radio" name="cc" className="form-control radio" />
                    <div className="ms-cont">
                    <p className="f-500">PayNow</p>
                    <p className="mb-0">Pay via PayNow for a quick and easy transaction</p>
                    </div>
                </div>
                </div>
                <div className="col-12 text-right pr-0 mt-3">
                <button className="btn btn-sm">Cancel</button>
                <button className="btn btn-blue">Confirm Pay</button>
                </div>
            </div>
            </div>
        </section>
        {/* Main Content Ends here */}
    </div>

    )
};

const mapStateToProps = (state, ownProps) => {
    return {
        modelPaymentShow: state.Hire.modelPaymentShow,
        
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        setPaymentModel: (data) => dispatch(actions.setPaymentModel(data)),
        
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentModel);
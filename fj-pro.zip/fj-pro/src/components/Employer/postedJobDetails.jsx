import React, { useEffect } from "react";
import Header from "./header";
import Head from "../EmployerMainPages/postedJobs";
import ShortList from "./Modals/shortListModel";
import Views from "./Modals/viewsModel";
import Applicant from "./Modals/applicantModel";
import { connect } from 'react-redux';
import { PostedJob,postedJobDetail,View,Shortlisted,ApplicantList,ClosedJob } from "../../actions/EmployerPostedJob";
import { Link } from "react-router-dom";
import moment from 'moment';
// import history from "../../../stores/history"

function JobDetails(props) {
  useEffect(() => {
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    // const elem2 = document.createElement("link");
    // elem2.rel = "stylesheet"
    // elem2.type = "text/css"
    // elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    // elem2.id = "design_app_style"
    // elem2.async = true;
    // document.head.appendChild(elem2);
    let job_id = props.job_id ? props.job_id :window.location.pathname.split('/')[2]
    props.detailsCall(job_id);
  }, []);
  
  return (
    <div>
    <div className="container-fluid">
    {/* header Starts here */}
    <Header />
    {/* header Ends here */}
    {/* Main Content Starts here */}
    <section className="row main-content">
      <div className="container">
        <div className="row">
          <div className="col-12 hdr-row">
            <h1>
              <a href="javascript:;"
               onClick={() => window.history.back()}
                className="back n__back-button">
                <img src="/assets/images/app/back-arrow.svg"  alt="icon" /><span>Back</span>
              </a>
            </h1>
            <div>
            <Link to =  {`/edit/job-post/${!props.job_id ? window.location.pathname.split('/')[2]: props.job_id}`}
            >
              <button className="btn btn-gray mr-2">Edit</button>
              </Link>
              <a href="hire-posted-job-grid.html" className="btn btn-red" onClick={()=>{props.closedListCall({
                job_id :props.job_id,
                status_code : "2" 
              })}} >Delete Job</a>
            </div>
          </div>
          {props.get_details.map((det, k)=>{
            let start = moment(det.start_date+' '+ det.start_time)
            let end = moment(det.end_date+' '+ det.end_time)
            const hours = (end.diff(start, 'hours'))
            const days = (end.diff(start, 'days'))
            const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
            const firstDate = new Date(det.start_date);
            const secondDate = new Date(det.end_date);
            
            const diffDays = Math.round(Math.abs((firstDate - secondDate) / oneDay))
            let start_date = moment(start).format("ddd Do MMM,YYYY,h:mm a");
            let end_date = moment(end).format("ddd Do MMM,YYYY,h:mm a");
            return(
            <div className="col-12 mb-5" key = {k}>
            <div className="snippet-box p-4 job-detail">
              <div className="row">
                <div className="col-md-4 lft-col">
                  <div className="img-wrap">
                    <img className="img-fluid" src={localStorage.getItem('profile_url') !== 'null' ? localStorage.getItem('profile_url') :
                    process.env.PUBLIC_URL+"/assets/images/app/profile-horizontal.png"}
                    alt="image" />
                  </div>
                  <div className="btn-wrap">
                    <button className="btn btn-gray-light">
                      <small>Total no of Vacancies</small>
                      <span>{det.job_stat_information.total_vacancies}</span>
                    </button>
                    <button className="btn btn-gray-light">
                      <small>Total Jobs Filled</small>
                      <span>{det.job_stat_information.jobs_filled}</span>
                    </button>
                    <button className="btn btn-gray-light">
                      <small>Active Vacancies</small>
                      <span>{det.job_stat_information.active_vacancies}</span>
                    </button>
                    <button className="btn btn-gray-light" onClick={()=>{props.setFieldValues("views_show",true)
                  props.showViewers(det.id)}}>
                      <small>Total No of Views</small>
                      <span>{det.job_stat_information.total_views}</span>
                    </button>
                    <button className="btn btn-gray-light" onClick={()=>{props.setFieldValues("applicant_show",true)
                   props.showApplicant(det.id)}}>
                      <small>No of Applicants</small>
                      <span>{det.job_stat_information.job_applicants}</span>
                    </button>
                    <button className="btn btn-gray-light" onClick={()=>{props.setFieldValues("shortlist_show",true)
                  props.showShortList(det.id)}}>
                      <small>Shortlisted</small>
                      <span>{det.job_stat_information.shortlisted}</span>
                    </button>
                  </div>
                </div>
                <div className="col-md-8 rgt-col">
                  <h2>{det.industry_type}</h2>
                  <span className="designation">
                    {det.job_title}/ {det.job_position}
                    <small>{det.job_locations}</small>
                  </span>
                  <p className="lead">{det.job_description}</p>
                  <div className="row job-desc">
                    <div className="col-lg-6 col-md-12">
                      <div className="row mb-2">
                        <div className="col-md-5">
                          <p>Job Type</p>
                        </div>
                        <div className="col-md-7">
                          <span>{det.job_type}</span>
                        </div>
                      </div>
                      <div className="row mb-2">
                        <div className="col-md-5">
                          <p>Start On</p>
                        </div>
                        <div className="col-md-7">
                          <span>{start_date}</span>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-6 col-md-12">
                      <div className="row mb-2">
                        <div className="col-md-5">
                          <p>Salary Based</p>
                        </div>
                        <div className="col-md-7">
                          <span>{det.salary_based}</span>
                        </div>
                      </div>
                      <div className="row mb-2">
                        <div className="col-md-5">
                          <p>End On</p>
                        </div>
                        <div className="col-md-7">
                          <span>{end_date}</span>
                        </div>
                      </div>
                    </div>
                    <div className="col-xl-6 col-lg-12 mt-5">
                      <div className="row mb-3">
                        <h4 className="col-12">Salary Calculation</h4>
                        <div className="col-md-5">
                          <p>{det.salary_based === 'per-hour'? 'Per Hour'
                          : det.salary_based === 'per-day'? 'Per Day'
                          : det.salary_based === 'per-month'? 'Per Month'
                          : det.salary_based === 'per-week'? 'Per Week':'Hourly Rate'
                          }</p>
                        </div>
                        <div className="col-md-7">
                          <span>{det.currency} {
                            new Intl.NumberFormat('en-US', 
                            {style: 'decimal', minimumFractionDigits: 2}).
                            format(isNaN(det.amount)
                            ? '0.00':det.amount)
                          }</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Number of Hours</p>
                        </div>
                        <div className="col-md-7">
                          <span>{det.number_of_hours} {det.number_of_hours === "1" ? 'Hr':'Hrs'}</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Number of Days 
                            
                          </p>
                        </div>
                        <div className="col-md-7">
                          <span>{diffDays}</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Total Salary</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{
                            det.job_salaries && 
                            det.job_salaries.length > 0 &&
                            new Intl.NumberFormat('en-US', 
                            {style: 'decimal', minimumFractionDigits: 2}).
                            format(isNaN(det.job_salaries[1].total_salary_base_by_employer)
                            ? '0.00':det.job_salaries[1].total_salary_base_by_employer)
                            }</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>EPF {det.amount <= 5000 ? "(13%)" : "(12%)"}</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM
                            {det.job_salaries && 
                          det.job_salaries.length > 0 &&
                          new Intl.NumberFormat('en-US', 
                            {style: 'decimal', minimumFractionDigits: 2}).
                            format(isNaN(det.job_salaries[1].employer_epf)
                            ? '0.00':det.job_salaries[1].employer_epf)
                          
                          }</span>
                        </div>
                      </div>

                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Socso (1.75%)</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{det.job_salaries && 
                          det.job_salaries.length > 0 &&
                          new Intl.NumberFormat('en-US', 
                            {style: 'decimal', minimumFractionDigits: 2}).
                            format(isNaN(det.job_salaries[1].employer_socso)
                            ? '0.00':det.job_salaries[1].employer_socso)
                          
                          }</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>EIS (0.2%)</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{
                            det.job_salaries && 
                            det.job_salaries.length > 0 &&
                            new Intl.NumberFormat('en-US', 
                            {style: 'decimal', minimumFractionDigits: 2}).
                            format(isNaN(det.job_salaries[1].employer_eis)
                            ? '0.00':det.job_salaries[1].employer_eis)
                            }</span>
                        </div>
                      </div>
                     
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Total Cost</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{
                            det.job_salaries && 
                            det.job_salaries.length > 0 &&
                            new Intl.NumberFormat('en-US', 
                            {style: 'decimal', minimumFractionDigits: 2}).
                            format(isNaN(det.job_salaries[1].actual_salary_paid_by_employer)
                            ? '0.00':det.job_salaries[1].actual_salary_paid_by_employer)
                            }</span>
                        </div>
                      </div>
                    </div>
                    {/* <div className="col-xl-6 col-lg-12 mt-5">
                      <div className="row mb-3">
                        <h4 className="col-12">Salary for above 60</h4>
                        <div className="col-md-5">
                        <p>{det.salary_based === 'per-hour'? 'Per Hour'
                          : det.salary_based === 'per-day'? 'Per Day'
                          : det.salary_based === 'per-month'? 'Per Month'
                          : det.salary_based === 'per-week'? 'Per Week':'Hourly Rate'
                          }</p>
                        </div>
                        <div className="col-md-7">
                          <span>{det.currency} {det.amount}</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Number of Hours</p>
                        </div>
                        <div className="col-md-7">
                          <span>{det.number_of_hours} {det.number_of_hours === "1" ? 'Hr':'Hrs'}</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Number of Days 
                            
                          </p>
                        </div>
                        <div className="col-md-7">
                          <span>{diffDays}</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>EPF (4%)</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{
                             det.job_salaries && 
                             det.job_salaries.length > 0 &&
                             new Intl.NumberFormat('en-US', 
                             {style: 'decimal'}).
                             format(isNaN(det.job_salaries[0].employer_epf)
                             ? '0.00':det.job_salaries[0].employer_epf)
                             
                             }</span>
                        </div>
                      </div>

                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>Socso (0%)</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{
                            det.job_salaries && 
                            det.job_salaries.length > 0 &&
                            new Intl.NumberFormat('en-US', 
                             {style: 'decimal'}).
                             format(isNaN(det.job_salaries[0].employer_socso)
                             ? '0.00':det.job_salaries[0].employer_socso)
                            }</span>
                        </div>
                      </div>
                      <div className="row mb-3">
                        <div className="col-md-5">
                          <p>EIS (0%)</p>
                        </div>
                        <div className="col-md-7">
                          <span>RM{
                            det.job_salaries && 
                            det.job_salaries.length > 0 &&
                            new Intl.NumberFormat('en-US', 
                            {style: 'decimal'}).
                            format(isNaN(det.job_salaries[0].employer_eis)
                            ? '0.00':det.job_salaries[0].employer_eis)
                            }</span>
                        </div>
                      </div>
                    </div> */}
                    {/* <div className="col-md-12">
                      <div className="row total-cost">
                        <div className="col-lg-6 col-md-12">
                          <div className="row">
                            <p className="col-md-4">Total Cost</p>
                            <span className="col-md-8">RM141.60</span>
                          </div>
                        </div>
                      </div>
                    </div> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
          )})}
        </div>
      </div>
    </section>
    {/* Main Content Ends here */}
  </div>
  {/* Main Wrapper Ends here */}
  {/* Modal Wrapper Starts here */}
  <ShortList />
        <Views />
        <Applicant />
  {/* Modal Wrapper Ends here */}
  {/* Script Starts here */}
  {/* Script Ends here */}
</div>
  )};


  const mapStateToProps = (state, ownProps) => {
    return {
      job_list: state.Postedjob.job_list,
      get_details:state.Postedjob.get_details,
      job_id:state.Postedjob.job_id,
        // categories: state.Home.categories
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(PostedJob(f, v)),
        detailsCall: (id) => dispatch(postedJobDetail(id)),
        showApplicant:(id)=>dispatch(ApplicantList(id)),
      showShortList:(id)=>dispatch(Shortlisted(id)),
      showViewers:(id)=>dispatch(View(id)),
      closedListCall: (id) => dispatch(ClosedJob(id)),
    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(JobDetails);
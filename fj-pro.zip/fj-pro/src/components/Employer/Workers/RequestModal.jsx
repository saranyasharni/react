import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from "../../../actions/Employer/Workers";
import $ from 'jquery';

function ShortListModel(props) {
    const [state, setState] = useState({
        extraHours : '',
        extraDays : '',
        start_time : '',
        end_time:'',
        extend_type:'work',
        start_date:'',
        extended_day:'',
        // start_date:moment(new Date()).format('MM/DD/YYYY'),
        end_date:'',
        amount:'',
        errors:{}
    })
    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
            $(document).ready(function () {
                window.$(".start_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                setState({
                    ...state,
                    start_date: e.target.value
                });  
            }});
            window.$(".end_date_work1")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                setState({
                    ...state,
                    end_date: e.target.value
                });  
            }});
            window.$(".extend_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                setState({
                    ...state,
                    extended_day: e.target.value,
                    // start_date : e.target.value,
                    // end_date :e.target.value
                });  
            }});
            })
    
    })
    }, []);

    useEffect(() => {
        // require("../../../assets/css/app-style.css");
        $(document).ready(function () {
      
            $(document).ready(function () {
                window.$(".start_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                setState({
                    ...state,
                    start_date: e.target.value
                });  
            }});
            window.$(".end_date_work1")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                setState({
                    ...state,
                    end_date: e.target.value
                });  
            }});
            window.$(".extend_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                setState({
                    ...state,
                    extended_day: e.target.value,
                    // start_date : e.target.value,
                    // end_date :e.target.value
                });  
            }});
            })
    
        })
        if (props.request_status === 1) {
            $("#extend-request-modal .alert").html(
                `<strong>Success!</strong> Request send sucessfully.`
            );
            $("#extend-request-modal .alert")
                .removeClass("alert-danger")
                .addClass("alert-success");
            setTimeout(function () {
                $("#extend-request-modal .alert").removeClass("alert-success");
                $("#extend-request-modal .alert").html("");
                
                props.setRequestModal(false)
                props.setValues('request_status', 0);
            }, 3000);
              
        } else if (props.request_status === 2) {
            $("#extend-request-modal .alert").html(
                `<strong>Sorry!</strong> . Please try again later`
            );
            $("#extend-request-modal .alert")
                .removeClass("alert-success")
                .addClass("alert-danger");
            setTimeout(function () {
                $("#extend-request-modal .alert").removeClass("alert-danger");
                $("#extend-request-modal .alert").html("");
                
                props.setValues('request_status', 0);
            }, 3000);
        }
    });

    
    const updateErrors = errors => {
        setState({
          ...state, 
          errors: { ...state.errors, ...errors }
        });
    };

    const validation = async (e) => {
        let errors = state.errors;
        let valid = true;

        if (state.extend_type === 'work') {
            if (state.extended_day === '') {
                errors.extended_day = 'Cannot be empty'
                updateErrors(errors);
                valid = false;
            }
            
        }
        if (state.extend_type === 'job') {
            if (state.start_date === '') {
                errors.start_date = 'Cannot be empty'
                updateErrors(errors);
                valid = false;
            }
            if (state.end_date === '') {
                errors.end_date = 'Cannot be empty'
                updateErrors(errors);
                valid = false;
            }
        }
        if (state.start_time === "") {
            errors.start_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }
        if (state.end_time === "") {
            errors.end_time = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }
        if (state.amount === "") {
            errors.amount = 'Cannot be empty'
            updateErrors(errors);
            valid = false;
        }
        updateErrors(errors);
        return valid;
    } 

    const submitRequest = async(e) => {
        // console.log(state.errors, 'state.errors')
        e.preventDefault();
        const result = await validation();
       
        if (result) {
            console.log(state.extended_day, 'state.extended_day')
            props.sendExtendRequest({
                employee_id:props.employeeId && props.employeeId,
                employer_id:localStorage.getItem('emp_id'),
                work_id:props.work_id && props.work_id,
                extension_date:state.extended_day !== '' ? state.extended_day : null,
                start_date:state.start_date !== '' ? state.start_date : null,
                end_date:state.end_date !== '' ? state.end_date : null,
                start_time:state.start_time,
                end_time:state.end_time,
                number_of_hours:null,
                amount:state.amount,
                extend_current_day:state.extend_type === 'work' ? 1 : 0
            })
        } 
    }
    
    return (
    <Modal 
    show={props.requestModal} 
    id="extend-request-modal" tabIndex={-1}
    className="modal fade custom-modal"
            // style={{ "paddingRight": 17 }} 
    onHide={() => props.setRequestModal(false)}
    role="dialog" 
    aria-hidden="true"
    centered 
    >
    
    <div className="modal-content">
      <div className="modal-header">
         
        <h5 className="mt-2 modal-title w-100 justify-content-center">Request Candidate</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close"
        onClick={() => props.setRequestModal(false)}
        >
          <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3">
        <div className="row">
            <form className="form-section col-md-12">
            <div className="alert" role="alert">  </div>
            <div className="form-group mb-1">
                    <label>Work Extend Type</label>
                    <div className="col-12 p-0">
                    <label className="input">
                        <input type="radio" name="work"
                        value = "work"
                        checked = {state.extend_type === 'work'}
                        onChange={() => {
                            setState({
                                ...state,
                                extend_type : 'work'
                            })
                        }}
                         />
                        Extend Work
                    </label>
                    <span className="radio-cont">Your work will be extened to the selected day or today from the end of the work. You can extend only one day</span>
                    </div>
                    <div className="col-12 p-0">
                    <label className="input">
                        <input type="radio" name="job" 
                        value = "job"
                        checked = {state.extend_type === 'job'}
                        onChange={() => {
                            setState({
                                ...state,
                                extend_type : 'job'
                            })
                        }}
                        />
                        Extend Job
                    </label>
                    <span className="radio-cont">Your job days will be extened to the selected days from the end of the job. You can extend more than one day</span>
                    </div>
                </div>
                
                <div className={`row ${state.extend_type === 'work' ? 'd-block':'d-none'}`} >
                <div className="col-md-12 form-group mb-1">
                    <label>Date to extend</label>
                    <div className="input-group date extend_date_work mar-t-no" data-date-format="mm/dd/yyyy">
                        <input type="text" className="form-control" 
                        value = {state.extended_day}
                        />

                        <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div>
                    {state.errors.extended_day &&
                        state.errors.extended_day.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.extended_day}
                        </small>
                        ) : (
                        ""
                    )} 
                </div>
                </div>
                <div className={`row ${state.extend_type === 'job' ? '':'d-none'}`} >
                <div className="col-md-6 form-group mb-1">
                    <label>Start Date</label>
                    <div className="input-group date start_date_work mar-t-no" data-date-format="mm/dd/yyyy">
                        <input type="text" className="form-control" 
                        value = {state.start_date}
                        />

                        <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div>
                    {state.errors.start_date &&
                        state.errors.start_date.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.start_date}
                        </small>
                        ) : (
                        ""
                    )}        
                </div>
                <div className="col-md-6 form-group">
                    <label>End Date</label>
                    <div className="input-group date end_date_work1 mar-t-no" data-date-format="mm/dd/yyyy">
                        <input type="text" className="form-control" 
                        value = {state.end_date}
                        />

                        <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div>
                    {state.errors.end_date &&
                        state.errors.end_date.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.end_date}
                        </small>
                        ) : (
                        ""
                    )} 
                </div>
                </div>
                    <div className="row">
                    <div className="col-md-6 form-group mb-1">
                    <label>Start Time</label>
                   
                        <input type="time" className="form-control" 
                        value = {state && state.start_time}
                        onChange = {(e) => { {
                            // calculateExtraSalary(e.target.value,state.end_time,state.amount);
                            
                            setState({
                                ...state,
                                start_time:e.target.value
                            });

                        }}}
                        />
                         {state.errors.start_time &&
                        state.errors.start_time.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.start_time}
                        </small>
                        ) : (
                        ""
                    )}        
            
                    </div>
                    <div className="col-md-6 form-group">
                        <label>End Time</label>
                        
                        <input type="time" className="form-control" 
                        value = {state && state.end_time}
                        onChange = {(e) =>{ {
                            // calculateExtraSalary(state.start_time,e.target.value,state.amount);
                            setState({
                                ...state,
                                end_time:e.target.value
                            });

                        }}}
                        />
                        {state.errors.end_time &&
                        state.errors.end_time.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.end_time}
                        </small>
                        ) : (
                        ""
                        )}        
                    </div>
                   
                    <div className="col-md-6 form-group">
                        <label>Currency</label>
                        <input type="text" 
                        name  = "currency"
                        className="form-control" 
                        value="RM"
                        readOnly 
                        style = {{
                            background:'none',
                            cursor: 'not-allowed'
                        }}
                        />

                    </div>
                    <div className="col-md-6 form-group">
                        <label>Amount</label>
                        <input type="text" className="form-control" 
                        name = "amount"
                        value = {state && state.amount}
                        onChange = {(e) =>{ {
                            // calculateExtraSalary(state.start_time,state.end_time,e.target.value);
                            setState({
                                ...state,
                                amount:e.target.value
                            });
                            // if (e.target.value.length > 1) {
                            
                            // }
                        }
                        }}
                        placeholder={100} />
                        {state.errors.amount &&
                        state.errors.amount.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.amount}
                        </small>
                        ) : (
                        ""
                    )}        
                    </div>
                    </div>
            </form>
        </div>
        <div className="row mt-2 mb-3">
          <div className="col-md-12 text-right"
          >
            <button className="btn btn-blue"
             disabled = {props.btnLoading ? true:false}
            onClick={
                    submitRequest
                // console.log(state.start_time, 'state.start_time');
                // console.log(state.end_time, 'state.start_time');
                // console.log(state.date, 'state.date')
            } 
            >{props.btnLoading ? 'Loading...':'Request'}</button>
          </div>
        </div>
      </div>
    </div>
  
</Modal>

)
};

const mapStateToProps = (state, ownProps) => {
    return {
        requestModal:state.Workers.requestModal,
        request_status: state.Workers.request_status,
        btnLoading:state.Hire.btnLoading,
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setRequestModal : data => dispatch(actions.setRequestModal(data)),
        sendExtendRequest : data => dispatch(actions.sendExtendRequest(data)),
        setValues  : (f,v) => dispatch(actions.setValues(f,v))
        
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ShortListModel);
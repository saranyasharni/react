import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from '../../../actions/Employer/Workers';
import moment from "moment"
import $ from 'jquery'
import CsvDownload from 'react-json-to-csv'

function WorkerAttendance(props) {
    
    const [key, setkey] = useState(0)
    const [state, setState]  = useState({
        filter:0,
        filter_by:null,
        filter_term:null
    })
    useEffect(() => {   
        
        $('#editable').prop('disabled', true)
        // require("../../../assets/css/app-style.css");
    }, []);
    
    return (
        <>
            <form className="custom-form row five-col form-section my-3">
                <div className="form-group col-md-3">
                <label>Search By</label>
                <select className="form-control selectpicker"
                    data-live-search="true"    
                    title = "Choose One"
                    value = {state.filter_by}
                    onChange = {(e) => {
                    setState({
                        ...state,
                        filter_by:e.target.value,
                    })
                    //   this.props.getAllWorkers({
                    //     employer_id:employer_id,
                    //     filter:1,
                    //     filter_by:e.target.value,
                    //     filter_term:this.state.filter_term
                    // })        
                    }}
                    >
                    
                    <option value = "name">Employee Name</option>
                    <option value = "role">Role</option>
                    <option value = "place"> Place</option>
                    <option value = "work_type">Work Type</option>
                    <option value = "work_status">Working Status</option>
                </select>
                </div>
                  <div className="form-group col-md-3">
                  {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
                  <label>Search Term </label>
                  <input className="form-control" 
                  value = {state.filter_term}
                  onChange = {(e) => {
                    setState({
                        ...state,
                        filter_term:e.target.value
                    })
                    props.getAllWorkers({
                      employer_id:localStorage.getItem('emp_id'),
                      filter:1,
                      filter_by:state.filter_by,
                      filter_term:e.target.value
                  }) }}   
                  placeholder = "Ex:manager"
                  ></input>
                  </div>
                  <div className="form-group col-md-3"
                  style = {{
                    marginTop : "30px"
                  }}
                  >
                  {/* <img className="inside-input" src="/assets/images/app/search-icon.svg" alt="icon" /> */}
                  <button type = "button" className="btn btn-blue"
                  onClick = {(e) => {
                    window.jQuery('.form-control').val('');
                    setState({
                      filter:0,
                      filter_by:null,
                      filter_term:null
                    })
                    props.getAllWorkers({
                        employer_id:localStorage.getItem('emp_id'),
                        filter:0,
                        filter_by:null,
                        filter_term:null
                  })}}   
                  >
                    Reset All 
                  </button>
                  
                  </div>
          </form>
        <div className="row">
            <div className="snippet-box1 attend-left">
            {
                
                props.currentWorkers && 
                props.currentWorkers.length > 0 ?
                props.currentWorkers.map((i, k) => {
                    
                    return (
                        <div 
                        className={`emp-snippet ${k === key ?'active' : ''} mb-3`} key = {k}
                        onClick = {() => {
                            setkey(k)
                            props.getLoginReport({
                                employee_id :i.employeeId,
                                job_id : i.jobId
                            });
                            props.setData({
                                
                                employee_id :i.employeeId,
                                job_id : i.jobId
                            })

                        }}
                        >
                        <div className="hire-candidate">
                        <div className="avatar">
                            <img className="img-fluid" src={!i.profile_url ||
                            i.profile_url  === "null"
                            ?
                            "/assets/images/app/avatar-1.png" :
                            i.profile_url
                            
                            } alt="Staff" 
                            style = {{
                               height: "100%"
                            }}
                            />
                        </div>
                        <div className="avatar-detail">
                            <h6>{i.employee_name}</h6>
                            <span>{i.role}</span>
                        </div>
                        </div>
                        <span className="light mt-2">Nissi Fresh Store, {i.place}</span>
                        <span className="dark mb-2">{i.work_type} | Per Hour RM{ new Intl.NumberFormat('en-US', {style: 'decimal', minimumFractionDigits: 2}).format(isNaN(i.amount)? '0.00':i.amount)}</span>
                     
                    </div>
                    
                    )
                }):
                <div className="hire-candidate"
                style = {{
                    marginTop: '63px',
                    marginLeft: '73px'
                }}
                >
                    No Employees yet
                </div>
                
            }
            {/* <div className="prev-next-btn text-center">
                <button className="btn btn-gray mr-2">
                    <img 
                    src={process.env.PUBLIC_URL+"/assets/images/app/chevron-arrow.svg"}alt="icon" />
                    Prev
                </button>
                <button className="btn btn-gray next">
                    Next
                    <img src={process.env.PUBLIC_URL+"/assets/images/app/chevron-arrow.svg"}
                     alt="icon" />
                </button>
            </div> */}
            
            </div>
            <div className="snippet-box1 min-h-vh p-4 attend-wrap">
            {
                
                props.loginReport &&
                props.loginReport.jobDetails &&
                <div className="attendance-tb-hdr">
                    <h4
                    className = "text-capitalize"
                    >{props.loginReport.jobDetails &&
                    props.loginReport.jobDetails.job_position
                    }</h4>
                    <h6 className = "text-capitalize">
                        {
                        props.loginReport.jobDetails &&
                        props.loginReport.jobDetails.job_location
                        }
                    </h6>
                </div>
            }
            
            <div className="table-responsive">
                <table className="emp-table attend-table w-nowrap">
                <thead>
                    <tr><th>Date</th>
                    <th>Log In Time</th>
                    <th>Log Out Time</th>
                    {/* <th>Total Hrs Working</th> */}
                    {/* <th>Total Hrs Worked</th> */}
                    <th>Employer Epf</th>
                    <th>Employer Socso</th>
                    <th>Employer Eis</th>
                    <th>Employee Epf</th>
                    <th>Employee Socso</th>
                    <th>Employee Eis</th>
                    <th>Working Hours</th>
                    <th>Worked Hours</th>
                    <th>Total Salary</th>
                    <th>Earned Salary</th>
                    {/* <th>Extra Work Hr</th> */}
                   
                    {/* <th></th> */}
                    </tr>
                </thead>
                <tbody>
                {
                props.loginReport &&
                props.loginReport.loginDetails &&
                props.loginReport.loginDetails.length > 0 &&
                props.loginReport.loginDetails.map((i, k) => {
                    return (
                    <tr key = {k}>
                    <td >{moment(new Date(i.login_date))
                    .format('DD MMMM YYYY')}</td>
                    <td>
                    {i.actual_start_time}
                        {/* <input id = "editable" 
                    style = {{border:'none'}}
                    disabled 
                    value = {i.start_time}/> */}
                    </td>
                    <td>{i.actual_end_time}</td>
                    {/* <td>{i.total_working_hours} Hours</td>
                    <td>{i.total_hours_worked} Hours</td> */}
                    {/* <td>{i.extra_hours} Hours</td> */}
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.employer_epf ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.employer_epf)
                    ? '0.00':i.worker_salary_reduction.employer_epf) 
                    : '0.00'
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.employer_socso ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.employer_socso)
                    ? '0.00':i.worker_salary_reduction.employer_socso) 
                     : '0.00'
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.employer_eis ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.employer_eis)
                    ? '0.00':i.worker_salary_reduction.employer_eis) 
                     : '0.00'
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.employee_epf ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.employee_epf)
                    ? '0.00':i.worker_salary_reduction.employee_epf) 
                     : '0.00'
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.employee_socso ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.employee_socso)
                    ? '0.00':i.worker_salary_reduction.employee_socso) 
                     : '0.00'
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.employee_eis ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.employee_eis)
                    ? '0.00':i.worker_salary_reduction.employee_eis) 
                     : '0.00'
                    } </td>
                    <td>{i.total_working_hours
                    } </td>
                    <td>{i.total_hours_worked
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.total_salary ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.total_salary)
                    ? '0.00':i.worker_salary_reduction.total_salary) 
                     :'0.00'
                    } </td>
                    <td>RM{i.worker_salary_reduction 
                    && i.worker_salary_reduction.earned_salary ?
                    new Intl.NumberFormat('en-US', 
                    {style: 'decimal', minimumFractionDigits: 2}).
                    format(isNaN(i.worker_salary_reduction.earned_salary)
                    ? '0.00':i.worker_salary_reduction.earned_salary) 
                     : '0.00'
                    } </td>
                    {/* <td>RM{i.salary}</td> */}
                    {/* <td><button 
                    onClick = {(e) => {
                        $('#editable').removeAttr('disabled')
                        props.update_employee_login_time({
                            work_id:i.id
                        })
                    }
                    }
                    className="btn btn-blue">Edit</button></td> */}
                    </tr>
                    )
                    })
                }
                    
                    {/* <tr>
                    <td>06 July 2020</td>
                    <td>07:24 AM</td>
                    <td>05:21 PM</td>
                    <td>110 Hours</td>
                    <td>10 Hours</td>
                    <td />
                    <td>RM 250</td>
                    </tr>
                    <tr>
                    <td>07 July 2020</td>
                    <td>07:24 AM</td>
                    <td>05:21 PM</td>
                    <td>110 Hours</td>
                    <td>10 Hours</td>
                    <td />
                    <td>RM 350</td>
                    </tr> */}
                </tbody>
                </table>
            </div>
            {/* <div className="prev-next-btn">
            <button className="btn btn-gray mr-2">
                <img src={process.env.PUBLIC_URL+"/assets/images/app/chevron-arrow.svg"}
                alt="icon" />
                Prev
            </button>
            <button className="btn btn-gray next">
                Next
                <img src={process.env.PUBLIC_URL+"/assets/images/app/chevron-arrow.svg"}
                alt="icon" 
                />
            </button>
            </div> */}
            {/* <img src={process.env.PUBLIC_URL + "/assets/images/download-icon.svg"} alt="icon" /> */}
            {
                props.loginReport.sheet &&
                props.loginReport.sheet.length > 0 &&
                <CsvDownload data={props.loginReport.sheet} 
                   className="dw-link"
                   style = {{
                    background: 'none',
                    border:'none'
                   }}
                >
                    Download Attendance Sheet
                </CsvDownload>
            }
            
            {/* <a href="javascript:;" className="dw-link"
            onClick = {() => {
                props.downloadSheet({
                    employee_id:props.employee_id,
                    job_id:props.job_id
                })}
            }
            >
                <img src={process.env.PUBLIC_URL + "/assets/images/download-icon.svg"} alt="icon" />
                Download Attendance Sheet
            </a> */}
            </div>
        </div>
    </>
   
    )};

    const mapStateToProps = (state, ownProps) => {
        return {
            showModel: state.Workers.showModel,
            workerDetails : state.Workers.workerDetails,
            currentWorkers:state.Workers.currentWorkers,
            loginReport :state.Workers.loginReport,
            employee_id:state.Workers.employee_id,
            job_id:state.Workers.job_id
        }
    };
    
    const mapDispatchToProps = (dispatch, ownProps) => {
       
        return {
            handelModel : (data) => dispatch(actions.handelModel(data)),
            getLoginReport : (data) => dispatch(actions.getLoginReport(data)),
            setData: data => dispatch(actions.setData(data)),
            getAllWorkers: (data) => dispatch(actions.getWorkers(data)),
            saveSalary : (data) => dispatch(actions.saveSalary(data)),
            setSuccess : data => dispatch(actions.setSuccess(data)),
            // downloadSheet : data => dispatch(actions.downloadSheet(data)),
            update_employee_login_time : data => dispatch(actions.update_employee_login_time(data))
        }
       
    };

    export default connect(mapStateToProps, mapDispatchToProps)(WorkerAttendance); 
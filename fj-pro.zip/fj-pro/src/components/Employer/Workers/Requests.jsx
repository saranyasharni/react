import React, { useEffect, useState } from "react";
import moment from "moment";
import * as actions from '../../../actions/Employer/Workers';
import $ from "jquery"
import { connect } from 'react-redux'

function WorkerRequests(props) {
    
    const [state, setState] = useState({
      status:0,
      loading:false,
      date: moment(new Date()).format('DD MMMM YYYY')
    })

    useEffect(() => {   
      $(document).ready(function () {
        window.jQuery(".cal-icon")
        .datepicker({
          format: "mm/dd/yyyy",
          todayHighlight:true,
          autoclose: true
      })
      })
        // require("../../../assets/css/app-style.css");
    }, []);
    function getYesterdaysDate() {
      var date = new Date(state.date)
      
      date.setDate(date.getDate()-1);
      let date1 =  date.getDate() + ' ' + 
      (date.toLocaleString('default', { month: 'long' })) + 
      ' ' + date.getFullYear();
      
      let sendDateFormat = 
      ('0' + (date.getMonth()+1)).slice(-2) +'/' +
       ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear();

      props.getLateRequests({
        employer_id:localStorage.getItem('emp_id'),    
        page_no : 0,
        limit : 100,
        filter:1,
        filter_date:sendDateFormat

      })
      setState({
          date:date1
      })
  }
  function getTomorrowsDate() {
      var date = new Date(state.date);
      date.setDate(date.getDate()+1);
      let date1 =  date.getDate() + ' ' + 
      (date.toLocaleString('default', { month: 'long' })) + 
      ' ' + date.getFullYear();
      // let sendDateFormat = date.getDate() + '/' + (date.getMonth()+1) + '/' + date.getFullYear();
      setState({
          date:date1
      })
      let sendDateFormat = 
      ('0' + (date.getMonth()+1)).slice(-2) +'/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear();

      props.getLateRequests({
        employer_id:localStorage.getItem('emp_id'),    
        page_no : 0,
        limit : 100,
        filter:1,
        filter_date:sendDateFormat

      })
  }
    return (
        
        <div className="row">
        <div className="snippet-box min-h-vh">
          <div className="table-hdr row">
          <div className="date-nav">
            <a href="javascript:;" className="date-prev"
            onClick = {() => {
              getYesterdaysDate()
            }}
            >
                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
            </a>
            {/* <span>{state.date}</span> */}
            <img src="/assets/images/app/calendar-icon.svg" alt="icon" />
            <input className="cal-icon"
            
            onSelect = {(e) => {
              let date = new Date(e.target.value)
              let sendDateFormat = 
              ('0' + (date.getMonth()+1)).slice(-2) +'/' +
              ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear();
              setState({
                date:moment(new Date(e.target.value)).format('DD MMMM YYYY')
              });
            props.getLateRequests({
              employer_id:localStorage.getItem('emp_id'),    
              page_no : 0,
              limit : 100,
              filter:1,
              filter_date:sendDateFormat
      
            })
          }}
            
            value = {state.date}
            >
                
            </input>
            <a href="javascript:;" className="date-next"
            onClick = {() => {
                getTomorrowsDate()
            }}
            >
                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
            </a>
            </div>
            {/* <div className="date-nav">
              <a href="javascript:;" className="date-prev">
                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
              </a>
              <span>July 5 - July 11, 2020</span>
              <a href="javascript:;" className="cal-icon">
                <img src="/assets/images/app/calendar-icon.svg" alt="icon" />
              </a>
              <a href="javascript:;" className="date-next">
                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
              </a>
            </div> */}
          </div>
          <div className="row">
			{
				props.lateRequests &&
				props.lateRequests.length > 0 ?
				props.lateRequests.map((i,k) => {
					return (
						<div className="mb-3 col-md-6 col-lg-4" key = {k}>
						<div className="req-snip">
							<div className="hire-candidate">
							<div className="avatar">
								<img className="img-fluid" src={i.employee && 
								i.employee.profile_url &&
                i.employee.profile_url !== "null" &&
                i.employee.profile_url !== null
                ? i.employee.profile_url 
								:"/assets/images/app/avatar-1.png"
								} 
                style = {{
                  height : '100%'
                }}
                alt="Staff" />
							</div>
							<div className="av-cont">
								<h6>{i.employee && 
								i.employee.name
								}</h6>
								<span>{i.job && 
								i.job.job_position}  | {i.job &&
									i.job.job_location
								}</span>
							</div>
							</div>
							<div className="row req-cont mt-3">
							<p className="col-md-5 text-truncate">Date : {
							moment(new Date(i.request_date)).format('DD MMMM YYYY')}</p>
							{/* <p className="col-md-7 text-truncate">Correct Log In Time : 11:00 AM</p> */}
              <p className="col-md-7 text-truncate">Correct Log In Time : {i.request_time}
              </p>
							<p className="col-md-12 mt-2">Description</p>
							<p className="col-md-12">{i.description}</p>
							<div className="col-12 mt-3 mb-1 text-right">
								<button className="btn btn-red" 
								onClick = {
									(e) => {
                    props.rejectRequest({
                      request_id:i.id,
                      employee_id:i.employee_id
                    })
									}
								}
								>
									Reject Request</button>
								<button className="btn btn-blue mt-0"
                onClick = {
									(e) => {
                    props.acceptRequest({
                      request_id:i.id,
                      employee_id:i.employee_id
                    })
									}
								}
                >Accept</button>
							</div>
							</div>
						</div>
						</div>
					)
				}):
        <div className="empty-job">
        <img src="assets/images/app/undraw-empty.svg" alt="image"/>
        <p>There's nothing here.</p>
        </div>
			  }
        </div>
        </div>
      </div>
        
   
    )};

    const mapStateToProps = (state, ownProps) => {
        return {
            lateRequests:state.Workers.lateRequests
        }
    };
    
    const mapDispatchToProps = (dispatch, ownProps) => {
       
        return {
          getLateRequests : (data) => dispatch(actions.getLateRequests(data)),
            handelModel : (data) => dispatch(actions.handelModel(data)),
            saveSalary : (data) => dispatch(actions.saveSalary(data)),
            rejectRequest : (data) => dispatch(actions.rejectRequest(data)),
            acceptRequest : (data) => dispatch(actions.acceptRequest(data)),
        }
       
    };

    export default connect(mapStateToProps, mapDispatchToProps)(WorkerRequests); 
import React, { useEffect, useState } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import * as actions from '../../../actions/Employer/Workers';
import {getCreditAmount} from '../../../actions/Employer/Hire'
import $ from "jquery"
import StripeCheckout from 'react-stripe-checkout';
import moment from "moment";

function EditWorkers(props) {
    
    const [state, setState] = useState({
        extraHours : '',
        extraDays : '1',
        start_time : '',
        end_time:'',
        extend_type:'work',
        epfPaidByEmployer : '',
        socsoPaidByEmployer : '',
        start_date:'',
        end_date:'',
        // moment(new Date()).format('MM/DD/YYYY')
        amount:'',
        eisPaidByEmployer :'',
        extraAmountBase :'',
        totalExtraSalary :'',
        epfPaidByEmployee : '',
        socsoPaidByEmployee : '',
        eisPaidByEmployee :'',
        totalAmountPaidByEmployer:'',
        reducedSalaryToEmployee:'',
        fjAdminFee:'',
        payment_type : 'card',
        errors:{}
    })

    useEffect(() => {
        props.getCreditAmount()
        $(document).ready(function () {
            window.jQuery('.time-picker').datetimepicker({
                format: 'HH:mm',
                stepping: 30,
                icons: {
                    up: "fa fa-angle-up",
                    down: "fa fa-angle-down"
                }
            }).on('dp.change', function (e) {  
              
            });    
          
        window.$(".start_date_work")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
            autoclose:true
        // endDate: "+0d",
        })
        .off("change")
        .change((e) => {{
            
            // setState({
            //     ...state,
            //     start_date: e.target.value
            // });  
        }});
        window.$(".end_date_work")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
            autoclose:true
        // endDate: "+0d",
        })
        .off("change")
        .change((e) => {{
            
            // setState({
            //     ...state,
            //     end_date: e.target.value
            // });  
        }});
        window.$(".extend_date_work")
        .datepicker({
        format: "mm/dd/yyyy",
        todayHighlight: true,
            autoclose:true
        // endDate: "+0d",
        })
        .off("change")
        .change((e) => {{
            
            // setState({
            //     ...state,
            //     extended_day: e.target.value,
            //     start_date : e.target.value,
            //     end_date :e.target.value
            // });  
        }});
       
        })
        
        // require("../../../assets/css/app-style.css");
    }, []);

    useEffect(() => {
        $(document).ready(function () {
            window.jQuery('.time-picker').datetimepicker({
                format: 'HH:mm',
                stepping: 30,
                icons: {
                    up: "fa fa-angle-up",
                    down: "fa fa-angle-down"
                }
            }).on('dp.change', function (e) {  
              
            });  
            window.$(".start_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                calculateExtraSalary(
                    e.target.value,
                    state.end_date,
                    state.start_time,state.end_time,state.amount
                );
                setState({
                    ...state,
                    start_date: e.target.value
                });  
            }});
            window.$(".end_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                calculateExtraSalary(
                    state.start_date,
                    e.target.value,
                    state.start_time,state.end_time,state.amount
                );
                setState({
                    ...state,
                    end_date: e.target.value
                });  
            }});
            window.$(".extend_date_work")
            .datepicker({
            format: "mm/dd/yyyy",
            todayHighlight: true,
            autoclose:true
            // endDate: "+0d",
            })
            .off("change")
            .change((e) => {{
                calculateExtraSalary(
                    e.target.value,
                    e.target.value,
                    state.start_time,
                    state.end_time,
                    state.amount
                );
                // setState({
                //     ...state,
                //     extended_day: e.target.value,
                //     start_date : e.target.value,
                //     end_date :e.target.value
                // });  
            }});
        // if (props.status === 1) {
        //     $("#edit-work-salary-modal .alert").html(
        //         `<strong>Success!</strong> ${props.modelMessage}.`
        //     );
        //     $("#edit-work-salary-modal .alert")
        //         .removeClass("alert-danger")
        //         .addClass("alert-success");
        //     setTimeout(function () {
        //         $("#edit-work-salary-modal .alert").removeClass("alert-success");
        //         $("#edit-work-salary-modal .alert").html("");
        //         window.$("#edit-work-salary-modal").modal("hide");

        //         props.setSuccess(0, '');
        //     }, 3000);
              
        if (props.modelStatus === 2) {
            $("#edit-work-salary-modal .alert").html(
                `<strong>Sorry!</strong> ${props.modelMessage}.`
            );
            $("#edit-work-salary-modal .alert")
                .removeClass("alert-success")
                .addClass("alert-danger");
            setTimeout(function () {
                $("#edit-work-salary-modal .alert").removeClass("alert-danger");
                $("#edit-work-salary-modal .alert").html("");
                window.$("#edit-work-salary-modal").modal("hide");
                props.setModelSuccess(0, '');
            }, 3000);
        }
    
    })
    })

    const onToken = () => {
        let actualAmount = state && state.totalAmountPaidByEmployer
        let walletAmount = Number(props.walletAmount)
        // let walletAmount = Number(10.90)
        if (state.payment_type === 'credit' && (walletAmount < actualAmount )) {
            props.setModelSuccess(2, 'Not enough amount, Please pay with card.');
        } else {
            props.saveSalary({
                work_id:props.workerProfile && props.workerProfile.id,
                currency:"RM",
                amount:state.extraAmountBase,
                total_extra_salary:state.totalExtraSalary,
                number_of_hours:state.extraHours,
                number_of_days:state.extraDays,
                start_date:state.start_date,
                end_date:state.end_date,
                start_time:state.start_time,
                end_time:state.end_time,
                employer_epf:state.epfPaidByEmployer,
                employer_socso:state.socsoPaidByEmployer,
                from_credits:state.payment_type === 'credit' ? '1' :'0',
                employer_eis:state.eisPaidByEmployer,
                actual_salary_paid_by_employer:state.totalAmountPaidByEmployer,
                total_salary_base_by_employer:state.totalExtraSalary,
                employee_epf:state.epfPaidByEmployee,
                employee_eis:state.eisPaidByEmployee,
                employee_socso:state.socsoPaidByEmployee,
                reduced_salary_for_employee:state.reducedSalaryToEmployee,
                fj_admin_fee:state.fjAdminFee,
                // number_of_hours:state.extraHours,
                // number_of_days:state.extraDays,
                extend_current_day: state.extend_type==='work' ? 1 :0
            })
        }
    }
    const updateErrors = errors => {
        setState({
          ...state, 
          errors: { ...state.errors, ...errors }
        });
    };
    const handleErrors = (type, e) => {
        let errors = state.errors;
        let valid = true;
        if (type === 'time_check') {
            var converted_startTime = moment(state.start_time, "HH:mm");
            var converted_endTime = moment(e.target.value, "HH:mm");
            var duration = moment.duration(converted_endTime.diff(converted_startTime));
            var hours = parseInt(duration.asHours());
            console.log(hours, 'hours')
            if (hours < 1) {
                // alert()
                errors.time_check = 'Hours should be minimum 1 hr'
                updateErrors(errors);
                valid = false;
            } else {
                errors.time_check = ''
                updateErrors(errors);
                valid = false;
            }
        }
    }
    const calculateExtraSalary = (startDate,endDate,start_time,end_time,amount) => {
        
        let dynamicAdminFee = 0
        
        if (props.salaryContributions 
            && props.salaryContributions.adminFee 
            && props.salaryContributions.adminFee.admin_fee
            && props.salaryContributions.adminFee.admin_fee.admin_fee
            && props.salaryContributions.adminFee.admin_fee.admin_fee !== '0' &&
            props.salaryContributions.adminFee.admin_fee.admin_fee !== 'null'
            ) {
            
            dynamicAdminFee = parseInt(props.salaryContributions.adminFee.admin_fee.admin_fee)
        }
        let start = start_time
        let end = end_time
        let salary = Number(amount).toFixed(2)            
        var Difference_In_Days 
        if (state.extend_type === 'job') {
            
            var new_date1 = new Date(startDate); 
            var new_date2 = new Date(endDate); 
            // console.log(state.startDate, 'startDatw')
            // console.log(state.endDate, 'endDate')
            // To calculate the time difference of two dates 
            var Difference_In_Time = new_date2.getTime() - new_date1.getTime(); 
            // To calculate the no. of days between two dates 
            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24); 
        } else {
            var Difference_In_Days = 0; 
        }
        
        // console.log(start_time,end_time,salary, 'calculationvalues')
        var converted_startTime=moment(start, "HH:mm");
        var converted_endTime=moment(end, "HH:mm");
        var duration = moment.duration(converted_endTime.diff(converted_startTime));
        var hours = parseInt(duration.asHours());
        var minutes = parseInt(duration.asMinutes())-hours*60;
        let salaryPerMinutes = '';
        if (minutes !== 0) {
            if (minutes <= 15 &&  minutes > 0) {
                salaryPerMinutes = salary*(1/4)
            } else if (minutes <= 30 && minutes >= 16) {        
                salaryPerMinutes = salary*(1/2).toFixed(2)
            } else if (minutes >= 31 && minutes <= 45) {
                salaryPerMinutes = salary*(3/4).toFixed(2)
            } else if (minutes >= 46 && minutes <= 59) {
                salaryPerMinutes = salary*(3/5).toFixed(2)
            } else {
                salaryPerMinutes = 0.00    
            }
        } else {
            salaryPerMinutes = 0.00
        }
        // console.log(salaryPerMinutes, 'salaryPerMinutes')
        let hours_minutes = hours + '.' +minutes

        let totalSalary = parseInt((hours * salary).toFixed(2)) +
        parseInt(salaryPerMinutes) ;
        if (state.extend_type === 'job') {
        
            totalSalary = ((Difference_In_Days+1) * totalSalary).toFixed(2)
        } 
        
        // let totalSalary = (state.extraDays * salary).toFixed(2)
        let below_sixty_employer_paid_Salary = 0.00;
        let above_sixty_employee_reduced_Salary = 0.00;
        let below_sixty_employer_socso = 0.00;
        let below_sixty_employer_eis = 0.00;
        let below_sixty_employee_reduced_Salary = 0.00;
        let below_sixty_fjAdminFee = 0.00;
        let above_sixty_employer_epf = 0.00;
        let below_sixty_employer_epf = 0.00;
        let above_sixty_employer_paid_Salary = 0.00;
        let above_sixty_fjAdminFee = 0.00;
        let below_sixty_employee_socso= 0.00;
        let below_sixty_employee_eis = 0.00;
        let below_sixty_employee_epf = 0.00;
        // console.log(totalSalary, 'totalSalary')
        // console.log(props.workerProfile.age_category, 'props.workerProfile.age_category')
        if (props.workerProfile && props.workerProfile.age_category === "below 60" ) {
            if (amount <= 5000) {
                
                if (props.salaryContributions &&
                    props.salaryContributions.contributions &&
                    props.salaryContributions.contributions.length > 0 &&
                    props.salaryContributions.contributions[0].employer_epf &&
                    props.salaryContributions.contributions[0].employee_epf
                    ) {
                
                        below_sixty_employer_epf =  (totalSalary * (parseInt(props.
                        salaryContributions.contributions[0].employer_epf)/100)).toFixed(2)
                        below_sixty_employee_epf =  (totalSalary * (parseInt(props.
                        salaryContributions.contributions[0].employee_epf)/100)).toFixed(2)
                        
                } else {
                    below_sixty_employer_epf =  (totalSalary * (13/100)).toFixed(2)
                    below_sixty_employee_epf =  (totalSalary * (9/100)).toFixed(2)
                    
                }
                // above_sixty_employee_epf =  (totalSalary * (11/100)).toFixed(2)
            } else {
                if (props.salaryContributions &&
                    props.salaryContributions.contributions &&
                    props.salaryContributions.contributions.length > 0 &&
                    props.salaryContributions.contributions[2].employer_epf
                    ) {
                        below_sixty_employer_epf =  (totalSalary * (parseInt(props.
                        salaryContributions.contributions[2].employer_epf)/100)).toFixed(2)
                        below_sixty_employee_epf =  (totalSalary * (parseInt(props.
                        salaryContributions.contributions[2].employee_epf)/100)).toFixed(2)
                } else {
                    below_sixty_employer_epf =  (totalSalary * (12/100)).toFixed(2)
                    below_sixty_employee_epf =  (totalSalary * (11/100)).toFixed(2)
                }
               
            }
            if (props.salaryContributions &&
                props.salaryContributions.contributions &&
                props.salaryContributions.contributions.length > 0 &&
                props.salaryContributions.contributions[2].employer_eis &&
                props.salaryContributions.contributions[2].employee_eis &&
                props.salaryContributions.contributions[2].employer_socso &&
                props.salaryContributions.contributions[2].employee_socso) {
                below_sixty_employer_socso = (totalSalary * (parseFloat(
                    props.salaryContributions.contributions[2].employer_socso
                )/100)).toFixed(2)
                
                below_sixty_employer_eis = (totalSalary * (parseFloat(
                    props.salaryContributions.contributions[2].employer_eis
                )/100)).toFixed(2)
                below_sixty_employee_socso = (totalSalary * (parseFloat(
                    props.salaryContributions.contributions[2].employee_socso
                )/100)).toFixed(2)
                below_sixty_employee_eis = (totalSalary * (parseFloat(
                    props.salaryContributions.contributions[2].employee_eis
                )/100)).toFixed(2)
            } else {
                below_sixty_employer_socso = (totalSalary * (1.75/100)).toFixed(2)
                below_sixty_employer_eis = (totalSalary * (0.2/100)).toFixed(2)
                below_sixty_employee_socso = (totalSalary * (0.5/100)).toFixed(2)
                below_sixty_employee_eis = (totalSalary * (0.2/100)).toFixed(2)
            }

            below_sixty_employer_paid_Salary = (Number(totalSalary) + 
            Number(below_sixty_employer_epf) + Number(below_sixty_employer_socso) + Number(below_sixty_employer_eis)).toFixed(2)
            below_sixty_employee_reduced_Salary = (Number(totalSalary) -
            Number(below_sixty_employee_epf) - Number(below_sixty_employee_socso)).toFixed(2) - parseInt(below_sixty_employee_eis)
            if (dynamicAdminFee !== 0) {
                below_sixty_fjAdminFee = (below_sixty_employer_paid_Salary * (dynamicAdminFee/100)).toFixed(2)
            } else {
                below_sixty_fjAdminFee = (below_sixty_employer_paid_Salary * (10/100)).toFixed(2)
            }
            // console.log(below_sixty_employer_epf, 'below_sixty_employer_epf')
            // console.log(below_sixty_employee_epf, 'below_sixty_employee_epf')
            // console.log(below_sixty_employee_socso, 'below_sixty_employee_socso')
            // console.log(below_sixty_employer_socso, 'below_sixty_employer_socso')
            // console.log(below_sixty_employer_eis, 'below_sixty_employer_eis')
            // console.log(below_sixty_employee_eis, 'below_sixty_employee_eis')
            setState ({
                ...state,
                epfPaidByEmployer :below_sixty_employer_epf,
                start_time : start_time,
                end_time: end_time,
                start_date: startDate,
                extended_day: startDate,
                end_date:endDate,
                amount : amount,
                socsoPaidByEmployer :below_sixty_employer_socso,
                eisPaidByEmployer :below_sixty_employer_eis,
                extraAmountBase :salary,
                totalExtraSalary :totalSalary,
                epfPaidByEmployee : below_sixty_employee_epf,
                socsoPaidByEmployee :below_sixty_employee_socso,
                eisPaidByEmployee :below_sixty_employee_eis,
                totalAmountPaidByEmployer:below_sixty_employer_paid_Salary,
                reducedSalaryToEmployee:below_sixty_employee_reduced_Salary,
                fjAdminFee:below_sixty_fjAdminFee,
                extraHours : hours_minutes,
                extraDays : Difference_In_Days+1,
                extraWeeks :'',
                extraMonths :'',
            })
            // console.log(state, 'statetotalSalary')
            // console.log(above_sixty_employer_epf, 'above_sixty_employer_epf')
            // console.log(above_sixty_employee_reduced_Salary, 'above_sixty_employee_reduced_Salary')
            // console.log(above_sixty_employer_paid_Salary, 'above_sixty_employer_paid_Salary')
           
        } else {
            if (props.salaryContributions &&
                props.salaryContributions.contributions &&
                props.salaryContributions.contributions.length > 0 &&
                props.salaryContributions.contributions[1].employer_epf
            ) {
                above_sixty_employer_epf =  (totalSalary * (parseInt(props.
                salaryContributions.contributions[1].employer_epf)/100)).toFixed(2)
            } else {
                above_sixty_employer_epf =  (totalSalary * (4/100)).toFixed(2)
            }

            above_sixty_employee_reduced_Salary = parseInt(totalSalary)
            above_sixty_employer_paid_Salary = (Number(totalSalary) + 
            Number(above_sixty_employer_epf)).toFixed(2)
            if (dynamicAdminFee !== 0) {
                above_sixty_fjAdminFee = (above_sixty_employer_paid_Salary * (dynamicAdminFee/100)).toFixed(2)    
            } else {
                above_sixty_fjAdminFee = (above_sixty_employer_paid_Salary * (10/100)).toFixed(2)    
            }
        
            setState (
                {
                ...state,
                start_time : start_time,
                end_time: end_time,
                amount : amount,
                extended_day: startDate,
                extraHours : hours_minutes,
                extraDays : Difference_In_Days+1,
                extraWeeks :'',
                extraMonths :'',
                epfPaidByEmployer : above_sixty_employer_epf,
                socsoPaidByEmployer :0.00,
                eisPaidByEmployer :0.00,
                extraAmountBase :salary,
                totalExtraSalary :totalSalary,
                epfPaidByEmployee : 0.00,
                socsoPaidByEmployee :0.00,
                eisPaidByEmployee :0.00,
                totalAmountPaidByEmployer:above_sixty_employer_paid_Salary,
                reducedSalaryToEmployee:above_sixty_employee_reduced_Salary,
                fjAdminFee:above_sixty_fjAdminFee
            },
            
            )   
        }
    }
    return (
        <Modal show={props.showModel} className="modal fade custom-modal"
        id = "edit-work-salary-modal"
        onHide={
            () => props.handelModel(false)}
        tabIndex="-1" role="dialog" aria-hidden="true"
        centered
        >
     
        {/* <div className="modal-dialog modal-dialog-centered" role="document"> */}
            <div className="modal-content">
            <div className="modal-header">
                <h5 className="modal-title w-100 justify-content-center">Edit Extra Working Hours</h5>
                <button 
                onClick = {() => props.handelModel(false)}
                type="button" className="close" data-dismiss="modal" aria-label="Close">
                <img className="img-fluid" src="/assets/images/modal-close-icon.svg" alt="icon" />
                </button>
            </div>
            <div className="modal-body edit-wrk">
               
                <div className="row">
                <h5 className="col-12 mb-3">Salary Calculation</h5>
                <div className="col-md-6 cal-cont">
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">{
                        props.workerProfile 
                        && props.workerProfile.job && props.workerProfile.job.salary_based
                    }
                    </span>
                    <span className="col-md-5 col-5">{props.workerProfile 
                    && props.workerProfile.job && props.workerProfile.job.currency
                    } {" "} {props.workerProfile.job && props.workerProfile.job.amount}
                    </span>
                    </div>
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">Number of Hour</span>
                    <span className="col-md-5 col-5">{
                        props.workerProfile 
                        && props.workerProfile.job && props.workerProfile.job.number_of_hours
                    }</span>
                    </div>
                    <div className="row mb-3">
                    <span className="dark col-md-7 col-7">Number of Days</span>
                    <span className="col-md-5 col-5">{
                        props.workerProfile 
                        && props.workerProfile.job && props.workerProfile.job.number_of_days
                    }</span>
                    </div>
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">Total Salary  Pay</span>
                    <span className="col-md-5 col-5">{props.workerProfile 
                    && props.workerProfile.job && props.workerProfile.job.job_salaries &&
                    props.workerProfile.job.job_salaries[0].total_salary_base_by_employer}</span>
                    </div>
                    <div className="row mb-3">
                    <span className="dark col-md-7 col-7">FlexiJobs Fee</span>
                    <span className="col-md-5 col-5">{props.workerProfile 
                    && props.workerProfile.job && props.workerProfile.job.job_salaries &&
                    props.workerProfile.job.job_salaries[0].fj_admin_fee}</span>
                    </div>
                </div>
                <div className="col-md-6 cal-cont">
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">EPF ({
                    props.workerProfile.age_category === "below 60" 
                    && state.amount <= 5000 ? 
                    props.salaryContributions.contributions[0].employer_epf :
                    (props.workerProfile.age_category === "below 60" && state.amount > 5000) ?
                    props.salaryContributions.contributions[2].employer_epf :
                    props.workerProfile.age_category === "above 60" ?
                    props.salaryContributions.contributions[1].employer_epf
                    :""
                    }
                    %)</span>
                    <span className="col-md-5 col-5">RM{
                    props.workerProfile 
                    && props.workerProfile.job && props.workerProfile.job.job_salaries &&
                    props.workerProfile.job.job_salaries[0].employer_epf}
                    </span>
                    </div>
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">EIS ({props.workerProfile.age_category === "below 60" 
                    && state.amount <= 5000 ? 
                    props.salaryContributions.contributions[0].employer_eis :
                    (props.workerProfile.age_category === "below 60" && state.amount > 5000) ?
                    props.salaryContributions.contributions[2].employer_eis :
                    props.workerProfile.age_category === "above 60" ?
                    props.salaryContributions.contributions[1].employer_eis
                    :""}%)</span>
                    <span className="col-md-5 col-5">RM{
                    props.workerProfile 
                    && props.workerProfile.job && props.workerProfile.job.job_salaries &&
                    props.workerProfile.job.job_salaries[0].employer_eis}
                    </span>
                    </div>
                    <div className="row mb-1 mb-md-5">
                    <span className="dark col-md-7 col-7">SOCSO ({props.workerProfile.age_category === "below 60" 
                    && state.amount <= 5000 ? 
                    props.salaryContributions.contributions[0].employer_socso :
                    (props.workerProfile.age_category === "below 60" && state.amount > 5000) ?
                    props.salaryContributions.contributions[2].employer_socso :
                    props.workerProfile.age_category === "above 60" ?
                    props.salaryContributions.contributions[1].employer_socso
                    :""}%)</span>
                    <span className="col-md-5 col-5">RM{
                        props.workerProfile 
                        && props.workerProfile.job && props.workerProfile.job.job_salaries &&
                        props.workerProfile.job.job_salaries[0].employer_socso
                    }
                    </span>
                    </div>
                    <div className="row total-cal">
                    <span className="dark col-md-7 col-7">Total Cost</span>
                    <span className="col-md-5 col-5">RM {
                        props.workerProfile 
                        && props.workerProfile.job && props.workerProfile.job.job_salaries &&
                        props.workerProfile.job.job_salaries[0].actual_salary_paid_by_employer
                    }
                    </span>
                    </div>
                </div>
                </div>
                <div className="row mt-4">
                <h5 className="col-12 mb-3">Extra Salary Calculation</h5>
                
                <div className="col-12 form-section mb-2">
                
                <div className="form-group mb-1">
                    <label>Work Extend Type</label>
                    <div className="col-12 p-0">
                    <label className="input">
                        <input type="radio" name="work"
                        value = "work"
                        checked = {state.extend_type === 'work'}
                        onChange={() => {
                            setState({
                                ...state,
                                extend_type : 'work'
                            })
                        }}
                         />
                        Time Extension
                    </label>
                    <span className="radio-cont">Your work will be extened to the selected day or today from the end of the work. You can extend only one day</span>
                    </div>
                    <div className="col-12 p-0">
                    <label className="input">
                        <input type="radio" name="job" 
                        value = "job"
                        checked = {state.extend_type === 'job'}
                        onChange={() => {
                            setState({
                                ...state,
                                extend_type : 'job'
                            })
                        }}
                        />
                        Extend Job
                    </label>
                    <span className="radio-cont">Your job days will be extened to the selected days from the end of the job. You can extend more than one day</span>
                    </div>
                </div>
                
                <div className={`row ${state.extend_type === 'work' ? 'd-block':'d-none'}`} >
                <div className="col-md-12 form-group mb-1">
                    <label>Date to extend</label>
                    <div className="input-group date extend_date_work mar-t-no" data-date-format="mm/dd/yyyy">
                        <input type="text" className="form-control" 
                        value = {state.extended_day}
                        />

                        <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div>
                               
                </div>
                </div>
                <div className={`row ${state.extend_type === 'job' ? '':'d-none'}`} >
                <div className="col-md-6 form-group mb-1">
                    <label>Start Date</label>
                    <div className="input-group date start_date_work mar-t-no" data-date-format="mm/dd/yyyy">
                        <input type="text" className="form-control" 
                        value = {state.start_date}
                        />

                        <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div>
                               
                </div>
                <div className="col-md-6 form-group">
                    <label>End Date</label>
                    <div className="input-group date end_date_work mar-t-no" data-date-format="mm/dd/yyyy">
                        <input type="text" className="form-control" 
                        value = {state.end_date}
                        />

                        <div className="input-group-addon">
                        <img src="/assets/images/calendar-icon.svg" alt="icon" />
                        </div>
                    </div>
                
                </div>
                </div>
                    <div className="row">
                    <div className="col-md-6 form-group mb-1">
                    <label>Start Time</label>
                   
                        {/* <input type="text" className="form-control" 
                        value = {state && state.start_time}
                        onChange = {(e) => { {
                            calculateExtraSalary(
                                state.start_date,
                                state.end_date,
                                e.target.value,state.end_time,state.amount
                                );
                        }}}
                        /> */}
                     
                        <input type="text" className="form-control time-picker"
                        onBlur = {(e) => { {
                            calculateExtraSalary(
                                state.start_date,
                                state.end_date,
                                e.target.value,state.end_time,state.amount
                                );
                        }}}
                        value = {state && state.start_time}
                        />
                         
                    </div>
                    <div className="col-md-6 form-group">
                        <label>End Time</label>
                        {/* <input type="time" className="form-control" 
                        value = {state && state.end_time}
                        onChange = {(e) => { {
                            handleErrors("time_check", e)
                            calculateExtraSalary(
                                state.start_date,
                                state.end_date,
                                state.start_time,e.target.value,state.amount);
                            
                            
                        }}}
                        /> */}
                        <input type="text" className="form-control time-picker" 
                        
                        value = {state && state.end_time}
                        onBlur = {(e) => { {
                            handleErrors("time_check", e)
                            calculateExtraSalary(
                                state.start_date,
                                state.end_date,
                                state.start_time,e.target.value,state.amount);
                        }}}
                        />
                        {state.errors.time_check &&
                        state.errors.time_check.length > 0 ? (
                        <small className="text-danger">
                            {state.errors.time_check}
                        </small>
                        ) : (
                        ""
                        )}
                    </div>
                    <div className="col-md-6 form-group">
                        <label>Currency</label>
                        <input type="text" 
                        name  = "currency"
                        className="form-control" 
                        value="RM"
                        readOnly 
                        style = {{
                            background:'none',
                            cursor: 'not-allowed'
                        }}
                        />

                    </div>
                    <div className="col-md-6 form-group">
                        <label>Amount</label>
                        <input type="text" className="form-control" 
                        name = "amount"
                        value = {state && state.amount}
                        onChange = {(e) =>{ {
                            calculateExtraSalary(state.start_date,
                                state.end_date,state.start_time,state.end_time,e.target.value);
                            // setState({
                            //     ...state,
                            //     amount:e.target.value
                            // });
                            // if (e.target.value.length > 1) {
                            
                            // }
                        }
                        }}
                        placeholder={100} />
                    </div>
                    </div>
                    <div className = "row">
                        {console.log(state.payment_type, 'state.payment_type')}
                  <div className="col-6 ">
                    <label className="input">
                        <input type="radio" name="credit"
                        value = "credit"
                        checked = {state.payment_type === 'credit'}
                        onChange={() => {
                          setState({
                            ...state,
                            payment_type : 'credit'
                          });
                          
                        }}
                        />
                        Pay from credit 
                    </label>
                    </div>
                    <div className="col-6 ">
                    <label className="input">
                        <input type="radio" name="card"
                        value = "card"
                        checked = {state.payment_type === 'card'}
                        onChange={() => {
                          setState({
                            ...state,
                            payment_type : 'card'
                          });
                          
                        }}
                         />
                        Pay from Card
                    </label>
                    </div>
                    
                    </div>
                </div>
               
                <div className="col-md-6 cal-cont">
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">Extra Rate</span>
                    <span className="col-md-5 col-5">RM {state && state.extraAmountBase }</span>
                    </div>
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">Number of Hour</span>
                    <span className="col-md-5 col-5">{state && state.extraHours ? state.extraHours:
                    '0:00' } Hrs</span>
                    </div>
                    <div className="row mb-3">
                    <span className="dark col-md-7 col-7">Number of Days</span>
                    <span className="col-md-5 col-5">{state && state.extraDays}</span>
                    </div>
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">Total Salary  Pay</span>
                    <span className="col-md-5 col-5">RM {state && state.totalExtraSalary}</span>
                    </div>
                    <div className="row mb-3">
                    <span className="dark col-md-7 col-7">FlexiJobs Fee</span>
                    <span className="col-md-5 col-5">RM {state && state.fjAdminFee}</span>
                    </div>
                </div>
                <div className="col-md-6 cal-cont">
                    <div className="row mb-2">
                    <span className="dark col-md-7 col-7">EPF ({ props.workerProfile.age_category === "below 60" 
                    && state.amount <= 5000 ? 
                    props.salaryContributions.contributions[0].employer_epf :
                    (props.workerProfile.age_category === "below 60" && state.amount > 5000) ?
                    props.salaryContributions.contributions[2].employer_epf :
                    props.workerProfile.age_category === "above 60" ?
                    props.salaryContributions.contributions[1].employer_epf
                    :""}%)</span>
                    
                    <span className="col-md-5 col-5">RM{state && state.epfPaidByEmployer}</span>
                    </div>
                    <div className="row mb-1 mb-md-5">
                    <span className="dark col-md-7 col-7">SOCSO ({props.workerProfile.age_category === "below 60" 
                    && state.amount <= 5000 ? 
                    props.salaryContributions.contributions[0].employer_socso :
                    (props.workerProfile.age_category === "below 60" && state.amount > 5000) ?
                    props.salaryContributions.contributions[2].employer_socso :
                    props.workerProfile.age_category === "above 60" ?
                    props.salaryContributions.contributions[1].employer_socso
                    :""}%)</span>
                    <span className="col-md-5 col-5">RM{state && state.socsoPaidByEmployer}</span>
                    </div>
                    <div className="row mb-1 mb-md-5">
                    <span className="dark col-md-7 col-7">EIS ({props.workerProfile.age_category === "below 60" 
                    && state.amount <= 5000 ? 
                    props.salaryContributions.contributions[0].employer_eis :
                    (props.workerProfile.age_category === "below 60" && state.amount > 5000) ?
                    props.salaryContributions.contributions[2].employer_eis :
                    props.workerProfile.age_category === "above 60" ?
                    props.salaryContributions.contributions[1].employer_eis
                    :""}%)</span>
                    <span className="col-md-5 col-5">RM{state && state.eisPaidByEmployer}</span>
                    </div>
                    <div className="row total-cal">
                    <span className="dark col-md-7 col-7">Total Cost</span>
                    <span className="col-md-5 col-5">RM {state && state.totalAmountPaidByEmployer}</span>
                    </div>
                </div>
                <div className="alert mt-4" role="alert">
                        
                </div>
                <div className="col-md-12 form-group text-right">
                
                {state.payment_type === 'card' ?
                <StripeCheckout
                       amount={state && Number(state.totalAmountPaidByEmployer)}
                       billingAddress
                       shippingAddress
                       name="Upgrade now." // the pop-in header title
                       // description="Big Data Stuff" // the pop-in header subtitle
                       // className="btn btn-orange" 
                    //    style = {{marginLeft:'900px'}}
                       // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                       // description="Awesome Product"
                       // image="assets/images/logo-small.png"
                       stripeKey="pk_test_51IknhvSBf2Rw9k3F4KyXJRX7iOyoztpzn5yAUWLLSvs7uBj9FQdB488ke7aevqLUyaasz0u5yUY6zQ9Rtljb0xKJ00TPVSUNBE"
                       token={onToken}
                   >
                <button className="btn btn-blue"
                onClick = {() => {
                    
                props.handelModel(false)
                }}
                disabled = {props.loading ? true : false}
                >{props.loading ? "Loading..." : 'Pay Extra Salary'}
                </button>
                </StripeCheckout> :
                 <button className="btn btn-blue"
                 onClick = {onToken}
                 disabled = {props.loading ? true : false}
                 >{props.loading ? "Loading..." : 'Pay Extra Salary'}
                 </button>
                }
                    
                </div>
              
                </div>
                
            </div>
            
            </div>
        {/* </div> */}
        </Modal>
    )};

    const mapStateToProps = (state, ownProps) => {
        return {
            showModel: state.Workers.showModel,
            modelMessage: state.Workers.modelMessage,
            workerDetails : state.Workers.workerDetails,
            loading : state.Workers.loading,
            showMsg:state.Workers.showMsg,
            status:state.Workers.status,
            walletAmount : state.Hire.walletAmount,
            salaryContributions:state.Jobs.salaryContributions,
            modelStatus:state.Workers.modelStatus
        }
    };
    
    const mapDispatchToProps = (dispatch, ownProps) => {
       
        return {
            getCreditAmount: () => dispatch(getCreditAmount()),
            handelModel : (data) => dispatch(actions.handelModel(data)),
            saveSalary : (data) => dispatch(actions.saveSalary(data)),
            setSuccess : (data, msg) => dispatch(actions.setSuccess(data,msg)),
            setModelSuccess : (data, msg) => dispatch(actions.setModelSuccess(data,msg))
        }
       
    };

    export default connect(mapStateToProps, mapDispatchToProps)(EditWorkers); 
import React, { useEffect, useRef } from "react";
import { connect } from 'react-redux';
import Moment from 'react-moment';
import { io } from 'socket.io-client';
import $ from 'jquery';
import * as actions from "../../../actions/Employer/Chat";
import { Scrollbar } from "react-scrollbars-custom";
const endPoint = "http://ec2-54-169-157-197.ap-southeast-1.compute.amazonaws.com:3001/"

function ChatLeft(props) {
    const [input, setInput] = React.useState('')
    const messagesEndRef = useRef(null);
    const socket = io(endPoint)
    
    useEffect(() => {
        scrollToBottom()
        let emp_id = localStorage.emp_id ? localStorage.getItem('emp_id') :''
        let chatRoom = localStorage.chat_room_emp_id ? localStorage.getItem('chat_room_emp_id') : ''
        
        socket.on("connect", () => {
            // console.log(socket.id, 'second check'); // x8WIv7-mJelg7on_ALbx            
        });
        // socket.emit('openChat', {user_type:'employer', user_id:1})
        // console.log(parseInt(chatRoom), 'chatRoomOPOPO'); 

        socket.emit('joinRoom', ({chatRoomId:parseInt(chatRoom), user_type: "employer"}))
    
        socket.on('newMessage', ({chatRoomId, message}) => {
            
            // console.log(message, 'message created')            
            // console.log(props.chatRoomId, 'props.chatRoomId')
            // console.log(chatRoomId, 'props.chatRoomId')
            var newMessages = message
            if (props.chat_status === 0) {

            if (props.chatRoomId !== chatRoomId) {
            
        
            if (newMessages.employer_id) {
                // alert('if')
                props.messageStatus(1)
                props.updateNewMegs(
                    [{
                        id:newMessages.id,
                        employee_id:newMessages.employee_id ? newMessages.employee_id : null,
                        employer_id:newMessages.employer_id ? newMessages.employer_id : null,
                        message:newMessages.message,
                        chatRoomId:newMessages.chatRoomId,
                        createdAt:newMessages.createdAt,
                    }])
                    props.messageStatus(0)
            } else {
                // alert('else')
                props.updateNewMegs(
                    [{
                        id:newMessages.id,
                        employee_id:newMessages.employee_id ? newMessages.employee_id : null,
                        employer_id:newMessages.employer_id ? newMessages.employer_id : null,
                        message:newMessages.message,
                        chatRoomId:newMessages.chatRoomId,
                        createdAt:newMessages.createdAt,
                    }]
                )
                props.messageStatus(0)
            }
            }
        }
        })
        

        // socket.emit('joinRoom', ({chatRoomId: chatRoomsList[0].id, user_type: "employer"}))
        // socket.on('chatRoomId', (chatRoomId, profileData) => {
        //     console.log(chatRoomId, 'chatRoomIdchatRoomId')
        //     this.props.setChatData(
        //         chatRoomId.messages
        //     )
        //     // this.props.setChatRoomId(
        //     //     chatRoomsList[0].id
        //     // )
           
            
        // })
        return () => {
            let chat_room_id = props.chatRoomId
            //Component Unmount
            if (socket) {
              socket.emit("leaveRoom", {
                chat_room_id,
              });
            }
        };

       
    }, [props.chatRoomId]);
    
    useEffect(() => {
        scrollToBottom()
    })

    function scrollToBottom(){    
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }

    const sendMsg = () => {
        
        let emp_id = localStorage.emp_id ? localStorage.getItem('emp_id') :''
        let chatRoom = localStorage.chat_room_emp_id ? localStorage.getItem('chat_room_emp_id') : ''
        console.log(props.chatRoomId, 'props.chatRoomId')
        // console.log(props.chatRoomId, 'props.chatRoomId')
        // console.log(emp_id, 'emp_id')
        // console.log(input, 'input')
        if (input !== '') {
            
            socket.emit('openChat', {user_type:'employer', user_id:emp_id})

            socket.emit('joinRoom', ({chatRoomId: parseInt(chatRoom), user_type: "employer"}))
            setInput("")
            socket.emit('postMessage', ({chatRoomId: parseInt(chatRoom), from: "employer", user_id: emp_id, message:input}));
            
            socket.on('newMessage', ({chatRoomId, message}) => {
                console.log("message created after post: ", chatRoomId, message);
            })
            
            scrollToBottom()
            // socket.emit('postMessage', ({chatRoomId: props.chatRoomId, from: "employer", user_id: emp_id, message: input}));
            
        }
        
    }
    return (
       
        <div className="chat-right">
            {
            props.chatContents  ? 
            (
            <>
            <div className="col-12 hdr-row">
            <div className="card-row">
            <div className="card-left">
            <div className="avatar">
                <img className="img-fluid" 
                style = {{
                    height : 'inherit'
                }}
                src={props.chatProfile.profile_url ? 
                    props.chatProfile.profile_url : "/assets/images/app/avatar-4.png"
                } alt="Username" />
            </div>
            <a className="chat-back" href="javascript:;">
                <img src="/assets/images/app/back-arrow.svg" alt="icon" />
            </a>
            </div>
            <div className="card-right">
            <div>
                <p className="lead text-truncate">{props.chatProfile.name ? props.chatProfile.name :'' }</p>
                <span className="sub text-truncate">Purchase Manager</span>
            </div>
            <div className="r-job-item">
                <div className="dropdown more">
                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img src="/assets/images/app/more-btn.svg" />
                </button>
                <div className="dropdown-menu" aria-labelledby="more-menu">
                    <ul className="list-unstyled">
                    <li><a href="javascript:;">View Profile</a></li>
                    <li><a href="javascript:;">Share</a></li>
                    <li><a href="javascript:;" className="red">End Discussion</a></li>
                    </ul>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        {/* <ScrollArea>
        { () => <div>Some long content. </div> }
        </ScrollArea> */}
        <div className="col-12 chat-sec">
        <Scrollbar style={{ width: 740}}
        noScrollX = {false}
        >
        <div className="mscroll-y "
        id = "chat_scroll"
        >
        
            <div className="day-seperator">
            <span>Today</span>
            </div>
            <div className="col-12 px-0 my-3">
            <span className="alert">He Applied to Purchase Manager position on Oct 28,2020.</span>
            </div>
            {
                props.chatContents && 
                props.chatContents.length > 0 &&
                props.chatContents.map((i, k) => {
                if (i.employer_id !== null) {
                return (
                <>
                <div key = {k} className= "col-12 px-0 my-3 chat-row f-end" >
                <div className="chat-cont">
                    <p>{i.message}</p>
                    <span><Moment fromNow>{new Date(i.createdAt)}</Moment></span>
                </div>
                <div className="chat-avatar">
                    <img className="img-fluid" src="/assets/images/app/logo-icon.png" />
                </div>
                </div>
                </>
                )
                        
                } else {
                    return (
                       
                    <div key = {k} className="col-12 px-0 my-3 chat-row">
                        <div className="chat-avatar">
                            <img className="img-fluid" src="/assets/images/app/avatar-1.png" />
                        </div>
                        <div className="chat-cont">
                            <p>{i.message}</p>
                            <span><Moment fromNow>{i.createdAt}</Moment></span>
                        </div>
                    </div> 
                    )
                        
                }
                    
                })
            } 
            <div ref={messagesEndRef} />  
          
          
        </div>
        
        </Scrollbar>    
        </div>
        
        <div className="col-12 chat-btm">
        <div className="chat-btm-wrap">
            <a href="javascript:;" className="icons">
            <img className="emoti img-fluid" src="/assets/images/app/emoticon.svg" alt="icon" />
            </a>
            <input placeholder="Enter your Message" 
            type="text" 
            className="form-control" name 
            value = {input}
            onChange = {(e) => {setInput(
                e.target.value
            )}}
            />
            <a href="javascript:;" className="icons mr-3">
            <img className="img-fluid" src="/assets/images/app/mic-icon.svg" alt="icon" />
            </a>
            <a href="javascript:;" className="icons mr-3">
            <img className="img-fluid" src="/assets/images/app/attachment-icon.svg" alt="icon" />
            </a>
            {/* <form onSubmit={sendMsg}>
            <button 
            type = "submit"
            href="javascript:;" className="icons" 
            onClick = {sendMsg}
            > */}
            <a href="javascript:;" className="icons"
            onClick = {sendMsg}
            >
            <img className="img-fluid"
            
             src="/assets/images/app/send-icon.svg" alt="icon" />
             </a>
            {/* </button> */}
            {/* <button type="submit">Submit</button> */}
            {/* </form> */}
            
        </div>
        </div>
                   </>
               ) : (
                   <>
                    <div className="nodata-wrap">
                    <img className="no-data-img" src="/assets/images/app/undraw-publish.svg" alt="image" />
                    <p>No Chats Started Yet</p>
                    {/* <Link to = {`/create/job-post`}
                    className="btn btn-blue" href="hire-create-post-job.html">+ Post a Job</Link>  */}
                    </div>
                   </>
               )
            }
        
    </div>
    )
    }


const mapStateToProps = (state, ownProps) => {
    return {
        chatContents : state.Chat.chatContents,
        chatRoomId: state.Chat.chatRoomId,
        chatProfile: state.Chat.chatProfile,
        chat_status:state.Chat.chat_status
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        updateNewMegs: (data) => dispatch(actions.updateNewMegs(data)),
        messageStatus: (data) => dispatch(actions.messageStatus(data))

    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ChatLeft);
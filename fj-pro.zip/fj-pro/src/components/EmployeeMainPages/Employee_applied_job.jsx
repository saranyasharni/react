import React, { useEffect, useState } from "react";
import Header from "../Common/App/AppHeader";
import Employee_navtab from "../Employee/EmployeeAppliedJobs/employee_navtab";
import ApplyJobGrid from "../Employee/EmployeeAppliedJobs/Employee_applied_job_grid";
import ApplyJobList from "../Employee/EmployeeAppliedJobs/Employee_applied_job_list";
import Alert from "react-bootstrap/Alert";
import { connect } from 'react-redux';
import { AppliedJob, Applied_job_list, 
  AppliedClosedJobList ,getWorkingJobs,
} from "../../actions/Employee/AppliedJobs";


function Employee_Applied_jobs(props) {

  useEffect(() => {
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    props.getWorkingJobs({
      employee_id : localStorage.getItem('employee_id'),
      page_no : 0,
      limit : 10
    })
  }, []);

  useState(() => {
    // if (show_alert) {

    // }
  })

  return (
    <React.Fragment>
      <div className="container-fluid">
        <Header />
        <section class="row main-content">
          <div className="container">
            <Employee_navtab />
            {
              <Alert
                show={props.show_alert}
                variant={props.varient}
                dismissible
                onClose={() => props.setFieldValues('show_alert', false)}
              >
                <strong>
                  {props.varient == "success"
                    ? "Success!"
                    : "Error!"}
                </strong>{" "}
                {props.showMsg}
              </Alert>
            }
            {props.grid_show == true ? (
              <ApplyJobGrid />
            ) : (
                <ApplyJobList />
              )}


          </div>
        </section>
      </div>
    </React.Fragment>
  );
};


const mapStateToProps = (state, ownProps) => {
  return {
    show: state.Appliedjob.show_login,
    grid: state.Appliedjob.grid_active,
    list: state.Appliedjob.list_active,
    grid_show: state.Appliedjob.grid,
    list_show: state.Appliedjob.list,
    job_list: state.Appliedjob.job_list,
    closed_job: state.Appliedjob.closed_jobs_list,
    show_alert: state.Appliedjob.show_alert,
    showMsg: state.Appliedjob.showMsg,
    sort_asc: state.Appliedjob.sort_asc,
    status: state.Appliedjob.active_status,
    varient: state.Appliedjob.varient,
    searchDisplay: state.Appliedjob.searchDisplay


    // categories: state.Home.categories
  };

};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setFieldValues: (f, v) => dispatch(AppliedJob(f, v)),
    postedJobListAction: (input) => dispatch(Applied_job_list(input)),
    closedJobListAction: (input) => dispatch(AppliedClosedJobList(input)),
    getWorkingJobs : (data) => dispatch(getWorkingJobs(data))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Employee_Applied_jobs);

import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import Header from "../Common/App/AppHeader";
import $, { data } from "jquery"
import * as actions from '../../actions/Employee/Offers';
import moment from 'moment';
import Alert from "react-bootstrap/Alert";
import ConfirmationPopup from './ConfirmationPopup';

class Offers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            application_id:''
        }
    }

    componentDidMount() {
        let THIS = this
        $(document).ready(function(){
            let removingElament = document.getElementById("custom_app_style");
            if (removingElament !== null) {
                removingElament.remove()
            }
            const elem2 = document.createElement("link");
            elem2.rel = "stylesheet"
            elem2.type = "text/css"
            elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
            elem2.id = "design_app_style"
            elem2.async = true;
        });
        let employee_id = localStorage.getItem('employee_id')
            this.props.getOffers({
                employee_id : employee_id
            });

            this.props.getAcceptedOffers({
                employee_id : employee_id
            })
        }

    componentDidUpdate() {
        let THIS = this        
        if (this.props.status === 1 || this.props.status ===2) {
            // setTimeout(function() {
            //     THIS.props.setShow(false)
            // }, 5000)
        }
    }
    
    render() {
        
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col">
                    <ul className="nav nav-tabs">
                    <li>
                        <a className="active" data-toggle="tab" href="#offers">
                        Offers
                        <span className="badge">{this.props.offers && this.props.offers.length}</span>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#accepted">
                        Accepted
                        <span className="badge">{
                            this.props.acceptedOffersList && 
                            this.props.acceptedOffersList.length
                        }</span>
                        </a>
                    </li>
                    </ul>
                    {/* <div className="df-ac">
                    <button className="btn btn-gray ico mr-3">
                        <img src="/assets/images/app/search-icon-dark.svg" alt="icon" />
                    </button>
                    <button className="btn btn-gray ico mr-3">
                        <img src="/assets/images/app/sort-icon.svg" alt="icon" />
                    </button>
                    <div className="btn-set mr-0">
                        <a className="active" href="javascript:;">
                        <img src="/assets/images/app/grid-icon.svg" alt="icon" />
                        </a>
                        <a href="javascript:;">
                        <img src="/assets/images/app/list-icon.svg" alt="icon" />
                        </a>
                    </div>
                    </div> */}
                </div>
                <div className="col-12">
                    <div className="tab-content">
                    {
                        <Alert
                        show={this.props.show}
                        variant={this.props.varient}
                        dismissible
                        onClose={() => this.props.setShow(false)}
                        >
                        <strong>
                        {
                            this.props.status === 1 ? "Success!" 
                            : this.props.status === 3 ? "Info!"
                            :"Error!"
                        }
                        </strong>{" "}
                        {this.props.showMsg}
                        </Alert>
                    }
                    <div id="offers" className="tab-pane fade in show active">

                        <div className="row dashboard-snip-sec">
                        { this.props.offers && this.props.offers.length > 0 &&
                          this.props.offers.map((i, k) => {
                                return(
                                <div className="col-lg-4 col-md-6" key = {k}>
                                <div className="r-job-item job-offer">
                                <div className="dropdown more dd-active">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                <ul className="list-unstyled">
                                    <li><Link
                                    to = {`view-job-offer/${i.application_status}/${i.id}`}
                                    >View Job Offer</Link></li>
                                </ul>
                                </div>
                            </div>
                            <h6 className="mb-1 pr-4">
                                {i.job &&
                                i.job.industry_type
                                }
                            </h6>
                            <p className="mb-4 pr-4">
                                {
                                    i.job &&
                                    i.job.employer &&
                                    i.job.employer.company_name
                                }
                            </p>
                            <div className="row mb-1">
                                <div className="col-6"><p>Location</p></div>
                                <div className="col-6"><span>
                                    {/* 22 June 2020 */}
                                    {
                                    i.job &&
                                    i.job.job_location &&
                                    i.job.job_location
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-1">
                                <div className="col-6"><p>Position</p></div>
                                <div className="col-6"><span>
                                    {/* 22 June 2020 */}
                                    {
                                    i.job &&
                                    i.job.job_position &&
                                    i.job.job_position
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-1">
                                <div className="col-6"><p>Start Date</p></div>
                                <div className="col-6"><span>
                                    {/* 22 June 2020 */}
                                    {
                                    i.job &&
                                    i.job.job_location &&
                                    moment(new Date(i.job.start_date)).format('DD MMMM YYYY')
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>End Date</p></div>
                                <div className="col-6"><span>
                                {
                                    i.job &&
                                    i.job.end_date &&
                                    moment(new Date(i.job.end_date)).format('DD MMMM YYYY')
                                }
                                </span></div>
                            </div>
                            {/* <div className="row mb-2">
                                <div className="col-6"><p>{i.job && i.job.salary_based} </p></div>
                                <div className="col-6"><span>RM {i.job && new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.amount)
                                        ? '0.00':i.job.amount)}</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>No of Hour</p></div>
                                <div className="col-6">
                                <span>
                                    {
                                        i.job && i.job.number_of_hours
                                    } {" "} Hours
                                </span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>No of Days</p></div>
                                <div className="col-6"><span>{i.job && i.job.number_of_days} 
                                {" "}days</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>EPF (11%)</p></div>
                                <div className="col-6"><span>RM
                                    {
                                        // console.log(i.job.job_salaries[0], 'i.job.job_salaries')
                                    i.job && i.job.job_salaries.length > 0 && 
                                    new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(i.job.job_salaries[0].employee_epf)
                                    ? '0.00':i.job.job_salaries[0].employee_epf)
                                    
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Socso (0.50%)</p></div>
                                <div className="col-6"><span>RM{
                                    i.job && 
                                    i.job.job_salaries.length > 0 && 
                                    new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(i.job.job_salaries[0].employee_socso)
                                    ? '0.00':i.job.job_salaries[0].employee_socso)
                                    
                                }</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Eis (0.50%)</p></div>
                                <div className="col-6"><span>RM
                                    {
                                        i.job && 
                                        i.job.job_salaries.length > 0 && 
                                        new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.job_salaries[0].employer_eis)
                                        ? '0.00':i.job.job_salaries[0].employer_eis)
                                        
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-4">
                                <div className="col-6"><p>Total Pay</p></div>
                                <div className="col-6"><span><strong>RM
                                    {
                                        i.job && 
                                        i.job.job_salaries.length > 0 && 
                                        new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.job_salaries[0].reduced_salary_for_employee)
                                        ? '0.00':i.job.job_salaries[0].reduced_salary_for_employee)
                                        
                                    }
                                </strong></span></div>
                            </div> */}
                            <div className="row">
                                <div className="col-6">
                                <button className="btn btn-red fs-13 w-100 m-0"
                                onClick = {() => {

                                    this.setState({
                                        application_id:i.id
                                    })
                                    this.props.confirmPopupShow(true)
                                    // this.props.rejectOffers({
                                    //     application_id:i.id,
                                    // })    
                                }}
                                >Reject Offer</button>
                                </div>
                                <div className="col-6">
                                <button className="btn btn-blue fs-13 w-100 m-0"
                                onClick = { () => {
                                    this.props.acceptedOffers({
                                        application_id:i.id,
                                        // job_id:29,
                                        // employee_id:43,
                                        status_code:4,
                                    })    
                                    
                                }
                                 }
                                >Accept Offer</button>
                                </div>
                            </div>
                            </div>
                            </div>      
                            )
                          })
                        }  
                        </div>
                    </div>
                    <div id="accepted" className="tab-pane fade">
                        <div className="row dashboard-snip-sec">
                        {
                            this.props.acceptedOffersList && 
                            this.props.acceptedOffersList.length > 0 &&
                            this.props.acceptedOffersList.map((i,k) => {
                            return (
                                <div className="col-lg-4 col-md-6" key = {k}>
                                <div className="r-job-item job-offer">
                                <div className="dropdown more dd-active">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                <ul className="list-unstyled">
                                    <li><Link
                                    to = {`view-job-offer/${i.application_status}/${i.id}`}
                                    >View Job</Link></li>
                                </ul>
                                </div>
                            </div>
                            <h6 className="mb-1 pr-4">
                                {i.job &&
                                i.job.industry_type
                                }
                            </h6>
                            <p className="mb-4 pr-4">
                                {
                                    i.job &&
                                    i.job.employer &&
                                    i.job.employer.company_name
                                }
                            </p>
                            <div className="row mb-1">
                                <div className="col-6"><p>Location</p></div>
                                <div className="col-6"><span>
                                    {/* 22 June 2020 */}
                                    {
                                    i.job &&
                                    i.job.job_location &&
                                    i.job.job_location
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-1">
                                <div className="col-6"><p>Position</p></div>
                                <div className="col-6"><span>
                                    {/* 22 June 2020 */}
                                    {
                                    i.job &&
                                    i.job.job_position &&
                                    i.job.job_position
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-1">
                                <div className="col-6"><p>Start Date</p></div>
                                <div className="col-6"><span>
                                    {/* 22 June 2020 */}
                                    {
                                    i.job &&
                                    i.job.start_date &&
                                    moment(new Date(i.job.start_date)).format('DD MMMM YYYY')
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>End Date</p></div>
                                <div className="col-6"><span>
                                {
                                    i.job &&
                                    i.job.end_date &&
                                    moment(new Date(i.job.end_date)).format('DD MMMM YYYY')
                                }
                                </span></div>
                            </div>
                            {/* <div className="row mb-2">
                                <div className="col-6"><p>{i.job && i.job.salary_based} </p></div>
                                <div className="col-6"><span>RM {i.job && new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.amount)
                                        ? '0.00':i.job.amount)}</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>No of Hour</p></div>
                                <div className="col-6">
                                <span>
                                    {
                                        i.job && i.job.number_of_hours
                                    } {" "} Hours
                                </span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>No of Days</p></div>
                                <div className="col-6"><span>{i.job && i.job.number_of_days} 
                                {" "}days</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>EPF (11%)</p></div>
                                <div className="col-6"><span>RM
                                    {
                                        // console.log(i.job.job_salaries[0], 'i.job.job_salaries')
                                    i.job && i.job.job_salaries.length > 0 && 
                                    new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.job_salaries[0].employee_epf)
                                        ? '0.00':i.job.job_salaries[0].employee_epf)
                                    
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Socso (0.50%)</p></div>
                                <div className="col-6"><span>RM{
                                    i.job && 
                                    i.job.job_salaries.length > 0 && 
                                    new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.job_salaries[0].employee_socso)
                                    ? '0.00':i.job.job_salaries[0].employee_socso)

                                }</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Eis (0.50%)</p></div>
                                <div className="col-6"><span>RM
                                    {
                                        i.job && 
                                        i.job.job_salaries.length > 0 && 
                                        new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.job_salaries[0].employer_eis)
                                    ? '0.00':i.job.job_salaries[0].employer_eis)
                                        
                                    }
                                </span></div>
                            </div>
                            <div className="row mb-4">
                                <div className="col-6"><p>Total Pay</p></div>
                                <div className="col-6"><span><strong>RM
                                    {
                                        i.job && 
                                        i.job.job_salaries.length > 0 && 
                                        new Intl.NumberFormat('en-US', 
                                        {style: 'decimal', minimumFractionDigits: 2}).
                                        format(isNaN(i.job.job_salaries[0].reduced_salary_for_employee)
                                    ? '0.00':i.job.job_salaries[0].reduced_salary_for_employee)
                                        
                                    }
                                </strong></span></div>
                            </div> */}
                            <div className="row">
                                <div className="col-6">
                                <Link className="btn btn-gray fs-13 w-100 m-0"
                                to = {`view-job-offer/${i.application_status}/${i.id}`}
                                >View</Link>
                                </div>
                                <div className="col-6">
                                <button className="btn btn-blue fs-13 w-100 m-0"
                                onClick = {() => {
                                    this.props.ConfirmOffer({
                                        application_id:i.id
                                    })
                                }}
                                >{i.application_status === 'offer-accepted' ? 'Confirmation': 'Confirmed'}</button>
                                </div>
                            </div>
                            </div>
                            </div>      
                            )
                            }) 
                        }
                        
                        {/* <div className="col-lg-4 col-md-6">
                            <div className="r-job-item job-offer">
                            <div className="dropdown more dd-active">
                                <button className="btn dropdown-toggle" type="button" id="more-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="/assets/images/app/more-btn.svg" />
                                </button>
                                <div className="dropdown-menu" aria-labelledby="more-menu">
                                <ul className="list-unstyled">
                                    <li><a href="javascript:;">View Job</a></li>
                                </ul>
                                </div>
                            </div>
                            <h6 className="mb-1 pr-4">F&amp;B</h6>
                            <p className="mb-4 pr-4">Nissi Fresh Store</p>
                            <div className="row mb-1">
                                <div className="col-6"><p>Start Date</p></div>
                                <div className="col-6"><span>22 June 2020</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Start Date</p></div>
                                <div className="col-6"><span>22 June 2020</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Hourly Rate</p></div>
                                <div className="col-6"><span>RM 10</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>No of Hour</p></div>
                                <div className="col-6"><span>4 Hrs</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>No of Days</p></div>
                                <div className="col-6"><span>4</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>EPF (11%)</p></div>
                                <div className="col-6"><span>RM17.4</span></div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-6"><p>Socso (0.50%)</p></div>
                                <div className="col-6"><span>RM0.80</span></div>
                            </div>
                            <div className="row mb-4">
                                <div className="col-6"><p>Total Pay</p></div>
                                <div className="col-6"><span><strong>RM141.60</strong></span></div>
                            </div>
                            <div className="row">
                                <div className="col-6">
                                <button className="btn btn-gray fs-13 w-100 m-0">View</button>
                                </div>
                                <div className="col-6">
                                <button className="btn btn-blue fs-13 w-100 m-0">Confirmation</button>
                                </div>
                            </div>
                            </div>
                        </div> */}
                        </div> 
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>

            {/* Main Wrapper Ends here */}
            <ConfirmationPopup
                application_id= {this.state.application_id}
            />
            </>            
            </div>
            
            </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        offers:state.Offers.offers,
        acceptedOffersList :state.Offers.acceptedOffersList,
        status:state.Offers.status,
        show:state.Offers.show, 
        varient:state.Offers.varient,
        showMsg:state.Offers.showMsg,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getOffers : (data) => dispatch(actions.getOffers(data)),
        getAcceptedOffers : (data) => dispatch(actions.getAcceptedOffers(data)),
        setShow : (data) => dispatch(actions.setShow(data)),
        acceptedOffers : (data) => dispatch(actions.acceptedOffers(data)),
        rejectOffers : (data) => dispatch(actions.rejectOffers(data)),
        ConfirmOffer : (data) => dispatch(actions.ConfirmOffer(data)),
        confirmPopupShow : (data) => dispatch(actions.confirmPopupShow(data))
    }
};

const offers = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Offers);

export default offers;

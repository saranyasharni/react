import React, { useEffect } from "react";
import Header from "../Common/App/AppHeader";
import Employee_navtab from "../Employee/EmployeeAppliedJobs/employee_navtab";

function Employee_applied_job_list() {
  useEffect(() => {
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
  }, []);
  return (
    <div className="container-fluid">
      <Header />
      <section class="row main-content">
        <div className="container">
          <Employee_navtab />
          <div class="col-12">
            <div class="tab-content">
              <div id="active" class="tab-pane fade in show active">
                <div class="row dashboard-snip-sec job-list">
                  <div class="col-12">
                    <div class="job-snippet">
                      <div class="img-wrap">
                        <img
                          class="img-fluid"
                          src="/assets/images/app/job-snip-img.jpg"
                          alt="img"
                        />
                        <span class="date badge">Thu 16 - Sun 20</span>
                      </div>
                      <div class="r-job-item">
                        <div class="dropdown more">
                          <button
                            class="btn dropdown-toggle"
                            type="button"
                            id="more-menu"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                          >
                            <img src="/assets/images/app/more-btn.svg" />
                          </button>
                          <div
                            class="dropdown-menu"
                            aria-labelledby="more-menu"
                          >
                            <ul class="list-unstyled">
                              <li>
                                <a href="javascript:;">Chat</a>
                              </li>
                              <li>
                                <a
                                  href="javascript:;"
                                  data-toggle="modal"
                                  data-target="#share-modal"
                                >
                                  Share
                                </a>
                              </li>
                              <li>
                                <a href="javascript:;" class="red">
                                  Decline
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <h6>F&B</h6>
                            <span class="job-type text-truncate">
                              Nissi Fresh Store
                            </span>
                            <p class="text-truncate">Salary $13 Hourly</p>
                            <span class="location text-truncate d-block">
                              <img
                                src="/assets/images/app/location-pin-icon.svg"
                                alt="icon"
                              />
                              St Andrews Lane, London, UK
                            </span>
                          </div>
                          <div class="col-md-4 text-left text-md-right job-l-right">
                            <p class="expire">Job Expires in 10 days</p>
                            <button class="btn btn-blue px-4">More Info</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="job-snippet">
                      <div class="img-wrap">
                        <img
                          class="img-fluid"
                          src="/assets/images/app/job-snip-img-1.jpg"
                          alt="img"
                        />
                        <span class="date badge">Thu 16 - Sun 20</span>
                      </div>
                      <div class="r-job-item">
                        <div class="dropdown more">
                          <button
                            class="btn dropdown-toggle"
                            type="button"
                            id="more-menu"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                          >
                            <img src="/assets/images/app/more-btn.svg" />
                          </button>
                          <div
                            class="dropdown-menu"
                            aria-labelledby="more-menu"
                          >
                            <ul class="list-unstyled">
                              <li>
                                <a href="javascript:;">Chat</a>
                              </li>
                              <li>
                                <a
                                  href="javascript:;"
                                  data-toggle="modal"
                                  data-target="#share-modal"
                                >
                                  Share
                                </a>
                              </li>
                              <li>
                                <a href="javascript:;" class="red">
                                  Decline
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <h6>F&B</h6>
                            <span class="job-type text-truncate">
                              Nissi Fresh Store
                            </span>
                            <p class="text-truncate">Salary $13 Hourly</p>
                            <span class="location text-truncate d-block">
                              <img
                                src="/assets/images/app/location-pin-icon.svg"
                                alt="icon"
                              />
                              St Andrews Lane, London, UK
                            </span>
                          </div>
                          <div class="col-md-4 text-left text-md-right job-l-right">
                            <p class="expire">Job Expires in 10 days</p>
                            <button class="btn btn-blue px-4">More Info</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="job-snippet">
                      <div class="img-wrap">
                        <img
                          class="img-fluid"
                          src="/assets/images/app/job-snip-img-2.jpg"
                          alt="img"
                        />
                        <span class="date badge">Thu 16 - Sun 20</span>
                      </div>
                      <div class="r-job-item">
                        <div class="dropdown more">
                          <button
                            class="btn dropdown-toggle"
                            type="button"
                            id="more-menu"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                          >
                            <img src="/assets/images/app/more-btn.svg" />
                          </button>
                          <div
                            class="dropdown-menu"
                            aria-labelledby="more-menu"
                          >
                            <ul class="list-unstyled">
                              {/* <li>
                                <a href="javascript:;">Chat</a>
                              </li> */}
                              <li>
                                <a
                                  href="javascript:;"
                                  data-toggle="modal"
                                  data-target="#share-modal"
                                >
                                  Share
                                </a>
                              </li>
                              <li>
                                <a href="javascript:;" class="red">
                                  Decline
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <h6>F&B</h6>
                            <span class="job-type text-truncate">
                              Nissi Fresh Store
                            </span>
                            <p class="text-truncate">Salary $13 Hourly</p>
                            <span class="location text-truncate d-block">
                              <img
                                src="/assets/images/app/location-pin-icon.svg"
                                alt="icon"
                              />
                              St Andrews Lane, London, UK
                            </span>
                          </div>
                          <div class="col-md-4 text-left text-md-right job-l-right">
                            <p class="expire">Job Expires in 10 days</p>
                            <button class="btn btn-blue px-4">More Info</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="closed" class="tab-pane fade">
                <div class="empty-job">
                  <img src="/assets/images/app/undraw-empty.svg" alt="image" />
                  <p>There's nothing here.</p>
                </div>
              </div>
            </div>
          </div>

          <div class="map-sec">
            <div class="col-12 hdr-row">
              <h2>Map</h2>
              <a class="close" href="javascript:;">
                <img src="/assets/images/app/cross-black.svg" alt="icon" />
              </a>
            </div>
            <div class="col-12 px-0">
              <img
                class="img-fluid w-100"
                src="/assets/images/app/map-img.png"
                alt="Map"
              />
            </div>
          </div>
        </div>
      </section>

      <div
        class="modal fade custom-modal"
        id="share-modal"
        tabindex="-1"
        role="dialog"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Share job</h5>
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <img
                  class="img-fluid"
                  src="images/modal-close-icon.svg"
                  alt="icon"
                />
              </button>
            </div>
            <div class="modal-body pt-0">
              <div class="col-12">
                <div class="row job-list">
                  <div class="job-snippet profile-snippet">
                    <div class="img-wrap">
                      <img
                        class="img-fluid"
                        src="images/app/job-snip-img.jpg"
                        alt="img"
                      />
                      <span class="date badge">Thu 16 - Sun 20</span>
                      <span class="new badge">New</span>
                      <a href="javascript:;" class="favorite">
                        <img src="images/app/heart-icon.svg" alt="icon" />
                      </a>
                    </div>
                    <div class="r-job-item">
                      <div class="row">
                        <div class="col-md-12">
                          <h6>F&B</h6>
                          <span class="job-type text-truncate">
                            Nissi Fresh Store
                          </span>
                          <p class="text-truncate mt-0">Salary $13 Hourly</p>
                          <span class="location text-truncate d-block mt-3">
                            <img
                              src="images/app/location-pin-icon.svg"
                              alt="icon"
                            />
                            St Andrews Lane, London, UK
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 job-share px-0">
                <h6>Share with</h6>
                <ul class="list-inline">
                  <li class="list-inline-item">
                    <a href="javascript:;">
                      <img src="images/app/copy-link-icon.svg" alt="icon" />
                      Copy Link
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="javascript:;">
                      <img src="images/app/fb-icon.svg" alt="icon" />
                      Facebook
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="javascript:;">
                      <img src="images/app/skype-icon.svg" alt="icon" />
                      Skype
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="javascript:;">
                      <img src="images/app/twitter-icon.svg" alt="icon" />
                      Twitter
                    </a>
                  </li>
                </ul>
              </div>
              <div class="col-12 text-right mt-2 px-0">
                <button class="btn btn-gray">Cancel</button>
                <button class="btn btn-blue">Share</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Employee_applied_job_list;

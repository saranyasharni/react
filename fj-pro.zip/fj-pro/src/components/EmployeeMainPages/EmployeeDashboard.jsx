import React, { useState, useEffect } from "react";
import Header from "../Common/App/AppHeader";
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import JobCard from '../Employee/Dashboard/JobCard';
import JobInfo from '../Employee/Dashboard/JobInfo';
import JobOffers from '../Employee/Dashboard/JobOffers';
// import { Dasboard, } from "../../actions/Employee/Dashboard";
import { setShow } from "../../actions/Employee/Offers";
import Alert from "react-bootstrap/Alert";
import NotifyModel from "../NotifyModel"
import $ from "jquery"

function EmployeeDashboard(props) {
  useEffect(() => {
    let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
      removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
    
    $(document).ready(function () {
      if (localStorage.notify_model) {
        // window.$('#notify-model').modal('show')
      }
    })
    
  }, []);

  useEffect(() => {
    if (props.varient === 'success' || props.varient === 'danger') {
      setTimeout(function() {
        props.setShow(false)
      }, 5000)
    }
  })
  
  return (
    <React.Fragment>
    <div className="container-fluid">
      <Header />

      {/* Main Content Starts here */}
      <section className="row main-content">
        <div className="container">
        {
            <Alert
              style = {{
                marginTop:'12px'
              }}
                show={props.show}
                variant={props.varient}
                dismissible
                onClose={() => props.setShow(false)}
            >
                <strong>
                    {props.varient == "success"
                        ? "Success!"
                        : "Error!"}
                </strong>{" "}
                {props.showMsg}
            </Alert>
          }
          <div className="row">
            <div className="col-12 hdr-row">
              <h1>Overview</h1>
              <Link to = "/employee-view-jobs" className="btn btn-blue">Seach Job</Link>
            </div>
          </div>
          <div className="row mb-5">
            <div className="col-md-8">
            <JobInfo />
            <JobCard />
            </div>
            <div className="col-md-4">
            <JobOffers />
            </div>
          </div>
        </div>
      </section>
      {/* Main Content Ends here */}

      {/* <JobInfo/>
        <JobCard/>
        <JobOffers/> */}
      <NotifyModel/>
    </div>
    </React.Fragment>
  );
}

const mapStateToProps = (state, ownProps) => {
  return {
    showMsg: state.Offers.showMsg,
    status: state.Offers.status,
    show:state.Offers.show,
    varient: state.Offers.varient,  
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setShow: (f, v) => dispatch(setShow(f, v)),
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeDashboard);

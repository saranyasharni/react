import React, { useEffect, useState } from "react";
import Header from "../Common/App/AppHeader.jsx";
import { connect } from 'react-redux';
import Grid from '../Employee/viewJob/viewJob_grid';
import List from '../Employee/viewJob/viewJob_list';
import HeaderTap from '../Employee/viewJob/viewJob_navtab';
import { View_Job, View_job_list, savedJobs} from "../../actions/Employee/viewJob";
import Alert from "react-bootstrap/Alert";

function EmployeeViewJobs(props) {
    const[state, setState] = useState({
        employee_id: localStorage.getItem('employee_id'),
        filter:0,
        filter_by:null,
        location:null,
        page_no:'0',
        limit:'50'
    })

    useEffect(() => {
        props.viewJobListAction(state);
        props.SavedJobs(state)
        let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
        // window.$(".selectpicker").selectpicker({
        //     size: 4
        // });
    }, []);
    
    useEffect(()=> {
        if (props.varient === "success" || props.varient === "danger") {
          setTimeout(function() {
            props.setFieldValues('show_alert', false)
          }, 5000)
        }
      })
    return (
        <React.Fragment>
            <div className="container-fluid">
                <Header />
                <section className="row main-content">
                    <div className="container">

                        <HeaderTap />
                        {
                            
                            <Alert
                                show={props.show_alert}
                                variant={props.varient}
                                dismissible
                                onClose={() => props.setFieldValues('show_alert', false)}
                            >
                                <strong>
                                    {props.varient === 
                                        "success"
                                        ? "Success!"
                                        : "Error!"
                                    }
                                </strong>{" "}
                                {props.showMsg}
                            </Alert>
                        }

                        {
                            
                        !props.viewStatuslist ? (
                            <Grid />
                        ) : (
                                <List />
                            )
                        }

                    </div>
                </section>
            </div>
        </React.Fragment>

    );
};

const mapStateToProps = (state, ownProps) => {
    return {
        show: state.Emp_View_Job.show_login,
        grid: state.Emp_View_Job.grid_active,
        list: state.Emp_View_Job.list_active,
        // grid_show: state.Emp_View_Job.grid,
        viewStatuslist: state.Emp_View_Job.viewStatuslist,      
        list_show: state.Emp_View_Job.list,
        job_list: state.Emp_View_Job.job_list,
        closed_job: state.Emp_View_Job.closed_jobs_list,
        show_alert: state.Emp_View_Job.show_alert,
        showMsg: state.Emp_View_Job.showMsg,
        sort_asc: state.Emp_View_Job.sort_asc,
        status: state.Emp_View_Job.active_status,
        varient: state.Emp_View_Job.varient,
        searchDisplay: state.Appliedjob.searchDisplay
        // categories: state.Home.categories
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(View_Job(f, v)),
        postedJobListAction: (input) => dispatch(View_job_list(input)),
        viewJobListAction: (data) => dispatch(View_job_list(data)),
        SavedJobs : (data) => dispatch(savedJobs(data))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeViewJobs);

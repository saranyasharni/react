import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { Link } from "react-router-dom";
import Header from "../Common/App/AppHeader";
import ChatLeft from "../Employee/Chats/ChatLeft";
import $ from "jquery"
import * as actions from '../../actions/Employer/Chat';
import config from '../../actions/Common/Api_Links'
import ChatRight from '../Employee/Chats/ChatRight';
import { io } from 'socket.io-client';
const endPoint = "http://ec2-54-169-157-197.ap-southeast-1.compute.amazonaws.com:3001/"
const socket = io(endPoint)
class Chat extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chatContentLists : [], 
            chatContent : [], 
            chatRoomId_current : '',
            chatProfileInfo: []
        }
    }

    componentDidMount() {
        let THIS = this
        $(document).ready(function(){
            // require("../../assets/css/app-style.css");
            let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    const elem2 = document.createElement("link");
    elem2.rel = "stylesheet"
    elem2.type = "text/css"
    elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
    // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
    elem2.id = "design_app_style"
    elem2.async = true;
    document.head.appendChild(elem2);
            $(".chat-list .card-row").click(function(){
                $(".chat-right").addClass("show");
            });
            $(".chat-right .hdr-row .chat-back").click(function() {
                $(".chat-right").removeClass("show");
            });
            
            socket.on("connect", () => {
                let chat_employee_id = localStorage.getItem('employee_id')
                // console.log(socket.id, 'first check'); // x8WIv7-mJelg7on_ALbx
                if (!window.location.pathname.split('/')[3]) {
                    // alert('if')
                    socket.emit('openChat', {user_type:'employee', user_id:chat_employee_id})

                    socket.on('chatRoomsList', (chatRoomList)=>{
                        // console.log(chatRoomList, 'chatRoomList')
        
                        THIS.setState({
                            chatContentLists : chatRoomList
                        })    
                        
                    });
                    socket.on('chatRoomId', (chatRoomId, ProfileData)=>{
        
                        if (chatRoomId.messages) {
                            THIS.props.setChatData(
                                chatRoomId.messages
                            )
                            THIS.props.setProfileInfo(
                                chatRoomId.profileData
                            )
                            THIS.props.setChatRoomId(
                                chatRoomId.chatRoomId
                            )
                        }
                    
                })
                } else {
                    // alert('ifele')
                    socket.emit('chat', ({employee_id: chat_employee_id, employer_id: window.location.pathname.split('/')[3], user_type: 'employee'}));

                socket.on('chatRoomsList', (chatRoomList)=>{
                    console.log(chatRoomList, 'chatRoomList')
       
                    THIS.setState({
                        chatContentLists : chatRoomList
                    })    
                    
                });
                socket.on('chatRoomId', (chatRoomId, ProfileData)=>{
       
                    if (chatRoomId.messages) {
                        THIS.props.setChatData(
                            chatRoomId.messages
                        )
                        THIS.props.setProfileInfo(
                            chatRoomId.profileData
                        )
       
                        THIS.props.setChatRoomId(
                            chatRoomId.chatRoomId
                        )
                    }
                    
                })
                }
                
                
            });
        
       
    });
    }

    componentDidUpdate() {
        // let THIS = this
        $(document).ready(function(){
            
            $(".chat-list .card-row").click(function(){
                $(".chat-right").addClass("show");
            });
            $(".chat-right .hdr-row .chat-back").click(function(){
                $(".chat-right").removeClass("show");
            });
            // let chat_employee_id = localStorage.getItem('employee_id')
            // socket.emit('chat', ({employee_id: chat_employee_id, employer_id: window.location.pathname.split('/')[3], user_type: 'employee'}));

            //     socket.on('chatRoomsList', (chatRoomList)=>{
            //         console.log(chatRoomList, 'chatRoomList')
       
            //         THIS.setState({
            //             chatContentLists : chatRoomList
            //         })    
                    
            //     });
            //     socket.on('chatRoomId', (chatRoomId, ProfileData)=>{
       
            //         if (chatRoomId.messages) {
            //             THIS.props.setChatData(
            //                 chatRoomId.messages
            //             )
            //             THIS.props.setProfileInfo(
            //                 chatRoomId.profileData
            //             )
       
            //             THIS.props.setChatRoomId(
            //                 chatRoomId.chatRoomId
            //             )
            //         }
                    
            //     })
        })    
    }
    
    render() {
        
        return (
            <>
            <div className="container-fluid">
            <Header/>
            <>
            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
                {
                    console.log(this.state.chatProfileInfo, 'chatContentLists'),
                    this.state.chatContentLists ? (
                    <>
                    <div className="row">
                        <div className="col-12 hdr-row">
                            <h1>Messages</h1>
                        </div>
                        <div className="col-12">
                            <div className="chat-container">
                            <ChatRight
                            chatLists = {this.state.chatContentLists}
                            />
                            <ChatLeft
                            chatProfileInfo = {this.state.chatProfileInfo}
                            // chatRoomId_current= {this.state.chatRoomId_current}
                            />
                            </div>
                        </div>
                    </div>
                    </>
                    ) : (
                    <>
                    <div className="nodata-wrap">
                    <img className="no-data-img" src="/assets/images/app/undraw-publish.svg" alt="image" />
                    <p>No Chats Started Yet</p>
                    {/* <Link to = {`/create/job-post`}
                    className="btn btn-blue" href="hire-create-post-job.html">+ Post a Job</Link>  */}
                    </div>
                    </>
                )
                }
            </div>
            </section>

            {/* Main Wrapper Ends here */}
            </>            
            </div>
            
            </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    
    return {
        
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setChatData : (data) => dispatch(actions.setChatData(data)),        
        setChatRoomId : (data) => dispatch(actions.setChatRoomId(data)),
        setProfileInfo : (data) => dispatch(actions.setProfileInfo(data))
    }
};

const chat = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Chat);

export default chat;





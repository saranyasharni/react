import React, { useEffect } from "react";
import Header from "../Common/App/AppHeader.jsx";
import { connect } from 'react-redux';
import $ from "jquery";
import { Profile, AddNewField, UpdateProfile, UploadEmployeeProfile, getEmployeeProfile 
} from "../../actions/Employee/MyProfile";
import Alert from "react-bootstrap/Alert";
import Loader from "../Helper/Loader"
import Dropzone from "react-dropzone";
import Autocomplete from "react-google-autocomplete";
import {
    getIndustries, 
    getPositions,
    getSkills,
    getBankS,
    getLanguages,
    getQualifications,
    getPassoutYear
  } from "../../actions/Home"
function MyProfile (props) {   
    useEffect(() => {
        props.getSkills()
        props.getBankS()
        props.getIndustries()
        props.getLanguages()
        props.getPassoutYear()
        props.getQualifications()
    },[])
    useEffect(() => {
        if (props.dummy === 0) 
        props.defaultSetValues();
        let removingElament = document.getElementById("custom_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "design_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
        $(document).ready(function () {
            window.$('.selectpicker').selectpicker();
            window.jQuery(".input-group.date").datepicker({
              format: "dd/mm/yyyy",
              todayHighlight: true,
              autoclose:true
            //   endDate: "+0d",
            })
            // .off("change")
            // .change((e) => {
            //     alert('h')
            //     // THIS.props.changeInput("dob", e.target.value);
            // });
        })
        $(document).ready(function () {
        $('input.example1').on('change', function() {
        
            $('input.example1').not(this).prop('checked', false);  
        });
        })
        },[props.dummy]);

        useEffect(() => {
        if (props.varient === "success" || props.varient === "danger") {
            // setTimeout(function() {
            //     props.setFieldValues('show_alert', false)
            // }, 3000)
        }
        
        $(document).ready(function () {
            window.$('.selectpicker').selectpicker('refresh');
            $('input.example1').on('change', function() {
        
                $('input.example1').not(this).prop('checked', false);  
            });
            window.jQuery(".input-group.date").datepicker({
                format: "dd/mm/yyyy",
                todayHighlight: true,
                autoclose:true
              //   endDate: "+0d",
              })
            //   .off("change")
            //   .change((e) => {
            //     //   alert(0)
            //     qualificationChangeFunc(e,1,"year_completed")
            //     // THIS.props.changeInput("dob", e.target.value);
            // });
        
        })
        })

      const qualificationChangeFunc =(e,idx,val)=>{
        let arr =[...props.qualifications];
        arr[idx][val] = e.target.value;
        
        props.setFieldValues("qualifications",arr);
      };

      const langChangeFunc =(e,idx,val)=>{
          
        let arr =[...props.language_skill];
        if (e === "1" || e === "0") {
            arr[idx][val] = e
          } else if (e === "") {
            arr[idx][val] = ""
          }  else {
            arr[idx][val] = e.target.value
          }

        // arr[idx][val] = e.target.value;
        props.setFieldValues("language_skill",arr);
      };

      const skillChangeFunc =(e,idx,val)=>{
        let arr = [...props.skills];
        arr[idx][val] = e.target.value;
        // console.log(arr, 'arr')
        props.setFieldValues("skills",arr);
      };

      const workExperienceChangeFunc = (e,idx,val) => {
        // console.log(e.target.checked, 'val')
        let arr = [...props.working_experience];
        if (e.target.checked) {
            arr.map((i,k)=>{
                i.current_company = "no"
            })
            arr[idx][val] = e.target.checked ? "yes" : "no";
        } else {
            arr[idx][val] = e.target.value;
        }
        
        props.setFieldValues("working_experience",arr);
      };

      const handleDropzone = (files) => {
        if (files) {
            props.UploadEmployeeProfile("resume_file", files[0]);  
        }
        
      }
      const calculateExp = () => {
        let arr = props.working_experience
      
        let arr_length = props.working_experience.length-1
        let splitstart = arr[0].start_date.split('/')
        let newStart = splitstart[2]+'-'+splitstart[1]+'-'+splitstart[0]
        
        let splitEnd = arr[arr_length].end_date.split('/')
        let newEnd = splitEnd[2]+'-'+splitEnd[1]+'-'+splitEnd[0]
        
        let df = new Date(newStart)
        let dt = new Date(newEnd) 
        var startMonth = df.getFullYear() * 12 + df.getMonth();  
        var endMonth = dt.getFullYear() * 12 + dt.getMonth();
        var monthInterval = (endMonth - startMonth);
        
        var yearsOfExperience = Math.floor (monthInterval / 12);
        var monthsOfExperience = monthInterval % 12;  
        let total_exp 
        if (yearsOfExperience <= 0) {
          let months = dt.getMonth() - df.getMonth() + 
          (12 * (dt.getFullYear() - df.getFullYear()))
          total_exp = months + `${months === 1? ' month' : ' months'} `
        } else {
          total_exp = yearsOfExperience +(yearsOfExperience === 1 ? ' year':' years') + ' ' +
          monthsOfExperience + (monthsOfExperience === 1 ? ' month' : ' months')
        } 
        // console.log(total_exp, 'total_exp')
        props.setFieldValues("total_expereience",total_exp)
        
    }
    const deleteItem = (index, param) => {
      
        if (param === 'skills') {
            let arr = [...props.skills];
            arr.splice(index,1)
            props.setFieldValues("skills",arr);
        }
        if (param === 'lang') {
            let arr =[...props.language_skill];
            arr.splice(index,1)
            props.setFieldValues("language_skill",arr);
        }
        if (param === 'experience') {
            let arr = [...props.working_experience];
            arr.splice(index,1)
            props.setFieldValues("working_experience",arr);
        }
    }
    const setLocation = (place) => {
        let length = place.address_components &&
        place.address_components.length > 0 ?
        place.address_components.length-1 :""
        props.setFieldValues("address", place.formatted_address)
        props.setFieldValues("city",place.address_components && place.address_components.length >0 &&place.address_components[length-2].long_name)
        if (place.address_components && place.address_components.length >0 && place.address_components[length].types[0] ==="postal_code") {
            props.setFieldValues("postal_code", parseInt(place.address_components[length].long_name))
            
          } else {
            props.setFieldValues("postal_code", "")
          } 
        
    }
    const updateFunc =()=>{
        // console.log(props.private, 'props.private')
        let input ={
            name:props.full_name,
            mobile:props.mobile_no,
            email:props.email,
            address:props.address,
            city:props.city,
            postal_code:props.postal_code,
            about:props.about,
            resume_desc:props.resume,
            resume_file:props.resume_file,
            resume_setting:props.privacy,
            total_exp:props.total_expereience,
            language_skill:props.language_skill,
            education_details:props.qualifications,
            profile_img: props.profile_img,
            employee_id:localStorage.getItem('employee_id'),
            skills:props.skills,
            work_experience:props.working_experience,
            bank_name:props.bank_name,
            bank_account_number:props.bank_account_number,
            passport_no : props.passport_no,
            epf:props.epf,
            socso:props.socso,
            eis:props.eis
        }
        props.UpdateProfile(input)
        };
        return (
            <>
            <div className="container-fluid">
            <Header />
            {/* Main Content Starts here */}
            <section className="row main-content">
            {/* {console.log(props.working_experience, 'props.total_expereience')} */}
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row">
            
                    <h1>My Profile</h1>
                   
                </div>
                <div className="col-12 mb-5">
                {
                <Alert
                show={props.show_alert}
                variant={props.varient}
                dismissible
                onClose={() => props.setFieldValues('show_alert', false)}
                >
                <strong>
                    {props.varient == "success"
                    ? "Success!"
                    : "Error!"}
                </strong>{" "}
                {props.showMsg}
                </Alert>
                }
                    <div className="snippet-box p-3 p-md-5 form-section">
                    {
                        props.loading ? (
                            <Loader
                                marginLeft = "473px"
                            />
                        ) : (
                            <form className="custom-form row">
                        
                        <div className="col-12 pt-3 text-center mb-5">
                        <div className="profile-img">
                            <img className="img-fluid" 
                            src={props.profile_img}  
                            style= {{
                                height : '108px' 

                            }}
                            
                            />
                            <a href="javascript:;" className="change">
                            <label for="myfile">
                            <img className="img-fluid" src="assets/images/app/camera-icon.svg" 

                            alt="icon" />
                            
                            <input type="file" 
                            accept="image/*"
                            id="myfile" name="myfile" style={{ display: "none" }} onChange={(e) => props.UploadEmployeeProfile("profile_img", e.target.files[0])}></input>
                            
                              </label>
                              
                            </a>
                        </div>
                        <span
                        style = {{
                            position:'absolute',
                            bottom: '-19px',
                            left:'420px',
                            fontSize:'12px',
                            color:'red'
                        }}
                        >Image Size should be(500x500)</span>
                        </div>
                        <div className="col-12 form-legend mt-0 mt-md-3 mb-4">
                        <span className="subtitle">Basic Details</span>
                        <div className="row mt-2">
                            <div className="col-lg-6 col-md-12 form-group">
                            <div className="row form-group">
                                <div className="col-md-6">
                                <label>Full Name</label>
                                <input type="text"
                                disabled
                                 className="form-control" name value ={props.full_name} onChange={(e)=>props.setFieldValues("full_name",e.target.value)}  defaultValue="Carmen Sullivan" />
                                </div>
                                <div className="col-md-6 mt-3 mt-md-0">
                                <label>Email</label>
                                <input type="text" className="form-control" name value ={props.email} defaultValue="mike@gmail.com" onChange={(e)=>props.setFieldValues("email",e.target.value)}  />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-6">
                                <label>Mobile No</label>
                                <input type="text" className="form-control" name  
                                value ={props.mobile_no} defaultValue="+60 8056 8356" onChange={(e)=>props.setFieldValues("mobile_no",e.target.value)}  />
                                </div>
                                <div className="col-md-6 mt-3 mt-md-0">
                                <label>Ic/Passport No</label>
                                <input type="text" className="form-control" name defaultValue="MK504RJ80"  value ={props.passport_no} onChange={(e)=>props.setFieldValues("passport_no",e.target.value)}  />
                                </div>
                            </div>
                            </div>
                            <div className="col-lg-6 col-md-12 form-group parellel">
                            <label>About your self</label>
                            <textarea className="form-control" value ={props.about} defaultValue={"I’ was responsible for this Opening"} onChange={(e)=>props.setFieldValues("about",e.target.value)}  />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6 from-group">
                            <label>Address</label>
                            <Autocomplete
                            apiKey={'AIzaSyAECO2GnFATOVmIKjFnAj5tzFL-DObFac8'}
                            className={"form-control"
                            } 
                            onChange={(e)=>props.setFieldValues("address",e.target.value)} 
                            value ={props.address}
                            onPlaceSelected={(place) => {
                                setLocation(place)
                                
                            }}
                            options={{
                                types: ['address'],
                                componentRestrictions: { country: "my" },
                            }}
                            // defaultValue={this.props.location}
                            />
                            {/* <input type="text" 
                            disabled
                            className="form-control" value ={props.address} name
                             onChange={(e)=>props.setFieldValues("address",e.target.value)} defaultValue="45 Jalan Tun Ismail, 50480 Kuala Lumpur, Malaysia" /> */}
                            </div>
                            <div className="col-md-6 form-group">
                            <div className="row">
                                <div className="col-md-6 mt-3 mt-md-0">
                                <label>City</label>
                                <input
                                className = "form-control"
                                
                                value ={props.city} 
                                onChange={(e)=>props.setFieldValues("city",e.target.value)}
                                ></input>
                              
                                </div>
                                <div className="col-md-6 mt-3 mt-md-0">
                                <label>Postal Code</label>
                                <input
                                
                                 type="text" className="form-control" defaultValue={50480} value ={props.postal_code} name onChange={(e)=>props.setFieldValues("postal_code",e.target.value)}  />
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                        <div className="col-12 form-legend mb-4">
                        <span className="subtitle">Resume</span>
                        <div className="row mt-2">
                            <div className="col-lg-6 col-md-12 form-group parellel">
                            <label>Describe Your Position and accomplishments as your Role</label>
                            <textarea className="form-control" value={props.resume} onChange={(e)=>props.setFieldValues("resume",e.target.value)}  defaultValue={"Vivamus eget aliquam dui. Integer eu arcu vel arcu suscipit ultrices quis non mauris. Aenean scelerisque, sem eu dictum commodo, velit nisi blandit magna, quis scelerisque ipsum lectus ut libero. Sed elit diam, dignissim ac congue quis, aliquam in purus. Proin ligula nulla, scelerisque quis venenatis pulvinar, congue eget neque. Proin scelerisque metus sit amet dolor tempor vehicula. Sed laoreet quis velit vitae facilisis. Duis ut sapien eu urna laoreet maximus. Donec nibh diam, vulputate vel nulla ut, viverra congue turpis. Fusce consectetur posuere purus, eget placerat nunc hendrerit at. Sed lectus dui, euismod a odio vitae, dictum dictum justo. Donec condimentum nunc vitae libero bibendum, cursus ultrices massa commodo."} />
                            </div>
                            <div className="col-lg-6 col-md-12 form-group">
                            <label>Upload Your Resume</label>
                            <Dropzone
                            onDrop={(acceptedFiles) => {
                            // var infoArea = document.getElementById( 'file-upload-filename' );
                            // var fileName =  acceptedFiles[0].name;
                            // infoArea.textContent =  fileName;
                            handleDropzone(acceptedFiles);
                          }}
                        >
                          {({ getRootProps, getInputProps }) => (
                            <div
                              className="upload-wizard"
                              style={{ outline: "none" }}
                              {...getRootProps()}
                            >
                            
                              <input
                                {...getInputProps()}
                                id="resume_upload"
                                type="file"
                                accept="application/pdf"
                                style={{ display: "none" }}
                              ></input>
                              
                              <span>
                                Upload your Resume (pdf only)  <br /> or
                              </span>
                              <a href="javascript:;">Browse File</a>
                              <strong  id="file-upload-filename" />
                              
                            </div>
                          )}
                        </Dropzone>
                        <strong>
                                {
                                   
                                props.picLoading ? "Uploading..." : props.resume_file}
                              </strong>
                        </div>
                        </div>

                        </div>
                        <div className="col-12 form-legend mb-2">
                        <span className="subtitle">Personal Details</span>
                        
                        <div className="row mt-2">
                            <div className="col-lg-6 col-md-6 form-group">
                            <label>Bank Name</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose Year"
                                value={props.bank_name}
                                onChange={(e) => {
                                  props.setFieldValues(
                                    "bank_name",
                                    e.target.value
                                );
                            }}
                            >
                           
                           {
                                props.banks &&
                                props.banks.length > 0 &&
                                props.banks.map((i,k) => {
                                    return <option
                                    key= {k}
                                    value = {i}
                                    >{i}</option>
                                })
                            }
                            </select>
                            
                            </div>
                            <div className="col-lg-6 col-md-6 form-group">
                            <label>Account Number</label>
                            <input type="text"
                            className="form-control" 
                            name 
                            placeholder="Account Number" 
                            value={props.bank_account_number}
                            onChange={(e) => {
                            props.setFieldValues(
                                "bank_account_number",
                                e.target.value
                            );
                            }}
                            />
                            </div>
                            
                        </div>
                        </div>
                        <div className="col-12 form-legend mb-4">
                        <div className="row mt-2">
                            <div className="col-lg-6 col-md-6 form-group">
                            <label>EPF</label>
                            <input type="text"
                            className="form-control" 
                            name 
                            // placeholder="Account Number" 
                            value={props.epf}
                            onChange={(e) => {
                            props.setFieldValues(
                                "epf",
                                e.target.value
                            );
                            }}
                            />
                            </div>
                            <div className="col-lg-6 col-md-6 form-group">
                            <label>SOCSO</label>
                            <input type="text"
                            className="form-control" 
                            name 
                            // placeholder="Account Number" 
                            value={props.socso}
                            onChange={(e) => {
                            props.setFieldValues(
                                "socso",
                                e.target.value
                            );
                            }}
                            />
                            </div>
                            {/* <div className="col-lg-4 col-md-6 form-group">
                            <label>EIS</label>
                            <input type="text"
                            className="form-control" 
                            name 
                            // placeholder="Account Number" 
                            value={props.eis}
                            onChange={(e) => {
                            props.setFieldValues(
                                "eis",
                                e.target.value
                            );
                            }}
                            />
                            </div> */}
                            </div>
                        </div>
                        <div className="col-12 form-legend mb-4">
                        <span className="subtitle">Qualification &amp; Skills</span>
                        {props.qualifications.map((qual,idx)=>{
                        // console.log()
                        return(
                        <div className="row mt-2">
                            <div className="col-md-6 form-group">
                            <label>Institution Name</label>
                            <input type="text" className="form-control" 
                            name 
                            value={qual.institution_name} 
                            
                            onChange={(e)=> {
                                // alert('came here')
                                qualificationChangeFunc(e,idx,"institution_name")}
                                } />
                            </div>
                            <div className="col-md-3 form-group">
                            <label>Qualification</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose one"
                            value={qual.qualification}  
                            onChange={(e)=>qualificationChangeFunc(e,idx,"qualification")}>
                                
                                {
                                props.listqualifications &&
                                props.listqualifications.length > 0 &&
                                props.listqualifications.map((i,k) => {
                                  return <option value="Diploma"
                                  key = {k}
                                  value = {i}
                                  >
                                    {i}
                                  </option>
                                })
                              }
                            </select>
                            </div>
                            {/* <div className="col-md-3 form-group">
                            <label>Year of Completed</label>
                            <div className="input-group date mar-t-no" data-date-format="dd/mm/yyyy">
                                <input type="text" className="form-control" 
                                value={qual.year_completed} 
                                onSelect = { (e) => {
                                    qualificationChangeFunc(e,idx,"year_completed")
                                }
                                    
                                }
                                
                                />
                                <div className="input-group-addon">
                                <img src="assets/images/calendar-icon.svg" alt="icon" />
                                </div>
                            </div>
                            </div> */}
                             <div className="col-md-3">
                                <label>Year Completed</label>
                                <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose Year"
                              value={qual.year_completed} 
                                onChange = { (e) => {
                                    qualificationChangeFunc(e,idx,"year_completed")
                                }}
                            >
                           
                             {
                               props.completion_year_arr &&
                               props.completion_year_arr.length > 0 &&
                               props.completion_year_arr.map((i,k) => {
                                 return <option key = {k}value={i}>{i}</option>
                               })
                             }
                              
                            </select>
                                {/* <input type="text" className="form-control" name  
                                value={qual.year_completed} 
                                onChange = { (e) => {
                                    qualificationChangeFunc(e,idx,"year_completed")
                                }}
                                /> */}
                            </div>
                            {/* <div className={idx===0 ? 
                                "col-12 form-section mb-2 d-none" : "col-12 form-section mb-4"}
                            >
                                <a
                                href="javascript:;" className="add-sec text-danger float-right"
                                onClick = {() => {
                                deleteItem(idx, 'experience') 
                                }}
                                >
                                <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                                Delete
                                </a>
                            </div>   */}
                            </div>
                            )})}
                        {/* <a href="javascript:;" className="add-sec" onClick={()=>{
                            props.setFieldValues("dummy", Math.random())
                            props.pushArray("qualifications",{education:'',year_completed:'',qualification:''})}}>
                            
                            <img src="assets/images/add-circle-fill-icon.svg" alt="icon" />
                            Add Education Qualification
                        </a> */}
                        </div>
                        <div className="col-12 form-legend mb-4">
                        <span className="subtitle">Language Skills</span>
                        {props.language_skill.map((lan,idx)=>{
                        return(
                        <div className="row mt-2">
                            <div className="col-lg-3 col-md-6 form-group">
                            <label>Language</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose One"
                             value={lan.language} 
                            onChange={(e)=>{
                                if (e.target.value === 'Others') {
                                    // alert()
                                    langChangeFunc("1",idx,'new_lang')
                                    langChangeFunc("",idx,"language")
                                  } else {
                                    langChangeFunc("0",idx,'new_lang')
                                    langChangeFunc(e,idx,"language")
                                  }
                                // langChangeFunc(e,idx,"language")
                            }}>
                            {/* <option>Choose One</option> */}
                            {
                            props.listlanguages &&
                            props.listlanguages.length > 0 &&
                            props.listlanguages.map((i,k) => {
                                return (
                                <option value={i} key = {k}>{i}</option>
                                )
                            })
                            }
                            </select>
                            {lan.new_lang === "1" &&
                            <input
                            value={lan.language}
                            id = 'lang_input'
                            type="text" className={`form-control mt-1 ${lan.new_lang === "1"?
                                '':'d-none'
                            }`}
                            onChange = {(e) => {langChangeFunc(e,idx,"language")}}
                            placeholder="Enter Language Here" name />
                            }
                            
                            </div>
                            <div className="col-lg-3 col-md-6 form-group">
                            <label>Spoken</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose One"
                            value={lan.spoken} 
                            onChange={(e)=>langChangeFunc(e,idx,"spoken")}>
                            <option>Choose One</option>
                            <option>Excellent</option>
                            <option>Good</option>
                            <option>Better</option>
                            
                            </select>
                            </div>
                            
                            <div className="col-lg-3 col-md-6 form-group">
                            <label>Read</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose One"
                            value={lan.read} 
                            onChange={(e)=>langChangeFunc(e,idx,"read")}
                            >
                            
                            <option value = "Excellent">Excellent</option>
                            <option>Good</option>
                            <option>Better</option>
                            
                            </select>
                            </div>
                            <div className="col-lg-3 col-md-6 form-group">
                            <label>Written</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose One"
                            value={lan.written} onChange={(e)=>langChangeFunc(e,idx,"written")}>
                            
                            <option>Excellent</option>
                            <option>Good</option>
                            <option>Better</option>
                
                            </select>
                            </div>
                            <div className={idx===0 ? 
                                "col-12 form-section mb-2 d-none" : "col-12 form-section mb-2"}
                            >
                                <a
                                href="javascript:;" className="add-sec text-danger float-right"
                                onClick = {() => {
                                deleteItem(idx, 'lang') 
                                }}
                                >
                                <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                                Delete
                                </a>
                        </div>  
                        </div>
                        )})}
                        <a href="javascript:;" onClick={()=>{ 
                            props.pushArray("language_skill",{language:'',spoken:'',read:'',written:''})
                            props.setFieldValues("dummy", Math.random())
                            }} className="add-sec">
                            <img src="assets/images/add-circle-fill-icon.svg" alt="icon" />
                            Add Language
                        </a>
                        </div>
                        <div className="col-12 form-legend mb-4">
                        <span className="subtitle">Skills</span>
                        {props.skills.map((ski,idx)=>{
                        return(
                        <div className="row mt-2">
                            <div className="col-md-6 form-group">
                            <label>Eg: System Operator, Billing, Waiter Etc.</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose One"
                            name="category" 
                            
                            value={ski.skill_name} 
                            onChange={(e)=>skillChangeFunc(e,idx,"skill_name")} 
                            >
                            
                            {
                                props.skills_new &&
                                props.skills_new.length &&
                                props.skills_new.map((i,k) => {
                                return <option
                                key = {k}
                                >{i}</option>
                                })

                            }

                        </select>
                            {/* <input type="text" className="form-control" name defaultValue="System Operator" 
                            value={ski.skill_name} onChange={(e)=>skillChangeFunc(e,idx,"skill_name")} 
                            /> */}
                            </div>
                            <div className="col-lg-6 col-md-6 form-group">
                            <label>Proficiency</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose Proficiency"
                            value={ski.experience} 
                            onChange={(e)=>skillChangeFunc(e,idx,"experience")}
                            >
                            <option>Choose Proficiency</option>
                            <option value = "Advanced">Advanced</option>
                            <option value = "Intermediate">Intermediate</option>
                            <option value = "Beginner">Beginner</option>
                            </select>
                            </div>
                            <div className={idx===0 ? 
                                "col-12 form-section mb-2 d-none" : "col-12 form-section mb-2"}
                            >
                                <a
                                href="javascript:;" className="add-sec text-danger float-right"
                                onClick = {() => {
                                deleteItem(idx, 'skills') 
                                }}
                                >
                                <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                                Delete
                                </a>
                        </div>  
                        </div>
                           )})}
                        <a href="javascript:;" className="add-sec" onClick={()=>{
                            props.setFieldValues("dummy", Math.random())
                            props.pushArray("skills",{skill_name:'',experience:''})}}>
                            <img src="assets/images/add-circle-fill-icon.svg" alt="icon" />
                            Add Skills
                        </a>
                        </div>
                        <div className="col-12 form-legend mb-4">
                        <span className="subtitle">Working Experience</span>
                        {props.working_experience.map((wor,idx)=>{
                           return(
                        <div>       
                        <div className="row mt-2">
                            <div className="col-lg-3 col-md-6 form-group">
                            <label>Category</label>
                            <select className=" form-control selectpicker" 
                                data-live-search="true"    
                                title = "Choose Category"
                            value={wor.category} 
                            onChange={
                                (e)=>{
                                var index = e.target.selectedIndex;
                                var optionElement = e.target.childNodes[index]
                                var option =  optionElement.getAttribute('data-id');  
                                workExperienceChangeFunc(e,idx,"category");
                                props.getPositions(option)
                            }
                            }
                            
                            >
                           
                            {
                  // console.log(this.props.industries, 'industries'),
                            props.industries &&
                            props.industries.length > 0 &&
                            props.industries.map((i,k) => {
                                return <option
                                key = {k}
                                data-id = {i.id}
                                value = {i.industry_type}>{i.industry_type}</option>
                                
                            })
                            }
                
                            {/* <option value = "Events & Promotions">Events &amp; Promotions</option>
                            <option value = "F&B">F&amp;B</option>
                            <option value = "Hospitality"> Hospitality</option>
                            <option value = "Logistics">Logistics</option> */}
                            </select>
                            </div>
                            <div className="col-lg-3 col-md-6 form-group">
                            <label>Your Position</label>
                            {/* <select name="category" className="form-control "
                             value={wor.position}
                             onChange={(e)=>workExperienceChangeFunc(e,idx,"position")}
                            >
                                <option value = "">Choose Position</option>
                                {

                                props.positions &&
                                props.positions.length > 0 &&
                                props.positions.map((i,k) => {
                                    return <option
                                    key = {k}
                                    value = {i}>{i}</option>
                                    
                                })
                                }
                            </select> */}
                            <input className="form-control" type="text"
                             value={wor.position} placeholder="Eg: Graphic Designer" name onChange={(e)=>workExperienceChangeFunc(e,idx,"position")} />
                            </div>
                            <div className="col-lg-6 col-md-12 form-group">
                            <label>Company Name</label>
                            <input className="form-control" type="text" value={wor.company_name} placeholder="Company Name" name onChange={(e)=>workExperienceChangeFunc(e,idx,"company_name")}/>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6 form-group">
                            <div className="row">
                                <div className="col-xl-6 col-lg-12 col-md-12 form-group">
                                <label>Start Date</label>
                                <div className="input-group date mar-t-no" 
                                data-date-format="DD/MM/YYYY"
                                >
                                    <input type="text" className="form-control" value={wor.start_date} 
                                    onBlur={(e)=>{
                                        setTimeout(() => {
                                            workExperienceChangeFunc(e,idx,"start_date")
                                        },500) 
                                        }
                                    } 
                                    />
                                    <div className="input-group-addon">
                                        <img src="assets/images/calendar-icon.svg" alt="icon" />
                                    </div>
                                </div>
                                </div>
                                <div className="col-xl-6  col-lg-12 col-md-12 form-group">
                                <label>End Date</label>
                                <div className="input-group date mar-t-no" data-date-format="DD/MM/YYYY">
                                    <input type="text" className="form-control" value={wor.end_date} 
                                    onBlur={(e)=>{
                                        calculateExp();
                                        setTimeout(() => {
                                            workExperienceChangeFunc(e,idx,"end_date")
                                        }, 500)
                                        
                                    }} />
                                    <div className="input-group-addon">
                                    <img src="assets/images/calendar-icon.svg" alt="icon" />
                                    </div>
                                </div>
                                </div>
                                <div className="col-12">
                                <label className="switch">
                                    <input type="checkbox" 
                                    className = "example1"
                                    checked = {wor.current_company === "yes" ? true :false}
                                    onChange={(e)=>workExperienceChangeFunc(e,idx,"current_company")}
                                     />
                                    <span className="slider" />
                                </label>
                                <span className="txt" 
                                // value={wor.current_company} 
                                >I Currently work here</span>
                                <a
                                href="javascript:;" className={idx === 0 ?
                                "add-sec text-danger float-right d-none" : 
                                "add-sec text-danger float-right"
                                }
                                onClick = {() => {
                                deleteItem(idx, 'experience')
                                
                                }}
                                >
                                <img src={process.env.PUBLIC_URL+"/assets/images/app/trash-icon.svg"} alt="icon" />
                                Delete
                                </a>
                                </div>
                            </div>
                            </div>
                            <div className="col-md-6 form-group parellel">
                            <label>Your Responsibilities</label>
                            <textarea className="form-control" value={wor.responsibilities} placeholder="Your Responsibilities..." defaultValue={""} onChange={(e)=>workExperienceChangeFunc(e,idx,"responsibilities")} />
                            </div>
                        </div>
                        </div>
                        )})}
                        <a href="javascript:;" className="add-sec" onClick={()=>{
                            props.setFieldValues("dummy", Math.random())
                            props.pushArray("working_experience",{category:'',position:'',company_name:'',start_date:'',end_date:'',responsibilities:'',
                            current_company:''})}}>
                            <img src="assets/images/add-circle-fill-icon.svg" alt="icon" />
                            Add Working Experience
                        </a>
                        {/* <div className="row mt-4">
                            <div className="col-12 form-group mb-0">
                            <label>Resume Privacy Settings</label>
                          
                            </div>
                        </div> */}
                        
                        </div>
                        </form>
                        
                        )
                        }
                     <div>
                    {/* <a href="javascript:;" className="btn btn-gray mr-2">Share</a> */}
                    <a href="javascript:;" className="btn btn-blue" onClick={updateFunc}>Save</a>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>
            {/* Main Content Ends here */}
            </div>
            </>
        
        );
    };


const mapStateToProps = (state, ownProps) => {
    const{
    profile_img,
    full_name,
    email,
    mobile_no,
    passport_no,
    address,
    about,
    city,
    postal_code,
    resume,
    resume_file,
    privacy,
    qualifications,
    year,
    loading,
    language_skill,
    skills,
    working_experience,
    varient,
    show_alert,
    showMsg,
    dummy,
    picLoading,
    bank_name,
    bank_account_number,
    epf,
    total_expereience,
    socso,
    eis
    }=state.Emp_Profile
    return {
    profile_img,
    full_name,
    email,
    total_expereience,
    mobile_no,
    passport_no,
    address,
    about,
    loading,
    city,
    postal_code,
    resume,
    resume_file,
    privacy,
    qualifications,
    year,
    language_skill,
    skills,
    working_experience,
    varient,
    show_alert,
    showMsg,
    dummy,
    bank_name,
    bank_account_number,
    epf,
    socso,
    eis,
    picLoading,
    banks: state.Home.banks,
    skills_new: state.Home.skills,
    positions : state.Home.positions,
    industries : state.Home.industries,
    listlanguages : state.Home.listlanguages,
    listqualifications: state.Home.listqualifications,
    completion_year_arr : state.Home.completion_year_arr
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setFieldValues: (f, v) => dispatch(Profile(f, v)),
        getIndustries : () => dispatch(getIndustries()),
        getPositions : data => dispatch(getPositions(data)),
        getBankS : () => dispatch(getBankS()),
        getSkills : () => dispatch(getSkills()),
        pushArray:(f, v) => dispatch(AddNewField(f, v)),
        UpdateProfile:(v) =>dispatch(UpdateProfile(v)),
        UploadEmployeeProfile:(f, v) => dispatch(UploadEmployeeProfile(f, v)),
        defaultSetValues: () => dispatch(getEmployeeProfile()),
        getLanguages : () => dispatch(getLanguages()),
        getQualifications : () => dispatch(getQualifications()),
        getPassoutYear : () => dispatch(getPassoutYear()),
    }
};

const profile = connect(
    mapStateToProps,
    mapDispatchToProps,
)(MyProfile);

export default profile;

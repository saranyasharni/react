import React, { Component } from "react";
import Header from "../Common/App/AppHeader.jsx";

class EmployeeViewJobs extends Component {
	
	constructor(props) {
		super(props);
		this.state = {};
	}

  	componentDidMount() {
    	// require('../../assets/css/app-style.css');
		// let removingElament = document.getElementById("custom_app_style");
		// // console.log(removingElament, 'removingElament')  
		// if (removingElament !== null) {
		// 	removingElament.remove()
		// }
		// const elem2 = document.createElement("link");
		// elem2.rel = "stylesheet"
		// elem2.type = "text/css"
		// elem2.href = process.env.PUBLIC_URL+"/assets/css/app-style.css";
		// // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
		// elem2.id = "custom_app_style"
		// elem2.async = true;
		// document.head.appendChild(elem2);
  	}
  // componentDidUpdate() {
    
  //   window.$(".selectpicker").selectpicker();
  
  // }
  render() {
    return (
        <>
        <div className="container-fluid">
        <Header />
        

            {/* Main Content Starts here */}
            <section className="row main-content">
            <div className="container">
               
            </div>
            </section>
            {/* Main Content Ends here */}


        
        </div>
        </>
      
    );
  }
}

export default EmployeeViewJobs;

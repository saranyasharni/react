import React, { useEffect, useState } from "react";
import Header from "../Common/App/AppHeader";
import { connect } from 'react-redux';
import {
    acceptedOffers,rejectOffers,
    ConfirmOffer, ViewOffers,setShow,confirmPopupShow
  }from '../../actions/Employee/Offers'
import Alert from "react-bootstrap/Alert";
import ConfirmationPopup from './ConfirmationPopup';
import {Link} from "react-router-dom";
import moment from 'moment';
import history from "../../stores/history";

function View_details (props) {
    const[app_id, setAppId] = useState('')
    useEffect(() => {
        // require("../../..//assets/css/app-style.css");
        props.ViewOffers({
            application_id : window.location.pathname.split('/')[3],
            employee_id : localStorage.getItem('employee_id')
        });
    },[]);
 
    // console.log("det",props.job_id)

    return(
      <React.Fragment>
        <div className="container-fluid">
          {/* header Starts here */}
          <Header />
          {/* header Ends here */}
          {/* Main Content Starts here */}
          <section className="row main-content">
            <div className="container">
                <div className="row">
                {/* <div className="col-12 hdr-row ff-col">
                    <h1>
                    <a href="javascript:;" className="back"
                   
                    >
                        <img src="/assets//as/images/app/back-arrow.svg" alt="icon" />
                    </a>
                    Back
                    </h1>
                    <button className="btn btn-red min-w mr-2">Reject Offer</button>
                    <a href="javascript:;" className="btn btn-blue min-w">Accept Offer</a>
                </div> */}
                <div className="col-12 hdr-row ff-col">
         
                <h1>
                    <a href="javascript:;" className="back n__back-button"
                    onClick={() => 
                        history.goBack()
                    } 
                    >
                    <img src="/assets/images/app/back-arrow.svg" alt="icon" /> <span>Back</span>
                    </a>
                    {/* Back */}
                </h1>
                {
                // window.location.pathname.split('/')[2] === 'hired' ||
                // window.location.pathname.split('/')[2] === 'offer-accepted' ?
                <div>
                <button className="btn btn-red min-w mr-2"
                onClick={()=>{
                    
                    props.confirmPopupShow(true)
                //     props.rejectOffers({
                //     application_id:props.offersDetail.id
                // })
            }}
                
                >Reject Offer</button>
                <a href="javascript:;" className="btn btn-blue min-w"
                onClick={()=>{
                    if (props.offersDetail && props.offersDetail.application_status === 'hired'){
                      props.acceptedOffers({
                        application_id:props.offersDetail.id,
                        status_code:4,
                      })
                    } else if (props.offersDetail && props.offersDetail.application_status === 'offer-accepted') {
                      props.ConfirmOffer({
                        application_id:props.offersDetail.id
                      })
                    } else if (props.offersDetail && props.offersDetail.application_status === 'on-board') {

                    } else if (props.offersDetail && props.offersDetail.application_status === 'completed') {

                    } else {

                    }
                  }
                }
                >
                {
                    window.location.pathname.split('/')[2] === 'hired'?
                    'Accept Offer' :"Confirm offer"
                }
                </a>
                </div> 
                // : ""
                }
                
                </div>
                <div className="col-12 mb-5">
                {
                    <Alert
                    
                        show={props.show}
                        variant={props.varient}
                        dismissible
                        onClose={() => props.setShow(false)}
                    >
                        <strong>
                            {props.varient == "success"
                                ? "Success!"
                                : "Error!"}
                        </strong>{" "}
                        {props.showMsg}
                    </Alert>
                    }
                    <div className="snippet-box p-4 job-detail">
                    <div className="row">
                        {
                        // console.log(props.offersDetail, 'offersDetail')
                        /* <div className="col-md-4 lft-col">
                        
                        <div className="row job-desc contact mt-4 mb-4">
                            <div className="col-12">
                        
                            </div>
                        </div>
                        <button className="btn btn-blue">View Contact Details</button>
                        </div> */}
                        <div className="col-md-8 rgt-col">
                        <div className="row job-desc">
                            <div className="col-12">
                            <h4 className="mb-3">Company Info</h4>
                            <h2 className="mb-1">
                                {props.offersDetail &&
                                props.offersDetail.job && 
                                props.offersDetail.job.industry_type
                                }
                                
                            </h2>
                            <span className="designation dark">
                                {
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    props.offersDetail.job.employer && 
                                    props.offersDetail.job.employer.company_name
                                }
                                {/* Magical business solution */}
                            </span>
                            {/* <p className="job-desc-light mt-3">Required 3 freshers/experience office Admin need Travel management, Management Information System (MIS), MS-Office, Office administration, Communication Skills</p> */}
                            </div>
                        </div>
                        <div className="row job-desc mt-4">
                            <div className="col-12 col-lg-9">
                            <h4 className="mb-3">Required</h4>
                            
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Job Position</p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                {
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    props.offersDetail.job.job_position
                                }
                                </span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Job Type</p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                {
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    props.offersDetail.job.job_type
                                }
                                </span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Start Date</p>
                                </div>
                                <div className="col-md-9">
                                <span>{
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    moment(new Date(props.offersDetail.job.start_date)).format('DD MMMM YYYY')
                                    
                                    }</span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>End Date</p>
                                </div>
                                <div className="col-md-9">
                                <span>{
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    moment(new Date(props.offersDetail.job.end_date)).format('DD MMMM YYYY')
                                    
                                    }</span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>No of Hours </p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                    {
                                        props.offersDetail &&
                                        props.offersDetail.job && 
                                        props.offersDetail.job.number_of_hours
                                        

                                    }{" "}Hours
                                </span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>No of Days </p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                    {
                                        props.offersDetail &&
                                        props.offersDetail.job && 
                                        props.offersDetail.job.number_of_days
                                    }{" "}Days
                                    </span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Epf</p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                RM{
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    props.offersDetail.job.job_salaries.length > 0 && 
                                    new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(props.offersDetail.job.job_salaries[0].employee_epf)
                                    ? '0.00':props.offersDetail.job.job_salaries[0].employee_epf)
                                    }
                                </span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Socso</p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                RM{
                                    props.offersDetail &&
                                    props.offersDetail.job && 
                                    props.offersDetail.job.job_salaries.length > 0 && 
                                    new Intl.NumberFormat('en-US', 
                                    {style: 'decimal', minimumFractionDigits: 2}).
                                    format(isNaN(props.offersDetail.job.job_salaries[0].employee_socso)
                                    ? '0.00':props.offersDetail.job.job_salaries[0].employee_socso)
                                    
                                }
                                </span>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Eis</p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                   RM{
                                       props.offersDetail &&
                                       props.offersDetail.job && 
                                       props.offersDetail.job.job_salaries.length > 0 && 
                                       new Intl.NumberFormat('en-US', 
                                       {style: 'decimal', minimumFractionDigits: 2}).
                                       format(isNaN(props.offersDetail.job.job_salaries[0].employee_eis)
                                       ? '0.00':props.offersDetail.job.job_salaries[0].employee_eis)
                                       
                                   }
                                </span>
                                </div>
                            </div>
                           
                            <div className="row mb-2">
                                <div className="col-md-3">
                                <p>Total Pay</p>
                                </div>
                                <div className="col-md-9">
                                <span>
                                RM {
                                    props.offersDetail &&
                                        props.offersDetail.job && 
                                        props.offersDetail.job.job_salaries.length > 0 && 
                                        new Intl.NumberFormat('en-US', 
                                       {style: 'decimal', minimumFractionDigits: 2}).
                                       format(isNaN(props.offersDetail.job.job_salaries[0].reduced_salary_for_employee)
                                       ? '0.00':props.offersDetail.job.job_salaries[0].reduced_salary_for_employee)
                                    }
                                </span>
                                </div>
                            </div>
                         
                            </div>
                        </div>
                       
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>

          {/* Main Content Ends here */}
          
        </div>
        <ConfirmationPopup
           application_id= {props.offersDetail.id}
        />
        {/* Main Wrapper Ends here */}
        {/* Script Starts here */}
        {/* Script Ends here */}
        </React.Fragment>
    )
};

const mapStateToProps = (state, ownProps) => {
  return {
      
    offersDetail : state.Offers.offersDetail,
    showMsg: state.Offers.showMsg,
    status: state.Offers.status,
    show:state.Offers.show,
    varient: state.Offers.varient,  
    };
  
  };
  
  const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        setShow: (f, v) => dispatch(setShow(f, v)),
        ConfirmOffer: (data) => dispatch(ConfirmOffer(data)),
        rejectOffers:(id,job)=>dispatch(rejectOffers(id,job)),
        confirmPopupShow:(data)=> dispatch(confirmPopupShow(data)),
        acceptedOffers:(id,job)=>dispatch(acceptedOffers(id,job)),
        ViewOffers : (data) => dispatch(ViewOffers(data)),

    }
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(View_details);
import React, { useEffect, useState } from "react";
import moment from "moment";
import config from "../../actions/Common/Api_Links"
import * as actions from '../../actions/Employee/AppliedJobs';
import $ from "jquery"
import { connect } from 'react-redux'
import Loader from '../Helper/Loader'
import Header from "../Common/App/AppHeader";
import Alert from "react-bootstrap/Alert";
function Interviews(props) {
    
    const [state, setState] = useState({
      editDate:'',
        editStartTime:'',
        editEndTime:'',
        scheduleId : '',
        employee_id : '',
        job_id: '',
        status:0,
        loading:false,
        modelMessage:'',
        date: moment(new Date()).format('DD MMMM YYYY')
    })
    useEffect(() => {
        props.listWorkRequests()
    }, [])
    useEffect(() => {
      if (props.job_status === 1 || props.job_status ===2) {
        // setTimeout(function() {
        //     props.setShow(false)
        // }, 2000)
      } 
    })
    function getYesterdaysDate() {
        var date = new Date(state.date)
        
        date.setDate(date.getDate()-1);
        let date1 =  date.getDate() + ' ' + 
        (date.toLocaleString('default', { month: 'long' })) + 
        ' ' + date.getFullYear();
        console.log(date1,'atte')
        let sendDateFormat = 
        ('0'+(date.getMonth()+1)).slice(-2) + '/' + ('0'+ date.getDate()).slice(-2) + '/' + date.getFullYear();

        props.getSchedules({
            employer_id:localStorage.getItem('emp_id'),
            status_code : 8,
            filter:1,
            filter_by:'date',
            industry_type:null,
            job_position:null,
            page_no:0,
            limit:1,
            interview_date:sendDateFormat
        })
        setState({
            ...state,
            date:date1
        })
  }
  function getTomorrowsDate() {
    var date = new Date(state.date);
    date.setDate(date.getDate()+1);
    let date1 =  date.getDate() + ' ' + 
    (date.toLocaleString('default', { month: 'long' })) + 
    ' ' + date.getFullYear();
    let sendDateFormat = 
    ('0'+(date.getMonth()+1)).slice(-2) + '/' + ('0'+ date.getDate()).slice(-2) + '/' + date.getFullYear();
    setState({
        ...state,
        date:date1
    })
    props.getSchedules({
        employer_id:localStorage.getItem('emp_id'),
        status_code : 8,
        filter:1,
        filter_by:'date',
        industry_type:null,
        job_position:null,
        page_no:0,
        limit:1,
        interview_date:sendDateFormat
    })
}

    return (
        
        <div>   
        {/* Main Wrapper Starts here */}
        <div className="container-fluid">
        <Header/>
        {/* Hero Section Starts here */}
        {/* Hero Section Ends here */}
        <section className="row main-content">
            <div className="container">
                <div className="row">
                <div className="col-12 hdr-row ff-col mb-2">
                    <h1>Work Extension Requests</h1>
                </div>
                
                  
            <div className="col-12 mb-5 schedule-i-wrap">
        
                    {
                        <Alert
                        show={props.show}
                        variant={props.varient}
                        dismissible
                        onClose={() => props.setShow(false)}
                        >
                        <strong>
                        {
                            props.job_status === 1 ? "Success!" 
                            : props.job_status === 2 ? "Error!"
                            :"Info!"
                        }
                        </strong>{" "}
                        {props.showMsg}
                        </Alert>
                    }
                    <div className="table-hdr row mb-0 mb-md-4">
                        {/* <div className="col-12">
                            <div className="date-nav">
                            <a href="javascript:;" className="date-prev"
                            onClick = {() => {
                                getYesterdaysDate()
                                
                            }}
                            >
                                <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
                            </a>
                            
                            <img src="/assets/images/app/calendar-icon.svg" alt="icon" />
                        
                            <input className="cal-icon"
                 
                            onSelect = {(e) => {
                            setState({
                                ...state,
                                date: moment(new Date(e.target.value)).format('DD MMMM YYYY')
                            });  
                            props.getSchedules({
                                employer_id:localStorage.getItem('emp_id'),
                                status_code:8,
                                filter:1,
                                filter_by:'date',
                            
                                industry_type:null,
                                job_position:null,
                                page_no:0,
                                limit:1,
                            
                                interview_date:moment(new Date(e.target.value)).format('MM/DD/YYYY')
                            })
                            
                        }}
                            
                        value = {state.date}
                    ></input>
                       
                    <a href="javascript:;" className="date-next"
                    onClick = {() => {
                        getTomorrowsDate()
                    }}
                    >
                        <img src="/assets/images/app/chevron-arrow.svg" alt="icon" />
                    </a>
                    </div>
                    </div> */}
                    </div>
                            {

                            props.loading ?
                            <div className="empty-job">
                            <Loader/>
                            </div>:
                             <div className="row">
                             {/* { */}
                            <div className="snippet-box min-h-vh">
                            <div className="table-hdr row">
                              {/* <div className="date-nav">
                                <a href="javascript:;" className="date-prev">
                                  <img src="images/app/chevron-arrow.svg" alt="icon" />
                                </a>
                                <span>July 5 - July 11, 2020</span>
                                <a href="javascript:;" className="cal-icon">
                                  <img src="images/app/calendar-icon.svg" alt="icon" />
                                </a>
                                <a href="javascript:;" className="date-next">
                                  <img src="images/app/chevron-arrow.svg" alt="icon" />
                                </a>
                              </div> */}
                            </div>
                            <div className="row">
                            {
                                // console.log(props.list_employer_requests, 'props.list_employer_requests'),
                                props.list_employer_requests &&
                                props.list_employer_requests.length > 0 ?
                                props.list_employer_requests.map((i,k) => {
                                    return <div className="mb-3 col-md-6 col-lg-4" key = {k}>
                                    <div className="req-snip">
                                      <div className="hire-candidate">
                                        <div className="avatar">
                                          <img className="img-fluid" src={
                                           i &&
                                           i.job &&
                                           i.job.employer &&
                                           i.job.employer.profile_url &&
                                           i.job.employer.profile_url !== "null"
                                           ? 
                                           i.job.employer.profile_url :
                                           process.env.PUBLIC_URL+"/assets/images/app/avatar-1.png"   
                                          } alt="Staff" />
                                        </div>
                                        <div className="av-cont">
                                          <h6
                                          style = {{
                                              textTransform : 'capitalize'
                                          }}
                                          >{i.worker &&
                                          i.worker.job &&
                                          i.worker.job.employer &&
                                          i.worker.job.employer.company_name
                                          }</h6>
                                          <span>{
                                              i.worker &&
                                              i.worker.job &&
                                              i.worker.job.industry_type ? 
                                              i.worker.job.industry_type :''
                                              }  | {
                                                i.worker &&
                                                i.worker.job &&
                                                i.worker.job.job_position ? 
                                                i.worker.job.job_position :''
                                              }, {
                                                i.worker &&
                                                i.worker.job &&
                                                i.worker.job.job_location ? 
                                                i.worker.job.job_location :''
                                              } </span>
                                        </div>
                                      </div>
                                      <div className="row req-cont mt-3">
                                      <p className="col-md-12"> Date :{
                                            i.extend_current_day === '0' ?
                                            `${moment(new Date( i.start_date)).format('DD MMMM YYYY')} - ${moment(new Date( i.end_date)).format('DD MMMM YYYY')}`
                                            :  `${moment(new Date(i.start_date)).format('DD MMMM YYYY')} `
                                        }</p>
                                        <p className="col-md-12 text-truncate">Log In Time : {i.start_time}-{i.end_time}</p>
                                        <p className="col-md-12 mt-2">Description</p>
                                        <p className="col-md-12">{
                                            i.extend_current_day === '0' ?
                                            `Your job has been extended from ${moment(new Date( i.start_date)).format('DD MMMM YYYY')} to ${moment(new Date( i.end_date)).format('DD MMMM YYYY')}`
                                            :  `Your Work has been extended on ${moment(new Date(i.start_date)).format('DD MMMM YYYY')} from ${i.start_time} to ${i.end_time} `
                                        }</p>
                                        <div className="col-12 mt-3 mb-1 text-right">
                                          
                                          <button className="btn btn-red"
                                          disabled = {
                                            i.status === 'extend-request-declined' ||
                                            i.status === 'extend-request-accepted'?
                                            
                                            true : false
                                          }
                                          onClick = {() => {
                                            props.rejectRequest({
                                              request_id:i.id,
                                              work_id:i.workerId
                                            })
                                          }}
                                          >{i.status === 'extend-request-declined'?
                                          'Rejected' : "Reject"
                                          }
                                          </button>
                                          <button className="btn btn-outline-blue mt-0"
                                          disabled = {
                                            i.status === 'extend-request-declined' ||
                                            i.status === 'extend-request-accepted'?
                                            true : false
                                          }
                                          onClick = {() => {
                                              props.acceptRequest({
                                                request_id:i.id
                                              })
                                          }}
                                          >
                                            {
                                              
                                              i.status === 'extend-request-accepted'?
                                              'Accepted' : 'Accept'
                                            }
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                })
                                
                                 :<div className="empty-job">
                                 <img src="assets/images/app/undraw-empty.svg" alt="image"/>
                                 <p>There's nothing here.</p>
                             </div>
                            }
                    

                            </div>
                          </div>
                          
                             {/* : <div className="empty-job">
                             <img src="assets/images/app/undraw-empty.svg" alt="image"/>
                             <p>There's nothing here.</p>
                         </div>  */}
                             {/* } */}
                             
                             </div>
                             }
                         </div>
                
           
                </div>
            </div>
        </section>

        </div>
        {/* Main Wrapper Ends here */}
        
        </div>
   
    )};

    const mapStateToProps = (state, ownProps) => {
        return {
            list_employer_requests:state.Appliedjob.list_employer_requests,
            loading : state.Appliedjob.loading,
            show: state.Appliedjob.show,
            job_status : state.Appliedjob.job_status,
            varient: state.Appliedjob.varient,
            showMsg : state.Appliedjob.showMsg
        }
    };
    
    const mapDispatchToProps = (dispatch, ownProps) => {
       
        return {
            listWorkRequests : () => dispatch(actions.listWorkRequests()),
            rejectRequest : (data) => dispatch(actions.rejectRequest(data)),
            acceptRequest : (data) => dispatch(actions.acceptRequest(data)),
            setShow : data => dispatch(actions.setShow(data))
        }
       
    };

    export default connect(mapStateToProps, mapDispatchToProps)(Interviews); 
import React, { useEffect } from "react";
import { Modal } from 'react-bootstrap';
import { connect } from 'react-redux';
import { confirmPopupShow,rejectOffers } from "../../actions/Employee/Offers";
// import history from "../../../stores/history";
function ConfirmationPopup(props) {
    useEffect(() => {
        
        let removingElament = document.getElementById("custom_app_style");
    // console.log(removingElament, 'removingElament')  
    if (removingElament !== null) {
        removingElament.remove()
    }
    
    }, []);
    // console.log("modal", props.applicant_list)
    return (
        <Modal show={props.show} className="custom-modal custom-modal"
        onHide={() => props.confirmPopupShow(false)}
        tabindex="-1" role="dialog" aria-hidden="true"
        centered>
  {/* <div className="modal-dialog modal-sm modal-dialog-centered" role="document"> */}
    <div className="modal-content">
      <div className="modal-header pb-0">
        <button
          type="button"
          className="close"
          data-dismiss="modal"
          onClick = {() => props.confirmPopupShow(false)}
          aria-label="Close"
        >
          <img
            className="img-fluid"
            src="/assets/images/modal-close-icon.svg"
            alt="icon"
          />
        </button>
      </div>
      <div className="modal-body px-md-5 px-3 pt-0">
        <div className="row">
          <div className="col-md-12">
            <h5 className="modal-title w-100 justify-content-center">
              Are you sure
            </h5>
            <p className="fs-14 dark text-center my-4">Do you want to Reject?</p>
          </div>
        </div>
        <div className="row mt-2 mb-3">
          <div className="col-md-12 text-center">
            <button className="btn btn-gray mr-2 px-4"
            onClick = {() => props.confirmPopupShow(false)}
            >No</button>
            <button className="btn btn-blue px-4"
            onClick= {() => {
                props.rejectOffers({
                    application_id:props.application_id
                })
            }}
            >Yes</button>
          </div>
        </div>
      </div>
    </div>
  {/* </div> */}
</Modal>
    )
};


const mapStateToProps = (state, ownProps) => {
    return {
        show: state.Offers.confirm_popup,
        
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        confirmPopupShow: (data) => dispatch(confirmPopupShow(data)),
        rejectOffers:(id,job)=>dispatch(rejectOffers(id,job)),
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(ConfirmationPopup);
import React from "react";
import Header from './Common/Header';
import Footer from './Common/Footer';
import Banner from './HomeSection/Home_Banner1'
import Testimonials from './HomeSection/Testimonals';
import App_Section from './HomeSection/App_Section';
import { connect } from 'react-redux'

class Landing extends React.Component{
    constructor(props) {
        super(props)
    }

    componentDidMount() {
        // require('../assets/css/custom-style.css');
        let removingElament = document.getElementById("design_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
        // console.log(document.getElementById("custom_app_style"), 'custom_app_style')  
        this.props.getHome()
        // this.props.getJobs()
        // fetch(
        //     "http://9f9ed825feb1.ngrok.io/employer-home"
        //   )
        //     .then((response) => response.json())
        //     .then((data) => {
        //       this.setState({description:data.description,jobs:data.jobs,dashboard:data.dashboard.content,test:data.testimonials})
        //     })  
    
    };

    render() {
        return(
            <div>   
            {/* Main Wrapper Starts here */}
            <div className="container-fluid main-wrap">
            <Header/>
            {/* Hero Section Starts here */}
            {/* Hero Section Ends here */}
            <Banner/>
            {/* Feature Section Starts here */}
            {/* Feature Section Ends here */}
            {/* Testimonial Section Starts here */}
            <Testimonials/>
            {/* Testimonial Section Ends here */}
            {/* App Section Starts here */}
            {/* <App_Section/> */}
            {/* App Section Ends here */}
            </div>
            {/* Main Wrapper Ends here */}
            <Footer/>
            {/* Modal Wrapper Starts here */}

            </div>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        
    }
};

const category = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Landing);

export default category;
import React, { Component, Fragment } from 'react'

export default class App_Section extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="row app-wrap">
            <div className="container text-center">
                <h6>It's Time</h6>
                <h2>Start to Use this app of faith locally and globally</h2>
                <div className="col-12">
                <a href="javascript:;">
                    <img className="img-fluid" src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"} alt="icon" />
                </a>
                <a href="javascript:;">
                    <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/google-playstore-icon.png"} alt="icon" />
                </a>
                </div>
            </div>
            </section>

        )
    }
}



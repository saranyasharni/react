import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import jQuery from 'jquery';

class Testimonals extends Component {
    constructor(props) {
        super(props);
    }

    render() {
       
        return (

            <section className="row testi-wrap">
            <div className="element-wrap">
                <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/elements-2.svg"} alt="elements" />
            </div>
            <div className="container">
            <div className="row text-center">
            <h2 className="col-12">People are loving us</h2>
            </div>
            <div className="row">
           
            <div className="col-12">
            {
            this.props.testimonials &&
            this.props.testimonials.length > 0 &&
            this.props.testimonials.map((tes, index)=>{
                
                let mixed_class = ''
                switch (index) {
                    case 0:
                      mixed_class = "main active";
                      break;
                    case 1:
                      mixed_class = "lf-1";
                      break;
                    case 2:
                       mixed_class = "lf-2";
                      break;
                    case 3:
                      mixed_class = "rg-1";
                      break;
                    case 4:
                      mixed_class = "rg-2";
                      break;
                  }

            return(
            <div className={"testi-sec" +' '+ mixed_class} key= {index}>
            <div className={"testi-thumb"}>
                <img className="img-fluid" src={tes.profile_url} alt="icon"/>
            </div>
            <div className="testi-cont">
                <h6>{tes.content}</h6>
                <span>{tes.author}</span>
                <em>{tes.company}</em>
            </div>
            </div>
          
            )}
            )
            }
                </div>
                   
                </div>
            </div>
        </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        testimonials:state.Home.testimonials,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
    }
};

const testimonials = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Testimonals);

export default testimonials;




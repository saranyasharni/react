import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import $ from 'jquery';
import { Link } from "react-router-dom";

class Home_Banner1 extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {   
        var THIS = this;
        $(document).ready(function(){
            if (THIS.props.dashboard) {
                window.$('.feature-wrap .owl-carousel').owlCarousel({
                    items:1,
                    loop:true,
                    dots:false,
                    nav: true
                });
              
                $(".testi-sec").mouseenter(function(){
                  $(".testi-sec").removeClass("active");
                  $(this).addClass("active");
                });
            }
          
        });
    
    }

    componentDidUpdate() {
        var THIS = this;
        $(document).ready(function(){
            if (THIS.props.dashboard) {
                window.$('.feature-wrap .owl-carousel').owlCarousel({
                    items:1,
                    loop:true,
                    dots:false,
                    nav: true
                });
            
                $(".testi-sec").mouseenter(function(){
                $(".testi-sec").removeClass("active");
                $(this).addClass("active");
                });
            }
          
        });
    }

    render() {
        
        return (
            <>
            {/* {
                console.log(this.props.jobs, 'this.props.jobs')
            } */}
            <section className="row">
            <div className="hero-section container">
                <div className="row">
                {/* Hero Left Starts */}
                <div className="col-lg-7 col-md-12">
                    <h1>
                    FIND YOUR JOBS <br />
                    in <span>FlexiJobs</span>
                    </h1>
                    <p className="lead">
                    
                    {/* Flexi Job uses technology to provide you with pre-screened temporary workers ready to start today. Find the best workers while saving time, effort and money */}
                    {this.props.jobs.length > 0  && this.props.jobs[0].description}
                    </p>
                    <div className="row">
                    {this.props.jobs.length > 0 && this.props.jobs[0].jobs.map((det, k)=>{
                    return(
                    <div className="col-md-6 my-3" key = {k}>
                        <div className="hero-snippet">
                        <img  src={det.industry_icon ? det.industry_icon: ''} alt="icon" />
                        <h3>{det.industry_name}</h3>
                        <p>{det.panel1_content}</p>
                        <Link 
                        to = {`/jobs/${det.id}`}
                        className="more"
                        >
                            Learn More
                            <img src={process.env.PUBLIC_URL+"/assets/images/arrow-blue.svg"} alt="icon" />
                        </Link>
                        </div>
                    </div>
                    )}) 
                    }
                    </div>
                </div>
                {/* Hero Left Ends */}
                {/* Hero Right Starts */}
                <div className="col-lg-5 d-none d-lg-block">
                    <div className="her-rgt-img">
                    <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/hero-rgt-img.jpg"} alt="image90" />
                    </div>
                </div>
                {/* Hero Right Ends */}
                </div>
            </div>
            </section>
            <section className="row feature-wrap mt-5">
            <div className="swril-wrap container-fluid p-0">
                <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/yellow-swirl.svg"} alt="elements" />
            </div>
            <div className="element-wrap">
                <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/elements-1.svg" }alt="elements" />
            </div>
            <div className="swril-wrap btm container-fluid p-0">
                <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/yellow-swirl.svg"} alt="elements" />
            </div>
            <div className="container">
                <div className="row">
                
                
                <div className="col-lg-6 col-md-7">
                    {

                    this.props.dashboard && this.props.dashboard.length > 0 &&
                    <div className="owl-carousel">
                    {
                  
                    this.props.dashboard && this.props.dashboard.map((con)=>{
                  
                    return(
                    <div 
                    key = {con.id}
                    className="feature-item">
                        <h2>Dashboard</h2>
                        <p>
                            {
                                con.description
                            }
                            {/* Job flex uses technology to provide you with pre-screened temporary workers ready to start today. Find the best workers while saving time, effort and money */}
                        </p>
                    </div>
                      )})
                    }
                    {/* <div className="feature-item">
                        <h2>Dashboard</h2>
                        <p>Job flex uses technology to provide you with pre-screened temporary workers ready to start today. Find the best workers while saving time, effort and money</p>
                    </div> */}
                    </div>
                    }
                </div>
              
                </div>
            </div>
            <div className="sshot d-none d-md-block">
                <img className="img-fluid" src={"/assets/images/dashboard-sshot.png"} alt="icon" />
            </div>
            </section>
            </>
        )
    }
}
const mapStateToProps = (state, ownProps) => {
    
    return {
        jobs:state.Home.jobs,
        dashboard:state.Home.dashboard
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
    }
};

const category1 = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Home_Banner1);

export default category1;





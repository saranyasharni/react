// import React, { Component, useEffect, useMemo, useRef } from "react";
// import { Form } from "react-bootstrap";
// this.setState((prevState) => ({
//  user : {
//      ...prevState.user,
//      age:78
//  }
// }))

// const calculation = useMemo(() => {
//     // I will also be run every time myNumber changes
//     return myNumber * 2
//   }, [myNumber])

//   const calculate = useCallback(() => {
//     // I will also be run every time myNumber changes
//     return myNumber * 2
//   }, [myNumber])

// // const ThemeContext = React.createContext("light")
// // class App extends Component {
// //     render() {
// //         return <ThemeContext.Provider value = "dark">
// //             <ThemeButton />
// //         </ThemeContext.Provider>
// //     }
// // }
// // function ThemeButton() {
// //     return <ToolBar/>
// // }
// // class ToolBar extends Component {
// //     static contextType = ThemeContext;
// //     render() {
// //         return ReactDOM.createPortal(
// //             this.props.children,
// //             domNode);
// //         )
// //     }
// // }

// // function Test(props) {
// //     const focusInput =  useRef(null)
// //     useEffect(() => {
// //         focusInput.current.focus()
// //     },[])
// //     return <form>
// //            <input
// //            ref = {focusInput}
// //            value = "example"
// //            />     
// //     </form>
// // }
// /* */
// // function NumberList(props) {
// //     return <li>{props.value}</li>
// // }

// // function Test() {
// //     const arr = [1,3,4]
// //     const listItems = arr.map((i,k) => 
// //         <NumberList
// //         key = {i}
// //         value = {i}
// //         />
// //     )
// //     return (
// //         <ul>
// //             {listItems}
// //         </ul>
// //     )
// // }
// /* */
// // function createMarkup() {
// //     return {_html : "my test code"}
// // }
// // function Test() {
// //     <div dangerouslySetInnerHTML= {createMarkup()}>

// //     </div>
// // }
// // class Test extends Component {
// //     constructor(props){
// //       super(props);
// //       this.node = createRef();
// //     }
// //     componentDidMount() {
// //       this.node.current.scrollIntoView();
// //     }
// //     componentDidCatch(err, info) {
// //         logErrorToMyService()
// //     }
// //     static getDerivedStatefromError(err) {
// //         return{hasError: true}
// //     }
// //     set(params) {
        
// //     }
// //     render() {
// //         if (this.state.hasError) {
// //             return <h1>{'Something went wrong.'}</h1>     
// //         }
// //       return <div ref={this.node} />
// //     }
// //   }
// // const hocExampe = wrappedCom(wrapper)

// //   React.cloneElement(
// //     element,
// //     [props],
// //     [...children]
// //   )

// //   React.cloneElement(
// //     type,
// //     [props],
// //     [...children]
// //   )
// // function Test() {
// //     const[state, setState] = useState({
// //         input : '',
// //         list:[]
// //     })
// //     const 
// //     return <div>
// //         <form 
        
// //         >
// //         <label>
// //             Name:
// //             <input type="text" name="name" 
// //             onChange = {(e) => {
// //                 setState({
// //                     ...state,
// //                     input:e.target.value
// //                 }
// //                 )
// //             }}
// //             />
// //         </label>
// //         <button type="text" 
// //         onClick= {(e) => {
// //             e.preventDefault()
// //             setState({
// //             ...state,
// //             list : [...state.list,state.input]
// //         })}}
// //         >
// //          submit   
// //         </button>
         
// //         {state.list && state.list.length > 0 && state.list.map((i,k) => {
// //             return <p>{i}</p>
// //         })}
// //         </form>
// //     </div>
// // }

// export default Test;
import React from "react";
import Header from './Common/Header';
import Footer from './Common/Footer';
import history from "./../stores/history"
import Banner from './HomeSection/Home_Banner1'
import Testimonials from './HomeSection/Testimonals';
import App_Section from './HomeSection/App_Section';
import { connect } from 'react-redux'
import * as actions from '../actions/Jobs'
import {getHome} from '../actions/Home'

class Jobs extends React.Component{
    constructor(props){
        super(props)
        
    }

    // componentWillMount() {   
    //     let pathId = this.props.location.pathname.split('/')[2] 
    //     this.props.getJobs(pathId)
    // }

    componentDidMount() {
        this.props.getHome()
        let pathId = this.props.location.pathname.split('/')[2] 
        this.props.getJobs(pathId)
        let removingElament = document.getElementById("design_app_style");
        // console.log(removingElament, 'removingElament')  
        if (removingElament !== null) {
            removingElament.remove()
        }
        const elem2 = document.createElement("link");
        elem2.rel = "stylesheet"
        elem2.type = "text/css"
        elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
        // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
        elem2.id = "custom_app_style"
        elem2.async = true;
        document.head.appendChild(elem2);
    }

    componentWillReceiveProps(nextProps) {
        // require('../assets/css/custom-style.css');
        if (nextProps.location !== this.props.location) {
            
            let removingElament = document.getElementById("design_app_style");
            // console.log(removingElament, 'removingElament')  
            if (removingElament !== null) {
                removingElament.remove()
            }
            
            const elem2 = document.createElement("link");
            elem2.rel = "stylesheet"
            elem2.type = "text/css"
            elem2.href = process.env.PUBLIC_URL+"/assets/css/custom-style.css";
            // src={process.env.PUBLIC_URL+"/assets/images/app-store-icon.png"}
            elem2.id = "custom_app_style"
            elem2.async = true;
            document.head.appendChild(elem2);
                // let pathId = this.props.location.pathname.split('/')[2]
                let pathId = window.location.pathname.split('/')[2]
                // console.log(pathId, 'disabled')
                this.props.getJobs(pathId)
            }
        
        };
     
    render(){

        return(
            <div>
               
               {/* Main Wrapper Starts here */}
                <div className="container-fluid main-wrap">
                <Header/>
                {/* Hero Section Starts here */}
                <section className="row hero-section category-hero">
                    {
                        this.props.panelInfo.panel1_background && 
                        <img className="img-fluid full-banner" 
                            // style = {{height:'600px'}}
                          src={this.props.panelInfo.panel1_background} alt="icon"
                        // src={process.env.PUBLIC_URL+"/assets/images/logistics-slide.jpg"} alt="icon"
                         />    
                    }
                    
                    {
                        this.props.panelInfo &&
                        <div className="container-fluid hero-cont">
                        <div className="container">
                            <div className="banner-cont">
                            <h1>
                                {/* Get Reliable Workers For Your Logistics &amp; Warehouse Business */}
                                {
                                //    console.log(this.props.panelInfo.panel1_title, 'panel1_content()()'),
                                    this.props.panelInfo.panel1_title
                                }
                            </h1>
                            <span>
                                {
                                    this.props.panelInfo.panel1_content
                                }
                                {/* Whether you need workers for your warehouse or delivery drivers for your fleet, FlexiJobs can help. Switch to our end-to-end staffing platform and quickly find qualified workers tailored to your needs. */}
                            </span>
                            <button className="btn btn-blue"
                            onClick = {(e) => {

                                localStorage.getItem('emp_id') ?
                                history.push('/create/job-post'):
                                history.push('/login_hire')
                            }
                            }
                            >Post a Job</button>
                            </div>
                        </div>
                        </div>
                    }
                   
                </section>
                {/* Hero Section Ends here */}
                {/* Feature Section Starts here */}
                <section className="row feature-wrap category-wrap mt-5">
                    <div className="swril-wrap container-fluid p-0">
                    <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/yellow-swirl.svg"} alt="elements" />
                    </div>
                    <div className="element-wrap">
                    <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/elements-1.svg"} alt="elements" />
                    </div>
                    <div className="swril-wrap btm container-fluid p-0">
                    <img className="img-fluid" src={process.env.PUBLIC_URL+ "/assets/images/yellow-swirl.svg"} alt="elements" />
                    </div>
                    <div className="container">
                    <div className="row">
                        <div className="col-lg-6">
                        {
                        this.props.panelInfo &&
                        <div className="feature-item">
                            <h2>
                                {
                                    this.props.panelInfo.panel2_title
                                }
                                {/* Get Qualified Logistics and Warehouse Staff with FlexJobs */}
                            </h2>
                            <p>
                            {/* We have a large network of pre-screened, experienced workers immediately available for long term, fixed term, or casual hiring needs */}
                            {
                                this.props.panelInfo.panel2_content
                            }
                            </p>
                            <ul className="list-unstyled">
                                {
                                  this.props.panelInfo.staffs_list && this.props.panelInfo.staffs_list.length > 0 &&
                                  this.props.panelInfo.staffs_list.map((i, k) => {
                                      return (
                                        <li key= {k}>
                                            {i.item_name}
                                            {/* Picker and Packer */}
                                        </li>
                                        // <li>General Labourers</li>
                                        // <li>Couriers and Drivers</li>
                                      )
                                  })
                                }
                            
                            </ul>
                        </div>
                        }
                        </div>
                        <div className="col-lg-6">
                        <div className="feature-img">
                            {
                              this.props.panelInfo.panel2_image &&    
                              <img 
                              src= {this.props.panelInfo.panel2_image}
                              className="img-fluid" 
                            //   src={process.env.PUBLIC_URL+ "/assets/images/logistics-feature-img.jpg"} 
                              alt="image" 
                              />
                            }
                            
                        </div>
                        </div>
                    </div>
                    </div>
                </section>
                
                <App_Section/>
                {/* App Section Ends here */}
                </div>
                {/* Main Wrapper Ends here */}
                <Footer/>
                {/* Modal Wrapper Starts here */}

            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        panelInfo : state.Jobs.panelInfo
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
        getJobs: (data) => dispatch(actions.getJobs(data)),
        getHome : () => dispatch(getHome())
    }
};

const jobs = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Jobs);

export default jobs;
export function convertDateFormate(date, format) {
    if (format === 'month') {
        return date
    } else {
        return date
    }
}
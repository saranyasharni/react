import React, { useEffect } from "react";
import { connect } from 'react-redux';

function Loader(props) {    
    // let marginProps = props.margin ? props.margin : ''
    return (
        <div className="spinner-border text-primary" role="status"
        style = {{
            marginLeft:props.marginLeft,
            marginTop:props.marginTop
        }}
        >
            <span className="sr-only">Loading...</span>
        </div>  
        // <>
        // <img 
        // src={process.env.PUBLIC_URL + "/assets/images/loader.gif"} alt="icon" 
        // style = {
        //     {
        //        marginLeft : marginProps  
        //     }
        // }
        // />
        // <p>Loading...</p>   
        // </>
    )
}


const mapStateToProps = (state, ownProps) => {
    return {
        
    };

};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Loader);
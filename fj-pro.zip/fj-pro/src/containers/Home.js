import { connect } from 'react-redux'
import HomeComponent from '../components/Home'
import * as actions from '../actions/Home';

const mapStateToProps = (state, ownProps) => {
  return {
    // latestArticlesList: state.Home.latestArticles,
   
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getHome: () => dispatch(actions.getHome()),
    // getJobs: () => dispatch(actions.getAllJobs())
  }
};

const Home = connect(
  mapStateToProps,
  mapDispatchToProps,
)(HomeComponent);

export default Home;

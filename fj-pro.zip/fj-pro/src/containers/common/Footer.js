import { connect } from 'react-redux'
import FooterComponent from '../../components/common/Footer'
import * as actions from '../../actions/common/Footer';

const mapStateToProps = (state, ownProps) => {
  return {
  
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
  
  }
};

const Footer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(FooterComponent);

export default Footer;

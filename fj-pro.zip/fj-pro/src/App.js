import React, { Component } from "react";
import Routes from './routes'
import { Provider } from 'react-redux'
import configureStore from './stores/configureStore';
function App() {
  
  React.useEffect(() => {
    
    //eslint-disable-next-line
  }, []);

  
    return (
      <Provider store={configureStore()} >
        
          <Routes 
          
          />
        
      </Provider>
    );
  

}

export default App;

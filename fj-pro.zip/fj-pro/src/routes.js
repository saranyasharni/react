import React, { Component, Fragment } from "react";

import {
  BrowserRouter as Router,
  Switch,
  Route,
  withRouter,
} from "react-router-dom";
import PrivateRoute from './PrivateRoute';
import ScrollTop from "./ScrollTop";
import Home from "./containers/Home";
import Job from "./components/Job";
import Worklogin from "./components/AccountSection/login_work";
import Hirelogin from "./components/AccountSection/login";
import Worksignup from "./components/AccountSection/signup_work";
import Hiresignup from "./components/AccountSection/signup";
import ForgotPassword from "./components/AccountSection/forgotPassword";
import vericationPage from "./components/AccountSection/verification";
import ResetPassword from "./components/AccountSection/resetPassword";
import EmployerResetPassword from "./components/AccountSection/EmployerResetPassword";
import ScheduleViewProfile from "./components/Employer/Hire/ScheduleViewProfile";
import Employee_Applied_jobs from "./components/EmployeeMainPages/Employee_applied_job";
import EmployeeDashboard from "./components/EmployeeMainPages/EmployeeDashboard";
import Employee_applied_job_list from "./components/EmployeeMainPages/Employee_applied_job_list";
import EmployeeViewJobs from "./components/EmployeeMainPages/EmployeeViewJobs";
import EmployeeViewJobsList from "./components/EmployeeMainPages/EmployeeViewJobsList";
import WorkingJobDetail from "./components/Employee/EmployeeAppliedJobs/WorkingJobDetail";
import EmployerPostedJobList from "./components/EmployerMainPages/postedJobs";
import EmployerPostedJobDetails from "./components/Employer/postedJobDetails";
import CreateJobPost from "./components/EmployerMainPages/CreateJobPost"
import HireStaff from "./components/EmployerMainPages/Hire1";
import Interviews from "./components/EmployerMainPages/Interview"
import viewProfile from "./components/Employer/Hire/ViewProfile";
import Mycompany from "./components/EmployerMainPages/myCompany"
import JobPost from "./components/EmployerMainPages/JobPost";
import PaymentSelectPage from "./components/Employer/Hire/PaymentSelectPage";
import AccountVerifications from './components/AccountSection/EmailVerificationOtp';
// import EmployerChat from "./components/EmployerMainPages/Chat";
// import EmployeeChat from "./components/EmployeeMainPages/Chat";
import MyProfile from "./components/EmployeeMainPages/MyProfile"
import EmployerDashboard from "./components/EmployerMainPages/EmployerDashboard";
import EmployerAppliedJob from "./components/EmployeeMainPages/Employee_applied_job";
import Employee_applied_job_details from "./components/Employee/EmployeeAppliedJobs/Employee_applied_job_details";
import Employee_view_job_details from "./components/Employee/viewJob/viewJob_details";
import Workers from "./components/EmployerMainPages/Workers";
import Offers from "./components/EmployeeMainPages/Offers";
import Recriutment from "./components/EmployerMainPages/Recruitment";
import verification_email from "./components/AccountSection/EmailVerification";
import ViewJobOffer from './components/EmployeeMainPages/OfferDetail';
import employeeNotifictions from './components/EmployeeMainPages/EmployeeNotifications'
import Notifictions from './components/EmployerMainPages/Notifications'
import Transactions from './components/EmployerMainPages/Transactions'
import Credits from './components/EmployerMainPages/Credits'
// import test from './components/dropdown'
import Request from './components/EmployeeMainPages/Requests'
class Routes extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      socket: [] 
    };
  }

  componentDidMount () {
      // const token = localStorage.getItem("CC_Token"); 
  }

  render() {
    return (
      <Fragment>
        <ScrollTop />
        <Switch>
          <Route exact path="/" component={Home} />
          {/* <Route exact path="/dropdown" component={test} /> */}
          <Route exact path="/jobs/:id" component={Job} />
          <Route exact path="/login_work" component={Worklogin} />
          <Route exact path="/login_hire" component={Hirelogin} />
          <Route exact path="/signup_work" component={Worksignup} />
          <Route exact path="/signup_hire" component={Hiresignup} />
          <Route exact path= "/verification_wait_page" component={verification_email}/>
          <Route
            exact
            path="/employee/forgot_password"
            component={ForgotPassword}
          />
          <Route
            exact
            path="/employer/forgot_password"
            component={ForgotPassword}
          />
          <Route
            exact
            path="/employee/account_verification"
            component={AccountVerifications}
          />
          <Route
            exact
            path="/employer/account_verification"
            component={AccountVerifications}
          />
          {/* <Route exact path="/events/photos/:id" component={EventPhotos} /> */}
          <Route
            exact
            path="/employee/reset_password/:id"
            component={ResetPassword}
          />
          <Route
            exact
            path="/employer/reset_password/:id"
            component={EmployerResetPassword}
          />
          <Route exact path="/verify" component={vericationPage} />
          
          <Route
            exact
            path="/employee_applied_jobs"
            component={Employee_Applied_jobs}
          />

          <Route
            exact
            path="/view-profile/schedule/:id/:employee_id"
            component={ScheduleViewProfile}
          />

          <Route
            exact
            path="/employee-dashboard"
            component={EmployeeDashboard}
          />
          <Route
            exact
            path="/employee_applied_job_list"
            component={Employee_applied_job_list}
          />
          <Route
            exact
            path="/employee-view-jobs"
            component={EmployeeViewJobs}
          />
           <Route
            exact
            path="/employer_posted_job_list/:filter"
            component={EmployerPostedJobList}
          />
           <Route
            exact
            path="/employer_posted_job_details/:id"
            component={EmployerPostedJobDetails}
            />
          <Route
           exact 
           path = "/job-post"
           component = {JobPost}
          />
          <Route
           exact 
           path = "/create/job-post"
           component = {CreateJobPost}
          />
          <Route exact path = "/:job_status/job-post/:id"
           component = {CreateJobPost}
          />
          {/* <Route exact path = "/employer/chat"
           component = {EmployerChat}
           socket = {this.state.socket}
          /> */}
          <Route exact path = "/employer/dashboard"
           component = {EmployerDashboard}
          />
          <Route exact path = "/view-profile/:id/:employee_id/:path_name"
           component = {viewProfile}
          />
          <PrivateRoute
           exact 
           path = "/hire-staff"
           component = {HireStaff}
          />
          <PrivateRoute
           exact 
           path = "/hire-staff/:path_name"
           component = {HireStaff}
          />
          <PrivateRoute
           exact 
           path = "/hire-staff/:path_name/:cat_id/:pos_id"
           component = {HireStaff}
          />
          <Route
           exact 
           path = "/my_company"
           component = {Mycompany}
          />

          <Route
           exact 
           path = "/employee_applied_jobs"
           component = {EmployerAppliedJob}
           />

          <Route
           exact 
           path = "/employee_applied_jobs_details/:id/:status"
           component = {Employee_applied_job_details}
           />

          <Route
           exact 
           path = "/workers"
           component = {Workers}
          />
          <Route
           exact 
           path = "/extended-requests"
           component = {Request}
          />
           
          <Route
           exact 
           path = "/employee_view_jobs_details/:id"
           component = {Employee_view_job_details}
          />
          <Route
           exact 
           path = "/my-profile"
           component = {MyProfile}
          />
          {/* <Route
           exact 
           path = "/employee/chat"
           component = {EmployeeChat}
          />  */}
          <Route
           exact 
           path = "/recruitment"
           component = {Recriutment}
          />
          {/* <Route
           exact 
           path = "/employee/chat/:id"
           component = {EmployeeChat}
          /> */}

          <Route 
          exact path = "/view-applied-profile/:id" 
          component = {WorkingJobDetail} 
          />
          
          <Route 
          exact path = "/transactions" 
          component = {Transactions} 
          />

          <Route 
          exact path = "/credits" 
          component = {Credits} 
          />

          <Route exact path = "/payment" component = {PaymentSelectPage} />
          <Route exact path = "/view-job-offer/:status/:id" component = {ViewJobOffer} />
          <Route exact path = "/interviews" component = {Interviews} />
          <Route exact path = "/offers" component = {Offers} />
          <Route exact path = "/employee-notifications" component = {employeeNotifictions} />
          <Route exact path = "/employer-notifi-cations" component = {Notifictions} />
           
        </Switch>
      </Fragment>
    );
  }
}

export default withRouter(Routes);

const values={
    password_new:'',
    password_conf:'',
    type:"password",
    display:false,
    type_conf:"password",
    display_conf:false,
    same_check:false,
    length_check:false,
    number_check:false,
    string_check:false,
    varient:'',
    show_alert:false,
    showMsg:'',
};


export const PasswordSet = (state = values, action) => {
    switch (action.type) {
        case 'SET_PASSWORD':
            return { ...state, [action.pro]: action.val }

        default:
            return state;
    }
}
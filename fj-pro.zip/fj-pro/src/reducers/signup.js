const init = {
    jobs: [],
    testimonials: [],
    dashboard: [],
};

export const Home = (state = init, action) => {

    switch (action.type) {
        
        default:
            return state;
    }
};
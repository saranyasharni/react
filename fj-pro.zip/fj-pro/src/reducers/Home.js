const init = {
    jobs: [],
    testimonials: [],
    dashboard: [],
    show: false,
    show_login: false,
    completion_year_arr : [],
    industries : [],
    skills:[],
    banks:[],
    positions : [],
    listlanguages : [],
    listqualifications: []
};

export const Home = (state = init, action) => {

    switch (action.type) {
        case'PASSED_YEARS':
            let completion_year_arr = [] 
            for(let i=2026; i>= 1996; i--) {
                
                completion_year_arr.push(i)
            }
            return {...state, completion_year_arr:completion_year_arr}
        case "SET_QUALIFICATIONS":
            return {...state, listqualifications : action.data}
        case "SET_LANGUAGES":
            return {...state, listlanguages : action.data}
        case "SET_INDUSTRIES":
            return {...state, industries : action.data}
        case "SET_SKILLS":
            return {...state, skills : action.data}
        case "SET_BANKS":
            return {...state, banks : action.data}
        case "SET_POSITIONS":
            return {...state, positions : action.data}
        case 'SET_JOBS':

            return { ...state, jobs: action.data }
        case 'SET_TESTMONALS':
            // alert('jkio')
            return { ...state, testimonials: action.data }
        case 'SET_DASHBOARD':

            return { ...state, dashboard: action.data }
        case "UPDATE_FIELDS":
            return { ...state, [action.field]: action.data }
        default:
            return state;
    }
};
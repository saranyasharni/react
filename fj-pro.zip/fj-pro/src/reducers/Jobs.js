const init = {
    panelInfo: [],
    industry_new:'',
    industries_id :'',
    showAmount :'',
    
    days_format_array: 
        [            
        {
            class:'',
            day_name:'Mon'   
        },
        {
            class:'',
            day_name:'Tue'
        },
        {
            class:'',
            day_name:'Wed'
        },
        {
            class:'',
            day_name:'Thu'
        },
        {
            class:'',
            day_name:'Fri'
        },
        {
            class:'',
            day_name:'Sat'
        },
        {
            class:'',
            day_name:'Sun'
        },
    ],
        number_of_days : '',
        number_of_hours : '',
        aboveSixtySalary: {
            employer_epf:"",
            employer_socso:"", 
            employer_eis:"",
            actual_salary_paid_by_employer:"",
            total_salary_base_by_employer:"",
            employee_epf:"",
            employee_socso:"",
            employee_eis:"",
            reduced_salary_for_employee:"",
            fj_admin_fee:""
        },

        belowSixtySalary : {
            employer_epf:"",
            employer_socso:"", 
            employer_eis:"",
            actual_salary_paid_by_employer:"",
            total_salary_base_by_employer:"",
            employee_epf:"",
            employee_socso:"",
            employee_eis:"",
            reduced_salary_for_employee:"",
            fj_admin_fee:""
        },
    industry:'',
    jobPosition:'',
    vacancy:'',
    jobTitle:'',
    jobDesc:'',
    jobType:'Part-Time',
    loading :false,
    salaryBased:'Per Hour',
    currency:"RM",
    amount:'',
    gender:'',
    experience : '',
    requirements_work_experience:"",
    requirements_language:false,
    requirements_age_limit:false,
    showDateStart :'',
    showDateEnd:'',
    scheduleStartDate:'',
    scheduleStartTime:'',
    scheduleEndDate:'',
    scheduleEndTime:'',
    shiftBreakStart:'',
    shiftBreakEnd:'',
    location:'',
    lat:'',
    lon:'',
    marker:{
        location:'',
        lat:'',
        lon:'',
    },
    errors:{},
    job_created_status: '',
    show:false,
    varient:'',
    showMsg:'',
    draftLoading:false
};

export const Jobs = (state = init, action) => {
    switch (action.type) {
        case "DRAFT_LOADING":
            return {...state, draftLoading:action.data}
        case "SET_SALARY_CONTRIBUTION":
            return {...state, salaryContributions:action.data}
        case "SET_LOADING":
            return {...state, loading : action.data}
        case 'PANEL_INFO':
            return { ...state, panelInfo: action.data }
        case 'CHANGE_INPUT': 
            // alert()
            // console.log(action.field, action.value, "lat, lng .............................");
            return {...state, [action.field]: action.value}
        case 'SET_SHOW':
            return { ...state, show: action.data };
        case 'UPDATE_ERRORS':
            return { ...state, errors: { ...state.errors, ...action.data } };
        case 'RESET_FORM':
            console.log(action.data, 'claering')
            return {...state, ...action.data}
        case 'SET_SCHEDULE':
            // console.log(action.data, 'action.data')
            return {...state, days_format_array:action.data}
        case 'EDIT_JOB':
            console.log(action.data, "action *****************************");
            console.log(state, "state ....................................");
            return {...state, ...action.data}    
        case 'SET_SUCCESS':
            if (action.data === 1) {
                return { ...state, 
                    job_created_status: action.data,
                    show:true,
                    varient:'success',
                    showMsg: action.msg
                };
            } else {
                return { ...state, 
                    job_created_status: action.data,
                    show:true,
                    varient:'danger',
                    showMsg: action.msg
                };
            }
                
        default:
            return state;
    }
};
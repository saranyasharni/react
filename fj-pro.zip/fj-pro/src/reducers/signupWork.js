const init = {
    errors : {},
    empName: '',
    dob:'',
    url : '',
    gender:'',
    country_code:'+60',
    phone_number: '',
    Email: '',
    qualification_ot:'',
    emailExists: false,
    loading:false,
    Address:'',
    city:'',
    postal_code:'',
    mailing_address_postal_code:'',
    mailing_address_city:'',
    mailing_address1 :'',
    main_roles:'',
    privacy_policy :false,
    resume_file:'',
    is_vaccinated:'',
    proof_document:[],
    resume_privacy_setting:'privacy',
    instution_name:'',
    qualification:'',
    completion_year:'',
    language_skills:[],
    added_cat_id:'',
    added_new_skill_name:'',
    new_skill_added:false,
    new_position_added:false,
    added_new_position:'',
    jobExperience : [
        {
            category:'',
            position:'',
            company_name:'',
            start_date:'',
            end_date:'',
            new_position:0,
            responsibilities:'',
            current_company:'no'
        }
    ],
    multiSkills:[
        {skill_name:'',experience:'', extra_skill:0}
    ],
    language:'',
    spoken:'',
    read:'',
    written:'',
    password:'',
    confirm_password:'',
    employee_register_status: 2,
    show:false,
    varient:'',
    showMsg:'',
    landline_number: '',
    land_line_country_code:'+60',
    user_name: '',
    company_name: '',
    company_registration_number: '',
    billing_checkbox:false,
    mailing_address: '',
    file_name:'',
    skill_name : '',
    skill_experience : '',
    billing_address: '',
    company_landline_number: '',
    company_land_line_country_code : '+60',
    company_mobile_number: '',
    company_number_country_code: '+60',
    last_name:'',
    ic_number : '',
    total_experience:"",
    epf :'',
    socso :'',
    bank_name:'',
    bank_account_number :'',
    disability:false,
    desc_disability:''
};

export const signupWork = (state = init, action) => {

    switch (action.type) {
     
        case 'ADD_MORE_FIELD':
            // alert()
            return { ...state, [action.field]: [...state[action.field], action.data] }
            // return {...state, jobExperience:[...state.jobExperience, {
            //     category:'',
            //     position:'',
            //     company_name:'',
            //     start_date:'',
            //     end_date:'',
            //     current_company:false,
            //     responsibilities:''
            // }]}
        case 'INPUT_CHANGE':   

        //   console.log(action.value, 'act')
            return { ...state, [action.field]: action.value }
        case 'RESET_FORM':
            return {...state, ...action.data}
        case 'SET_LOADING':
            // alert(action.data)
            return {...state, loading:action.data}
        case 'SIGNUP_EMP_STATUS':
            if (action.data === 1) {
                return { ...state, 
                    employee_register_status: action.data,
                    show:true,
                    varient:'success',
                    showMsg: action.message
                };
            } else {
                return { ...state, 
                    employee_register_status: action.data,
                    show:true,
                    varient:'danger',
                    showMsg: action.message
                };
            }
            case 'EMAIL_EXISTS':
                console.log(action, "reducer ...................")
                return { ...state, 
                    emailExists: action.data
                };
                    
        case 'UPDATE_ERRORS':
            return { ...state, errors: { ...state.errors, ...action.data } };

        case 'SET_SHOW':
            return { ...state, show: action.data };

        case 'All_LANG_SKILLS': 
            
            return {...state, language_skills: [...state.language_skills, {...action.data}]}
        default:
            return state;
    }
};
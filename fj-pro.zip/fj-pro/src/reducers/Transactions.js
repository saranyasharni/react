const init = {
    transactionList: [],
    creditList:[]
};

export const Transactions = (state = init, action) => {

    switch (action.type) {
        case 'SET_TRANSACTIONS':
            // console.log(action.data, 'action.data')
            return { ...state, transactionList: action.data }
        case 'SET_CREDITS':
            return { ...state, creditList: action.data }
        default:
            return state;
    }
};
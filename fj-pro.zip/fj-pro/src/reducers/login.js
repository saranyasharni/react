const value = {
    user_name: "",
    password: '',
    user_fill: false,
    pass_fill: false,
    valid_email : false,
    varient:'',
    show_alert:false,
    showMsg:'',
}

export const Login = (state = value, action) => {
    switch (action.type) {
        case 'SET_HIRE_LOGIN':
            return { ...state, [action.key]: action.val }

        default:
            return state;
    }
}
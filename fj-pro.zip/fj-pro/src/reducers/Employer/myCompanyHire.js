const input ={
    company_name:"",
    location:'',
    about_company:'',
    no_of_employees:'0-50',
    business_type:'super market',
    company_no:'',
    landline:'',
    code:'',
    mobile:'',
    address:'',
    addressLine1:'',
    address_city:'',
    address_pincode:'',    
    billing_adderess_line1:'',
    billing_adderess_city:'',
    billing_adderess_pincode:'',
    billing_adderess:'',
    certificate:[],
    same_as_billing_address:false,
    profile_pic:'',
    copy_address:false,
    varient:'',
    show_alert:false,
    showMsg:'',
};



export const ProfileCompany = (state = input, action) => {
    
    switch (action.type) {
        case "COMPANY_DATAS":
            // console.log(action.data, 'action.data')        
            return { ...state, [action.field]: action.data }
            case "CERTIFICATE":
                return { ...state, certificate: [...state.certificate, action.data] }
            case "IMG_REMOVE":
                const rem = state.certificate
                rem.splice(action.data, 1);
                return { ...state, certificate:[...rem] }
                
        default:
            return state;
    }
}
const init = {
    chatContents:[],
    chatRoomId:'',
    chatProfile: [],
    chat_status: 0
};

export const Chat = (state = init, action) => {
    switch (action.type) {
        case 'SET_CHAT_MSG':
            return {...state, chatContents:action.data}
        case 'SET_SEND_MSG_STATUS':
            
            return {...state, chat_status:action.data}
        case 'SET_PROFILE_INFO':
            return {
                ...state, chatProfile:action.data
            }
        case 'SET_CHAT_ROOM':
            return {
                ...state, chatRoomId:action.data
            }
        case 'UPDATE_MSG':
            return {
                ...state, chatContents:[...state.chatContents, ...action.data]
            }
        default:
            return state;
    }
};
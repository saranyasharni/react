const init = {
    limit:16,
    page_no :0,
    extra_loading_status:0,
    employeeLists:[],
    hire_emp_id:"",
    UnEmployeesLists:[],
    shortListedEmployees:[],
    loading : false,
    extraLoading : false,
    modelLoading:false,
    btnLoading : false,
    wort_start_time :'',
    work_status:0,
    page_no : 0,
    modelPaymentShow:false,
    hire_status:0,
    show: false,
    varient:'',
    modelShowPosition:"hide",
    modelRequestStatus: 0,
    positions : [],
    showMsg: '',
    disable: false,
    workers: [],
    modelSchedule: {},
    modelShortList: {},
    scheduleList : [],
    rejectedList : [],
    listOnePosition : [],
    profileContactStatus : 0,
    viewType : false,
    apiCall : 0,
    status:0,
    showHireModel:false,
    showJobHire:false,
    showContractModel:false,
    candidateDetail : [],
    hired_status: 0,
    hired_status_msg : '',
    salaryContributions: [],
    scheduleModels : {} ,
    walletAmount: "",
    hire_text :'Hire',
    shortlist_text :'Shortlist',
    interview_text :'Schedule Interview',
    profile_url:null,
   
};

export const Hire = (state = init, action) => {
    switch (action.type) {
        
        case "SET_EXTRA_LOADING":
            return {...state, extraLoading:action.data}
        case 'UPDATE_PAGE_NUMBER':
            return {...state, page_no:action.data}
        case 'SET_AMOUNT':
            return {...state, walletAmount:action.data}
        case 'SET_HIRED_STATUS':
            return {...state, hired_status: action.val,
                hired_status_msg: action.data
            }
        case "SET_MODEL_LOADING":
            return {
                ...state, modelLoading:action.data
            }
        case 'SET_CONTRACT_MODAL':
            return {...state, showContractModel: action.data}
        case 'SET_CANDIDATE':
            return {...state, candidateDetail: action.data}
        case 'HIRE_CANDIDATE_MODALS':
            
            return {
                ...state, showHireModel:action.data,
                showJobHire:action.show,
                hire_emp_id : action.emp_id,
                profile_url : action.url
            }
        case 'SET_SEARCH_API_CALL':
            return {...state, apiCall:action.data}
        case 'SET_LOADING':
            return {...state, loading:action.data}
        case 'SET_SHOW_VIEW_LIST':
            return {...state, viewType :action.data}
        case 'SET_WORKERS':
            return {...state, workers:action.data}
        case 'SET_CONTACT_INFO':
            return {...state, profileContactStatus :action.data}
        case 'SET_REJECTED_LISTS':
            return {...state, rejectedList:action.data}
        case 'SET_SCHEDULES_LISTS':
            return {...state, scheduleList:action.data}
        case 'SET_EMPLOYEE-LISTS':
            return {...state, employeeLists:action.data}
        case 'SET_EXTRA_SEARCH_EMP_LIST':
            return {...state, UnEmployeesLists:[...state.UnEmployeesLists,...action.data]}
        case 'SET_UNAPPLIED_LISTES':
            return {...state, UnEmployeesLists:action.data}
        case 'SET_ONE_POSITION':
            return {...state, listOnePosition:action.data}
        case 'SET_SHORTLISTED_EMPLOYEES':
            return {...state, shortListedEmployees:action.data}   
        case 'SHOW_RESPONSE_MSG':
            if (action.val === 1) {
                return {
                    ...state, 
                    hire_status: action.val,
                    status:action.val,
                    show:true,
                    varient:'success',
                    disable: false,
                    showMsg: action.data
                };
            } else if (action.val === 3) {
                  return { ...state, 
                    hire_status: action.val,
                    status:action.val,
                    show:true,
                    varient:'info',
                    disable: true,
                    showMsg: action.data
                };
            } else {
                return { ...state, 
                    hire_status: action.val,
                    status:action.val,
                    show:true,
                    disable: true,
                    varient:'danger',
                    showMsg: action.data
                };
            }
        case 'SET_POSITIONS': 
            return {...state, positions:action.data}
        case 'SET_SHOW':
            return { ...state, show: action.data };
        case 'SET_BTN_SHOW':
            return { ...state, btnLoading: action.data };
        case 'SET_PAYMENT_MODEL':
            return { ...state, modelPaymentShow: action.data };
        case 'SET_EXTRA_LOADING_STATUS':
            
            return {...state, extra_loading_status:action.data}
        case 'SET_SHOW_HIDE':
            
            return { ...state, 
                modelSchedule: action.data, 
            };
        case 'SET_SCHEDULE_MODEL':
  
            return {
                ...state,
                scheduleModels: action.data
            }
        case 'SET_SHOW_SHORTLIST':
            console.log(action.data, "actions ........................")
            return {...state, modelShortList: action.data}
        default:
            return state;
    }
};
const values = {
    currentWorkers: [],
    workerDetails: {},
    showModel : false,
    show:false,
    varient:'success',
    disable: false,
    requestModal:false,
    loading:false,
    request_status:0,
    employee_id :'',
    job_id : '',
    showMsg: '',
    modelMessage:'',
    modelStatus:0,
    status:0,
    loginReport : [],
    lateRequests : []
};
  
  
  export const Workers = (state = values, action) => {
    switch (action.type) {
        case 'SET_DATA':
            
            return{...state, 
                employee_id:action.data.employee_id,
                job_id:action.data.job_id
            }
        case 'SET_LOADING':
            return {...state, loading:action.data }
        case 'SET_SHOW':
            return { ...state, show: action.data };
        case "SET_LATE_REQUESTS":
            return {...state, lateRequests: action.data}
            
        case "SET_CURRENT_WORKERS":
            return { ...state, currentWorkers: action.data }
        case "EDIT_WORKER":
            // console.log(action.data, 'action.data')
            return {
                ...state, workerDetails: action.data,
            }
        case "SET_LOGIN_REPORT":
           
            return { ...state, loginReport: action.data }
        case 'SET_MODAL_SUCC':
            console.log(action.msg, action.data, 'data')
            return { ...state, modelMessage: action.msg,
                modelStatus:action.data
            }
        case 'SHOW_RESPONSE_MSG':
        if (action.val === 1) {
            return {
                ...state, 
                status: action.val,
                show:true,
                varient:'success',
                disable: false,
                showMsg: action.data
            };
        } else if (action.val === 2) {
            return { ...state, 
                status: action.val,
                show:true,
                disable: true,
                varient:'danger',
                showMsg: action.data
            };
            
        } else {
            
            return { ...state, 
                status: action.val,
                show:false,
                disable: true,
                varient:'',
                showMsg: ""
            };
        }
        case "HANDLE_MODEL":
            return {...state, showModel:action.data}
        case "EXTEND_REQUEST_MODAL":
            return {...state, requestModal:action.data}
        case "SET_VALUES":
            return {...state, [action.field]:action.value}
        default:
            return state;
      }
  }
const init = {
    position:null ,
    location : null,
    filter : 0,
    industry_type :null,
    experience : null,
    search_term : null,
    limit:15,
    page_no : 0,
    lat:null,
    lon:null,
    is_vaccinated:false
};

export const Filters = (state = init, action) => {

    switch (action.type) {
        
        case "SET_SEARCH_EMP_FILTER":
            console.log(action.data, 'data')
            return { ...state, [action.field]: action.data }
        default:
            return state;
    }
};
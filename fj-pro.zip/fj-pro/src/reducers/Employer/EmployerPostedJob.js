import { data } from "jquery";

const values = {
  views_show:false,
  applicant_show:false,
  shortlist_show:false,
  share_show:false,
  grid:false,
  list:true,
  grid_active:"",
  list_active:"active",
  job_list:[],
  drafted_jobs:[],
  get_details:[],
  job_id:"",
  view_list:[],
  applicant_list:[],
  short_list:[],
  closed_jobs_list:[],
  varient:'',
  show_alert:false,
  showMsg:'',
  search:'',
  sort_asc:true,
  filter_term:'',
  filter:0,
  filter_name:"",
  active_status:"active",
  searchDisplay:"none",

};


export const Postedjob = (state = values, action) => {

    switch (action.type) {
        case "POSTED_JOBS":
            // console.log(action.data,action.field, 'action.data')
            return { ...state, [action.field]: action.data }
        case "SORT_JOBS":
            console.log(state.job_list,action.activeData,action.data, 'SORT_JOBS')
            console.log(action.activeData,action.data, 'action.activeData,action.data')
            var res = [];
            if (action.activeData === 'active' && action.data === 'ascending') {
                if (action.data === 'ascending') {
                    
                    // console.log(res, 'res12')    
                } else if (action.data === 'desending') {
                    res.reverse()
                } else {
                    res = state.job_list
                }
            }
            // console.log(action.activeData, 'action.activeData')
            // let sort_res= [];
            // if (action.activeData === 'active') {
                
                // sort_res = state.job_list
            // } else if (action.activeData === 'closed') {
            //     sort_res = state.closed_jobs_list
            // }  else if (action.activeData === 'drafted') {
            //    sort_res = state.drafted_jobs
            // }     
                // alert(action.data)
            //     console.log(sort_res, 'sort_res')
          
            
            // console.log(res, 'res12')
            return {...state, job_list:res}
        default:
            // console.log(state, 'statr809809')
            return state;
    }
}
import { combineReducers } from 'redux'
import { connectRouter } from 'connected-react-router'
import { Home } from './Home';
import { Login } from './login';
import { Login_work } from './login_work';
import {PasswordSet} from './resetPassword';
import {Jobs} from './Jobs';
import {signupWork} from './signupWork';
import {Postedjob} from './Employer/EmployerPostedJob';
import {Hire} from './Employer/Hire';
import {ProfileCompany} from './Employer/myCompanyHire';
import {Chat} from './Employer/Chat';
import {Appliedjob} from './Employee/AppliedJobs';
import {Emp_Profile} from './Employee/MyProfile';
import {Emp_View_Job} from './Employee/viewJob';
import {Emp_Dasboard} from './Employee/Dashboard'
import {Workers} from './Employer/Workers';
import {Offers} from './Employee/Offers';
import {Notifications} from './Notifications';
import {Filters} from './Employer/Filters'
import {Transactions} from './Transactions'
export default combineReducers({
    Home,
    Jobs,
    signupWork,
    Login,
    Login_work,
    PasswordSet,
    Hire,
    Chat,
    Postedjob,
    ProfileCompany,
    Appliedjob,
    Emp_Profile,
    Emp_View_Job,
    Emp_Dasboard,
    Workers,
    Offers,
    Notifications,
    Filters,
    Transactions
});
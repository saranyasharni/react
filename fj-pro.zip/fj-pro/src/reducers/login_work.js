const value = {
    user_name: "",
    password: '',
    user_fill: false,
    pass_fill: false,
    valid_email: false,
    varient:'',
    show_alert:false,
    showMsg:'',
}

export const Login_work = (state = value, action) => {
    switch (action.type) {
        case 'SET_WORK_LOGIN':
            return { ...state, [action.key]: action.val }

        default:
            return state;
    }
}
let dash ={
  job_card:[],
  job_info:[],
  job_offer:[],
  varient:'',
  show_alert:false,
  showMsg:'',
};



export const Emp_Dasboard = (state = dash, action) => {

    switch (action.type) {
        case "DASBOARD":
            return { ...state, [action.field]: action.data }
        default:
            return state;
    }
};
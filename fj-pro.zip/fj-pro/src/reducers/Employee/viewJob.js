let view = {
    views_show:false,
    applicant_show:false,
    shortlist_show:false,
    share_show:false,
    grid:false,
    viewStatuslist:true,
    grid_active:"",
    list_active:"active",
    job_list:[],
    get_details:[],
    job_id:"",
    view_list:[],
    applicant_list:[],
    short_list:[],
    closed_jobs_list:[],
    show_alert:false,
    job_applied_status: 0,
    show:false,
    applyLoad : false,
    varient:'',
    showMsg: '',
    search:'',
    filter_term:'',
    filter:0,
    filter_name:"",
    active_status:"active",
    searchDisplay:"none",
    savedJobLists:[]
};

export const Emp_View_Job = (state = view, action) => {

    switch (action.type) {
        case "SET_LOADING":
            return { ...state, applyLoad: action.data };
        case "EMPLOYEE_VIEW_JOB":
            return { ...state, [action.field]: action.data };
        case 'SET_SUCCESS':
            if (action.data === 1) {
               
                return { ...state, 
                    job_applied_status: action.data,
                    show_alert:true,
                    varient:'success',
                    showMsg: action.msg
                };
            } else {
               
                return { ...state, 
                    job_applied_status: action.data,
                    show_alert:true,
                    varient:'danger',
                    showMsg: action.msg
                };
            }
        case 'SET_SHOW':
            return { ...state, show_alert: action.data };
        case 'SAVED_JOB_LIST':
            return {...state, savedJobLists:action.data}
        default:
            return state;
    }
};
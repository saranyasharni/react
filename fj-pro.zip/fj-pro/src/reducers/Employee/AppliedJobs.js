const values = {
    views_show:false,
    applicant_show:false,
    shortlist_show:false,
    share_show:false,
    grid:false,
    list:true,
    grid_active:"",
    list_employer_requests: [],
    list_active:"active",
    job_list:[],
    get_details:[],
    job_id:"",
    view_list:[],
    applicant_list:[],
    short_list:[],
    closed_jobs_list:[],
    varient:'',
    show: false,
    show_alert:false,
    showMsg:'',
    search:'',
    sort_asc:true,
    filter_term:'',
    filter:0,
    filter_name:"",
    active_status:"active",
    searchDisplay:"none",
    working_jobs : [],
    correct_login_date : "",
    correct_login_time : '',
    description : "",
    request_status : 0,
    modelMessage : '',
    urrentJobDetail : [],
    work_status:0,
    work_start_time:"00:00",
    loading:false,
    stop_loading : false
};
  
export const Appliedjob = (state = values, action) => {

    switch (action.type) {
        case 'SET_REQUESTS':
            
            return {...state, list_employer_requests:action.data}
        case 'LOADING':
            return {...state, loading:action.data}
        case 'STOP_LOADING':
            return {...state, stop_loading:action.data}
        case 'SET_WORKING_TIME':
            return {...state,
                work_status:action.data.work_status,
                work_start_time:action.data.work_start_time,
            }
        case 'SET_SHOW':
            return { ...state, show: action.data };
        case "CURRENT_JOB":
            return {...state, currentJobDetail : action.data}
        case "APPLIED_JOBS":
            return { ...state, [action.field]: action.data }
        case "INPUT_CHANGE": 
            return {...state, [action.field]: action.val}
        case "WORKING_JOBS":
            return { ...state, working_jobs: action.data }
        case "MODEL_SUCCESS":
            return {...state, request_status:action.data, 
            modelMessage :action.message
        }
        case 'SET_SUCCESS':
            if (action.data === 1 || action.data === 2) {
                // alert('k')
                return { ...state, 
                    job_status: action.data,
                    show:true,
                    varient:'success',
                    showMsg: action.msg
                };
            } else {
                // alert('kl')
                return { ...state, 
                    job_status: action.data,
                    show:true,
                    varient:'danger',
                    showMsg: action.msg
                };
            }
        default:
            return state;
    }
}
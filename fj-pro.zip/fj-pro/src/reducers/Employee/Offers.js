let init = {    
    offers: [],
    acceptedOffersList : [],
    status: "",
    show:false,
    varient:'',
    showMsg: "",
    offersDetail : [],
    confirm_popup :false,
};
    
export const Offers = (state = init, action) => {
    switch (action.type) {
        case 'SET_OFFERS':
            return {
                ...state, offers: action.data
            }
        case 'VIEW_OFFERS':
            return {...state, offersDetail : action.data}
        case 'SET_ACCEPTED_OFFERS':
            // console.log(action.data, 'action.data')
            return {
                ...state, acceptedOffersList: action.data
            }
        case 'SET_SUCCESS':
            if (action.data === 1) {
                return { ...state, 
                    status: action.data,
                    show:true,
                    varient:'success',
                    showMsg: action.msg
                };
            } else {
                return { ...state, 
                    status: action.data,
                    show:true,
                    varient:'danger',
                    showMsg: action.msg
                };
            }
            case 'SET_SHOW':
                return { ...state, show: action.data };
            case 'SET_CONFIRM_POPUP':
                return { ...state, confirm_popup: action.data };
        
        default:
            return state;
        }
    };
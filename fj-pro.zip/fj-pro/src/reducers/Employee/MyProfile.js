let profile ={
  profile_img:'',
  full_name:'',
  email:'',
  bank_name:'',
  bank_account_number:'',
  epf:'',
  socso:'',
  eis:'',
  mobile_no:'',
  passport_no:'',
  address:'',
  about:"",
  city:'',
  postal_code:'',
  resume:"",
  resume_file:'',
  privacy:"public",
  institution_name:'',
  count : 0,
  year_completed: '',
  qualification_val:'',
  qualifications:[
      {institution_name:'',year_completed:'',qualification:''}
    ],
  language_skill:[
      {language:'',spoken:'',read:'',written:''}
    ],
  skills:[
      {skill_name:'',experience:''}
    ],
  working_experience:[
    {category:'',position:'',company_name:'',start_date:'',end_date:'',responsibilities:'',
  current_company:"no", new_position:0}
],
total_expereience : '',
  varient:'',
    show_alert:false,
    showMsg:'',
    public:false,
    private:"public",
    dummy:0,
    loading:false,
    picLoading:false
};

export const Emp_Profile = (state = profile, action) => {

    switch (action.type) {
        case "EMPLOYEE_PROFILE":
          // console.log(action.data, 'action.data')
            return { ...state, [action.field]: action.data }
        case 'SET_LOADING':
          return {...state, loading:action.data}
          case 'SET_PIC_LOADING':
            return {...state, picLoading:action.data}
        case "SET_COUNT":
            return { ...state, count:action.data }
        case "ADD_NEW_FIELD":
          // console.log(state[action.field], 'state[action.field]')
                return { ...state, [action.field]: [...state[action.field], action.data] }
        default:
            return state;
    }
};
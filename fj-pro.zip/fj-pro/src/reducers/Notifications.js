const init = {
    employeeNotifications: [],
    
};

export const Notifications = (state = init, action) => {

    switch (action.type) {
        case'NOTIFICATIONS':
        
            return {...state, employeeNotifications:action.data}
        case'EMP_NOTIFICATIONS':
        
            return {...state, employeeNotifications:action.data}
        default:
        
            return state;
    }
};
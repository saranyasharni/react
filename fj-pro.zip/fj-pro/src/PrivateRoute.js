import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom';
class PrivateRoute extends Component {
    constructor(props) {
        super(props)
    }
    componentWillMount() {
        // console.log('rest', localStorage.getItem('emp_id'))
    }
    render() {
        const { component: Component, ...rest } = this.props;
        return (

            // Show the component only when the emp is logged in
            // Otherwise, redirect the emp to /signin page
            <Route {...rest} render={props => (
                localStorage.emp_id ?
                    <Component {...props} />
                    : <Redirect to="/login_hire" />
            )} />
        );

    }
}

export default PrivateRoute;
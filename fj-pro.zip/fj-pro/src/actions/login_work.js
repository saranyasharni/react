import config from './Common/Api_Links';
import history from "../stores/history";
import {setLoading} from '../actions/signupWork'
import $ from 'jquery'

export const sendWorkLogin = (key, val) => ({
  type: "SET_WORK_LOGIN",
  key,
  val,
});

export const sendWorkData = (values) => {
    const { username, password } = values;
    return dispatch => {
        dispatch(setLoading(true))
        return fetch(config.loginWork, {
            method: 'post',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "Authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            },
            body: JSON.stringify({
                email: username,
                password
            })
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.message === 'your account is not verified yet, please verify to login') {
                
                $('.signup-btm-p>p').removeClass('d-none')
                $('.signup-btm-p>p').addClass('d-block')
            }
            if (response.status == 1) {
                dispatch(setLoading(false))
                localStorage.setItem('employee_id', response.data.id)
                localStorage.setItem('employee_profile_url', response.data.profile_url)
                localStorage.setItem('employee_name', response.data.name)
                localStorage.setItem('employee_email', response.data.email)
                
                if (response.data.ic_number === "" 
                || response.data.bank_name === null 
                || response.data.bank_name === ""
                || response.data.account_number === ""
                || response.data.account_number === null) {
                    // window.$('#notify-model').modal('show')
                    localStorage.setItem('notify_model', 1)
                } else if (response.data.ic_number === null) {
                    // window.$('#notify-model').modal('show')
                    localStorage.setItem('notify_model', 1)
                } else {
                    localStorage.setItem('notify_model', 0)
                }
                
                // window.location.href = '/employer/dashboard'          
                // history.push('/employee-dashboard')
                window.location.href = '/employee-dashboard'
            } else {
                dispatch(setLoading(false))
                dispatch(sendWorkLogin('show_alert',true))
                dispatch(sendWorkLogin('varient','danger'))
                dispatch(sendWorkLogin('showMsg',response.message))
            }
        })
        .catch((e) => {
            console.log(e)
        })
    }

};

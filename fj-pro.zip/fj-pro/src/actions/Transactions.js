import config from './Common/Api_Links'
// import history from "../stores/history";
export const setLoading = (data) => {
    return {
        type: 'SET_LOADING',
        data
    }
}

export const setTransactions = (data) => ({
    type: 'SET_TRANSACTIONS',
    data
})

export const setCredits = (data) => ({
    type: 'SET_CREDITS',
    data
})

export const TransactionLists = () => {

    let formData = new URLSearchParams();
    formData.append('employer_id', localStorage.getItem('emp_id'));
    // formData.append('employer_id', 42);
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.listTransaction, {
        method: "post",
        headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body: formData,
        })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            dispatch(setTransactions(response.data))
            dispatch(setLoading(false))
            
          } else {
            dispatch(setLoading(false))
          }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
        });
    };
};

export const CreditLists = () => {
    
    let formData = new URLSearchParams();
    formData.append('employer_id', localStorage.getItem('emp_id'));
    // formData.append('employer_id', 42);
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.listCredits, {
        method: "post",
        headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body: formData,
        })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            dispatch(setCredits(response.data))
            dispatch(setLoading(false))
            
          } else {
            dispatch(setLoading(false))
          }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
        });
    };
};
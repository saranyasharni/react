import config from './Common/Api_Links';
import history from '../stores/history'


export const setPassword = (pro, val) => ({
     type: "SET_PASSWORD",
     pro, val
});


export const sendResetPassword = (val) => {
     
     const { token, password } = val;
     return dispatch => {
          return fetch(config.resetPasswordEmployee, {
               method: 'post',
               headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    "Authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
               },
               body: JSON.stringify({
                    token,
                    password
               })
          })
               .then((response) => response.json())
               .then((response) => {
                    if (response.status == 1) {
                         dispatch(setPassword('show_alert',true))
                         dispatch(setPassword('varient','success'))
                         dispatch(setPassword('showMsg',"Password Changed Successfully"))
                         history.push('/login_work')
                         
                    } else {
                         dispatch(setPassword('show_alert',true))
                         dispatch(setPassword('varient','danger'))
                         dispatch(setPassword('showMsg',response.message))
                         
                    }
               })
               .catch((e) => {
                    console.log(e)
               })
     }
};

export const sendEmployerResetPassword = (val) => {
  
     const { token, password } = val;
     return dispatch => {
          return fetch(config.resetPasswordEmployer, {
               method: 'post',
               headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    "Authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
               },
               body: JSON.stringify({
                    token,
                    password
               })
          })
               .then((response) => response.json())
               .then((response) => {
                    if (response.status == 1) {
                         dispatch(setPassword('show_alert',true))
                         dispatch(setPassword('varient','success'))
                         dispatch(setPassword('showMsg',"Password Changed Successfully"))
                         history.push('/login_hire')
                    } else {
                         dispatch(setPassword('show_alert',true))
                         dispatch(setPassword('varient','danger'))
                         dispatch(setPassword('showMsg',response.message))
                    }
               })
               .catch((e) => {
                    console.log(e)
               })
     }
};
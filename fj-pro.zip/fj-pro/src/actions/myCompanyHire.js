import config from './Common/Api_Links'


export const MyCompanyPage =(field,data)=>({
 type: "COMPANY_DATAS",
 field,data
});

export const certificateArray =(data)=>({
  type: "CERTIFICATE",
  data
 });

 export const removeImg =(data)=>({
  type: "IMG_REMOVE",
  data
 });


export const MyComapanyValues = (prof,id) => {
  let employer_id;
    if(prof ==undefined){
       employer_id =localStorage.getItem('emp_id')
    }else{
       employer_id =id
    }
    
    return (dispatch) => {
        return fetch(config.getHireCompanyProfile, {
          method: "post",
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: JSON.stringify({
            employer_id
          }),
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.status == 1) {
              if (response.data.employer_documents &&
                response.data.employer_documents.length > 0
                ) {
                  localStorage.setItem('notify_employer_model', 0)
                } 
                let data =response.data
                dispatch(MyCompanyPage("location",data.location))
                dispatch(MyCompanyPage("company_name",data.company_name))
                if (data.same_as_billing_address === "1") {
                  dispatch(MyCompanyPage("same_as_billing_address",true))
                } else {
                  dispatch(MyCompanyPage("same_as_billing_address",false))
                }
               
                dispatch(MyCompanyPage("about_company",data.about))
                dispatch(MyCompanyPage("no_of_employees",data.no_of_employees))
                dispatch(MyCompanyPage("business_type",data.business_type))
                dispatch(MyCompanyPage("company_no",data.company_reg_id))
                dispatch(MyCompanyPage("landline",data.contact_landline))
                dispatch(MyCompanyPage("mobile",data.contact_mobile))
                dispatch(MyCompanyPage("address",data.mailing_address))
                dispatch(MyCompanyPage("addressLine1",data.mailing_address_2))
                dispatch(MyCompanyPage("address_city",data.mailing_address_city))
                dispatch(MyCompanyPage("address_pincode",data.mailing_address_state))
                dispatch(MyCompanyPage("billing_adderess",data.billing_address))
                dispatch(MyCompanyPage("billing_adderess_line1",data.billing_address_2))
                dispatch(MyCompanyPage("billing_adderess_city",data.billing_address_city))
                dispatch(MyCompanyPage("billing_adderess_pincode",data.billing_address_state))
                dispatch(MyCompanyPage("code",data.contact_mobile_cc))
                dispatch(MyCompanyPage("profile_pic",data.profile_url))
                
                dispatch(MyCompanyPage("certificate",data.employer_documents))
                // console.log(data.profile_url, 'data.profile_url')
                localStorage.setItem('profile_url', data.profile_url)
                if (data.employer_documents && data.employer_documents.length === 0) {
                  setTimeout(function(){
                    if(document.getElementById('testScroll') !== null) {
                      document.getElementById('testScroll').scrollIntoView({
                        behavior: "smooth"
                      });
                    }
                 
                  }, 1000)
                  // $('#testScroll')[0].focus()
                }
            } else {
              // alert(response.message);
            }
          })
          .catch((e) => {
            console.log(e);
          });
      };
    };



    export const EditComapanyValues = (input) => {
        
        return (dispatch) => {
            return fetch(config.editHireCompanyProfile, {
              method: "post",
              headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
              },
              body: JSON.stringify(
                input
              ),
            })
              .then((response) => response.json())
              .then((response) => {
                if (response.status == 1) {
                  if (response.data.employer_documents &&
                    response.data.employer_documents.length > 0
                    ) {
                      localStorage.setItem('notify_employer_model', 0)
                    }
                    dispatch(MyCompanyPage('show_alert',true))
                    dispatch(MyCompanyPage('varient','success'))
                    dispatch(MyCompanyPage('showMsg',"Profile details edited successfully"))
                } else {
                    dispatch(MyCompanyPage('show_alert',true))
                    dispatch(MyCompanyPage('varient','danger'))
                    dispatch(MyCompanyPage('showMsg',response.message))
                }
              })
              .catch((e) => {
                console.log(e);
              });
          };
        };


        export const UploadComapanyProfile = (type,file) => {
          
          const formData = new FormData();
          formData.append('upload_file', file);
          if(type=="prof"){
            formData.append('upload_type','profile');
          }else{
            formData.append('upload_type','file');
          }
          return (dispatch) => {
              return fetch(config.uploadProfilePic, {
                method: "post",
                headers: {
                  
                  Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                },
                body: formData,
              })
                .then((response) => response.json())
                .then((response) => {
                  if (response.status == 1) {
                    if(type=="prof"){
                      dispatch(MyCompanyPage('profile_pic',response.file_links_data[0].original_data))
                    }else{
                      dispatch(certificateArray({url:response.file_links_data[0].original_data}))
                    }
                      
                  } else {
                      dispatch(MyCompanyPage('show_alert',true))
                      dispatch(MyCompanyPage('varient','danger'))
                      dispatch(MyCompanyPage('showMsg',response.message))
                  }
                })
                .catch((e) => {
                  console.log(e);
                });
            };
          };
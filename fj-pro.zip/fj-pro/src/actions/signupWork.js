import config from './Common/Api_Links'
import history from "../stores/history";

export const panelBackgroundInfo = (data) => ({
    type: 'PANEL_INFO',
    data,
});

export const resetForm = (data) => ({
    type: 'RESET_FORM',
    data
});

export const AddMoreField = (field, data) => ({

    type: "ADD_MORE_FIELD",
    field, 
    data
});
export const inputChange =  (field, value) => {
    return {
        type: 'INPUT_CHANGE',
        field, value
    }
};

export const updateErrors = (data) => {
    return {
        type: 'UPDATE_ERRORS',
        data
    }
};

export const addAllLangSkills = (data) => {
    return {
        type: 'All_LANG_SKILLS',
        data
    }
}
export const setShow = (data) => {
    return {
        type: 'SET_SHOW',
        data
    }
}
export const setLoading = (data) => {
    return {
        type: 'SET_LOADING',
        data
    }
}

export const signupEmployeeStatus = (data, message) => {
    return {
        type: 'SIGNUP_EMP_STATUS',
        data,
        message
    }
}

export const emailExists = (data) => {

    return {
        type: 'EMAIL_EXISTS',
        data
    }

}


export const checkEmailExistance = (data) => {
    console.log(data, "check email runs .................");
    let formData = new URLSearchParams();    //formdata object
    formData.append("email", data.email);

    return dispatch => {
        // dispatch(setLoading(true))
        return fetch(config.checkEmailExistance, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
                        }
                    })
            .then(response => {
                if (response) {
                    return response.json();
                }
            })
            .then(responseData => {
                
                if (responseData.status === 1) {
           
                    dispatch(emailExists(false))
                  
                } else if(responseData.status === 0) {
                    
                    dispatch(emailExists(true))
                }
            })
    }
}


export const signUpWorkRegister = (data) => {
    
    let skills = JSON.stringify(data.language_skills)
    let converted_skill_details = JSON.stringify(data.skill_details)
    let converted_experience = JSON.stringify(data.work_experience)
    if (data.country_code == '') {
        data.country_code = '60'
    }
    let formData = new URLSearchParams();    //formdata object
    formData.append("name",data.empName)
    formData.append("dob",data.dob)
    formData.append("is_vaccinated",data.is_vaccinated)
    formData.append("gender",data.gender)
    formData.append("country_code",data.country_code)
    formData.append("mobile",data.phone_number)
    formData.append("email",data.Email)
    formData.append("address",data.Address)
    formData.append("city",data.city)
    formData.append("postal_code",data.postal_code)
    formData.append("resume_desc",data.main_roles)
    formData.append("resume_file",data.resume_file)
    formData.append("resume_setting",data.resume_privacy_setting)
    formData.append("institution_name",data.instution_name)
    formData.append("education",data.qualification)
    formData.append("qualification",data.qualification === "others"? data.qualification_ot: data.qualification)
    formData.append("year_completed",data.completion_year)
    formData.append("password",data.password)
    formData.append('language_skill', skills);   //append the values with key, value pair
    formData.append('skill',converted_skill_details);
    formData.append('work_experience',converted_experience)
    formData.append('ic_number',data.ic_number)
    formData.append('epf',data.epf)
    formData.append('socso',data.socso)
    formData.append('bank_name',data.bank_name)
    formData.append('account_number',data.account_number)
    formData.append('disability',data.disability)
    formData.append('disability_description',data.disability_description)
    formData.append('lat',10.9974)
    formData.append('lon',76.9589)
    formData.append('experience',data.total_experience)
    return dispatch => {
        dispatch(setLoading(true))
        return fetch(config.signUpForEmployee, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
            .then(response => {
                if (response) {
                    return response.json();
                }
            })
            .then(responseData => {
                
                if (responseData.status === 1) {
                    
                    localStorage.setItem('work_employee_id', responseData.data.employee_id)
                    localStorage.setItem('work_emp_email_id', responseData.data.email) 
                    localStorage.setItem('user', 'employee')
                    
                    dispatch(resetForm({
                        errors : {},
                        empName: '',
                        dob:'',
                        gender:'',
                        country_code:'',
                        phone_number: '',
                        Email: '',
                        Address:'',
                        city:'',
                        postal_code:'',
                        main_roles:'',
                        resume_file:'',
                        resume_privacy_setting:'',
                        instution_name:'',
                        qualification:'',
                        completion_year:'',
                        language_skills:[],
                        language:'',
                        password:'',
                        confirm_password:'',
                        spoken:'',
                        read:'',
                        written:'',
                        employee_register_status: 2,
                        show:false,
                        varient:'',
                        showMsg:''
                    }))
                    history.push('/verify')
                    dispatch(setLoading(false))
                } else if (responseData.status === -1) {
                    dispatch(signupEmployeeStatus(-1, responseData.message))
                    dispatch(setLoading(false))
                } else {
                    dispatch(signupEmployeeStatus(3, 'Something went wrong, Please try again'))
                    dispatch(setLoading(false))
                }
            })


    };
};

export const signUpHireRegister = (data) => {
    // console.log(data, 'bodydata')
    
    let formData = new URLSearchParams();
    let converData = JSON.stringify([data.url])
    formData.append("user_name",data.user_name)
    formData.append("email",data.email)
    formData.append("mobile",data.phone_number)
    formData.append("landline",data.landline_number)
    formData.append("same_as_billing_address",data.same_as_billing_address)
    formData.append("company_name",data.company_name)
    formData.append("company_reg_id",data.company_registration_number)
    formData.append("mailing_address",data.mailing_address)
    formData.append("billing_address",data.billing_address)
    
    formData.append("mailing_address_2", data.mailing_address_2)
    formData.append("mailing_address_city", data.mailing_address_city)
    formData.append("mailing_address_state", data.mailing_address_state)
    formData.append("mailing_country", data.mailing_country)

    formData.append("billing_address_2", data.billing_address_2)
    formData.append("billing_address_city", data.billing_address_city)
    formData.append("billing_address_state", data.billing_address_state)
    formData.append("billing_country", data.billing_country)

    formData.append("contact_landline",data.landline_number)
    formData.append("contact_mobile",data.phone_number)
    formData.append("password",data.password)
    formData.append("documents",converData)
    formData.append("account_type",1)
    
    return dispatch => {
        dispatch(setLoading(true))
    return fetch(config.signForUpEmployer, {
        method: 'POST',
        body: formData,
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
        }
    })
        .then(response => {
            if (response) {
                return response.json();
            }
        })
        .then(responseData => {

            if (responseData.status === 1) {
                localStorage.setItem('hire_emp_id', responseData.data.employer_id)
                localStorage.setItem('hire_email_id', responseData.data.email) 
                localStorage.setItem('account_type_paid', responseData.data.account_type) 
                localStorage.setItem('user', 'employer') 
                dispatch(resetForm({
                    errors : {},
                    country_code:'',
                    phone_number: '',
                    Email: '',
                    landline_number: '',
                    user_name: '',
                    company_name: '',
                    company_registration_number: '',
                    billing_checkbox:'',
                    mailing_address: '',
                    billing_address: '',
                    company_landline_number: '',
                    company_mobile_number: '',
                    company_number_country_code: '',
                    employee_register_status: 2,
                    show:false,
                    password:'',
                    confirm_password:'',
                    varient:'',
                    showMsg:'',
                    password:'',
                    confirm_password:'',
                }))
                history.push('/verify')
                dispatch(setLoading(false))
            } else if (responseData.status === -1) {
                dispatch(signupEmployeeStatus(-1, responseData.message))
                dispatch(setLoading(false))
            } else if (responseData.status === 0) {
                dispatch(signupEmployeeStatus(-1, responseData.message))
                dispatch(setLoading(false))
            }else {
                dispatch(signupEmployeeStatus(3, 'Something went wrong, Please try again'))
                dispatch(setLoading(false))
            }
        })
};

};  

export const UploadEmployeeProfile = (file) => {
    console.log('img', file)
    let formData = new FormData();
    formData.append('upload_file', file);
    return (dispatch) => {
        dispatch(setLoading(true))
      return fetch(config.uploadProfilePic, {
        method: "post",
        headers: {
  
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body: formData,
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            dispatch(setLoading(false))
            dispatch(resetForm({
                resume_file : response.file_links_data[0].original_data,
                file_name: file.name
            }))
            
            // if (type == "profile_img") {
            //   dispatch(Profile('profile_img', response.file_links_data[0].original_data))
            // } else {
            //   dispatch(Profile('resume_file', response.file_links_data[0].original_data))
            // }
  
          } else {
            dispatch(setLoading(false))
          }
        })
        .catch((e) => {
            dispatch(setLoading(false))
          console.log(e);
        });
    };
  };

    export const uploadEmployerDocument = (file) => {
    
    let formData = new FormData();
    formData.append('upload_file', file);
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.uploadProfilePic, {
        method: "post",
        headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body: formData,
        })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            dispatch(setLoading(false))
            dispatch(resetForm({
                proof_document : {'url':response.file_links_data[0].original_data},
                file_name: file.name
            }))
          } else {
            dispatch(setLoading(false))
          }
        })
        .catch((e) => {
            dispatch(setLoading(false))
          console.log(e);
        });
    };
  };

  export const addPositions = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append('industry_type_id', data.cat_id);
    formData.append('position', data.position);
    return dispatch => {
        
        return fetch(config.add_position, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                
            } else {
                
            }
        })
    };
}

export const addIndustries = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append('industry_type', data.cat_id);
    return dispatch => {
        return fetch(config.add_industries, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                
            } else {
                
            }
        })
    };
}

export const addSkills = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append('skill', data.skill);
    return dispatch => {
        
        return fetch(config.add_skill, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                
            } else {
                
            }
        })
    };
}

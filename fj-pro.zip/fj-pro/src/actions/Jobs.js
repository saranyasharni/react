import config from './Common/Api_Links';
import history from "../stores/history";
import {getPositions} from "../actions/Home"
import {addPositions,addIndustries} from "./signupWork";
import moment from "moment"

export const panelBackgroundInfo = (data) => ({
    type: 'PANEL_INFO',
    data,
});
export const setDraftLoading = (data) => ({
    type: 'DRAFT_LOADING',
    data,
})
export const setSalaryContribution = data => ({
    type : 'SET_SALARY_CONTRIBUTION',
    data: data
})
export const updateInput = (field, value) => ({
    type: 'CHANGE_INPUT',
    field,
    value
});

export const setLoading = data => ({
    type:"SET_LOADING",
    data
});

export const setSuccess = (data, msg) => ({
    type:'SET_SUCCESS',
    data,
    msg
});
export const setEditJobResults = (data) => ({
    type: 'EDIT_JOB',
    data:data
})
export const setSchedule = (data) => ({
    type: 'SET_SCHEDULE',
    data
})
export const resetForm = (data) => ({
    type: 'RESET_FORM',
    data
})
export const updateErrors = (data) => {
    return {
        type: 'UPDATE_ERRORS',
        data
    }
};

export const setShow = (data) => {
    return {
        type: 'SET_SHOW',
        data
    }
}

export const getJobs = (data) => {
    
    return dispatch => {
        return fetch(config.industries+data, {
            method: 'GET',
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })

            .then(responseData => {
                // console.log(responseData, 'responseData90')
                if (responseData) {

                    dispatch(panelBackgroundInfo(responseData.result))
                    
                } else {
                    dispatch(panelBackgroundInfo([]))
                    
                }
            })
    };
};

export const createJob = (data) =>  {
    console.log(data, 'data')
    let emp_id = localStorage.emp_id ?  localStorage.getItem('emp_id') :''
    let convert_other_reqs = JSON.stringify(data.other_reqs);
    let convert_shifts = JSON.stringify(data.shifts);
    let converted_salary = JSON.stringify(data.salary_detail);
    let convert_locations = JSON.stringify(data.location);
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",emp_id)
    formData.append("industry_type",data.industry)    
    formData.append("industry_type_id",data.industry_type_id)  
    formData.append("job_position",data.jobPosition)
    formData.append("save_as_draft",data.save_as_draft)        
    formData.append("job_vacancy",data.vacancy)
    formData.append("lat",data.lat)
    formData.append("lon",data.lon)
    formData.append("job_title",data.jobTitle)
    formData.append("job_description",data.jobDesc)
    formData.append("job_type",data.jobType)
    formData.append("salary_based",data.salaryBased)
    formData.append("currency",data.currency)
    formData.append("amount",data.amount)
    formData.append("gender",data.gender)
    formData.append("other_reqs",convert_other_reqs)
    formData.append("start_date",data.scheduleStartDate)
    formData.append("start_time", data.scheduleStartTime)
    formData.append("end_date", data.scheduleEndDate)
    formData.append("end_time", data.scheduleEndTime)
    formData.append("shifts", convert_shifts)
    formData.append("location", convert_locations)
    formData.append("salary_detail", converted_salary)
    formData.append("number_of_hours", data.number_of_hours)
    formData.append("number_of_days", data.number_of_days)
    formData.append("epf","5")
    formData.append("socso","11")
    formData.append("fj_fee","5")
    formData.append("total_salary","50")
    formData.append("status_code","1")

    return dispatch => {
        if (data.save_as_draft === 1) {
            // alert()
            dispatch(setDraftLoading(true))
        } else {
            dispatch(setLoading(true))
        }
        return fetch(config.createJobs, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
                return response.json();
        })
        .then(responseData => {
            // console.log(responseData, 'responseData90')
            if (responseData) {
                // dispatch(setSuccess(1, 'Job Created Successfully'))
                dispatch(resetForm({
                    industry:'',
                    industry_new:'',
                    jobPosition:'',
                    vacancy:'',
                    jobTitle:'',
                    jobDesc:'',
                    marker:{},
                    jobType:'',
                    salaryBased:'',
                    currency:'',
                    amount:'',
                    gender:'',
                    requirements_work_experience:'',
                    requirements_language:'',
                    requirements_age_limit:'',
                    scheduleStartDate:'',
                    scheduleStartTime:'',
                    scheduleEndDate:'',
                    scheduleEndTime:'',
                    shiftBreakStart:'',
                    shiftBreakEnd:'',
                    location:'',
                    errors:{},  
                }))

                if (data.show_position) {
                    dispatch(addPositions({
                        position:data.jobPosition,
                        cat_id:data.industry_type_id,
                    }))
                } 
                    
                if (data.save_as_draft === 1) {
                    dispatch(setDraftLoading(false))
                    history.push('/employer_posted_job_list/drafted')                 
                } else {
                    dispatch(setLoading(false))
                    history.push('/employer_posted_job_list/active')                 
                }
            } else {
                
                if (data.save_as_draft === 1) {
                    dispatch(setDraftLoading(false))
                } else {
                    dispatch(setLoading(false))
                }
                dispatch(setSuccess(-1, responseData.message))
            }
        })
        .catch((err) => {
            dispatch(setLoading(false))
            console.log(err);
        });
    };
};

export const getJobById = (val, days_arr) => {
    let data = {
        'job_id':val
    }
    let sendData = JSON.stringify(data)
    // console.log(sendData, 'sendData')
    return dispatch => {
        return fetch(config.getJobById, {
            method: 'post',
            body: sendData,
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "Authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            },
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                let lang_skill = '';
                let work_exp = '';
                let age_limit = '';
                dispatch(getPositions(response.data[0].industry_type_id))
                // if (response.data[0].job_requirements.length > 0 &&
                //     response.data[0].job_requirements[0].requirement === "1"
                //     ) {
                       
                //         work_exp = true
                // } else {
                //     work_exp = false
                // }
                // if (response.data[0].job_requirements.length > 0 &&
                //     response.data[0].job_requirements[1].requirement === "1"
                //     ) {
                //         lang_skill = true
                // } else {
                //     lang_skill = false
                // }
                // if (response.data[0].job_requirements.length > 0 &&
                //     response.data[0].job_requirements[2].requirement === "1"
                //     ) {
                //         age_limit = true
                // } else {
                //     age_limit = false
                // }
                
                // if (response.data[0] && response.data[0].salary_based === 'per-month') { 
                //     response.data[0].salary_based = 'Month'
                // } else if (response.data[0] && response.data[0].salary_based === 'per-week') {
                //     response.data[0].salary_based = 'Week'
                // } else if (response.data[0] && response.data[0].salary_based === 'per-day') {
                //     response.data[0].salary_based = 'Per Day'
                // } else {
                    response.data[0].salary_based = 'Per Hour'
                // }
                let show_start_date = ""
                let show_end_date = ""

                if (window.location.pathname.split('/')[1] === 'similar') {
                    show_start_date = ""
                    show_end_date = ""
                } else  {
                    show_start_date = 
                    response.data[0].start_date !== 'Invalid date' &&
                    response.data[0].start_date !== null &&
                    response.data[0].start_date !== '' ?
                    new Date(response.data[0].start_date): 
                    ''
                    show_end_date = 
                    response.data[0].end_date !== 'Invalid date' &&
                    response.data[0].end_date !== null &&
                    response.data[0].end_date !== 'null' &&
                    response.data[0].end_date !== '' ?
                    new Date(response.data[0].end_date) : 
                    ''
                } 
                var editJob = {
                    industry:response.data[0].industry_type,
                    industry_new:response.data[0].industry_type_id,
                    jobPosition:response.data[0].job_position,
                    vacancy:response.data[0].job_vacancy,
                    jobTitle:response.data[0].job_title,
                    jobDesc:response.data[0].job_description,
                    jobType:response.data[0].job_type,
                    salaryBased:response.data[0].salary_based,
                    currency:response.data[0].currency,
                    amount:response.data[0].amount,
                    showAmount:response.data[0].amount,
                    gender:response.data[0].gender,
                    requirements_work_experience:
                    response.data[0].job_requirements.length > 0 &&
                    response.data[0].job_requirements[0].requirement,
                    marker:{
                        lat:response.data[0].lattitude,
                        lon:response.data[0].longitude
                    },
                    requirements_language:lang_skill,
                    requirements_age_limit:age_limit,
                    scheduleStartDate:show_start_date,
                    scheduleEndDate:show_end_date,
                    scheduleStartTime:
                    response.data[0].start_time !== null &&
                    response.data[0].start_time !== '' &&
                    response.data[0].start_time !== undefined &&
                    response.data[0].start_time !== 'Invalid date'
                    ?new Date(`Aug 28, 2008 ${response.data[0].start_time}:00`):
                    '',
                    
                    scheduleEndTime:
                    response.data[0].end_time !== 'Invalid date' &&
                    response.data[0].end_time !== null &&
                    response.data[0].end_time !== ''
                    ? new Date(`Aug 28, 2008 ${response.data[0].end_time}:00`):
                    '',
                    // shifts:response.data[0].job_shifts,
                    shiftBreakStart:response.data[0].job_shifts[0].start_time,
                    shiftBreakEnd:response.data[0].job_shifts[0].end_time,
                    location:response.data[0].job_location,
                    number_of_days:response.data[0].number_of_days,
                    number_of_hours:response.data[0].number_of_hours,
                    aboveSixtySalary:response.data[0].job_salaries[0],
                    belowSixtySalary:response.data[0].job_salaries[1]
                }
                console.log(editJob.scheduleStartTime, 'editArticleDetails')
                var start_date = new Date(response.data[0].start_date);
                var end_date = new Date(response.data[0].end_date);
                var day = 1000*60*60*24;
                var diff = (end_date.getTime()- start_date.getTime())/day;
                var dateArr = []
                for (var i=0; i<=diff; i++) {
                    var xx = start_date.getTime()+day*i;
                    var date_day = new Date(xx).toLocaleString('en-us', {weekday:'short'})
                    dateArr.push(date_day);
                }
                var newDayArray = []
                days_arr.map(o => {
                    if (dateArr.includes(o.day_name) === true) {
                        newDayArray.push({
                            class:'',
                            day_name:o.day_name
                        })
                    } else {
                        newDayArray.push({
                            class:'in-active',
                            day_name:o.day_name
                        })
                    }
                    
                })
                
                dispatch(setEditJobResults(editJob))
                dispatch(setSchedule(newDayArray))
            } else {
                alert(response.message)
            }
        })
        .catch((e) => {
            console.log(e)
        })
    }
};
export const editJob = (data) => {
    let convert_other_reqs = JSON.stringify(data.other_reqs)
    let convert_shifts = JSON.stringify(data.shifts)
    let convert_locations = JSON.stringify(data.location)
    let converted_salary = JSON.stringify(data.salary_detail);
    let formData = new URLSearchParams();    //formdata object
    // formData.append("employer_id",1)
    formData.append("job_id",data.jobId)
    formData.append("industry_type",data.industry)    
    formData.append("industry_type_id",data.industry_type_id)    
    formData.append("save_as_draft",data.save_as_draft)    
    formData.append("job_position",data.jobPosition)    
    formData.append("job_vacancy",data.vacancy)
    formData.append("job_title",data.jobTitle)
    formData.append("job_description",data.jobDesc)
    formData.append("job_type",data.jobType)
    formData.append("lat",data.lat)
    formData.append("lon",data.lon)
    formData.append("salary_based",data.salaryBased)
    formData.append("currency",data.currency)
    formData.append("amount",data.amount)
    formData.append("gender",data.gender)
    formData.append("salary_detail", converted_salary)
    formData.append("number_of_hours", data.number_of_hours)
    formData.append("number_of_days", data.number_of_days)
    formData.append("other_reqs",convert_other_reqs)
    formData.append("start_date",data.scheduleStartDate)
    formData.append("start_time",data.scheduleStartTime)
    formData.append("end_date",data.scheduleEndDate)
    formData.append("end_time",data.scheduleEndTime)
    formData.append("shifts",convert_shifts)
    formData.append("epf","5")
    formData.append("socso","11")
    formData.append("fj_fee","5")
    formData.append("total_salary","50")
    formData.append("status_code","1")
    formData.append("location",convert_locations)

    return dispatch => {
        if (data.save_as_draft === 1) {
            // alert()
            dispatch(setDraftLoading(true))
        } else {
            dispatch(setLoading(true))
        }
        return fetch(config.editJob, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
                return response.json();
        })
        .then(responseData => {
            // console.log(responseData, 'responseData90')
            if (responseData) {
                // dispatch(setSuccess(1, 'Job Edited Successfully'))
                dispatch(resetForm({
                    industry:'',
                    industry_new:'',
                    jobPosition:'',
                    vacancy:'',
                    jobTitle:'',
                    jobDesc:'',
                    jobType:'',
                    salaryBased:'',
                    currency:'',
                    amount:'',
                    gender:'',
                    requirements_work_experience:'',
                    requirements_language:'',
                    requirements_age_limit:'',
                    scheduleStartDate:'',
                    scheduleStartTime:'',
                    scheduleEndDate:'',
                    scheduleEndTime:'',
                    shiftBreakStart:'',
                    shiftBreakEnd:'',
                    location:'',
                    marker:{},
                    errors:{},  
                }))
                history.push('/employer_posted_job_list/active') 
            } else {
                dispatch(setSuccess(-1, responseData.message))
            }
          if (data.save_as_draft === 1) {
            // alert()
            dispatch(setDraftLoading(false))
        } else {
            dispatch(setLoading(false))
        }
        })
        .catch((err) => {
          if (data.save_as_draft === 1) {
            // alert()
            dispatch(setDraftLoading(false))
        } else {
            dispatch(setLoading(false))
        }
            console.log(err);
        });
    };
};  
export const salaryContribution = () => {
    let formData = new URLSearchParams ();    //formdata object
    
    formData.append("employer_id", localStorage.getItem('emp_id'))    
    // formData.append("employer_id", 34)    
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.salary_contribution, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {    
            if (response.status === 1) { 
                dispatch(setSalaryContribution(response.data))   
            } else {
                dispatch(setSalaryContribution([]))   
            }
        })
        .catch((e) => {
            
            console.log(e);
        });
    };
};

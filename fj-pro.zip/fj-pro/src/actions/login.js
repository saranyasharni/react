import {setLoading} from '../actions/signupWork'
import config from "./Common/Api_Links";
import history from "../stores/history";
import $ from 'jquery'
export const sendLogin = (key, val) => ({
  type: "SET_HIRE_LOGIN",
  key,
  val,
});

export const sendData = (values) => {
  const { username, password } = values;
  return (dispatch) => {
    dispatch(setLoading(true))
    return fetch(config.loginHire, {
      method: "post",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
      },
      body: JSON.stringify({
        email: username,
        password,
      }),
      })
      .then((response) => response.json())
      .then((response) => {
        if (response.message === 'your account is not verified yet, please verify to login') 
        {
          
          $('.signup-btm-p>p').removeClass('d-none')
          $('.signup-btm-p>p').addClass('d-block')
        }
        if (response.status == 1) {
          
          console.log(response, 'response')
          localStorage.setItem('emp_id', response.result.id)
          localStorage.setItem('profile_url', response.result.profile_url)
          localStorage.setItem('user_name', response.result.user_name)
          localStorage.setItem('email', response.result.email)
          localStorage.setItem('account_type_paid', response.result.account_type)
          dispatch(setLoading(false))
          // window.location.href = "/employer/dashboard";
          if (response.result.document_url === null) {
            // window.$('#notify-employer-model').modal('show')
            localStorage.setItem('notify_employer_model', 1)
          } else if (response.result.document_url === "") {
            // window.$('#notify-employer-model').modal('show')
            localStorage.setItem('notify_employer_model', 1)
          } else if (response.result.document_url === 'null') {
            // window.$('#notify-employer-model').modal('show')
            localStorage.setItem('notify_employer_model', 1)
          } else {
            localStorage.setItem('notify_employer_model', 0)
          }
          sessionStorage.setItem('Emp_address', response.result.mailing_address)
          window.location.href = '/employer/dashboard'          
          // window.location.('/employer/dashboard')
        } else {
          dispatch(setLoading(false))
          dispatch(sendLogin('show_alert',true))
          dispatch(sendLogin('varient','danger'))
          dispatch(sendLogin('showMsg',response.message))
        }
      })
      .catch((e) => {
        console.log(e);
      });
  };
};

import { data } from 'jquery';
import config from './Common/Api_Links';

export const Dasboard =(field,data) =>({
    type:"DASBOARD",
    field,data
});

export const setNotifications = (data) => ({
    type:"NOTIFICATIONS",
    data
})

export const setEmployerNotifications = (data) => ({
  type:"EMP_NOTIFICATIONS",
  data
})

export const getNotification = (data) => {
    
    let formData = new URLSearchParams();

    formData.append('employee_id',data.employee_id);
    return (dispatch) => {
        return fetch(config.employeeNotifications, {
            method: "post",
            headers: {
    
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: formData,
        })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
        
            dispatch(setNotifications(response.data))
  
          } else {
            dispatch(setNotifications([]))
          }
        })
        .catch((e) => {
            
          console.log(e);
        });
    };
};


export const getEmployerNotification = (data) => {
    
  let formData = new URLSearchParams();

  formData.append('employer_id',data.employer_id);
  return (dispatch) => {
      return fetch(config.employerNotifications, {
          method: "post",
          headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: formData,
      })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
      
          dispatch(setEmployerNotifications(response.data))

        } else {
          dispatch(setEmployerNotifications([]))
        }
      })
      .catch((e) => {
          
        console.log(e);
      });
  };
};


export const readNotification = (data) => {
    
  let formData = new URLSearchParams();

  formData.append('employer_id',data.employer_id);
  formData.append('notification_id',data.notification_id);
  return (dispatch) => {
      return fetch(config.read_notification, {
          method: "post",
          headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: formData,
      })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
          dispatch(getEmployerNotification({
            employer_id:localStorage.getItem('emp_id')
          }))
          // dispatch(setEmployerNotifications(response.data))

        } else {
          // dispatch(setEmployerNotifications([]))
        }
      })
      .catch((e) => {
          
        console.log(e);
      });
  };
};

export const readEmployeeNotification = (data) => {
    
  let formData = new URLSearchParams();

  formData.append('employee_id',data.employee_id);
  formData.append('notification_id',data.notification_id);
  return (dispatch) => {
      return fetch(config.read_employee_notifications, {
          method: "post",
          headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: formData,
      })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
          dispatch(getNotification({
            employee_id:localStorage.getItem('employee_id')
          }))
          // dispatch(setEmployerNotifications(response.data))

        } else {
          // dispatch(setEmployerNotifications([]))
        }
      })
      .catch((e) => {
          
        console.log(e);
      });
  };
};

export const viewEmployerNotification = (data) => {
    
  let formData = new URLSearchParams();

  formData.append('employer_id',localStorage.getItem('emp_id'));
  
  return (dispatch) => {
      return fetch(config.view_employer_notifications, {
          method: "post",
          headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: formData,
      })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
          dispatch(getEmployerNotification({
            employer_id:localStorage.getItem('emp_id')
          }))
          // dispatch(setEmployerNotifications(response.data))

        } else {
          // dispatch(setEmployerNotifications([]))
        }
      })
      .catch((e) => {
          
        console.log(e);
      });
  };
};

export const viewEmployeeNotification = (data) => {
    
  let formData = new URLSearchParams();

  formData.append('employee_id',localStorage.getItem('employee_id'));
  
  return (dispatch) => {
      return fetch(config.view_employee_notifications, {
          method: "post",
          headers: {
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: formData,
      })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
          dispatch(getNotification({
            employee_id:localStorage.getItem('employee_id')
          }))
          // dispatch(setEmployerNotifications(response.data))

        } else {
          // dispatch(setEmployerNotifications([]))
        }
      })
      .catch((e) => {
          
        console.log(e);
      });
  };
};



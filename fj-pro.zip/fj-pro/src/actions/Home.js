import { setLanguage } from 'react-geocode';
import config from './Common/Api_Links'

export const setJobs = (data) => ({
    type: 'SET_JOBS',
    data,
});

export const setSkills = (data) => ({
    type: 'SET_SKILLS',
    data,
})

export const setLanguages = (data) => ({
    type: 'SET_LANGUAGES',
    data,
})

export const setQualifications = (data) => ({
    type: 'SET_QUALIFICATIONS',
    data,
})

export const setBanks = (data) => ({
    type: 'SET_BANKS',
    data
})

export const setDashboard = (data) => ({
    type: 'SET_DASHBOARD',
    data,
});

export const setTestimonals = (data) => ({
    type: 'SET_TESTMONALS',
    data,
});

export const setFieldValues = (field,data) => ({
    type: 'UPDATE_FIELDS',
    field,data,
});
export const getPassoutYear = () => ({
    type : 'PASSED_YEARS'
})
export const setIndustries = (data) =>  ({
    type : "SET_INDUSTRIES",
    data
})

export const setpositions = (data) =>  ({
    type : "SET_POSITIONS",
    data
})

export const getIndustries = () => {
    return dispatch => {
        
        return fetch(config.getIndustries, {
            method: 'POST',
            headers: {
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                dispatch(setIndustries(responseData.data))
            } else {
                dispatch(setIndustries([]))
            }
        }).catch((err) => {
            console.log(err)
        })
    };
}

export const getselectedIndustries = () => {
    let formData = new URLSearchParams ();    //formdata object
    
    formData.append("employer_id", localStorage.getItem('emp_id'))    
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.list_selected_industries, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                dispatch(setIndustries(responseData.data))
            if (window.location.pathname.split('/')[2] === 'shortlisted' 
            ) {
                
                // console.log(window.location.pathname.split('/')[3],
                // window.location.pathname.split('/')[4], 'window.location.pathname.split('/')[3]')
                if (window.location.pathname.split('/').length > 4) {
                    console.log(window.location.pathname.split('/'), 'jkgjhffghfgh')
                    let cat_id = window.location.pathname.split('/')[3];
                    let pos_id = window.location.pathname.split('/')[4]
                    window.$('#hiredser_select_industry').selectpicker('val', cat_id);
                    window.$('#hiredser_select_industry').selectpicker('refresh');
                }
            
            }
        
            } else {
                dispatch(setIndustries([]))
            }
        }).catch((err) => {
            console.log(err)
        })
    };
};


export const getPositions = (industry_type_id) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append('industry_type_id', industry_type_id);
    return dispatch => {
        
        return fetch(config.getPositions, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                dispatch(setpositions(responseData.data))
            } else {
                dispatch(setpositions([]))
            }
        })
    };
}

export const getSkills = () => {
    // let formData = new URLSearchParams();    //formdata object
    return dispatch => {
        
        return fetch(config.skills, {
            method: 'POST',
            // body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                dispatch(setSkills(responseData.data))
            } else {
                dispatch(setSkills([]))
            }
        })
    };
}

export const getBankS = () => {
    // let formData = new URLSearchParams();    //formdata object
    return dispatch => {
        
        return fetch(config.listBanks, {
            method: 'POST',
            // body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then(responseData => {
            if (responseData) {
                dispatch(setBanks(responseData.data))
            } else {
                dispatch(setBanks([]))
            }
        })
    };
}

export const getHome = () => {
    // let formData = new URLSearchParams();    //formdata object
    
    // formData.append('user_id', user_id);
    return dispatch => {
        dispatch(setDashboard([]))
        return fetch(config.HomePage, {
            method: 'GET',
            // body: formData,
            // headers: {
            //     // "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            //     "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            // }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
             
                if (responseData) {

                    dispatch(setJobs(responseData.result))
                    dispatch(setDashboard(responseData.result[0].dashboard))
                    dispatch(setTestimonals(responseData.result[0].testimonials))
                } else {
                    dispatch(setJobs([]))
                    dispatch(setDashboard([]))
                    dispatch(setTestimonals([]))
                }
            })


    };
};

export const getQualifications = () => {
    // let formData = new URLSearchParams();    //formdata object
    // formData.append('user_id', user_id);
    return dispatch => {
        dispatch(setDashboard([]))
        return fetch(config.listQualifications, {
            method: 'POST',
            // body: formData,
            headers: {
                // "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
             
                if (responseData) {

                    dispatch(setQualifications(responseData.data))
                    
                } else {
                    dispatch(setQualifications([]))
                    
                }
            })


    };
};

export const getLanguages = () => {
    // let formData = new URLSearchParams();    //formdata object
    
    // formData.append('user_id', user_id);
    return dispatch => {
        dispatch(setDashboard([]))
        return fetch(config.listLanguages, {
            method: 'POST',
            // body: formData,
            headers: {
                // "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
             
                if (responseData) {

                    dispatch(setLanguages(responseData.data))
                    
                } else {
                    dispatch(setLanguages([]))
                    
                }
            })


    };
};


  


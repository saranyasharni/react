import config from './Common/Api_Links'
import moment from "moment"
import {setLoading} from './Employer/Workers'

export const PostedJob = (field,data) =>({
 type: "POSTED_JOBS",
 field,data
});

export const sortJobs = (data, activeData) => ({
  type: "SORT_JOBS",
  data,
  activeData
});

export const postedJobList = (input) => {
 
    return (dispatch) => {
      dispatch(setLoading(true))
        return fetch(config.PostedJobList, {
          method: "post",
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: JSON.stringify(
            input
          ),
        })
        .then((response) => response.json())
          .then((response) => {
            if (response.status == 1) {
                // console.log(response, 'responseJons')
                response.data.map((i, k) => {
                  if (i.end_date && i.start_date) {
                    var date1 = new Date(); 
                    var date2 = new Date(i.start_date); 
                      
                    // To calculate the time difference of two dates 
                    var Difference_In_Time = date2.getTime() - date1.getTime(); 
                      
                    // To calculate the no. of days between two dates 
                    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24); 
                    if (Math.round(Difference_In_Days + 1) < 0) {
                      response.data[k]['expiration_date'] = 0  
                    }  else {
                      response.data[k]['expiration_date'] = Math.round(Difference_In_Days + 1)
                    }
                    
                  }
                })
                // console.log(response, 'responseJons')
                dispatch(PostedJob("job_list",response.data))
                dispatch(setLoading(false))
            } else if (response.status == -1) {
              // alert(response.message);
              dispatch(PostedJob("job_list",[]))
              dispatch(setLoading(false))
            }else{
              dispatch(setLoading(false))
            }
          })
          .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
          });
      };
    };

    
    export const draftedJobList = (input) => {
    return (dispatch) => {
      dispatch(setLoading(true))
        return fetch(config.PostedJobList, {
          method: "post",
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
          },
          body: JSON.stringify(
            input
          ),
        })
        .then((response) => response.json())
          .then((response) => {
            if (response.status == 1) {
                response.data.map((i, k) => {
                  if (i.end_date && i.start_date) {
                    var date1 = new Date(); 
                    var date2 = new Date(i.start_date); 
                      
                    // To calculate the time difference of two dates 
                    var Difference_In_Time = date2.getTime() - date1.getTime(); 
                      
                    // To calculate the no. of days between two dates 
                    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24); 
                    if (Math.round(Difference_In_Days + 1) < 0) {
                      response.data[k]['expiration_date'] = 0  
                    }  else {
                      response.data[k]['expiration_date'] = Math.round(Difference_In_Days + 1)
                    }
                    
                  }
                })
                // console.log(response, 'responseJons')
                dispatch(PostedJob("drafted_jobs", response.data))
                dispatch(setLoading(false))
            } else if (response.status == -1) {
              // alert(response.message);
              dispatch(PostedJob("drafted_jobs", []))
              dispatch(setLoading(false))
            }else{
              dispatch(setLoading(false))
            }
          })
          .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
          });
      };
    };

    export const postedClosedJobList = (input) => {
      return (dispatch) => {
          return fetch(config.PostedJobList, {
            method: "post",
            headers: {
              "Content-type": "application/json; charset=UTF-8",
              Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify(
              input
            ),
          })
            .then((response) => response.json())
            .then((response) => {
              if (response.status == 1) {
                  dispatch(PostedJob("closed_jobs_list",response.data))
              } else {
                // alert(response.message);
              }
            })
            .catch((e) => {
              console.log(e);
            });
        };
      };
      export const ClosedJob = (id) => {
        // console.log("Action")
        
        let formData = new URLSearchParams();    //formdata object
        formData.append("job_id",id.job_id)
        formData.append("status_code",id.status_code)    
        return (dispatch) => {
            return fetch(config.jobClosed, {
              method: "post",
              headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
              },
              body: formData
            })
              .then((response) => response.json())
              .then((response) => {
                if (response.status == 1) {
                  dispatch(PostedJob('show_alert',true));
                  dispatch(PostedJob('varient','success'));
                  dispatch(PostedJob('showMsg',"Job Removed Successfully"));
                  let input={
                    employer_id:localStorage.getItem('emp_id'),
                    filter:"0",
                    filter_name:'null',
                    filter_term:'null',
                    status_code:'1',
                    page_no : '0',
                    limit : '50'
                };
                let input1 = {
                  employer_id:localStorage.getItem('emp_id'),
                  filter:"0",
                  filter_name:'null',
                  filter_term:'null',
                  status_code:'3',
                  page_no : '0',
                  limit : '50'
                }
                let inputDraft = {
                  employer_id:localStorage.getItem('emp_id'),
                  filter:"0",
                  filter_name:'null',
                  filter_term:'null',
                  status_code:'4',
                  page_no : '0',
                  limit : '50'
                }
                  dispatch(postedJobList(input));
                  dispatch(postedClosedJobList(input1));
                  dispatch(draftedJobList(inputDraft));
                } else {
                  dispatch(PostedJob('show_alert',true))
                  dispatch(PostedJob('varient','danger'))
                  dispatch(PostedJob('showMsg',response.message))
                }
              })
              .catch((e) => {
                console.log(e);
              });
      };
    };
    export const postedJobDetail = (id) => {
        console.log("Action")
        const job_id =id
        return (dispatch) => {
            return fetch(config.PostedJobDetails, {
              method: "post",
              headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
              },
              body: JSON.stringify({
                job_id
              }),
            })
              .then((response) => response.json())
              .then((response) => {
                if (response.status == 1) {
                  console.log("api",response.data)
                    dispatch(PostedJob("get_details",response.data))
                } else {
                }
              })
              .catch((e) => {
                console.log(e);
              });
          };
        };
    

        export const View = (id) => {
          console.log("Action")
          const job_id =id
          return (dispatch) => {
              return fetch(config.ViewsList, {
                method: "post",
                headers: {
                  "Content-type": "application/json; charset=UTF-8",
                  Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                },
                body: JSON.stringify({
                  job_id
                }),
              })
                .then((response) => response.json())
                .then((response) => {
                  if (response.status == 1) {
                      dispatch(PostedJob("view_list",response.data))
                  } else {
                    
                  }
                })
                .catch((e) => {
                  console.log(e);
                });
            };
          };


          export const ApplicantList = (id) => {
            console.log("Action")
            const job_id =id
            return (dispatch) => {
                return fetch(config.ApplicantsList, {
                  method: "post",
                  headers: {
                    "Content-type": "application/json; charset=UTF-8",
                    Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                  },
                  body: JSON.stringify({
                    job_id
                  }),
                })
                  .then((response) => response.json())
                  .then((response) => {
                    if (response.status == 1) {
                        dispatch(PostedJob("applicant_list",response.data))
                    } else {
                      
                    }
                  })
                  .catch((e) => {
                    console.log(e);
                  });
              };
            };

            export const Shortlisted = (id) => {
              console.log("Action")
              const job_id =id
              return (dispatch) => {
                  return fetch(config.ShortlistedList, {
                    method: "post",
                    headers: {
                      "Content-type": "application/json; charset=UTF-8",
                      Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                    },
                    body: JSON.stringify({
                      job_id
                    }),
                  })
                    .then((response) => response.json())
                    .then((response) => {
                      if (response.status == 1) {
                          dispatch(PostedJob("short_list",response.data))
                      } else {
                        
                      }
                    })
                    .catch((e) => {
                      console.log(e);
                    });
                };
              };
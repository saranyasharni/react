import config from '../Common/Api_Links'

export const setLoading = (data) => ({
  type: "SET_LOADING",
  data
});
export const setPicLoading = (data) => ({
  type: "SET_PIC_LOADING",
  data
});

export const Profile = (field, data) => ({
  type: "EMPLOYEE_PROFILE",
  field, data
});

export const AddNewField = (field, data) => ({
  type: "ADD_NEW_FIELD",
  field, data
});

export const setCount = (field, data) => ({
  type: "SET_COUNT",
  data
})

export const getEmployeeProfile = () => {
  const employee_id = localStorage.getItem('employee_id')
  return (dispatch) => {
    return fetch(config.getEmployeeProfile, {
      method: "post",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
      },
      body: JSON.stringify({
        employee_id
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
         
          if (response.data[0].ic_number === "" ||
          response.data[0].ic_number === null ||
          response.data[0].account_number === "" ||
          response.data[0].bank_name === "" ||
          response.data[0].account_number === null || 
          response.data[0].bank_name === null 
          ) {
            // alert()
            localStorage.setItem('notify_model', 1)
          } else {
            localStorage.setItem('notify_model', 0)
          }
          let data = response.data[0];
          // if (data.resume_setting == "private") {
          //   alert('last2')
          //   dispatch(Profile("private", "private"))
          // } else if (data.resume_setting === "public"){
          //   alert('last1')
          //   dispatch(Profile("private", "public"))
          // } else {
          //   alert('last')
          //   dispatch(Profile("private", "public"))
          // }
          
          if (response.data[0].account_number === null ||
            response.data[0].account_number === "null" ||
            response.data[0].account_number === undefined
            ) {
           
              response.data[0].account_number = ""
            }
          if (data.profile_url === null ||
            data.profile_url === 'null' 
            ) {
              data.profile_url = ""
          }
          if (data.self_desc === null || data.self_desc === "null") {
            data.self_desc = ""
          } 
          dispatch(Profile("privacy", data.resume_setting))
          dispatch(Profile("profile_img", data.profile_url))
          dispatch(Profile("full_name", data.name))
          dispatch(Profile("email", data.email))
          dispatch(Profile("mobile_no", data.mobile))
          dispatch(Profile("passport_no", data.ic_number))
          dispatch(Profile("address", data.address))
          dispatch(Profile("bank_account_number", data.account_number))
          dispatch(Profile("bank_name", data.bank_name))
          dispatch(Profile("about", data.self_desc))
          dispatch(Profile("eis", data.eis))
          dispatch(Profile("socso", data.socso))
          dispatch(Profile("epf", data.epf))
          dispatch(Profile("city", data.city))
          dispatch(Profile("postal_code", data.postal_code))
          dispatch(Profile("resume", data.resume_desc))
          dispatch(Profile("resume_file", data.resume_file))
          // dispatch(Profile("private", data.resume_setting))
          if (data.education_details.length === []) {
            dispatch(Profile("qualifications", [{ 
              education: '', year_completed: '', qualification: ''
            }]))
          } else {
            // dispatch(Profile("qualification", [{ education: '', year_completed: '', qualification: '' }]))
            dispatch(Profile("qualifications", data.education_details))
          }
          dispatch(Profile("year", data.year_completed))
          if (data.languages.length == []) {
            dispatch(Profile("language_skill", [{language:'',spoken:'',read:'',written:''}]))
          } else {
            dispatch(Profile("language_skill", data.languages.reverse()))
          }
          if (data.employee_skills.length == 0) {
            dispatch(Profile("skills", [{skill_name:'',experience:''}]))
          } else {
            dispatch(Profile("skills", data.employee_skills))
          }
          if (data.working_experiences.length == []) {
            dispatch(Profile("working_experience", [{category:'',position:'',company_name:'',start_date:'',end_date:'',responsibilities:'',
            current_company:''}]))
          } else {
            dispatch(Profile("working_experience", data.working_experiences.reverse()))
          }
        } else {
        }
      })
      .catch((e) => {
        console.log(e);
      });
  };
};

export const UpdateProfile = (input) => {
  // console.log(input, 'inputcoming here')
  let lang_skills = JSON.stringify(input.language_skill)
  let skills = JSON.stringify(input.skills)
  let work_exp = JSON.stringify(input.work_experience)
  let educational_detail = JSON.stringify(input.education_details)
  // console.log(skills, 'skills')
  JSON.stringify(input.skills)
  JSON.stringify(input.work_experience)
  JSON.stringify(input.education_details)
  let formData = new URLSearchParams();    //formdata object
  formData.append("name",input.name)
  formData.append("mobile",input.mobile)
  formData.append("email",input.email)
  formData.append("address",input.address )
  formData.append("city",input.city)
  formData.append("self_desc",input.about)
  formData.append("postal_code",input.postal_code)
  formData.append("resume_desc",input.resume_desc)
  formData.append("ic_number",input.passport_no)
  formData.append("resume_file",input.resume_file)
  formData.append("bank_name",input.bank_name)
  formData.append("account_number",input.bank_account_number)
  formData.append("epf",input.epf)
  formData.append("experience",input.total_exp)
  formData.append("socso",input.socso)
  formData.append("eis",input.eis)
  formData.append("profile_url",input.profile_img)
  formData.append("resume_setting",input.resume_setting)
  formData.append("education_details",educational_detail)
  formData.append("skills",skills)
  formData.append("work_experience",work_exp)
  formData.append("language_skill",lang_skills)
  formData.append("employee_id",localStorage.getItem('employee_id'))
  
  return (dispatch) => {
    dispatch(setLoading(true))
    return fetch(config.employee_profile_upload, {
      method: "post",
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
      },
      body: formData,
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) { 
          if (response.data.ic_number === "" ||
          response.data.ic_number === null ||
          response.data.account_number === "" ||
          response.data.bank_name === "" ||
          response.data.account_number === null || 
          response.data.bank_name === null 
          ) {
            // alert()
            localStorage.setItem('notify_model', 1)
          } else {
            localStorage.setItem('notify_model', 0)
          }
          dispatch(setLoading(false))
          dispatch(Profile('show_alert', true))
          dispatch(Profile('varient', 'success'))
          dispatch(Profile('showMsg', "Profile details Edited successfully"))
        } else {
          dispatch(setLoading(false))
          dispatch(Profile('show_alert', true))
          dispatch(Profile('varient', 'danger'))
          dispatch(Profile('showMsg', response.message))
        }
      })
      .catch((e) => {
        dispatch(setLoading(false))
        console.log(e);
        dispatch(Profile('show_alert', true))
        dispatch(Profile('varient', 'danger'))
        dispatch(Profile('showMsg', "Please Try again Later"))
      });
  };
};




export const UploadEmployeeProfile = (type, file) => {
  // console.log('img', file)
  const formData = new FormData();
  formData.append('upload_file', file);
  return (dispatch) => {
    dispatch(setPicLoading(true))
    return fetch(config.uploadProfilePic, {
      method: "post",
      headers: {

        Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
      },
      body: formData,
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.status == 1) {
          if (type == "profile_img") {
            dispatch(Profile('profile_img', response.file_links_data[0].original_data))
          } else {
            dispatch(Profile('resume_file', response.file_links_data[0].original_data))
          }

        } else {
          dispatch(Profile('show_alert', true))
          dispatch(Profile('varient', 'danger'))
          dispatch(Profile('showMsg', response.message))
        }
        dispatch(setPicLoading(false))
      })
      
      .catch((e) => {
        dispatch(setPicLoading(false))
        console.log(e);
      });
  };
};
import config from '../Common/Api_Links'
// import { setSuccess, setWorkers } from '../Employer/Hire';

export const AppliedJob = (field, data) => ({
    type: "APPLIED_JOBS",
    field, data
});
export const setLoading = data => ({
    type: "LOADING",
    data
})
export const setRequests = data => ({
    type : 'SET_REQUESTS',
    data
})
export const setStopLoading = data => ({
    type: "STOP_LOADING",
    data
})
export const setWorkeringTime = data => ({
    type: "SET_WORKING_TIME",
    data
})
export const inputChange = (field, val) => ({
    type : "INPUT_CHANGE",
    field,
    val
});

export const CurrentJob = (data) => ({
    type : "CURRENT_JOB",
    data
})

export const setModelSuccess = (data, message) => ({
    type : "MODEL_SUCCESS",
    data,
    message
});

export const setSuccess = (data, msg) => ({
    type:'SET_SUCCESS',
    data,
    msg
});

export const setShow = (data) => ({
    type : "SET_SHOW",
    data
});

export const setWorkeringJobs = (data) => ({
    type : "WORKING_JOBS",
    data
});

export const getWorkingJobs = (data) => {
    let formData = new URLSearchParams();
    formData.append('employee_id', data.employee_id)
    // formData.append('employee_id', 45)
    formData.append('page_no', data.page_no)
    formData.append('limit', data.limit)
    
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.list_working_jobs, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                // dispatch(setLoading(false))
                dispatch(setWorkeringJobs(response.data))
            // window.location.href = "/employee-dashboard";
            } else {
                // dispatch(setLoading(false))
                dispatch(setWorkeringJobs([]))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setWorkeringJobs([]))
            console.log(e);
        });
    };
};


export const Applied_job_list = (input) => {

    return (dispatch) => {
        return fetch(config.EmployeeAppliedJobList, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify(
                input
            ),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log(response, 'responseJons')
                    response.data.map((i, k) => {
                        if (i.end_date && i.start_date) {
                            
                            var date1 = new Date(i.start_date);
                            var date2 = new Date(i.end_date);

                            // To calculate the time difference of two dates 
                            var Difference_In_Time = date2.getTime() - date1.getTime();

                            // To calculate the no. of days between two dates 
                            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
                            response.data[k]['expiration_date'] = Difference_In_Days
                        }
                    })

                    dispatch(AppliedJob("job_list", response.data))
                } else if (response.status == -1) {
                    // alert(response.message);
                    dispatch(AppliedJob("job_list", []))
                } else {

                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const AppliedClosedJobList = (input) => {
    return (dispatch) => {
        return fetch(config.EmployeeAppliedJobListCompleted, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify(
                input
            ),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    dispatch(AppliedJob("closed_jobs_list", response.data))
                } else {
                    dispatch(AppliedJob("closed_jobs_list", []))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};


export const AppliedClosedJob = (id,app_id) => {
    // console.log("Action")
    const application_id = app_id
    const job_id = id
    let status_code = 6
    return (dispatch) => {
        return fetch(config.EmployeeAppliedjobDeclien, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                application_id,
                job_id,
                status_code
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    dispatch(AppliedJob('show_alert', true));
                    dispatch(AppliedJob('varient', 'success'));
                    dispatch(AppliedJob('showMsg', response.message));
                    let input = {
                        employee_id: localStorage.getItem('employee_id'),
                        filter: "0",
                        filter_name: 'null',
                        filter_term: 'null',
                    };
                    dispatch(Applied_job_list(input));
                    dispatch(AppliedClosedJobList(input));
                } else {
                    dispatch(AppliedJob('show_alert', true))
                    dispatch(AppliedJob('varient', 'danger'))
                    dispatch(AppliedJob('showMsg', response.message))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const WorkingJobDetail = (id) => {
    const work_id = id;
    // const employee_id =localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.getCurrentJobDetail, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                work_id:work_id,
                // employee_id:employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log("api", response.data)
                    dispatch(CurrentJob(response.data))
                    if (response.data && response.data.worker_attendance_details) {
                        if (response.data && response.data.worker_attendance_details 
                            && response.data.worker_attendance_details[0].status === 'work-stopped'
                            || response.data.worker_attendance_details[0].status === 'auto-stopped'
                        ) {
                            // alert('stop')
                            dispatch(setWorkeringTime({
                                work_status:1,
                                work_start_time:`work stoped at ${response.data.worker_attendance_details[0].actual_end_time}`
                            }))
                        } else {
                        dispatch(setWorkeringTime({
                            work_status:1,
                            work_start_time:`work started at ${response.data.worker_attendance_details[0].actual_start_time}`
                        }))
                        }
                    }
                    
                } else {
                    dispatch(CurrentJob([]))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const viewCompletedProfile = (id) => {
    let work_id = id;
    const employee_id = localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.viewCompletedJob, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                work_id:work_id,
                employee_id:employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log("api", response.data)
                    response.data = {application:response.data}
                    dispatch(AppliedJob("get_details", [response.data]))
                } else {
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const AppliedJobDetail = (id) => {
    const application_id = id;
    const employee_id = localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.viewAppliedJob, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                application_id:application_id,
                employee_id:employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log("api", response.data)
                    dispatch(AppliedJob("get_details", [response.data]))
                } else {
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const startWork = (data) => {
    let formData = new URLSearchParams();
    formData.append('employee_id', data.employee_id)
    formData.append('work_id',data.work_id)
    formData.append('job_id',data.job_id)
    formData.append('login_date',data.login_date)
    formData.append('login_time',data.login_time)
    formData.append('extended',data.extended)
    formData.append('extended_work_id',data.extended_work_id)
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.startWork, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                dispatch(setLoading(false))
                dispatch(setWorkeringTime({
                    work_status:1,
                    work_start_time:`work started at ${response.data.actual_start_time}`
                }))
                dispatch(setSuccess(1, 'Successfully Started Work'))
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setLoading(false))
                dispatch(setWorkeringTime({
                    work_status:1,
                    work_start_time:response.message
                }))
                
                dispatch(setSuccess(3, response.message))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setWorkeringJobs([]))
            dispatch(setSuccess(3, 'Please try after sometime'))
            console.log(e);
        });
    };
};

export const stopWork = (data) => {
    let formData = new URLSearchParams();
    formData.append('employee_id', data.employee_id)
    formData.append('work_id',data.work_id)
    formData.append('job_id',data.job_id)
    formData.append('login_date',data.login_date)
    formData.append('logout_time',data.login_time)
    formData.append('extended',data.extended)
    formData.append('extended_work_id',data.extended_work_id)
    
    return (dispatch) => {
        dispatch(setStopLoading(true))
        return fetch(config.stopWork, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                dispatch(setStopLoading(false))
                if (response.data ) {
                    dispatch(setWorkeringTime({
                        work_status:1,
                        work_start_time:`work stopped at ${response.data.actual_end_time}`
                    }))
                }    
                
                dispatch(setSuccess(1, 'Successfully Stopped Work'))
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setStopLoading(false))
                dispatch(setWorkeringTime({
                    work_status:1,
                    work_start_time:response.message
                }))
               
                dispatch(setSuccess(2, response.message))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setWorkeringTime({}))
            dispatch(setSuccess(2, 'Please try after sometime'))
            console.log(e);
        });
    };
};

export const requestLateLogin = (data) => {
    let formData = new URLSearchParams();    
    formData.append('employee_id',data.employee_id)
    formData.append('employer_id',data.employer_id)
    formData.append('job_id',data.job_id)
    formData.append('request_date',data.request_date)
    formData.append('request_time',data.request_time)
    formData.append('description',data.description)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.requestLateLogin, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                // dispatch(setLoading(false))
                
                dispatch(setModelSuccess(1, 'Request Send Successfully'))
            } else {
                // dispatch(setLoading(false))
                dispatch(setModelSuccess(2, response.message))
                
                
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setWorkeringJobs([]))
            dispatch(setModelSuccess(2, 'Please try after sometime'))
            console.log(e);
        });
    };
};

export const listWorkRequests = () => {
    let formData = new URLSearchParams();    
    formData.append('employee_id',localStorage.getItem('employee_id'))
    // formData.append('employee_id',55)
    
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.list_exteneded_emp_requests, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status === 1) {
                dispatch(setLoading(false))
                
                dispatch(setRequests(response.data))

            } else {
                dispatch(setLoading(false))
                dispatch(setRequests([]))
                
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setWorkeringJobs([]))
            console.log(e);
        });
    };
};

export const acceptRequest = (data) => {
    let formData = new URLSearchParams();    
    formData.append('employee_id',localStorage.getItem('employee_id'))
    formData.append('extended_work_id',data.request_id)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.accept_extend_request, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                // dispatch(setLoading(false))
                
                dispatch(setSuccess(1, 'Request Accepted Successfully'))
                dispatch(listWorkRequests())
            } else {
                // dispatch(setLoading(false))
                
                dispatch(setSuccess(2, response.message))
         
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            
            dispatch(setSuccess(2, 'Try again later'))
            console.log(e);
        });
    };
};

export const rejectRequest = (data) => {
    let formData = new URLSearchParams();    
    formData.append('employee_id',localStorage.getItem('employee_id'))
    formData.append('extended_work_id',data.request_id)
    formData.append('work_id',data.work_id)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.decline_extend_request, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                // dispatch(setLoading(false))
                
                dispatch(setSuccess(1, 'Request Rejected Successfully'))
                dispatch(listWorkRequests())

            } else {
                // dispatch(setLoading(false))
                
                dispatch(setSuccess(2, response.message))
         
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            
            dispatch(setSuccess(2, 'Try again later'))
            console.log(e);
        });
    };
};
import config from '../Common/Api_Links';

export const Dasboard =(field,data) =>({
    type: "DASBOARD",
    field,data
});

export const JobInfo= () => {
    
    const employee_id = localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.EmployeeDasboardJobinfo, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                employee_id:employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log("api", response.data)
                    dispatch(Dasboard("job_info", response.data))
                } else {
                    dispatch(Dasboard("job_info",[]))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};


export const JobCard = () => {
    
    const employee_id =localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.EmployeeDasboardJobcard, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                employee_id:employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    console.log("api", response.data)
                    dispatch(Dasboard("job_card", response.data))
                } else {
                    dispatch(Dasboard("job_card",[]))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const JobOffer = () => {
    const employee_id =localStorage.getItem('employee_id')
    const status_code  = "0"
    return (dispatch) => {
        return fetch(config.EmployeeDasboardJoboffer, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                employee_id:employee_id,
                status_code:status_code 
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    console.log("api", response.data)
                    dispatch(Dasboard("job_offer", response.data))
                } else {
                    dispatch(Dasboard("job_offer",[]))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};


export const AcceptOffer = (id,job) => {
    let application_id =id;
    let job_id = job
    let employee_id = localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.AcceptJoboffer, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                application_id,
                job_id,
                employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    dispatch(Dasboard('show_alert', true))
                    dispatch(Dasboard('varient', 'success'))
                    dispatch(Dasboard('showMsg', "Offer Accepted Successfully"))
                    dispatch(JobOffer())
                } else {
                    dispatch(Dasboard('show_alert', true))
                    dispatch(Dasboard('varient', 'danger'))
                    dispatch(Dasboard('showMsg', response.message))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};


export const DeclineOffer = (id,job) => {
    let application_id =id;
    let job_id = job
    return (dispatch) => {
        return fetch(config.DeclineJoboffer, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                application_id,
                job_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    dispatch(Dasboard('show_alert', true))
                    dispatch(Dasboard('varient', 'success'))
                    dispatch(Dasboard('showMsg', "Offer Declined Successfully"))
                    dispatch(JobOffer())
                } else {
                    dispatch(Dasboard('show_alert', true))
                    dispatch(Dasboard('varient', 'danger'))
                    dispatch(Dasboard('showMsg', response.message))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};



import { connectAdvanced } from 'react-redux';
import config from '../Common/Api_Links';
import {JobOffer} from './Dashboard';
import history from "../../stores/history"

export const Dasboard =(field,data) =>({
    type: "DASBOARD",
    field,data
});

export const setShow = (data) => {
    return {
        type: 'SET_SHOW',
        data
    }
}
export const confirmPopupShow = (data) => {
    return {
        type: 'SET_CONFIRM_POPUP',
        data
    }
}
export const setViewOffer = (data) => ({
    type : "VIEW_OFFERS",
    data
})
export const setOffers = (data) => ({
    type :'SET_OFFERS',
    data
});

export const setSuccess =(data, msg) =>({
    type: "SET_SUCCESS",
    data,
    msg
});

export const setAcceptedOffers = (data) => ({
    type: 'SET_ACCEPTED_OFFERS',
    data
});

export const getOffers = (data) => {
    let formData = new URLSearchParams();    
    formData.append('employee_id',data.employee_id)
    formData.append('page_no',0)
    formData.append('limit',1000)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.jobOffers, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setOffers(response.data))
            } else {
                dispatch(setOffers([]))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            
            dispatch(setOffers([]))
            console.log(e);
        });
    };
};

export const getAcceptedOffers = (data) => {
    let formData = new URLSearchParams();    
    formData.append('employee_id',data.employee_id)
    formData.append('page_no',0)
    formData.append('limit',30)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.acceptedOffers, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                
                dispatch(setAcceptedOffers(response.data))
            } else {
                dispatch(setAcceptedOffers([]))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            
            dispatch(setAcceptedOffers([]))
            console.log(e);
        });
    };
};

export const acceptedOffers = (data) => {
    let formData = new URLSearchParams();    
    
    formData.append('application_id',data.application_id)
    formData.append('status_code',data.status_code)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.acceptJobOffer, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setSuccess(1,"Offer Accepted Successfully"))

                dispatch(JobOffer())
                dispatch(getAcceptedOffers({
                    employee_id:localStorage.getItem('employee_id'),
                    page_no:0,
                    limit:30
                }))
                
                dispatch(getOffers({
                    employee_id:localStorage.getItem('employee_id'),
                    page_no:0,
                    limit:1000
                }))
                history.push('/offers')
                
            } else {
                dispatch(setSuccess(2,response.message))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setSuccess(2, "Please try after some time"))
            console.log(e);
        });
    };
};

export const rejectOffers = (data) => {
    let formData = new URLSearchParams();    
    
    formData.append('application_id',data.application_id)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.DeclineJoboffer, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setSuccess(1, "Offer Rejected Successfully"))
                dispatch(JobOffer())
                dispatch(getAcceptedOffers({
                    employee_id:localStorage.getItem('employee_id'),
                    page_no:0,
                    limit:30
                }))
                dispatch(getOffers({
                    employee_id:localStorage.getItem('employee_id'),
                    page_no:0,
                    limit:1000
                }))
                  dispatch(confirmPopupShow(false))
                history.push('/offers')
                
            } else {
                
                dispatch(setSuccess(2, response.message))
                dispatch(confirmPopupShow(false))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setSuccess(2, "Please try after some time"))
            console.log(e);
        });
    };
};

export const ConfirmOffer = (data) => {
    let formData = new URLSearchParams();    
    
    formData.append('application_id',data.application_id)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.confirmNewOffer, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setSuccess(1,"Offer Confirmed Successfully"))
                dispatch(JobOffer())
                dispatch(getAcceptedOffers({
                    employee_id:localStorage.getItem('employee_id'),
                    page_no:0,
                    limit:30
                }))
                dispatch(getOffers({
                    employee_id:localStorage.getItem('employee_id'),
                    page_no:0,
                    limit:1000
                }))
                history.push('/employee_applied_jobs')
            } else {
                dispatch(setSuccess(2,response.message))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setSuccess(2, "Please try after some time"))
            console.log(e);
        });
    };
};

export const ViewOffers = (data) => {
    let formData = new URLSearchParams();    
    
    formData.append('application_id',data.application_id)
    formData.append('employee_id',data.employee_id)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.viewJobOffer, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setViewOffer(response.data))
            } else {
                dispatch(setViewOffer([]))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setViewOffer([]))
            console.log(e);
        });
    };
};

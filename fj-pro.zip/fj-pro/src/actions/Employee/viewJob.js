import config from '../Common/Api_Links'

export const setSuccess = (data, msg) => ({
    type:'SET_SUCCESS',
    data,
    msg
});

export const setLoading = (data) => ({
    type:'SET_LOADING',
    data
});

export const savedJobList = (data) => ({
    type: 'SAVED_JOB_LIST',
    data
});

export const View_Job =(field,data)=>({
    type: "EMPLOYEE_VIEW_JOB",
    field,
    data
});

export const setShow = (data) => {
    return {
        type: 'SET_SHOW',
        data
    }
}

export const View_job_list = (data) => {
    
    let formData = new URLSearchParams();    //formdata object
    formData.append("employee_id",data.employee_id)
    formData.append("filter",data.filter)
    formData.append("filter_by",data.filter_by)
    formData.append("location",data.location)
    formData.append("lat",data.lat ? data.lat : null)
    formData.append("lon",data.lon ? data.lon : null)
    formData.append("distance",data.distance ? data.distance : null)
    formData.append("radius_search",data.radius_search ? data.radius_search : null)
    formData.append("limit",50)
    formData.append("page_no",0)
    return (dispatch) => {
        return fetch(config.EmployeeViewJobList, {
            method: "post",
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log(response, 'responseJons')
                    response.data.map((i, k) => {
                        if (i.end_date && i.end_date) {
                            var date1 = new Date();
                            var date2 = new Date(i.end_date);

                            // To calculate the time difference of two dates 
                            var Difference_In_Time = date2.getTime() - date1.getTime();

                            // To calculate the no. of days between two dates 
                            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
                            if (Math.round(Difference_In_Days + 1) < 0) {
                                response.data[k]['expiration_date'] = 0  
                            }  else {
                                response.data[k]['expiration_date'] = Math.round(Difference_In_Days)
                            }
                            // response.data[k]['expiration_date'] = Difference_In_Days
                        }
                    })
                    // console.log(response, 'responseJons')
                    dispatch(View_Job("job_list", response.data))
                } else if (response.status == -1) {
                    // alert(response.message);
                    dispatch(View_Job("job_list", []))
                } else {

                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const savedJobs = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employee_id",data.employee_id)
    
    return (dispatch) => {
        return fetch(config.getSavedJobLists, {
            method: "post",
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log(response, 'responseJons')
                    response.data.map((i, k) => {
                        if (i[0].end_date && i[0].end_date) {
                            var date1 = new Date();
                            var date2 = new Date(i[0].end_date);

                            // To calculate the time difference of two dates 
                            var Difference_In_Time = date2.getTime() - date1.getTime();

                            // To calculate the no. of days between two dates 
                            var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
                            if (Math.round(Difference_In_Days + 1) < 0) {
                                response.data[k][0]['expiration_date'] = 0  
                            }  else {
                                response.data[k][0]['expiration_date'] = Math.round(Difference_In_Days )
                            }
                            // response.data[k][0]['expiration_date'] = Difference_In_Days
                        }
                    })
                    
                    dispatch(savedJobList(response.data))
                } else if (response.status == -1) {
                    // alert(response.message);
                    dispatch(savedJobList([]))
                } else {

                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};


export const ViewJobDetail = (id) => {
    const job_id = id;
    const employee_id =localStorage.getItem('employee_id')
    return (dispatch) => {
        return fetch(config.EmployeeViewJobDetails, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                job_id:job_id,
                employee_id:employee_id
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log("api", response.data)
                    dispatch(View_Job("get_details", [response.data]))
                } else {
                    dispatch(View_Job("get_details",[]))
                }
            })
            .catch((e) => {
                console.log(e);
            });
    };
};

export const ApplyJob = (data) => {
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.ApplyJob, {
            method: "post",
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body: JSON.stringify({
                job_id:data.job_id,
                employee_id:data.employee_id,
                employer_id:data.employer_id,
                status_code:1
            }),
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                dispatch(setLoading(false))
                dispatch(setSuccess(1, response.message))
                window.location.href = "/employee_applied_jobs"
            } else {
                dispatch(setLoading(false))
                dispatch(setSuccess(-1, response.message))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setSuccess(-1, "Please try again later"))
        });
    };
};

export const savedJob = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employee_id",data.employee_id)
    formData.append("job_id",data.job_id)
    formData.append("saved",data.saved)

    return (dispatch) => {
        return fetch(config.saveJob, {
            method: "post",
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                dispatch(setSuccess(1, response.message))  
                dispatch(View_job_list({
                    employee_id:localStorage.getItem('employee_id'),
                    filter:0,
                    filter_by:null,
                    location:null,
                    limit: 50,
                    page_no: 0
                }))
                dispatch(savedJobs({
                    employee_id:localStorage.getItem('employee_id'),
                }))
            } else {
                dispatch(setSuccess(-1, response.message))                  
            }
        })
        .catch((e) => {
            dispatch(setSuccess(-1, "Please try again later"))                  
            // console.log(e);
        });
    };
};
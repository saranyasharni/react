import config from "../Common/Api_Links";
import history from "../../stores/history";
export const setLoading = (data) => ({
  type: "SET_LOADING",
  data
});

export const scheduleModelsetUp = (data) => ({
    type: "SET_SCHEDULE_MODEL",
    data
})

export const setAmount = (data) => ({
    type : 'SET_AMOUNT',
    data
})
export const setBtnLoading = (data) => ({
    type: "SET_BTN_SHOW",
    data
});
export const setModalLoading = data => ({
    type: "SET_MODEL_LOADING",
    data
})
export const setExtraLoading = (data) => ({
    type: "SET_EXTRA_LOADING",
    data
});
export const setExtraLoadingStatus = data => ({
    type: "SET_EXTRA_LOADING_STATUS",
    data
})
export const setExtraSearchEmployeeLists = (data) => ({
    type : "SET_EXTRA_SEARCH_EMP_LIST",
    data
})

export const updatePageNumber = (data) => ({
    type: "UPDATE_PAGE_NUMBER",
    data
});

export const hireCandidateModal = (data, show, emp_id, url) => ({
    type: "HIRE_CANDIDATE_MODALS",
    data,
    show, 
    emp_id,
    url
});

export const setContractModal = data => ({
    type : "SET_CONTRACT_MODAL",
    data
});

export const setCandidate = data => ({
    type : "SET_CANDIDATE",
    data
});

export const setSearchApiCall = data => ({
    type: "SET_SEARCH_API_CALL",
    data
})
export const setScheduleInterview = (data) => ({
    type: "SET_SCHEDULE_INTERVIEW",
    data
})
export const showContact = (data) => ({
    type : "SET_CONTACT_INFO",
    data
})
export const setEmployeeLists = (data) => ({
    type: "SET_EMPLOYEE-LISTS",
    data
});

export const setSchedules = (data) => ({
    type: "SET_SCHEDULES_LISTS",
    data
});
export const setPaymentModel = (data) => ({
    type: "SET_PAYMENT_MODEL",
    data
})
export const setRejected = (data) => ({
    type: "SET_REJECTED_LISTS",
    data
});

export const setShowModel = (data) => ({
    type: "SET_SHOW_HIDE",
    data
});

export const setPositions = (data) => ({
    type: "SET_POSITIONS",
    data
});

export const setOnePosition = (data) => ({
    type: "SET_ONE_POSITION",
    data
})

export const setShortListModel = (data) => ({
    // console.log(data, "actions");
    type: "SET_SHOW_SHORTLIST",
    data
});

export const setWorkers = (data) => ({
    type: "SET_WORKERS",
    data
});

export const setNewEmployeeLists = data => ({
    type:'SET_UNAPPLIED_LISTES',
    data
})

export const setShotListEmployees = (data) => ({
    type: "SET_SHORTLISTED_EMPLOYEES",
    data
});

export const setSuccess = (val, data) => ({
    type: "SHOW_RESPONSE_MSG",
    val,
    data
});

export const setHiredStatus = (val, data) => ({
    type: "SET_HIRED_STATUS",
    val,
    data
})

export const setShow = (data) => {
    return {
        type: 'SET_SHOW',
        data
    }
}

export const showView = (data) => {
    return {
        type: 'SET_SHOW_VIEW_LIST',
        data
    }
}

export const getAllPositions = (data) => {
    
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",localStorage.getItem('emp_id'))
    formData.append("industry_type",data.industry_type )
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.listPositions, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {             
                dispatch(setPositions(response.data))

            // window.location.href = "/employee-dashboard";
            } else {
           
                dispatch(setPositions([]))
            }
        })
        .catch((e) => {
            dispatch(setPositions([]))
            console.log(e);
        });
    };
};

export const getOnePosition = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id", localStorage.getItem('emp_id'))
    formData.append("industry_type", data.industry_type)
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.listOnePosition, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
    
            if (response.status == 1) {             
                dispatch(setOnePosition(response.data))
            // window.location.href = "/employee-dashboard";
            } else {   
                dispatch(setOnePosition([]))
            }
        })
        .catch((e) => {
            dispatch(setOnePosition([]))
            console.log(e);
        });
    };
};

export const getAllWorkers = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",data.employer_id)
    formData.append("filter",data.filter)
    // formData.append("filter_by",data.filter_by)
    // formData.append("filter_term",data.filter_term)
    formData.append("status_code",3)
    formData.append("industry_type",data.industry_type)
    formData.append("job_position",data.job_position)
    formData.append("page_no","0")
    formData.append("limit","15")
    // formData.append("location",data.location)
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.hired, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
        // 
            // console.log(response, 'response9090')
            if (response.status == 1) {
             
                dispatch(setLoading(false))
                dispatch(setWorkers(response.data))
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setLoading(false))
                dispatch(setWorkers([]))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
        });
    };
};

export const getSchedules = (data) => {
    let formData = new URLSearchParams();    //formdata object
    // formData.append("employer_id", data.employer_id)
    // formData.append("status_code", data.status_code)
   
    formData.append('employer_id', data.employer_id)
    formData.append("status_code", data.status_code)
    formData.append('filter',data.filter)
    formData.append('filter_by',data.filter_by)
    formData.append('industry_type',data.industry_type)
    formData.append('job_position',data.job_position)
    formData.append('page_no','0')
    formData.append('limit','15')
    formData.append("interview_date",data.interview_date)
    // formData.append("filter_date",data.filter_date)
    
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.listScheules, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {
                dispatch(setLoading(false))
                dispatch(setSchedules(response.data))
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setLoading(false))
                dispatch(setSchedules([]))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setSchedules([]))
            console.log(e);
        });
    };
};



export const cancelInterview = (data) => {
    let formData = new URLSearchParams();//formdata object
    // formData.append("employer_id", data.employer_id)
    // formData.append("status_code", data.status_code)
    formData.append("schedule_id",data.schedule_id)
    formData.append("employee_id",data.employee_id)
    formData.append("job_id",data.job_id)

    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.cancel_interview, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setSuccess(1, 'Interview Cancelled successfuly'))
                dispatch(getSchedules({
                    employer_id:localStorage.getItem("emp_id"),
                    status_code : 8,
                    filter:0,
                    filter_by:null,
                    industry_type:null,
                    job_position:null,
                    page_no:0,
                    limit:15,
                    interview_date:null
                }))
            } else {
                // dispatch(setLoading(false))
                dispatch(setSuccess(2, response.message))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setSuccess(2, 'Please Try again after some time'))
            console.log(e);
        });
    };
};

export const getRejected = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id", data.employer_id)
    formData.append("filter", data.filter)
    formData.append("status_code",9)
    formData.append("industry_type","null")
    // formData.append("filter_term",data.filter_term)
    formData.append("job_position","null")
    formData.append("page_no","0")
    formData.append("limit","15")
    // formData.append("location",data.location)
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.listRejected, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'response9090')
            if (response.status == 1) {   
                dispatch(setLoading(false))
                dispatch(setRejected(response.data))
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setLoading(false))
                dispatch(setRejected([]))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setSchedules([]))
            console.log(e);
        });
    };
};

export const getAllUnappliedEmployees = (data, load) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",data.employer_id)
    formData.append("filter",data.filter)
    formData.append("position",data.position)
    formData.append("location",data.location)
    formData.append("experience",data.experience)
    formData.append("search_term",data.search_term)
    formData.append("is_vaccinated",data.is_vaccinated)
    formData.append("industry_type",data.industry_type)
    formData.append("lat", data.lat)
    formData.append("lon", data.lon)
    formData.append("limit", data.limit)
    formData.append("page_no", data.page_no)

    return (dispatch) => {
        
        if (!load) {
            dispatch(setLoading(false))
        } else {
        
            dispatch(setExtraLoading(true))
        }
        return fetch(config.search_employees, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
        
                if (!load) {
                    
                    dispatch(setLoading(false))
                    dispatch(setNewEmployeeLists(response.data))
                } else {
                    
                    dispatch(setExtraLoading(false))
                    if (response.data.length > 0) {
                        dispatch(setExtraSearchEmployeeLists(response.data))
                    } else {
                        // console.log(response.data.length, 'length')
                    // if (response.data === []) {
                        // alert('else')
                        dispatch(setExtraSearchEmployeeLists([]))
                        dispatch(setExtraLoadingStatus(1))
                    // }        
                    }
        
                }
            
            } else {
               
                if (!load) {
                    dispatch(setLoading(false))
                } else {
                    dispatch(setSuccess(2, 'No Data to load'))
                    dispatch(setExtraLoading(false))
                }
                dispatch(setNewEmployeeLists([]))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
        });
    };
};

export const getAllEmployees = (data) => {
    
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",data.employer_id)
    formData.append("filter",data.filter)
    formData.append("job_position",data.position)
    formData.append("industry_type",data.industry_type)
    // formData.append("location",data.location)
    // formData.append("experience",data.experience)
    // formData.append("search_term",data.search_term)
    formData.append("status_code",'1')
    formData.append("page_no",'0')
    formData.append("limit",'15')

    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.getEmployeeLists, {
        method: "post",
        headers: {
             "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                // console.log(response, 'response9090')
                dispatch(setLoading(false))
                dispatch(setEmployeeLists(response.data))
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setLoading(false))
                dispatch(setEmployeeLists([]))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
        });
    };
};

export const getShortlistedEmployees = (data) => {
    // console.log(data, 'dataShorllist')
    let convertData = {
        'employer_id':data.employer_id,
        'status_code':"2",
        'filter':data.filter,
        'industry_type':data.industry_type,
        'job_position':data.job_position,
        'page_no':data.page_no,
        'limit':"15",
    }

    let sendData = JSON.stringify(convertData)
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.getShortListedEmployees, {
        method: "post",
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:sendData
        })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            dispatch(setShotListEmployees(response.data))
            dispatch(setLoading(false))
            // window.location.href = "/employee-dashboard";
          } else {
            dispatch(setShotListEmployees([]))
            dispatch(setLoading(false))
          }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            console.log(e);
        });
    };
};
  
export const getEmployeeProfile = (data) => {
    let convertData = {'employer_id':data}
    let sendData = JSON.stringify(convertData)
    return (dispatch) => {
      return fetch(config.getEmployeeLists, {
        method: "post",
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:sendData
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.status == 1) {
            console.log(response, 'response')
            // window.location.href = "/employee-dashboard";
          } else {
            
          }
           })
        .catch((e) => {
          console.log(e);
        });
    };
};

export const hireEmployee = (data) => {
    let convertData = {
        'employee_id':data.employee_id,
        'job_id':data.job_id,
        'status_code':'3',
        're_hire': '0',
        'contract_url': data.url,
        'request':data.request,
        'employer_id':localStorage.getItem('emp_id'),
        'from_credits':data.from_credits
    }

    let sendData = JSON.stringify(convertData)
    
    return (dispatch) => {
        // dispatch(setSuccess(3, 'Please wait a moment'))
        return fetch(config.hireEmployee, {
            method: "post",
            headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:sendData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                // console.log(response, 'response')
                dispatch(setHiredStatus(1, 'Profile has been hired successfully', 'Hired'))
                // dispatch(getAllWorkers({
                //     employer_id:localStorage.getItem('emp_id'),
                //     status_code : "3",
                //     filter:0,
                //     industry_type:null,
                //     job_position:null,
                //     page_no:0,
                //     limit:15
                // }))
                history.push('/hire-staff')
                // dispatch(getShortlistedEmployees(localStorage.getItem('emp_id')))
            } else {
               
                dispatch(setHiredStatus(2, response.message))
            }
        })
        .catch((err) => {
            dispatch(setHiredStatus(2, 'Please Try after some time'))
        });
    };
};

export const shortListEmployee = (data) => {
    
    let convertData = {
        'employee_id':data.employee_id,
        'job_id':data.job_id,
        'application_id':data.application_id,
        'status_code':'2',
        'request' : data.request
    }

    let sendData = JSON.stringify(convertData)
    
    return (dispatch) => {
        dispatch(setBtnLoading(true))
        return fetch(config.shotListEmployee, {
            method: "post",
            headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:sendData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                // console.log(response, 'response')
                dispatch(setSuccess(1, 'Profile has been shortlisted successfully', 'Shortlisted'))
                
                let employerId = localStorage.emp_id ? localStorage.getItem('emp_id') :''
                dispatch(getAllEmployees({
                    employer_id:employerId,
                    filter:0,
                    position:null,
                    location:null, 
                    experience: null,
                    search_term: null,
                    industry_type : null,
                    status_code: 1
                }))
                dispatch(getAllUnappliedEmployees({
                    employer_id:employerId,
                    filter:0,
                    position:null,
                    location:null,
                    search_term : null,
                    industry_type : null,
                    experience:null,
                    lat:'null',
                    lon:'null',
                    page_no:0,
                    limit:15
                }, false))
                dispatch(getShortlistedEmployees({
                    employer_id:employerId,
                    filter:'0',
                    industry_type :'null' ,
                    job_position : 'null',
                    page_no:'0',
                    limit : '15',
                    status_code : '2'
                }))
                dispatch(getSchedules({
                    employer_id:employerId,
                    status_code : 8,
                    filter:0,
                    filter_by:null,
                    industry_type:null,
                    job_position:null,
                    page_no:0,
                    limit:15,
                    interview_date:null
                }))
                dispatch(setShortListModel({
                    application_id: 'null',
                    employee_id: '',
                    job_id : null,
                    show:false,
                    status_code: 2,
                    show_status: 'show',
                    request : 1
                }))
                setTimeout(() => {
                    history.push("/hire-staff")
                }, 2500)
            } else {
                // alert(response.message)
                dispatch(setShortListModel({
                    application_id: 'null',
                    employee_id: '',
                    job_id : null,
                    show:false,
                    status_code: 2,
                    show_status: 'show',
                    request : 1
                }))
            }
            dispatch(setBtnLoading(false))
          
        })
        .catch((err) => {
            dispatch(setBtnLoading(false))
            dispatch(setSuccess(2, "Please try again later"))
        });
    };
    };


    export const reShortlistEmployee = (data) => {
        let convertData = {
            'employee_id':data.employee_id,
            'job_id':data.job_id,
            'status_code':'3',
            're_hire': '0',
            'contract_url': data.url,
            'request':data.request,
            'employer_id':localStorage.getItem('emp_id'),
            'from_credits':data.from_credits
        }
    
        let sendData = JSON.stringify(convertData)
        
        return (dispatch) => {
            // dispatch(setSuccess(3, 'Please wait a moment'))
            return fetch(config.hireEmployee, {
                method: "post",
                headers: {
                "Content-type": "application/json; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
                },
                body:sendData
            })
            .then((response) => response.json())
            .then((response) => {
                if (response.status == 1) {
                    // console.log(response, 'response')
                    dispatch(setHiredStatus(1, 'Profile has been hired successfully', 'Hired'))
                    // dispatch(getAllWorkers({
                    //     employer_id:localStorage.getItem('emp_id'),
                    //     status_code : "3",
                    //     filter:0,
                    //     industry_type:null,
                    //     job_position:null,
                    //     page_no:0,
                    //     limit:15
                    // }))
                    history.push('/hire-staff')
                    // dispatch(getShortlistedEmployees(localStorage.getItem('emp_id')))
                } else {
                   
                    dispatch(setHiredStatus(2, response.message))
                }
            })
            .catch((err) => {
                dispatch(setHiredStatus(2, 'Please Try after some time'))
            });
        };
    };



    export const declineEmployee = (data) => {
    // let convertData = {
    //     'application_id':data.id,
    //     'status_code':'7'
    // }
    // let sendData = JSON.stringify(convertData)
    let formData = new URLSearchParams();    //formdata object
    formData.append("application_id",data.id)
    formData.append("status_code",7)
    
    return (dispatch) => {
        // dispatch(setSuccess(3, 'Shortlisting...Please wait a moment'))
        return fetch(config.declineEmployee, {
            method: "post",
            headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                // console.log(response, 'response')
                dispatch(setSuccess(1, 'Profile has been declined successfully'))
  
            } else {
                // alert(response.message)
                dispatch(setSuccess(2, response.message))
            }
        })
        .catch((err) => {
            dispatch(setSuccess(2, err))
        });
    };
  };
  
  export const bookMark = (data) => {
    let convertData = {
        'application_id':data.application_id,
        'bookmarked':data.bookmarked
    }
    let sendData = JSON.stringify(convertData)
    
    return (dispatch) => {
        // dispatch(setSuccess(3, 'Please wait a moment'))
        return fetch(config.bookmark, {
            method: "post",
            headers: {
            "Content-type": "application/json; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:sendData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                // console.log(response, 'response')
                
                if (data.bookmarked === '0'){
                    dispatch(setSuccess(1, 'Removed from bookmarks'))
                } else {
                    dispatch(setSuccess(1, response.message))
                }
                let employerId = localStorage.emp_id ? localStorage.getItem('emp_id') :''
                if (data.api_call === 1) {
                    dispatch(getAllEmployees({
                        employer_id:employerId,
                        filter:0,
                        position:null,
                        location:null, 
                        experience: null,
                        search_term: null,
                        status_code: 1
                    }))
                } else {
                    // dispatch(getShortlistedEmployees(employerId))
                }
                
            } else {
                // alert(response.message)
                dispatch(setSuccess(2, response.message))
            }
        })
        .catch((err) => {
            dispatch(setSuccess(2, "Please try again later"))
        });
    };
};

export const scheduleInterview = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",data.employer_id)
    formData.append("employee_id",data.employee_id)
    formData.append("status_code",data.status_code)
    formData.append("application_id",data.application_id)
    formData.append("interview_date",data.interview_date)
    formData.append("start_time",data.start_time)
    formData.append("end_time",data.end_time)
    formData.append("interview_method",data.interview_method)
    formData.append("interview_details",data.interview_details)
    formData.append("job_id",data.job_id)
    formData.append("request",data.request)

    return (dispatch) => {
        dispatch(setBtnLoading(true))
        return fetch(config.scheduleInterview, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            
            if (response.status == 1) { 
                dispatch(setSuccess(1, 'Interview Scheduled successfully', 'Scheduled'))
                // dispatch(setScheduleInterview(response.data))
                dispatch(getAllEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:0,
                    position:null,
                    location:null,
                    experience:null,
                    industry_type : null,
                    page_no:0,
                    limit:15
                }))
                dispatch(getAllUnappliedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:0,
                    position:null,
                    location:null,
                    search_term : null,
                    industry_type : null,
                    experience:null,
                    lat:'null',
                    lon:'null',
                    page_no:0,
                    limit:15
                }, false))
                dispatch(setShowModel({
                    employee_id :'',
                    application_id : "null",
                    show: false,
                    job_id : null,
                    show_status: '',
                    request:''
                }))
                dispatch(getSchedules({
                    employer_id:localStorage.getItem('emp_id'),
                    status_code : 8,
                    filter:0,
                    industry_type:null,
                    job_position:null,
                    page_no:0,
                    limit:15,
                    filter_by:null,
                    interview_date:null
                }))
               
                dispatch(getAllWorkers({
                    employer_id:localStorage.getItem('emp_id'),
                    status_code : "3",
                    filter:0,
                    industry_type:null,
                    job_position:null,
                    page_no:0,
                    limit:15
                }))
        
                dispatch(getShortlistedEmployees({
                    employer_id:localStorage.getItem('emp_id'),
                    filter:"0",
                    industry_type :'null' ,
                    job_position : 'null',
                    page_no:"0",
                    limit : "15",
                    status_code : "2"
                }))
                setTimeout(() => {
                    history.push("/hire-staff")
                }, 2500)
            } else {
                dispatch(setSuccess(2, response.message))
                dispatch(setShowModel({
                    employee_id :'',
                    application_id : "null",
                    show: false,
                    job_id : null,
                    show_status: '',
                    request:''
                }))
            }
            dispatch(setBtnLoading(false))
        })
        .catch((e) => {
            dispatch(setBtnLoading(false))
            dispatch(setSuccess(2, 'Please try again later'))
            // console.log(e);
        });
    };
};

export const viewScheduledProfile = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("application_id",18)
    formData.append("status_code",data.status_code)
    
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.viewScheduleProfile, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            // console.log(response, 'viewProfilerespo')
            if (response.status == 1) { 
                dispatch(setSuccess(1, 'Rejected successfully'))
                // setScheduledProfile({
                //      employer_id,
                //     status_code
                // })
               
            } else {
                dispatch(setSuccess(2, response.message))  
            }
            dispatch(setLoading(false))
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setSuccess(2, 'Please try again later'))
            // console.log(e);
        });
    };
};

export const rejectCandidate = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("application_id",data.application_id)
    formData.append("status_code",data.status_code)
    
    return (dispatch) => {
        dispatch(setBtnLoading(true))
        return fetch(config.rejectCandidate, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            
            if (response.status == 1) { 
                dispatch(setSuccess(1, 'Rejected successfully'))
                let employerId = localStorage.emp_id ? localStorage.getItem('emp_id') :''
                dispatch(getAllEmployees({
                    employer_id:employerId,
                    filter:0,
                    position:null,
                    location:null, 
                    experience: null,
                    search_term: null,
                    industry_type : null,
                    status_code: 1
                }))
           
                dispatch(getShortlistedEmployees({
                    employer_id:employerId,
                    filter:'0',
                    industry_type :'null' ,
                    job_position : 'null',
                    page_no:'0',
                    limit : '15',
                    status_code : '2'
                }))
                dispatch(getSchedules({
                    employer_id:employerId,
                    status_code : 8,
                    filter:0,
                    filter_by:null,
                    industry_type:null,
                    job_position:null,
                    page_no:0,
                    limit:15,
                    interview_date:null
                }))
                dispatch(getRejected({
                    employer_id:employerId,
                    status_code:9,
                    filter:0,
                    industry_type:null,
                    job_position:null,
                    page_no:0,
                    limit:32
                }))
                setTimeout(() => {
                    history.push("/hire-staff")
                }, 2500)
               
            } else {
                dispatch(setSuccess(2, response.message))  
            }
            dispatch(setBtnLoading(false))
        })
        .catch((e) => {
            dispatch(setBtnLoading(false))
            dispatch(setSuccess(2, 'Please try again later'))
            // console.log(e);
        });
    };
};

export const getCandidateDetails = (data) => {
    let formData = new URLSearchParams ();    //formdata object
    formData.append("job_id", data.job_id)    
    formData.append("employee_id", data.employee_id)    
    return (dispatch) => {
        dispatch(setModalLoading(true))
        return fetch(config.getCandidateDetail, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {    
            if (response.status === 1) { 
                dispatch(setCandidate(response.data))
                // dispatch(setSuccess(1, 'Please pay to view more profiles'))
            } else {
                dispatch(setCandidate([]))
                // dispatch(setSuccess(2, response.message))  
            }
            dispatch(setModalLoading(false))
        })
        .catch((e) => {
            dispatch(setSuccess(2, 'Please try again later'))
            dispatch(setModalLoading(false))
        });
    };
};

export const viewContact = (data) => {
    let formData = new URLSearchParams ();    //formdata object
    formData.append("employee_id",data.employee_id)
    formData.append("employer_id",data.employer_id)
    formData.append("account_type",data.account_type)
    
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.view_contact, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            
            if (response.status === 1) { 
                // if (response.data.available_count === "0") {
                //     dispatch(setSuccess(1, 'This is your last profile, Please pay to view more profiles'))
                //     dispatch(showContact(1))
                // } else if (response.data.available_count === "2") {
                //     dispatch(setSuccess(1, 'You can able to view 2 more profile'))
                //     dispatch(showContact(1))
                // } else if (response.data.available_count === "1") {
                //     // dispatch(setSuccess(1, 'You can able to view 1 more profile'))
                //     dispatch(setSuccess(1, 'Profile is unlocked'))
                //     dispatch(showContact(1))
                // } else {
                    
                    dispatch(setSuccess(1, 'Profile is unlocked'))
                    dispatch(showContact(1))
                    // dispatch(setPaymentModel(true))
                // }
            } else if (response.status === -1) {
                dispatch(setSuccess(1, 'You already viewed this profile'))  
                dispatch(showContact(1))
            } else {
                dispatch(setSuccess(2, response.message))  
                dispatch(showContact(2))
                dispatch(setPaymentModel(true))
            }
        })
        .catch((e) => {
            dispatch(setSuccess(2, 'Please try again later'))
            // console.log(e);
        });
    };
};

export const upgradeAccount = () => {
    let formData = new URLSearchParams ();    //formdata object
    
    formData.append("employer_id", localStorage.getItem('emp_id'))    
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.upgradeAccount, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {    
            if (response.status === 1) { 
                dispatch(setCandidate(response.data))
                localStorage.setItem('account_type_paid', '2')
                dispatch(setSuccess(1, 'You have upgraded your account'))
                setTimeout(function(){
                    window.location.reload()
                },2000)
            } else {
                dispatch(setCandidate([]))
                dispatch(setSuccess(2, response.message))  
            }
        })
        .catch((e) => {
            dispatch(setSuccess(2, 'Please try again later'))
            // console.log(e);
        });
    };
};

export const getCreditAmount = () => {
    let formData = new URLSearchParams ();    //formdata object
    
    formData.append("employer_id", localStorage.getItem('emp_id'))    
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.CreditAmount, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        .then((response) => response.json())
        .then((response) => {    
            if (response.status === 1) { 
                dispatch(setAmount(response.data.wallet_balance))
                
            } else {
                dispatch(setAmount())
                dispatch(setSuccess(2, response.message))  
            }
        })
        .catch((e) => {
            dispatch(setSuccess(2, 'Please try again later'))
            // console.log(e);
        });
    };
};


import config from "../Common/Api_Links";
import {setBtnLoading} from '../Employer/Hire'
export const setCurrentWorkers = (data) => ({
    type: "SET_CURRENT_WORKERS",
    data
});
export const setModelSuccess = (data,msg) => {
    return {
        type: 'SET_MODAL_SUCC',
        data,
        msg
    }
}
export const setShow = (data) => {
    return {
        type: 'SET_SHOW',
        data
    }
}

export const setValues = (field, value) => ({
    type:'SET_VALUES',
    field,value
})

export const setLoading = (data) => ({
    type: "SET_LOADING",
    data
});

export const setLateRequest = data => ({
    type : "SET_LATE_REQUESTS",
    data
})

export const setLoginReport = (data) => ({
    type: "SET_LOGIN_REPORT",
    data
})

export const setSuccess = (val, data) => ({
    type: "SHOW_RESPONSE_MSG",
    val,
    data
});

export const viewWorkerDetail = (data) => ({
    type : "EDIT_WORKER",
    data
});

export const handelModel = data => ({
    type: 'HANDLE_MODEL',
    data
})

export const setRequestModal = data => ({
    type:'EXTEND_REQUEST_MODAL',
    data
})

export const setData = data => ({
    type: 'SET_DATA',
    data
})

export const getWorkers = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("employer_id",data.employer_id)
    formData.append("filter_by",data.filter_by)
    formData.append("filter",data.filter)
    formData.append("filter_term",data.filter_term)
    // formData.append("page_no",0)
    // formData.append("limit",10)
    // formData.append("filter_term",data.filter_term)
    // formData.append("filter_term",data.filter_term)
    
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.list_workers, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            if (response.status == 1) {
                dispatch(setLoading(false))
                response.data.map((i,k) => {
                    if (i.hours_worked !== '' && i.hours_worked !== null) {
                        let worked_hrs = i.hours_worked.split('.')[1]
                        if (worked_hrs != '00' && worked_hrs !== undefined) {
                            let convert =  0+'.'+worked_hrs
                            let newWorkedHrs = Number(convert)*60
                            i.hours_worked = i.hours_worked.split('.')[0]+'.'+newWorkedHrs
                        } else {
                            i.hours_worked = i.hours_worked.split('.')[0]+'.'+'00'
                        }
                    }
                })
                dispatch(setCurrentWorkers(response.data))
                // console.log(response.data, 'response.data.employerId')
                if (response.data.length > 0) {
                    dispatch(getLoginReport({
                        employee_id :response.data[0].employeeId,
                        job_id : response.data[0].jobId
                    }))
                    dispatch(getRequests({
                        employee_id :response.data[0].employeeId,
                    }))
                    dispatch(setData({
                        employee_id :response.data[0].employeeId,
                        job_id : response.data[0].jobId
                    }))
                }
            // window.location.href = "/employee-dashboard";
            } else {
                dispatch(setLoading(false))
                dispatch(setCurrentWorkers([]))
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setCurrentWorkers([]))
            console.log(e);
        });
    };
};

export const editSalary = (data) => {
    let formData = new URLSearchParams();    //formdata object
    formData.append("work_id", data.worker_id)
    formData.append("employee_id", data.employee_id)
    return (dispatch) => {
        // dispatch(setLoading(true))
        return fetch(config.edit_worker, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            
            if (response.status == 1) {
                // dispatch(setLoading(false))
                dispatch(viewWorkerDetail(response.data))
            // window.location.href = "/employee-dashboard";
            } else {
                // dispatch(setLoading(false))
                dispatch(viewWorkerDetail([]))
            }
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            dispatch(setCurrentWorkers([]))
            console.log(e);
        });
    };
};


export const saveSalary = (data) => {
    
    let formData = new URLSearchParams();    //formdata object
    // formData.append("work_id", data.work_id)
    // formData.append("extra_hours", data.extra_hours)
    // formData.append("currency", data.currency)
    formData.append("from_credits",data.from_credits)
    formData.append('work_id',data.work_id)
    formData.append('start_date',data.start_date)
    formData.append('end_date',data.end_date)
    formData.append('start_time',data.start_time)
    formData.append('end_time',data.end_time)
    formData.append('employer_epf',data.employer_epf)
    formData.append('employer_socso',data.employer_socso)
    formData.append('employer_eis',data.employer_eis)
    formData.append('actual_salary_paid_by_employer',data.actual_salary_paid_by_employer)
    formData.append('total_salary_base_by_employer',data.total_salary_base_by_employer)
    formData.append('employee_epf',data.employee_epf)
    formData.append('employee_eis',data.employee_eis)
    formData.append('employee_socso',data.employee_socso)
    formData.append('reduced_salary_for_employee',data.reduced_salary_for_employee)
    formData.append('fj_admin_fee',data.fj_admin_fee)
    formData.append('number_of_hours',data.number_of_hours)
    formData.append('number_of_days',data.number_of_days)
    formData.append('currency',data.currency)
    formData.append('amount',data.amount)
    formData.append('extend_current_day',data.extend_current_day)
        
    return (dispatch) => {
        dispatch(setLoading(true))
        return fetch(config.save_worker, {
        method: "post",
        headers: {
            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
        },
        body:formData
        })
        
        .then((response) => response.json())
        .then((response) => {
            
            if (response.status == 1) {
                dispatch(setSuccess(1, 'Payment Sent to Admin'))
                dispatch(setLoading(false))
                dispatch(handelModel(false))
                // setTimeout(function(){
                //     window.location.reload();
                // }, 2000)
                
            } else {
                dispatch(setSuccess(2, response.message))
                dispatch(setLoading(false))
                dispatch(handelModel(false))
                // setTimeout(function(){
                //     window.location.reload();
                // }, 2000)
            }
        })
        .catch((e) => {
            dispatch(setLoading(false))
            dispatch(setSuccess(2, 'Please Try again later'))
            console.log(e);
        });
    };
}

export const getLoginReport = (data) => {
    // console.log(data, 'data')
    let formData = new URLSearchParams();
    // formData.append('employee_id',10)
    // formData.append('job_id',31)
    formData.append('employee_id',data.employee_id)
    formData.append('job_id',data.job_id)
    return (dispatch) => {
        return fetch(config.get_login_report, {
            method:'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body : formData
        })
        .then((res) => res.json())
        .then((res) => {
            if (res.status === 1) {
                
                res.data.jobDetails.job_location = 
                res.data.jobDetails.employer.company_name + ', ' +
                res.data.jobDetails.job_location
                let sheet = []
                res.data.loginDetails &&
                res.data.loginDetails.length > 0 &&
                res.data.loginDetails.map((i,k) => {
                    if (i.total_working_hours !== '' && i.total_hours_worked !== ''
                    && i.total_working_hours !== null && i.total_hours_worked !== null
                    ) {
                        let worked_hrs = i.total_hours_worked.split('.')[1]
                        let working_hrs = i.total_working_hours.split('.')[1]
                        
                        if (worked_hrs != '00') {
                            let convert =  0+'.'+worked_hrs
                            
                            let newWorkedHrs = Number(convert)*60
                            i.total_hours_worked = i.total_hours_worked.split('.')[0]+'.'+newWorkedHrs
                        }
                        if (working_hrs != '00') {
                            let convert =  0+'.'+working_hrs
                            let newWorkingHrs = Number(convert)*60
                            i.total_working_hours = i.total_working_hours.split('.')[0]+'.'+newWorkingHrs
                        }

                    } 
                    let needed_objects = {
                        'Date':i.login_date,
                        'Log In Time':i.actual_start_time,
                        'Log Out Time':i.actual_end_time,
                        'Employer Epf':i.worker_salary_reduction && i.worker_salary_reduction.employer_epf,
                        'Employer Socso':i.worker_salary_reduction && i.worker_salary_reduction.employer_socso,
                        'Employer Eis':i.worker_salary_reduction && i.worker_salary_reduction.employer_eis,
                        'Employee Epf':i.worker_salary_reduction && i.worker_salary_reduction.employee_epf,
                        'Employee Socso':i.worker_salary_reduction && i.worker_salary_reduction.employee_socso,
                        'Employee Eis':i.worker_salary_reduction && i.worker_salary_reduction.employee_eis,
                        'Working Hours':i.worker_salary_reduction && i.worker_salary_reduction.working_hours,
                        'Worked Hours':i.worker_salary_reduction && i.worker_salary_reduction.hours_worked,
                        'Total Salary':i.worker_salary_reduction && i.worker_salary_reduction.total_salary,
                        'Earned Salary':i.worker_salary_reduction && i.worker_salary_reduction.earned_salary    
                    }
                    sheet.push(needed_objects)    
                // res.data.loginDetails[k]['attendance'] = needed_objects
                })
                
                res.data.sheet = sheet
                dispatch(setLoginReport(res.data))
                // console.log(res, 're45')
            } else {
                dispatch(setLoginReport([]))
                // console.log(res, 're45')
            }
            
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            // dispatch(setSuccess(2, 'Please Try again later'))
            console.log(e);
        });
        
    }
}
export const getRequests = data => {
    
    let formData = new URLSearchParams()
    // formData.append('employer_id',29)
    formData.append('employee_id',data.employee_id)
    
    formData.append('employer_id',localStorage.getItem('emp_id'))
    return (dispatch) => {
        return fetch(config.list_extension_requests, {
            method : 'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                dispatch(setLateRequest(response.data))
            } else {
                dispatch(setLateRequest([]))
            }
        })
        .catch((err) => {
            console.log(err, 'catch')
        })
    }
}
// export const getLateRequests = (data) => {
//     if (!data.filter) {
//         data.filter = 0
//     } 
//     if (!data.filter_date) {
//         data.filter_date = null
//     }
//     let formData = new URLSearchParams()
//     formData.append('employer_id',localStorage.getItem('emp_id'))
//     formData.append('page_no',0)
//     formData.append('limit',15)
//     formData.append('filter',data.filter)
//     formData.append('filter_date',data.filter_date)

//     return (dispatch) => {
//         return fetch(config.list_requests, {
//             method : 'post',
//             headers : {
//                 "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
//                 Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
//             },
//             body:formData
//         })
//         .then((response) => response.json())
//         .then((response) => {
//             if (response.status === 1) {
//                 dispatch(setLateRequest(response.data))
//             } else {
//                 dispatch(setLateRequest([]))
//             }
//         })
//         .catch((err) => {
//             console.log(err, 'catch')
//         })
//     }
// }

export const rejectRequest = (data) => {
    let formData = new URLSearchParams()
    formData.append('request_id',data.request_id)
    formData.append('employee_id',data.employee_id)
    return (dispatch) => {
        return fetch(config.rejectRequest, {
            method : 'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                dispatch(setSuccess(1, 'Request removed successfully'))
                // dispatch(setLateRequest(response.data))
            } else {
                dispatch(setSuccess(2, response.message))
                // dispatch(setLateRequest([]))
            }
        })
        .catch((err) => {
            dispatch(setSuccess(2, 'Please Try after some time'))
            console.log(err, 'catch')
        })
    }
}

export const completeProject = (data) => {
    let formData = new URLSearchParams()
    formData.append('work_id',data.work_id)
    
    return (dispatch) => {
        return fetch(config.completeJob, {
            method : 'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                // dispatch(setLateRequest(response.data))
                dispatch(setSuccess(1, 'Project status updated to admin'))               
            } else {
                dispatch(setSuccess(2, response.message))
                // dispatch(setLateRequest([]))
            }
        })
        .catch((err) => {
            dispatch(setSuccess(2, 'Please try after some time'))
            console.log(err, 'catch')
        })
    }
}
export const acceptRequest = (data) => {
    
    let formData = new URLSearchParams()
    formData.append('request_id',data.request_id)
    formData.append('employee_id',data.employee_id)
    return (dispatch) => {
        return fetch(config.acceptRequest, {
            method : 'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body:formData
        })
        .then((response) => response.json())
        .then((response) => {
            if (response.status === 1) {
                // dispatch(setLateRequest(response.data))
                dispatch(setSuccess(1, 'Request accepted successfully'))               
            } else {
                dispatch(setSuccess(2, response.message))
                // dispatch(setLateRequest([]))
            }
        })
        .catch((err) => {
            dispatch(setSuccess(2, 'Please try after some time'))
            console.log(err, 'catch')
        })
    }
}

export const sendExtendRequest = data => {
    let formData = new URLSearchParams();
    
    formData.append('employee_id',data.employee_id)
    formData.append('employer_id',data.employer_id)
    formData.append('work_id',data.work_id)
    formData.append('extension_date',data.extension_date)
    formData.append('start_date',data.start_date)
    formData.append('end_date',data.end_date)
    formData.append('start_time',data.start_time)
    formData.append('end_time',data.end_time)
    formData.append('number_of_hours',data.number_of_hours)
    formData.append('amount',data.amount)
    formData.append('extend_current_day',data.extend_current_day)
    
    return (dispatch) => {
        dispatch(setBtnLoading(true))
        return fetch(config.request_to_work_extra_hours, {
            method:'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body : formData
        })
        .then((res) => res.json())
        .then((res) => {
            if (res.status === 1) {
                dispatch(setValues("request_status", 1))
                // console.log(res, 're45')
                dispatch(setBtnLoading(false))
            } else {
                dispatch(setValues("request_status", 2))
                dispatch(setBtnLoading(false))
                // console.log(res, 're45')
            }
            
        })
        .catch((e) => {
            dispatch(setBtnLoading(false))
            dispatch(setValues("request_status", 2))
            console.log(e);
        });
        
    }
}
export const update_employee_login_time = (data) => {
    // console.log(data, 'data')
    let formData = new URLSearchParams();
    formData.append('employee_id',data.employee_id)
    formData.append('job_id',data.job_id)
    return (dispatch) => {
        return fetch(config.update_employee_login_time, {
            method:'post',
            headers : {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                Authorization: "Basic YWRtaW46RmxleGlBZG1pbg==",
            },
            body : formData
        })
        .then((res) => res.json())
        .then((res) => {
            if (res.status === 1) {
                
                // console.log(res, 're45')
            } else {
                
                // console.log(res, 're45')
            }
            
        })
        .catch((e) => {
            // dispatch(setLoading(false))
            // dispatch(setSuccess(2, 'Please Try again later'))
            console.log(e);
        });
        
    }
}
import config from '../Common/Api_Links'

// export const setExtraSearchEmployeeLists = (field,data) => ({
//     type: 'UPDATE_FIELDS',
//     field,data,
// });

export const setSearchEmployeeFilter = (field,data,) => ({
    type : "SET_SEARCH_EMP_FILTER",
    field,data,
})
// export const getHome = () => {
//     let formData = new URLSearchParams();    //formdata object
    
//     formData.append('user_id', user_id);
//     return dispatch => {
//         dispatch(setDashboard([]))
//         return fetch(config.HomePage, {
//             method: 'GET',
//             body: formData,
//             headers: {
//                 "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
//                 "authorization": "Basic YWRtaW46RmxleGlBZG1pbg=="
//             }
//         })
//             .then(response => {
//                 if (response.status === 200) {
//                     return response.json();

//                 }
//             })
//             .then(responseData => {
             
//                 if (responseData) {

//                     dispatch(setJobs(responseData.result))
//                     dispatch(setDashboard(responseData.result[0].dashboard))
//                     dispatch(setTestimonals(responseData.result[0].testimonials))
//                 } else {
//                     dispatch(setJobs([]))
//                     dispatch(setDashboard([]))
//                     dispatch(setTestimonals([]))
//                 }
//             })


//     };
// };

  


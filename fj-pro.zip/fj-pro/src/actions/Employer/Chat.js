import config from "../Common/Api_Links";

export const setSuccess = (val, data) => ({
    type: "SHOW_RESPONSE_MSG",
    val,
    data
});

export const setProfileInfo = (data) => ({    
    
    type: "SET_PROFILE_INFO",
    data : data
});

export const messageStatus = (data) => (
    {    
    type: "SET_SEND_MSG_STATUS",
    data
});

export const setChatData = (data) => ({    
    type: "SET_CHAT_MSG",
    data : data
});

export const setChatRoomId = (data) => ({
    type: 'SET_CHAT_ROOM',
    data: data
})

export const updateNewMegs = (data) => ({
    type: 'UPDATE_MSG',
    data:data
})
  
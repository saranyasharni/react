import React, {Component} from 'react'

class CompanyDetails extends Component {
	render() {
    
    return(
      <div>
      <div className="form-group">
        <label htmlFor="file">Upload Company Logo</label>
        <input
          className="form-control"
          id="file"
          name="file"
          type="file"
        />
      </div>
      <div className="form-group">
        <label htmlFor="companyname">Company Name</label>
        <input
          className="form-control"
          name="companyname"
          type="text"
          value={this.props.companyname}
          onChange={this.props.handleChange}
        />
      </div>
    
      <div className="form-group">
        <label htmlFor="emailid">Email Id</label>
        <input
          className="form-control"
          id="emailid"
          name="emailid"
          type="text"
          value={this.props.emailid}
          onChange={this.props.handleChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="jobtitle">Job Title</label>
        <input
          className="form-control"
          id="jobtitle"
          name="jobtitle"
          type="text"
          value={this.props.jobtitle}
          onChange={this.props.handleChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="exp">Years of Experience</label>
        <input
          className="form-control"
          id="exp"
          name="exp"
          type="text"
          value={this.props.expeience}
          onChange={this.props.handleChange}
        />
      </div>
      <div className="form-group">
        <input
          className="form-control"
          id="exp"
          name="exp"
          type="checkbox"
          value={this.props.expeience}
          onChange={this.props.handleChange}
        />
        <label htmlFor="exp">I accept the terms and conditions</label>
      </div>
      <button>back </button>
      <button>send OTP</button>
      </div>
    );
  }
}
export default CompanyDetails;
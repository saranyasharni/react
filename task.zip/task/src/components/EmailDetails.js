import React from 'react'
import OtpInput from 'react-otp-input';

export default function EmailDetails(props) {
	return (
	    <React.Fragment>
    <div className="form-group">
      <label htmlFor="password">Enter Your Code:</label>
         <OtpInput
          
          numInputs={6}
          separator={<span>-</span>}
        />
    </div>
    <button className="btn btn-success btn-block">Back</button>
    <button className="btn btn-success btn-block">Verify</button>
    </React.Fragment>
    );
}


import React, {Component} from 'react'
import Dropdown from 'react-dropdown';
import 'react-dropdown/style.css';
import 'react-flags-select/css/react-flags-select.css';
import {locations} from './Locations.jsx'
import ReactFlagsSelect from 'react-flags-select';

class PersonalForm extends Component {
	render() {
		const options = [
  'one', 'two', 'three'
];
const defaultOption = options[0];
	    return(
	    <div className= "container">
	    <div className="form-group">
        <label htmlFor="name">Full Name</label>
        <input
          className="form-control"
          name="name"
          type="text"
          value={this.props.name}
          onChange={this.props.handleChange}
        />
      	</div>
	    <div className="form-group">
	      	<label htmlFor="gender">Gender:</label>
	        <label className="radio-inline">
	        <input 
	        	type="radio"
	        	value="male"  
	        	onChange = {this.props.handleRadio}
	        	checked={this.props.gender === "male"}
	        	/>
	        	Male 
	        </label>
			<label className="radio-inline">
			<input 
				type="radio" 
				value="female" 
				onChange = {this.props.handleRadio}
				checked={this.props.gender === "female"}/>
				Female
			</label>
			<label className="radio-inline">
			<input 
				type="radio"
				value="others" 
				onChange = {this.props.handleRadio}
				checked={this.props.gender === "others"}/>
				Others
			</label>
	      	</div>
	      	<div className="form-group">
	      	<label htmlFor="gender">Country:</label>
	      	 <ReactFlagsSelect
		    defaultCountry="IN"
		    onSelect={this.onSelectFlag} 
		    />
    		</div>
    		<div className="form-group">
	      	<label htmlFor="gender">State:</label>
	      	 <Dropdown
	      	  
	      	 options={options} 
	      	 onChange={this._onSelect} 
	      	 value={defaultOption} 
	      	 placeholder="Select an option"
	      	  />;
    		</div>
	      	<div className="form-group">
	      	<label htmlFor="number">PhoneNumber:</label>
		       	<input 
	            type= "number" 
	            name = "phone"
	            onChange={this.props.handleChange} 
	            className="form-control"
	            value = {this.props.phone} 
	            id="number"/>
	      	</div>

	      	<div className="form-group">
	        	<button type="submit" className="btn btn-default" onClick={this.props.changeNext}>Next</button>
	      	</div>
	      	</div>
	    )
		}
	}
export default PersonalForm;
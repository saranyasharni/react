import React from 'react'

export const locations = {
		country :
			[
			'india',
			'new-york',
			'pakistan',
			'US'
			],
		state: 
			[
			'lkj',
			'jhjkh',
			'kjk'
			]	

	}
	

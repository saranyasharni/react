import React, {Component} from 'react'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import PersonalForm from './components/PersonalForm'
import CompanyDetails from './components/CompanyDetails'
import EmailDetails from './components/EmailDetails'

class App extends Component {
  constructor() {
    super();
    this.state = 
      { 
        tabIndex: 0,
        name: "",
        gender: '',
        country: '',
        state: '',
        phone: '+91',
        companyname : "",
      };
      this.handleChange = this.handleChange.bind(this);
      this.handleRadio = this.handleRadio.bind(this);
      this.handleNext = this.handleNext.bind(this);
  }

  handleNext() {
    let tabVal = this.state.tabIndex;
    this.setState({ 
      tabIndex: tabVal+1
    }); 
  }

  handleChange(event) {
    event.preventDefault();
    console.log(event.target.name);
    const {name, value}  = event.target;

    this.setState({ 
      [name]: value
    });
  }

  handleRadio(event) {
    this.setState({ 
      gender: event.target.value
    });
   }    
  
  
  render() {
    return (
      <Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex })}>
        <TabList>
          <Tab>1 Personal Details</Tab>
          <Tab>2 Company Details</Tab>
          <Tab>3 Email Verification</Tab>
        </TabList>
        <TabPanel>
          <PersonalForm
            name = {this.state.name}
            gender = {this.state.gender}
            phone = {this.state.phone}
            handleChange = {this.handleChange}
            changeNext = {this.handleNext}
            handleRadio = {this.handleRadio}
          />
        </TabPanel>
        <TabPanel>
        <CompanyDetails
        
        handleChange = {this.handleChange}
        companyname = {this.state.companyname}
      />
        </TabPanel>
        <TabPanel>
          <EmailDetails/>
        </TabPanel>
      </Tabs>
    );
  }
}

export default App;
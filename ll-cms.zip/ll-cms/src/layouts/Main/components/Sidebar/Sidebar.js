import React from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/styles';
import {  Drawer } from '@material-ui/core';
import DashboardIcon from '@material-ui/icons/Dashboard';
import PeopleIcon from '@material-ui/icons/People';
import CategoryIcon from '@material-ui/icons/Category';
import WorkIcon from '@material-ui/icons/Work';
import AboutIcon from '@material-ui/icons/Description';
import WhatsNewIcon from '@material-ui/icons/NewReleases';
import HelpCenterIcon from '@material-ui/icons/ContactSupport';
import ContributionIcon from '@material-ui/icons/Toc';
import CardMembershipIcon from '@material-ui/icons/CardMembership';
import InputIcon from '@material-ui/icons/Input';
import { SidebarNav } from './components';

const useStyles = makeStyles(theme => ({
  drawer: {
    width: 240,
    [theme.breakpoints.up('lg')]: {
      marginTop: 64,
      height: 'calc(100% - 64px)'
    }
  },
  root: {
    backgroundColor: theme.palette.white,
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    padding: theme.spacing(2)
  },
  divider: {
    margin: theme.spacing(2, 0)
  },
  nav: {
    marginBottom: theme.spacing(2)
  }
}));

const Sidebar = props => {
  const { open, variant, onClose, className, ...rest } = props;

  const classes = useStyles();

  const pages = [
    {
      title: 'Dashboard',
      href: '/dashboard',
      icon: <DashboardIcon />
    },
    {
      title: 'Users',
      href: '/users',
      icon: <PeopleIcon />
    },
    {
      title: 'Categories',
      href: '/categories',
      icon: <CategoryIcon />
    },
    {
      title: 'SubCategories',
      href: '/subcategories',
      icon: <CategoryIcon />
    },
    {
      title: 'Jobs',
      href: '/jobs',
      icon: <WorkIcon />
    },
    {
      title: 'AboutUs',
      href: '/aboutus',
      icon: <AboutIcon />
    },
    {
      title: `What's New`,
      href: '/whatsnew',
      icon: <WhatsNewIcon />
    },
    // {
    //   title: `plans`,
    //   href: '/plans',
    //   icon: <CardMembershipIcon />
    // },
    {
      title: 'Help Center',
      href: '/helpcenter',
      icon: <HelpCenterIcon />
    },
    {
      title: 'Contribution',
      href: '/contribution',
      icon: <ContributionIcon />
    },
    {
      title: 'Applied Jobs',
      href: '/applied-jobs',
      icon: <ContributionIcon />
    },
    {
      title: 'Advertise with us',
      href: '/advertise-with-us',
      icon: <ContributionIcon />
    },
    {
      title: 'Subscribers',
      href: '/subscribers-list',
      icon: <ContributionIcon />
    },
    {
      title: 'Logout',
      href: '/sign-in',
      icon: <InputIcon />
    },
   
  ];

  return (
    <Drawer
      anchor="left"
      classes={{ paper: classes.drawer }}
      onClose={onClose}
      open={open}
      variant={variant}
    >
      <div
        {...rest}
        className={clsx(classes.root, className)}
      >
        {/* <Profile /> */}
       ` {/* <Divider className={classes.divider} />` */}
        <SidebarNav
          className={classes.nav}
          pages={pages}
          
        />
        {/* <UpgradePlan /> */}
      </div>
    </Drawer>
  );
};

Sidebar.propTypes = {
  className: PropTypes.string,
  onClose: PropTypes.func,
  open: PropTypes.bool.isRequired,
  variant: PropTypes.string.isRequired
};

export default Sidebar;

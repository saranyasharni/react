import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/styles';
import { AppBar, Toolbar } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    boxShadow: 'none',
    backgroundColor:"black"
  },
  logoPng:{
    height:"40px",
    width:"40px"
  },
  headerTitle:{
    fontSize:"20px",
    textTransform:"uppercase",
    fontWeight:"blod",
    marginLeft:"10px",
    color:theme.palette.warning.main,
    fontFamily:"Robot,sans-serif"
  }
}));

const Topbar = props => {
  const { className, ...rest } = props;

  const classes = useStyles();

  return (
    <AppBar
      {...rest}
      className={clsx(classes.root, className)}
    
      position="fixed"
    >
      <Toolbar>
        <RouterLink to="/">
          <img
            alt="Logo"
            className={classes.logoPng}
            src="/images/logos/logo.png"
          />
        </RouterLink>
        <div className={classes.headerTitle}>Admin Dashboard</div>
      </Toolbar>
    </AppBar>
  );
};

Topbar.propTypes = {
  className: PropTypes.string
};

export default Topbar;

import React, { useState } from 'react';
import { makeStyles } from '@material-ui/styles';
import {Typography,Backdrop,
    CircularProgress,Snackbar} from '@material-ui/core';
import MuiAlert from '@material-ui/lab/Alert';
import {connect} from "react-redux";
import {config} from "../../redux/actions/API/Services.js";
import * as actions from "../../redux/actions/Categories"
import { useEffect } from 'react';
import jQuery from 'jquery';

const useStyles = makeStyles((theme) => ({
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    },
}));

function SubCategoryList(props) {
    const [category, setCategory] = useState([]);
    const [categoryId, setCategoryId] = useState(null);
    const [subcategory, setSubCategory] = useState([]);
    const [open,setOpen] = useState(false);
    
    useEffect(() => {
        var requestOptions = {
            method: "POST",
            redirect: "follow"
        };
        fetch(config.view_category, requestOptions)
            .then(res => res.json())
            .then(data => {
                if (data.status === 1) {
                    setCategory(data.data)
                }
            })
    }, [])
    
    function handleChange (event) {
        var id = event.target.value;
        setCategoryId(id);
        fetch (config.subcategory + `/${id}`)
        .then(res => res.json())
        .then(data => {
            setSubCategory(data.Events)
        })
        props.setSubCategoryList(id)
    }

    function saveSubCategory(e) {
        var subCategories = [];
        jQuery('.sub_cat_check').each(function (item) {
            if (jQuery(this).is(":checked")) {
                subCategories.push({ 
                    category_id: categoryId,
                    id: jQuery(this).data('id'),
                    name: jQuery(this).attr('name'),
                    image : jQuery(this).attr('img')
                });
            }
            return;
        })
       props.saveSubCategory(subCategories, categoryId)
    }   
 
    useEffect(() => {
        console.log(props, 'upda')
        if (props.updateMessage !== "") {
            setOpen(true)
        } else {
            setOpen(false)
        }
    }, [props])

    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }

    const handleAlertClose= (event,reason)=>{
        setOpen(false);
    }

    const classes = useStyles();
    return (
    <>
      <Backdrop className={classes.backdrop} open={props.loading} >
            <CircularProgress color="inherit" />
        </Backdrop>
    <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
        <Alert onClose={handleAlertClose} severity={props.set_success?"success":"error"}>
            {props.updateMessage}
        </Alert>
    </Snackbar>
    <div className="category-right">
        <div className="category-head mt-10">
            <span className="title">List of Sub Categories</span>
            <button 
            className="btn btn-primary"
            onClick = {(e) => {saveSubCategory(e)}}
            >
            Save
            </button>
        </div>
        <div className="category-sec sub-cat">
            <form>
            <div className="row single-row">
                <div className="form-group">
                <label>Category Name</label>
                <select 
                    onChange = {(e) => {handleChange(e)}}
                    className="form-control select-sub"
                >
                <option> Select Subcategory </option>
                {
                    category.map(option => 
                    <option 
                        key = {option.id} 
                        value = {option.id} 
                    >
                        {option.name}
                    </option>
                    ) 
                }
                </select>
                </div>
            </div>
            <div className="row multi-col">
                {subcategory && subcategory.length> 0? subcategory.map(item => {
                    var val = !props.subcategoryList? "" : props.subcategoryList.filter(Category=> Category.id === item.id) 
                    //console.log(val, 'val')
                    return (  
                    <>
                    <div className="form-group" key={item.id} >
                    <label className="custom-checkbox" key={item.id} >
                        <input 
                        key = {item.id}
                        data-id = {item.id}
                        className = "sub_cat_check"
                        type="checkbox" 
                        name={item.name}
                        img = {item.img_url}
                        defaultChecked={val[0] && val[0].id ? 'checked' : ''} 
                        />
                        {item.name}
                    <span className="checkmark" />
                    </label>
                    </div>
                    </>
                    );   
                }) : 
                <p>please select a category</p>
                } 
            </div>
            </form>
        </div>
    </div>
    </>
  );
};

const mapStateToProps = (state, ownProps) => {
  return {
    updateMessage: state.Categories.updateMessage,
    set_success: state.Categories.set_success,
    subcategoryList: state.Categories.subcategoryList,
    loading: state.Categories.loading
  }
}

const mapDispatchToProps = (dispatch,ownProps) => {
  return {
    saveSubCategory: (data, categoryId) => {
        dispatch(actions.saveSubCategory(data, categoryId));
    },
    setSubCategoryList: (data) => dispatch(actions.viewSubCategory(data))
  }
}
export default connect(mapStateToProps,mapDispatchToProps) (SubCategoryList);

import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import Button from '@material-ui/core/Button'
// import CreateIcon from '@material-ui/icons/Create';
import TextField from '@material-ui/core/TextField'
import TextareaAutosize from '@material-ui/core/TextareaAutosize'
import Typography from  '@material-ui/core/Typography'
import {connect} from "react-redux"
 import * as actions from "../../../redux/actions/AboutUs"
const useStyles = makeStyles((theme) => ({
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    
    // boxShadow: theme.shadows[5],
    padding: theme.spacing(2),
    width:"50vw"
  },
   actions:{
    color:theme.palette.warning.main
  },
  descrInput:{
      fontSize:"18px",
      width:"100%",
      padding:theme.spacing(2),
      fontFamily:"Robot,sans-serif",
      marginBottom:theme.spacing(2)
  },
  editBtn:{
      backgroundColor:theme.palette.warning.main,
      color:"white",
      '&:active':{
          backgroundColor:theme.palette.warning.dark
      },
      '&:hover':{
        backgroundColor:theme.palette.warning.dark

      }
  
  },
  cancelBtn:{
      color:theme.palette.warning.main,
      marginLeft:theme.spacing(2)
  },
  title:{
      fontSize:"18px",
      color:theme.palette.warning.main,
      marginTop:theme.spacing(2),
      marginBottom:theme.spacing(2)
  },
  content:{
    fontSize:"18px",
    color:theme.palette.warning.main,
    marginTop:theme.spacing(2),
    marginBottom:theme.spacing(2)
  },
  titleInput:{
      fontSize:"18px",
      color:"black"
  },
  addbtn:{
    backgroundColor:"black",
    color:"white",
    '&:hover':{
      backgroundColor:"black",
    color:"white",
    }
  }

}));

 function AddContent(props) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const titleD = props.title


  const [state,setState] = React.useState({
    title:"",
    descr:""
  })

  const handleChange=(event)=>{
    setState({...state,[event.target.name]:event.target.value})
    
  }
  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleEdit=()=>{
    let temp = {...props.aboutData}
    
    let newData ={
      page_id:temp._id,
      page_title:"ABOUT US",
      brief_description:temp.brief_description,
      additional_details:[...temp.additional_details.filter(item=>{
      return  item.title !== titleD
      }),state]
    }
    console.log(newData)
   props.updateAboutData(newData)
   handleClose()
  }

  return (
    <div>
     <Button variant="container" onClick={handleOpen} className={classes.addbtn}>Add Content</Button>
     {/* <Button size="medium" onClick={handleOpen}className={classes.actions} startIcon={<CreateIcon />}>Edit </Button> */}

      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        className={classes.modal}
        open={open}
        onClose={handleClose}
        closeAfterTransition
        disableEnforceFocus
        disableAutoFocus
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <div className={classes.paper}>
          <Typography className={classes.title}>
          Title
        </Typography>
          <TextField id="outlined-basic" name="title" color="warning" onChange={handleChange} className={classes.titleInput} variant="outlined" />
          <Typography className={classes.content} >
          Content
        </Typography>
          <TextareaAutosize aria-label="minimum height" name="descr"  onChange={handleChange} rowsMin={7} className={classes.descrInput} placeholder="Minimum 3 rows" />
           <Button size="medium" variant="contained" color="warning"className={classes.editBtn} onClick={handleEdit}>Save</Button>
           <Button size="medium" className={classes.cancelBtn} onClick={handleClose}>cancel</Button>

          </div>
        </Fade>
      </Modal>
    </div>
  );
}
const mapStateToProps=(state,ownProps)=>{
  const {aboutData,loading,error} = state.AboutUs
  return{
    aboutData,
    loading,
    error
  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    // getAboutData:()=>{dispatch(actions.getAboutData())}
    updateAboutData:(data)=>{dispatch(actions.updateAboutData(data))}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(AddContent)
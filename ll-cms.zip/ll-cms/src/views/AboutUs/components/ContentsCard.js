import React,{useState,useEffect} from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import DeleteIcon from '@material-ui/icons/Delete';

// import CreateIcon from '@material-ui/icons/Create';
import ContentEdit from './ContentEdit';
import {connect} from "react-redux"
 import * as actions from "../../../redux/actions/AboutUs"
const useStyles = makeStyles((theme)=>({
    
        root: {
          minWidth: 275,
          marginTop:theme.spacing(2)
        },
        bullet: {
          display: 'inline-block',
          margin: '0 2px',
          transform: 'scale(0.8)',
        },
        title: {
          fontSize: "24px",
          fontWeight:"bold",
          color:"black"
        },
        pos: {
          marginBottom: 12,
          fontSize:"16px"
        },
        actions:{
            color:theme.palette.warning.main
        }
      
}));
function ContentsCard(props) {
    const [items,setItems] = useState([])
    useEffect(()=>{
   setItems(props.content)
    },[props])
    const classes = useStyles();

    const handleDelete=(item)=>{
      let temp = {...props.aboutData}
      let newData ={
        page_id:temp._id,
        page_title:"ABOUT US",
        brief_description:temp.brief_description,
        additional_details:[...temp.additional_details.filter(i=>i.title!==item)]
      }
      console.log(newData)
     props.updateAboutData(newData)
    }
    return (
        <>
           {!items?"":items.map((item,index)=>{
               return(
                   <>
<Card className={classes.root} key={index}>
      <CardContent>
        <Typography className={classes.title}  gutterBottom>
          {item.title}
        </Typography>
        
        <Typography className={classes.pos} color="textSecondary">
          {item.descr}
        </Typography>
        
      </CardContent>
      <CardActions>
          <ContentEdit descr={item.descr} title={item.title} />
            <Button size="medium" onClick={()=>handleDelete(item.title)} className={classes.actions} startIcon={<DeleteIcon />}>Delete </Button>
      </CardActions>
    </Card>
                   </>
               )
           })}
             
        </>
    )
}
const mapStateToProps=(state,ownProps)=>{
  const {aboutData,loading,error} = state.AboutUs
  return{
    aboutData,
    loading,
    error
  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    // getAboutData:()=>{dispatch(actions.getAboutData())}
    updateAboutData:(data)=>{dispatch(actions.updateAboutData(data))}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ContentsCard)

import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
// import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import DescriptionEdit from './DescriptionEdit';
const useStyles = makeStyles((theme)=>({
    
        root: {
          minWidth: 275,
          marginTop:theme.spacing(2)
        },
        
        pos: {
          marginBottom: 12,
          fontSize:"16px"
        }
      
}));
function DescriptionCard(props) {
    const classes = useStyles();
    return (
        <>
             <Card className={classes.root}>
      <CardContent>
        
        
        <Typography className={classes.pos} color="textSecondary">
          {props.descr}
        </Typography>
        
      </CardContent>
      <CardActions>
        {/* <Button size="medium" className={classes.actions}>Edit Description</Button> */}
        <DescriptionEdit value={props.descr}/>
      </CardActions>
    </Card>
        </>
    )
}


export default DescriptionCard

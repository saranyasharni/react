export { default } from './AboutUs';

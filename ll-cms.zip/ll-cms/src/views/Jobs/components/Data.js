export const jobData = [
    {
        title:"Research Developer in Advertising",
        location:"singapore",
        posted_date:"2019-04-20",
        about:`At Hotstar, we have 300 million users and capture close to a billion click stream messages daily. The engineering team at Hotstar is at the center of the action and is responsible for creating unmatched user experience. Our engineers solve real life complex problems and create compelling experiences for our customers. 

        We're looking for a research engineer in advertising who is comfortable working with multiple languages, frameworks, platforms and excited to participate in cutting-edge applied research in machine intelligence and machine learning applications. As a research engineer, you’ll be responsible for formulating industrial problems into research questions and thus performing research to innovate solutions for ads targeting and delivery. If you’re excited to work with a group of friendly and experienced machine learning researchers to build the machine intelligence to support high-performance, high-availability, scalable services, this is likely the team for you.
        
        The pace of our growth is incredible – if you want to tackle hard and interesting problems at scale, and create an impact within an entrepreneurial environment, join us!`,
        key_reponsiblities:[
            "Major contributor of continuous improvements in the quality of the ads targeting and ads delivery",
            "Keep track of both industry and academic research trends in related areas, including but not limited to ad targeting and delivery, machine learning and distributed computation",
            "Participate in ad projects planning with product managers and the team based on data-driven investigation methods and industry trends"
        ],
        qualifications:[
            "Master degree or above. 1+ year experience of practical algorithm design and implementation in ads or machine learning related fields. (Experience in ad server will be a plus)",
            "Solid mathematics, computer and machine learning background.",
            "Solid knowledge and hands-on experiences in big data processing and parallel computing frameworks such as Hadoop and Spark.",
            "Logical thinker with good problem solving and analytical ability to solve real problems",
            "Passion for applied research and new technology, open to interdisciplinary work"
        ]

    },
    {
        title:"Research Developer in Advertising",
        location:"singapore",
        posted_date:"2019-04-20",
        about:`At Hotstar, we have 300 million users and capture close to a billion click stream messages daily. The engineering team at Hotstar is at the center of the action and is responsible for creating unmatched user experience. Our engineers solve real life complex problems and create compelling experiences for our customers. 

        We're looking for a research engineer in advertising who is comfortable working with multiple languages, frameworks, platforms and excited to participate in cutting-edge applied research in machine intelligence and machine learning applications. As a research engineer, you’ll be responsible for formulating industrial problems into research questions and thus performing research to innovate solutions for ads targeting and delivery. If you’re excited to work with a group of friendly and experienced machine learning researchers to build the machine intelligence to support high-performance, high-availability, scalable services, this is likely the team for you.
        
        The pace of our growth is incredible – if you want to tackle hard and interesting problems at scale, and create an impact within an entrepreneurial environment, join us!`,
        key_reponsiblities:[
            "Major contributor of continuous improvements in the quality of the ads targeting and ads delivery",
            "Keep track of both industry and academic research trends in related areas, including but not limited to ad targeting and delivery, machine learning and distributed computation",
            "Participate in ad projects planning with product managers and the team based on data-driven investigation methods and industry trends"
        ],
        qualifications:[
            "Master degree or above. 1+ year experience of practical algorithm design and implementation in ads or machine learning related fields. (Experience in ad server will be a plus)",
            "Solid mathematics, computer and machine learning background.",
            "Solid knowledge and hands-on experiences in big data processing and parallel computing frameworks such as Hadoop and Spark.",
            "Logical thinker with good problem solving and analytical ability to solve real problems",
            "Passion for applied research and new technology, open to interdisciplinary work"
        ]

    }
]
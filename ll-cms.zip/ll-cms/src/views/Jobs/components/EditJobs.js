import React,{useState,useEffect} from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography'
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { makeStyles } from '@material-ui/core/styles';
import { TextareaAutosize } from '@material-ui/core';
import {connect} from 'react-redux';
import * as actions from "../../../redux/actions/Jobs"
const useStyles = makeStyles((theme)=>({
    title:{
        fontSize:theme.typography.pxToRem(20),
        fontWeight:"bold",
        marginBottom:theme.spacing(2),
        marginTop:theme.spacing(2)
    },
    descrInput:{
        fontSize:"18px",
        width:"100%",
        padding:theme.spacing(2),
        fontFamily:"Robot,sans-serif",
        marginBottom:theme.spacing(2)
    },
    btn:{
        color:theme.palette.warning.main
    }
}))
 function EditJobs(props) {
    const classes = useStyles()
  const [open, setOpen] = React.useState(false);
  const [scroll, setScroll] = React.useState('paper');
  const [state,setState] = useState({
    title:props.data.title,
    location:props.data.location,
   about:props.data.about,
   key_reponsiblities:props.data.key_reponsiblities,
   qualifications:props.data.qualifications
  })
  React.useEffect(()=>{
    setState({
  
      title:props.data.title,
      location:props.data.location,
     about:props.data.about,
     key_reponsiblities:props.data.key_reponsiblities,
     qualifications:props.data.qualifications
    
  })
  },[props])
  const handleClickOpen = (scrollType) => () => {
    setOpen(true);
    setScroll(scrollType);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleEdit=()=>{
    
    let newData ={
  title:state.title,
  location:state.location,
  about:state.about,
  key_reponsiblities:state.key_reponsiblities,
  qualifications:state.qualifications,
    job_id:props.data._id,
  posted_date:new Date()
    }
    console.log(newData)
   props.updateJobs(newData)
   handleClose()
  }
  const handleChange=(event)=>{
    setState({...state,[event.target.name]:event.target.value})
    
  }
  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [open]);

  return (
    <div>
      <Button onClick={handleClickOpen('paper')} size="small" color="primary">
              Edit
            </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        scroll={scroll}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
        maxWidth={"sm"}
        fullWidth={true}
      >
        <DialogTitle id="scroll-dialog-title">Edit Job</DialogTitle>
        <DialogContent dividers={scroll === 'paper'}>
          <DialogContentText
            id="scroll-dialog-description"
            ref={descriptionElementRef}
            tabIndex={-1}
          >
              <Typography className={classes.title}>Title</Typography>
              
                <TextField id="outlined-basic" name="title" label="title" onChange={handleChange} variant="outlined" defaultValue={props.data.title}/>
                
  <Typography className={classes.title}>Location</Typography>
  <TextField id="outlined-basic" label="location" name="location" variant="outlined" onChange={handleChange} defaultValue={props.data.location} />
  <Typography className={classes.title}>About the role</Typography>

  <TextareaAutosize aria-label="minimum height"name="about"onChange={handleChange}rowsMin={7} defaultValue={props.data.about}className={classes.descrInput} placeholder="Minimum 3 rows" />
  <Typography className={classes.title}>Key Responsiblities</Typography>
  <TextareaAutosize aria-label="minimum height" name="key_responsiblities"onChange={handleChange} rowsMin={7}  defaultValue={props.data.key_reponsiblities} className={classes.descrInput} placeholder="Minimum 3 rows" />
  <Typography className={classes.title}>Qualifications</Typography>
  <TextareaAutosize aria-label="minimum height" name="qualifications" onChange={handleChange} rowsMin={7} defaultValue={props.data.qualifications} className={classes.descrInput} placeholder="Minimum 3 rows" />
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className={classes.btn}>
            Cancel
          </Button>
          <Button onClick={handleEdit} className={classes.btn}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
const mapStateToProps=(state,ownProps)=>{
  const {jobsData,loading,error} = state.Jobs
  return{
    jobsData,
    loading,
    error
  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    // getAboutData:()=>{dispatch(actions.getAboutData())}
    updateJobs:(data)=>{dispatch(actions.updateJobs(data))}
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(EditJobs)
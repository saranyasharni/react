import React,{useState,useEffect} from 'react'
import { makeStyles } from '@material-ui/core/styles';
import {Typography,Backdrop,
    CircularProgress,Snackbar } from '@material-ui/core'
import JobContent from "./components/JobContent"
import MuiAlert from '@material-ui/lab/Alert';
 import {jobData} from "./components/Data"
import {connect} from "react-redux"
import AddJob from './components/AddJob';
import * as actions from "../../redux/actions/Jobs"
const useStyles = makeStyles((theme)=>({
    root:{
        padding:theme.spacing(3)
    },
    title:{
        fontSize:"30px",
        color:theme.palette.warning.main,
        fontWeight:"bolder",
        marginBottom:theme.spacing(4)
    },
    wrapper:{
        marginBottom:theme.spacing(2)
    },
    flex:{
        display:"flex",
        justifyContent:"space-between"
    },
    addbtn:{
        height:"40px",
        backgroundColor:"black",
        color:"white",
        '&:hover':{
          backgroundColor:"black",
        color:"white",
        }
      }, backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
      },
}))
function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
function Jobs(props) {
    const [jobs,setJobs] = useState([])
    const [open,setOpen] = useState(false)
    useEffect(()=>{
        props.getJobs()
    },[])
    useEffect(()=>{
        if(props.message !== ""){
        setOpen(true)
        }else{
          setOpen(false)
        }
        
        },[props])
        useEffect(()=>{
        console.log(props)
        },[])
    useEffect(()=>{
 setJobs(props.jobsData)
    },[props.jobsData])
    const handleAlertClose=(event,reason)=>{
  
        setOpen(false);
      }
    const classes = useStyles()
    return (
        <>
         <Backdrop className={classes.backdrop} open={props.loading} >
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
        <Alert onClose={handleAlertClose} severity={props.success?"success":"error"}>
         {
             console.log(props.message, 'props.messagejob'),
         props.message}
        </Alert>
      </Snackbar>
        <div className={classes.root}>
            <div className={classes.flex}>
           <Typography className={classes.title}  gutterBottom>
         Jobs
        </Typography>
        {/* <Button variant="container" className={classes.addbtn}>Add Content</Button> */}
        <AddJob  />
        </div>
        {!jobs?"":jobs.map((job,index)=>{
            return(
                <div className={classes.wrapper}>
                 <JobContent jobs={job} />
                </div>
            )
        })}
       
        </div>
        </>
    )
}
const mapStateToProps=(state,ownProps)=>{
    const {jobsData,loading,error,message,success} = state.Jobs
    const {keys,sum}  = state.Dashboard
    return{
        jobsData,  
        loading,
        error,
        message,
        success,
        keys,
        sum
    }
}
const mapDispatchToProps =(dispatch,ownProps)=>{
    return{
        getJobs:()=>{dispatch(actions.getJobs())}
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Jobs)

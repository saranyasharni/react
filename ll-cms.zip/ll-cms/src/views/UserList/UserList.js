import React, { useState,useEffect } from 'react';
import { makeStyles } from '@material-ui/styles';
import MuiAlert from '@material-ui/lab/Alert';
import { UsersToolbar, UsersTable } from './components';
// import mockData from './data';
import {Backdrop,
  CircularProgress,Snackbar } from '@material-ui/core'
import {connect} from "react-redux"
import * as actions from "../../redux/actions/UsersList"
const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3)
  },
  content: {
    marginTop: theme.spacing(2)
  }, backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: '#fff',
  },
}));

const UserList = (props) => {
  const classes = useStyles();
const [users,setUsers] = useState(props.userData);
const [open,setOpen] = useState(false)

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

useEffect(()=>{
props.getUser()
  },[])
useEffect(()=>{
setUsers(props.userData)
},[props.userData])

useEffect(()=>{
  if(props.message !== ""){
  setOpen(true)
  }else{
    setOpen(false)
  }
},[props])

const handleAlertClose=(event,reason)=>{
  setOpen(false);
}
  return (
    <>
    <Backdrop className={classes.backdrop} open={props.loading} >
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
        <Alert onClose={handleAlertClose} severity={props.success?"success":"error"}>
         {props.message}
        </Alert>
      </Snackbar>
    <div className={classes.root}>
      <UsersToolbar />
      <div className={classes.content}>
        <UsersTable users={props.userData} />
      </div>
    </div>
    </>
  );
};
const mapStateToProps=(state,ownProps)=>{
  const {userData,loading,error,message,success} = state.UserList
  return{
      userData,  
      loading,
      error,
      message,
      success
  }
}
const mapDispatchToProps =(dispatch,ownProps)=>{
  return{
    getUser:()=>{dispatch(actions.getUser())}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(UserList);

import React,{useState,useEffect} from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography'
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { makeStyles } from '@material-ui/core/styles';
 import { IconButton,MenuItem } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import CreateIcon from '@material-ui/icons/Create';
import {connect} from 'react-redux';
import * as actions from "../../../../redux/actions/UsersList"
const useStyles = makeStyles((theme)=>({
    title:{
        fontSize:theme.typography.pxToRem(20),
        fontWeight:"bold",
        marginBottom:theme.spacing(2),
        marginTop:theme.spacing(2)
    },
    descrInput:{
        fontSize:"18px",
        width:"100%",
        padding:theme.spacing(2),
        fontFamily:"Robot,sans-serif",
        marginBottom:theme.spacing(2)
    },
    btn:{
        color:theme.palette.warning.main
    },
    formControl: {
        
        minWidth: 180,
      }
}))
 function EditUser(props) {
    const classes = useStyles()
  const [open, setOpen] = React.useState(false);
  const [scroll, setScroll] = React.useState('paper');
  const [state,setState] = useState({
    name:props.user.name,
    email:props.user.email,
    mobile_no:props.user.contact_no,
    plan_name:props.user.plan_name,
    login_type:props.user.login_type,
    user_active:props.user.user_active
  })
  React.useEffect(()=>{
    setState({
    name:props.user.name,
    email:props.user.email,
    mobile_no:props.user.contact_no,
    plan_name:props.user.plan_name,
    login_type:props.user.login_type,
    user_active:props.user.user_active
  })
  console.log(props,"user edit")
  },[props])
  const handleClickOpen = (scrollType) => () => {
    setOpen(true);
    setScroll(scrollType);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleEdit=()=>{
    
   props.updateUser(state)
   handleClose()
  }
  const handleChange=(event)=>{
    setState({...state,[event.target.name]:event.target.value})
    
  }
  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [open]);

  return (
    <div>
  
          <IconButton aria-label="edit" onClick={handleClickOpen('paper')}>
            <CreateIcon />
    </IconButton>
      <Dialog
        open={open}
        onClose={handleClose}
        scroll={scroll}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
      >
        <DialogTitle id="scroll-dialog-title">Edit User</DialogTitle>
        <DialogContent dividers={scroll === 'paper'}>
          <DialogContentText
            id="scroll-dialog-description"
            ref={descriptionElementRef}
            tabIndex={-1}
          >
              <Typography className={classes.title}>Name</Typography>
              <TextField id="outlined-basic" name="name" label="name" onChange={handleChange} variant="outlined" defaultValue={props.user.name}/>
              <Typography className={classes.title}>Contact Number</Typography>
              <TextField id="outlined-basic" name="mobile_no" label="contact" onChange={handleChange} variant="outlined" defaultValue={props.user.contact_no}/>
                 <Typography className={classes.title}>Plan Name</Typography>
                 <FormControl variant="outlined" className={classes.formControl}>
        <InputLabel id="demo-simple-select-outlined-label">plan name</InputLabel>
        <Select
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          value={state.plan_name}
          onChange={handleChange}
          label="plan name"
          name="plan_name"
        className={classes.plan}
        defaultValue={props.user.plan_name}
        >
          
          <MenuItem value="Personal">Personal</MenuItem>
          <MenuItem value="Student">Student</MenuItem>
          <MenuItem value="Free">Free</MenuItem>
        </Select>
        </FormControl>
                 
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className={classes.btn}>
            Cancel
          </Button>
          <Button onClick={handleEdit} className={classes.btn}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    
    updateUser:(email)=>{dispatch(actions.updateUser(email))}
  }
}

export default connect(null,mapDispatchToProps)(EditUser)
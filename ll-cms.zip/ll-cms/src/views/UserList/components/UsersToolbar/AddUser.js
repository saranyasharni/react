import React,{useState} from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography'
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { makeStyles } from '@material-ui/core/styles';
 import { MenuItem } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import {connect} from 'react-redux';
import * as actions from "../../../../redux/actions/UsersList"
const useStyles = makeStyles((theme)=>({
    title:{
        fontSize:theme.typography.pxToRem(20),
        fontWeight:"bold",
        marginBottom:theme.spacing(2),
        marginTop:theme.spacing(2)
    },
    descrInput:{
        fontSize:"18px",
        width:"100%",
        padding:theme.spacing(2),
        fontFamily:"Robot,sans-serif",
        marginBottom:theme.spacing(2)
    },
    btn:{
        color:theme.palette.warning.main
    }, 
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
      },
      addUser:{
        backgroundColor:"black",
        color:"white",
        
        '&:hover':{
          backgroundColor:"black",
        color:"white",
        }
      }
}))
 function AddUser(props) {
    const classes = useStyles()
  const [open, setOpen] = React.useState(false);
  const [scroll, setScroll] = React.useState('paper');
  const [state,setState] = useState({
    name:"",
    email:"",
    mobileNumber:"",
    register_type:"",
    login_type:"2",
    password:"password"
  })
  // React.useEffect(()=>{
  //   setState({
  //   name:props.user.name,
  //   email:props.user.email,
  //   contact_no:props.user.contact_no,
  //   plan_name:props.user.plan_name,
  //   login_type:props.user.login_type,
  //   user_active:props.user.user_active
  // })
  // },[props])
  const handleClickOpen = (scrollType) => () => {
    setOpen(true);
    setScroll(scrollType);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleAdd=()=>{
    
   props.addUser(state)
   handleClose()
  }
  const handleChange=(event)=>{
    setState({...state,[event.target.name]:event.target.value})
    
  }
  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [open]);

  return (
    <div>
  
        
    <Button
          className={classes.addUser}
          variant="contained"
          onClick={handleClickOpen('paper')}
        >
          Add user
        </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        scroll={scroll}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
        maxWidth={"sm"}
        fullWidth={true}
      >
        <DialogTitle id="scroll-dialog-title">Add User</DialogTitle>
        <DialogContent dividers={scroll === 'paper'}>
          <DialogContentText
            id="scroll-dialog-description"
            ref={descriptionElementRef}
            tabIndex={-1}
          >
              <Typography className={classes.title}>Name</Typography>
              <TextField id="outlined-basic" name="name" label="name" onChange={handleChange} variant="outlined"/>
              <Typography className={classes.title}>Email</Typography>
              <TextField id="outlined-basic" name="email" label="email" onChange={handleChange} variant="outlined"/>
              <Typography className={classes.title}>Contact Number</Typography>
              <TextField id="outlined-basic" name="mobileNumber" label="Mobile" onChange={handleChange} variant="outlined"/>
                
                 <Typography className={classes.title}>Plan Name</Typography>
                 <FormControl variant="outlined" className={classes.formControl}>
        <InputLabel id="demo-simple-select-outlined-label">Choose Plan</InputLabel>
        <Select
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          value={state.register_type}
          onChange={handleChange}
          label="plan name"
          name="register_type"
        className={classes.plan}
    
        >
          
          <MenuItem value="Personal">Personal</MenuItem>
          <MenuItem value="Student">Student</MenuItem>
          <MenuItem value="Free">Free</MenuItem>
        </Select>
        </FormControl>
                 
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className={classes.btn}>
            Cancel
          </Button>
          <Button onClick={handleAdd} className={classes.btn}>
            Add
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    
    addUser:(state)=>{dispatch(actions.addUser(state))}
  }
}

export default connect(null,mapDispatchToProps)(AddUser)
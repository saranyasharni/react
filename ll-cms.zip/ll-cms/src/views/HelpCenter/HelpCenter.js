import React,{useState,useEffect} from 'react'
import {Typography,Backdrop,
    CircularProgress,Snackbar} from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles';
import MuiAlert from '@material-ui/lab/Alert';
// import {jobData} from "./components/Data"
import {connect} from "react-redux"
import * as actions from "../../redux/actions/HelpCenter"
import ContentSection from './components/ContentSection';
import AddContent from './components/AddContent';

const useStyles = makeStyles((theme) => ({
    root:{
    padding:theme.spacing(3)
    },
    flex:{
        display:"flex",
        justifyContent:"space-between"
    },
    title:{
        fontSize:"30px",
        color:theme.palette.warning.main,
        fontWeight:"bolder",
        marginBottom:theme.spacing(4)
    },
    descr:{
        fontSize:"20px",
        fontWeight:"blod",
        color:"black",
        marginTop:theme.spacing(2)
    },
    wrapper:{
        marginBottom:theme.spacing(2)
    },
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
      },
  }));
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
function HelpCenter(props) {
    const [faqData,setfaqData] = useState(props.faqData)
    const [open,setOpen] = useState(false)
    useEffect(()=>{
        props.getFaq()
    },[])

    useEffect(()=>{
        setfaqData(props.faqData)
        console.log(props.faqData,"from faq")
    },[props])

    useEffect(()=>{
        if(props.message !== ""){
        setOpen(true)
        }else{
            console.log(props.message)
          setOpen(false)
        }
        
        },[props])

        const handleAlertClose=(event,reason)=>{
            setOpen(false);
        }
    const classes = useStyles();
    return (
        <>
        <Backdrop className={classes.backdrop} open={props.loading} >
            <CircularProgress color="inherit" />
        </Backdrop>
        <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
            <Alert onClose={handleAlertClose} severity={props.success?"success":"error"}>
                {props.message}
            </Alert>
        </Snackbar>
        <div className={classes.root}>
            <Typography className={classes.title}  gutterBottom>
                Help Center
            </Typography>
        <div className={classes.flex}>
           <Typography className={classes.title}  gutterBottom>
         FAQ's
        </Typography>
        {/* <Button variant="container" className={classes.addbtn}>Add Content</Button> */}
        <AddContent  />
        </div>
        
        {/* <ContentCard content={contents}/> */}
        {!faqData?"":faqData.map(item=>{
            return(
                <div className={classes.wrapper}>
<ContentSection faqs={item} />
                </div>
            )
        })}
        
        </div>
        </>
    )
}

const mapStateToProps=(state,ownProps)=>{
    const {faqData,loading,error,message,success} = state.HelpCenter
    return{
        faqData,  
        loading,
        error,
        message,
        success
    }
}
const mapDispatchToProps =(dispatch,ownProps)=>{
    return{
        getFaq:()=>{dispatch(actions.getFaq())}
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(HelpCenter)

export const contents = [
    {
        _id:"2345",
        is_show:true,
        question:"What is LiveLive Premium Membership?",
        answer:`This membership gives you access to all our premium titles (including LiveLive titles) which are currently available on the platform as well as the titles which we will be added in the future.

        In addition, you also get access to Unlimited live sports (Cricket, Pro Kabaddi League, ISL, Tennis grand slams, Premier League, Bundesliga, F1 & more), latest Indian movies' digital premieres, LiveLive Originals, popular Disney movies & kids shows (in English & select Indian languages), Hotstar Specials and Star serials before TV.
        
        We offer 2 plans for LiveLive Premium membership. A deeply discounted yearly plan for Rs. 1499 or a monthly plan for Rs. 299. All our subscription plans are non-refundable. Our free content continues to be available for free for all users`
    },
    {
        _id:"2315",
        is_show:true,
        question:"How long is the membership valid?",
        answer:"Your membership is valid as long you don't cancel it. Your membership may only get interrupted in case your payment is disrupted due to credit card expiry or third party payment process failure. If we make any changes in the structure of the membership, we will inform you before we roll out the changes"
    },
    {
        _id:"2325",
        is_show:true,
        question:"What is LiveLive?",
        answer:"LiveLive is an online video streaming service from Disney made exclusively available on LiveLive in Hindi, Tamil, Telugu & English"
    },
   
]
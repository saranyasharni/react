import React, { useState, useEffect } from 'react';
import {config} from "../../redux/actions/API/Services.js";
import { makeStyles } from '@material-ui/styles';
import {Typography,Backdrop,
    CircularProgress,Snackbar} from '@material-ui/core';
import MuiAlert from '@material-ui/lab/Alert';
// import {apiData} from './data';
import {connect} from "react-redux"
import * as actions from "../../redux/actions/Categories"
import jQuery from 'jquery';

const useStyles = makeStyles((theme) => ({
  backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
  },
}));

function CategoryList(props) {
    const [category, setCategory] = useState([]);
    const [open,setOpen] = useState(false);

    function handleCategory(e) {
      var categories = [];
      jQuery('.test').each(function (item) {
        if (jQuery(this).is(":checked")) {
          categories.push({ 
            id: jQuery(this).data('id'),
            name: jQuery(this).attr('name'),
            image: jQuery(this).attr('img')
          });
        }
      })
      props.saveCategory(categories)
    }

    useEffect(() => {
      fetch(config.get_categories)
        .then(res => res.json())
        .then(res => {
          setCategory(res.data)
         
        }).catch(err => {
          
        })
    },[]);

    useEffect(() => {
      props.listingCategories()
    },[]);

    useEffect(() => {
      // console.log(props, 'upda')
      if (props.updateMessage !== "") {
          setOpen(true)
      } else {
          setOpen(false)
      }
  }, [props])

  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

  const handleAlertClose= (event,reason)=>{
    setOpen(false);
  }

  const classes = useStyles();
    return (
    <>
    <Backdrop className={classes.backdrop} open={props.loading} >
      <CircularProgress color="inherit" />
    </Backdrop>
    <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
      <Alert onClose={handleAlertClose} severity={props.set_success?"success":"error"}>
        {props.updateMessage}
      </Alert>
    </Snackbar>
    <div className="category-right">
      <div className="category-head mt-10">
          <span className="title">List of Categories</span>
          <button 
            className="btn btn-primary" 
            type="button" 
            onClick = {(e) => {handleCategory(e)}}
            //style = {{marginLeft : '50rem'}}
          >
            Save
          </button>
      </div>
        
          <div className="category-sec">
          <form>
          <div className = "throwerror" style={{textAlign:"center"}}>
            <p style={{color:"red"}}> {!props.setMessage ? '': props.setMessage}</p>
          </div>
          {!category ? "" :
          category.map(item => { 
          var val = !props.category? "" : props.category.filter(Category=> Category.id === item.id) 
          return (    
            <>
    
            <div className="form-group" key={item.id}>
            <label className="custom-checkbox">
            <input 
              className = "test"
              type = "checkbox" 
              name = {item.name} 
              img = {item.img}
              data-id = {item.id}
              defaultChecked = {val[0] && val[0].id ? 'checked' : ''}
              //ref = {checkBoxVal}
              //onChange = {(e) => {handleCategory(e)}}
            />
            {item.name}
            <span className="checkmark" />
            </label>
            </div>
            </>
          );})
        }
        
        </form>
        </div>
    </div>
    </>
  );
};

const mapStateToProps = (state,ownProps) => {
  return {
    listingCategory: state.Categories.listingCategory,
    category:state.Categories.category,
    updateMessage:state.Categories.updateMessage,
    set_success: state.Categories.set_success,
    loading: state.Categories.loading
  }
}

const mapDispatchToProps = (dispatch,ownProps) => {
  return{
    saveCategory: data => {
      dispatch(actions.setCategory(data));
    },
    // liveListing: () => {
    //   dispatch(actions.liveListingCategory());
    // },
    listingCategories: () => {
      dispatch(actions.catListing())
    }
  }
}
export default connect(mapStateToProps,mapDispatchToProps) (CategoryList);

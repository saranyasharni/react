export { default } from './MonthlyProfit';

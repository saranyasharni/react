import React,{useEffect,useState} from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { Bar } from 'react-chartjs-2';
import { makeStyles } from '@material-ui/styles';
import DateRangePicker from '@wojtekmaj/react-daterange-picker';
import moment from "moment"
import palette from 'theme/palette';

import {
  Card,
  CardHeader,
  CardContent,
  // CardActions,
  Divider,
  // Button,
  FormControl,
  InputLabel,
  Select,
  Button,
  MenuItem
} from '@material-ui/core';
import {connect} from "react-redux"
import * as actions from "../../../../redux/actions/Dashboard"
// import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
// import ArrowRightIcon from '@material-ui/icons/ArrowRight';

import {  options } from './chart';
// import DatePicker from './DatePicker';

const useStyles = makeStyles((theme) => ({
  root: {},
  chartContainer: {
    height: 400,
    position: 'relative'
  },
  actions: {
    justifyContent: 'flex-end'
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120
  },
  flex:{
    display:"flex",
   },
   center:{
    marginTop:"8px"
 },
 updateBtn:{
   height:"38px",
   marginTop:"8px",
   marginLeft:"10px"
 }
   
}));
 
const LatestSales = props => {
  const { className, ...rest } = props;

  const [type, setType] = React.useState('Month');
  
    const [value, onChange] = useState([moment().startOf('month').format('YYYY-MM-DD'), moment().endOf('month').format('YYYY-MM-DD')]);
  const handleChange = (event) => {
    setType(event.target.value);
    
  };
  const handleUpdate =()=>{
    console.log(value, 'value9090')
    if (value && value.length > 0) {
      props.getDatafromDate(value[0],value[1],type)
    }
  }

  const classes = useStyles();
 useEffect(()=>{
  props.getDatafromDate(value[0],value[1],type)

 },[])
 useEffect(()=>{
 console.log(props,"props")
 },[props])
 const data = {
  labels: props.keys,
  datasets: [
    {
      label: 'Total Profit in $',
      backgroundColor: palette.primary.main,
      data: props.sum
    }
  ]
};
  return (
    <Card
      {...rest}
      className={clsx(classes.root, className)}
    >
      <CardHeader
        action={
          <div>
            
        <div className={classes.flex}>
         
              <FormControl variant="outlined" className={`${classes.formControl} month-selector`}>
        <Select
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          value={type}
          onChange={handleChange}
          
        >
          
          <MenuItem value="Month">Month</MenuItem>
          <MenuItem value="Year">Year</MenuItem>
          <MenuItem value="Week">Week</MenuItem>
          <MenuItem value="Day">Day</MenuItem>
        </Select>
      </FormControl>
      <div className={classes.center}>
      <DateRangePicker
        onChange={onChange}
        value={value}
        format="yyyy-MM-dd"
      />
    </div>
        
       <Button className={classes.updateBtn} onClick={handleUpdate} variant="contained" color="primary">Update</Button>
      </div>
      </div>
        }
        title="Revenue Scale"
      />
      <Divider />
      {!props.keys.length ?<div style={{textAlign:"center"}}>No data Found</div>:""}
      <CardContent>
        <div className={classes.chartContainer}>
          <Bar
            data={data}
            options={options}
          />
        </div>
      </CardContent>
      
    </Card>
  );
};

LatestSales.propTypes = {
  className: PropTypes.string
};

const mapStateToProps =(state,ownProps)=>{
  const {sum,keys} = state.Dashboard
  return{
    sum,
    keys
  }
}
const mapDispatchToProps = (dispatch,ownProps)=>{
  return{
    getDatafromDate:(from,to,type)=>{dispatch(actions.getDatafromDate(from,to,type))}

  }
}
export default connect(mapStateToProps,mapDispatchToProps)(LatestSales);

export const chartData = [
    {
        "plan": "premium-family",
        "amount": 20,
        "created_date": "2020-06-06T03:33:00.005Z"
    },
    {
        "plan": "premium-personal",
        "amount": 45,
        "created_date": "2020-06-06T03:33:00.005Z"
    },
    {
        "plan": "premium-family",
        "amount": 20,
        "created_date": "2020-06-07T03:33:00.005Z"
    },
    {
        "plan": "premium-personal",
        "amount": 45,
        "created_date": "2020-06-10T03:33:00.005Z"
    },
    {
        "plan": "premium-family",
        "amount": 20,
        "created_date": "2019-06-13T03:33:00.005Z"
    },
    {
        "plan": "premium-family",
        "amount": 20,
        "created_date": "2019-06-07T03:33:00.005Z"
    },
    {
        "plan": "premium-personal",
        "amount": 45,
        "created_date": "2019-06-10T03:33:00.005Z"
    },
    {
        "plan": "premium-family",
        "amount": 20,
        "created_date": "2019-06-13T03:33:00.005Z"
    }
]

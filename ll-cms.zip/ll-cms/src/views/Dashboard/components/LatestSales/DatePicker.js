import React, { useState } from 'react';
import DateRangePicker from '@wojtekmaj/react-daterange-picker';
import {makeStyles} from '@material-ui/styles'

const useStyles = makeStyles((theme)=>({
    center:{
       marginTop:"8px"
    }
}))
function DatePicker() {
    const classes = useStyles()
    const [value, onChange] = useState([new Date(), new Date()]);
    return (
        <div className={classes.center}>
      <DateRangePicker
        onChange={onChange}
        value={value}
        format="yyyy-MM-dd"
      />
    </div>
    )
}

export default DatePicker

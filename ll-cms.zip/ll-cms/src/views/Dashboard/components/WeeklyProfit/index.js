export { default } from './WeeklyProfit';

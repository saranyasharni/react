export { default } from './LatestProducts';

export { default } from './YearlyProfit';

export { default } from './Typography';

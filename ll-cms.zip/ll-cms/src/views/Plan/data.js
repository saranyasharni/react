export const contents = [
    {
        title:"LiveLive Streaming",
        descr:"LiveLive is a streaming service that allows our members to watch a wide variety of award-winning TV shows, movies, documentaries, and more on thousands of internet-connected devices. With Netflix, you can enjoy unlimited ad-free viewing of our content. There's always something new to discover, and more TV shows and movies are added every month!"
    },
    {
        title:"Live Shows  & Programms",
        descr:"Watch anywhere, anytime, on thousands of devices. LiveLive streaming software allows you to instantly watch content from LiveLive through any internet-connected device that offers the LiveLive app, including smart TVs, game consoles, streaming media players, set-top boxes, smartphones, and tablets. View our Internet Speed Recommendations to achieve the best performance."
    },
    {
        title:"Streaming Devices",
        descr:"In over 190 countries, LiveLive members get instant access to great content. LiveLive has an extensive global content library featuring award-winning Netflix originals, feature films, documentaries, TV shows, and more. Netflix content will vary by region, and may change over time"
    },
   
]
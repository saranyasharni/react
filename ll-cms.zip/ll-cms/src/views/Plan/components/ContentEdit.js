
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button'
import CreateIcon from '@material-ui/icons/Create';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';

import { orange } from '@material-ui/core/colors';
import Typography from  '@material-ui/core/Typography'
import {connect} from "react-redux"
import * as actions from "../../../redux/actions/Plans"

const useStyles = makeStyles((theme) => ({
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    
    // boxShadow: theme.shadows[5],
    padding: theme.spacing(2),
    width:"50vw"
  },
   actions:{
    color:theme.palette.warning.main
  },
  descrInput:{
      fontSize:"18px",
      width:"100%",
      padding:theme.spacing(2),
      fontFamily:"Robot,sans-serif",
      marginBottom:theme.spacing(2)
  },
  editBtn:{
      backgroundColor:theme.palette.warning.main,
      color:"white",
      '&:active':{
          backgroundColor:theme.palette.warning.dark
      },
      '&:hover':{
        backgroundColor:theme.palette.warning.dark

      }
  
  },
  cancelBtn:{
      color:theme.palette.warning.main,
      marginLeft:theme.spacing(2)
  },
  title:{
      fontSize:"18px",
      color:theme.palette.warning.main,
      marginTop:theme.spacing(2),
      marginBottom:theme.spacing(2)
  },
  content:{
    fontSize:"18px",
    color:theme.palette.warning.main,
    marginTop:theme.spacing(2),
    marginBottom:theme.spacing(2)
  },
  titleInput:{
      fontSize:"18px",
      color:"black"
  }

}));

 function ContentEdit(props) {
  // console.log(props, 'coming 89')
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const titleD = props.title
  const handleOpen = () => {
    setOpen(true);
  };
  const OrangeCheckbox = withStyles({
    root: {
      color: orange[400],
      '&$checked': {
        color: orange[600],
      },
    },
    checked: {},
  })((props) => <Checkbox color="default" {...props} />);
  const [state,setState] = React.useState({
    id : props.id,
    title:props.title,
    price:props.descr,
    uninterrupted_viewing: props.uninterrupted_viewing,
    unlimited_download: props.unlimited_download,
    stream_cast_enabled: props.stream_cast_enabled,
    access_to_live_content: props.access_to_live_content,
    same_day_release: props.same_day_release,
    major_events_coverage: props.major_events_coverage,
    all_access_pass:  props.all_access_pass
  })

  const handleChange=(event)=> {
    setState({...state,[event.target.name]:event.target.value})
  }
  const handleCheckbox=(event)=> {
    console.log(event.target.name, 'event.target.name')
    console.log(event.target.checked, 'event.target.checked')
    setState({...state,[event.target.name]:event.target.checked})
  }

  const handleClose = () => {
    setOpen(false);
  };
  
  const handleEdit=()=>{
    console.log(state, 'afteredit')
    props.updatePlan(state)
   
   handleClose()
  }

  return (
    <div>
     
     <Button size="medium" onClick={handleOpen}className={classes.actions} startIcon={<CreateIcon />}>Edit </Button>

      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        className={classes.modal}
        open={open}
        onClose={handleClose}
        closeAfterTransition
        disableEnforceFocus
        disableAutoFocus
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <div className={classes.paper}>
          <Typography className={classes.title}>
          Title
        </Typography>
          <TextField id="outlined-basic" name="title" color="warning" onChange={handleChange} defaultValue={props.title}className={classes.titleInput} variant="outlined" />
          <Typography className={classes.title} >
          Price
        </Typography>
          {/* <TextareaAutosize aria-label="minimum height" name="descr"  onChange={handleChange} rowsMin={7} className={classes.descrInput} placeholder="Minimum 3 rows" defaultValue={props.descr}/> */}
          <TextField id="outlined-basic" name="price" color="warning" onChange={handleChange} defaultValue={props.descr}className={classes.titleInput} variant="outlined" />
          <Typography className={classes.content} >
          Services
          </Typography>
          <FormControl component="fieldset">
          <FormGroup aria-label="position" row>
          <FormControlLabel
          value="uninterrupted_viewing"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.uninterrupted_viewing} 
            onChange={handleCheckbox} 
            name="uninterrupted_viewing" 
            />}
          label="uninterrupted_viewing"
          labelPlacement="end"
        />
        <FormControlLabel
          value="unlimited_download"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.unlimited_download} 
            onChange={handleCheckbox} 
            name="unlimited_download" 
            />}
          label="unlimited_download"
          labelPlacement="end"
        />
        <br/>
        <FormControlLabel
          value="stream_cast_enabled"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.stream_cast_enabled} 
            onChange={handleCheckbox} 
            name="stream_cast_enabled" 
            />}
          label="stream_cast_enabled"
          labelPlacement="end"
        />
        <FormControlLabel
          value="access_to_live_content"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.access_to_live_content} 
            onChange={handleCheckbox} 
            name="access_to_live_content" 
            />}
          label="access_to_live_content"
          labelPlacement="end"
        />
        <FormControlLabel
          value="same_day_release"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.same_day_release} 
            onChange={handleCheckbox} 
            name="same_day_release" 
          />}
          label="same_day_release"
          labelPlacement="end"
        />
        <FormControlLabel
          value="major_events_coverage"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.major_events_coverage} 
            onChange={handleCheckbox} 
            name="major_events_coverage" 
            />}
          label="major_events_coverage"
          labelPlacement="end"
        />
        <FormControlLabel
          value="all_access_pass"
          control={<OrangeCheckbox 
            color="primary" 
            checked={state.all_access_pass} 
            onChange={handleCheckbox} 
            name="all_access_pass" 
            />}
          label="all_access_pass"
          labelPlacement="end"
        />
        </FormGroup>
        </FormControl>
        <Typography className={classes.content} >
          
          </Typography>
           <Button size="medium" variant="contained" color="warning"className={classes.editBtn} onClick={handleEdit}>Save</Button>
           <Button size="medium" className={classes.cancelBtn} onClick={handleClose}>cancel</Button>

          </div>
        </Fade>
      </Modal>
    </div>
  );
}
const mapStateToProps=(state,ownProps)=>{
  const {plan,loading,error} = state.Plans
  return{
    plan,
    loading,
    error
  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    updatePlan:(data)=>{dispatch(actions.updatePlan(data))},
    // updateWhatsNew:(data)=>{dispatch(actions.updateWhatsNew(data))}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ContentEdit)
import React,{useState,useEffect} from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import DeleteIcon from '@material-ui/icons/Delete';
// import CreateIcon from '@material-ui/icons/Create';
import ContentEdit from './ContentEdit';
import {connect} from "react-redux"
 import * as actions from "../../../redux/actions/Plans"
const useStyles = makeStyles((theme)=>({
    
        root: {
          minWidth: 275,
          marginTop:theme.spacing(2)
        },
        bullet: {
          display: 'inline-block',
          margin: '0 2px',
          transform: 'scale(0.8)',
        },
        title: {
          fontSize: "24px",
          fontWeight:"bold",
          color:"black"
        },
        pos: {
          marginBottom: 12,
          fontSize:"16px"
        },
        actions:{
            color:theme.palette.warning.main
        }
      
}));
function ContentsCard(props) {
    
    const [items,setItems] = useState([])
    useEffect(()=>{
      setItems(props.content)
    },[props])
    const classes = useStyles();
    const handleDelete=(item)=>{
      console.log(item, 'item90')
      props.deletePlan(item)
    }
    return (
        <>
        {!items?"":items.map((item,index)=>{
        return(
        <>
        <Card className={classes.root} key={index}>
        <CardContent>
        <Typography className={classes.title}  gutterBottom>
          {item.plan_name}
        </Typography>
        
        <Typography className={classes.pos} color="textSecondary">
          {item.plan_price}
        </Typography>
        
        </CardContent>
        <CardActions>
          <ContentEdit 
          descr={item.plan_price} 
          title={item.plan_name} 
          id = {item._id}
          uninterrupted_viewing= {item.uninterrupted_viewing ? item.uninterrupted_viewing : false}
          unlimited_download= {item.unlimited_download ? item.unlimited_download: false}         
          stream_cast_enabled= {item.stream_cast_enabled ? item.stream_cast_enabled : false}
          access_to_live_content= {item.access_to_live_content ? item.access_to_live_content : false}
          same_day_release= {item.same_day_release ? item.same_day_release : false}
          major_events_coverage= {item.major_events_coverage ? item.major_events_coverage : false}
          all_access_pass= {item.all_access_pass ? item.all_access_pass : false }
          />
               {/* <Button size="medium" className={classes.actions} startIcon={<CreateIcon />}>Edit </Button> */}
        <Button size="medium" className={classes.actions}  onClick={()=>handleDelete(item._id)} startIcon={<DeleteIcon />}>Delete </Button>
        </CardActions>
        </Card>
        </>
        )
        })}
             
        </>
    )
}
const mapStateToProps=(state,ownProps)=>{
  const {plan,loading,error} = state.Plans
  return{
    plan,
    loading,
    error
  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    // getAboutData:()=>{dispatch(actions.getAboutData())}
    deletePlan:(data)=>{dispatch(actions.deletePlan(data))}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ContentsCard)


import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import Button from '@material-ui/core/Button'
import {connect} from "react-redux"
// import CreateIcon from '@material-ui/icons/Create';
import DeleteIcon from '@material-ui/icons/Delete';
import   IconButton from '@material-ui/core/IconButton'
import * as actions from "../../../../redux/actions/UsersList"

import Typography from '@material-ui/core/Typography'
const useStyles = makeStyles((theme) => ({
  
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    
    // boxShadow: theme.shadows[5],
    padding: theme.spacing(3),
    width:"50vw"

  },
   actions:{
    color:theme.palette.warning.main
  },
  descrInput:{
      fontSize:"18px",
      width:"100%",
      padding:theme.spacing(2),
      fontFamily:"Robot,sans-serif",
      marginBottom:theme.spacing(2)
  },
  editBtn:{
      backgroundColor:theme.palette.warning.main,
      color:"white",
      '&:active':{
          backgroundColor:theme.palette.warning.dark
      },
      '&:hover':{
        backgroundColor:theme.palette.warning.dark

      }
  
  },
  cancelBtn:{
      color:theme.palette.warning.main,
      marginLeft:theme.spacing(2)
  },
  title:{
      fontSize:"30px",
      fontWeight:"blod",
      color:"black",
      marginBottom:theme.spacing(3)
  },
  email:{
    fontSize:"16px",
    color:"black",
  },
  userlist:{
      display:"flex",
      flexDirection:"column",
      margin:"5px 0px"
  }

}));

function DeleteUser(props) {
  const [deleteMail, setMail] = React.useState('')
    React.useEffect(()=>{
      if (props.users && props.users.length > 0) {
        setMail(props.users[0].email)
      }
  // console.log(props, 'deleteemail')
    },[props])
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleDelete = () => {
    // console.log(deleteMail, 'deleteMail')
    props.deleteUser({
      email:deleteMail
    })
    // handleClose()
  }
  return (
    <div>
     
     <IconButton aria-label="delete"  onClick={handleOpen}>
            <DeleteIcon />
          
          </IconButton>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        className={classes.modal}
        open={open}
        onClose={handleClose}
        closeAfterTransition
        disableEnforceFocus
        disableAutoFocus
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <div className={classes.paper}>
          <Typography className={classes.title}>
          Are you sure you want to Delete this User ?
        </Typography>
        <div className={classes.userlist}>
        {props.users.map(item=>{
            return(
                <>
                <Typography className={classes.email}>
          {item.email}
        </Typography>
                </>
            )
        })}
        </div>
           <Button size="medium" variant="contained" 
           
           color="warning"className={classes.editBtn}
           onClick = {() => {handleDelete()}}
           >Delete</Button>
           <Button size="medium" className={classes.cancelBtn} onClick={handleClose}>cancel</Button>

          </div>
        </Fade>
      </Modal>
    </div>
  );
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    
    deleteUser:(email)=>{dispatch(actions.deleteUser(email))}
  }
}
export default connect(null,mapDispatchToProps)(DeleteUser)
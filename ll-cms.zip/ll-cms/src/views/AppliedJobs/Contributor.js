import React,{useEffect,useState} from 'react'
import ContributorsList from "./components/ContributorList"
import { makeStyles } from '@material-ui/styles';

import mockData from './components/Data.js';
import {connect} from "react-redux"
import MuiAlert from '@material-ui/lab/Alert';
import {Backdrop,
  CircularProgress,Snackbar } from '@material-ui/core'
import * as actions from "../../redux/actions/Contributors"
const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3)
  },
  content: {
    marginTop: theme.spacing(2)
  }, backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: '#fff',
  },
}));
function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}
function Contributor(props) {
  const classes = useStyles();
  const [open,setOpen] = useState(false)
  useEffect(()=>{
  props.getContributors()
  },[])
  const handleAlertClose=(event,reason)=>{
    setOpen(false);
  }
    return (
        <>
        <Backdrop className={classes.backdrop} open={props.loading} >
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
        <Alert onClose={handleAlertClose} severity={props.success?"success":"error"}>
         {props.message}
        </Alert>
      </Snackbar>
          <ContributorsList users={props.contributorsData} />  
        </>
    )
}


const mapStateToProps=(state,ownProps)=>{
  const {contributorsData,loading,error,message,success} = state.Contributors
  return{
    contributorsData,  
      loading,
      error,
      message,
      success
  }
}
const mapDispatchToProps =(dispatch,ownProps)=>{
  return{
    getContributors:()=>{dispatch(actions.list_applications())}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(Contributor);

import React,{useState,useEffect} from 'react'
import {Typography,Backdrop,
  CircularProgress,Snackbar} from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles';
import ContentCard from "./components/ContentCard" 
import MuiAlert from '@material-ui/lab/Alert';

// import {contents} from "./data"
import * as actions from "../../redux/actions/WhatsNew"
import {connect } from 'react-redux'
import AddContent from './components/AddContent';
const useStyles = makeStyles((theme) => ({
    root:{
    padding:theme.spacing(3)
    },
    title:{
        fontSize:"30px",
        color:theme.palette.warning.main,
        fontWeight:"bolder",
        marginBottom:theme.spacing(4)
    },
    descr:{
        fontSize:"20px",
        fontWeight:"blod",
        color:"black",
        marginTop:theme.spacing(2)
    }, backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
    },
    flex:{
      display:"flex",
      flexDirection:"row",
      justifyContent:"space-between",
      marginTop:theme.spacing(2)
    },
    addbtn:{
      backgroundColor:"black",
      color:"white",
      '&:hover':{
        backgroundColor:"black",
      color:"white",
      }
    }
  }));
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
function WhatsNew(props) {
  const [open,setOpen] = useState(false)
  const [contents ,setCont] = useState([])
    const classes = useStyles();
    useEffect(()=>{
      if(props.whatsnewData){
        
        setCont(props.whatsnewData.additional_details)
      }
    
    },[props.whatsnewData])
    useEffect(()=>{
      if(props.message !== ""){
      setOpen(true)
      }else{
        setOpen(false)
      }
      
      },[props])
     useEffect(()=>{
    props.getWhatsNewData()
    },[])
    const handleAlertClose=(event,reason)=>{
      
    setOpen(false);
    }
    return (
      <>
       <Backdrop className={classes.backdrop} open={props.loading} >
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleAlertClose} >
        <Alert onClose={handleAlertClose} severity={props.success?"success":"error"}>
         {props.message}
        </Alert>
      </Snackbar>
        <div className={classes.root}>
           <Typography className={classes.title}  gutterBottom>
          What's New
        </Typography>
       <div className={classes.flex}> 
        <Typography className={classes.descr}  gutterBottom>
          Contents
        </Typography>
        <AddContent />
        </div>
        <ContentCard content={contents}/>
        </div>
        </>
    )
}
const mapStateToProps=(state,ownProps)=>{
  const {whatsnewData,loading,error,message,success} = state.WhatsNew
  return{
    whatsnewData,
    loading,
    error,
    message,
    success
  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    getWhatsNewData:()=>{dispatch(actions.getWhatsNewData())}
  }
}
export default connect(mapStateToProps,mapDispatchToProps) (WhatsNew)



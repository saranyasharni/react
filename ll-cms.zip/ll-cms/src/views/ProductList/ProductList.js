import React, { useState } from 'react';
import { makeStyles } from '@material-ui/styles';
import {  Grid,  Backdrop,
  CircularProgress, } from '@material-ui/core';
// import ChevronRightIcon from '@material-ui/icons/ChevronRight';
// import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';

import { ProductsToolbar, ProductCard } from './components';
// import {apiData} from './data';
import {connect} from "react-redux"
import * as actions from "../../redux/actions/Categories"
const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3)
  },
  content: {
    marginTop: theme.spacing(2)
  },
  pagination: {
    marginTop: theme.spacing(3),
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end'
  },backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: '#fff',
  },
}));

const ProductList = (props) => {
  const classes = useStyles();
  const [Categories,setCategories] = useState(props.categories);
  React.useEffect(()=>{
setCategories(props.categories)
console.log(props.categories,"from category list")
  },[props.categories])
 React.useEffect(()=>{
  props.getCategories()
 },[])
  

  return (
    <>
     <Backdrop className={classes.backdrop} open={props.loading} >
        <CircularProgress color="inherit" />
      </Backdrop>
    <div className={classes.root}>
      <ProductsToolbar />
      <div className={classes.content}>
        <Grid
          container
          spacing={3}
        >
          {!Categories?"":Categories.map(item => (
            <Grid
              item
              key={item.id}
              lg={4}
              md={6}
              xs={12}
            >
              <ProductCard category={item} />
            </Grid>
          ))}
        </Grid>
      </div>
      
    </div>
    </>
  );
};

const mapStateToProps=(state,ownProps)=>{
  const {filterCategories,loading,error} = state.Categories
  return{
    categories:filterCategories,
    loading,
    error
  }
}

const mapDispatchToProps = (dispatch,ownProps)=>{
  return{
    getCategories:()=>{dispatch(actions.getCategories())}
  }
}
export default connect(mapStateToProps,mapDispatchToProps) (ProductList);

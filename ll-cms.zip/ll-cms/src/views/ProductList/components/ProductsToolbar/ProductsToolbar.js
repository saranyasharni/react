import React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/styles';
import {connect}from "react-redux"
import { SearchInput } from 'components';
import ToggleButton from '@material-ui/lab/ToggleButton';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';
import * as actions from "../../../../redux/actions/Categories"
const useStyles = makeStyles(theme => ({
  '@global':{
    '.MuiToggleButton-root':{
      '.Mui-selected ':{
        color:"white !impotant",
        backgroundColor:theme.palette.warning.main
      }
       
      }
  },
  togglebtn:{
 color:"white",
 backgroundColor:theme.palette.warning.main
  },
  
  
  row: {
    height: '42px',
    display: 'flex',
    alignItems: 'center',
    marginTop: theme.spacing(1)
  },
  spacer: {
    flexGrow: 1
  },
  importButton: {
    marginRight: theme.spacing(1)
  },
  exportButton: {
    marginRight: theme.spacing(1)
  },
  searchInput: {
    marginRight: theme.spacing(1)
  }
}));

const ProductsToolbar = props => {
  const { className, ...rest } = props;
  const [alignment, setAlignment] = React.useState('All');
React.useEffect(()=>{
  props.filterCategory(alignment)
 
},[alignment])

  const handleAlignment = (event, newAlignment) => {
    // props.filterCategory(alignment)
    setAlignment(newAlignment);
  };
  const classes = useStyles();

  return (
    <div
      {...rest}
      className={clsx(classes.root, className)}
    >
      <div className={classes.row}>
        <span className={classes.spacer} />
        
         <ToggleButtonGroup
      value={alignment}
      exclusive
      onChange={handleAlignment}
      aria-label="text alignment"
      
    >
      <ToggleButton value="enabled" aria-label="left aligned" className={{selected:classes.togglebtn}}>
        Enabled
      </ToggleButton>
      <ToggleButton value="disabled" aria-label="centered" classes={{selected:classes.togglebtn}}>
        Disabled
      </ToggleButton>
      <ToggleButton value="All" aria-label="right aligned" classes={{selected:classes.togglebtn}}>
       All
      </ToggleButton>
      
    </ToggleButtonGroup>
      </div>
      <div className={classes.row}>
        <SearchInput
          className={classes.searchInput}
          placeholder="Search product"
        />
      </div>
    </div>
  );
};

ProductsToolbar.propTypes = {
  className: PropTypes.string
};

const mapStateToProps=(state,ownProps)=>{
  return{

  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    filterCategory:(filter)=>{dispatch(actions.filterCategory(filter))}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ProductsToolbar);

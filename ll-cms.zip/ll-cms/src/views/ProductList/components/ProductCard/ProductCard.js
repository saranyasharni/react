import React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/styles';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  Grid,
  Divider
} from '@material-ui/core';
import * as actions from "../../../../redux/actions/Categories"
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import {connect} from "react-redux"
const useStyles = makeStyles(theme => ({
  root: props=>({
    backgroundColor:props.backgroundColor,
    color:props.color
  }),
  imageContainer: {
    height: 64,
    width: 64,
    margin: '0 auto',
    border: `1px solid ${theme.palette.divider}`,
    borderRadius: '5px',
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  image: {
    width: '100%'
  },
  statsItem: {
    display: 'flex',
    alignItems: 'center'
  },
  statsIcon: {
    color: theme.palette.icon,
    marginRight: theme.spacing(1)
  },
  typo:props=>({
    color:props.color
  })
}));

const ProductCard = props => {
  const { className, ...rest } = props;
  const [category,setCategory] = React.useState(props.category)
React.useEffect(()=>{
setCategory(props.category)
setState({checkedA:props.category.status==="active"?true:false})
},[props.category])
  const [state, setState] = React.useState({
    checkedA: category.status==="active"?true:false
  });
  const handleChange = (event) => {
    let status =category.status==="active"?"in-active":"active"
    let data= {
      category_id:category._id,
      status:status
    }
    props.changeStatus(JSON.stringify(data))
    
    console.log("triggred")
  };
  const prop1 ={backgroundColor:"black",color:"white"}
  const prop2 ={backgroundColor:"white",color:"black"}
  const classes = useStyles(!state.checkedA?prop1:prop2);

  return (
    <Card
      {...rest}
      className={clsx(classes.root, className)}
    >
      <CardContent>
        <div className={classes.imageContainer}>
          <img
            alt="Product"
            className={classes.image}
            src={category.img}
          />
        </div>
        <Typography
          align="center"
          gutterBottom
          variant="h4"
          className={classes.typo}
        >
          {category.name}
        </Typography>
        <Typography
          align="center"
          variant="body1"
          className={classes.typo}
        >
          {category.description}
        </Typography>
      </CardContent>
      <Divider />
      <CardActions>
        <Grid
          container
          justify="space-between"
        >
          <Grid
            className={classes.statsItem}
            item
          >
            
             <FormControlLabel
             className={classes.typo}
        control={<Switch checked={state.checkedA} onChange={handleChange} name="checkedA" />}
        label="Enable"
      />
          </Grid>
       
        </Grid>
      </CardActions>
    </Card>
  );
};

ProductCard.propTypes = {
  className: PropTypes.string,
  product: PropTypes.object.isRequired
};

const mapStateToProps=(state,ownProps)=>{
  return{

  }
}
const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    changeStatus:(category_id,status)=>{dispatch(actions.changeStatus(category_id,status))},
    getCategories:()=>{dispatch(actions.getCategories())}
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ProductCard);

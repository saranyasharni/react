import React,{useState,useEffect} from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography'
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { makeStyles } from '@material-ui/core/styles';
 import { IconButton,Select,MenuItem } from '@material-ui/core';

import CreateIcon from '@material-ui/icons/Create';
import {connect} from 'react-redux';
import * as actions from "../../../redux/actions/Contributors"
const useStyles = makeStyles((theme)=>({
    title:{
        fontSize:theme.typography.pxToRem(20),
        fontWeight:"bold",
        marginBottom:theme.spacing(2),
        marginTop:theme.spacing(2)
    },
    descrInput:{
        fontSize:"18px",
        width:"100%",
        padding:theme.spacing(2),
        fontFamily:"Robot,sans-serif",
        marginBottom:theme.spacing(2)
    },
    btn:{
        color:theme.palette.warning.main
    },
    formControl: {
        
        minWidth: 180,
      }
}))
 function UpdateList(props) {
    const classes = useStyles()
  const [open, setOpen] = React.useState(false);
  const [scroll, setScroll] = React.useState('paper');
  const [state,setState] = useState({
    status:props.user.status,
    contributor_id:props.user._id
  })
  React.useEffect(()=>{
    setState({
    status:props.user.status,
    contributor_id:props.user._id
  })
  console.log(props,"user edit")
  },[props])
  const handleClickOpen = (scrollType) => () => {
    setOpen(true);
    setScroll(scrollType);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleEdit=()=>{
    
   props.delete_advertisement(state)
   handleClose()
  }
  const handleChange=(event)=>{
    setState({...state,[event.target.name]:event.target.value})
    
  }
  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [open]);

  return (
    <div>
  
          <IconButton aria-label="edit" onClick={handleClickOpen('paper')}>
            <CreateIcon />
    </IconButton>
      <Dialog
        open={open}
        onClose={handleClose}
        scroll={scroll}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
      >
        <DialogTitle id="scroll-dialog-title">Edit Contributor Status</DialogTitle>
        <DialogContent dividers={scroll === 'paper'}>
          <DialogContentText
            id="scroll-dialog-description"
            ref={descriptionElementRef}
            tabIndex={-1}
          >
              {/* <Typography className={classes.title}>Status</Typography>
              <TextField id="outlined-basic" name="status" label="name" onChange={handleChange} variant="outlined" defaultValue={props.user.status}/> */}
              
              <Select
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          value={state.status}
          onChange={handleChange}
          label="status"
          name="status"
        className={classes.plan}
        defaultValue={props.user.status}
        >
          
          <MenuItem value="active">active</MenuItem>
          <MenuItem value="in-active">in-active</MenuItem>
          
        </Select>  
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className={classes.btn}>
            Cancel
          </Button>
          <Button onClick={handleEdit} className={classes.btn}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

const mapDispatchToProps=(dispatch,ownProps)=>{
  return{
    
    delete_advertisement:(state)=>{dispatch(actions.delete_advertisement(state))}
  }
}

export default connect(null,mapDispatchToProps)(UpdateList)
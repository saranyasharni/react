import palette from '../palette';
export default {
    selected:{
        backgroundColor:palette.warning.main,
        color:"white"
    },
    root:{
        
        '&.Mui-selected':{
            backgroundColor:palette.warning.main,
            color:"white"
        }
    }
  };
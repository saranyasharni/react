import React from 'react';
import { Switch, Redirect } from 'react-router-dom';

import { RouteWithLayout } from './components';
import { Main as MainLayout, Minimal as MinimalLayout } from './layouts';

import {
  Dashboard as DashboardView,
  //ProductList as ProductListView,
  CategoryList as CategoryListView,
  SubCategoryList as SubCategoryListView,
  UserList as UserListView,
  SignIn as SignInView,
  NotFound as NotFoundView
} from './views';
import AboutUs from "./views/AboutUs/AboutUs";
import Jobs from "./views/Jobs/Jobs";
import WhatsNew from "./views/WhatsNew/WhatsNew";
// import Plan from "./views/Plan/Plan";
import applied_jobs from "./views/AppliedJobs/Contributor";
import add from "./views/AdvertisersAppliedList/Contributor";
import HelpCenter from 'views/HelpCenter/HelpCenter';
import Contributor from 'views/Contributor/Contributor';
import subscribe from 'views/SubscriberList/Contributor';

const loggedIn = () => {
  let token = localStorage.getItem("token")
  if (!token) {
    return <Redirect exact to="/sign-in" />
  }
}
const Routes = () => {
  return (
    <>
    <Switch>
      <Redirect
        exact
        from="/"
        to="/sign-in"
      />
      
      <RouteWithLayout
        component={DashboardView}
        exact
        layout={MainLayout}
        path="/dashboard"
      />
      <RouteWithLayout
        component={UserListView}
        exact
        layout={MainLayout}
        path="/users"
      />
      <RouteWithLayout
        component={CategoryListView}
        exact
        layout={MainLayout}
        path="/categories"
      />
       <RouteWithLayout
        component={SubCategoryListView}
        exact
        layout={MainLayout}
        path="/subcategories"
      />
       <RouteWithLayout
        component={WhatsNew}
        exact
        layout={MainLayout}
        path="/whatsnew"
      />

      <RouteWithLayout
        component={applied_jobs}
        exact
        layout={MainLayout}
        path="/applied-jobs"
      />

      <RouteWithLayout
        component={add}
        exact
        layout={MainLayout}
        path="/advertise-with-us"
      />
      <RouteWithLayout
        component={subscribe}
        exact
        layout={MainLayout}
        path="/subscribers-list"
      />

      <RouteWithLayout
        component={HelpCenter}
        exact
        layout={MainLayout}
        path="/helpcenter"
      />
      
      <RouteWithLayout
        component={AboutUs}
        exact
        layout={MainLayout}
        path="/aboutus"
      />
      <RouteWithLayout
        component={Jobs}
        exact
        layout={MainLayout}
        path="/jobs"
      />
       <RouteWithLayout
        component={Contributor}
        exact
        layout={MainLayout}
        path="/contribution"
      />
      <RouteWithLayout
        component={SignInView}
        exact
        layout={MinimalLayout}
        path="/sign-in"
      />
     
      <RouteWithLayout
        component={NotFoundView}
        exact
        layout={MinimalLayout}
        path="/not-found"
      />
       
      
      <Redirect to="/not-found" />
      
    </Switch>
    {loggedIn()}
    </>
  );
};

export default Routes;

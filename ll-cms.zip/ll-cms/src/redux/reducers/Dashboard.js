export const initialState={
monthly_profit:"",
weekly_profit:"",
yearly_profit:"",
month_err:"",
year_err:"",
week_err:"",
sum:[],
keys:[],
err_graph:"",
total_profit:"",
loading:false
}

export const Dashboard =(state=initialState,action)=>{
    switch (action.type) {
        case "SET_MONHTLY_PROFIT":
           return{...state,monthly_profit:action.payload.reduce((acc,i)=>{
             return acc+i.amount
           },0)}
        case "SET_WEEKLY_PROFIT":
           return{...state,weekly_profit:action.payload.reduce((acc,i)=>{
            return acc+i.amount
          },0)}
        case "SET_YEARLY_PROFIT":
           return{...state,yearly_profit:action.payload.reduce((acc,i)=>{
            return acc+i.amount
          },0)}
        case "SET_GRAPH_DATA":
            return{...state,sum:action.payload.sum,keys:action.payload.keys}
        case "ERR_GRAPH":
            return{...state,err_graph:action.payload}
        case "ERR_MONTH":
            return{...state,month_err:action.payload}
        case "ERR_WEEK":
           return{...state,week_err:action.payload}
        case "ERR_YEAR":
           return{...state,year_err:action.payload}
        case "SET_LOADING":
            return{...state,loading:action.payload}
        case "TOTAL_PROFIT":
            return{...state,total_profit:state.monthly_profit+state.weekly_profit+state.yearly_profit}
        default:
            return state
    }
}
import { combineReducers } from "redux";
import { connectRouter } from "connected-react-router";
import {AboutUs} from "./AboutUs"
import {Categories} from "./Categories"
import {Contributors} from "./Contributor"
import {Dashboard} from "./Dashboard"
import {HelpCenter} from "./HelpCenter"
import {Jobs} from "./Jobs"
import {SignIn} from "./SignIn"
import {UserList} from "./UserList"
import {WhatsNew} from "./WhatsNew"
import {Plans} from "./Plans"


const RootReducer = history =>
  combineReducers({
    AboutUs,
    Categories,
    Contributors,
    Dashboard,
    HelpCenter,
    Jobs,
    SignIn,
    UserList,
    WhatsNew,
    Plans,
    router: connectRouter(history),
    
  });

export default RootReducer;
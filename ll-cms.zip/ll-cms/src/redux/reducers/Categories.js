export const initialState = {
    categories:[],
    filterCategories:[],
    error:"",
    loading:false,
    updateMessage:"",
    category:[],
    listingCategory:[],
    setMessage: "",
    set_success:"",
    subcategoryList: []
}

export const Categories = (state=initialState, action)=>{
    //alert('atkeS')
    switch (action.type) {
        case "LIST_CATEGORY":
            return{...state,category:action.payload}
        case "LISTING_CATEGORIES":
            return{...state,listingCategory:action.payload}
        case "SET_SUB_CAT_LIST":
            
            return{...state,subcategoryList:action.payload}
        case "SAVE_SET_CAT_MSG":
            return{...state,setMessage:action.payload}
        case "SET_CATEGORIES":
            return{...state,categories:action.payload,filterCategories:action.payload}
        case "UPDATE_SUCCESS":
            return{...state,updateMessage:action.payload,set_success:true}
        case "UPDATE_FAIL":
            return{...state,updateMessage:"Opps! something went wrong,Please try again", set_success:false}
        case "SET_LOADING":
            return{...state,loading:action.payload}
        case "ERROR":
                return{...state,error:action.payload}
        case "GET_ALL":
            return{
                ...state,filterCategories:[...state.categories]
            }
        case "GET_ENABLED":
            return{
                ...state,filterCategories:[...state.categories.filter(i=>i.status===action.payload)]
            }
        case "GET_DISABLED":
            return{
                ...state,filterCategories:[...state.categories.filter(i=>i.status===action.payload)]
            }
        default:
            return state
    }
}
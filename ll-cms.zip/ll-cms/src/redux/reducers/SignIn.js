let token = localStorage.getItem('token')

export const initialState= token ?{loggedIn:true,loading:false,error:"",email:"",redirect:false}:{
    loggedIn:false,
    loading:false,
    error:"",
    email:"",
    redirect:false
}

export const SignIn =(state=initialState,action)=>{
    switch (action.type) {
        case "LOGIN_SUCCESS":
           return{...state,loggedIn:action.payload.loggedIn,email:action.payload.email,redirect:"/dashboard"}
        case "SET_LOADING":
            return{
                ...state,
                loading:action.payload
            }
        case "ERORR":
            return{
                ...state,
                error:action.payload
            }
        case "LOGOUT":
            return{
                ...state,
                loggedIn:false,
                error:"",
                loading:false,
                redirect:false
            }
        default:
            return state
    }
}
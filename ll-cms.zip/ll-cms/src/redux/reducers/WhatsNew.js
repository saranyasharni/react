export const initialState={
    whatsnewData:{},
    loading:false,
    error:"",
    message:"",
    success:""
    }
    
    export const WhatsNew =(state=initialState,action)=>{
        switch (action.type) {
            case "SET_WHATSNEW":
               return{...state,whatsnewData:action.payload[0]}
               case "SET_LOADING":
                return{...state,loading:action.payload}
            case "ERROR":
                    return{...state,error:action.payload}
            case "UPDATE_SUCCESS":
                return{
                    ...state,message:action.payload,success:true
                }
                case "UPDATE_FAIL":
                    return{
                        ...state,message:"Opps! something went wrong,Please try again",success:false
                    }
            default:
                return state
        }
    }
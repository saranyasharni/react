export const initialState={
    faqData:[],
    loading:false,
    error:"",
    message:"",
    success:""
    }
    
    export const HelpCenter = (state=initialState,action)=>{
        switch (action.type) {
            case "SET_FAQ":
               return{...state,faqData:action.payload.filter(i=>i.is_show===true)}
               case "SET_LOADING":
                return{...state,loading:action.payload}
            case "ERROR":
                return{...state,error:action.payload}
                    case "UPDATE_SUCCESS":
                        return{
                            ...state,message:action.payload,success:true
                        }
                    case "UPDATE_FAIL":
                        return{
                            ...state,message:"Opps! something went wrong,Please try again",success:false
                        }
            default:
                return state
        }
    }
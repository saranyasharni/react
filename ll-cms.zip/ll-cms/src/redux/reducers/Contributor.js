export const initialState={
    contributorsData:[],
    loading:false,
    error:"",
    message:"",
    success:""
    }
    
    export const Contributors =(state=initialState,action)=>{
        switch (action.type) {
            case "SET_CONTRIBUTOR":
               return{...state,contributorsData:action.payload}
               case "SET_LOADING":
                return{...state,loading:action.payload}
            case "ERROR":
                    return{...state,error:action.payload}
                    case "UPDATE_SUCCESS":
                        return{
                            ...state,message:action.payload,success:true
                        }
                        case "UPDATE_FAIL":
                            return{
                                ...state,message:"Opps! something went wrong,Please check the values",success:false
                            }
            default:
                return state
        }
    }
export const initialState={
    plan:[],
    loading:false,
    error:"",
    message:"",
    success:""
}
    
export const Plans = (state=initialState,action) => {
    
    switch (action.type) {
        case "SET_PLAN":
            return{...state,plan:action.payload}
        case "SET_LOADING":
            return{...state,loading:action.payload}
        case "ERROR":
            return{...state,error:action.payload}
        case "UPDATE_SUCCESS":
            return{
                    ...state,message:action.payload,success:true
                }
        case "UPDATE_FAIL":
            return{
                ...state,message:"Opps! something went wrong,Please try again",success:false
            }
        default:
            return state
        }
    }
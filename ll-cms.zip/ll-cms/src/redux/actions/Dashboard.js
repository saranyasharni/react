import {config} from "./API/Services"
import moment from "moment"
import {chartData}  from "../../views/Dashboard/components/LatestSales/Data"
var _ = require('lodash');

 const monthData=(data)=>({
     type:"SET_MONHTLY_PROFIT",
     payload:data
 })
 const weekData=(data)=>({
    type:"SET_WEEKLY_PROFIT",
    payload:data
})
const yearData=(data)=>({
    type:"SET_YEARLY_PROFIT",
    payload:data
})
const monthDataErr=(err)=>({
    type:"ERR_MONTH",
    payload:err
})
const weekDataErr=(err)=>({
    type:"ERR_WEEK",
    payload:err
})
const yearDataErr=(err)=>({
    type:"ERR_YEAR",
    payload:err
})
const setGrpahData=(data)=>({
    type:"SET_GRAPH_DATA",
    payload:{
        sum:data.sum,
        keys:data.keysObj
    }
})
 const ErrgraphData=(err)=>({
     type:"ERR_GRAPH",
     payload:err
 })
const setLoading=(data)=>({
    type:"SET_LOADING",
    payload:data
})

export const getData =()=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    const startOfMonth = moment().startOf('month').format('YYYY-MM-DD');
const endOfMonth   = moment().endOf('month').format('YYYY-MM-DD');
const startOfWeek = moment().startOf('week').format('YYYY-MM-DD');
const endOfWeek   = moment().endOf('week').format('YYYY-MM-DD');
const startOfYear = moment().startOf('year').format('YYYY-MM-DD');
const endOfYear   = moment().endOf('year').format('YYYY-MM-DD');
    let month = {fromDate:startOfMonth,toDate:endOfMonth}
    let week = {fromDate:startOfWeek,toDate:endOfWeek}
    let year = {fromDate:startOfYear,toDate:endOfYear}
    console.log(month,year,week,"from dashboard")
    var requestOptions1 = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(month),
        redirect: 'follow'
      };
      var requestOptions2 = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(week),
        redirect: 'follow'
      };
      var requestOptions3 = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(year),
        redirect: 'follow'
      };
    return dispatch=>{
        setLoading(dispatch(setLoading(true)))
         fetch(config.finance,requestOptions1)
         .then(res=>res.json())
         .then(data=>{
             console.log(data,"month dashboard")
             if(data.status===1){
                 dispatch(monthData(data.data))
             }
             else{
                 dispatch(monthDataErr(data.message))
             }
         }).catch(err=>{dispatch(monthDataErr(err))})
        //week
         fetch(config.finance,requestOptions2)
         .then(res=>res.json())
         .then(data=>{
            console.log(data,"dashboard2")
             if(data.status===1){
                 dispatch(weekData(data.data))
             }
             else{
                 dispatch(weekDataErr(data.message))
             }
         }).catch(err=>{dispatch(weekDataErr(err))})

         //year

         fetch(config.finance,requestOptions3)
         .then(res=>res.json())
         .then(data=>{
            console.log(data,"dashboard3")
             if(data.status===1){
                 dispatch(yearData(data.data))
             }
             else{
                 dispatch(yearDataErr(data.message))
             }
         }).catch(err=>{dispatch(yearDataErr(err))})
         dispatch(setLoading(false))
    }
}

export const getDatafromDate=(from,to,type)=>{
    let fromDate = moment(from).format("YYYY-MM-DD")
    let toDate = moment(to).format("YYYY-MM-DD")
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({fromDate,toDate}),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(setLoading(true))
        return fetch(config.finance,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            console.log(fromDate,toDate,type,"from dates")
            console.log(data,"data")
            // updateData(type,chartData,dispatch)
            if(data.status ===1)
            {
                // dispatch(grpahData(data.data))
                console.log(data)
                updateData(type,data.data,dispatch)
                dispatch(setLoading(false))
            }
            else{
                dispatch(setLoading(false))
                dispatch(ErrgraphData(data.message))
            }
        })
        .catch(err=>{
            console.log(from,to,type)
            dispatch(ErrgraphData(err))
        })
    }
}

export const updateData = async (type,data,dispatch)=>{
    switch(type){
        case "Month" :{
            console.log("Entered")
            var groupedByMonth = await _.groupBy(data, function (result) {
                return moment(result['created_date']).startOf('month').format("MMM YY");
              }); 
              let valuesObj = Object.values(groupedByMonth)
              let sum = valuesObj.map(i=>{
                return  _.sumBy(i, function(o) { return o.amount; });
              })
              let keysObj = Object.keys(groupedByMonth)
              console.log({sum,keysObj})
             return dispatch(setGrpahData({sum,keysObj}))
        }
        case "Year" :{
            console.log("Entered")
            var groupedByYear = await _.groupBy(data, function (result) {
                return moment(result['created_date']).startOf('year').format("YYYY");
              }); 
              let valuesObj = Object.values(groupedByYear)
              let sum = valuesObj.map(i=>{
                return _.sumBy(i, function(o) { return o.amount; });
              })
              let keysObj = Object.keys(groupedByYear)
              console.log({sum,keysObj})
              return dispatch(setGrpahData({sum,keysObj}))
        }
        case "Week" :{
            console.log("Entered")
            var groupedByWeek =  await _.groupBy(data, function (result) {
                return moment(result['created_date']).startOf('week').format("wo YYYY MMM");
              });
              let valuesObj = Object.values(groupedByWeek)
              let sum = valuesObj.map(i=>{
                return _.sumBy(i, function(o) { return o.amount; });
              })
              let keysObj = Object.keys(groupedByWeek)
              console.log({sum,keysObj})
              return dispatch(setGrpahData({sum,keysObj}))
        }
        case "Day":{
            console.log("Entered")
            var groupedByDay = await _.groupBy(data, function (result) {
                return moment(result['created_date']).startOf('day').format("MMM Do YYYY");
              });
              let valuesObj = Object.values(groupedByDay)
              let sum = valuesObj.map(i=>{
                return _.sumBy(i, function(o) { return o.amount; });
              })
              let keysObj = Object.keys(groupedByDay)
              console.log({sum,keysObj})
              return dispatch(setGrpahData({sum,keysObj}))
        }
         default:
            return dispatch(setGrpahData({sum:[],keysObj:[]}))

            
    }
}
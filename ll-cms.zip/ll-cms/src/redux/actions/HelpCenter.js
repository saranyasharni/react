import {config} from "./API/Services"
import {contents} from "../../views/HelpCenter/data"


const faqData=(data)=>({
    type:"SET_FAQ",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})
const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})

export const getFaq =()=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
       
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.faqList,requestOptions)
        .then(res=>res.json())
        .then(data=>{
         console.log(data)
            // dispatch(faqData(contents))
            //     dispatch(SetLoading(false))
            if(data.status===1){
                dispatch(faqData(data.data))
                dispatch(SetLoading(false))
                
            }
            else{
                console.log(data)
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
                dispatch(SetLoading(false))
        })
    }
}

export const updateFaq =(data)=>{
   
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(data),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.faqUpdate,requestOptions)
        .then(res=>res.json())
        .then(data=> {
            if (data.status ===1) {
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getFaq())
            } else {
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}
export const addFaq =(data)=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(data),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.faqCreate,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            if (data.status ===1)
            {
                console.log(data)
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getFaq())
            }
            else{console.log(data)
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{console.log(err)
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}

export const deleteFaq =(id)=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({qa_id:id}),
        redirect: 'follow'
      };
    return dispatch=>{
        return fetch(config.faqDelete,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            if(data.status ===1){
                console.log(data)
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getFaq()) 
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    
    }
}
import {config} from "./API/Services"
const setAbout=(data)=>({
    type:"SET_ABOUT",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})

const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})

export const getAboutData =()=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({slug:"about_us"}),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.getPageDetails,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            console.log(data,"from about us")
            //    dispatch(setAbout(Aboutdata))
            //    dispatch(SetLoading(false))
            if(data.status ===1){
               dispatch(setAbout(data.data))
               dispatch(SetLoading(false))
               
            }
            else{
                dispatch(setError(data.message))
               dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}

export const updateAboutData = (data)=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(data),
        redirect: 'follow'
    };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.updatePageDetails,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // dispatch(updateSuccess("successfully updated"))
            //    dispatch(SetLoading(false))
            // // dispatch(getAboutData())
            
            // dispatch(updateSuccess(data.message))
            if(data.status ===1)
            {

                dispatch(updateSuccess("updated successfully"))
                dispatch(SetLoading(false))
                dispatch(setAbout(data))
                dispatch(getAboutData())
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}
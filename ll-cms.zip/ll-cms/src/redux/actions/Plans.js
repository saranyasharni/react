import {config} from "./API/Services"

const setPlan=(data)=>({
    type:"SET_PLAN",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})

const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})

export const getAllPlanData =()=> {
    
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        // body: JSON.stringify({slug:"whats_new"}),
        redirect: 'follow'
    };
    return dispatch => {
        dispatch(SetLoading(true))
        return fetch(config.get_plan_details,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            
            //    dispatch(setWhatsNew(Aboutdata))
            //    dispatch(SetLoading(false))
            if (data.status ===1) {
                
               dispatch(setPlan(data.data))
               dispatch(SetLoading(false))
               
            } else { 
                dispatch(setError(data.message))
               dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}
export const addPlan = (data)=>{
    
    let formData = new URLSearchParams();    //formdata object
    
    formData.append('plan_name', data.title);
    formData.append('plan_price', data.price);
    formData.append('uninterrupted_viewing', data.uninterrupted_viewing);
    formData.append('unlimited_download', data.unlimited_download);
    formData.append('stream_cast_enabled', data.stream_cast_enabled);
    formData.append('access_to_live_content', data.access_to_live_content);
    formData.append('same_day_release', data.same_day_release);
    formData.append('major_events_coverage', data.major_events_coverage);
    formData.append('all_access_pass', data.all_access_pass)
    formData.append('plan_expiry', '1 month');
    formData.append('account_count', '1');

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formData,
        redirect: 'follow'
      };
    return dispatch=>{
        
        dispatch(SetLoading(true))
        return fetch(config.create_plan, requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // dispatch(updateSuccess("successfully updated"))
            //    dispatch(SetLoading(false))
            // // dispatch(getAboutData())
            
            // dispatch(updateSuccess(data.message))
            if(data.status ===1){

                dispatch(updateSuccess("created successfully"))
                dispatch(SetLoading(false))
                dispatch(getAllPlanData())
                //  dispatch(setWhatsNew(data))
                // dispatch(getWhatsNewData())
            }
            else {
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
        
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}

export const updatePlan = (data)=>{
    // console.log(data, 'dataof edit')
    let formData = new URLSearchParams();    //formdata object
    formData.append('id', data.id);   //append the values with key, value pair
    formData.append('plan_price', data.price);
    formData.append('plan_name', data.title);
    formData.append('uninterrupted_viewing', data.uninterrupted_viewing);
    formData.append('unlimited_download', data.unlimited_download);
    formData.append('stream_cast_enabled', data.stream_cast_enabled);
    formData.append('access_to_live_content', data.access_to_live_content);
    formData.append('same_day_release', data.same_day_release);
    formData.append('major_events_coverage', data.major_events_coverage);
    formData.append('all_access_pass', data.all_access_pass);
    
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formData,
        redirect: 'follow'
      };
    return dispatch=>{
        
        dispatch(SetLoading(true))
        return fetch(config.update_plans, requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // dispatch(updateSuccess("successfully updated"))
            //    dispatch(SetLoading(false))
            // // dispatch(getAboutData())
            
            // dispatch(updateSuccess(data.message))
            if(data.status ===1){

                dispatch(updateSuccess("updated successfully"))
                dispatch(SetLoading(false))
                dispatch(getAllPlanData())
                //  dispatch(setWhatsNew(data))
                // dispatch(getWhatsNewData())
            }
            else {
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
        
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}

export const deletePlan = (data)=>{
    // console.log(data, 'dataof edit')
    let formData = new URLSearchParams();    //formdata object
    formData.append('id', data);   //append the values with key, value pair
    
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formData,
        redirect: 'follow'
      };
    return dispatch=>{
        
        dispatch(SetLoading(true))
        return fetch(config.delete_plan, requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // dispatch(updateSuccess("successfully updated"))
            //    dispatch(SetLoading(false))
            // // dispatch(getAboutData())
            
            // dispatch(updateSuccess(data.message))
            if(data.status ===1){

                dispatch(updateSuccess("deleted successfully"))
                dispatch(SetLoading(false))
                //  dispatch(setWhatsNew(data))
                dispatch(getAllPlanData())
            }
            else {
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
        
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}
import {config} from "./API/Services"
import Userdata from "../../views/UserList/data"
const userData=(data)=>({
    type:"SET_USERDATA",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})
const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})
export const getUser =()=>{
    var myHeaders = new Headers();
    let token = localStorage.getItem("token")
myHeaders.append("authorization", token);
myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

var urlencoded = new URLSearchParams();
urlencoded.append("email", "admin@livelive.com");

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: urlencoded,
  redirect: 'follow'
};
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.userList,requestOptions).then(res=>res.json())
        .then(data=>{
            //
            // dispatch(SetLoading(false))
            if(data.status ===1){
                dispatch(userData(data.data))
                console.log(data)
                 dispatch(SetLoading(false))
            }
            else{
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}

export const updateUser =(state)=>{
    var myHeaders = new Headers();
    let token = localStorage.getItem("token")
myHeaders.append("authorization", token);
myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

var urlencoded = new URLSearchParams();
 urlencoded.append("email", state.email);
urlencoded.append("plan_name", state.plan_name);
urlencoded.append("login_type", state.login_type);
urlencoded.append("user_active", state.user_active);
urlencoded.append("contact_no", state.mobile_no);
urlencoded.append("name", state.name);

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: urlencoded,
  redirect: 'follow'
};
    return dispatch=>{
        // dispatch(SetLoading(true))
        return fetch(config.editUser,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // let temp = userData.map(i=>{
            //     if(i.email === state.email){
            //         i.plan_name= state.plan_name
            //     }
            //     return i
            // })
            // dispatch(updateSuccess("success"))
            //     dispatch(SetLoading(false))
            //     dispatch(userData(temp))
            if(data.status ===1)
            {
                dispatch(updateSuccess(data.message))
                // dispatch(SetLoading(false))
                // dispatch(getUser())
                window.location.reload()
            }
            else{
                dispatch(updateFail(data.message)) 
                // dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err)) 
                // dispatch(SetLoading(false))
        })
    }
}

export const addUser=(state)=>{
    var myHeaders = new Headers();
    let token = localStorage.getItem("token")
myHeaders.append("authorization", token);
myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

var urlencoded = new URLSearchParams();
urlencoded.append("email", state.email);
urlencoded.append("password", state.password);
urlencoded.append("login_type", state.login_type);
urlencoded.append("register_type", state.register_type);
urlencoded.append("name", state.name);
urlencoded.append("mobileNumber", state.mobileNumber);

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: urlencoded,
  redirect: 'follow'
};
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.addUser,requestOptions).then(res=>res.json())
        .then(data=>{
            if(data.status ===1)
            {console.log(data)
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getUser())
            }
            else{
                console.log(data)
                dispatch(updateSuccess(data.message))
                // dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
                dispatch(getUser())
            }
        })
        .catch(err=>{console.log(err)
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}

export const deleteUser=(state)=>{
    var myHeaders = new Headers();
    let token = localStorage.getItem("token")
    myHeaders.append("authorization", token);
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("email", state.email);

    var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: urlencoded,
    redirect: 'follow'
    };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.deleteUser,requestOptions).then(res=>res.json())
        .then(data=>{
            if(data.status ===1)
            {console.log(data)
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getUser())
                window.location.reload()
            }
            else{
                console.log(data)
                dispatch(updateSuccess(data.message))
                // dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
                dispatch(getUser())
                window.location.reload()
            }
        })
        .catch(err=>{console.log(err)
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}
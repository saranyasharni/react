import {config} from "./API/Services"
import {apiData} from "../../views/ProductList/data"

const Categories =(categories)=>({
    type:"SET_CATEGORIES",
    payload:categories
})

const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})

const setError =error=>({
    type:"ERROR",
    payload:error
})

const updateSuccess=(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})

const updateFailure=(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})

const getAll=()=>({
    type:"GET_ALL",
    payload:""
})

const getEnabled=()=>({
    type:"GET_ENABLED",
    payload:"active"
})

const getDisabled=()=>({
    type:"GET_DISABLED",
    payload:"in-active"
})

const setSubCatList= data=>({
    type:"SET_SUB_CAT_LIST",
    payload:data
})
const listCategory = (data) => ({
    type:"LISTING_CATEGORIES",
    payload:data
})

const categoryList = data => ({
    type:"LIST_CATEGORY",
    payload:data
})

const setCategorySaveMsg = (data) => ({
    type:"SAVE_SET_CAT_MSG",
    payload:data
})

export const saveSubCategory = (data, categoryId) => {
    let subCategory = JSON.stringify(data)
    var myHeaders = new Headers();
    myHeaders.append('authorization', localStorage.getItem('token'));
    var urlencoded = new URLSearchParams();
    urlencoded.append("sub_categories", subCategory);
    urlencoded.append("category_id", categoryId);
    var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: urlencoded,
        redirect: "follow"
    };

    return dispatch => {
        dispatch(SetLoading(true))
        return fetch(config.save_sub_category, requestOptions)
        .then(res=>res.json())
        .then(res => {
            if (res.status === 1) {
                dispatch(updateSuccess(res.message))
                dispatch(SetLoading(false)) 
                dispatch(viewSubCategory(categoryId))
            } else{console.log(res)
                dispatch(updateFailure(res.message)) 
                dispatch(SetLoading(false)) 
            }
        })
    }
}

export const setCategory = data => {
    let category = JSON.stringify(data)
    //console.log(category, 'data')
    var myHeaders = new Headers();
    myHeaders.append('authorization', localStorage.getItem('token'));
    // console.log('token', localStorage.getItem('token'));  
    var urlencoded = new URLSearchParams();
    urlencoded.append("cat_data", category);

    var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: urlencoded,
    redirect: "follow"
    };

    return dispatch => {
        dispatch(SetLoading(true))
        return fetch(config.save_category, requestOptions)
            .then(res => res.json())
            .then(res => {
                if (res.status === 1) {
                    
                    dispatch(updateSuccess(res.message))
                    dispatch(SetLoading(false)) 
                    dispatch(catListing())
                } else {
                    dispatch(updateFailure(res.message)) 
                    dispatch(SetLoading(false)) 
                    dispatch(catListing())
                }
            }).catch(err=>{
                dispatch(updateFailure(err))
                dispatch(SetLoading(false)) 
            })
    }
}

export const filterCategory=(filter)=>{
    return dispatch=>{
        dispatch(SetLoading(true))
        filter==="All"?  dispatch(getAll()):filter==="enabled" ?dispatch(getEnabled()):dispatch(getDisabled())
        dispatch(SetLoading(false))
    }
}

export const getCategories = (value)=>{
    return dispatch=>{  
        dispatch(SetLoading(true))
        return fetch(config.categories,{
            method:"POST"
        }).then(res=>res.json())
        .then(data=>{
            // console.log(apiData,"from getcategories")
            //   dispatch(Categories(apiData))
            //    dispatch(SetLoading(false))
            if(data.status===1){
              
                dispatch(Categories(data.data))
                dispatch(SetLoading(false))
            }
            else{
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        }).catch(err=>{
            dispatch(setError(err))
            // dispatch(Categories(apiData))
                dispatch(SetLoading(false))
        })
    }
}

export const changeStatus=(value)=>{
var myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");
var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: value,
    redirect: 'follow'
  };
    console.log(value,"values")
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.updateCategory,requestOptions).then(res=>res.json())
        .then(data=>{
            console.log(data)
            if (data.status===1) {
                //  dispatch(getCategories(value))
                 dispatch(SetLoading(false)) 
                 window.location.reload()
            }
            else {
                dispatch(updateFailure(data.message))
                dispatch(SetLoading(false))  
            }
         
           
        }).catch(err=>{
            
            dispatch(updateFailure(err))
           
                dispatch(SetLoading(false)) 
        })
    }
}

export const viewSubCategory = data => {
    var myHeaders = new Headers();
    myHeaders.append('authorization', localStorage.getItem('token'));
    var urlencoded = new URLSearchParams();
    urlencoded.append("category_id", data);
    var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: urlencoded,
        redirect: "follow"
    };
    return dispatch => {
        return fetch (config.view_sub_category, requestOptions)
            .then(res => {
                if (res.status === 200) {
                    return res.json();
                }
            })
            .then(res => {
                if (res.status === 1) {
                    dispatch(setSubCatList(res.data))
                }
            })
    }
}

export const catListing = () => {
    var requestOptions = {
        method: "POST",
        redirect: "follow"
    };
    return dispatch => {
        fetch(config.view_category, requestOptions)
        .then(res => res.json())
        .then(data => {
            if (data.status === 1) {
                dispatch(categoryList(data.data));
            }
        }).catch(err => {
            dispatch(setError(err))
          //dispatch(SetLoading(false))
        })
    }
}
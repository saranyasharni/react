import {config} from "./API/Services"
const setWhatsNew=(data)=>({
    type:"SET_WHATSNEW",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})

const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})

export const getWhatsNewData =()=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({slug:"whats_new"}),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.getPageDetails,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // console.log(data,"whats new")
            //    dispatch(setWhatsNew(Aboutdata))
            //    dispatch(SetLoading(false))
            if(data.status ===1){
               dispatch(setWhatsNew(data.data))
               dispatch(SetLoading(false))
               
            }
            else{
                dispatch(setError(data.message))
               dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}

export const updateWhatsNew = (data)=>{
    // console.log(data, 'data789')
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(data),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.updatePageDetails,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            // dispatch(updateSuccess("successfully updated"))
            //    dispatch(SetLoading(false))
            // // dispatch(getAboutData())
            
            // dispatch(updateSuccess(data.message))
            if(data.status ===1)
            {
                
                dispatch(updateSuccess("successfully updated"))
                dispatch(SetLoading(false))
                 dispatch(setWhatsNew(data))
                dispatch(getWhatsNewData())
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}
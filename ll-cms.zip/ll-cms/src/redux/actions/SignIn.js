import {config} from "./API/Services"
import history from '../store/history'
// let token ="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjVlY2E0ZTBlOGNiNDRjM2Q2ZWJkMWY2ZSIsImlhdCI6MTU5MDYyNjk3NSwiZXhwIjoxNTkwNzEzMzc1fQ.KrGwuu2jGTAnTbZ2CgLbxcPOzyIeYLbJ9WCGiiKNdII"
 const AuthSuccess=data=>(
     
    {
     type:"LOGIN_SUCCESS",
      payload:{
          loggedIn:true,
          email:data.email
      }
 })
const AuthFailure =data=>({
    type:"ERORR",
    payload:data
})

const Logout =()=>({
    type:"LOGOUT"
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})

export const  Authentication = (email,password)=>{
    var myHeaders = new Headers();
    console.log(email,password)
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    
    var urlencoded = new URLSearchParams();
    urlencoded.append("email", email);
    urlencoded.append("password", password);
    
    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: urlencoded,
      redirect: 'follow'
    };
    console.log("Called")
    return  dispatch=>{
        
        dispatch(SetLoading(true))
        
        return fetch(config.sigIn,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           
            if(data.status ===1){
                localStorage.setItem("token",data.token)
                console.log(data,"data from signin")
                dispatch(AuthSuccess(data.data))
                dispatch(SetLoading(false))
                history.push("/dashboard")
            }
            else{
                dispatch(AuthFailure(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            // dispatch(AuthSuccess({email:"admin@livelive.com"}))
            dispatch(AuthFailure(err))
                dispatch(SetLoading(false))
                console.log(err)
        })
    }
}

export const LogoutAuth  = (email)=>{
    console.log(email,"email")
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    
    var urlencoded = new URLSearchParams();
    urlencoded.append("email", email);
    
    
    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: urlencoded,
      redirect: 'follow'
    };
    return dispatch=>{
        return fetch(config.signOut,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           
            if(data.status ===1){
                localStorage.removeItem("token")
                dispatch(Logout())
                history.push("/sign-in")
                window.location.reload(true)
            }
            else{
               console.log(data) 
               localStorage.removeItem("token")
               dispatch(Logout())
               history.push("/sign-in")
               window.location.reload(true)
            }
        })
    }
}
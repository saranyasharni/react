import {config} from "./API/Services"
import {jobData} from "../../views/Jobs/components/Data"

const jobsData=(data)=>({
    type:"SET_JOBDATA",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})
const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})
export const getJobs =()=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
       
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.jobsList,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            if(data.status===1){
                dispatch(jobsData(data.data))
                dispatch(SetLoading(false))
             }
            else{
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
           
        })
    }
}

export const updateJobs =(data)=>{
   
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(data),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.updateJobs,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            if(data.status ===1)
            {
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getJobs())
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}

export const addJobs =(data)=>{
   
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(data),
        redirect: 'follow'
      };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.addJobs,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            if(data.status ===1)
            {   console.log(data,"from jobs")
                dispatch(updateSuccess('Created Successfully'))
                dispatch(SetLoading(false))
                dispatch(getJobs())
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    }
}

export const deleteJob =(id)=>{
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({job_id:id}),
        redirect: 'follow'
      };
    return dispatch=>{
        return fetch(config.deleteJobs,requestOptions)
        .then(res=>res.json())
        .then(data=>{
            if(data.status ===1){
                console.log(data)
                dispatch(updateSuccess('Deleted Successfully'))
                dispatch(SetLoading(false))
                dispatch(getJobs()) 
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err))
            dispatch(SetLoading(false))
        })
    
    }
}
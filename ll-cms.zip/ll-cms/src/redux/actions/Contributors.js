import {config} from "./API/Services"
// import Userdata from "../../views/UserList/data"
const userData=(data)=>({
    type:"SET_CONTRIBUTOR",
    payload:data
})
const SetLoading = data=>({
    type:"SET_LOADING",
    payload:data
})
const setError =error=>({
    type:"ERROR",
    payload:error
})
const updateSuccess =(message)=>({
    type:"UPDATE_SUCCESS",
    payload:message
})
const updateFail =(message)=>({
    type:"UPDATE_FAIL",
    payload:message
})
export const getContributors =()=>{
    var myHeaders = new Headers();
//     let token = localStorage.getItem("token")
// myHeaders.append("authorization", token);
myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

// var urlencoded = new URLSearchParams();
// urlencoded.append("email", "admin@livelive.com");

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  redirect: 'follow'
};
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.contributorsList,requestOptions).then(res=>res.json())
        .then(data=>{
            //
            // dispatch(SetLoading(false))
            if(data.status ===1){
                dispatch(userData(data.data))
                console.log(data)
                 dispatch(SetLoading(false))
            }
            else{
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}

export const updateContributors =(state)=>{
    console.log(state,"state")
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: JSON.stringify(state),
  redirect: 'follow'
};
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.updateContributors,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           console.log(data,"cont")
            if(data.status ===1)
            {   
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                dispatch(getContributors())
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err)) 
                dispatch(SetLoading(false))
        })
    }
}

export const list_applications =()=> {
var myHeaders = new Headers();

myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  redirect: 'follow'
};

return dispatch=>{
    dispatch(SetLoading(true))
    return fetch(config.list_applications,requestOptions).then(res=>res.json())
    .then(data=>{
        //
        // dispatch(SetLoading(false))
        if(data.status ===1){
            dispatch(userData(data.data))
            console.log(data)
                dispatch(SetLoading(false))
        }
        else{
            dispatch(setError(data.message))
            dispatch(SetLoading(false))
        }
    })
    .catch(err=>{
        dispatch(setError(err))
        dispatch(SetLoading(false))
    })
    }
}

export const list_subscribers =()=>{
    // console.log(state,"state")
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    //   body: JSON.stringify(state),
    redirect: 'follow'
    };

    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.list_subscribers,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           console.log(data,"cont")
            
            if(data.status ===1){
                dispatch(userData(data.data))
                console.log(data)
                dispatch(SetLoading(false))
            }
            else{
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}

export const advertise_with_us =()=>{
    // console.log(state,"state")
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/json");
    var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    //   body: JSON.stringify(state),
    redirect: 'follow'
    };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.advertise_with_us,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           console.log(data,"cont")
            
            if(data.status ===1){
                dispatch(userData(data.data))
                console.log(data)
                    dispatch(SetLoading(false))
            }
            else{
                dispatch(setError(data.message))
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(setError(err))
            dispatch(SetLoading(false))
        })
    }
}

export const updateAppliedJobs =(state)=>{
    console.log(state,"state")
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    var urlencoded = new URLSearchParams();
    urlencoded.append("application_id", state.contributor_id);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.delete_job_application,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           console.log(data,"cont")
            if (data.status ===1)
            {   
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                // dispatch(list_applications())
                window.location.reload()
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err)) 
                dispatch(SetLoading(false))
        })
    }
}

export const delete_advertisement =(state)=>{
    console.log(state,"state")
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    var urlencoded = new URLSearchParams();
    urlencoded.append("application_id", state.contributor_id);
    
    var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: urlencoded,
  redirect: 'follow'
};
    return dispatch=>{
        dispatch(SetLoading(true))
        return fetch(config.delete_advertisement,requestOptions)
        .then(res=>res.json())
        .then(data=>{
           console.log(data,"cont")
            if(data.status ===1)
            {   
                dispatch(updateSuccess(data.message))
                dispatch(SetLoading(false))
                window.location.reload()
            }
            else{
                dispatch(updateFail(data.message)) 
                dispatch(SetLoading(false))
            }
        })
        .catch(err=>{
            dispatch(updateFail(err)) 
                dispatch(SetLoading(false))
        })
    }
}

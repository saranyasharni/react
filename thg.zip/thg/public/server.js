const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const path = require('path');
const fs = require('fs');
const request_npm = require('request');
const { replace } = require('lodash');

const bodyParser = require("body-parser");
const parseString = require("xml2js").parseString;
const xml2js = require("xml2js");
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// parse application/json
app.use(bodyParser.json());

// const siteUrl = "https://api.thehomeground.asia/api/v1";
const siteUrl = "http://stagingapi.thehomeground.asia/api/v1";

app.get('/404.html', function(request, response) {
    response.sendFile(__dirname + '/404.html');
});

app.get('/sitemap.xml', function(request, response) {
    response.sendFile(__dirname + '/sitemap.xml');
});

app.get('/ads.txt', function(request, response) {
    response.sendFile(__dirname + '/ads.txt');
});

app.get('/google97b0051308b9d090.html', function(request, response) {
    response.sendFile(__dirname + '/google97b0051308b9d090.html');
});

app.get('/', function (request, response) {
    console.log('Home page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');        
            var meta_social_title = 'TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV';
            var meta_social_description = 'TheHomeGround Asia – Latest and trending news and events happening around Asia. Delving deeper to better explain stories. Letting readers voice their opinions. Watch events live.';
            var meta_title = 'TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV';
            var meta_description = 'TheHomeGround Asia – Latest and trending news and events happening around Asia. Delving deeper to better explain stories. Letting readers voice their opinions. Watch events live.';
            var meta_keywords = "Latest news from Singapore, Top news stories from Singapore, Latest Singapore news and headlines, Latest Singapore News & Headlines, Latest News and Updates on Singapore";
            var article_image = 'https://thehomeground.asia/assets/images/thg_567.jpeg'

            data = data.replace(/\$META_TITLE/g, meta_title);
            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);

            data = data.replace(/\$OG_TITLE/g, meta_social_title);
            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
            data = data.replace(/\$OG_IMAGE/g, article_image);
            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
            response.send(result);
        }      
           
    });
});

app.get('/profile/:user', function (request, response) {
    console.log('Profile page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "");
        data = data.replace(/\$META_KEYWORDS/g, "");

        data = data.replace(/\$OG_TITLE/g, "My Profile");
        data = data.replace(/\$OG_DESCRIPTION/g, "My Profile");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
});

app.get('/feature-live-stream/:evnt_id/:slug', function (request, response) {
    console.log('feature-live-stream page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "");
        data = data.replace(/\$META_KEYWORDS/g, "");

        data = data.replace(/\$OG_TITLE/g, "TheHomeGroud Asia");
        data = data.replace(/\$OG_DESCRIPTION/g, "TheHomeGroud Asia");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
});

app.get('/yourarticles/:user', function (request, response) {
    console.log('Your article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_KEYWORDS/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");

        data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$OG_DESCRIPTION/g, "My Articles");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
});

app.get('/events/videos/:id', function (request, response) {
    console.log('Your article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_KEYWORDS/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");

        data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$OG_DESCRIPTION/g, "Event videos");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
});
app.get('/events/photos/:id', function (request, response) {
    console.log('Your article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_KEYWORDS/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");

        data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$OG_DESCRIPTION/g, "Event Photos");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
});
app.get('/category/featured-events/:slug', function (request, response) {
    console.log('Featured event sub!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    // read in the index.html file
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl !== "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null" && request.originalUrl != "/undefined" && request.originalUrl != "/vauchersubscribe" && request.originalUrl != "/contestsubmit" && request.originalUrl != "/contestgiveaway" &&
        request.originalUrl != "/contest" && request.originalUrl != "/all-submissions" && 
        request.originalUrl != "/contest-winner" && request.originalUrl != "/editors-pick" &&
        request.originalUrl != "/giveaway-winner" && request.originalUrl != "/search" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/logo192.png" && request.originalUrl != '/sockjs-node'
        ) {
            console.log('came here1')
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[3];
            console.log(split_path, 'split_path')
            if (remove_slug_slash.length > 0) {
                try {
                    console.log('came here2')
                    request_npm.post(siteUrl+'/article_detail', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            user_id: 0,
                            page_no: 0,
                            limit: 1,
                            slug: split_path
                        }
                    }, async (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }
                        console.log('came here3')
                        var res = { body: JSON.parse(httpResponse.body) };
                        console.log('RESPONSE00', res   )

                        if (res.body.status == 1 && res.body.data.length > 0 && res.body.data[0].ID !== null ) {
                            
                            var description = res.body.data[0].post_content.substring(0, 300);
                            var description2 = description.replace(/<[^>]*>/g, '');

                            if (res.body.data[0].swp_og_title == null) {
                                var meta_social_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.data[0].swp_og_title;
                            }

                            if (res.body.data[0].aioseop_keywords == '' && res.body.data[0].aioseop_keywords == null) {
                                var meta_keywords = 'THG'
                            } else {
                                var meta_keywords = res.body.data[0].aioseop_keywords
                            }

                            var substr_content = meta_social_title;
                            if (res.body.data[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.data[0].swp_og_description;
                            }

                            if (res.body.data[0].aioseop_title == null || res.body.data[0].aioseop_title == "") {
                                var meta_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_title = res.body.data[0].aioseop_title;
                            }

                            if (res.body.data[0].aioseop_description == null || res.body.data[0].aioseop_description == "") {
                                var meta_description = description2;
                            } else {
                                var meta_description = res.body.data[0].aioseop_description;
                            }
                           
                            if (res.body.data[0].custom_feature_image_url != "") {
                                let img = res.body.data[0].custom_feature_image_url.split('/');
                                let appendStr = img[0]+'//'+img[2]+'/md_'+img[3];
                                let checkMdImg = await apiOn(appendStr);
                                let appendStr2 = img[0]+'//'+img[2]+'/sm_'+img[3];
                                let checkMdImg2 = await apiOn(appendStr2);
                                let appendStr3 = img[0]+'//'+img[2]+'/mb_app_'+img[3];
                                let checkMdImg3 = await apiOn(appendStr3);
                                console.log("checkMdImg", checkMdImg)
                                console.log("checkMdImg2", checkMdImg2)
                                console.log("checkMdImg3", checkMdImg3)
                                if (checkMdImg === 200) {
                                    var featured_image = appendStr;
                                } else if (checkMdImg2 === 200) {
                                    var featured_image = appendStr2;
                                } else if (checkMdImg3 === 200) {
                                    var featured_image = appendStr3;
                                } else {
                                    var featured_image = res.body.data[0].custom_feature_image_url;
                                }
                                console.log(featured_image, 'featured_image')
                                //var featured_image =  appendStr
                            } else {
                                var featured_image = res.body.data[0].image_url ? res.body.data[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.data[0].swp_og_image_url != null && res.body.data[0].swp_og_image_url != "") {
                                var article_image = res.body.data[0].swp_og_image_url;
                            } else { 
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }
                        else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            response.send(result);
        }
    });
})
app.get('/category/:slug/:subSlug', function (request, response) {
    console.log('Sub Category page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[3];

            if (remove_slug_slash.length > 0) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_meta_details', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            slug: split_path
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        // console.log('result', JSON.parse(httpResponse.body))
                        var res = { body: JSON.parse(httpResponse.body) };

                        if (res.body.result.length > 0 && res.body.status == 1) {

                            if (res.body.result[0].swp_og_title == null) {
                                var meta_social_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.result[0].swp_og_title;
                            }

                            if (res.body.result[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.result[0].swp_og_description;
                            }

                            if (res.body.result[0].aioseop_title == null || res.body.result[0].aioseop_title == "") {
                                if (split_path == 'sports') {
                                    var meta_title = "Free Watch Football Online | Live Sky Sports Streaming Site";
                                } else if (split_path == 'travel') {
                                    var meta_title = "THG - Singapore Tourism Board | Online Travel News ";
                                } else {
                                    var meta_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                                }

                            } else {
                                var meta_title = res.body.result[0].aioseop_title;
                            }

                            if (res.body.result[0].aioseop_description == null || res.body.result[0].aioseop_description == "") {
                                if (split_path == 'sports') {
                                    var meta_description = "Watch Football live streaming free. THG provides you with the best possible coverage for the major sport events worldwide. Get live sports streaming updates online.";
                                } else if (split_path == 'travel') {
                                    var meta_description = "Get Singapore’s online travel news on THG and check daily updates. All the latest breaking news on Singapore travel. Browse and see the complete collection of travels daily updates.";
                                } else {
                                    var meta_description = meta_social_description;
                                }
                            } else {
                                var meta_description = res.body.result[0].aioseop_description;
                            }

                            if (res.body.result[0].aioseop_keywords == null || res.body.result[0].aioseop_keywords == "") {
                                if (split_path == 'sports') {
                                    var meta_keywords = "watch football online, live sport stream, live stream sports, free sports streaming sites, sky sports live stream, free football streaming, best football streaming sites watch football online free, watch sports online, free sports streaming";
                                } else if (split_path == 'lifestle') {
                                    var meta_keywords = "online travel news, singapore travel news, singapore tourism board";
                                } else {
                                    var meta_keywords = "online travel news, singapore travel news, singapore tourism board"
                                }

                            } else {
                                var meta_keywords = res.body.result[0].aioseop_keywords;
                            }

                            if (res.body.result[0].custom_feature_image_url != "") {
                                var featured_image = res.body.result[0].custom_feature_image_url;
                            } else {
                                var featured_image = res.body.result[0].image_url ? res.body.result[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.result[0].swp_og_image_url != null && res.body.result[0].swp_og_image_url != "") {
                                var article_image = res.body.result[0].swp_og_image_url;
                            } else {
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);

                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            console.log('ingatha')
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
});

app.get('/bookmarklist/:user', function (request, response) {
    console.log('Settings article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "");
        data = data.replace(/\$META_KEYWORDS/g, "");

        data = data.replace(/\$OG_TITLE/g, "My Bookmarks");
        data = data.replace(/\$OG_DESCRIPTION/g, "Bookmarklist");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
});

app.get('/category/whats_happening', function (request, response) {
    console.log('whats happing page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[3];

            if (remove_slug_slash.length > 0) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/whats_happen_banner', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        // form: {
                        //     slug: split_path
                        // }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = JSON.parse(httpResponse.body);
                        console.log('result', res.data)

                        if (res.data[0] && res.data[0].ID !== null) {
                            // console.log('not here')
                            if (res.data[0].post_title !== null && res.data[0].post_title !== '') {
                                var meta_social_title = res.data[0].post_title;
                            } else {
                                var meta_social_title = 'Whats happening'
                            }

                            if (res.data[0].post_content !== null && res.data[0].post_content !== '') {
                                var meta_social_description = res.data[0].post_content.substring(0, 40);
                                
                            } else {
                                var meta_social_description = meta_social_title;
                            }
                            
                            var meta_title = meta_social_title;
                            
                            var meta_description = meta_social_description;
                            var meta_keywords = meta_social_description;

                            if (res.data[0].custom_feature_image_url !== ""
                                && res.data[0].custom_feature_image_url !== null
                            ) {
                                var featured_image = res.data[0].custom_feature_image_url;
                            } else if (res.data[0].image_url !== ""
                                && res.data[0].image_url !== null
                            ) {
                                var featured_image = res.data[0].image_url;
                            } else {
                                var featured_image = res.data[0].thumbnail_image ? 
                                res.data[0].thumbnail_image : '';
                            }
                            
                            var article_image = featured_image;
                            
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            console.log('came here')
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})

app.get('/category/:slug', function (request, response) {
    console.log('category alone page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    // read in the index.html file
    fs.readFile(filePath, 'utf8', function (err, data) {

        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[2];

            if (remove_slug_slash.length > 0) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_meta_details', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            slug: split_path
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        // console.log('result', JSON.parse(httpResponse.body))
                        var res = { body: JSON.parse(httpResponse.body) };

                        if (res.body.result.length > 0 && res.body.status == 1) {

                            if (res.body.result[0].swp_og_title == null) {
                                var meta_social_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.result[0].swp_og_title;
                            }

                            if (res.body.result[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.result[0].swp_og_description;
                            }

                            if (res.body.result[0].aioseop_title == null || res.body.result[0].aioseop_title == "") {
                                if (split_path == 'sports') {
                                    var meta_title = "Free Watch Football Online | Live Sky Sports Streaming Site";
                                } else if (split_path == 'travel') {
                                    var meta_title = "THG - Singapore Tourism Board | Online Travel News ";
                                } else {
                                    var meta_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                                }

                            } else {
                                var meta_title = res.body.result[0].aioseop_title;
                            }

                            if (res.body.result[0].aioseop_description == null || res.body.result[0].aioseop_description == "") {
                                if (split_path == 'sports') {
                                    var meta_description = "Watch Football live streaming free. THG provides you with the best possible coverage for the major sport events worldwide. Get live sports streaming updates online.";
                                } else if (split_path == 'travel') {
                                    var meta_description = "Get Singapore’s online travel news on THG and check daily updates. All the latest breaking news on Singapore travel. Browse and see the complete collection of travels daily updates.";
                                } else {
                                    var meta_description = meta_social_description;
                                }
                            } else {
                                var meta_description = res.body.result[0].aioseop_description;
                            }

                            if (res.body.result[0].aioseop_keywords == null || res.body.result[0].aioseop_keywords == "") {
                                if (split_path == 'sports') {
                                    var meta_keywords = "watch football online, live sport stream, live stream sports, free sports streaming sites, sky sports live stream, free football streaming, best football streaming sites watch football online free, watch sports online, free sports streaming";
                                } else if (split_path == 'lifestle') {
                                    var meta_keywords = "online travel news, singapore travel news, singapore tourism board";
                                } else {
                                    var meta_keywords = "online travel news, singapore travel news, singapore tourism board"
                                }

                            } else {
                                var meta_keywords = res.body.result[0].aioseop_keywords;
                            }

                            if (res.body.result[0].custom_feature_image_url != "") {
                                var featured_image = res.body.result[0].custom_feature_image_url;
                            } else {
                                var featured_image = res.body.result[0].image_url ? res.body.result[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.result[0].swp_og_image_url != null && res.body.result[0].swp_og_image_url != "") {
                                var article_image = res.body.result[0].swp_og_image_url;
                            } else {
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } 
                        // else if (request.params.slug == 'whats_happening') {
                            
                        //     data = data.replace(/\$META_TITLE/g, request.params.slug);
                        //     data = data.replace(/\$META_DESCRIPTION/g, "Players on the track for the championship");
                        //     data = data.replace(/\$META_KEYWORDS/g, 'whats happening');
                        //     data = data.replace(/\$OG_TITLE/g, "Players on the track for the championship");
                                
                        //     data = data.replace(/\$OG_DESCRIPTION/g, "Players on the track for the championship");
                        //     data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                        //     result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                        //     response.send(result);
                        // } 
                        else if (request.params.slug == 'thg-tv') {
                                console.log('under thg_tv')
                                data = data.replace(/\$META_TITLE/g, request.params.slug);
                                data = data.replace(/\$META_DESCRIPTION/g, meta_social_description);
                                data = data.replace(/\$META_KEYWORDS/g, 'thg TV');
                                data = data.replace(/\$OG_TITLE/g, "Easiest Japanese Popular Breakfast 1");
                                data = data.replace(/\$OG_DESCRIPTION/g, "Easiest Japanese Popular Breakfast 1");
                                data = data.replace(/\$OG_IMAGE/g, 'https://static-cdn.espx.cloud/userstorage/bf01b389-16cc-46ed-94cd-35d151cefde2/4VLf52VN8VZE1b2W.jpg');
                                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                                response.send(result);
                            } else if (request.params.slug == 'reel') {
                                data = data.replace(/\$META_TITLE/g, request.params.slug);
                                data = data.replace(/\$META_DESCRIPTION/g, "reel");
                                data = data.replace(/\$META_KEYWORDS/g, 'reel');
                                data = data.replace(/\$OG_TITLE/g, "reel");
                                data = data.replace(/\$OG_DESCRIPTION/g, "reel");
                                data = data.replace(/\$OG_IMAGE/g, 'https://thgtv-image-upload.s3.ap-southeast-1.amazonaws.com/1596882998442_tennis-origins-e1444901660593.jpg');
                                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                                response.send(result);
                            } else if (request.params.slug == 'thg_school') {
                                data = data.replace(/\$META_TITLE/g, request.params.slug);
                                data = data.replace(/\$META_DESCRIPTION/g, "THG School");
                                data = data.replace(/\$META_KEYWORDS/g, "THG School");
                                data = data.replace(/\$OG_TITLE/g, "THG School");
                                data = data.replace(/\$OG_DESCRIPTION/g, "THG School");
                                data = data.replace(/\$OG_IMAGE/g, 'https://thgtv-image-upload.s3.ap-southeast-1.amazonaws.com/1596882998442_tennis-origins-e1444901660593.jpg');
                                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                                response.send(result);
                            } else if (request.params.slug == 'featured-events') {
                                data = data.replace(/\$META_TITLE/g, request.params.slug);
                                data = data.replace(/\$META_DESCRIPTION/g, "featured events");
                                data = data.replace(/\$META_KEYWORDS/g, "featured-events");
                                data = data.replace(/\$OG_TITLE/g, "featured-events");
                                data = data.replace(/\$OG_DESCRIPTION/g, "featured-events");
                                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                                response.send(result);
                            } 
                            
                            else {
                                response.sendFile(__dirname + '/404.html');
                            }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
});

function apiOn(url) {
    return new Promise(resolve => {
      request_npm.get(url, (error, httpResponse, body) => {
          if(error) resolve(httpResponse.statusCode)
          resolve(httpResponse.statusCode)
      })
    });
}

app.get('/whats_happening/:slug', function (request, response) {
    console.log('whats happen article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    // read in the index.html file
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/contribute-with-us" && request.originalUrl != "/reach-us" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/subscribe" && request.originalUrl != "/data-protection-policy" && request.originalUrl != "/terms-conditions" && request.originalUrl != "/advertise-with-us" && request.originalUrl != "/null") {

            var original_link = request.originalUrl;
            console.log(original_link, "original_link")
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[2];

            if (remove_slug_slash.length > 0) {
                try {

                    request_npm.post(siteUrl+'/whats_happen_by_slug', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            user_id: 0,
                            page_no: 0,
                            limit: 1,
                            slug: split_path
                        }
                    }, async (error, httpResponse, body) => {
                    
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = { body: JSON.parse(httpResponse.body) };
                        //console.log(res.body.data, 'res@#$')
                        if (res.body.status === 1 && res.body.data.length > 0 && res.body.data[0].ID !== null) {
                            var description = res.body.data[0].post_content.substring(0, 300);
                            var description2 = description.replace(/<[^>]*>/g, '');

                            if (res.body.data[0].swp_og_title == null) {
                                var meta_social_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.data[0].swp_og_title;
                            }

                            if (res.body.data[0].aioseop_keywords && res.body.data[0].aioseop_keywords == '' && res.body.data[0].aioseop_keywords == null) {
                                var meta_keywords = 'THG Events'
                            } else {
                                var meta_keywords = 'THG Events'
                            }

                            var substr_content = meta_social_title;

                            if (res.body.data[0].venue == null) {
                                var meta_social_venue = null;
                            } else {
                                var meta_social_venue = res.body.data[0].venue;
                            }

                            if (res.body.data[0].start_date_and_time !== []) {
                                let day = res.body.data[0].start_date_and_time[0].split(' ')[0]
                                const start_day = new Date(day)
                                let startMonth = start_day.toLocaleString('default', { month: 'short' })
                                // console.log(res.body.data[0].start_date_and_time[0].split('-'), "TODAY")
                                let start = res.body.data[0].start_date_and_time[0].split('-')[2].split(' ')[0] +' '+ startMonth + ' ' + res.body.data[0].start_date_and_time[0].split('-')[0]
                                //console.log(start, "STARTt9089")
                                var end = start;
                               
                                    if (res.body.data[0].end_date_and_time[0] !== '') {
                                        let day1 = res.body.data[0].end_date_and_time[0].split(' ')[0]
                                        let end_date = new Date(day1)
                                        let endMonth = end_date.toLocaleString('default', { month: 'short' })
                                        var end = start + " - " + res.body.data[0].end_date_and_time[0].split('-')[2].split(' ')[0] +' '+ endMonth + ' ' + res.body.data[0].end_date_and_time[0].split('-')[0]
                                    } else {
                                        var end = start
                                    }
                                
                                
                                //console.log(end, 'FINALTEST')
                                var meta_social_date_of_event = end
                                
                            } else {
                                var meta_social_date_of_event = '';
                            }

                            if (res.body.data[0].swp_og_title == null || res.body.data[0].swp_og_title == "") {
                                var meta_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_title = res.body.data[0].swp_og_title;
                            }

                            if (res.body.data[0].swp_og_description == null || res.body.data[0].swp_og_description == "") {
                                var meta_description = description2;
                            } else {
                                var meta_description = res.body.data[0].swp_og_description;
                            }

                            if (res.body.data[0].custom_feature_image_url != "") {
                                let img = res.body.data[0].custom_feature_image_url.split('/');
                                let appendStr = img[0]+'//'+img[2]+'/md_'+img[3];
                                let checkMdImg = await apiOn(appendStr);
                                let appendStr2 = img[0]+'//'+img[2]+'/sm_'+img[3];
                                let checkMdImg2 = await apiOn(appendStr2);
                                let appendStr3 = img[0]+'//'+img[2]+'/mb_app_'+img[3];
                                let checkMdImg3 = await apiOn(appendStr3);
                                console.log("checkMdImg", checkMdImg)
                                console.log("checkMdImg2", checkMdImg2)
                                console.log("checkMdImg3", checkMdImg3)
                                if (checkMdImg === 200) {
                                    var featured_image = appendStr;
                                }else if (checkMdImg2 === 200) {
                                    var featured_image = appendStr2;
                                }else if (checkMdImg3 === 200) {
                                    var featured_image = appendStr3;
                                } else {
                                    var featured_image = res.body.data[0].custom_feature_image_url;
                                }
                                
                                console.log("featured_image", featured_image)
                               // var featured_image = img_replace;
                            } else {
                                var featured_image = res.body.data[0].image_url ? res.body.data[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.data[0].swp_og_image_url != null && res.body.data[0].swp_og_image_url != "") {
                                var article_image = res.body.data[0].swp_og_image_url;
                            } else {
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g,  
                            'DATE' + ": " + meta_social_date_of_event
                            + "; " +
                            
                            'VENUE' + ": " + meta_social_venue);
                            data = data.replace(/\$OG_DATE/g, meta_social_date_of_event);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            response.send(result);
        }
    });
});
app.get('/contest', function (request, response) {
    console.log('Contest page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[3];

            if (remove_slug_slash.length > 0) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_featured_contest', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            page_no: 0,
                            limit: 4
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = JSON.parse(httpResponse.body);
                        // console.log('result', res.result)

                        if (res.result !== [] && res.result[0] && res.result[0].post_id !== null) {
                            // console.log('not here')
                            if (res.result[0].post_title !== null && res.result[0].post_title !== '') {
                                var meta_social_title = res.result[0].post_title;
                            } else {
                                var meta_social_title = 'Contest'
                            }

                            if (res.result[0].post_content !== null && res.result[0].post_content !== '') {
                                var meta_social_description = res.result[0].post_content.substring(0, 40);
                                
                            } else {
                                var meta_social_description = meta_social_title;
                            }
                            
                            var meta_title = meta_social_title;
                            
                            var meta_description = meta_social_description;
                            var meta_keywords = meta_social_description;

                            if (res.result[0].custom_featured_image_url !== ""
                                && res.result[0].custom_featured_image_url !== null
                                && res.result[0].custom_featured_image_url !== undefined
                            ) {
                                var featured_image = res.result[0].custom_featured_image_url;
                            } else if (res.result[0].giveaway_thumbnail_image_url !== ""
                                && res.result[0].giveaway_thumbnail_image_url !== null
                            ) {
                                var featured_image = res.result[0].giveaway_thumbnail_image_url;
                            } else {
                                var featured_image = res.result[0].thumbnail_image_url ? 
                                res.result[0].thumbnail_image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }
                            
                            var article_image = featured_image;
                            
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            data = data.replace(/\$META_TITLE/g, "TheHomeGround Contest");
                            data = data.replace(/\$META_DESCRIPTION/g, "Contest");
                            data = data.replace(/\$META_KEYWORDS/g, "Contest");

                            data = data.replace(/\$OG_TITLE/g, "Contest");
                            data = data.replace(/\$OG_DESCRIPTION/g, "Contest");
                            data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
                            response.send(result);
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})

app.get('/productDetail/:id', function (request, response) {
    console.log('create article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "Product Detail");
        data = data.replace(/\$META_KEYWORDS/g, "Product Detail");

        data = data.replace(/\$OG_TITLE/g, "Product Detail");
        data = data.replace(/\$OG_DESCRIPTION/g, "Product Detail");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);
    });
})

app.get('/contest-winner', function (request, response) {
    console.log('Profile page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "contest-winner");
        data = data.replace(/\$META_KEYWORDS/g, "contest-winner");

        data = data.replace(/\$OG_TITLE/g, "contest-winner");
        data = data.replace(/\$OG_DESCRIPTION/g, "contest-winner");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
})

app.get('/giveaway-winner', function (request, response) {
    console.log('giveaway-winner page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "giveaway-winner");
        data = data.replace(/\$META_KEYWORDS/g, "giveaway-winner");

        data = data.replace(/\$OG_TITLE/g, "giveaway-winner");
        data = data.replace(/\$OG_DESCRIPTION/g, "giveaway-winner");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
})

app.get('/contestsubmit/:post_id', function (request, response) {
    console.log('contest submit page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            
            var split_path = original_link.split('/')[2];
            console.log(split_path)
            if (split_path) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_contest_detail', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            post_id:split_path
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = JSON.parse(httpResponse.body);
                        console.log('result', res.result)

                        if (res.result && res.result[0].ID !== null) {
                            // console.log('not here')
                            if (res.result[0].post_title !== null && res.result[0].post_title !== '') {
                                var meta_social_title = res.result[0].post_title;
                            } else {
                                var meta_social_title = 'Contest'
                            }

                            if (res.result[0].post_content !== null && res.result[0].post_content !== '') {
                                var meta_social_description = res.result[0].post_content.substring(0, 40);
                                
                            } else {
                                var meta_social_description = meta_social_title;
                            }
                            
                            var meta_title = meta_social_title;
                            
                            var meta_description = meta_social_description;
                            var meta_keywords = meta_social_description;

                            if (res.result[0].image_url !== ""
                                && res.result[0].image_url !== null
                                && res.result[0].image_url !== undefined
                            ) {
                                var featured_image = res.result[0].custom_feat_image_url;
                            } else {
                                var featured_image = res.result[0].image_url;
                            }
                            
                            var article_image = featured_image;
                            
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            console.log('came here')
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})

app.get('/contestgiveaway/:post_id', function (request, response) {
    console.log('contest giveaway page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            
            var split_path = original_link.split('/')[2];
            console.log(split_path)
            if (split_path) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_giveaway_list', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            post_id:split_path
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = JSON.parse(httpResponse.body);
                        console.log('result', res.result)

                        if (res.result.give_away && res.result.give_away[0].ID !== null) {
                            // console.log('not here')
                            if (res.result.give_away[0].post_title !== null && res.result.give_away[0].post_title !== '') {
                                var meta_social_title = res.result.give_away[0].post_title;
                            } else {
                                var meta_social_title = 'Contest Giveaway'
                            }

                            if (res.result.give_away[0].post_content !== null && res.result.give_away[0].post_content !== '') {
                                var meta_social_description = res.result.give_away[0].post_content.substring(0, 40);
                                
                            } else {
                                var meta_social_description = meta_social_title;
                            }
                            
                            var meta_title = meta_social_title;
                            
                            var meta_description = meta_social_description;
                            var meta_keywords = meta_social_description;

                            if (res.result.give_away[0].image_url !== ""
                                && res.result.give_away[0].image_url !== null
                                && res.result.give_away[0].image_url !== undefined
                            ) {
                                var featured_image = res.result.give_away[0].image_url;
                            } else {
                                var featured_image = 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }
                            
                            var article_image = featured_image;
                            
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            console.log('came here')
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})
app.get('/all-submissions', function (request, response) {
    console.log('Profile page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }
        let og_img = "https://thehomeground.asia/assets/images/thg_567.jpeg"
        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "all-submissions");
        data = data.replace(/\$META_KEYWORDS/g, "all-submissions");

        data = data.replace(/\$OG_TITLE/g, "all-submissions");
        data = data.replace(/\$OG_DESCRIPTION/g, "all-submissions");
        data = data.replace(/\$OG_IMAGE/g, og_img);
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
})

app.get('/episodes/:slug/:subSlug', function (request, response) {
    console.log('Episodes page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            
            var split_path = original_link.split('/')[3];
            console.log(original_link)
            if (split_path) {
                try {
                    request_npm.get(`https://api.live2.asia/api/v1/events/${split_path}`, {
                        headers: {
                            "Content-type": "application/json; charset=UTF-8",
                            "x-app-id": "7386573047397500",
                            
                        },
                        
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = JSON.parse(httpResponse.body);
                        console.log('result', res)

                        if (res && res.id !== null && res.id !== '') {
                            // console.log('not here')
                            if (res.name !== null && res.name !== '') {
                                var meta_social_title = res.name;
                            } else {
                                var meta_social_title = 'Episode name '
                            }
                           
                            if (res.Programmes && res.Programmes[0].name !== null && res.Programmes[0].name !== '') {
                                
                                var meta_social_description = res.Programmes[0].name.substring(0,100)
                                
                            } else {
                                var meta_social_description = meta_social_title;
                            }
                            
                            var meta_title = meta_social_title;
                            
                            var meta_description = meta_social_description;
                            var meta_keywords = meta_social_description;

                            if (res.img_url !== ""
                                && res.img_url !== null
                                && res.img_url !== undefined
                            ) {
                                var featured_image = res.img_url;
                            } else {
                                var featured_image = 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }
                            
                            var article_image = featured_image;
                            
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
                            data = data.replace(/\$META_DESCRIPTION/g, "Episodes in THG TV");
                            data = data.replace(/\$META_KEYWORDS/g, "Episodes in THG TV");

                            data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
                            data = data.replace(/\$OG_DESCRIPTION/g, "Episodes in THG TV");
                            data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
                            response.send(result);
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });

    // fs.readFile(filePath, 'utf8', function (err, data) {
    //     if (err) {
    //         return console.log(err);
    //     }
    //     data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
    //     data = data.replace(/\$META_DESCRIPTION/g, "Episodes in THG TV");
    //     data = data.replace(/\$META_KEYWORDS/g, "Episodes in THG TV");

    //     data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
    //     data = data.replace(/\$OG_DESCRIPTION/g, "Episodes in THG TV");
    //     data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
    //     result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
    //     response.send(result);

    // });
})

app.get('/thgtvdetail/:slug/:subId', function (request, response) {
    console.log('thgtv detail page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            
            var split_path = original_link.split('/')[3];
            var sub_split_path = split_path.split('&&&')[0]
            // console.log(split_path, 'split_path')
            // console.log(sub_split_path, 'sub_split_path')
            if (sub_split_path) {
                try {
                    request_npm.get(`https://api.live2.asia/api/v1/programmes/${sub_split_path}`, {
                        headers: {
                            "Content-type": "application/json; charset=UTF-8",
                            "x-app-id": "7386573047397500",
                          
                        },
                        
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = JSON.parse(httpResponse.body);
                        console.log('result', res)

                        if (res && res.id !== null && res.id !== '') {
                            // console.log('not here')
                            if (res.name !== null && res.name !== '') {
                                var meta_social_title = res.name;
                            } else {
                                var meta_social_title = 'video detail '
                            }

                            if (res.Events && res.Events[0].name && res.Events[0].name !== null && res.Events[0].name !== '') {
                                var meta_social_description = res.Events[0].name.substring(0, 40);
                                
                            } else {
                                var meta_social_description = meta_social_title;
                            }
                            
                            var meta_title = meta_social_title;
                            
                            var meta_description = meta_social_description;
                            var meta_keywords = meta_social_description;

                            if (res.img_url !== ""
                                && res.img_url !== null
                                && res.img_url !== undefined
                            ) {
                                var featured_image = res.img_url;
                            } else {
                                var featured_image = 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }
                            
                            var article_image = featured_image;
                            
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            data = data.replace(/\$META_TITLE/g, "THG TV Detail");
                            data = data.replace(/\$META_DESCRIPTION/g, 'THG TV Detail');
                            data = data.replace(/\$META_KEYWORDS/g, 'THG TV Detail');
                            data = data.replace(/\$OG_TITLE/g, 'THG TV Detail');
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, '');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})
app.get('/createarticle/:user', function (request, response) {
    console.log('create article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "Article create");
        data = data.replace(/\$META_KEYWORDS/g, "Article Create");

        data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$OG_DESCRIPTION/g, "CREATE ARTICLE");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
})
app.get('/bookmarkarticles/:bucket', function (request, response) {
    console.log('create article page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "Bookmark Articles");
        data = data.replace(/\$META_KEYWORDS/g, "Bookmark Articles");

        data = data.replace(/\$OG_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$OG_DESCRIPTION/g, "Bookmark Articles");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
})

app.get('/onthepitch', function (request, response) {
    console.log('Onthepitch page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[2];
            // console.log(split_path, 'split_path')
            if (remove_slug_slash.length > 0) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_meta_details', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            slug: split_path
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = { body: JSON.parse(httpResponse.body) };
                        console.log('result', res.body.result)

                        if (res.body.result.length > 0 && res.body.status == 1) {

                            if (res.body.result[0].swp_og_title == null) {
                                var meta_social_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.result[0].swp_og_title;
                            }

                            if (res.body.result[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.result[0].swp_og_description;
                            }

                            if (res.body.result[0].aioseop_title == null || res.body.result[0].aioseop_title == "") {
                                
                                var meta_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                                
                            } else {
                                var meta_title = res.body.result[0].aioseop_title;
                            }

                            if (res.body.result[0].aioseop_description == null || res.body.result[0].aioseop_description == "") {
                               
                                var meta_description = meta_social_description;
                               
                            } else {
                                var meta_description = res.body.result[0].aioseop_description;
                            }

                            if (res.body.result[0].aioseop_keywords == null || res.body.result[0].aioseop_keywords == "") {
                                
                            var meta_keywords = "online travel news, singapore travel news, singapore tourism board"
                                
                            } else {
                                var meta_keywords = res.body.result[0].aioseop_keywords;
                            }

                            if (res.body.result[0].custom_feature_image_url != "") {
                                var featured_image = res.body.result[0].custom_feature_image_url;
                            } else {
                                var featured_image = res.body.result[0].image_url ? res.body.result[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.result[0].swp_og_image_url != null && res.body.result[0].swp_og_image_url != "") {
                                var article_image = res.body.result[0].swp_og_image_url;
                            } else {
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})

app.get('/editors-pick', function (request, response) {
    console.log('Profile page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        data = data.replace(/\$META_TITLE/g, "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV");
        data = data.replace(/\$META_DESCRIPTION/g, "editors-pick");
        data = data.replace(/\$META_KEYWORDS/g, "editors-pick");

        data = data.replace(/\$OG_TITLE/g, "editors-pick");
        data = data.replace(/\$OG_DESCRIPTION/g, "editors-pick");
        data = data.replace(/\$OG_IMAGE/g, "https://thehomeground.asia/assets/images/thg_567.jpeg");
        result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + "");
        response.send(result);

    });
})
app.get('/reel/:slug', function (request, response) {
    console.log('reel Sub Category page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/discover-hong-kong" && request.originalUrl != "/singapore-tourism-board" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null") {

            console.log('if', request.originalUrl)
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[2];
            // console.log(split_path, 'split_path')
            if (remove_slug_slash.length > 0) {
                try {
                    console.log('hi')
                    request_npm.post(siteUrl+'/get_meta_details', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            slug: split_path
                        }
                    }, (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        // console.log('result', JSON.parse(httpResponse.body))
                        var res = { body: JSON.parse(httpResponse.body) };

                        if (res.body.result.length > 0 && res.body.status == 1) {

                            if (res.body.result[0].swp_og_title == null) {
                                var meta_social_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.result[0].swp_og_title;
                            }

                            if (res.body.result[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.result[0].swp_og_description;
                            }

                            if (res.body.result[0].aioseop_title == null || res.body.result[0].aioseop_title == "") {
                                if (split_path == 'sports') {
                                    var meta_title = "Free Watch Football Online | Live Sky Sports Streaming Site";
                                } else if (split_path == 'travel') {
                                    var meta_title = "THG - Singapore Tourism Board | Online Travel News ";
                                } else {
                                    var meta_title = res.body.result[0].post_title ? res.body.result[0].post_title : '';
                                }

                            } else {
                                var meta_title = res.body.result[0].aioseop_title;
                            }

                            if (res.body.result[0].aioseop_description == null || res.body.result[0].aioseop_description == "") {
                                if (split_path == 'sports') {
                                    var meta_description = "Watch Football live streaming free. THG provides you with the best possible coverage for the major sport events worldwide. Get live sports streaming updates online.";
                                } else if (split_path == 'travel') {
                                    var meta_description = "Get Singapore’s online travel news on THG and check daily updates. All the latest breaking news on Singapore travel. Browse and see the complete collection of travels daily updates.";
                                } else {
                                    var meta_description = meta_social_description;
                                }
                            } else {
                                var meta_description = res.body.result[0].aioseop_description;
                            }

                            if (res.body.result[0].aioseop_keywords == null || res.body.result[0].aioseop_keywords == "") {
                                if (split_path == 'sports') {
                                    var meta_keywords = "watch football online, live sport stream, live stream sports, free sports streaming sites, sky sports live stream, free football streaming, best football streaming sites watch football online free, watch sports online, free sports streaming";
                                } else if (split_path == 'lifestle') {
                                    var meta_keywords = "online travel news, singapore travel news, singapore tourism board";
                                } else {
                                    var meta_keywords = "online travel news, singapore travel news, singapore tourism board"
                                }

                            } else {
                                var meta_keywords = res.body.result[0].aioseop_keywords;
                            }

                            if (res.body.result[0].custom_feature_image_url != "") {
                                var featured_image = res.body.result[0].custom_feature_image_url;
                            } else {
                                var featured_image = res.body.result[0].image_url ? res.body.result[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.result[0].swp_og_image_url != null && res.body.result[0].swp_og_image_url != "") {
                                var article_image = res.body.result[0].swp_og_image_url;
                            } else {
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);

                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }   else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            console.log('else', request.originalUrl)
            response.send(result);
        }
    });
})

app.get('/videodetail/:slug', function (request, response) {
    console.log('VideoDetail page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    // read in the index.html file
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl !== "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null" && request.originalUrl != "/undefined" && request.originalUrl != "/vauchersubscribe" && request.originalUrl != "/contestsubmit" && request.originalUrl != "/contestgiveaway" &&
        request.originalUrl != "/contest" && request.originalUrl != "/all-submissions" && 
        request.originalUrl != "/contest-winner" && request.originalUrl != "/editors-pick" &&
        request.originalUrl != "/giveaway-winner"
        ) {
            console.log('came here1')
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[2];

            if (remove_slug_slash.length > 0) {
                try {
                    console.log('came here2')
                    request_npm.post(siteUrl+'/article_detail', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            user_id: 0,
                            page_no: 0,
                            limit: 1,
                            slug: split_path
                        }
                    }, async (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }
                        console.log('came here3')
                        var res = { body: JSON.parse(httpResponse.body) };
                        console.log('RESPONSE00', res   )

                        if (res.body.status == 1 && res.body.data.length > 0 && res.body.data[0].ID !== null ) {
                            
                            var description = res.body.data[0].post_content.substring(0, 300);
                            var description2 = description.replace(/<[^>]*>/g, '');

                            if (res.body.data[0].swp_og_title == null) {
                                var meta_social_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.data[0].swp_og_title;
                            }

                            if (res.body.data[0].aioseop_keywords == '' && res.body.data[0].aioseop_keywords == null) {
                                var meta_keywords = 'THG'
                            } else {
                                var meta_keywords = res.body.data[0].aioseop_keywords
                            }

                            var substr_content = meta_social_title;
                            if (res.body.data[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.data[0].swp_og_description;
                            }

                            if (res.body.data[0].aioseop_title == null || res.body.data[0].aioseop_title == "") {
                                var meta_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_title = res.body.data[0].aioseop_title;
                            }

                            if (res.body.data[0].aioseop_description == null || res.body.data[0].aioseop_description == "") {
                                var meta_description = description2;
                            } else {
                                var meta_description = res.body.data[0].aioseop_description;
                            }
                           
                            if (res.body.data[0].custom_feature_image_url != "") {
                                let img = res.body.data[0].custom_feature_image_url.split('/');
                                let appendStr = img[0]+'//'+img[2]+'/md_'+img[3];
                                let checkMdImg = await apiOn(appendStr);
                                let appendStr2 = img[0]+'//'+img[2]+'/sm_'+img[3];
                                let checkMdImg2 = await apiOn(appendStr2);
                                let appendStr3 = img[0]+'//'+img[2]+'/mb_app_'+img[3];
                                let checkMdImg3 = await apiOn(appendStr3);
                                console.log("checkMdImg", checkMdImg)
                                console.log("checkMdImg2", checkMdImg2)
                                console.log("checkMdImg3", checkMdImg3)
                                if (checkMdImg === 200) {
                                    var featured_image = appendStr;
                                } else if (checkMdImg2 === 200) {
                                    var featured_image = appendStr2;
                                } else if (checkMdImg3 === 200) {
                                    var featured_image = appendStr3;
                                } else {
                                    var featured_image = res.body.data[0].custom_feature_image_url;
                                }
                                console.log(featured_image, 'featured_image')
                                //var featured_image =  appendStr
                            } else {
                                var featured_image = res.body.data[0].image_url ? res.body.data[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.data[0].swp_og_image_url != null && res.body.data[0].swp_og_image_url != "") {
                                var article_image = res.body.data[0].swp_og_image_url;
                            } else { 
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            response.send(result);
        }
    });
});

app.get('/feature/:slug', function (request, response) {
    console.log('Feature Blog page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    // read in the index.html file
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }

        result = data;

        if (request.originalUrl != "/index.html" && request.originalUrl !== "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null" && request.originalUrl != "/undefined" && request.originalUrl != "/vauchersubscribe" && request.originalUrl != "/contestsubmit" && request.originalUrl != "/contestgiveaway" &&
        request.originalUrl != "/contest" && request.originalUrl != "/all-submissions" && 
        request.originalUrl != "/contest-winner" && request.originalUrl != "/editors-pick" &&
        request.originalUrl != "/giveaway-winner"
        ) {
            console.log('came here1')
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[2];

            if (remove_slug_slash.length > 0) {
                try {
                    console.log('came here2')
                    request_npm.post(siteUrl+'/article_detail', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            user_id: 0,
                            page_no: 0,
                            limit: 1,
                            slug: split_path
                        }
                    }, async (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }
                        console.log('came here3')
                        var res = { body: JSON.parse(httpResponse.body) };
                        console.log('RESPONSE00', res)

                        if (res.body.status == 1 && res.body.data.length > 0 && res.body.data[0].ID !== null ) {
                            
                            var description = res.body.data[0].post_content.substring(0, 300);
                            var description2 = description.replace(/<[^>]*>/g, '');

                            if (res.body.data[0].swp_og_title == null) {
                                var meta_social_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_social_title = res.body.data[0].swp_og_title;
                            }

                            if (res.body.data[0].aioseop_keywords == '' && res.body.data[0].aioseop_keywords == null) {
                                var meta_keywords = 'THG'
                            } else {
                                var meta_keywords = res.body.data[0].aioseop_keywords
                            }

                            var substr_content = meta_social_title;
                            if (res.body.data[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.data[0].swp_og_description;
                            }

                            if (res.body.data[0].aioseop_title == null || res.body.data[0].aioseop_title == "") {
                                var meta_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_title = res.body.data[0].aioseop_title;
                            }

                            if (res.body.data[0].aioseop_description == null || res.body.data[0].aioseop_description == "") {
                                var meta_description = description2;
                            } else {
                                var meta_description = res.body.data[0].aioseop_description;
                            }
                           
                            if (res.body.data[0].custom_feature_image_url != "") {
                                let img = res.body.data[0].custom_feature_image_url.split('/');
                                let appendStr = img[0]+'//'+img[2]+'/md_'+img[3];
                                let checkMdImg = await apiOn(appendStr);
                                let appendStr2 = img[0]+'//'+img[2]+'/sm_'+img[3];
                                let checkMdImg2 = await apiOn(appendStr2);
                                let appendStr3 = img[0]+'//'+img[2]+'/mb_app_'+img[3];
                                let checkMdImg3 = await apiOn(appendStr3);
                                console.log("checkMdImg", checkMdImg)
                                console.log("checkMdImg2", checkMdImg2)
                                console.log("checkMdImg3", checkMdImg3)
                                if (checkMdImg === 200) {
                                    var featured_image = appendStr;
                                } else if (checkMdImg2 === 200) {
                                    var featured_image = appendStr2;
                                } else if (checkMdImg3 === 200) {
                                    var featured_image = appendStr3;
                                } else {
                                    var featured_image = res.body.data[0].custom_feature_image_url;
                                }
                                console.log(featured_image, 'featured_image')
                                //var featured_image =  appendStr
                            } else {
                                var featured_image = res.body.data[0].image_url ? res.body.data[0].image_url : 'https://thehomeground.asia/assets/images/thg_567.jpeg';
                            }

                            if (res.body.data[0].swp_og_image_url != null && res.body.data[0].swp_og_image_url != "") {
                                var article_image = res.body.data[0].swp_og_image_url;
                            } else { 
                                var article_image = featured_image;
                            }

                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }
                        
                        else if (request.params.slug == 'terms-conditions') {
                            
                            data = data.replace(/\$META_TITLE/g, "Terms and conditions");
                            data = data.replace(/\$META_DESCRIPTION/g, "Terms and conditions");
                            data = data.replace(/\$META_KEYWORDS/g, 'Terms and conditions');
                            data = data.replace(/\$OG_TITLE/g, "Terms and conditions");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "Terms and conditions");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } 
                        else if (request.params.slug == 'data-protection-policy') {
                            console.log('terms and con')
                            data = data.replace(/\$META_TITLE/g, "Data protection Policy");
                            data = data.replace(/\$META_DESCRIPTION/g, "Data protection Policy");
                            data = data.replace(/\$META_KEYWORDS/g, 'Data protection Policy');
                            data = data.replace(/\$OG_TITLE/g, "data protection policy");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "data protection policy");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }
                        else if (request.params.slug == 'career') {
                            console.log('carrer')
                            data = data.replace(/\$META_TITLE/g, "Career");
                            data = data.replace(/\$META_DESCRIPTION/g, "Career");
                            data = data.replace(/\$META_KEYWORDS/g, 'Career');
                            data = data.replace(/\$OG_TITLE/g, "career");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "career");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } 
                        else if (request.params.slug == 'contribute-to-THG') {
                            console.log('contribute-to-THG')
                            data = data.replace(/\$META_TITLE/g, "Contribute to THG");
                            data = data.replace(/\$META_DESCRIPTION/g, "Contribute to THG");
                            data = data.replace(/\$META_KEYWORDS/g, 'Contribute to THG');
                            data = data.replace(/\$OG_TITLE/g, "Contribute");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "Contribute");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } 
                        
                        else if (request.params.slug == 'advertise-with-us') {
                            console.log('advertisement')
                            data = data.replace(/\$META_TITLE/g, "Advertise with us");
                            data = data.replace(/\$META_DESCRIPTION/g, "Advertise with us");
                            data = data.replace(/\$META_KEYWORDS/g, 'Advertise-with-us');
                            data = data.replace(/\$OG_TITLE/g, "Advertise");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "Advertise");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }  
                        else if (request.params.slug == 'how-we-make-THG') {
                            console.log('how we make thg')
                            data = data.replace(/\$META_TITLE/g, "How we make the THG");
                            data = data.replace(/\$META_DESCRIPTION/g, "How we make the THG");
                            data = data.replace(/\$META_KEYWORDS/g, 'How we make the THG');
                            data = data.replace(/\$OG_TITLE/g, "How we make thg");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "How we make thg");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }  
                        else if (request.params.slug == 'subscribe') {
                            console.log('subscribe')
                            data = data.replace(/\$META_TITLE/g, "Subscribe");
                            data = data.replace(/\$META_DESCRIPTION/g, "Subscribe");
                            data = data.replace(/\$META_KEYWORDS/g, 'Subscribe');
                            data = data.replace(/\$OG_TITLE/g, "subscribe");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "subscribe");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } else if (request.params.slug == 'about-us') {
                            data = data.replace(/\$META_TITLE/g, "about-us");
                            data = data.replace(/\$META_DESCRIPTION/g, "about-us");
                            data = data.replace(/\$META_KEYWORDS/g, 'about-us');
                            data = data.replace(/\$OG_TITLE/g, "about-us");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "about-us");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }  
                        else if (request.params.slug == 'search') {
                            data = data.replace(/\$META_TITLE/g, "search");
                            data = data.replace(/\$META_DESCRIPTION/g, "search");
                            data = data.replace(/\$META_KEYWORDS/g, 'search');
                            data = data.replace(/\$OG_TITLE/g, "search");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "search");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }  else if (request.params.slug == 'contestsubmit') {
                            data = data.replace(/\$META_TITLE/g, "contestsubmit");
                            data = data.replace(/\$META_DESCRIPTION/g, "contestsubmit");
                            data = data.replace(/\$META_KEYWORDS/g, 'contestsubmit');
                            data = data.replace(/\$OG_TITLE/g, "contestsubmit");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "contestsubmit");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        } 
                        else if (request.params.slug == 'contestgiveaway') {
                            data = data.replace(/\$META_TITLE/g, "contestgiveaway");
                            data = data.replace(/\$META_DESCRIPTION/g, "contestgiveaway");
                            data = data.replace(/\$META_KEYWORDS/g, 'contestgiveaway');
                            data = data.replace(/\$OG_TITLE/g, "contestgiveaway");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "contestgiveaway");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }
                        else if (request.params.slug == 'contest') {
                            console.log('contest')
                            data = data.replace(/\$META_TITLE/g, "contest");
                            data = data.replace(/\$META_DESCRIPTION/g, "contest");
                            data = data.replace(/\$META_KEYWORDS/g, 'contest');
                            data = data.replace(/\$OG_TITLE/g, "contest");
                            
                            data = data.replace(/\$OG_DESCRIPTION/g, "contest");
                            data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }
                        else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            response.send(result);
        }
    });
});

app.get('/:slug', function (request, response) {
    console.log('Blog page visited!', request.originalUrl);
    const filePath = path.resolve(__dirname, 'index.html');

    // read in the index.html file
    fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
            return console.log(err);
        }
        result = data;
        if (request.originalUrl != "/index.html" && request.originalUrl !== "/favicon.ico" && request.originalUrl != "/robots.txt" && request.originalUrl != "/sitemap.xml" && request.originalUrl != "/planner" && request.originalUrl != "/fb_ads.html" && request.originalUrl != "/manifest.json" && request.originalUrl != "/service-worker.js" && request.originalUrl != "/ads.txt" && request.originalUrl != "/404javascript.js" && request.originalUrl != "/404testpage4525d2fdc" && request.originalUrl != "/null" && request.originalUrl != "/undefined" && request.originalUrl != "/vauchersubscribe" && request.originalUrl != "/contestsubmit" && request.originalUrl != "/contestgiveaway" && request.originalUrl != "/data-protection-policy" && 
        request.originalUrl != "/about-us" && 
        request.originalUrl != "/search" && 
        request.originalUrl != "/how-we-make-THG" && 
        request.originalUrl != "/subscribe" && 
        request.originalUrl != "/advertise-with-us" && 
        request.originalUrl != "/career" && 
        request.originalUrl != "/terms-conditions" && 
        request.originalUrl != "/contest" && request.originalUrl != "/all-submissions" && 
        request.originalUrl != "/contest-winner" && request.originalUrl != "/editors-pick" &&
        request.originalUrl != "/giveaway-winner" && request.originalUrl != "/favicon.ico" && request.originalUrl != "/logo192.png" && request.originalUrl != '/sockjs-node'
        ) {
            // console.log('came here1')
            var original_link = request.originalUrl;
            var remove_quest_mark = original_link.split('?');

            var remove_slug_slash = remove_quest_mark[0].split('/');

            var split_path = remove_slug_slash[1];

            if (remove_slug_slash.length > 0) {
                try {
                    // console.log('came here2')
                    request_npm.post(siteUrl+'/article_detail', {
                        headers: {
                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
                        },
                        form: {
                            user_id: 0,
                            page_no: 0,
                            limit: 1,
                            slug: split_path
                        }
                    }, async (error, httpResponse, body) => {
                        if (error) {
                            response.sendFile(__dirname + '/404.html');
                        }

                        var res = {}
                        
                        if (httpResponse.body) {
                            res = { body: JSON.parse(httpResponse.body) };
                        } else {
                            response.sendFile(__dirname + '/404.html');
                        }
                       
                        // console.log('RESPONSE00', res)
                        if (res.body.status == 1 && res.body.data.length > 0 && res.body.data[0].ID !== null ) {
                            
                            var description = res.body.data[0].post_content.substring(0, 300);
                            var description2 = description.replace(/<[^>]*>/g, '');
                            
                            if (res.body.data[0].swp_og_title == null) {
                                var meta_social_title = res.body.data[0].post_title ? res.body.data[0].post_title.replace('" ', '&quot; ').replace('"', '&quot;') : '';
                            } else {
                                var meta_social_title = res.body.data[0].swp_og_title;
                            }

                            if (res.body.data[0].aioseop_keywords == '' && res.body.data[0].aioseop_keywords == null) {
                                var meta_keywords = 'THG'
                            } else {
                                var meta_keywords = res.body.data[0].aioseop_keywords
                            }

                            var substr_content = meta_social_title;
                            if (res.body.data[0].swp_og_description == null) {
                                var meta_social_description = meta_social_title;
                            } else {
                                var meta_social_description = res.body.data[0].swp_og_description;
                            }

                            if (res.body.data[0].aioseop_title == null || res.body.data[0].aioseop_title == "") {
                                var meta_title = res.body.data[0].post_title ? res.body.data[0].post_title : '';
                            } else {
                                var meta_title = res.body.data[0].aioseop_title;
                            }

                            if (res.body.data[0].aioseop_description == null || res.body.data[0].aioseop_description == "") {
                                var meta_description = description2;
                            } else {
                                var meta_description = res.body.data[0].aioseop_description;
                            }
                           
                            if (res.body.data[0].custom_feature_image_url != "") {
                                let img = res.body.data[0].custom_feature_image_url.split('/');
                                let appendStr = img[0]+'//'+img[2]+'/md_'+img[3];
                                let checkMdImg = await apiOn(appendStr);
                                let appendStr2 = img[0]+'//'+img[2]+'/sm_'+img[3];
                                let checkMdImg2 = await apiOn(appendStr2);
                                let appendStr3 = img[0]+'//'+img[2]+'/mb_app_'+img[3];
                                let checkMdImg3 = await apiOn(appendStr3);
                                // console.log("checkMdImg", checkMdImg)
                                // console.log("checkMdImg2", checkMdImg2)
                                // console.log("checkMdImg3", checkMdImg3)
                                if (checkMdImg === 200) {
                                    var featured_image = appendStr;
                                } else if (checkMdImg2 === 200) {
                                    var featured_image = appendStr2;
                                } else if (checkMdImg3 === 200) {
                                    var featured_image = appendStr3;
                                } else {
                                    var featured_image = res.body.data[0].custom_feature_image_url;
                                }
                                // console.log(featured_image, 'featured_image')
                                //var featured_image =  appendStr
                            } else {
                                var featured_image = res.body.data[0].image_url ? res.body.data[0].image_url : 'https://thgtv-image-upload.s3.ap-southeast-1.amazonaws.com/1597230939315_Hot_Springs_in_Beitou%2C_Taiwan.jpg';
                            }

                            if (res.body.data[0].swp_og_image_url != null && res.body.data[0].swp_og_image_url != "") {
                                var article_image = res.body.data[0].swp_og_image_url;
                            } else { 
                                var article_image = featured_image;
                            }
                            console.log(meta_social_title, 'meta_social_title')
                            data = data.replace(/\$META_TITLE/g, meta_title);
                            data = data.replace(/\$META_DESCRIPTION/g, meta_description);
                            data = data.replace(/\$META_KEYWORDS/g, meta_keywords);
                            data = data.replace(/\$OG_TITLE/g, meta_social_title);
                            data = data.replace(/\$OG_DESCRIPTION/g, meta_social_description);
                            data = data.replace(/\$OG_IMAGE/g, article_image);
                            result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                            response.send(result);
                        }
                        
                        else {
                            response.sendFile(__dirname + '/404.html');
                        }

                    })

                } catch (err) {
                    console.log('Err', err);
                }
            }
        } else {
            if (request.params.slug == 'terms-conditions') {
                            
                data = data.replace(/\$META_TITLE/g, "Terms and conditions");
                data = data.replace(/\$META_DESCRIPTION/g, "Terms and conditions");
                data = data.replace(/\$META_KEYWORDS/g, 'Terms and conditions');
                data = data.replace(/\$OG_TITLE/g, "Terms and conditions");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "Terms and conditions");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            } 
            else if (request.params.slug == 'data-protection-policy') {
                console.log('terms and con')
                data = data.replace(/\$META_TITLE/g, "Data protection Policy");
                data = data.replace(/\$META_DESCRIPTION/g, "Data protection Policy");
                data = data.replace(/\$META_KEYWORDS/g, 'Data protection Policy');
                data = data.replace(/\$OG_TITLE/g, "Data protection Policy");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "Data protection Policy");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }
            else if (request.params.slug == 'career') {
                console.log('carrer')
                data = data.replace(/\$META_TITLE/g, "Career");
                data = data.replace(/\$META_DESCRIPTION/g, "Career");
                data = data.replace(/\$META_KEYWORDS/g, 'Career');
                data = data.replace(/\$OG_TITLE/g, "Career");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "Career");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            } 
            else if (request.params.slug == 'contribute-to-THG') {
                console.log('contribute-to-THG')
                data = data.replace(/\$META_TITLE/g, "Contribute to THG");
                data = data.replace(/\$META_DESCRIPTION/g, "Contribute to THG");
                data = data.replace(/\$META_KEYWORDS/g, 'Contribute to THG');
                data = data.replace(/\$OG_TITLE/g, "Contribute to THG");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "Contribute to THG");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            } 
            
            else if (request.params.slug == 'advertise-with-us') {
                console.log('advertisement')
                data = data.replace(/\$META_TITLE/g, "Advertise with us");
                data = data.replace(/\$META_DESCRIPTION/g, "Advertise with us");
                data = data.replace(/\$META_KEYWORDS/g, 'Advertise-with-us');
                data = data.replace(/\$OG_TITLE/g, "Advertise-with-us");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "Advertise-with-us");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }  
            else if (request.params.slug == 'how-we-make-THG') {
                console.log('how we make thg')
                data = data.replace(/\$META_TITLE/g, "How we make the THG");
                data = data.replace(/\$META_DESCRIPTION/g, "How we make the THG");
                data = data.replace(/\$META_KEYWORDS/g, 'How we make the THG');
                data = data.replace(/\$OG_TITLE/g, "How we make the THG");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "How we make the THG");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }  
            else if (request.params.slug == 'subscribe') {
                console.log('subscribe')
                data = data.replace(/\$META_TITLE/g, "Subscribe");
                data = data.replace(/\$META_DESCRIPTION/g, "Subscribe");
                data = data.replace(/\$META_KEYWORDS/g, 'Subscribe');
                data = data.replace(/\$OG_TITLE/g, "Subscribe");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "Subscribe");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            } else if (request.params.slug == 'search') {
                data = data.replace(/\$META_TITLE/g, "search");
                data = data.replace(/\$META_DESCRIPTION/g, "search");
                data = data.replace(/\$META_KEYWORDS/g, 'search');
                data = data.replace(/\$OG_TITLE/g, "search");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "search");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }  
            else if (request.params.slug == 'about-us') {
                data = data.replace(/\$META_TITLE/g, "about-us");
                data = data.replace(/\$META_DESCRIPTION/g, "about-us");
                data = data.replace(/\$META_KEYWORDS/g, 'about-us');
                data = data.replace(/\$OG_TITLE/g, "about-us");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "about-us");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }  else if (request.params.slug == 'contestsubmit') {
                data = data.replace(/\$META_TITLE/g, "contestsubmit");
                data = data.replace(/\$META_DESCRIPTION/g, "contestsubmit");
                data = data.replace(/\$META_KEYWORDS/g, 'contestsubmit');
                data = data.replace(/\$OG_TITLE/g, "contestsubmit");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "contestsubmit");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            } 
            else if (request.params.slug == 'contestgiveaway') {
                data = data.replace(/\$META_TITLE/g, "contestgiveaway");
                data = data.replace(/\$META_DESCRIPTION/g, "contestgiveaway");
                data = data.replace(/\$META_KEYWORDS/g, 'contestgiveaway');
                data = data.replace(/\$OG_TITLE/g, "contestgiveaway");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "contestgiveaway");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }
            else if (request.params.slug == 'contest') {
                console.log('contest')
                data = data.replace(/\$META_TITLE/g, "contest");
                data = data.replace(/\$META_DESCRIPTION/g, "contest");
                data = data.replace(/\$META_KEYWORDS/g, 'contest');
                data = data.replace(/\$OG_TITLE/g, "contest");
                
                data = data.replace(/\$OG_DESCRIPTION/g, "contest");
                data = data.replace(/\$OG_IMAGE/g, 'https://thehomeground.asia/assets/images/thg_567.jpeg');
                result = data.replace(/\$OG_URL/g, 'https://www.thehomeground.asia' + request.originalUrl);
                response.send(result);
            }
            // response.send(result);
        }
    });
});
// "ID": 11707, "ID": 10005
// "master-class"   "documentaries"  "web-series"  "top-picks"
app.post("/append_all_post_in_sitemap", function( request, response) {
    console.log("/append_all_post_in_sitemap")
    try{
        // request_npm.get('http://localhost:9000/api/v1/general_articles'

        let reel_slug = ["master-class","documentaries","web-series","top-picks"];
        let fe_ids = [11707, 10005];
        request_npm.post('http://localhost:9000/api/v1/general_articles', {
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            },
            form: { }
        }, 
        // request_npm.post('http://localhost:9000/api/v1/whats_happen_articles_for_sitemap', {
        //     headers: {
        //         "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        //         "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
        //     },
        //     form: { }
        // }, 
        // request_npm.post('http://localhost:9000/api/v1/reel_articles_for_sitemap', {
        //     headers: {
        //         "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        //         "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
        //     },
        //     form: { slug: reel_slug[0] }
        // }, 
        // request_npm.post('http://localhost:9000/api/v1/fevents_for_sitemap', {
        //     headers: {
        //         "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        //         "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
        //     },
        //     form: { slug: split_path }
        // }, 
        // request_npm.post('http://localhost:9000/api/v1/general_articles', {
        //     headers: {
        //         "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        //         "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
        //     },
        //     form: { slug: fe_ids[0] }
        // }, 
        (error, res, body) => {
          if (error) {
              console.error(error)
              return
          }
          let jsonResult = JSON.parse(body);
          let baseUrl = "https://www.thehomeground.asia/";
          let urlText = jsonResult.list.map(o => ({'loc':`${baseUrl}${o.post_name}`})); 
          fs.readFile("sitemap.xml", "utf-8", function(err, data) {
            if (err) console.log(err);
            parseString(data, function(err, xmlresult) {
              if (err) console.log(err);
              let jsonObj = xmlresult;
              
              jsonObj['urlset']['url'] = [...jsonObj['urlset']['url'], ...urlText];
              var builder = new xml2js.Builder();
              var xml = builder.buildObject(jsonObj);
          
              fs.writeFile("sitemap.xml", xml, function(err, data) {
                if (err) console.log(err);
                response.json({status: 1, msg: "successfully written our update xml to file"});
              });
            });
          });
  
      })
    } catch(err){
        console.log('Err', err);
    }
});
  
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
  
    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;
  
    return [year, month, day].join('-');
}

app.use(express.static(path.resolve(__dirname)));

app.get('*', function (request, response) {
    const filePath = path.resolve(__dirname, 'index.html');
    response.sendFile(filePath);
});

app.listen(port, () => console.log(`Listening on port ${port}`));
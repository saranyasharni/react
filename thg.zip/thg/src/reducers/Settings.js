const init = {
    activateDeactivateSuccess: 0,
    activeStatus: 0,
    removeAccountSuccess:0

};

export const Settings = (state = init, action) => {
    switch (action.type) {
        case 'ACTIVATE_INFO':
            return { ...state, ...action.data }
        case 'ACTIVATE_STATUS':
            return { ...state, activateDeactivateSuccess : action.data }
        default:
            return state;
    }
};
import { connect } from "react-redux";
import { showHide } from "../actions/BucketList";

const init = {
    bucketLists: [],
    bucket_id: '',
    bucket_name: '',
    articleLists: [],
    articleListPageno: 0,
    editBucketStatus: 0,
    showHideBtn: true,
    id : ''
};

export const BucketList = (state = init, action) => {
    switch (action.type) {
        case 'THREE_BUCKET_LIST':
            return { ...state, bucketLists: action.data }
        case 'ARTICLE_LISTS':
            return { ...state, articleLists: action.data }
        case 'EDIT_BUCKET_ITEM':
            return { ...state, ...action.data }
        case 'SHOW_HIDE_BTN':
            //console.log(action.data, 'CAME')
            return { ...state, ...action.data }
        case 'EDIT_BUCKET_STATUS':
            
            return { ...state, editBucketStatus: action.data }
        default:
            return state;
    }
};
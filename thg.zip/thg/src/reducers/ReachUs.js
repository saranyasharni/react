const init = {
    fullName: '',
    email: '',
    mobileNo: '',
    message: '',
    reachUsStatus: 0,
    reachUsErrors: {},
};

export const ReachUs = (state = init, action) => {
    switch (action.type) {
        case 'CHANGE_REACHUS_INFO':
            return { ...state, [action.field]: action.value };
        case 'REACHUS_STATUS':
            return { ...state, reachUsStatus: action.data };
        case 'UPDATE_REACHUS_ERRORS':
            return { ...state, reachUsErrors: { ...state.reachUsErrors, ...action.data } };
        case 'RESET_REACHUS_FORM':
            return { ...state, ...action.data };
        default:
            return state;
    }
};
const init = {
    latestArticles: [],
    latestPhotos: [],
    latestVideos: [],
    featuredEventsBannerList: [],
    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth(),
    currentDate: new Date().getDate(),
    daysOfMonth: [],
    datesOfMonth: [],
    calendarEvents: [],
    eventCategories: [],
    category_id: '',
    increaseCount: 1,
    decreaseCount: 1,
    event_id: '',
    purchaseTicket: '',
    playControls: false,
    amount: '',
    livtStreamVideos: [],
    streamVideoDetail: [],
    relatedVideos: [],
    eventDetail : []
};

export const FeatureParent = (state = init, action) => {
    switch (action.type) {
        case 'LATEST_ARTICLES_LIST':
            return { ...state, latestArticles: action.data }
        case 'SET_EVENT_DATA':
            return { ...state, eventDetail: action.data }
        case 'LATEST_PHOTOS_LIST':
            return { ...state, latestPhotos: action.data }
        case 'LIVE_STREAM_VIDEOS':
            return { ...state, livtStreamVideos: action.data }
        case 'SET_STREAM':
            return { ...state, streamVideoDetail: action.data }
        case 'SET_RELATED_VIDEOS':
            return { ...state, relatedVideos: action.data }
        case 'FEATURED_EVENT_VIDEOS_LIST':
            // alert('coming')
            return { ...state, latestVideos: action.data }
        case 'SET_EVENT_ID':

            return { ...state, event_id: action.data }
        case 'FEATURE_BANNER_LIST':
            return { ...state, featuredEventsBannerList: action.data }
        case 'UPDATE_MONTH_YEAR':
            const { flag } = action.data
            return { ...state, currentMonth: (flag === 1) ? state.currentMonth + 1 : state.currentMonth - 1 }
        case 'SET_MONTH_YEAR':
            return { ...state, ...action.data }
        case 'SET_CALENDAR_EVENTS':
            return { ...state, calendarEvents: action.data }
        case 'EVENT_CATEGORY_LIST':
            return { ...state, eventCategories: action.data }
        case 'PURCHASE_TICKET':
            return { ...state, purchaseTicket: action.data }

        default:
            return state;
    }
};
const init = {
    reelBanner: [],
    reelChildArticles: [],
    reelArticlePageNo: 0,
    articleMoreStatus: 0
};

export const ReelCategory = (state = init, action) => {
    switch (action.type) {
        case 'REEL_BANNER_LIST':
            return { ...state, reelBanner: action.data }
        case 'REEL_CHILD_ARTICLES':
            return { ...state, reelChildArticles: action.data }
        case 'NEW_REEL_CHILD_ARTICLES':
            let result = action.data.filter(o => !state.reelChildArticles.some(v => v.ID === o.ID))
            return { ...state, reelChildArticles: [...state.reelChildArticles, ...result], articleMoreStatus: result.length ? 0 : 1  }
        case 'UPDATE_REEL_PAGE_NO':
            const { flag } = action.data;
            return { ...state, reelArticlePageNo: (flag === 0) ? state.reelArticlePageNo + 1 : 0 }
        case 'UPDATE_ARTICLE_MORE_STATUS':
            return { ...state, articleMoreStatus: action.data }
        default:
            return state;
    }
};
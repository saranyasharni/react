const init = {
    fullName: '',
    email: '',
    subscribeFooterStatus: 0,
    subscribeFooterErrors: {},
    quickLinks: [
        {
            "term_id": 116,
            "name": "News",
            "slug": "news"
        },
        {
            "term_id": 5,
            "name": "Sports",
            "slug": "sports"
        },
        {
            "term_id": 24,
            "name": "Esports",
            "slug": "esports"
        },
        {
            "term_id": 25,
            "name": "Experiences",
            "slug": "travel"
        },
        // {
        //     "term_id": 3,
        //     "name": "Reel",
        //     "slug": "reel"
        // },
        {
            "term_id": 126,
            "name": "What's Happening",
            "slug": "whats_happening"
        },
        {
            "term_id": 27,
            "name": "THG TV",
            "slug": "thg-tv"
        },
        {
            "term_id": 4,
            "name": "Review",
            "slug": "review"
        },
        // {
        //     "term_id": 2,
        //     "name": "Featured Events",
        //     "slug": "featured-events"
        // },

    ],
    aboutUs : [],
    termsData: [],
    dataProtection: [],
    career:[],
    contributeToTHG:[],
    reachUs: [],
    contribute: [],
    makeThg: []

};
export const Footer = (state = init, action) => {
    switch (action.type) {
        case 'QUICK_LINKS':
            return { ...state, quickLinks: action.data };
        case 'CHANGE_SUBSCRIBE_FOOTER_INFO':
            return { ...state, [action.field]: action.value };
        case 'SUBSCRIBE_FOOTER_STATUS':
            return { ...state, subscribeFooterStatus: action.data };
        case 'UPDATE_SUBSCRIBE_FOOTER_ERRORS':
            return { ...state, subscribeFooterErrors: { ...state.subscribeFooterErrors, ...action.data } };
        case 'RESET_FOOTER_SUBSCRIBE_FORM':
            return { ...state, ...action.data };
        case 'ABOUT_US':
            return { ...state, aboutUs:action.data };
        case 'SET_TERMS_DATA':
            return { ...state, termsData:action.data };
        case 'SET_DATA_PROTECTION':
            return { ...state, dataProtection:action.data };
        case 'CAREER':
            return { ...state, career:action.data };
        case 'SET_REACH_US':
            return { ...state, reachUs:action.data};
        case 'CONTRIBUTETOTHG':
            return { ...state, contributeToTHG:action.data };
        case 'SET_CONTRIBUTE':
            return { ...state, contribute:action.data };
        case 'MAKE_THG':
            return { ...state, makeThg:action.data };

       default:
            return state;
    }
};

const init = {
    email: "",
    firstName: "",
    lastName: "",
    password: "",
    confirmPassword: '',
    errors: {},
    success: false,
    userDetails: [],
    loginEmail: '',
    loginPassword: '',
    bucket_name: '',
    bucketItem: {},
    bucketList: [],
    country: '',
    temperature: '',
    articleSuccess: 0,
    articleError: 0,
    loginStatus: 0,
    registrationStatus: 0,
    subCategoryList:[],
    sub_cat_list_esports:[],
    sub_cat_list_travel:[],
    sub_cat_list_review:[],
    categoryList: []
};

export const Header = (state = init, action) => {
    switch (action.type) {
        case 'INPUT_CHANGE':
            return { ...state, [action.field]: action.value };
        case 'CATEGORY_LISTS_HEADER':
            return { ...state, categoryList: action.data };    
        case 'SPORTS_SUB_CATEGORY_LIST':
            return { ...state, subCategoryList: action.data };
        case 'REVIEW_SUB_CATEGORY_LIST':
            return { ...state, sub_cat_list_review: action.data };
        case "ESPORTS_SUB_CATEGORY_LIST":
            return { ...state, sub_cat_list_esports: action.data };
        case "TRAVEL_SUB_CATEGORY_LIST":
            return { ...state, sub_cat_list_travel: action.data };
        case 'BUCKET_ITEM_CHANGE':
            return { ...state, bucketItem: { ...state.bucketItem, [action.field]: action.value } };
        case 'REGISTRATION':
            return { ...state, success: action.data };
        case 'UPDATE_ERRORS':
            return { ...state, errors: { ...state.errors, ...action.data } };
        case 'USER_DETAILS':
            return { ...state, userDetails: action.data };
        case 'RESET_FORM':
            return { ...state, ...action.data };
        case 'BUCKET_LIST':
            return { ...state, bucketList: action.data }
        case 'ARTICLE_BUCKET_STATUS':
            return { ...state, articleSuccess: action.data }
        case 'ARTICLE_BUCKET_ERROR_STATUS':
            return { ...state, articleError: action.data }
        case 'REGISTRATION_STATUS':
            return { ...state, registrationStatus: action.data }
        case 'LOGIN_STATUS':
            return { ...state, loginStatus: action.data }
        default:
            return state;
    }
};

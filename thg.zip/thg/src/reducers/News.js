const init = {
    newsLatestArticles: [],
    newsRecommendedArticles: [],
    reelArticles: [],
    newsBannerList: [],
    newsFeatureArticles: [],
    newsSportsCategoryList: [],
    newsESportsCategoryList: [],
    newsTravelCategoryList: [],
    newsReviewCategoryList: [],
    newsPopularArticles: [],
    whatsHappeningList: [],
    articleDetail: [],
    THGTvList: [],
    coachLists: [],
    trendingList: [],
    newsLoader: false,
    banner_status: 1,
    trending_status: 1,
    latest_status: 1,
    featured_status : 1,
    popular_status: 1,
    recommend_status : 1

};

export const News = (state = init, action) => {
    switch (action.type) {
        case 'NEWS_LATEST_ARTICLES_LIST':
            return { ...state, newsLatestArticles: action.data,
                latest_status:action.status
            }
        case 'SET_LOADING':
            return { ...state, newsLoader: action.data }
        case 'NEWS_BANNER_LIST':
            return { ...state, newsBannerList: action.data,
                banner_status: action.status
            }
        case 'NEWS_RECOMMENDED_ARTICLES_LIST':
            return { ...state, 
                newsRecommendedArticles: action.data,
                recommend_status: action.status

             }
        case 'NEWS_FEATURE_ARTICLES_LIST':
            return { ...state, newsFeatureArticles: action.data, featured_status: action.status }
        case 'REEL_ARTICLES_LIST':
            return { ...state, reelArticles: action.data }
        case 'NEWS_POPULAR_ARTICLES_LIST':
            return { ...state, newsPopularArticles: action.data, popular_status:action.status}
        case 'NEWS_SPORTS_CATEGORY_LIST':
            return { ...state, newsSportsCategoryList: action.data }
        case 'NEWS_ESPORTS_CATEGORY_LIST':
            return { ...state, newsESportsCategoryList: action.data }
        case 'NEWS_TRAVEL_CATEGORY_LIST':
            return { ...state, newsTravelCategoryList: action.data }
        case 'NEWS_REVIEW_CATEGORY_LIST':
            return { ...state, newsReviewCategoryList: action.data }
        case 'WHATS_HAPPENING_LIST':
            return { ...state, whatsHappeningList: action.data }
        case 'ARTICLE_DETAIL':
            return { ...state, articleDetail: action.data }
        case 'THG_TV_LIST':
            return { ...state, THGTvList: action.data }
        case 'COACH_LISTS':
            return { ...state, coachLists: action.data }
        case 'TRENDING_LISTS':
            return { ...state, trendingList: action.data, trending_status:action.status }
        default:
            return state;
    }
};
const init = {
    searchList: [],
    searchTerm: ''
};
export const Search = (state = init, action) => {
    switch (action.type) {
        case 'SEARCH_ARTICLES_LIST':
            return { ...state, searchList: action.data }
        case 'UPDATE_SEARCH_TERM':
            return { ...state, ...action.data }
        default:
            return state;
    }
};

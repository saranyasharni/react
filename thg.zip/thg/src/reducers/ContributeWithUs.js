const init = {
    fullName: '',
    email: '',
    mobileNo: '',
    companyAddress: '',
    interestOfChoosing: '',
    message: '',
    contributeStatus: 0,
    contributeErrors: {},
};

export const ContributeWithUs = (state = init, action) => {
    switch (action.type) {
        case 'CHANGE_CONTRIBUTE_INFO':
            return { ...state, [action.field]: action.value };
        case 'CONTRIBUTE_STATUS':
            return { ...state, contributeStatus: action.data };
        case 'UPDATE_CONTRIBUTE_ERRORS':
            return { ...state, contributeErrors: { ...state.contributeErrors, ...action.data } };
        case 'RESET_CONTRIBUTE_FORM':
            return { ...state, ...action.data };
        default:
            return state;
    }
};
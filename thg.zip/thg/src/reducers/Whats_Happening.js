const init = {
    featuredEvents: [],
    whatsHappenBannerList: [],
    upcomingEvents: [],
    ongoingEvents: [],
    categoryFilterList: [],
    upcomingEventNo: 0,
    ongoingEventNo: 0,
    articleMoreStatus: 0,
    moreUpcomingEvents: [],
    filterBy: '',
    changeDate: false,
    setdateArray: '',
    loading: false,
    showHideStatus : 0,
    showHideStatus_past: 0,
    articleMoreStatus_post:0
};

export const WhatsHappening = (state = init, action) => {
    switch (action.type) {
        case 'FEATURED_EVENT_LIST':
            return { ...state, featuredEvents: action.data }
        case 'SET_DATE_ARRAY':
            
            return { ...state, setdateArray: action.data }
        case 'SET_LOADING':
            
            return { ...state, loading: action.payload }
        case 'WHATS_HAPPEN_BANNER_LIST':
            return { ...state, whatsHappenBannerList: action.data }
        case 'UPCOMING_EVENT_LIST':
            
            return { ...state, upcomingEvents: action.data,
                moreUpcomingEvents: []
            }
        case 'MORE_UPCOMING_EVENT_LIST':
            
            // let upcoming = action.data.filter(o => !state.upcomingEvents.some(v => v.ID === o.ID));
           
            // return { ...state, upcomingEvents: [...state.upcomingEvents, ...upcoming], articleMoreStatus: upcoming.length ? 0 : 1,
            // }
            
        return {...state, moreUpcomingEvents:[...state.moreUpcomingEvents, ...action.data],
            showHideStatus:action.data.length ? 1 : 0 ,
            articleMoreStatus: action.data.length ? 0 : 1,
        
        }
            
        case 'ONGOING_EVENTS_LIST':
            return { ...state, ongoingEvents: action.data }
        case 'MORE_ONGOING_EVENTS_LIST':
            let ongoing = action.data.filter(o => !state.ongoingEvents.some(v => v.ID === o.ID))
            
            return { ...state, ongoingEvents: [...state.ongoingEvents, ...ongoing], articleMoreStatus_post: ongoing.length === 0 ? 1 : 0,
            showHideStatus_past:action.data.length ? 1 : 1,
            }
        case 'UPCOMING_EVENT_NO':
            const { upcomingFlag } = action.data;
            return { ...state, upcomingEventNo: (upcomingFlag === 0) ? state.upcomingEventNo + 1 : 0 }
        case 'ONGOING_EVENT_NO':
            const { ongoingFlag } = action.data;
            return { ...state, ongoingEventNo: (ongoingFlag === 0) ? state.ongoingEventNo + 1 : 0 }
        case 'UPDATE_ARTICLE_MORE_STATUS':
            return { ...state, articleMoreStatus: action.data }
        case 'MORE_STATUS_LIST_PAST':
                return { ...state, showHideStatus_past: action.data }
        case 'UPDATE_SHOW_HIDE_STATUS':
                return { ...state, showHideStatus: action.data }
        case 'UPDATE_VALUE':
            return { ...state, changeDate: action.data }
        case 'CATEGORY_FILTER_LIST':
            return { ...state, categoryFilterList: action.data }
        case 'UPDATE_FILTER_BY':
            return { ...state, filterBy: action.data }
        default:
            return state;
    }
    
};
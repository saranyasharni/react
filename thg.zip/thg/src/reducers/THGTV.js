const init = {
    onThePitchList: [],
    programmesList: [],
    episodesList: [],
    programmeStreamList: [],
    programme_id: '682134dd-b05d-4de5-b70e-d52177d3b983',
    liveStatus: 0,
    archiveStatus: 1,
    bannerEpisode: '',
    show_hide: 0,
};

export const THGTV = (state = init, action) => {
    switch (action.type) {
        case 'SHOW_HIDE':
            return { ...state, show_hide: action.data }
        case 'ON_THE_PITCH_LIST':
            return { ...state, onThePitchList: action.data }
        case 'PROGRAMMES_LIST':
            return { ...state, programmesList: action.data }
        case 'EPISODES_LIST':
            return { ...state, episodesList: action.data };
        case 'BANNER_EPISODE':
            return { ...state, bannerEpisode: action.id }    
        case 'PROGRAMME_STREAM_LIST':
            return { ...state, programmeStreamList: action.data }
        case 'UPDATE_PROGRAMME_ID':
            return { ...state, programme_id: action.data }
        case 'UPDATE_LIVE_STATUS':
            return { ...state, liveStatus: action.data }
        case 'NEW_ARCHIVE_LIST':
            // alert()
            let result = action.data.filter(o => !state.onThePitchList.some(v => v.ID === o.ID))
            return { ...state, onThePitchList: [...state.onThePitchList, ...action.data], archiveStatus: action.data.length ? 1 : 0, 
            show_hide: action.data.length ? 1 : 0
             }
        case 'UPDATE_PAGE_NO':
            const { flag } = action.data;
            return { ...state, archivePageNo: (flag === 0) ? state.archivePageNo + 1 : 0 }
        case 'UPDATE_ARCHIVE_STATUS':
            return { ...state, archiveStatus: action.data }
        default:
            return state;
    }
};
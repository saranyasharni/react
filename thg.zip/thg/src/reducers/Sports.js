const init = {
    latestArticlesList: [],
    eSportsCategoryList: [],
    travelCategoryList: [],
    reviewCategoryList: [],
    sportsSubCategoryList: [],
    articlePageNo: 0,
    featuredArticlesList: [],
    popularArticlesList: [],
    highlightsList: [],
    articleVideoStatus: 0,
    show_hide: 0,
    new_cat_status: 1
    //slug_val = ''
};

export const Sports = (state = init, action) => {
    switch (action.type) {
        case 'LATEST_ARTICLE_LIST':
            return { ...state, latestArticlesList: action.data }
        case 'NEW_LATEST_ARTICLE_LIST':
            let result = action.data.filter(o => !state.latestArticlesList.some(v => v.ID === o.ID))
            return { ...state, latestArticlesList: [...state.latestArticlesList, ...result], articleVideoStatus: result.length ? 0 : 1,
            show_hide:result.length ? 1 : 0, 
            new_cat_status: action.state
            }
        case 'FEATURED_ARTICLE_LIST':
            return { ...state, featuredArticlesList: [...action.data] }
        case 'POPULAR_ARTICLE_LIST':
            return { ...state, popularArticlesList: action.data }
        case 'ESPORTS_CATEGORY_LIST':
            return { ...state, eSportsCategoryList: action.data }
        case 'TRAVEL_CATEGORY_LIST':
            return { ...state, travelCategoryList: action.data }
        case 'REVIEW_CATEGORY_LIST':
            return { ...state, reviewCategoryList: action.data }
        case 'HIGH_LIGHTS_LIST':
            return { ...state, highlightsList: action.data }
        case 'UPDATE_PAGE_NO':
            const { flag } = action.data;
            return { ...state, articlePageNo: (flag === 0) ? state.articlePageNo + 1 : 0 }
        case 'UPDATE_ARTICLE_VIDEO_STATUS':
            return { ...state, articleVideoStatus: action.data }
        case 'SHOW_HIDE':
            return { ...state, show_hide: action.data }
        default:
            return state;
    }
};
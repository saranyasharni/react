const init = {
    reelBanner: [],
    reelChildArticles: [],
    reelArticlePageNo: 0,
};

export const FeatureCategory = (state = init, action) => {
    switch (action.type) {
        case 'REEL_BANNER_LIST':
            return { ...state, reelBanner: action.data }
        case 'REEL_CHILD_ARTICLES':
            return { ...state, reelChildArticles: action.data }
        case 'NEW_REEL_CHILD_ARTICLES':
            return { ...state, reelChildArticles: [ ...state.reelChildArticles, ...action.data ] }
        case 'UPDATE_REEL_PAGE_NO':
            const { flag } = action.data;
            return { ...state, reelArticlePageNo: (flag === 0) ? state.reelArticlePageNo + 1 : 0 }
        default:
            return state;
    }
};
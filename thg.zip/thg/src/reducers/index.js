import { combineReducers } from 'redux'
import { connectRouter } from 'connected-react-router'
import { Home } from './Home';
import { News } from './News';
import { Sports } from "./Sports";
import { ArticleDetail } from "./Article_Detail";
import { THGTV } from "./THGTV";
import { Reel } from "./Reel";
import { ReelCategory } from "./Reel_Category";
import { WhatsHappening } from "./Whats_Happening";
import { WhatsHappeningCategory } from "./Whats_Happening_Category";
import { Review_Category } from "./Review_Category";
import { CoachListing } from "./Coach_Listing";
import { FeatureParent } from "./Feature_Parent";
import { FeatureCategory } from "./Feature_Category";
import { VideoDetail } from "./Video_Detail";
import { ThgTvDetail } from "./ThgTvDetail";
import { Header } from "./common/Header";
import { Footer } from "./common/Footer";
import { BucketList } from './BucketList';
import { BucketListArticle } from './BucketListArticle';
import { CreateArticle } from './CreateArticle';
import { Profile } from './Profile';
import { Settings } from './Settings';
import { YourArticles } from './YourArticles';
import { Subscribe } from './Subscribe';
import { ReachUs } from './ReachUs';
import { ContributeWithUs } from './ContributeWithUs';
import { AdvertiseWithUs } from './AdvertiseWithUs';
import { DataProtectionPolicy } from './Data_Protection_Policy';
import { Contest } from './Contest';
import { Search } from './Search';
import { Survay } from './Survay';
import {subscribedEvent} from './SubscribedEventList'


export default combineReducers({
    Home,
    News,
    Sports,
    ArticleDetail,
    Header,
    Footer,
    THGTV,
    Reel,
    ReelCategory,
    WhatsHappening,
    WhatsHappeningCategory,
    Review_Category,
    CoachListing,
    FeatureParent,
    FeatureCategory,
    VideoDetail,
    BucketList,
    BucketListArticle,
    CreateArticle,
    Profile,
    Settings,
    YourArticles,
    Subscribe,
    ContributeWithUs,
    AdvertiseWithUs,
    ReachUs,
    ThgTvDetail,
    DataProtectionPolicy,
    Contest,
    Search,
    Survay,
    subscribedEvent
});
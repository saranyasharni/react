const init = {
    deleteStatus: 0,
    pendingStatus: 0,
    draftArticlePageNo: 0,
    publishArticlePageNo: 0,
    pendingArticlePageNo: 0,
    draftArticlesList: [],
    publishArticlesList: [],
    pendingArticlesList: [],
    articleMoreStatus: 0
};

export const YourArticles = (state = init, action) => {
    switch (action.type) {
        case 'DELETE_STATUS':
            return { ...state, deleteStatus: action.data };
        case 'CHANGE_PENDING_STATUS':
            return { ...state, pendingStatus: action.data };
        case 'USER_ARTICLE_LIST':
            return { ...state, ...action.data };
        case 'DRAFT_ARTICLES':
            return { ...state, draftArticlesList: action.data };
        case 'PUBLISH_ARTICLES':
            return { ...state, publishArticlesList: action.data };
        case 'PENDING_ARTICLES':
            return { ...state, pendingArticlesList: action.data };
        case 'MORE_DRAFT_ARTICLES':
            let draft = action.data.filter(o => !state.draftArticlesList.some(v => v.ID === o.ID))
            return { ...state, draftArticlesList: [...state.draftArticlesList, ...draft], articleMoreStatus: draft.length ? 0 : 1 };
        case 'MORE_PUBLISH_ARTICLES':
            let publish = action.data.filter(o => !state.publishArticlesList.some(v => v.ID === o.ID))
            return { ...state, publishArticlesList: [...state.publishArticlesList, ...publish], articleMoreStatus: publish.length ? 0 : 1 };
        case 'MORE_PENDING_ARTICLES':
            let pending = action.data.filter(o => !state.pendingArticlesList.some(v => v.ID === o.ID))
            return { ...state, pendingArticlesList: [...state.pendingArticlesList, ...pending], articleMoreStatus: pending.length ? 0 : 1 };
        case 'UPDATE_DRAFT_PAGE_NO':
            const { draftFlag } = action.data;
            return { ...state, draftArticlePageNo: (draftFlag === 0) ? state.draftArticlePageNo + 1 : 0 }
        case 'UPDATE_PUBLISH_PAGE_NO':
            const { publishFlag } = action.data;
            return { ...state, publishArticlePageNo: (publishFlag === 0) ? state.publishArticlePageNo + 1 : 0 }
        case 'UPDATE_PENDING_PAGE_NO':
            const { pendingFlag } = action.data;
            return { ...state, pendingArticlePageNo: (pendingFlag === 0) ? state.pendingArticlePageNo + 1 : 0 }
        case 'UPDATE_ARTICLE_MORE_STATUS':
            return { ...state, articleMoreStatus: action.data }
        default:
            return state;
    }
};
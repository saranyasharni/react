const init = {
    firstName: '',
    lastName: '',
    email: '',
    frequency: '',
    // frequencyList: [],
    notify_topics: [],
    subscribeStatus: 0,
    subscribeErrors: {},
};

export const Subscribe = (state = init, action) => {
    switch (action.type) {
        case 'CHANGE_SUBSCRIBE_INFO':
            
            return { ...state, [action.field]: action.value };
            
        case 'SUBSCRIBE_STATUS':
            return { ...state, subscribeStatus: action.data };
        case 'UPDATE_SUBSCRIBE_ERRORS':
            return { ...state, subscribeErrors: { ...state.subscribeErrors, ...action.data } };
        case 'RESET_SUBSCRIBE_FORM':
            return { ...state, ...action.data };
        // case 'FREQ_LIST':
        //     return { ...state, frequencyList: action.data };
        default:
            return state;
    }
};
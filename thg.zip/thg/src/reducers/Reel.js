const init = {
    topPicksList: [],
    webSeriesList: [],
    documentaryList: [],
    masterClassList: [],
    archivePageNo: 0,
    archiveStatus: 0
};

export const Reel = (state = init, action) => {
    switch (action.type) {
        case 'TOP_PICKK_LIST':
            return { ...state, topPicksList: action.data }
        case 'WEB_SERIES_LIST':
            return { ...state, webSeriesList: action.data }
        case 'DOCUMENTARY_LIST':
            return { ...state, documentaryList: action.data }
        case 'MASTER_CLASS_LIST':
            return { ...state, masterClassList: action.data }
        case 'NEW_MASTER_CLASS_LIST':
            let result = action.data.filter(o => !state.masterClassList.some(v => v.ID === o.ID))
            return { ...state, masterClassList: [...state.masterClassList, ...result], archiveStatus: result.length ? 0 : 1 }
        case 'UPDATE_PAGE_NO':
            const { flag } = action.data;
            return { ...state, archivePageNo: (flag === 0) ? state.archivePageNo + 1 : 0 }
        case 'UPDATE_ARCHIVE_STATUS':
            return { ...state, archiveStatus: action.data }
        default:
            return state;
    }
};
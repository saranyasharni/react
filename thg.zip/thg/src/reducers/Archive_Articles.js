const init = {
    archiveList: [],
    coachPageNo: 0,
    coachDetails: {}
};
export const Archive = (state = init, action) => {
    switch (action.type) {
        case 'ARCHIVE_ARTICLES_LIST':
            return { ...state, archiveList: action.data }
        case 'NEW_ARCHIVE_LIST':
            return { ...state, archiveList: [...state.archiveList, ...action.data] }
        case 'UPDATE_COACH_PAGE_NO':
            const { flag } = action.data;
            return { ...state, coachPageNo: (flag === 0) ? state.coachPageNo + 1 : 0 }
        case 'UPDATE_COACH_DETAILS':
            return { ...state, coachDetails: action.data }
        default:
            return state;
    }
};

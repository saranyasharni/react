const init = {
    coachList: [],
    coachPageNo: 0,
    coachDetails: {},
    coachSearch: ''
};
export const CoachListing = (state = init, action) => {
    switch (action.type) {
        case 'COACH_LIST':
            return { ...state, coachList: action.data }
        case 'NEW_COACH_LIST':
            return { ...state, coachList: [...state.coachList, ...action.data] }
        case 'UPDATE_COACH_PAGE_NO':
            const { flag } = action.data;
            return { ...state, coachPageNo: (flag === 0) ? state.coachPageNo + 1 : 0 }
        case 'UPDATE_COACH_DETAILS':
            return { ...state, coachDetails: action.data }
        case 'UPDATE_COACH_SEARCH':
            return { ...state, coachSearch: action.data }
        default:
            return state;
    }
};

const init = {
    fullName: '',
    email: '',
    budget: '',
    companyAddress: '',
    timeline: '',
    message: '',
    objective: '',
    advertiseStatus: 0,
    advertiseErrors: {},
};

export const AdvertiseWithUs = (state = init, action) => {
    switch (action.type) {
        case 'CHANGE_ADVERTISE_INFO':
            return { ...state, [action.field]: action.value };
        case 'ADVERTISE_STATUS':
            return { ...state, advertiseStatus: action.data };
        case 'UPDATE_ADVERTISE_ERRORS':
            return { ...state, advertiseErrors: { ...state.advertiseErrors, ...action.data } };
        case 'RESET_ADVERTISE_FORM':
            return { ...state, ...action.data };
        default:
            return state;
    }
};
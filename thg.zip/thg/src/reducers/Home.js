const init = {
    latestArticles: [],
    recommendedArticles: [],
    reelArticles: [],
    bannerList: [],
    featureArticles: [],
    sportsCategoryList: [],
    eSportsCategoryList: [],
    travelCategoryList: [],
    reviewCategoryList: [],
    exclusiveCategoryList: [],
    popularArticles: [],
    whatsHappeningList: [],
    articleDetail: [],
    THGTvList: [],
    coachLists: [],
    trendingList: [],
    homeLoader : false,
    latest_art_status:1,
    trending_art_status:1,
    recommendedArticles_status:1
};

export const Home = (state = init, action) => {
    switch (action.type) {
        case 'SET_LOADING':
            return { ...state, homeLoader: action.data }
        case 'LATEST_ARTICLES_LIST':
            return { ...state, 
                latestArticles: action.data,  
                latest_art_status:action.status
            }
        case 'RECOMMENDED_ARTICLES_LIST':
            return { ...state, recommendedArticles: action.data, 
                recommendedArticles_status:action.status}
        case 'BANNER_LIST':
            return { ...state, bannerList: action.data }
        case 'FEATURE_ARTICLES_LIST':
            return { ...state, featureArticles: action.data }
        case 'REEL_ARTICLES_LIST':
            return { ...state, reelArticles: action.data }
        case 'POPULAR_ARTICLES_LIST':
            return { ...state, popularArticles: action.data }
        case 'SPORTS_CATEGORY_LIST':
            return { ...state, sportsCategoryList: action.data }
        case 'ESPORTS_CATEGORY_LIST':
            return { ...state, eSportsCategoryList: action.data }
        case 'TRAVEL_CATEGORY_LIST':
            return { ...state, travelCategoryList: action.data }
        case 'REVIEW_CATEGORY_LIST':
            return { ...state, reviewCategoryList: action.data }
        case 'EXCLUSIVE_CATEGORY_LIST':
            return { ...state, exclusiveCategoryList: action.data }
        case 'WHATS_HAPPENING_LIST':
            return { ...state, whatsHappeningList: action.data }
        case 'ARTICLE_DETAIL':
            return { ...state, articleDetail: action.data }
        case 'THG_TV_LIST':
            return { ...state, THGTvList: action.data }
        case 'COACH_LISTS':
            return { ...state, coachLists: action.data }
        case 'TRENDING_LISTS':
            return { ...state, trendingList: action.data, trending_art_status:action.status }
        default:
            return state;
    }
};
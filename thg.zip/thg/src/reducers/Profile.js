const init = {
    userProfile: {},
    passwordErrors: {},
    errors: {},
    profileStatus: 0,
    frequencyList: [],
    category_ids: [],
    categories: [],
    catrgoryList: []
};

export const Profile = (state = init, action) => {
    switch (action.type) {
        case 'USER_PROFILE':
            return { ...state, userProfile: action.data }
        case 'CHANGE_PROFILE_INFO':
            return { ...state, userProfile: { ...state.userProfile, [action.field]: action.value } }
        case 'CHANGE_PASSWORD_INFO':
            return { ...state, userProfile: { ...state.userProfile, ...action.data } }
        case 'UPDATE_PASSWORD_ERRORS':
            return { ...state, passwordErrors: { ...state.passwordErrors, ...action.data } }
        case 'PROFILE_STATUS':
            return { ...state, profileStatus: action.data };
        case 'FREQ_LIST':
            return { ...state, frequencyList: action.data };
        case 'CATEGORY_LIST':
            return { ...state, catrgoryList: action.data };
        case 'UPDATE_ERRORS':
            return { ...state, errors: { ...state.errors, ...action.data } };
        case 'RESET_FORM':
            return { ...state, ...action.data };
        default:
            return state;
    }
};
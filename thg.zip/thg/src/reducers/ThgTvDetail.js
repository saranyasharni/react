const init = {
    streamVideoDetail: [],
    videoCommentsList: [],
    relatedVideos: [],
    latestVideos: [],
    subCommentsList: [],
    commentStatus: 0,
    replyCommentStatus: 0,
    subCommentStatus: 0,
    comment_review: '',
    reply_comment_review: '',
    comment_id: '',
    rating: '0',
    userlikedData : []
};

export const ThgTvDetail = (state = init, action) => {
    switch (action.type) {
        case 'STREAM_VIDEO_DETAIL':
            return { ...state, streamVideoDetail: action.data }
        case 'SET_LIKED_DATA':
            
            return { ...state, userlikedData: action.data }
        case 'VIDEO_COMMENTS_LIST':
            return { ...state, videoCommentsList: action.data }
        case 'RELATED_VIDEOS_LIST':
            return { ...state, relatedVideos: action.data }
        case 'LATEST_VIDEOS_LIST':
            return { ...state, latestVideos: action.data }
        case 'SUB_COMMENTS_LIST':
            return { ...state, subCommentsList: action.data }
        case 'COMMENT_STATUS':
            return { ...state, commentStatus: action.data }
        case 'REPLY_COMMENT_STATUS':
            return { ...state, replyCommentStatus: action.data }
        case 'COMMENT_REVIEW':
            return { ...state, [action.field]: action.value }
        default:
            return state;
    }
};
const init = {
    article_id: '',
    article_title: '',
    article_content: '',
    s3_image_upload_link: '',
    video_link: '',
    video_file: '',
    video_file_name:'',
    credit_line_img: '',
    credit_line_video: '',
    category_ids: [],
    categories: [],
    articleStatus: 0,
    editStatus: 0,
    articleErrors: {},
    article_image: '',
    dropdown: [],
    clearContent: 0,

};

export const CreateArticle = (state = init, action) => {
    switch (action.type) {
        case 'CHANGE_ARTICLE_INFO':
            return { ...state, [action.field]: action.value }
        case 'ARTICLE_STATUS':
            return { ...state, articleStatus: action.data };
        case 'EDIT_STATUS':
            return { ...state, editStatus: action.data };
        case 'UPDATE_ARTICLE_ERRORS':
           // console.log(action.data, 'Came345')
            return { ...state, articleErrors: { ...state.articleErrors, ...action.data } };
        case 'RESET_ARTICLE_FORM':
            return { ...state, ...action.data };
        case 'EDIT_ARTICLE_DETAIIL':
            return { ...state, ...action.data };
        case 'CATEGORY_LIST':
           // console.log(action.data, 'action.data')
            return { ...state, dropdown: action.data };
        default:
            return state;
    }
};
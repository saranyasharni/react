const init = {
    whatshappenArticleDetail: [],
    featuredEvents: [],
    loading: false 
};

export const WhatsHappeningCategory = (state = init, action) => {
    switch (action.type) {
        case 'WHATS_HAPPEN_DETAIL':
            return { ...state, whatshappenArticleDetail: action.data }
        case 'SET_LOADING':
            return { ...state, loading: action.data }
        case 'WHATS_HAPPEN_FEATURED_EVENT_LIST':
            return { ...state, featuredEvents: action.data }
        default:
            return state;
    }
};
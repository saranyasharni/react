/** @format */

import { act } from "react-dom/test-utils";

const init = {
  articleDetail: [],
  subCategoryList: [],
  commentsList: [],
  subCommentsList: [],
  designState: false,
  commentStatus: 0,
  replyCommentStatus: 0,
  subCommentStatus: 0,
  comment_review: "",
  reply_comment_review: "",
  rating: "0",
  comment_id: "",
  overList: "0",
  loading:false,
  relatedArticles : [],
  feature_related_articles: [],
  related_art_status:1,
  art_detail_status:1
};

export const ArticleDetail = (state = init, action) => {
  switch (action.type) {
    case "ARTICLE_DETAIL":
      return { ...state, articleDetail: action.data, art_detail_status:action.status};
    case "ARTICLE_DETAIL_RELATED":
      let articleDetail = [...state.articleDetail];
      articleDetail[0] = {...articleDetail[0], ['relatedArticles']:action.data};
      
      return { ...state, articleDetail:articleDetail,
        related_art_status:action.status
        };
    case "FEA_ARTICLE_DETAIL_RELATED":
      
      return { ...state, feature_related_articles: action.data };
    case 'SET_LOADING':
      return { ...state, loading: action.data }  
    case "NEXT_ARTICLE_DETAIL":
      return { ...state, articleDetail: action.data };
    case "UPDATE_DESIGN_STATE":
      return { ...state, designState: action.data };
    case "SPORTS_SUB_CATEGORY_LIST":
      return { ...state, subCategoryList: action.data };
    case "COMMENTS_LIST":
      return { ...state, commentsList: action.data };
    case "SUB_COMMENTS_LIST":
      return { ...state, subCommentsList: action.data };
    case "COMMENT_STATUS":
      return { ...state, commentStatus: action.data };
    case "REPLY_COMMENT_STATUS":
      return { ...state, replyCommentStatus: action.data };
    case "COMMENT_REVIEW":
      return { ...state, [action.field]: action.value };
    case "OVER_LIST":
      return { ...state, [action.field]: action.value };
    default:
      return state;
  }
};

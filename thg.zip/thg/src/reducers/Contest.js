const init = {
    contestList: [],
    bannerContestList: [],
    contestDetail: [],
    errors: {},
    first_name:'',
    last_name:'',
    contest_email:'',
    monthly_income:'',
    photos_desc:'',
    imageUrl: '',
    occupation: '',
    contest_occupation: '',
    dob: '',
    terms:false,
    mobile_no: '',
    contestStatus: 0,
    contestPageNo: 0,
    archiveStatus: 0,
    giveawayDetail:{},
    give_away_detail_list: [],
    all_submission_list:[],
    approved_list: [],
    items: [],
    new_approved_list : [],
    product_detail: [],
    fileType:'',
    loading:false
};

export const Contest = (state = init, action) => {
    switch (action.type) {
        case 'INPUT_CHANGE':
            return { ...state, [action.field]: action.value };
        case 'CONTEST_LIST':
            return { ...state, contestList: action.data }
        case 'GIVE_AWAY_DETAIL':
            return { ...state, give_away_detail_list: action.data }
        case 'BANNER_CONTEST_LIST':
            return { ...state, bannerContestList: action.data }
        case 'SET_LOADING':
            return { ...state, loading: action.data }
        case 'CONTEST_DETAIL':
            return { ...state, contestDetail: action.data }
        case 'CONTEST_STATUS':
            return { ...state, contestStatus: action.data }
        case 'SET_PRODUCT_DETAIL':
            return { ...state, product_detail: action.data }
        case 'UPDATE_ERRORS':
            return { ...state, errors: { ...state.errors, ...action.data } };
        case 'RESET_FORM':
            return { ...state, ...action.data};
        case 'NEW_CONTEST_LIST':
            //let result = action.data.filter(o => !state.contestList.some(v => v.ID === o.ID))
            return { ...state, contestList: [...state.contestList, ...action.data], archiveStatus: action.data.length ? 0 : 1 }
        case 'UPDATE_PAGE_NO':
            const { flag } = action.data;
            return { ...state, contestPageNo: (flag === 0) ? state.contestPageNo + 1 : 0 }
        case 'UPDATE_ARCHIVE_STATUS':
            return { ...state, archiveStatus: action.data }
        case 'GIVEAWAY_STATUS':
            return { ...state, giveawayDetail: action.data }
        case 'ALL_SUBMISSION':
            //let result_sub = action.data.filter(o => !state.items.some(v => v.ID === o.ID))
            return { ...state, items: [...state.items, ...action.data], archiveStatus: action.data.length ? 0 : 1 }
        case 'APPROVED_SUBMISSION':
            return { ...state, approved_list: action.data }
        case 'SET_NEW_APPROVED_SUB':
            //let result_approved_sub = action.data.filter(o => !state.approved_list.some(v => v.ID === o.ID))
            return { ...state, approved_list: [...state.approved_list, ...action.data], archiveStatus: action.data.length ? 0 : 1 }
        case 'SET_SUBMISSION':
            return { ...state, items: action.data }
        default:
            return state;
    }
};
const init = {
    survayList: [],
    survayStatus:2
    
};
export const Survay = (state = init, action) => {
    switch (action.type) {
        case 'SURVEY_QUESTIONS':
            return { ...state, survayList: action.data }
        case 'SURVAY_STATUS':
            return { ...state, survayStatus: action.data }
       
        default:
            return state;
    }
};

const init = {
    privacyContents: [],
    termsContents: [],
};

export const DataProtectionPolicy = (state = init, action) => {
    switch (action.type) {
        case 'PRIVACY_CONTENTS':
            return { ...state, privacyContents: action.data }
        case 'TERMS_CONTENTS':
            return { ...state, termsContents: action.data }
        default:
            return state;
    }
};
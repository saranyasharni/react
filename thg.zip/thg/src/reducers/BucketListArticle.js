const init = {
    articleLists: [],
    articleListPageno: 0,
    articleMoreStatus: 0
};

export const BucketListArticle = (state = init, action) => {
    switch (action.type) {
        case 'ARTICLE_LISTS':
            return { ...state, articleLists: [...action.data] }
        case 'MORE_ARTICLE_LISTS':
            let result = action.data.filter(o => !state.articleLists.some(v => v.ID === o.ID))
            return { ...state, articleLists: [...state.articleLists, ...result], articleMoreStatus: result.length ? 0 : 1 }
        case 'UPDATE_ARTICLE_LIST_PAGE_NO':
            const { flag } = action.data;
            return { ...state, articleListPageno: (flag === 0) ? state.articleListPageno + 1 : 0 }
        case 'UPDATE_ARTICLE_MORE_STATUS':
            return { ...state, articleMoreStatus: action.data }
        default:
            return state;
    }
};
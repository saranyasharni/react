import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import history from "../stores/history";
import ReactHtmlParser, {
    processNodes,
    convertNodeToElement,
    htmlparser2,
  } from "react-html-parser";
import ReactPhoneInput from "react-phone-input-2";
import 'react-phone-input-2/lib/style.css'


export default class ReachUs extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
        console.log(this.props.reachUs, 'reachUs')
    }
    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.reachUsStatus === 1) {
                THIS.props.resetReachUs({
                    fullName: '',
                    email: '',
                    mobileNo: '',
                    companyAddress: '',
                    interestOfChoosing: '',
                    message: '',
                    reachUsErrors: {}
                })
                jQuery('.advertise-forms .alert').html('<strong>Success!</strong> Reach Us Successfully.');
                jQuery('.advertise-forms .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".advertise-forms .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateReachUsStatus(0);
                setTimeout(function () {
                    history.push('/')
                }, 1000);
            } else if (THIS.props.reachUsStatus === 2) {
                jQuery('.advertise-forms .alert').html('<strong>Error!</strong> Failed To ReachUs.');
                jQuery('.advertise-forms .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".advertise-forms .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateReachUsStatus(0);
            }
        })
    }

    async reachUs(event) {
        event.preventDefault();
        if (await this.validateReachUsForm()) {
            this.props.createReachUs({
                fullName: this.props.fullName,
                email: this.props.email,
                mobileNo: this.props.mobileNo,
                message: this.props.message
            })
        }

    }

    async validateReachUsForm() {
        await this.props.resetReachUs({
            reachUsErrors: {}
        })
        let valid = true;
        let errors = this.props.reachUsErrors;
        if (this.props.fullName == "" || this.props.fullName == null) {
            valid = false;
            errors.fullName = "please enter name"
        }
        if (this.props.email == "" || this.props.email == null) {
            valid = false;
            errors.email = "please enter mail"
        }
        if (!this.props.email == "") {
            if (!this.validateEmail(this.props.email)) {
                valid = false;
                errors.email = "please enter a valid email"
            }
        }
        if (this.props.mobileNo == "" || this.props.mobileNo == null) {
            valid = false;
            errors.mobileNo = "please enter mobile no"
        }
        if (this.props.message == "" || this.props.message == null) {
            valid = false;
            errors.message = "please leave message"
        }
        this.props.updateReachUsErrors(errors);
        return valid;

    }

    validateEmail(email) {
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

        return expression.test(String(email).toLowerCase());
    }


    render() {

        return (


            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    <section className="reach-us-section my-account" style={{ backgroundImage: `url(${process.env.PUBLIC_URL + "/assets/images/reach-bg.png"})` }}>
                        <div className="container">
                            <div className="row">
                                <div className="col-md-6 col-sm-6 col-xs-12 reachus-form">
                                    <h1 className="text-left">Reach us</h1>
                                    <form className="advertise-forms">
                                        <div className="alert" role="alert">
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="examplename"
                                                value={(this.props.fullName) ? this.props.fullName : ''}
                                                onChange={e => {
                                                    if (e.target.value.match("^[a-zA-Z ]*$") != null) {
                                                        this.props.updateReachUsInfo('fullName', e.target.value)
                                                    }
                                                }}
                                                placeholder="Fullname"
                                            />
                                            {(this.props.reachUsErrors.fullName && this.props.reachUsErrors.fullName.length > 0) ?
                                                < span className='text-danger'>{this.props.reachUsErrors.fullName}</span> : ''}
                                            <i className="fa fa-user-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="exampleemail"
                                                value={(this.props.email) ? this.props.email : ''}
                                                onChange={e => this.props.updateReachUsInfo('email', e.target.value)}
                                                placeholder="Email"
                                            />
                                            {(this.props.reachUsErrors.email && this.props.reachUsErrors.email.length > 0) ?
                                                < span className='text-danger'>{this.props.reachUsErrors.email}</span> : ''}
                                            <i className="fa fa-envelope-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <ReactPhoneInput
                                                inputProps={{
                                                    name: 'phone'
                                                }}
                                                placeholder="Enter Phone Number"
                                                country={"sg"}
                                                value={(this.props.mobileNo) ? this.props.mobileNo : ''}
                                                onChange={phone => this.props.updateReachUsInfo('mobileNo', phone)}
                                            />
                                            {/* <input
                                                type="email"
                                                className="form-control"
                                                id="mobile"
                                                value={(this.props.mobileNo) ? this.props.mobileNo : ''}
                                                onChange={e => this.props.updateReachUsInfo('mobileNo', e.target.value)}
                                                placeholder="Mobile Number"
                                            /> */}
                                            {(this.props.reachUsErrors.mobileNo && this.props.reachUsErrors.mobileNo.length > 0) ?
                                                < span className='text-danger'>{this.props.reachUsErrors.mobileNo}</span> : ''}
                                            {/* <i className="fa fa-mobile" aria-hidden="true" /> */}
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="message"
                                                value={(this.props.message) ? this.props.message : ''}
                                                onChange={e => this.props.updateReachUsInfo('message', e.target.value)}
                                                placeholder="Message"
                                            />
                                            {(this.props.reachUsErrors.message && this.props.reachUsErrors.message.length > 0) ?
                                                < span className='text-danger'>{this.props.reachUsErrors.message}</span> : ''}
                                            <i className="fa fa-comment-o" aria-hidden="true" />
                                        </div>
                                        <button
                                            type="button"
                                            className="btn btn-primary btn-block reachus-btn"
                                            onClick={e => this.reachUs(e)}>
                                            SEND
          </button>
                                    </form>
                                </div>
                                <div className="col-md-6 col-sm-6 col-xs-12 relative">
                                <div className="location-detail">
                                    {
                                        // this.props.reachUs.map((o, k) => {
                                        //     let content = o.post_content
                                        // })
                                        // console.log(this.props.reachUs, 'this.props.reachUs'),
                                        // ReactHtmlParser(this.props.reachUs[0] ? this.props.reachUs[0].post_content : '')
                                        
                                    }

                                    
                                        <h4 className="text-left white-text">Our Location</h4>
                                        <div className="location-content">
                                            <div className="icon-loc">
                                                <i className="fa fa-map-marker" aria-hidden="true" />
                                            </div>
                                            <div className="icon-content">
                                                <p>
                                                    60 Paya Lebar Rd,
                                                    <br />
                                                    Paya Lebar Square,
                                                    <br />
                                                    #06-20,
                                                    <br />
                                                    Singapore 409051
                                                </p>
                                            </div>
                                        </div>
                                        <h4 className="text-left white-text">Email Address</h4>
                                        <div className="location-content">
                                            <div className="icon-loc">
                                                <i
                                                    className="fa fa-envelope-o"
                                                    aria-hidden="true"
                                                    id="email-loc-icon"
                                                />
                                            </div>
                                            <div className="icon-content">
                                                <p>contact@thehomeground.asia</p>
                                            </div>
                                        </div>
                                        <h4 className="text-left white-text">Contact Number</h4>
                                        <div className="location-content">
                                            <div className="icon-loc">
                                                <i
                                                    className="fa fa-mobile"
                                                    aria-hidden="true"
                                                    id="mobile-loc-icon"
                                                />
                                            </div>
                                            <div className="icon-content">
                                                <p>97482043</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>



                    <Footer />
                </div>
            </div >


        )
    }
}



import React, { Component, Fragment } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import jQuery from "jquery";
import Header from "../../containers/common/Header";
import Footer from "../../containers/common/Footer";

import MenuBar from "./MenuBar";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class SubscribedEventList extends Component {
  componentDidMount() {
    var THIS = this;

    THIS.props.updateSubscriptionEventPageNo({ draftFlag: 1 });
    THIS.props.getSubscribedEventList({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      page_no: 0,
      limit: 4,
    });
    // THIS.props.getPendingArticlesList({
    //   user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
    //   page_no: 0,
    //   limit: 4,
    //   post_status: "pending",
    // });
    // THIS.props.getPublishArticlesList({
    //   user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
    //   page_no: 0,
    //   limit: 4,
    //   post_status: "publish",
    // });
    jQuery(document).ready(function () {
      jQuery(".art-cont p").addClass("text-truncate");
      jQuery(".bucket-title .edit").click(function () {
        jQuery(this).hide();
        jQuery(this).siblings(".title").attr("contenteditable", "true");
      });

      jQuery(".bucket-title .action a").click(function () {
        jQuery(this)
          .parent(".action")
          .siblings(".title")
          .attr("contenteditable", "false");
        jQuery(this).parent(".action").siblings(".edit").show();
      });
    });
  }
  componentDidUpdate() {
    var THIS = this;
    jQuery(document).ready(function () {
      jQuery(".art-cont p").addClass("text-truncate");
      jQuery(".bucket-title .edit").click(function () {
        jQuery(this).hide();
        jQuery(this).siblings(".title").attr("contenteditable", "true");
      });

      jQuery(".bucket-title .action a").click(function () {
        jQuery(this)
          .parent(".action")
          .siblings(".title")
          .attr("contenteditable", "false");
        jQuery(this).parent(".action").siblings(".edit").show();
      });

      if (THIS.props.deleteStatus === 1) {
        // jQuery("#delete-article").modal("hide");
        console.log(jQuery(".alert1"), "DEEALERT");
        jQuery(".alert1").html(
          "<strong>Success!</strong> Article Deleted Successfully."
        );
        jQuery(".alert1").removeClass("alert-danger").addClass("alert-success");
        setTimeout(function () {
          jQuery(".alert1").removeClass("alert-success");
        }, 2000);
        THIS.props.updateDeleteStatus(0);
      } else if (THIS.props.deleteStatus === 2) {
        jQuery(".alert1").html("<strong>Error!</strong> Failed To Delete.");
        jQuery(".alert1").removeClass("alert-success").addClass("alert-danger");
        setTimeout(function () {
          jQuery(".alert1").removeClass("alert-danger");
        }, 2000);
        THIS.props.updateDeleteStatus(0);
      }

      if (THIS.props.pendingStatus === 1) {
        jQuery(".my-acc-right .alert1").html(
          "<strong>Success!</strong> Article Move to Pending Successfully."
        );
        jQuery(".my-acc-right .alert1")
          .removeClass("alert-danger")
          .addClass("alert-success");

        setTimeout(function () {
          jQuery(".my-acc-right .alert1").removeClass("alert-success");
        }, 2000);
        THIS.props.updatePendingStatus(0);
      } else if (THIS.props.pendingStatus === 2) {
        jQuery(".my-acc-right .alert1").html(
          "<strong>Error!</strong> Failed To Update."
        );
        jQuery(".my-acc-right .alert1")
          .removeClass("alert-success")
          .addClass("alert-danger");
        setTimeout(function () {
          jQuery(".my-acc-right .alert1").removeClass("alert-danger");
        }, 2000);
        THIS.props.updatePendingStatus(0);
      }

      if (THIS.props.articleMoreStatus === 1) {
        jQuery(".article-list .alert").html(
          "<strong>No More Articles</strong>"
        );
        jQuery(".article-list .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeArticleMoreStatus(0);
        setTimeout(function () {
          jQuery(".article-list .alert").removeClass("alert-danger");
        }, 2000);
      }
    });
  }

  showMoreSubscriptionEvent(e) {
    e.preventDefault();
    this.props.updateSubscriptionEventPageNo({ draftFlag: 0 });
    this.props.moreSubscribedEventListAction({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      page_no: this.props.subScriptionEventPageNo + 1,
      limit: 4,
      // post_status: "draft",
    });
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />
          {/* My Account Starts here */}
          <section className="container my-account">
            <MenuBar />
            <div className="my-acc-right">
              <div className="my-acc-cont">
                <div className="alert alert1" role="alert"></div>
                <h3>Subscribed Event List</h3>
                <div className="row mb-5">
                  <div className="tab-content col-12">
                    <div id="drafts" className="tab-pane fade in show active">
                      {this.props.subscribedEventList.length > 0 &&
                        this.props.subscribedEventList.map((o, k) => {
                          return (
                            <div
                              className="article-item your-article mb-3"
                              data-post={o.post_name}
                              data-id={o.ID}
                              key={o.ID}
                            >
                              <div className="art-img d-none d-md-block">
                                <Link to={`/category/featured-events/${o.post_name}`}>
                                <img
                                  className="lazyload"
                                  data-src={
                                    o.thumbnail_image === "" ||
                                    o.thumbnail_image === null ||
                                    o.thumbnail_image === undefined
                                      ? o.custom_feature_image_url
                                      : o.thumbnail_image
                                  }
                                  alt="icon"
                                /></Link>
                              </div>
                              <div className="art-cont">
                                <Link
                                  className="art-title text-truncate"
                                  style={{ textDecoration: "none" }}
                                  to={`/category/featured-events/${o.post_name}`}
                                >
                                  {o.post_title}
                                </Link>
                                {/* <p className="text-truncate"> */}
                                {ReactHtmlParser(o.post_content)}
                                {/* </p> */}
                              </div>
                              
                            </div>
                          );
                        })}

                      {this.props.subscribedEventList.length > 0 ? (
                        <div className="col-md-12 text-center article-list mt-5">
                          <div className="alert more" role="alert"></div>
                          <button
                            className="btn btn-orange"
                            type="button"
                            onClick={(e) => this.showMoreSubscriptionEvent(e)}
                          >
                            Show More
                          </button>
                        </div>
                      ) : (
                        <div className="no-data">
                          <img
                            className="mb-3 lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/no-data-icon.svg"
                            }
                            alt="icon"
                          />
                          <p>You have no items in draft</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* My Account Ends here */}
          

          <Footer />
        </div>
      </div>
    );
  }
}

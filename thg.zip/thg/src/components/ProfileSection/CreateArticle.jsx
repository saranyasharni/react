import React, { Component, Fragment } from 'react'

import jQuery, { post } from 'jquery'

import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'

import MenuBar from './MenuBar'

import CKEditor from 'ckeditor4-react';

import history from "../../stores/history";
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import Tippy from '@tippy.js/react'
import 'tippy.js/dist/tippy.css'

export default class CreateArticle extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        var search = window.location.pathname.split('/')[1]
        this.props.getCatList()
        if (search === 'editarticle') {
            this.props.getArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 1, slug: localStorage.getItem('edit_post') })
        } else {
            this.props.resetArticleForm({
                article_title: '',
                article_content: '',
                s3_image_upload_link: '',
                article_image: '',
                category_ids: [],
                categories: [],
                video_file: '',
                video_link: '',
                credit_text: '',
                credit_text_video: '',
                articleErrors: {}
            })
            jQuery('#video').val('');
            jQuery('#video-link').val('');
        }
    }

    componentDidMount() {
        
        var search = window.location.pathname.split('/')[1]
        //this.props.getCatList()
        if (search === 'editarticle') {
            
            this.props.getArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 1, slug: localStorage.getItem('edit_post') })
        } else {
            console.log(this.props.article_content, 'this.props.article_content')
            
            this.props.resetArticleForm({
                article_title: '',
                article_content: '',
                s3_image_upload_link: '',
                article_image: '',
                category_ids: [],
                categories: [],
                video_file: '',
                video_link: '',
                video_file_name:'',
                credit_text: '',
                credit_text_video: '',
                articleErrors: {}

            })
            jQuery('#video').val('');
            jQuery('#video-link').val('');
        }
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide();
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });

            jQuery(".bucket-title .action a").click(function () {
                jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
                jQuery(this).parent(".action").siblings(".edit").show();
            });

            window.jQuery(".category").select2({
                placeholder: "Choose Category...",
                allowClear: true
            }).val(THIS.props.category_ids).trigger('change');
            window.jQuery('.category').change(function () {
                var selectedValues = jQuery(this).val();
                var text = (jQuery('.category option:selected').length > 0) ? jQuery('.category option:selected').toArray().map(item => item.text).join().split(',') : [];
                // var textValues = text.split(',')
                console.log('text', jQuery('.category option:selected').length)
                THIS.props.changeArticlesInfo('categories', text)
                THIS.props.changeArticlesInfo('category_ids', selectedValues)
            });
        })
    }
    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide();
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });

            jQuery(".bucket-title .action a").click(function () {
                jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
                jQuery(this).parent(".action").siblings(".edit").show();
            });

            window.jQuery(".category").select2({
                placeholder: "Choose Category...",
                allowClear: true
            })
            if (THIS.props.categories.length > 0 && THIS.props.categories !== undefined || THIS.props.categories !== null) {
                window.jQuery("#tagsInput").tagsinput('removeAll');
                jQuery.each(THIS.props.categories, function (index, value) {
                    console.log('value', value)
                    window.jQuery('#tagsInput').tagsinput('add', value);
                });
            } else {
                window.jQuery("#tagsInput").tagsinput('removeAll');
            }

            if (THIS.props.articleStatus === 1) {
                THIS.props.resetArticleForm({
                    article_title: '',
                    article_content: '',
                    s3_image_upload_link: '',
                    category_ids: [],
                    categories: [],
                    article_image: '',
                    video_file: '',
                    video_link: '',
                    video_file_name: '',
                    credit_text: '',
                    credit_text_video: '',
                    articleErrors : {}

                })
                jQuery('#video').val('');
                jQuery('#video-link').val('');
                jQuery('.create-article .alert').html('<strong>Success!</strong> Article Created Successfully.');
                jQuery('.create-article .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".create-article .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateArticleStatus(0);
                setTimeout(function () {
                    history.push(`/yourarticles/${localStorage.getItem('user_login')}`)
                }, 1000);
            } else if (THIS.props.articleStatus === 2) {
                jQuery('.create-article .alert').html('<strong>Error!</strong> Failed To Create.');
                jQuery('.create-article .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".create-article .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateArticleStatus(0);
            }

            if (THIS.props.editStatus === 1) {
                THIS.props.resetArticleForm({
                    article_title: '',
                    article_content: '',
                    s3_image_upload_link: '',
                    category_ids: [],
                    categories: [],
                    article_image: '',
                    video_file: '',
                    video_link: '',
                    credit_text: '',
                    credit_text_video: '',
                    articleErrors : {}
                })
                jQuery('#video').val('');
                jQuery('#video-link').val('');
                jQuery('.create-article .alert').html('<strong>Success!</strong> Article Updated Successfully.');
                jQuery('.create-article .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".create-article .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateEditStatus(0);
                setTimeout(function () {
                    history.push(`/yourarticles/${localStorage.getItem('user_login')}`)
                }, 1000);
            } else if (THIS.props.editStatus === 2) {
                jQuery('.create-article .alert').html('<strong>Error!</strong> Failed To Update.');
                jQuery('.create-article .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".create-article .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateEditStatus(0);
            } else if (THIS.props.editStatus === 3) {
                window.jQuery('#remove-content').modal('hide')
                THIS.props.updateEditStatus(0);
            }

        })


    }

    componentWillReceiveProps(nextProps) {
        // console.log(nextProps.location, 'nextprops')
        // console.log(this.props.location, 'nextprops12')
        
        if (nextProps.location !== this.props.location) {
            let searchParam = (nextProps.location.pathname).split('/')[1];
            if (searchParam === 'editarticle') {
                this.props.getArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 1, slug: localStorage.getItem('edit_post') })
            } else {
                this.props.resetArticleForm({
                    article_title: '',
                    article_content: '',
                    s3_image_upload_link: '',
                    article_image: '',
                    category_ids: [],
                    categories: [],
                    video_file: '',
                    video_link: '',
                    video_file_name:'',
                    credit_text: '',
                    credit_text_video: '',
                    articleErrors: {}
                })
                jQuery('#video').val('');
                jQuery('#video-link').val('');
            }
        }
    }

    handleChange = (text, medium) => {
        this.props.changeArticlesInfo('article_content', text)

    }
    handleVideo = (e) => {
        let errors = this.props.articleErrors;
        if (e.target.files[0]) {
            let file =  e.target.files[0].size 
            // console.log(file, "videoFiles")
            if (file) {
                let compareFile = file / 1024 / 1024
                // console.log(compareFile, "videoFiles")
                if (compareFile > 500.2) {
                    errors.articleVideo = 'Please Upload less than 500MB';
                    jQuery('#video').val('');
                } else {
                    console.log('inner', jQuery('.video-upload-element').html(`<div class="loader-video d-block" style="margin-left: 39%;margin-right: 49%"><img class="img-fluid" src=${process.env.PUBLIC_URL + "/assets/images/loading.gif"}></img></div>`))
                    errors.articleVideo = '';
                    
                    this.props.articleImageUpload({ upload_file: e.target.files[0], flag: 1 })
                    var fileName = e.target.files[0].name;
                    
                    jQuery('#show_file_aftr').show()
                    jQuery('#show_file_aftr').val(fileName);
                    jQuery('#video').hide()
                    
                }
                this.props.updateArticleErrors(errors);
            }
        }
        
    }

    handleChangeMedia = (e) => {
        let self = this
        var _URL = window.URL || window.webkitURL;
        let errors = self.props.articleErrors;
        var file, img;
        if ((file = e.target.files[0])) {
            img = new Image();
            var objectUrl = _URL.createObjectURL(file);
            img.onload = function () {
                //alert(this.width + " " + this.height);
                if (this.width > 2000 && this.height > 1024) {
                errors.articleImage = "Image resolution too high. It should be 2000 x 1024px"
                jQuery('.img-wrap img').attr('src', `${process.env.PUBLIC_URL + "/assets/images/img-layer.svg"}`); 
                } else {
                    jQuery('.loader-pro').removeClass('d-none')
                    jQuery('.loader-pro').addClass('d-block')
                    jQuery('.img-wrap').addClass('d-none')
                    jQuery('.img-wrap').removeClass('d-block')
                    jQuery('.img-wrap img').attr('src', URL.createObjectURL(file));
                    jQuery('.img-wrap img').css({ 'margin-top': '45px'});
                    errors.articleImage = ""
                    self.props.articleImageUpload({ upload_file:file, flag: 0 })
                } 
                self.props.updateArticleErrors(errors);
               // _URL.revokeObjectURL(objectUrl);
            };
            img.src = objectUrl;
        }

    }
 
    publishArticle(event) {
        event.preventDefault();
        if (this.validateArticleForm()) {
            var search = window.location.pathname.split('/')[1]
            if (search === 'editarticle') {
                
                this.props.updateArticle({    
                    user_id: localStorage.getItem('user_id'), article_title: this.props.article_title,
                    article_content: this.props.article_content, category_ids: this.props.category_ids,
                    s3_image_upload_link: this.props.article_image, article_id: this.props.article_id,
                    custom_video_file: this.props.video_file, custom_s3_video_link: this.props.video_link,
                    credit_video: this.props.credit_text_video,
                    credit_image:this.props.credit_text,
                    post_status:'pending'
                })
                
            } else {
                
                this.props.createNewArticle({
                    user_id: localStorage.getItem('user_id'), article_title: this.props.article_title,
                    article_content: this.props.article_content, category_ids: this.props.category_ids,
                    s3_image_upload_link: this.props.article_image, custom_video_file: this.props.video_file,
                    custom_s3_video_link: this.props.video_link,
                    credit_video: this.props.credit_text_video,
                    credit_image:this.props.credit_text
                })
            }
        }

    }

    scheduleArticle(event) {
        event.preventDefault();
        if (this.validateArticleForm()) {
            var search = window.location.pathname.split('/')[1]
            if (search === 'editarticle') {
                this.props.updateArticle({    
                    user_id: localStorage.getItem('user_id'), article_title: this.props.article_title,
                    article_content: this.props.article_content, category_ids: this.props.category_ids,
                    s3_image_upload_link: this.props.article_image, article_id: this.props.article_id,
                    custom_video_file: this.props.video_file, custom_s3_video_link: this.props.video_link,
                    post_status:'draft',
                    credit_video: this.props.credit_text_video,
                    credit_image:this.props.credit_text

                })
                
            } else {
                
                this.props.scheduleNewArticle({
                    user_id: localStorage.getItem('user_id'), article_title: this.props.article_title,
                    article_content: this.props.article_content, category_ids: this.props.category_ids,
                    s3_image_upload_link: this.props.article_image, custom_video_file: this.props.video_file,
                    custom_s3_video_link: this.props.video_link,
                    credit_video: this.props.credit_text_video,
                    credit_image:this.props.credit_text
                    
                })
            }
        }

    }

    validateArticleForm() {
        let valid = true;
        let errors = this.props.articleErrors;
        if (this.props.article_title == "" || this.props.article_title == null) {
            valid = false;
            errors.articleTitle = "Cannot be Empty"
        }
        if (this.props.article_content == "" || this.props.article_content == null) {
            valid = false;
            errors.articleContent = "Cannot be Empty"
        }
        if (this.props.category_ids == "") {
            valid = false;
            errors.category = "Please Select Category"
        }
        if (this.props.article_image == "") {
            valid = false;
            errors.articleImage = "Please Select Image"
        }
        this.props.updateArticleErrors(errors);
        return valid;

    }

    render() {
        return (
            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    {
                        /* My Account Starts here */
                    }
                    <section className="container my-account">
                        <MenuBar />
                        {
                           
                        }
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <h3>Create Article</h3>
                                <div className="row mb-5">
                                    <form className="create-article col-md-12">
                                        <div className="alert" role="alert">
                                        </div>
                                        <div className="form-group mb-5">
                                            <input
                                                type="text"
                                                className="border-0 form-control"
                                                name
                                                style={{ fontWeight: 300 }}
                                                value={(this.props.article_title) ? this.props.article_title : ''}
                                                onChange={e => this.props.changeArticlesInfo('article_title', e.target.value)}
                                                placeholder="Title"
                                            />
                                            {(this.props.articleErrors.articleTitle && this.props.articleErrors.articleTitle.length > 0) ?
                                                < span className='text-danger'>{this.props.articleErrors.articleTitle}</span> : ''}
                                        </div>
                                        <div className="form-group mb-5">
                                            {
                                                // console.log(this.props.dropdown, 'category_ids37')
                                            }
                                            <select className="form-control category" multiple value={this.props.category_ids}>
                                            {
                                                    this.props.dropdown.length > 0 &&
                                                    this.props.dropdown.map((c, d) => (
                                                        
                                                        <optgroup value={c.term_id} label={c.name}>
                                                            {
                                                                c.sub_categories.length <= 0 && 
                                                                <option value={c.term_id} class="optionGroup">{c.name}</option>
                                                            }
                                                            
                                                            {
                                                                c.sub_categories.length > 0 &&
                                                                c.sub_categories.map((m, n) => (
                                                                   
                                                                    <option key={n}
                                                                        value={m.term_id}>
                                                                        {
                                                                         m.name}
                                                                    </option>
                                                                ))
                                                            }
                                                        </optgroup>

                                                    ))
                                                }
                                                {/* <option value="0">Parent Tag</option>
                                                <option value="1">&nbsp;&nbsp;&nbsp;Child Tag1</option>
                                                <option value="2">&nbsp;&nbsp;&nbsp;Child Tag2</option> */}
                                            </select>
                                            {(this.props.articleErrors.category && this.props.articleErrors.category.length > 0) ?
                                                < span className='text-danger'>{this.props.articleErrors.category}</span> : ''}
                                        </div>
                                        <div className="form-group mb-5" style={{ height: '500px' }}>
                                            <CKEditor
                                                data={this.props.article_content}
                                                type="classic"
                                                onChange={evt => this.props.changeArticlesInfo('article_content', evt.editor.getData())}
                                                config={
                                                    {
                                                        extraPlugins: 'easyimage,colorbutton,justify,showblocks,font,smiley,embed,autoembed,image2',
                                                        removePlugins: 'image',
                                                        embed_provider: '//ckeditor.iframe.ly/api/oembed?url={url}&callback={callback}',
                                                        contentsCss: [
                                                            'http://cdn.ckeditor.com/4.14.0/full-all/contents.css',
                                                            'https://ckeditor.com/docs/vendors/4.14.0/ckeditor/assets/css/widgetstyles.css'
                                                        ],
                                                        removeButtons: 'About,Source',
                                                        allowedContent: true,
                                                        height: 350,
                                                        image2_alignClasses: ['image-align-left', 'image-align-center', 'image-align-right'],
                                                        image2_disableResizer: false,
                                                        cloudServices_uploadUrl: 'https://33333.cke-cs.com/easyimage/upload/',
                                                        cloudServices_tokenUrl: 'https://33333.cke-cs.com/token/dev/ijrDsqFix838Gh3wGO3F77FSW94BwcLXprJ4APSp3XQ26xsUHTi0jcb1hoBt',
                                                        easyimage_styles: {
                                                            gradient1: {
                                                                group: 'easyimage-gradients',
                                                                attributes: {
                                                                    'class': 'easyimage-gradient-1'
                                                                },
                                                                label: 'Blue Gradient',
                                                                icon: 'https://ckeditor.com/docs/ckeditor4/4.14.0/examples/assets/easyimage/icons/gradient1.png',
                                                                iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.14.0/examples/assets/easyimage/icons/hidpi/gradient1.png'
                                                            },
                                                            gradient2: {
                                                                group: 'easyimage-gradients',
                                                                attributes: {
                                                                    'class': 'easyimage-gradient-2'
                                                                },
                                                                label: 'Pink Gradient',
                                                                icon: 'https://ckeditor.com/docs/ckeditor4/4.14.0/examples/assets/easyimage/icons/gradient2.png',
                                                                iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.14.0/examples/assets/easyimage/icons/hidpi/gradient2.png'
                                                            },
                                                            noGradient: {
                                                                group: 'easyimage-gradients',
                                                                attributes: {
                                                                    'class': 'easyimage-no-gradient'
                                                                },
                                                                label: 'No Gradient',
                                                                icon: 'https://ckeditor.com/docs/ckeditor4/4.14.0/examples/assets/easyimage/icons/nogradient.png',
                                                                iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.14.0/examples/assets/easyimage/icons/hidpi/nogradient.png'
                                                            }
                                                        },
                                                        easyimage_toolbar: [
                                                            'EasyImageFull',
                                                            // 'EasyImageSide',
                                                            'EasyImageAlt'
                                                        ],

                                                    }
                                                }
                                              
                                            />
                                         {(this.props.articleErrors.articleContent && this.props.articleErrors.articleContent.length > 0) ?
                                                        < span className='text-danger'>{this.props.articleErrors.articleContent}</span> : ''}
                                        </div>
                                        <h3 className="col-12">Media</h3>
                                        <div className="art-preview col-md-12">
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <h4>Feature Video Link</h4>
                                                    <div className="form-group mt-2">
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                           // id="video-link"
                                                            value = {this.props.video_link? this.props.video_link: ""}
                                                            onWheel={event => { event.preventDefault(); 
                                                                
                                                            }}
                                                            placeholder="http://www.example.com"
                                                            onChange={e => {{
                                                                e.preventDefault()
                                                                this.props.changeArticlesInfo('video_link', e.target.value)
                                                            }
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="form-group">
                                                        <h4>Feature Video File <span className="lt_cng">- Max 500MB</span> </h4>
                                                        <input className="form-control" 
                                                       
                                                        id="videofile" type="file" style={{ display: "none" }} accept="video/*" onChange={(e) => {{
                                                            this.handleVideo(e);
                                                            if (e.target.files[0]) {
                                                                // console.log('inner', jQuery('.video-upload-element').html(`<div class="loader-video d-block" style="margin-left: 39%;margin-right: 49%"><img class="img-fluid" src=${process.env.PUBLIC_URL + "/assets/images/loading.gif"}></img></div>`))
                                                                // this.props.articleImageUpload({ upload_file: e.target.files[0], flag: 1 })
                                                                // var fileName = e.target.files[0].name;
                                                                // jQuery('#video').val(fileName);
                                                            }

                                                        }}} />

                                                        <div
                                                            className="form-group">
                                                            <input
                                                                type="text"
                                                                className="form-control"
                                                                id="video"
                                                                placeholder= {(this.props.video_file) ? " " : "No file selected" }
                                                                
                                                                value = {
                                                                    this.props.video_file_name? this.props.video_file_name: this.props.video_file
                                                                }
                                                                
                                                                
                                                            />
                                                             <input
                                                                type="text"
                                                                style = {{display:'none'}}
                                                                className="form-control "
                                                                id="show_file_aftr"

                                                            />
                                                        </div>
                                                        <div className="form-group">
                                                            <button className="btn btn-green-flat mt-2 video-upload-element" type="button" onClick={() => jQuery('#videofile').click()}>CHOOSE VIDEO FILE</button>
                                                            {/* <div className="loader-video d-none" style={{ marginLeft: '25%', marginRight: '50%', marginTop: '25%' }}>

                                                                <img
                                                                    className="img-fluid"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                                                    alt="Avatar"
                                                                />
                                                            </div> */}
                                                        </div>
                                                        <div className="form-group">
                                                        <h4>Feature Video Credit Line (if applicable)</h4>
                                                            <input
                                                                type="text"
                                                                className="form-control"
                                                                placeholder="Example: Marina Bay Sands"
                                                                id="video"
                                                                value = {
                                                                    this.props.credit_text_video? this.props.credit_text_video: ''
                                                                }
                                                              
                                                                onChange={e => {{
                                                                    e.preventDefault()
                                                                    this.props.changeArticlesInfo('credit_text_video', e.target.value)
                                                                }
                                                                }}
                                                                
                                                            />
                                                             <input
                                                                type="text"
                                                                style = {{display:'none'}}
                                                                className="form-control "
                                                                id="show_file_aftr"

                                                            />
                                                        </div>

                                                    </div>
                                                    {(this.props.articleErrors.articleVideo && this.props.articleErrors.articleVideo.length > 0) ?
                                                        < span className='text-danger'>{this.props.articleErrors.articleVideo}</span> : ''}
                                                </div>
                                                <div className="col-md-6">
                                                    
                                                    <input id="articleImage" type="file" style={{ display: "none" }} accept="image/*" onChange={(e) => {
                                                        {
                                                            this.handleChangeMedia(e);   
                                                        
                                                    }}} />
                                                    <h4>Feature Image</h4>
                                                    <Tippy content={<div><p>1. Look for images that are in landscape. Do not submit images that are in portrait.</p> <p>2. Image needs to be 2000 X 1047 pixels (maintain aspect ratio according to width 2000).</p><p>3. Ensure that the image is not pixelated, clearly taken and the lighting is good.</p><p>4. If the image you have uploaded does not meet the above requirements, we reserve the right to replace it with an alternative image.</p></div>} >
                                                    <i class="fa fa-info-circle" aria-hidden="true"></i>
                                                    </Tippy>
                                                    <div className="img-wrap" 
                                                    data-toggle="tooltip"
                                                    onClick={() => 
                                                        jQuery('#articleImage').click()}>
                                                         
                                                        <img className="mb-4 lazyload" data-src={(this.props.article_image) ? this.props.article_image : process.env.PUBLIC_URL + "/assets/images/img-layer.svg"} alt="icon" style={{ height: '50%', width: '50%' }} 
                                                        src = {this.props.article_image ? this.props.article_image:process.env.PUBLIC_URL + "/assets/images/img-layer.svg"}
                                                        />
                                                    
                                                    {(this.props.article_image) ? " " : <p className="mb-0"> No file selected </p>}
                                                    </div>
                                                    <div className="loader-pro d-none" style={{ marginLeft: '25%', marginRight: '50%', marginTop: '25%' }}>
                                                    <img
                                                        className="img-fluid lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                                        alt="Avatar"
                                                    />
                                                    </div>
                                                    {(this.props.articleErrors.articleImage && this.props.articleErrors.articleImage.length > 0) ?
                                                        <span className='text-danger'>{this.props.articleErrors.articleImage}</span> : ''}
                                                        <div className="form-group">
                                                            <button className="btn btn-green-flat mt-2 image-upload-element" type="button" onClick={() => jQuery('#articleImage').click()}>CHOOSE IMAGE</button>
                                                           
                                                        </div>
                                                    {(this.props.article_image) ? <br/> : " " }

                                                    <div className="form-group">
                                                        <h4>Feature Image Credit Line (if applicable)</h4>
                                                            <input
                                                                type="text"
                                                                className="form-control"
                                                                placeholder="Example: Marina Bay Sands"
                                                                value = {this.props.credit_text ? this.props.credit_text :''}
                                                                
                                                                onChange={e => {{
                                                                    e.preventDefault();
                                                                    this.props.changeArticlesInfo('credit_text', e.target.value)
                                                                }
                                                                }}
                                                                
                                                            />
                                                             <input
                                                                type="text"
                                                                style = {{display:'none'}}
                                                                className="form-control "
                                                                id="show_file_aftr"

                                                            />
                                                        </div>

                                                </div>

                                            </div>
                                            <div className="col-md-12 text-right px-0 mt-4 crete_btn_grp">
                                            <button className="btn btn-trans mr-2" type="button" data-toggle="modal" data-target="#remove-content">Cancel</button>
                                            <button className="btn btn-orange-flat mr-2" disabled={(this.props.article_image === '') ? true : false} onClick={e => this.scheduleArticle(e)}>Save to Draft</button>
                                            <button className="btn btn-green-flat" disabled={(this.props.article_image === '') ? true : false} onClick={e => this.publishArticle(e)}>Submit For Approval</button>
                                        </div>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>
                    {
                        /* My Account Ends here */
                    }

                    {/* Remove Popup Starts here */}
                    <div
                        className="modal fade"
                        id="remove-content"
                        tabIndex={-1}
                        role="dialog"
                        aria-hidden="true"
                    >
                        <div className="modal-dialog modal-dialog-centered" role="document">
                            <div className="modal-content">
                                <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                                </button>
                                <div className="modal-body text-center p-5">
                                    <img
                                        className="img-fluid mb-4 lazyload"
                                        data-src={process.env.PUBLIC_URL + "/assets/images/doc-remove-icon.svg"}
                                        alt="icon"
                                    />
                                    <h3>Are you sure want to clear?</h3>
                                    <p className="sub-title">
                                        Your Content Will Be Erased.
          </p>
                                    <div className="alert"></div>
                                    <div className="col-12 mt-4 btn-wrap">
                                        <button className="btn btn-gray" type="button" data-dismiss="modal">Cancel</button>
                                        <button className="btn btn-red" type="button" onClick={(e) => {
                                            e.preventDefault()
                                            this.props.resetArticleForm({
                                                article_title: '',
                                                article_content: '',
                                                s3_image_upload_link: '',
                                                article_image: '',
                                                category_ids: [],
                                                categories: [],
                                                editStatus: 3,
                                                video_link: '',
                                                video_file: '',
                                                credit_line_video:"",
                                                credit_line_img:'',
                                                credit_text: '',
                                                credit_text_video: '',
                                                articleErrors: {}
                                            })
                                            jQuery('#video').val('');
                                            jQuery('#video-link').val('');
                                        }}>Ok</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Remove Popup Ends here */}

                    <Footer />
                </div>
            </div >


        )
    }
}



import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'
import MenuBar from './MenuBar'
import ReactPhoneInput from "react-phone-input-2";
import 'react-phone-input-2/lib/style.css'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import {BrowserRouter, Route, Link} from 'react-router-dom';

export default class Profile extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getUserProfile({ user_id: localStorage.getItem('user_id') })
        this.props.getFreqList()
        this.props.getCatList()
    }

    componentDidMount() {
        
        let THIS = this;
        jQuery(document).ready(function () {
            jQuery('.profile-form .select2-container').css('pointer-events', 'none')
            jQuery('#update_save_pro').hide()
            jQuery('#update_cancel_pro').hide()

            jQuery(".change-pass").click(function () {
                jQuery(this).hide();
                jQuery(".change-pass-encl").slideDown();
            });

            jQuery(".cancel-pass").click(function () {
                jQuery(".change-pass").show();
                jQuery(".change-pass-encl").slideUp();
                THIS.props.resetForm({
                    
                })
                THIS.props.updatePassowrdErrors({
                    password: '', newPassword: '', confirmPassword: ''
                });
            });

            window.jQuery(".pass-visible").off('click').click(function () {
                console.log('this', jQuery(this))
                // jQuery(this).toggleClass("show-pass");

            })
            // jQuery(".pass-visible").off('click').click(function () {
            //     if (jQuery(this).closest('.password-div').find('input').attr('type') === 'password') {
            //         jQuery(this).closest('.invisible-icon').attr('src', process.env.PUBLIC_URL + "/assets/images/visible.svg")
            //         jQuery(this).closest('.password-div').find('input').attr('type', 'text')
            //     } else {
            //         jQuery(this).closest('.password-div').find('input').attr('type', 'password')
            //     }
            // })

            window.jQuery('.input-group.date').datepicker(
                {
                    format: "dd/mm/yyyy",
                    endDate: "+0d"
                }).off('change').change((e) => { THIS.props.changeProfileInfo('date_of_birth', e.target.value) });
               
            window.jQuery(".select2").select2({
                closeOnSelect : false,
                placeholder : "Select Category",
                allowHtml: true,
                allowClear: true,
                
            }).val(THIS.props.userProfile.interested_in).trigger('change');
            window.jQuery(".select2").select2({disabled:true});

            window.jQuery('.select2').on('select2:close', function () {
                
                var selectedValues = jQuery(this).val();
                THIS.props.changeProfileInfo('interested_in', selectedValues)
            });

            // jQuery(".profile-form label .edit").click(function () {
            //     jQuery(this).hide();
            //     jQuery(this).parents(".form-group").find(".editout").show();
            //     jQuery(this).parents(".form-group").addClass("active");
            //     jQuery(this).parents(".form-group").find(".form-control").focus();
            // });

            // jQuery(".profile-form label .action i").click(function () {
            //     jQuery(this).parents(".form-group").find(".editout").hide();
            //     jQuery(this).parents(".form-group").find(".edit").show();
            //     jQuery(this).parents(".form-group").removeClass("active");
            //     jQuery(this).parents(".form-group").find(".form-control").focusout()
            // });
            window.jQuery('#tagsInput').off('change').change(() => {
                THIS.props.changeProfileInfo('notify', window.jQuery('#tagsInput').tagsinput('items'))
            })

        });
    }

    componentDidUpdate() {
        let THIS = this;
        jQuery(document).ready(function () {
            jQuery('.profile-form .select2-container').css('pointer-events', 'none')
            jQuery(".change-pass").click(function () {
                jQuery(this).hide();
                jQuery(".change-pass-encl").slideDown();
            });

            jQuery(".cancel-pass").click(function () {
                
                jQuery(".change-pass").show();
                jQuery(".change-pass-encl").slideUp();

                THIS.props.updatePassowrdErrors({
                    password: '', newPassword: '', confirmPassword: ''
                });
            });

            jQuery(".pass-visible").off('click').click(function () {
                console.log('ele', jQuery(this).closest(".pass-visible"))
                jQuery(this).closest('.password-div').find('.pass-visible').toggleClass('show-pass');
                if (jQuery(this).closest('.password-div').find('input').attr('type') === 'password') {
                    jQuery(this).closest('.visible-icon').attr('src', process.env.PUBLIC_URL + "/assets/images/visible.svg")
                    jQuery(this).closest('.password-div').find('input').attr('type', 'text')
                } else {
                    jQuery(this).closest('.password-div').find('input').attr('type', 'password')
                }
            })

            window.jQuery('.input-group.date').datepicker({ format: "dd/mm/yyyy", endDate: "+0d" }).off('change').change((e) => { THIS.props.changeProfileInfo('date_of_birth', e.target.value) });

            window.jQuery(".select2").select2({
                closeOnSelect : false,
                placeholder : "Select Category",
                allowHtml: true,
                allowClear: true,
                
            }).val(THIS.props.userProfile.interested_in).trigger('change');
            // window.jQuery(".select2").select2({disabled:true});

            window.jQuery('.select2').on('select2:close', function () {
                
                var selectedValues = jQuery(this).val();
                THIS.props.changeProfileInfo('interested_in', selectedValues)
            });

            // jQuery(".profile-form label .edit").click(function () {
            //     jQuery(this).hide();
            //     jQuery(this).parents(".form-group").find(".editout").show();
            //     jQuery(this).parents(".form-group").addClass("active");
            //     jQuery(this).parents(".form-group").find(".form-control").focus();
            // });

            // jQuery(".profile-form label .action i").click(function () {
            //     jQuery(this).parents(".form-group").find(".editout").hide();
            //     jQuery(this).parents(".form-group").find(".edit").show();
            //     jQuery(this).parents(".form-group").removeClass("active");
            //     jQuery(this).parents(".form-group").find(".form-control").focusout()
            // });

            window.jQuery('#tagsInput').off('change').change(() => {
                THIS.props.changeProfileInfo('interested_in', window.jQuery('#tagsInput').tagsinput('items'))
            })
            if (THIS.props.userProfile.interested_in !== undefined || THIS.props.userProfile.interested_in !== null || THIS.props.userProfile.interested_in !== '') {

                jQuery.each(THIS.props.userProfile.interested_in, function (index, value) {
                    window.jQuery('#tagsInput').tagsinput('add', value);
                });
            }

            window.jQuery('#tagsInput').off('change').change(() => {
                THIS.props.changeProfileInfo('interested_in', window.jQuery('#tagsInput').tagsinput('items'))
            })

            if (THIS.props.profileStatus === 1) {
                jQuery('.loader-page').addClass('d-none')
                jQuery('.profile-form').removeClass('d-none')
                jQuery('.loader-page').removeClass('d-block')
                jQuery('.profile-form').addClass('d-block')
                jQuery('.profile-form .alert').html('<strong>Success!</strong> Information Updated Successfully.');
                jQuery('.profile-form .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".profile-form .alert").removeClass('alert-success');
                }, 2000);
                jQuery(".form-group").find(".editout").hide();
                jQuery(".form-group").find(".edit").show();
                jQuery(".form-group").removeClass("active");
                jQuery('#editable_pro').show()
                jQuery('#update_save_pro').hide()
                jQuery('#update_cancel_pro').hide()        
                jQuery('.profile-form .form-control').css('pointer-events', 'none')
                jQuery('.profile-form .select2-container').css('pointer-events', 'none')
                window.jQuery(".select2").select2({disabled:true});
                THIS.props.updateProfileStatus(0);
            } else if (THIS.props.profileStatus === 2) {
                jQuery('.loader-pro').removeClass('d-block')
                jQuery('.loader-pro').addClass('d-none')
                jQuery('.prof-img').addClass('d-block')
                jQuery('.prof-img').removeClass('d-none')
                jQuery('.profile-form .alert').html('<strong>Success!</strong> Profile Picture Uploaded.');
                jQuery('.profile-form .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".profile-form .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateProfileStatus(0);
            } else if (THIS.props.profileStatus === 4) {
                jQuery('.profile-form .alert').html('<strong>Success!</strong> Password Updated.');
                jQuery('.profile-form .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".profile-form .alert").removeClass('alert-success');
                }, 2000);
                jQuery(".pass-visible").addClass("show-pass")
                jQuery('.password-div').find('input').attr('type', 'password')
                THIS.props.changePasswordInformation({ password: '', new_password: '', confirm_password: '' })
                jQuery(".cancel-pass").click()
                THIS.props.updateProfileStatus(0);
            } else if (THIS.props.profileStatus === 3) {
                jQuery('.profile-form .alert').html('<strong>Error!</strong> Failed To Update.');
                jQuery('.profile-form .alert').removeClass('alert-success').addClass('alert-danger')
                jQuery('.loader-page').removeClass('d-block')
                jQuery('.loader-page').addClass('d-none')
                jQuery('.profile-form').removeClass('d-none')
                jQuery('.profile-form').addClass('d-block')
                setTimeout(function () {
                    jQuery(".profile-form .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateProfileStatus(0);
            }

        });
    }

    async updateProfileInfo(event) {
        event.preventDefault();
        if (await this.validateForm()) {
            jQuery('.loader-page').removeClass('d-none')
            jQuery('.profile-form').addClass('d-none')
            jQuery('.loader-page').addClass('d-block')
            jQuery('.profile-form').removeClass('d-block')
            console.log(this.props.userProfile, 'this.props.userProfile')
            this.props.updateProfile({ ...this.props.userProfile, user_id: localStorage.getItem('user_id') })
        }
    }

    async validateForm() {
        await this.props.resetForm({
            errors: {}
        })
        let valid = true;
        let errors = this.props.errors;
        if (this.props.userProfile.user_email == "") {
            valid = false;
            errors.email = "please enter a mail"
        }
        if (!this.props.userProfile.user_email == "") {
            if (!this.validateEmail(this.props.userProfile.user_email)) {
                valid = false;
                errors.email = "please enter a valid email"
            }
        }
        this.props.updateErrors(errors);
        return valid;

    }



    validateEmail(email) {
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

        return expression.test(String(email).toLowerCase());
    }

    removeProfile(event) {
        event.preventDefault()
        this.props.changeProfileInfo('user_avatar', '')
        if (this.props.userProfile.ID !== null) {
            this.props.removeProfilePicture({ image_id: this.props.userProfile.ID, user_id: localStorage.getItem('user_id') })
        }

    }


    changePassword(event) {
        event.preventDefault()
        if (this.validPassword()) {
            this.props.updatePassword({ ...this.props.userProfile, user_id: localStorage.getItem('user_id') })
        }
    }

    validPassword() {
        let valid = true;
        let errors = this.props.passwordErrors;
        if (!this.props.userProfile.password) {
            valid = false;
            errors.password = "Cannot be Empty"
        } else {
            errors.password = ""
        }
        if (!this.props.userProfile.new_password) {
            valid = false;
            errors.newPassword = "Cannot be Empty"
        } else {
            errors.newPassword = ""
        }
        if (!this.props.userProfile.confirm_password) {
            valid = false;
            errors.confirmPassword = "Cannot be Empty"
        } else {
            errors.confirmPassword = ""
        }
        if (this.props.userProfile.new_password !== this.props.userProfile.confirm_password) {
            valid = false;
            errors.newPassword = "Password Not Matching"
            errors.confirmPassword = "Password Not Matching"
        }
        this.props.updatePassowrdErrors(errors);
        return valid;

    }

    makeEditable = (e) => {
        jQuery('#editable_pro').hide()
        window.jQuery(".select2").select2({disabled:false});
        jQuery('#update_save_pro').show()
        jQuery('#update_cancel_pro').show()
        jQuery('.profile-form .form-control').css('pointer-events', 'fill')
        jQuery('.profile-form .select2-container').css('pointer-events', 'fill')
        jQuery('#first_name').focus()
    }

    cancelProfileInfo = (e) => {
        jQuery('#editable_pro').show()
        window.jQuery(".select2").select2({disabled:true});
        jQuery('#update_save_pro').hide()
        jQuery('#update_cancel_pro').hide()        
        jQuery('.profile-form .form-control').css('pointer-events', 'none')
        jQuery('.profile-form .select2-container').css('pointer-events', 'none')
    }


    render() {

        return (
            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    {
                        /* My Account Starts here */
                    }
                    <section className="container my-account">
                        <MenuBar />
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <div className="my-acc-head">
                                    <h3>Profile</h3>
                                    <div>
                                        <button className="btn btn-asphalt"
                                        id = "editable_pro"
                                        type = 'button'
                                        style = {{marginRight: '19rem'}}
                                        onClick = {(e) => {this.makeEditable(e)}}
                                        >
                                        Edit
                                        </button>

                                        <button 
                                        className="btn btn-orange"
                                        id = "update_save_pro"
                                        type ='button'
                                        style = {{marginRight:'20px'}}
                                        onClick={(e) => this.updateProfileInfo(e)}
                                        >
                                            Update
                                        </button>

                                        <button 
                                            className="btn btn-gray"
                                            id = "update_cancel_pro"
                                            //style = {{marginRight:'8px'}}
                                            onClick = {(e) => this.cancelProfileInfo(e)}
                                        >
                                            Cancel
                                        </button> 
						            </div>
					            </div>

                                <div className="loader-page d-none" style={{ marginTop: '50%', marginBottom: '50%', textAlign: 'center' }}>

                                    <img
                                        className="img-fluid lazyload"
                                        data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                        alt="Avatar"
                                    />
                                </div>
                                <form className="profile-form">

                                    <div className="alert" role="alert">
                                    </div>

                                    <div className="row reverse-col">
                                        <div className="col-md-6 mb-5">
                                            <h3 className="title">Personal</h3>
                                            <div className="form-group form-value">
                                                <label>
                                                    First Name
                {/* <i className="edit">
                                                        <img
                                                            className="img-fluid lazyload"
                                                            data-src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"}
                                                            alt="icon"
                                                        />
                                                    </i>
                                                    <span className="action">
                                                        <i className="save editout">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/save-tick.svg"}
                                                                alt="icon"
                                                            />
                                                        </i>
                                                        <i className="cancel editout">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/save-cancel.svg"}
                                                                alt="icon"
                                                            />
                                                        </i>
                                                    </span> */}
                                                </label>
                                                <input
                                                    className="form-control"
                                                    pattern="[a-zA-Z]*"
                                                    id = "first_name"
                                                    title="Please enter on alphabets only."
                                                    value={(this.props.userProfile.first_name === 'undefined') ? '' : this.props.userProfile.first_name}
                                                    type="text"
                                                    name
                                                    onChange={(e) => {
                                                        if (e.target.value.match("^[a-zA-Z ]*$") != null) {
                                                            this.props.changeProfileInfo('first_name', e.target.value)
                                                        }

                                                    }}
                                                />
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Last Name
                                            {/* <i className="edit">
                                                        <img
                                                            className="img-fluid lazyload"
                                                            data-src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"}
                                                            alt="icon"
                                                        />
                                                    </i>
                                                    <span className="action">
                                                        <i className="save editout">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/save-tick.svg"}
                                                                alt="icon"
                                                            />
                                                        </i>
                                                        <i className="cancel editout">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/save-cancel.svg"}
                                                                alt="icon"
                                                            />
                                                        </i>
                                                    </span> */}
                                                </label>
                                                <input
                                                    className="form-control"
                                                    value={(this.props.userProfile.last_name === 'undefined') ? '' : this.props.userProfile.last_name}
                                                    onChange={(e) => {
                                                        if (e.target.value.match("^[a-zA-Z ]*$") != null) {
                                                            this.props.changeProfileInfo('last_name', e.target.value)
                                                        }

                                                    }}
                                                    type="text"
                                                    name
                                                />
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Username
                {/* <i className="edit">
                                                        <img
                                                            className="img-fluid"
                                                            src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"}
                                                            alt="icon"
                                                        />
                                                    </i>
                                                    <span className="action">
                                                        <i className="save editout">
                                                            <img
                                                                className="img-fluid"
                                                                src={process.env.PUBLIC_URL + "/assets/images/save-tick.svg"}
                                                                alt="icon"
                                                            />
                                                        </i>
                                                        <i className="cancel editout">
                                                            <img
                                                                className="img-fluid"
                                                                src={process.env.PUBLIC_URL + "/assets/images/save-cancel.svg"}
                                                                alt="icon"
                                                            />
                                                        </i>
                                                    </span> */}
                                                </label>
                                                <input
                                                    className="form-control"
                                                    value={(this.props.userProfile.user_login === 'undefined') ? '' : this.props.userProfile.user_login}
                                                    onChange={e => this.props.changeProfileInfo('user_login', e.target.value)}
                                                    type="text"
                                                    name
                                                />
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Short Bio
                            </label>
                                                <textarea
                                                    className="form-control"
                                                    value={(this.props.userProfile.description === 'undefined') ? '' : this.props.userProfile.description}
                                                    onChange={e => this.props.changeProfileInfo('description', e.target.value)}
                                                />
                                            </div>
                                        </div>
                                        <div className="col-md-6 mb-5 prof-img-sec">
                                            <div className="prof-img art-background" style={{ backgroundImage: `url(${(this.props.userProfile.user_avatar) ? this.props.userProfile.user_avatar : process.env.PUBLIC_URL + "/assets/images/avatar.png"})` }}>

                                                {/* <img
                                                    className="img-fluid"
                                                    src={(this.props.userProfile.user_avatar) ? this.props.userProfile.user_avatar : process.env.PUBLIC_URL + "/assets/images/avatar.png"}
                                                    alt="Avatar"
                                                /> */}
                                            </div>

                                            <div className="loader-pro d-none">

                                                <img
                                                    className="img-fluid lazyload"
                                                    data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                                    alt="Avatar"
                                                />
                                            </div>

                                            <div className="mt-4">
                                                <input id="file" type="file" style={{ display: "none" }} accept="image/*" onChange={(e) => {
                                                    if (e.target.files[0]) {
                                                        var fileName = e.target.files[0].name;
                                                        console.log('file', e.target.files[0])
                                                        jQuery('.loader-pro').removeClass('d-none')
                                                        jQuery('.loader-pro').addClass('d-block')
                                                        jQuery('.prof-img').addClass('d-none')
                                                        jQuery('.prof-img').removeClass('d-block')
                                                        // this.props.changeProfileInfo('user_avatar', URL.createObjectURL(e.target.files[0]))
                                                        this.props.createProfilePicture({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, upload_file: e.target.files[0], image_id: this.props.userProfile.ID })
                                                        // jQuery('.prof-img img').attr('src', URL.createObjectURL(e.target.files[0]));
                                                    }

                                                }} />
                                                <button className="btn btn-outline" type="button" onClick={() => jQuery('#file').click()}>Change Picture</button>
                                                <button className="btn btn-red" type="button" onClick={(e) => this.removeProfile(e)}>Remove</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6 mb-5">
                                            <h3 className="title">Private Info</h3>
                                            <div className="form-group">
                                                <label>
                                                    Email
                            </label>
                                                <input
                                                    className="form-control"
                                                    value={(this.props.userProfile.user_email === 'undefined') ? '' : this.props.userProfile.user_email}
                                                    onChange={e => this.props.changeProfileInfo('user_email', e.target.value)}
                                                    type="text"
                                                    name
                                                />
                                                {(this.props.errors.email && this.props.errors.email.length > 0) ?
                                                    < span className='text-danger'>{this.props.errors.email}</span> : ''}
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Mobile No#
                
                                                </label>
                                                <div className="input-group">
                                                    <ReactPhoneInput
                                                        inputProps={{
                                                            name: 'phone'
                                                        }}
                                                        placeholder="Enter Phone Number"
                                                        country={"sg"}
                                                        value={(this.props.userProfile.mobile_no === 'undefined') ? '' : this.props.userProfile.mobile_no}
                                                        onChange={phone => this.props.changeProfileInfo('mobile_no', phone)}
                                                    />
                                                    {/* <span className="flag">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/flag-sg.png"} alt="icon" />
                  +65
                </span>
                                                    <input
                                                        className="form-control"
                                                        maxlength="10"
                                                        pattern="\d{10}"
                                                        title="Please enter exactly 10 digits"
                                                        value={(this.props.userProfile.mobile_no === 'undefined') ? '' : this.props.userProfile.mobile_no}
                                                        onChange={e => this.props.changeProfileInfo('mobile_no', e.target.value)}
                                                        type="text"
                                                        name
                                                    /> */}
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Gender
                
                                                </label>
                                                <select className="form-control" value={(this.props.userProfile.gender_id === 'undefined') ? '' : this.props.userProfile.gender_id}
                                                    onChange={e => this.props.changeProfileInfo('gender_id', e.target.value)}>
                                                    <option value=''>Choose Gender</option>
                                                    <option value='6'>Male</option>
                                                    <option value='7'>Female</option>
                                                </select>
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Date of Birth
               
                                                </label>
                                                <div
                                                    className="input-group date mar-t-no"
                                                    data-date-format="dd/mm/yyyy"
                                                    data-date-endDate="0d"

                                                >
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={(this.props.userProfile.date_of_birth === 'undefined') ? '' : this.props.userProfile.date_of_birth}

                                                    />
                                                    <div className="input-group-addon">
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-icon.svg"} alt="icon" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-6 mb-5">
                                        <h3 className="title">Newsletter</h3>
                                        {
                                            this.props.userProfile.subscribed && this.props.userProfile.subscribed === 1
                                            ? (
                                            <>
                                            
                                            <div className="form-group">
                                                <label>
                                                    Frequency
                
                                                </label>
                                                <select className="form-control" value={(this.props.userProfile.frequency_id === 'undefined') ? '' : this.props.userProfile.frequency_id}
                                                    onChange={e => this.props.changeProfileInfo('frequency_id', e.target.value)}>
                                                    {
                                                        this.props.frequencyList.map((o, k) => (

                                                            <option key={k}
                                                                value={o.value_id}>{o.value_name}</option>
                                                        ))
                                                    }
                                                </select>
                                            </div>
                                            <div className="form-group">
                                                <label>
                                                    Notify about these topics

                                                </label>
                                                <select className="form-control select2 "   multiple value={this.props.userProfile.interested_in}>
                                                    {
                                                        this.props.categoryList.length > 0 &&
                                                        this.props.categoryList.map((c, d) => (
                                                            // <optgroup value={c.term_id} label={c.name}>
                                                                <option 
                                                                value={c.term_id} className="optionGroup ">{c.name
                                                                }
                                                                </option>
                                                                // {
                                                                //     c.sub_categories.length > 0 &&
                                                                //     c.sub_categories.map((m, n) => (
                                                                //     <option key={n}
                                                                //         value={m.term_id}>{m.name}</option>
                                                                //     ))
                                                                // }
                                                            // </optgroup>

                                                        ))
                                                    }
                                                   
                                                </select>
                                            </div>
                                            </>
                                            ) : (
                                                <>
                                                <div className="form-group">
                                                    
                                                    <Link to='/subscribe'>
                                                    <label>
                                                        Subscribe here
                                                    </label>
                                                    </Link>
                                                    
                                                </div>
                                                </>
                                            )
                                        }
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6 mb-5">
                                            <h3 className="title">Password</h3>
                                            <div className="form-group mb-0 active password-div">
                                                <label>Current Password</label>
                                                <input
                                                    className="form-control"
                                                    value={this.props.userProfile.password}
                                                    onChange={e => this.props.changeProfileInfo('password', e.target.value)}
                                                    type="password"
                                                    id="currentPassword"
                                                />
                                                <i className="pass-visible show-pass">
                                                    <img className="visible-icon lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/invisible.svg"} alt="icon" />
                                                    <img className="invisible-icon lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/visible.svg"}
                                                        alt="icon"
                                                    />
                                                </i>
                                            </div>
                                            {(this.props.passwordErrors.password && this.props.passwordErrors.password.length > 0) ?
                                                < span className='text-danger'>{this.props.passwordErrors.password}</span> : ''}
                                            <a href="javascript:;" className="text-link change-pass">
                                                Change Password
            </a>
                                            <div className="change-pass-encl mt-4 mb-0">
                                                <div className="form-group active password-div mb-0">
                                                    <label>New Password</label>
                                                    <input
                                                        className="form-control"
                                                        value={this.props.userProfile.new_password}
                                                        onChange={e => this.props.changeProfileInfo('new_password', e.target.value)}
                                                        type="password"
                                                        id="newPassword"
                                                    />
                                                    {/* <span className="pass-strength">
                                                        Strength:<span className="high">Strong</span>
                                                    </span> */}
                                                    <i className="pass-visible show-pass">
                                                        <img className="visible-icon lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/invisible.svg"} alt="icon" />
                                                        <img className="invisible-icon lazyload"
                                                            data-src={process.env.PUBLIC_URL + "/assets/images/visible.svg"}
                                                            alt="icon"
                                                        />
                                                    </i>
                                                </div>
                                                {(this.props.passwordErrors.newPassword && this.props.passwordErrors.newPassword.length > 0) ?
                                                    < span className='text-danger'>{this.props.passwordErrors.newPassword}</span> : ''}
                                                <div className="form-group active password-div mb-0 mt-4">
                                                    <label>Confirm New Password</label>
                                                    <input
                                                        className="form-control"
                                                        value={this.props.userProfile.confirm_password}
                                                        onChange={e => this.props.changeProfileInfo('confirm_password', e.target.value)}
                                                        type="password"
                                                        id="confirmNewPassword"
                                                    />
                                                    <i className="pass-visible show-pass">
                                                        <img className="visible-icon lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/invisible.svg"} alt="icon" />
                                                        <img className="invisible-icon lazyload"
                                                            data-src={process.env.PUBLIC_URL + "/assets/images/visible.svg"}
                                                            alt="icon"
                                                        />
                                                    </i>
                                                </div>
                                                {(this.props.passwordErrors.confirmPassword && this.props.passwordErrors.confirmPassword.length > 0) ?
                                                    < span className='text-danger'>{this.props.passwordErrors.confirmPassword}</span> : ''}
                                                <div className="form-group text-right mt-4">
                                                    <button className="btn btn-trans cancel-pass" type="button">Cancel</button>
                                                    <button className="btn btn-green-flat" type="button" onClick={(e) => this.changePassword(e)}>Update Password</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                    {
                        /* My Account Ends here */
                    }


                    <Footer />
                </div>
            </div >


        )
    }
}



import React, { Component, Fragment } from 'react'
import { Link } from 'react-router-dom';
import jQuery from 'jquery'
import Moment from 'react-moment';

import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'

import MenuBar from './MenuBar'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class BucketListArticle extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getArticleListByBucket({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, bucket_id: (localStorage.bucket_id) ? localStorage.getItem('bucket_id') : 0 })
        this.props.updateArticleListPageNo({ flag: 1 })
    }

    componentDidMount() {
        var THIS = this;
        console.log(THIS.props.editBucketStatus, 'THIS.props.editBucketStatus')
        jQuery(document).ready(function () {
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide();
                jQuery(this).siblings('.actionoio').css('display', 'block')
                jQuery('.bucket-title .actionoio').css('left', '100px')
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });

            // jQuery(".bucket-title .action a").click(function () {
            //     jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
            //     jQuery(this).parent(".action").siblings(".edit").show();
            // });
        })
    }

    componentDidUpdate() {

        var THIS = this;
        console.log(THIS.props.editBucketStatus, 'THIS.props.editBucketStatus')
        jQuery(document).ready(function () {
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide();
                jQuery(this).siblings('.actionoio').css('display', 'block')
                jQuery('.bucket-title .actionoio').css('left', '100px')
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });

            if  (THIS.props.editBucketStatus === 3) {
                jQuery(".bucket_mark .alert").html(
                  "<strong>Error!</strong> Bookmark list already exist."
                );
                jQuery(".bucket_mark .alert")
                  .removeClass("alert-success")
                  .addClass("alert-danger");
                THIS.props.changeBucketStatus(0);
                setTimeout(function () {
                  jQuery(".bucket_mark .alert").removeClass("alert-danger");
                }, 2000);
              }
            // jQuery(".bucket-title .action a").click(function () {
            //     jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
            //     jQuery(this).parent(".action").siblings(".edit").show();
            // });
           
            if (THIS.props.editBucketStatus === 1) {
                console.log('buc', THIS.props.editBucketStatus)
                var editBucketId = localStorage.getItem('edit_bucket_id')
                jQuery('.bucket_mark .alert').html('<strong>Success!</strong> Bucket Edited Successfully.');
                jQuery('.bucket_mark .alert').removeClass('alert-danger').addClass('alert-success')
                jQuery('.actionoio').hide();
                jQuery('.btn-editing').show();
                jQuery('.title').attr("contenteditable", "false")
                THIS.props.changeBucketStatus(0);
                setTimeout(function () {
                    jQuery('.bucket_mark .alert').removeClass('alert-success');
                }, 2000);
    
            }
            if (THIS.props.articleMoreStatus === 1) {
                jQuery('.article-list .alert').html('<strong>No More Articles</strong>');
                jQuery('.article-list .alert').removeClass('alert-success').addClass('alert-danger')
                THIS.props.changeArticleMoreStatus(0);
                setTimeout(function () {
                    jQuery(".article-list .alert").removeClass('alert-danger');
                }, 2000);
            }


        })


    }

    showMore(e) {
        e.preventDefault();
        this.props.updateArticleListPageNo({ flag: 0 });
        this.props.getMoreArticleListByBucket({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.articleListPageno + 1, limit: 12, bucket_id: (localStorage.bucket_id) ? localStorage.getItem('bucket_id') : 0 })
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        // var url = jQuery(e.target).closest(".article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        var url = jQuery(e.target).closest(".article-item").find('.art-background img').attr('src')
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
    }

    cancelHanle = (e) => {
        console.log(jQuery(e.target).closest('.actionoio').siblings('.edit'), 'CONCENTRATES')
        jQuery(e.target).closest('.actionoio').siblings('.edit').show()
        jQuery(e.target).closest('.actionoio').siblings(".title").attr("contenteditable", "false");
        jQuery(e.target).closest('.actionoio').css('display', 'none')
    }
    render() {

        return (
            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    {/* My Account Starts here */}
                    <section className="container my-account">
                        <MenuBar />
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <h3>
                                    <Link to={`/bookmarklist/${localStorage.getItem('user_login')}`} className="back">
                                       <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                    </Link>
                                    BookMark List
                                </h3>
                                <div className="row mb-5 bucket_mark">
                                    <div className="alert" role="alert">
                                    </div>
                                    <div className="col-md-12 mb-3">
                                        <span className="bucket-title" data-bucket-id={localStorage.getItem('bucket_id')} data-bucket-name={localStorage.getItem('bucket_name')} data-bucket=''>
                                            <span contentEditable="false" className="title" onKeyUp={(e) => {
                                                jQuery(e.target).closest('.bucket-title').data('bucket', jQuery(e.target).text())

                                            }}>
                                                {localStorage.getItem('bucket_name')}
                                            </span>
                                            <button className="btn btn-editing edit"
                                                    data-id = {localStorage.getItem('bucket_id')}
                                                    type = 'button'
                                                    //style = {{marginRight: '19rem'}}
                                                //     onClick = {(e) => {
                                                //         this.props.showHide({
                                                //         showHideBtn: false,
                                                //         id: o.id
                                                //     });
                                                //     //this.changeButton(e);
                                                // }}
                                                    >
                                                    Edit
                                                    </button>
                                                    <div className="actionoio">

                                                    <button 
                                                    className="btn-updating save"
                                                    type ='button'
                                                    id= "save_edit"
                                                    // style = {{display:"none"}}
                                                    onClick={(e) => {
                                                        // console.log(jQuery(e.target).closest('.bucket-title').data('bucket-id'), 'this is fine')
                                                        if (jQuery(e.target).closest('.bucket-title').data('bucket') !== '') {
                                                            localStorage.setItem('edit_bucket_id', jQuery(e.target).closest('.bucket-title').data('bucket-id'))
                                                            this.props.editBucket({ bucket_id: jQuery(e.target).closest('.bucket-title').data('bucket-id'), bucket_name: jQuery(e.target).closest('.bucket-title').data('bucket') })
                                                        } else {
                                                            jQuery('.actionoio').hide();
                                                            jQuery('.btn-editing').show();
                                                            jQuery('.title').attr("contenteditable", "false")
                                                        }
                                                       
                                                    }
                                                            
                                                    }
                                                    >
                                                    Update
                                                    </button>
                                                    <button 
                                                        className="btn-canceling save"
                                                        type ='button'
                                                        id= "save_edit"
                                                        // style = {{display:"none"}}
                                                        onClick={(e) => {{
                                                            this.cancelHanle(e)
                                                        }}
                                                        
                                                        }
                                                    >
                                                    Cancel
                                                    </button>
                                                </div>
                                            {/* <div className="action">
                                                <a href="javascript:;" className="save" onClick={(e) => {
                                                    console.log(jQuery(e.target).closest('.bucket-title').data('bucket'), 'BUCKET')
                                                    if (jQuery(e.target).closest('.bucket-title').data('bucket') !== '') {
                                                        this.props.editBucket({ bucket_id: jQuery(e.target).closest('.bucket-title').data('bucket-id'), bucket_name: jQuery(e.target).closest('.bucket-title').data('bucket') })
                                                    }


                                                }}>
                                                    <img
                                                        className="img-fluid lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/save-tick.svg"}
                                                        alt="icon"
                                                    />
                                                </a>
                                                <a href="javascript:;" className="cancel">
                                                    <img
                                                        className="img-fluid lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/save-cancel.svg"}
                                                        alt="icon"
                                                    />
                                                </a>
                                            </div> */}
                                            {/* <a href="javascript:;" className="edit">
                                                <img
                                                    className="img-fluid lazyload"
                                                    data-src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"}
                                                    alt="icon"
                                                />
                                            </a> */}
                                        </span>
                                    </div>
                                    {/* <div className="col-md-12 sorting mt-3">
                                        <ul className="list-inline">
                                            <li className="list-inline-item">
                                                <a className="active" href="javascript:;">
                                                    All
                  </a>
                                            </li>
                                            <li className="list-inline-item">
                                                <a href="javascript:;">Football</a>
                                            </li>
                                            <li className="list-inline-item">
                                                <a href="javascript:;">Review</a>
                                            </li>
                                            <li className="list-inline-item">
                                                <a href="javascript:;">Sports Wear</a>
                                            </li>
                                        </ul>
                                    </div> */}
                                    {
                                        this.props.articleLists.length > 0 &&
                                        this.props.articleLists.map((o, k) => {
                                            if (o.cat_name) {
                                                var cat_name = (o.cat_name).split(',');
                                            cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                            } else {
                                                cat_name = ''
                                            }
                                            
                                            return <div className="col-md-4 mb-4" key={o.ID}>
                                                <div className="article-item">
                                                    <Link to={`/${o.post_name}`} className="art-img art-background"
                                                        style={{ backgroundImage: `url(${(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url})` }}>
                                                        {/* <img src={o.image_url} alt="img" /> */}
                                                        {/* <span className="video-label">
                    <img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />
                                        12:32
                                    </span> */}
                                                        {(o.video_file === null || o.video_file === undefined) ? '' : <span className="video-label"><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span>}
                                                    </Link>
                                                    <div className="art-cont">
                                                        <span className="tag">{cat_name}</span>
                                                        <a href="javascript:;" className="favorite" data-id={o.ID} data-bucket-id={localStorage.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? "#remove-article" : "#signup-modal"}
                                                            onClick={(e) => {
                                                                this.bucketList(e)
                                                            }}>

                                                            <img className="outline lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"} alt="icon" data-article-id={o.ID} />
                                                            <img
                                                                className="filled lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                alt="icon"
                                                            />
                                                        </a>
                                                        <Link to={`/${o.post_name}`} className="art-title">
                                                            {o.post_title}
                                                        </Link>
                                                        <span className="date-time">
                                                            <Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        })
                                    }
                                    <div className="col-md-12 text-center article-list mt-4">
                                        <div className="alert" role="alert">
                                        </div>
                                        <button className="btn btn-orange" type="button" onClick={(e) => { this.showMore(e) }}>Show More</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    {/* My Account Ends here */}
                    <Footer />
                </div>
            </div >


        )
    }
}



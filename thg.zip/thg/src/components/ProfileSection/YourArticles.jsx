import React, { Component, Fragment } from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import jQuery from 'jquery'
import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'

import MenuBar from './MenuBar'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class YourArticles extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        
        THIS.props.updateDraftPageNo({ draftFlag: 1 });
        THIS.props.updatePublishPageNo({ publishFlag: 1 });
        THIS.props.updatePendingPageNo({ pendingFlag: 1 });
        THIS.props.getDraftArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 4, post_status: 'draft' })
        THIS.props.getPendingArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 4, post_status: 'pending' })
        THIS.props.getPublishArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 4, post_status: 'publish' })
        jQuery(document).ready(function () {
            jQuery('.art-cont p').addClass('text-truncate')
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide();
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });

            jQuery(".bucket-title .action a").click(function () {
                jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
                jQuery(this).parent(".action").siblings(".edit").show();
            });
        })
    }
    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery('.art-cont p').addClass('text-truncate')
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide();
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });

            jQuery(".bucket-title .action a").click(function () {
                jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
                jQuery(this).parent(".action").siblings(".edit").show();
            });

            if (THIS.props.deleteStatus === 1) {
               // jQuery("#delete-article").modal("hide");
               console.log(jQuery('.alert1'), 'DEEALERT')
                jQuery('.alert1').html('<strong>Success!</strong> Article Deleted Successfully.');
                jQuery('.alert1').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".alert1").removeClass('alert-success');
                }, 2000);
                THIS.props.updateDeleteStatus(0);
            } else if (THIS.props.deleteStatus === 2) {
                jQuery('.alert1').html('<strong>Error!</strong> Failed To Delete.');
                jQuery('.alert1').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".alert1").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateDeleteStatus(0);
            }

            if (THIS.props.pendingStatus === 1) {
                
                jQuery('.my-acc-right .alert1').html('<strong>Success!</strong> Article Move to Pending Successfully.');
                jQuery('.my-acc-right .alert1').removeClass('alert-danger').addClass('alert-success')
                
                setTimeout(function () {
                    jQuery(".my-acc-right .alert1").removeClass('alert-success');
                }, 2000);
                THIS.props.updatePendingStatus(0);
            } else if (THIS.props.pendingStatus === 2) {
                jQuery('.my-acc-right .alert1').html('<strong>Error!</strong> Failed To Update.');
                jQuery('.my-acc-right .alert1').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".my-acc-right .alert1").removeClass('alert-danger');
                }, 2000);
                THIS.props.updatePendingStatus(0);
            }

            if (THIS.props.articleMoreStatus === 1) {
                jQuery('.article-list .alert').html('<strong>No More Articles</strong>');
                jQuery('.article-list .alert').removeClass('alert-success').addClass('alert-danger')
                THIS.props.changeArticleMoreStatus(0);
                setTimeout(function () {
                    jQuery(".article-list .alert").removeClass('alert-danger');
                }, 2000);
            }

        })


    }

    showMoreDraftArticle(e) {
        e.preventDefault();
        this.props.updateDraftPageNo({ draftFlag: 0 });
        this.props.moreDraftArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.draftArticlePageNo + 1, limit: 4, post_status: 'draft' })
    }

    showMorePublishArticle(e) {
        e.preventDefault();
        this.props.updatePublishPageNo({ publishFlag: 0 });
        this.props.morePublishArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.publishArticlePageNo + 1, limit: 4, post_status: 'publish' })
    }

    showMorePendingArticle(e) {
        e.preventDefault();
        this.props.updatePendingPageNo({ pendingFlag: 0 });
        this.props.morePendingArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.pendingArticlePageNo + 1, limit: 4, post_status: 'pending' })
    }

    render() {

        return (
            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    {
                        /* My Account Starts here */
                    }
                    <section className="container my-account">
                        <MenuBar />
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <div className="alert alert1" role="alert">
                                </div>
                                <h3>Your Articles</h3>
                                <div className="row mb-5">
                                    <div className="col-12 mb-4">
                                        <ul className="nav nav-pills float-left">
                                            <li className="mr-2">
                                                <a data-toggle="tab" href="#drafts" className="active">
                                                    Drafts ({this.props.draftArticlesList.length})
              </a>
                                            </li>
                                            <li className="mr-2">
                                                <a data-toggle="tab" href="#pending">
                                                    Pending ({this.props.pendingArticlesList.length})
              </a>
                                            </li>
                                            <li>
                                                <a data-toggle="tab" href="#published">
                                                    Published ({this.props.publishArticlesList.length})
              </a>
                                            </li>
                                        </ul>
                                        <Link to={`/createarticle/${localStorage.getItem('user_login')}`}
                                            className="btn btn-green-flat float-right d-none d-md-block"
                                        >
                                            Create Article
          </Link>
                                    </div>
                                    <div className="tab-content col-12">
                                        <div id="drafts" className="tab-pane fade in show active">
                                            {this.props.draftArticlesList.length > 0
                                                && this.props.draftArticlesList.map((o, k) => {
                                                    return <div className="article-item your-article mb-3" data-post={o.post_name} data-id={o.ID} key={o.ID}>
                                                        <div className="art-img d-none d-md-block">
                                                            <img className="lazyload" data-src={(o.thumbnail_image === "" || o.thumbnail_image === null || o.thumbnail_image === undefined) ? o.custom_feature_image_url : o.thumbnail_image} alt="icon" />
                                                        </div>
                                                        <div className="art-cont">
                                                            {/* <Link to={`/${o.post_name}`} className="art-title text-truncate"
                                                                onClick={(e) => {
                                                                    localStorage.setItem('draft_status', 1)
                                                                }}>
                                                                
                                                            </Link> */}
                                                            <a
                                                            className="art-title text-truncate" 
                                                            style= {{textDecoration:'none'}} 
                                                            href= "javascript:;">{o.post_title}</a>
                                                            {/* <p className="text-truncate"> */}
                                                                {ReactHtmlParser(o.post_content)}
                                                            {/* </p> */}
                                                        </div>
                                                        <div className="btn-wrap">
                                                            <button className="btn btn-orange mr-2" type="button"
                                                                onClick={(e) => {
                                                                    e.preventDefault();
                                                                    this.props.updateArticle({ article_id: jQuery(e.target).closest('.article-item').data('id') })
                                                                }}>Move To Pending</button>
                                                            <Link to={`/editarticle/${localStorage.getItem('user_login')}`} className="btn btn-outline mr-2" type="button"
                                                                onClick={(e) => {
                                                                   
                                                                    localStorage.setItem('edit_article_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                    localStorage.setItem('edit_post', jQuery(e.target).closest('.article-item').data('post'))
                                                                }}>Edit</Link>
                                                            <button className="btn btn-red" type="button" data-toggle="modal" //data-target="#delete-article"
                                                                onClick={(e) => {
                                                                    // e.preventDefault();
                                                                    // localStorage.setItem('delete_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                    e.preventDefault();
                                                                    this.props.deleteArticleFromList({ article_id: jQuery(e.target).closest('.article-item').data('id') })
                                                                }}>Delete</button>
                                                        </div>
                                                    </div>
                                                })}

                                            {this.props.draftArticlesList.length > 0 ?
                                                <div className="col-md-12 text-center article-list mt-5">
                                                    <div className="alert more" role="alert">
                                                    </div>
                                                    <button className="btn btn-orange" type="button" onClick={(e) => this.showMoreDraftArticle(e)}>Show More</button>
                                                </div> : <div className="no-data">
                                                    <img className="mb-3 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/no-data-icon.svg"} alt="icon" />
                                                    <p>You have no items in draft</p>
                                                </div>}
                                        </div>
                                        <div id="pending" className="tab-pane fade in">
                                            {this.props.pendingArticlesList.length > 0
                                                && this.props.pendingArticlesList.map((p, q) => {
                                                    return <div className="article-item your-article mb-3" data-post={p.post_name} data-id={p.ID} key={p.ID}>
                                                        <div className="art-img d-none d-md-block">
                                                            <img className="lazyload" data-src={(p.custom_feature_image_url === "" || p.custom_feature_image_url === null || p.custom_feature_image_url === undefined) ? p.image_url : p.custom_feature_image_url} alt="icon" />
                                                        </div>
                                                        <div className="art-cont">
                                                            {/* <Link to={`/${p.post_name}`} className="art-title text-truncate"
                                                                onClick={(e) => {
                                                                    localStorage.setItem('draft_status', 1)
                                                                }}>
                                                                {p.post_title}
                                                            </Link> */}
                                                            <a
                                                            style= {{textDecoration:'none'}} 
                                                            className="art-title text-truncate"
                                                            href= "javascript:;"
                                                                // onClick={(e) => {
                                                                //     localStorage.setItem('draft_status', 1)
                                                                // }}
                                                                >
                                                                {p.post_title}
                                                            </a>
                                                            <p className="text-truncate">
                                                                {ReactHtmlParser(p.post_content)}
                                                            </p>
                                                        </div>
                                                        <div className="btn-wrap">
                                                            <Link to={`/editarticle/${localStorage.getItem('user_login')}`} className="btn btn-outline" type="button"
                                                                onClick={(e) => {
                                                                    localStorage.setItem('edit_article_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                    localStorage.setItem('edit_post', jQuery(e.target).closest('.article-item').data('post'))
                                                                }}>Edit</Link>
                                                            <button className="btn btn-red" type="button"
                                                                onClick={(e) => {
                                                                    e.preventDefault();
                                                                    this.props.deleteArticleFromList({ article_id: jQuery(e.target).closest('.article-item').data('id') })
                                                                }}>Delete</button>
                                                        </div>
                                                    </div>
                                                })}
                                            {this.props.pendingArticlesList.length > 0 ?
                                                <div className="col-md-12 text-center article-list mt-5">
                                                    <div className="alert" role="alert">
                                                    </div>
                                                    <button className="btn btn-orange" type="button" onClick={(e) => this.showMorePendingArticle(e)}>Show More</button>
                                                </div> :
                                                <div className="no-data">
                                                    <img className="mb-3 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/no-data-icon.svg"} alt="icon" />
                                                    <p>You have no pending items</p>
                                                </div>}
                                        </div>
                                        <div id="published" className="tab-pane fade in">
                                            {this.props.publishArticlesList.length > 0
                                                && this.props.publishArticlesList.map((m, n) => {
                                                    return <Link to={`/${m.post_name}`}>
                                                        <div className="article-item your-article mb-3" data-post={m.post_name} data-id={m.ID} key={m.ID}>
                                                            <div className="art-img d-none d-md-block">
                                                                <img className="lazyload" data-src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="icon" />
                                                            </div>
                                                            <div className="art-cont">
                                                                <Link to={`/${m.post_name}`} className="art-title text-truncate">
                                                                    {m.post_title}
                                                                </Link>
                                                                <p className="text-truncate">
                                                                    {ReactHtmlParser(m.post_content)}
                                                                </p>
                                                            </div>
                                                            <div className="btn-wrap">
                                                                {/* <Link to={`/editarticle/${localStorage.getItem('user_login')}`} className="btn btn-outline" type="button"
                                                                    onClick={(e) => {
                                                                        localStorage.setItem('edit_article_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                        localStorage.setItem('edit_post', jQuery(e.target).closest('.article-item').data('post'))
                                                                    }}>Edit</Link>
                                                                <button className="btn btn-red" type="button" data-toggle="modal" data-target="#delete-article"
                                                                    onClick={(e) => {
                                                                        e.preventDefault();
                                                                        localStorage.setItem('delete_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                    }}>Delete</button> */}
                                                            </div>
                                                        </div>
                                                    </Link>
                                                })}
                                            {this.props.publishArticlesList.length > 0 ?
                                                <div className="col-md-12 text-center article-list mt-5">
                                                    <div className="alert" role="alert">
                                                    </div>
                                                    <button className="btn btn-orange" type="button" onClick={(e) => this.showMorePublishArticle(e)}>Show More</button>
                                                </div> :
                                                <div className="no-data">
                                                    <img className="mb-3 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/no-data-icon.svg"} alt="icon" />
                                                    <p>You have no published items</p>
                                                </div>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    {
                        /* My Account Ends here */
                    }
                    {/* Remove Popup Starts here */}
                    <div
                        className="modal fade"
                        id="delete-article"
                        tabIndex={-1}
                        role="dialog"
                        aria-hidden="true"
                    >
                        <div className="modal-dialog modal-dialog-centered" role="document">
                            <div className="modal-content">
                                <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                                </button>
                                <div className="modal-body text-center p-5">
                                    <img
                                        className="img-fluid mb-4 lazyload"
                                        data-src={process.env.PUBLIC_URL + "/assets/images/doc-remove-icon.svg"}
                                        alt="icon"
                                    />
                                    <h3>Are you sure want to delete?</h3>
                                    <p className="sub-title">
                                        Your article will be erased.
          </p>
                                    <div className="alert"></div>
                                    <div className="col-12 mt-4 btn-wrap">
                                        <button className="btn btn-gray" type="button" data-dismiss="modal">Cancel</button>
                                        <button className="btn btn-red" type="button" onClick={(e) => {
                                            e.preventDefault()
                                            this.props.deleteArticleFromList({ article_id: localStorage.getItem('delete_id') })
                                        }}>Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Remove Popup Ends here */}


                    <Footer />
                </div>
            </div >


        )
    }
}



import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Home';
import * as headerActions from '../../actions/common/Header';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';

import jQuery from 'jquery'

import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'

import MenuBar from './MenuBar'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { event } from 'react-ga';


export default class BucketList extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.get3BucketList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0 })
    }

    componentDidMount() {
        var THIS = this;
       // console.log(this.props.showHideBtn, 'showhide')
        jQuery(document).ready(function () {
           
            // jQuery(".bucket-title .edit").click(function () {
            //     jQuery(this).hide()
            //    // jQuery(this).find(".save").css('display', 'block')
            //     jQuery(this).siblings(".title").attr("contenteditable", "true");
            // });

            // jQuery(".bucket-title .action a").click(function () {
            //     jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
            //     jQuery(this).parent(".action").siblings(".edit").show();
            // });
        })
    }
    componentDidUpdate() {
        var THIS = this;
        
        jQuery(document).ready(function () {
            
            jQuery(".bucket-title .edit").click(function () {
                jQuery(this).hide()
                jQuery(this).siblings('.actionoio').css('display', 'block')
                jQuery('.bucket-title .actionoio').css('left', '100px')
               // jQuery(this).find(".save").css('display', 'block')
                jQuery(this).siblings(".title").attr("contenteditable", "true");
            });
            // if  (THIS.props.articleError === 4) {
            //     jQuery(".bucket-form .alert").html(
            //       "<strong>Error!</strong> Bookmark list already exist."
            //     );
            //     jQuery(".bucket-form .alert")
            //       .removeClass("alert-success")
            //       .addClass("alert-danger");
            //     THIS.props.changeArticleErrorStatus(0);
            //     setTimeout(function () {
            //       jQuery(".bucket-form .alert").removeClass("alert-danger");
            //     }, 2000);
            // }

            // jQuery(".bucket-title .action a").click(function () {
            //     jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
            //     jQuery(this).parent(".action").siblings(".edit").show();
            // });
            // jQuery(".bucket-title .action a").click(function () {
            //     jQuery(this).parent(".action").siblings(".title").attr("contenteditable", "false");
            //     jQuery(this).parent(".action").siblings(".edit").show();
            // });

        })

        if (THIS.props.editBucketStatus === 1) {
            console.log('buc', THIS.props.editBucketStatus)
            var editBucketId = localStorage.getItem('edit_bucket_id')
            jQuery(`#${editBucketId} .alert`).html('<strong>Success!</strong> Bucket Edited Successfully.');
            jQuery(`#${editBucketId} .alert`).removeClass('alert-danger').addClass('alert-success')
            jQuery('.actionoio').hide();
            jQuery('.btn-editing').show();
            jQuery('.title').attr("contenteditable", "false")
            THIS.props.changeBucketStatus(0);
            setTimeout(function () {
                jQuery(`#${editBucketId} .alert`).removeClass('alert-success');
            }, 2000);

        } else if (THIS.props.editBucketStatus === 2) {
            var editBucketId = localStorage.getItem('edit_bucket_id')
            jQuery(`#${editBucketId} .alert`).html('<strong>Error!</strong> Failed to ediit bucket.');
            jQuery(`#${editBucketId} .alert`).removeClass('alert-success').addClass('alert-danger')
            setTimeout(function () {
                jQuery(`#${editBucketId} .alert`).removeClass('alert-danger');
            }, 2000);

            THIS.props.changeBucketStatus(0);
        } else if (THIS.props.editBucketStatus === 3) {
            var editBucketId = localStorage.getItem('edit_bucket_id')
            jQuery(`#${editBucketId} .alert`).html('<strong>Error!</strong> Bookmark list already exist.');
            jQuery(`#${editBucketId} .alert`).css('margin-left', '4px')
            jQuery(`#${editBucketId} .alert`).removeClass('alert-success').addClass('alert-danger')
            setTimeout(function () {
                jQuery(`#${editBucketId} .alert`).removeClass('alert-danger');
            }, 2000);

            THIS.props.changeBucketStatus(0);

        }


    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        // var url = jQuery(e.target).closest(".article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        var url = jQuery(e.target).closest(".article-item").find('.art-background img').attr('src')
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
    }
    cancelHanle = (e) => {
        console.log(jQuery(e.target).closest('.actionoio').siblings('.edit'), 'CONCENTRATES')
        jQuery(e.target).closest('.actionoio').siblings('.edit').show()
        jQuery(e.target).closest('.actionoio').siblings(".title").attr("contenteditable", "false");
        jQuery(e.target).closest('.actionoio').css('display', 'none')
    }
    render() {

        return (
            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    {/* My Account Starts here */}
                    <section className="container my-account">
                        <MenuBar />
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <h3>BookMark List</h3>
                                {
                                    this.props.bucketLists.length > 0 &&
                                    this.props.bucketLists.map((o, k) => {
                                        return <div className="row mb-5 bucket_markList" id={o.id}>
                                            <div className="alert" role="alert">
                                            </div>
                                            <div className="col-md-12 mb-3" key= {o.id}>
                                                <span className="bucket-title" 
                                                data-bucket-id={o.id} data-bucket-name={o.bucket_name} data-bucket=''>
                                                    <span 
                                                    contentEditable= "false"
                                                    className="title" onKeyUp={(e) => {
                                                        jQuery(e.target).closest('.bucket-title').data('bucket', jQuery(e.target).text())

                                                    }}>
                                                        {(o.bucket_name === undefined || o.bucket_name === null || o.bucket_name === 'undefined') ? '' : o.bucket_name}
                                                    </span>
                                                    
                                                        <button className="btn btn-editing edit"
                                                            data-id = {o.id}
                                                            type = 'button'
                                                            //style = {{marginRight: '19rem'}}
                                                        //     onClick = {(e) => {
                                                        //         this.props.showHide({
                                                        //         showHideBtn: false,
                                                        //         id: o.id
                                                        //     });
                                                        //     //this.changeButton(e);
                                                        // }}
                                                            >
                                                            Edit
                                                            </button>
                                                            <div className="actionoio">

                                                            <button 
                                                            className="btn-updating save"
                                                            type ='button'
                                                            id= "save_edit"
                                                            // style = {{display:"none"}}
                                                            onClick={(e) => {
                                                                // console.log(jQuery(e.target).closest('.bucket-title').data('bucket-id'), 'this is fine')
                                                                if (jQuery(e.target).closest('.bucket-title').data('bucket') !== '') {
                                                                    localStorage.setItem('edit_bucket_id', jQuery(e.target).closest('.bucket-title').data('bucket-id'))
                                                                    this.props.editBucket({ bucket_id: jQuery(e.target).closest('.bucket-title').data('bucket-id'), bucket_name: jQuery(e.target).closest('.bucket-title').data('bucket') })
                                                                } else {
                                                                    jQuery('.actionoio').hide();
                                                                    jQuery('.btn-editing').show();
                                                                    jQuery('.title').attr("contenteditable", "false")
                                                                }
                                                                // this.props.showHide({
                                                                //     showHideBtn: true,
                                                                //     id : o.id
                                                                // })
                                                            }
                                                            
                                                        }
                                                    >
                                                    Update
                                                    </button>
                                                    <button 
                                                            className="btn-canceling save"
                                                            type ='button'
                                                            id= "save_edit"
                                                            // style = {{display:"none"}}
                                                            onClick={(e) => {{
                                                                this.cancelHanle(e)
                                                            }}
                                                            
                                                        }
                                                    >
                                                    Cancel
                                                    </button>
                                                    </div>
                                                    
                                                    {/* <div className="action">
                                                        <a href="javascript:;" className="save" onClick={(e) => {
                                                            if (jQuery(e.target).closest('.bucket-title').data('bucket') !== '') {
                                                                localStorage.setItem('edit_bucket_id', jQuery(e.target).closest('.bucket-title').data('bucket-id'))
                                                                this.props.editBucket({ bucket_id: jQuery(e.target).closest('.bucket-title').data('bucket-id'), bucket_name: jQuery(e.target).closest('.bucket-title').data('bucket') })
                                                            }


                                                        }}>
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/save-tick.svg"}
                                                                alt="icon"
                                                            />
                                                        </a>
                                                        <a href="javascript:;" className="cancel">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/save-cancel.svg"}
                                                                alt="icon"
                                                            />
                                                        </a>
                                                    </div> */}
                                                    {/* <a href="javascript:;" className="edit">
                                                        <img
                                                            className="img-fluid lazyload"
                                                            data-src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"}
                                                            alt="icon"
                                                        />
                                                    </a> */}
                                                </span>
                                                <Link to={`/bookmarkarticles/${o.bucket_name}`} className="view-all" onClick={() => {
                                                    localStorage.setItem('bucket_id', o.id)
                                                    localStorage.setItem('bucket_name', (o.bucket_name === undefined || o.bucket_name === null || o.bucket_name === 'undefined') ? '' : o.bucket_name)
                                                }}>
                                                    View all
                                  <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                                </Link>
                                            </div>
                                            {o.articleLists.map((m, n) => {
                                                
                                                if (m.cat_name) {
                                                    var cat_name = (m.cat_name).split(',');
                                                    cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                                } else {
                                                    cat_name = ''
                                                }
                                                
                                               
                                                var image = (m.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                                return <div className="col-md-4 mb-4" key={m.ID}>
                                                    <div className="article-item">
                                                        <Link to={`/${m.post_name}`} className="art-img art-background"
                                                            style={{ backgroundImage: `url(${(m.custom_feature_image_url === undefined || m.custom_feature_image_url === null || m.custom_feature_image_url === '') ? m.image_url : m.custom_feature_image_url})` }}>
                                                            {/* <img src={o.image_url} alt="img" /> */}
                                                            {/* <span className="video-label">
        <img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />
    12:32
</span> */}
                                                            {/* {(m.video_file === null || m.video_file === undefined) ? '' : <span className="video-label"><img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span>} */}
                                                        </Link>
                                                        <div className="art-cont">
                                                            <span className="tag">{cat_name}</span>
                                                            <a href="javascript:;" className="favorite" data-id={m.ID} data-bucket-id={m.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? "#remove-article" : "#signup-modal"}
                                                                onClick={(e) => {
                                                                    this.bucketList(e)
                                                                }}>

                                                                <img className="outline lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"} alt="icon" data-article-id={m.ID} />
                                                                <img
                                                                    className="filled lazyload"
                                                                    data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                    alt="icon"
                                                                />
                                                            </a>
                                                            <Link to={`/${m.post_name}`} className="art-title">
                                                                {m.post_title}
                                                            </Link>
                                                            <span className="date-time">
                                                                <Moment format='DD MMM YYYY'>{m.post_date_gmt}</Moment>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            })}
                                        </div>
                                    })
                                }
                            </div>
                        </div>
                    </section>
                    {/* My Account Ends here */}
                    <Footer />
                </div>
            </div >


        )
    }
}



import React, { Component, Fragment } from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Profile';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class MenuBar extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var search = window.location.pathname.split('/')[1]
        jQuery(document).ready(function () {
            window.$(`.${search}`).addClass("active");
        })
        this.props.getUserProfile({ user_id: localStorage.getItem('user_id') })
    }

    render() {
        return (
            <Fragment>

                <div className="leftbar">
                    <div className="avatar-sec text-center">
                        <div className="prof-img art-background" style={{ backgroundImage: `url(${(this.props.userProfile.user_avatar) ? this.props.userProfile.user_avatar : process.env.PUBLIC_URL + "/assets/images/avatar.png"})` }}>
                            {/* <img className="img-fluid" src={(this.props.userProfile.user_avatar) ? this.props.userProfile.user_avatar : process.env.PUBLIC_URL + "/assets/images/avatar.png"} alt="img" /> */}
                        </div>
                        <span className="name">{(this.props.userProfile) ? (this.props.userProfile.first_name + ' ' + this.props.userProfile.last_name) : ''}</span>
                        <span className="username">{(this.props.userProfile) ? (this.props.userProfile.first_name + '_' + this.props.userProfile.last_name) : ''}</span>
                    </div>
                    <ul className="list-unstyled">
                        <li>
                            <Link to={`/profile/${localStorage.getItem('user_login')}`} className="profile">
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/profile-lf.svg"} alt="icon" />
                            Profile
                            </Link>
                        </li>
                        {/* <li>
                            <Link to={`/settings/${localStorage.getItem('user_login')}`} className="settings">
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gear-lf.svg"} alt="icon/" />
          Settings
        </Link>
                        </li> */}
                        <li>
                        <Link to={`/bookmarklist/${(this.props.userProfile) ? (this.props.userProfile.user_login) : ''}`} className="bookmarklist">
                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/favorite-lf.svg"} alt="icon" />
                        BookMark List
                        </Link>
                        </li>
                        {/* {localStorage.contributor && (localStorage.getItem('contributor') == 'true') ? (
                            <li>
                                <Link to={`/createarticle/${localStorage.getItem('user_login')}`} className="createarticle editarticle">
                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"} alt="icon" />
          Create Article
        </Link>
                            </li>) : ''}
                        {localStorage.contributor && (localStorage.getItem('contributor') == 'true') ? (
                            <li>
                                <Link to={`/yourarticles/${localStorage.getItem('user_login')}`} className="yourarticles">
                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/article-lf.svg"} alt="icon" />
          Your Articles
        </Link>
                            </li>) : ''} */}
                        <li>
                            <Link to={`/createarticle/${localStorage.getItem('user_login')}`} className="createarticle editarticle">
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/pen-lf.svg"} alt="icon" />
                            Create Article
                            </Link>
                        </li> 
                    
                        <li>
                            <Link to={`/yourarticles/${localStorage.getItem('user_login')}`} className="yourarticles">
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/article-lf.svg"} alt="icon" />
                            Your Articles
                            </Link>
                        </li>

                        {/* <li>
                            <Link to={`/event-subscription/${localStorage.getItem('user_login')}`} className="yourarticles">
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/add_shopping_cart.svg"} alt="icon" />
                            Subscribed Event List
                            </Link>
                        </li> */}
        
                        <li>
                            <Link to='/' onClick={() => {
                                localStorage.clear()
                                localStorage.removeItem("user_id");
                                localStorage.removeItem("event_id");
                                localStorage.removeItem("subscription");
                            }}
                            >   
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/power-lf.svg"} alt="icon" />
                            Logout
                            </Link>
                        </li>
                    </ul>
                </div>

            </Fragment >
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        userProfile: state.Profile.userProfile,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getUserProfile: (data) => dispatch(actions.getUserProfile(data)),
    }
};

const menuBar = connect(
    mapStateToProps,
    mapDispatchToProps,
)(MenuBar);

export default menuBar;

import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'

import MenuBar from './MenuBar'

import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


export default class Settings extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery(".de-activate .switch").click(function () {
                jQuery(this).toggleClass("active");
                if (jQuery(this).hasClass("active")) {
                    THIS.props.deactivateAccount({
                        'activate_status': 1,
                        'user_id': localStorage.getItem('user_id')
                    })
                } else {
                    THIS.props.deactivateAccount({
                        'activate_status': 0,
                        'user_id': localStorage.getItem('user_id')
                    })
                }
            });

            if (THIS.props.activeStatus === 0) {
                jQuery(".de-activate .switch").removeClass('active')
            } else {
                jQuery(".de-activate .switch").addClass('active')
            }
        })
    }
    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery(".de-activate .switch").off('click').click(function () {
                jQuery(this).toggleClass("active");
                if (jQuery(this).hasClass("active")) {
                    THIS.props.deactivateAccount({
                        'activate_status': 1,
                        'user_id': localStorage.getItem('user_id')
                    })
                } else {
                    THIS.props.deactivateAccount({
                        'activate_status': 0,
                        'user_id': localStorage.getItem('user_id')
                    })
                }
            });

            if (THIS.props.activeStatus === 0) {
                jQuery(".de-activate .switch").removeClass('active')
            } else {
                jQuery(".de-activate .switch").addClass('active')
            }

            if (THIS.props.activateDeactivateSuccess === 1 && THIS.props.activeStatus === 1) {
                jQuery('.my-acc-cont .alert').html('<strong>Success!</strong> Your Account is Deactivated.');
                jQuery('.my-acc-cont .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".my-acc-cont .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateActivateStatus(0);
            } else if (THIS.props.activateDeactivateSuccess === 1 && THIS.props.activeStatus === 0) {
                jQuery('.my-acc-cont .alert').html('<strong>Success!</strong> Your Account is Activated.');
                jQuery('.my-acc-cont .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".my-acc-cont .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateActivateStatus(0);
            } else if (THIS.props.activateDeactivateSuccess === 2) {
                jQuery('.my-acc-cont .alert').html('<strong>Error!</strong> Failed To Update.');
                jQuery('.my-acc-cont .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".my-acc-cont .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateActivateStatus(0);
            }

            if (THIS.props.removeAccountSuccess === 1) {
                jQuery('')
                jQuery('#remove-account .alert').html('<strong>Success!</strong> Your Account Deleted SuccessFully.');
                jQuery('#remove-account .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery("#remove-account .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateInfo({ 'removeAccountSuccess': 0 });
                setTimeout(function () {
                    window.jQuery("#remove-account").modal('hide');
                }, 2000);
            } else if (THIS.props.removeAccountSuccess === 2) {
                jQuery('#remove-account .alert').html('<strong>Success!</strong> Failed To Delete Your Account.');
                jQuery('#remove-account .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery("# .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateInfo({ 'removeAccountSuccess': 0 });
            }


        })


    }

    render() {

        return (


            <div className="container-fluid" >
                <div className="row">
                    <Header />
                    {
                        /* My Account Starts here */
                    }
                    <section className="container my-account">
                        <MenuBar />
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <h3>Settings</h3>
                                <div className="alert" role="alert">
                                </div>
                                <div className="de-activate clearfix">
                                    <p className="mb-0 float-left">De-activate My Account</p>
                                    <span className="switch">
                                        <span />
                                    </span>
                                </div>
                                <br />
                                <button className="btn btn-red mt-3 del" type="button" data-toggle="modal" data-target="#remove-account"
                                // onClick={e => {
                                //     e.preventDefault();
                                //     this.props.deleteAccount({ user_id: localStorage.getItem('user_id') })
                                // }}
                                >
                                    <img className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/trash-icon.svg"} alt="icon" />
        Delete My Account
      </button>
                            </div>
                        </div>
                    </section>;
                    {
                        /* My Account Ends here */
                    }

                    {/* Remove Popup Starts here */}
                    <div
                        className="modal fade"
                        id="remove-account"
                        tabIndex={-1}
                        role="dialog"
                        aria-hidden="true"
                    >
                        <div className="modal-dialog modal-dialog-centered" role="document">
                            <div className="modal-content">
                                <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                                </button>
                                <div className="modal-body text-center p-5">
                                    <img
                                        className="img-fluid mb-4 lazyload"
                                        data-src={process.env.PUBLIC_URL + "/assets/images/doc-remove-icon.svg"}
                                        alt="icon"
                                    />
                                    <h3>Are you sure want to remove?</h3>
                                    <p className="sub-title">
                                        Your account will be removed.
          </p>
                                    <div className="alert"></div>
                                    <div className="col-12 mt-4 btn-wrap">
                                        <button className="btn btn-gray" type="button" data-dismiss="modal">Cancel</button>
                                        <button className="btn btn-red" type="button" onClick={(e) => {
                                            e.preventDefault()
                                            this.props.deleteAccount({ user_id: localStorage.getItem('user_id') })
                                        }}>Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Remove Popup Ends here */}


                    <Footer />
                </div>
            </div >


        )
    }
}



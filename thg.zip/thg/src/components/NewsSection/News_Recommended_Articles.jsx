import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import * as actions from '../../actions/News';
import * as coachactions from '../../actions/Coach_Listing';
import * as headerActions from '../../actions/common/Header';
import jQuery from 'jquery';
import Moment from 'react-moment';
import AdSense from 'react-adsense';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";


class News_Recommended_Articles extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        // this.props.getWhatsHappeningList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12 });
        // this.props.getCoachListByUser({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 6 });
        this.props.getNewsRecommendedArticles({ page_no: 0, limit: 7, slug: 'news', filter_cat_id: '' });
    }
    componentDidMount() {
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
    }

    whatHappenArticle = o => {
        var cat_name = (o.cat_name).split(',');
        cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];

        var venue = (o.venue).split(',').slice(-1)[0];

        return <a href="javascript:;" className="wt-item">
            <div className="cal">
                <span className="date"><Moment format="DD">
                    {o.start_date_and_time[0]}
                </Moment></span>
                <span className="month"><Moment format="MMM YYYY" withTitle>
                    {o.start_date_and_time[0]}
                </Moment></span>
            </div>
            <div className="cal-cont" data-id={o.ID}>
                <Link to={`/whats_happening/${o.post_name}`}
                    onClick={(e) => {
                        localStorage.setItem('article_id', jQuery(e.target).closest('.cal-cont').data('id'))
                    }}><p className="text-truncate">{cat_name}</p></Link>
                <span className="text-truncate">
                    {o.post_title}
                </span>
                <span className="location">
                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon.svg"} alt="icon" />
                    {venue}
                </span>
            </div>
        </a>
    };

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        // var url = jQuery(e.target).closest(".hor-article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        var url = jQuery(e.target).closest(".hor-article-item").find('.art-background img').attr('src')
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".hor-article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".hor-article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".hor-article-item").find('.art-cont .art-title').text())
    }

    render() {

        return (

            <section className="container-fluid recommended">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-12">
                                <h3 className="title">Recommended Articles</h3>
                            </div>
                            <div className="col-md-8">
                                <div className={this.props.recommend_status === -1? 'd-block' : 'd-none'}>
                                    <h3 className="noarticle">No Articles</h3>
                                </div>
                                {
                                    this.props.newsRecommendedArticles.length > 0 &&
                                    this.props.newsRecommendedArticles.map((r, s) => {
                                        var cat_name = (r.cat_name).split(',');
                                        var cat_name_arr = [];
                                        cat_name.forEach(element => {
                                            cat_name_arr.push(element);
                                        });
                                        var image = (r.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                        return <div className="hor-article-item" key={r.ID}>
                                            <Link to={`/${r.post_name}`} className="art-img art-background"
                                                // style={{ backgroundImage: `url(${(r.thumbnail_image === undefined || r.thumbnail_image === null || r.thumbnail_image === "") ? r.custom_feature_image_url : r.thumbnail_image})` }}
                                            >
                                                <img src={(r.thumbnail_image === undefined || r.thumbnail_image === null || r.thumbnail_image === "") ? r.custom_feature_image_url : r.thumbnail_image} alt="img" />
                                                
                                                {(r.video_file === null || r.video_file === undefined) ? '' : <span className="video-label"><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span>}
                                            </Link>
                                            <div className="art-cont">
                                                <span className="tag">{cat_name[0]}</span>
                                                <a href="javascript:;" className="favorite" data-id={r.ID} data-bucket-id={r.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (r.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                    onClick={(e) => {
                                                        this.bucketList(e)
                                                    }}>
                                                    <img
                                                        className="outline lazyload"
                                                        data-src={image}
                                                        alt="icon"
                                                        data-article-id={r.ID}
                                                    />
                                                    <img
                                                        className="filled lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                        alt="icon"
                                                    />
                                                </a>
                                                <Link to={`/${r.post_name}`} className="art-title rec_art_title">
                                                    <p>
                                                        {r.post_title}
                                                    </p>
                                                    <span className="rec_span_remove text-truncate">
                                                        {r.post_content.replace(/<(.|\n)*?>/g, '')}
                                                    </span>
                                                </Link>
                                                <span className="date-time">
                                                    <Moment format='DD MMM YYYY' withTitle>{r.post_date_gmt}</Moment>
                                                </span>
                                            </div>
                                        </div>
                                    })
                                }
                            </div>
                            <div className="col-md-4">
                                <div className="mb-5">
                                    <div className="join-now text-center col p-0 calendar d-none d-sm-none d-md-block">
                                        {/* <div className="join-now col p-0 text-center mb-4"> */}
                                        <span className="head">Join Our Community</span>
                                        <span >Get our newsletter</span>
                                        <br/>
                                        <br/>
                                        
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/join-now-icon.svg"} alt="icon" />
                                        <p>
                                            {/* Blanditiis praesentium voluptatum deleniti atque corrupti quos
                                            dolores et quas molestias exceptur */}
                                        </p>
                                        <Link to="/subscribe" className="btn btn-orange">Subscribe</Link>
                                        {/* </div> */}
                                    </div>
                                </div>

                                <div className="mb-5">
                                    <div className="join-now text-center col p-0 calendar d-none d-sm-none d-md-block">
                                        {/* <div className="join-now col p-0 text-center mb-4"> */}
                                        <span className="head">CONTRIBUTE WITH US</span>
                                        <span >Write about topics you care about</span>
                                        <br/>
                                        <br/>
                                        
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/join-now-icon.svg"} alt="icon" />
                                        <p>
                                            {/* Blanditiis praesentium voluptatum deleniti atque corrupti quos
                                            dolores et quas molestias exceptur */}
                                        </p>
                                        <Link to="/contribute-to-THG" className="btn btn-orange">Let's get to it</Link>
                                        {/* </div> */}
                                    </div>
                                </div>
                                <div className="text-center d-none d-sm-none d-md-block">
                                {/* <AdSense.Google
                                    client='ca-pub-9111417808865977'
                                    slot='1638754887'
                                    // style={{ display: 'block', width: "100px", marginLeft: "0px", height: "800px" }}
                                    format='auto'
                                    responsive='true'
                                    layout="display"
                                    layoutKey='-gw-1+2a-9x+5c'
                                    /> */}
                                   
                               
                                 <UserAgentProvider
                                ua={window.navigator.userAgent}
                              >
                                <UserAgent windows mac>
                                <AdSense.Google
                                    client="ca-pub-9111417808865977"
                                    slot="2845449790"
                                    style={{ width: 350, height: 811, float: "left" }}
                                    format=""
                                />
                            
                        
                                </UserAgent>
                              </UserAgentProvider>
                          
                                    {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-ver.jpg"} alt="ad" /> */}
                                </div>
                                

                            </div>
                            {/* <div className="col-md-4">
                                <div className="whats-happen col p-0">
                                    <div className="head">
                                        What's Happening
                                    <Link to="/category/whats_happening">
                                            <img src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                        </Link>
                                    </div>
                                    <div className="wt-item-encl mscroll-y-inside">
                                        {this.props.whatsHappeningList.length > 0 &&
                                            this.props.whatsHappeningList.map((o, k) => (this.whatHappenArticle(o)))}
                                    </div>
                                </div>
                                <div className="col px-0 py-4 text-center">
                                    <img style={{ width: "100%" }} src={process.env.PUBLIC_URL + "/assets/images/ad-hor.jpg"} alt="ad" />
                                </div>
                                <div className="join-now col p-0 text-center mb-4">
                                    <span className="head">Join Our Community</span>
                                    <img src={process.env.PUBLIC_URL + "/assets/images/join-now-icon.svg"} alt="icon" />
                                    <p>
                                        Blanditiis praesentium voluptatum deleniti atque corrupti quos
                                        dolores et quas molestias exceptur
                                </p>
                                    <button className="btn btn-orange">Subscribe</button>
                                </div>
                                <div className="whats-happen coach col p-0">
                                    <div className="head">
                                        Coach
                                        <Link to="/category/coach_list">
                                            <img src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                        </Link>
                                    </div>
                                    <div className="wt-item-encl mscroll-y-inside">
                                        {
                                            this.props.coachLists.length > 0 &&
                                            this.props.coachLists.map((o, k) => {
                                                return <a href="javascript:;" className="wt-item" key={k}>
                                                    <div className="avatar-circle art-background" style={{ backgroundImage: `url(${o.guid})` }}>
                                                    </div>
                                                    <div className="cal-cont">
                                                        <p className="text-truncate">{o.display_name}</p>
                                                        <span className="text-truncate">{o.user_extra_values.split(',')[1]}</span>
                                                    </div>
                                                </a>
                                            })
                                        }
                                    </div>
                                </div>
                            </div> */}
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        newsLatestArticlesList: state.News.newsLatestArticles,
        newsBannerList: state.News.newsBannerList,
        newsFeatureArticlesList: state.News.newsFeatureArticles,
        newsPopularArticlesList: state.News.newsPopularArticles,
        newsRecommendedArticles: state.News.newsRecommendedArticles,
        recommend_status: state.News.recommend_status
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getNewsLatestArticlesList: (data) => dispatch(actions.getNewsLatestArticlesList(data)),
        getNewsBannerList: (data) => dispatch(actions.getNewsBannerList(data)),
        getNewsFeatureArticlesList: (data) => dispatch(actions.getNewsFeatureArticlesList(data)),
        getNewsPopularArticlesList: (data) => dispatch(actions.getNewsPopularArticlesList(data)),
        getNewsRecommendedArticles: (data) => dispatch(actions.getNewsRecommendedArticlesList(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    }
};

const newsRecommendedArticles = connect(
    mapStateToProps,
    mapDispatchToProps,
)(News_Recommended_Articles);

export default newsRecommendedArticles;


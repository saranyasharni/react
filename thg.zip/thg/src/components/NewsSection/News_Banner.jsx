import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/News';
import * as sportsActions from '../../actions/Sports';
import jQuery from 'jquery';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class News_Banner extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        jQuery('.cat-item').off('click').click(function () {
            jQuery('.cat-item').removeClass('active')
            jQuery(this).toggleClass('active')
        })
    }

    showRelatedArticles(e) {
        
        e.preventDefault();
        let location = ''
        if (jQuery('.loca_param').data('id')) {
            location = jQuery('.loca_param').data('id')
            
        }
        let filter_name = jQuery('.cat-item.active').data('name')
        // console.log(filter_name, 'filter_name')
        // console.log(location, 'location')
        let catslug = jQuery('.cat-item.active').data('id')
        let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
        this.props.getNewsBannerList({ 
            user_id: userid, page_no: 0, limit: 5, slug: "news", filter_cat_id: catslug ? catslug : '' ,
            location:location,
            filter_name: filter_name,
        });
        this.props.getNewsFeatureArticlesList({ 
            user_id: userid, page_no: 0, limit: 12, slug: "news", filter_cat_id: catslug ? catslug : '',
            location:location,
            filter_name: filter_name
        });
        this.props.getNewsLatestArticlesList({ 
            user_id: userid, page_no: 0, limit: 12, slug: "news", filter_cat_id: catslug ? catslug : '', 
            location:location,
            filter_name: filter_name
        });
        this.props.getCategoryList({ 
            user_id: userid, slug: "news", filter_cat_id: catslug ? catslug : '', 
            page_no: 0, limit: 9,
            location:location,
            filter_name: filter_name
        });
        // this.props.getNewsSportsCategoryList({ user_id: userid, slug: "sports", filter_cat_id: catslug ? catslug : '', page_no: 0, limit: 4 });
        // this.props.getNewsESportsCategoryList({ user_id: userid, slug: "esports", filter_cat_id: catslug ? catslug : '', page_no: 0, limit: 4 });
        // this.props.getNewsTravelCategoryList({ user_id: userid, slug: "travel", filter_cat_id: catslug ? catslug : '', page_no: 0, limit: 4 });
        // this.props.getNewsReviewCategoryList({ user_id: userid, slug: "review", filter_cat_id: catslug ? catslug : '', page_no: 0, limit: 4 });
        this.props.getNewsPopularArticlesList({ 
            user_id: userid, page_no: 0, limit: 12, slug: "news", filter_cat_id: 
            catslug ? catslug : '' ,
            location:location,
            filter_name: filter_name
        });
        this.props.getNewsRecommendedArticles({ page_no: 0, limit: 7, slug: 'news', filter_cat_id: catslug ? catslug : '' ,
        location:location,
        filter_name: filter_name
        });

    }


    render() {

        return (

            <section className="category-sec container-fluid">
                {/* parent-cat Starts here */}
                <div className="row parent-cat py-4" style={{ backgroundColor: 'white' }}>
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                                <a href="javascript:;" 
                                className="cat-item" 
                                data-id="113" 
                                data-name= 'local'
                                onClick={(e) => {
                                    this.showRelatedArticles(e)
                                }}>
                                    Local
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a 
                                href="javascript:;" 
                                className="cat-item"
                                data-id="114" 
                                data-name= 'international'
                                onClick={(e) => {
                                    this.showRelatedArticles(e)
                                }}>
                                    International
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;" className="cat-item" data-id="115" onClick={(e) => {
                                    this.showRelatedArticles(e)
                                }}>
                                    UGC (User Generated Content)
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                {/* parent-cat Ends here */}
            </section>






        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        newsLatestArticlesList: state.News.newsLatestArticles,
        newsBannerList: state.News.newsBannerList
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getNewsLatestArticlesList: (data) => dispatch(actions.getNewsLatestArticlesList(data)),
        getNewsBannerList: (data) => dispatch(actions.getNewsBannerList(data)),
        getCategoryList: (data) => dispatch(sportsActions.getCategoryList(data)),
        getNewsFeatureArticlesList: (data) => dispatch(actions.getNewsFeatureArticlesList(data)),
        getNewsPopularArticlesList: (data) => dispatch(actions.getNewsPopularArticlesList(data)),
        getNewsSportsCategoryList: (data) => dispatch(actions.getNewsSportsCategoryList(data)),
        getNewsESportsCategoryList: (data) => dispatch(actions.getNewsESportsCategoryList(data)),
        getNewsTravelCategoryList: (data) => dispatch(actions.getNewsTravelCategoryList(data)),
        getNewsReviewCategoryList: (data) => dispatch(actions.getNewsReviewCategoryList(data)),
        getNewsRecommendedArticles: (data) => dispatch(actions.getNewsRecommendedArticlesList(data)),
    }
};

const newsBanner = connect(
    mapStateToProps,
    mapDispatchToProps,
)(News_Banner);

export default newsBanner;




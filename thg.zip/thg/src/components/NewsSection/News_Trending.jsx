import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/News';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";
import ContentLoader, { Facebook } from "react-content-loader";

class News_Trending extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getNewsBannerList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5, slug: "news", filter_cat_id: '' });
        this.props.getTrendingLists();
    }

    componentDidMount() {
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
        var THIS = this;
   
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.newsBannerList.length > 0) {
                window.$('.banner .owl-carousel').owlCarousel({
                    items: 1,
                    loop: false,
                    dots: true,
                    autoplay:true,
                    autoplayTimeout:3000,
                    autoplayHoverPause:true,
                    rewind: true
                });

            }
            setTimeout(function () {
                var bannerH = window.$(".banner .owl-carousel").height();
                bannerH ? window.$(".trending-wrap").innerHeight(bannerH) : window.$(".trending-wrap").innerHeight("590px");
            }, 1000);

            if (THIS.props.trendingList.length > 0) {
                window.$(".mscroll-y").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,

                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "outside"
                });
            }

        })
    }

    render() {
        return (
            <section className="hero-sec container-fluid">
                {
                    this.props.newsLoader ? 
                       
                    <div className="loader-pro d-block" style={{
                        marginLeft: '48%', 
                        marginRight: '45%' ,
                        marginTop:'10%',
                        marginBottom:'20%'
                    }} >
                    <img
                      className="img-fluid lazyload"
                      data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                      alt="Avatar"
                    />

                    </div> :
                    <>
                    <div className="row news_trending_loader">
                    <div className="banner col-md-8 p-0">
                    {this.props.newsBannerList.length > 0 ?(
                    <>
                    {this.props.newsBannerList.length > 0 &&
                    (<div className="owl-carousel">
                        {this.props.newsBannerList.map((o, k) => {
                            return <Link to={`/${o.post_name}`} key={o.ID}><div className="item"
                                // style={{ backgroundImage: `url(${(o.custom_feature_image_url) ? o.custom_feature_image_url : o.thumbnail_image})` }}
                                >
                                    <img src={(o.custom_feature_image_url) ? o.custom_feature_image_url : o.image_url} alt="icon" />
                                <div className="carousel-cont">
                                    <div>
                                        <Link to={`/category/${(o.cat_name).split(',')[0].toLowerCase()}`}>
                                            <span className="tag">{(o.cat_name).split(',')[0]}</span>
                                        </Link>
                                        <h4>
                                            {o.post_title}
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            </Link>
                        })}</div>)}
                            
                        </>
                        ): (
                            <>
                
                            <div className= {this.props.banner_status === -1 ? 'd-block' : 'd-none'}>
                                <h3 className="noarticle">No Articles</h3>
                            </div>
                            </>
                        )
                    }            
                    
            </div>
                    
            <div className="trending-wrap col-md-4">
            <h3 className="title">Trending</h3>
            <>
            <div className="trend-article mscroll-y">
                {
                this.props.trendingList.length > 0 &&
                this.props.trendingList.map((m, n) => {
                    {
                        return <Link to={`/${m.post_name}`} className="trend-item">
                            <span className="trend-img">
                                <img data-src={(m.thumbnail_image) ? m.thumbnail_image : m.custom_feat_image_url} className="img-fluid lazyload" />
                            </span>
                            <span className="trend-cont">
                                <p>
                                    {m.post_title}
                                </p>
                                <span className="date-time">
                                    <Moment format='DD MMM YYYY'>{m.created_date}</Moment>
                                </span>
                            </span>
                        </Link>
                    }
                    })
                    }
                
                    </div>
                    </>
                        
                    </div>  
             
                    
                    </div>
                    </>
                    }
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        newsLatestArticlesList: state.News.newsLatestArticles,
        newsBannerList: state.News.newsBannerList,
        trendingList: state.News.trendingList,
        newsLoader:state.News.newsLoader,
        banner_status:state.News.banner_status,
        trending_status: state.News.trending_status

    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getNewsLatestArticlesList: (data) => dispatch(actions.getNewsLatestArticlesList(data)),
        getNewsBannerList: (data) => dispatch(actions.getNewsBannerList(data)),
        getTrendingLists: () => dispatch(actions.getTrendingList()),
    }
};

const newsTrending = connect(
    mapStateToProps,
    mapDispatchToProps,
)(News_Trending);

export default newsTrending;

import React, { Component, Fragment } from 'react'
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class News_Price_Section extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <div className="container py-5 price-sec">
                <div className="row">
                    <div className="col-md-6">
                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/price-img.png"} alt="image" />
                    </div>
                    <div className="col-md-6 price-cont">
                        <h3>Get a Dining voucher</h3>
                        {/* <p>Win a dining voucher worth $178 from Fusion Japanese Restaurant</p> */}
                        <button className="btn btn-gray"><Link to='/vauchersubscribe' style={{ textDecoration: 'none', color: 'black' }}>Subscribe to win</Link></button>
                    </div>
                </div>
            </div>







        )
    }
}



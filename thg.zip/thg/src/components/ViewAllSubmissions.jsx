import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';
import Footer from '../containers/common/Footer';
import Header from '../containers/common/Header';
import config from '../actions/common/Api_Links';
import * as actions from '../actions/Contest'
import { connect } from "react-redux";
import jQuery from 'jquery';
import ReactPlayer from 'react-player/lazy';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';

class ViewAllSubmissions extends Component {
  
    componentDidMount() {
        jQuery(document).ready(function () {
            jQuery('.show_video').click(function(){
             
                jQuery(this).closest('.submission-overlay').css('display', 'none')
            })
        })
        this.props.allSubmission({
            post_id:localStorage.getItem('cotest_slug'),
            page_no:0,
            limit:9
        })

    }
    componentDidUpdate () {
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery('.show_video').click(function(){
                
                jQuery(this).closest('.submission-overlay').css('display', 'none')
            })
        if (THIS.props.archiveStatus === 1) {
                
            jQuery('.alert').html('<strong>No more submissions to show.</strong>');

            jQuery('.alert').removeClass('alert-success').addClass('alert-danger')
            
            THIS.props.updateArchiveStatus(0);
            setTimeout(function () {
                jQuery(".alert").removeClass('alert-danger');
            }, 2000);
        }
    })
    }
    showMore(e) {
        e.preventDefault();
        this.props.updatePageNo({ flag: 0 });
        this.props.getNewAllsubmisson({ page_no: this.props.contestPageNo + 1, limit: 6 });
    }
    
 render () {
    //const { error, isLoaded, items } = this.state;
    // let new_items = this.props.all_submission_list ? this.props.all_submission_list : []
    // items.push(new_items)
    return (
        
            <>
                <Header />
                <div>
                {
                    //console.log(this.props.all_submission_list, 'this.props.all_submission_list')
                 //   console.log(items, 'items345')
                }
                <section className="category-sec container-fluid bdr-btm">
                    <div className="row parent-cat py-3">
                    <div className="container">
                        {/* { console.log(items, '5555555555')} */}
                        <h4>
                        <a href="javascript:;" className="back">
                        <Link to = {`/contestsubmit/${localStorage.cotest_slug ? localStorage.getItem('cotest_slug'): ''}`}>
                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                        </Link>
                        </a>
                            View all Submissions - <small>{localStorage.cotests_name ? localStorage.getItem('cotests_name'): 'contestname'}</small>
                        </h4>
                    </div>
                    </div>
                </section>
                {/* Category Section Ends here */}
                {/* Submission Section Starts here */}
                <section className="container-fluid mt-5 mb-5 min-h-vp">
                    <div className="row">
                    <div className="container">
                        <div className="row">
                        {
                            this.props.items.length > 0 && this.props.items.map((o,k) => {
                                return <div className="col-lg-4 col-md-6 col-12 mb-4"
                                key = {o.id}
                                >
                                <div className="submission-thumb"
                                data-id = {o.id}
                                >
                                
                                    {
                                        o.file_type &&
                                        o.file_type === 'video' 
                                        
                                        ? (
                                        <>
                                                  
                                        <ReactPlayer className="video-fluid" 
                                        url={o.image_url}
                                        //light = {true}
                                        config={{ file: { 
                                            attributes: {
                                                controlsList: 'nodownload'
                                            }
                                            }}}
                                            
                                        controls  />

                                        
                                        </>
                                            
                                        ): (
                                            <>
                                            <div
                                                style={{ backgroundImage: `url(${(o.image_url === "" || o.image_url === null || o.image_url === undefined) ? "" : o.image_url})`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat', height: '100%', width:'100%' }}
                                            >
                                                {/* <img class="img-fluid" src = {process.env.PUBLIC_URL + "/assets/images/submission-thumb-1.jpg"} alt="thumb"/> */}
                                                {/* <img
                                                className="img-fluid"
                                                src={o.image_url? o.image_url :
                                                process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                                alt="thumb"
                                                /> */}
                                            </div>
                                            </>
                                        )
                                    }
                                    
                                    <div className= {o.file_type === 'video' ? "video-tag d-block": "video-tag d-none"}>
                                    <img src={process.env.PUBLIC_URL+"/assets/images/play-icon.svg"} alt="icon"/>
                                    {o.video_duration !== undefined ? o.video_duration : '12:00'}
                                    </div>
                                    <div className="submission-overlay">
                                    <span className="name">{o.first_name ? o.first_name + ' ' +o.last_name: ' '}</span>
                                    <p>
                                    {
                                        ReactHtmlParser(o.description ? o.description.substring(0,410) : '')
                                    }
                                    </p>
                                    { o.file_type === 'video' ? (
                                        <>
                                        <button className="btn btn-orange show_video">
                                        
                                            Play Video
                                        </button>
                                        </>
                                    ): (
                                        <>
                                        
                                        </>
                                    )
                                    }
                                    
                                    </div>
                                </div>
                                
                            </div>
                            })
                        }
                        
                        {/* <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-3.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="video-tag">
                                <img src="images/play-icon.svg" alt="icon" />
                                2:98
                                </div>
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="video-tag">
                                <img src="images/play-icon.svg" alt="icon" />
                                2:98
                                </div>
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="video-tag">
                                <img src="images/play-icon.svg" alt="icon" />
                                2:98
                                </div>
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div> */}
                        </div>
                        {
                            this.props.items.length > 0
                            &&
                            <div className={this.props.items.length > 0 ? 'row d-block': 'row d-none'}>
                            <div className="col text-center mt-4 mb-5">
                            <div className="alert" role="alert">
                                </div>
                                <button className="btn btn-orange"
                                onClick={(e) => { this.showMore(e) }}
                                >Show more</button>
                            </div>
                            </div>
                        }
                        
                    </div>
                    </div>
                </section>
                </div>
        
                <Footer />
            </>
            
    )
 }

    
}
const mapStateToProps = (state, ownProps) => {
    return {
        contestPageNo: state.Contest.contestPageNo,
        all_submission_list : state.Contest.all_submission_list,
        items:state.Contest.items,
        archiveStatus:state.Contest.archiveStatus
    }
};
  
const mapDispatchToProps = (dispatch, state) => {
    return {
        allSubmission: (data) => dispatch(actions.allSubmission(data)),
        getNewAllsubmisson: (data) => dispatch(actions.getNewAllsubmisson(data)),
        updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
        updateArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data))
    }
};
export default connect(mapStateToProps, mapDispatchToProps) (ViewAllSubmissions)

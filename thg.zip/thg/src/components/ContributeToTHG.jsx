/** @format */

import React, { Component, Fragment } from "react";

import jQuery from "jquery";

import { Link } from "react-router-dom";

import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";

import history from "../stores/history";

export default class ContributeToTHG extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
		this.props.getContributeToTHG('contribute-to-thg')
  }
  componentDidMount() {
    document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />
          <Fragment>
            <section className="container-fluid mt-5">
              <div className="row">
                <div className="container">
                  <div className="row">
                    <div className="col-12 text-center mb-5">
                    </div>
                    <div className="col-md-12">
                      <h3 className="title">{ this.props.contributeToTHG[0] ? 
                      this.props.contributeToTHG[0].post_title : ''}</h3>
                      <div className="row">
                        <div className="col-md-8 fp-content">
                          <p>
                          {/* { 
                          ReactHtmlParser(
                            this.props.contributeToTHG[0] ? this.props.contributeToTHG[0].post_content : ''
                          )
                          } */}
                          {
                            this.props.contributeToTHG.length > 0 &&
                           // console.log(this.props.contributeToTHG[0].post_content, 'this.props.contributeToTHG'),
                            this.props.contributeToTHG.map((o, k) => {
                                var content = o.post_content;
                                
                                content = content.replace(/\r\n/g,'<p></p>');
                                return <p>
                                    {ReactHtmlParser(content)}

                                </p>
                            })
                          }
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

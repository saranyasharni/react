import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';
import Footer from '../containers/common/Footer';
import Header from '../containers/common/Header';

import * as actions from '../actions/Contest'
import ReactPlayer from 'react-player/lazy';
import {connect} from 'react-redux';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import jQuery from 'jquery';
class EditorsPick extends Component {
    
    componentDidMount() {
        this.props.getApprovedsubmisson({
            post_id:localStorage.getItem('cotest_slug'),
            page_no:0,
            limit:9
        })
        // let formData = new URLSearchParams();    //formdata object
        // formData.append('post_id', localStorage.getItem('cotest_slug'));
        // fetch(config.get_approved_submissions, {
        //     method: 'POST',
        //     body: formData,
        //     headers: {
        //         "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        //         "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
        //     }
        // })
        //   .then(res => res.json())
        //   .then(
        //     (result) => {
           
        //       this.setState({
        //         isLoaded: true,
        //         items: result.result
        //       });
        //     },
           
        //     (error) => {
        //       this.setState({
        //         isLoaded: true,
        //         error
        //       });
        //     }
        //   )
    }
    // useEffect(() => {

    //     alert('12')
    //     let formData = new URLSearchParams();    //formdata object
    //     formData.append('post_id', 667);
    
    //     fetch(config.get_giveaway_winners, {
    //         method: 'POST',
    //         body: formData,
    //         headers: {
    //             "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    //             "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
    //         }
    //     })
      
    //     .then(res => res.json())
    //     alert('1290')
    //     .then(data => {
    //         alert('45')
    //         console.log('came', data)
    //         if (data.status === 1) {
    //             alert()
                
    //             setItem(data.result);
    //         } else {
    //             setItem([]);
    //         }
            
    //     });

    // });
    componentDidUpdate () {
        var THIS = this;
        jQuery(document).ready(function () {
            jQuery('.show_video').click(function(){
                
                jQuery(this).closest('.submission-overlay').css('display', 'none')
            })
        if (THIS.props.archiveStatus === 1) {
                
            jQuery('.alert').html('<strong>No more submissions to show.</strong>');

            jQuery('.alert').removeClass('alert-success').addClass('alert-danger')
            
            THIS.props.updateArchiveStatus(0);
            setTimeout(function () {
                jQuery(".alert").removeClass('alert-danger');
            }, 2000);
        }
    })
    }
    showMore(e) {
        e.preventDefault();
        this.props.updatePageNo({ flag: 0 });
        this.props.getNewAllsubmisson({ page_no: this.props.contestPageNo + 1, limit: 3 });
    }
 render () {
    
    return (
        
            <>
                <Header />
                <div>
                <section className="category-sec container-fluid bdr-btm">
                    <div className="row parent-cat py-3">
                    <div className="container">
                        
                        <h4>
                        <a href="javascript:;" className="back">
                        <Link to = {`/contestsubmit/${localStorage.cotest_slug ? localStorage.getItem('cotest_slug'): ''}`}>
                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                        </Link>
                        </a>
                            Editor's Pick - <small>{localStorage.cotests_name ? localStorage.getItem('cotests_name'): 'contestname'}</small>
                        </h4>
                    </div>
                    </div>
                </section>
                {/* Category Section Ends here */}
                {/* Submission Section Starts here */}
                <section className="container-fluid mt-5 mb-5 min-h-vp">
                    <div className="row">
                    <div className="container">
                        <div className="row">
                        {
                            this.props.approved_list.length > 0 &&
                            this.props.approved_list.map((o,k) => {
                                return <div 
                                className="col-lg-4 col-md-6 col-12 mb-4"
                                key = {o.id}
                                >
                                <div className="submission-thumb">
                                {
                                        o.file_type &&
                                        o.file_type === 'video' 
                                        
                                        ? (
                                        <>
                                        
                                        <ReactPlayer className="video-fluid" 
                                        url={o.image_url}
                                        //light = {true}
                                        config={{ file: { 
                                            attributes: {
                                                controlsList: 'nodownload'
                                            }
                                            }}}
                                            
                                        controls  />

                                        
                                        </>
                                            
                                        ): (
                                            <>
                                            <div
                                            
                                            style = {{
                                                backgroundImage: `url(${(o.image_url === "" || o.image_url === null || o.image_url === undefined) ? process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg" : o.image_url})`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat', height: '100%', width: '100%' 
                                            }}
                                            >
                                                {/* <img
                                                className="img-fluid"
                                                src={o.image_url? o.image_url :
                                                process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                                alt="thumb"
                                                /> */}
                                            </div>
                                            </>

                                        )
                                    }
                                    <div className= {o.file_type === 'video' ? "video-tag d-block": "video-tag d-none"}>
                                    <img src={process.env.PUBLIC_URL+"/assets/images/play-icon.svg"} alt="icon"/>
                                    {o.video_duration !== undefined ? o.video_duration : '12:00'}
                                    </div>
                                    <div className="submission-overlay">
                                    <span className="name">{o.first_name ? o.first_name + ' ' +o.last_name: ' '}</span>
                                    <p>
                                    {
                                        ReactHtmlParser(o.description ? o.description.substring(0, 400) : '')
                                    }
                                    </p>
                                    { o.file_type === 'video' ? (
                                        <>
                                        <button className="btn btn-orange show_video">
                                            Show Video
                                        </button>
                                        </>
                                    ): (
                                        <>
                                        
                                        </>
                                    )
                                    }
                                    
                                    </div>
                               
                                </div>
                            </div>
                            })
                        }
                        
                        {/* <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-3.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="video-tag">
                                <img src="images/play-icon.svg" alt="icon" />
                                2:98
                                </div>
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="video-tag">
                                <img src="images/play-icon.svg" alt="icon" />
                                2:98
                                </div>
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="video-tag">
                                <img src="images/play-icon.svg" alt="icon" />
                                2:98
                                </div>
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-12 mb-4">
                            <div className="submission-thumb">
                            <div>
                                <img
                                className="img-fluid"
                                src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                                alt="thumb"
                                />
                                <div className="submission-overlay">
                                <span className="name">John Doe</span>
                                <p>
                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                                    occaecat cupidatat non proident, sunt in culpa qui officia
                                </p>
                                <button className="btn btn-orange">
                                    <img src="images/play-arrow.svg" />
                                    Play
                                </button>
                                </div>
                            </div>
                            </div>
                        </div> */}
                        </div>
                        {
                            this.props.approved_list.length > 0 &&
                            <div className={this.props.approved_list.length > 0 ? "row d-block" : 'row d-none'}>
                            <div className="col text-center mt-4 mb-5">
                            <div className="alert" role="alert">
                                </div>
                                <button 
                                onClick={(e) => { this.showMore(e) }}
                                className="btn btn-orange">Show more</button>
                            </div>
                            </div>
                        }
                        
                    </div>
                    </div>
                </section>
                </div>
        
                <Footer />
            </>
            
    )
 }
    
}
const mapStateToProps = (state, ownProps) => {
    return {
        contestPageNo: state.Contest.contestPageNo,
        approved_list : state.Contest.approved_list,
        //items:state.Contest.items,
        archiveStatus:state.Contest.archiveStatus
    }
};
  
const mapDispatchToProps = (dispatch, state) => {
    return {
        getApprovedsubmisson: (data) => dispatch(actions.getApprovedsubmisson(data)),
        getNewAllsubmisson: (data) => dispatch(actions.getNewApproSubmisson(data)),
        updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
        updateArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data))
    }
};
export default connect(mapStateToProps,mapDispatchToProps)(EditorsPick)

import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import 'react-trumbowyg/dist/trumbowyg.min.css'

import Trumbowyg from 'react-trumbowyg'



import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';



export default class checktexteditor extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {

    }

    componentDidMount() {
        var THIS = this;

    }
    componentDidUpdate() {
        var THIS = this;



    }

    componentWillReceiveProps(nextProps) {

    }

    handleChange = (e) => {
        console.log('e', e)
    }





    render() {

        return (


            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    {
                        /* My Account Starts here */
                    }
                    <section className="container my-account">
                        <div className="my-acc-right">
                            <div className="my-acc-cont">
                                <h3>Create Article</h3>
                                <div className="row mb-5">
                                    <form className="create-article col-md-12">
                                        <div className="alert" role="alert">
                                        </div>
                                        <div className="form-group mb-5">
                                            <input
                                                type="text"
                                                className="border-0 form-control"
                                                name
                                                style={{ fontWeight: 300 }}
                                                placeholder="Title"
                                            />

                                        </div>
                                        <div className="form-group mb-5" style={{ height: '500px' }}>
                                            <Trumbowyg id='react-trumbowyg'
                                                buttons={
                                                    [
                                                        ['viewHTML'],
                                                        ['formatting'],
                                                        'btnGrp-semantic',
                                                        ['link'],
                                                        ['insertImage'],
                                                        'btnGrp-justify',
                                                        'btnGrp-lists',
                                                        ['table'], // I ADDED THIS FOR THE TABLE PLUGIN BUTTON
                                                        ['fullscreen']
                                                    ]
                                                }
                                                data="<p>Hello</p>"
                                                placeholder='Type your text!'
                                                onChange={e => this.handleChange(e)}
                                                ref="trumbowyg"
                                            />

                                        </div>
                                        <div className="form-group mb-5">
                                            <select className="form-control category">

                                                <option value="0">Parent Tag</option>
                                                <option value="1">&nbsp;&nbsp;&nbsp;Child Tag1</option>
                                                <option value="2">&nbsp;&nbsp;&nbsp;Child Tag2</option>
                                            </select>

                                        </div>
                                        <div className="col-md-12 text-right px-0 mt-4">
                                            <button className="btn btn-trans">Schedule for Later</button>
                                            <button className="btn btn-green-flat" disabled={(this.props.article_image === '') ? true : false} onClick={e => this.publishArticle(e)}>Publish</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>
                    {
                        /* My Account Ends here */
                    }

                    <Footer />
                </div>
            </div >


        )
    }
}



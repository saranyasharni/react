import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import { Link } from 'react-router-dom';

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';

export default class Data_Protection_Policy extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
       // this.props.fetchPrivacyContents({ page_slug: 'privacy-policy' })
    }
    componentDidMount() {
        document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
        this.props.getDataProtection('data-protection-policy')
    }
    

    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Main Wrapper Starts here */}


                        {/* Coach Listing Starts here */}
                        <section className="container-fluid mt-5">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-12 text-center mb-5">
                                            {/* <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            /> */}
                                        </div>
                                        <div className="col-md-12">
                                        <h3 className="title">{this.props.dataProtection.length ? this.props.dataProtection[0].post_title: ''}
                                        </h3>
                                            <div className="row">
                                                <div className="col-12 fp-content">
                                                    {/* <p>Your privacy is important to us and the purpose of this Data Protection Policy is to inform you of how we manage personal data in accordance with the Personal Data Protection Act 2012 (“the Act”). Please take a moment to read this Data Protection Policy so that you know and understand the purposes for which we collect, use and disclose your Personal Data.</p>
                                                    <p>By interacting with us, submitting your personal data to us or signing up for any promotions or services offered by us, you will be treated as having given consent to us, our related affiliates, as well as our respective representatives, to collect, use, disclose and sharing, where necessary and appropriate, your Personal Data with our authorised service providers and relevant third parties in the manner referred to in this Data Protection Policy.</p>
                                                    <ol>
                                                        <li>
                                                            <strong>Personal Data</strong>
                                                            <ol>
                                                                <li>In this Data Protection Policy, “Personal Data” refers to any data, whether true or not, about an individual who can be identified (a) from that data; or (b) from that data and other information to which we have or are likely to have access, including data in our records as may be updated from time to time.</li>
                                                                <li>Examples of such Personal Data you may provide to us include (depending on the nature of your interaction with us) your name, NRIC, passport or other identification number, telephone number(s), mailing address, email address and any other information which you have provided us in any forms you may have submitted to us or in any other forms of interaction with you.</li>
                                                            </ol>
                                                        </li>
                                                        <li>
                                                            <strong>Collection of Personal Data</strong>
                                                            <ol>
                                                                <li>Generally, we collect Personal Data in the following ways:
                                                                    <ol>
                                                                        <li>when you use our services provided through our Site, including when you establish any accounts with us;</li>
                                                                        <li>when you request that we contact you, be included in an email or other mailing list; or when you respond to our request for additional Personal Data, our promotions and other initiatives;</li>
                                                                        <li>when you are contacted by, and respond to, our marketing representatives and agents and other service providers;</li>
                                                                        <li>when you use our electronic services, or interact with us via our websites and platforms or use services on our websites and platforms;</li>
                                                                        <li>when we communicate with you to inform you of changes and development to our policies, terms and conditions and other administrative information, including for the purposes of servicing you in relation to products and services offered to you;</li>
                                                                        <li>when we need to resolve complaints and handle any of your requests and enquiries;</li>
                                                                        <li>when you submit your Personal Data to us for any other reason</li>
                                                                    </ol>
                                                                </li>
                                                                <li>If you provide us with any Personal Data relating to a third party (e.g. information on your customers, spouse, children, parents, and/or employees), by submitting such information to us, you represent to us that you have obtained the consent of such third party to you providing us with their Personal Data for the respective purposes.</li>
                                                            </ol>
                                                        </li>
                                                        <li>
                                                            <strong>Purposes for the Collection, Use and Disclosure of Your Personal Data</strong>
                                                            <ol>
                                                                <li>
                                                                    Generally, we collect, use and disclose your Personal Data for the following purposes:
                                                                    <ol>
                                                                        <li>responding to, processing and handling your complaints, queries, requests, feedback and suggestions;</li>
                                                                        <li>verifying your identity;</li>
                                                                        <li>managing ourand our affiliate’s administrative and business operations and complying with internal policies and procedures;</li>
                                                                        <li>facilitating business asset transactions (which may extend to any mergers, acquisitions or asset sales); </li>
                                                                        <li>matching any Personal Data held which relates to you for any of the purposes listed herein;</li>
                                                                        <li>requesting feedback or participation in surveys, as well as conducting market research and/or analysis for statistical, profiling or other purposes for us to design our products, understand customer behaviour, preferences and market trends, and to review, develop and improve the quality of our products and services;</li>
                                                                        <li>preventing, detecting and investigating crime, including fraud and money-laundering or terrorist financing, and analysing and managing commercial risks;</li>
                                                                        <li>protecting and enforcing our contractual and legal rights and obligations;</li>
                                                                        <li>conducting audits, reviews and analysis of our internal processes, action planning and managing commercial risks;</li>
                                                                        <li>preventing, detecting and investigating crime and managing the safety and security of our premises and services (including but not limited to carrying out CCTV surveillance and conducting security clearances</li>
                                                                        <li>complying with any applicable rules, laws and regulations, codes of practice or guidelines or to assist in law enforcement and investigations by relevant authorities; and/or</li>
                                                                        <li>any other purpose relating to any of the above.</li>
                                                                    </ol>
                                                                </li>
                                                                <li>These purposes may also apply even if you do not maintain any account(s) with us, or have terminated these account(s).</li>
                                                                <li>In addition, we collect, uses and discloses your Personal Data for the following purposes depending on the nature of our relationship:
                                                                    <ol>
                                                                        <li>If you have an account with us:
                                                                            <ol>
                                                                                <li>to maintain your account with us;</li>
                                                                                <li>to verify and process your personal particulars in relation to provision ofOnline Services to you;</li>
                                                                                <li>to provide you with the goods and services which you have signed up for, including the provision and delivery of newspapers and magazines requested;</li>
                                                                                <li>communicating with you to inform you of changes and development to ourpolicies, terms and conditions and other administrative information, including for the purposes of servicing you in relation to products and services offered to you;</li>
                                                                                <li>resolving complaints and handling requests and enquiries;</li>
                                                                                <li>conducting market research for statistical, profiling and statistical analysis for the improvement of services provided to you; and</li>
                                                                                <li>the processing of your Personal Data in relation to any of the purposes stated above.</li>
                                                                            </ol>
                                                                        </li>
                                                                        <li>If you submit advertisement to us through <a href="mailto:advertise@thehomeground.asia">advertise@thehomeground.asia</a> or any of our other online advertising portals:
                                                                            <ol>
                                                                                <li>verify and process your personal particulars and payments made for the posting of the advertisements;</li>
                                                                                <li>communicating with you to inform you of changes and development to ourpolicies, terms and conditions and other administrative information, including for the purposes of servicing you in relation to products and services offered to you;</li>
                                                                                <li>resolving complaints and handling requests and enquiries;</li>
                                                                                <li>conducting market research for statistical, profiling and statistical analysis for the improvement of services provided to you; and</li>
                                                                                <li>the processing of your Personal Data in relation to any of the purposes stated above.</li>
                                                                            </ol>
                                                                        </li>
                                                                    </ol>
                                                                </li>
                                                                <li>In addition, where permitted under the Act, we may also collect, use and disclose your Personal Data for the following purposes (which we may describe in our documents and agreements as "Additional Purposes" for the handling of Personal Data):
                                                                    <ol>
                                                                        <li>providing or marketing services, products and benefits to you, including promotions, loyalty and reward programmes;</li>
                                                                        <li>matching Personal Data with other data collected for other purposes and from other sources (including third parties) in connection with the customisation, provision or offering of products, services, marketing or promotions, whether by us or other third parties;</li>
                                                                        <li>administering contests and competitions, and conducting lucky draws, including, where necessary, in order to announce the results of these contests, competitions and lucky draws and identify and contact the winners, and in order to publicise and conduct marketing strictly related to these contests, competitions and lucky draws</li>
                                                                        <li>sending you details of products, services, special offers and rewards, either to our customers generally, or which we have identified may be of interest to you; and/or</li>
                                                                        <li>conducting market research, understanding and analysing customer behaviour, location, preferences and demographics for us to offer you products and services as well as special offers and marketing programmes which may be relevant to your preferences and profile.</li>
                                                                    </ol>
                                                                </li>
                                                                <li>If you have provided your telephone number(s) and have indicated that you consent to receiving marketing or promotional information via your telephone number(s), then from time to time, we may contact you using such telephone number(s) (including via voice calls, text , fax or other means) with information about our products and services (including discounts and special offers).</li>
                                                                <li>In relation to particular products or services or in your interactions with us, we may also have specifically notified you of other purposes for which we collect, use or disclose your Personal Data. If so, we will collect, use and disclose your Personal Data for these additional purposes as well, unless we have specifically notified you otherwise.</li>
                                                            </ol>
                                                        </li>
                                                        <li>
                                                            <strong>Disclosure of Personal Data</strong>
                                                            <ol>
                                                                <li>We will take reasonable steps to protect your Personal Data against unauthorised disclosure. Subject to the provisions of any applicable law, your Personal Data may be provided, for the purposes listed above (where applicable), to the following entities or parties, whether they are located overseas or in Singapore:
                                                                    <ol>
                                                                        <li>our affiliates</li>
                                                                        <li>agents, contractors or third party service providers who provide operational services to us, such as telecommunications, information technology, payment, payroll, processing, training, market research, newspaper vendor services, newspaper delivery services, storage, archival or other services to us;</li>
                                                                        <li>vendors or any third party business partners who offer goods and services or sponsor contests or other promotional programs on our sites, whether in conjunction with us or not;</li>
                                                                        <li>external business and charity partners in relation to corporate promotional events;</li>
                                                                        <li>the Credit Bureau, or in the event of default or disputes, any debt collection agencies or dispute resolution centres;</li>
                                                                        <li>any business partner, investor, assignee or transferee (actual or prospective) to facilitate business asset transactions (which may extend to any merger, acquisition or asset sale;</li>
                                                                        <li>anyone to whom we transfer or may transfer our rights and duties;</li>
                                                                        <li>banks, credit card companies and their respective service providers;</li>
                                                                        <li>our professional advisors such as our auditors and lawyers;</li>
                                                                        <li>relevant government regulators or authority or law enforcement agency to comply with any laws or rules and regulations imposed by any governmental authority; and/or</li>
                                                                        <li>any other party to whom you authorise us to disclose your personal data.</li>
                                                                    </ol>
                                                                </li>
                                                            </ol>
                                                        </li>
                                                        <li>
                                                            <strong>Use of Cookies</strong>
                                                            <ol>
                                                                <li>Our websites and platforms use cookies and other technologies. Cookies are small text files stored in your computing or other electronic devices when you visit our website and platforms for record keeping purposes. Cookies are stored in your browser’s file directory, and the next time you visit the website or platform, your browser will read the cookie and relay the information back to the website, platform or element that originally set the cookie. Depending on the type of cookie it is, cookies may store user preferences and other information.</li>
                                                                <li>Web beacons (also known as pixel tags and clear GIFs) involve graphics that are not apparent to the user. Tracking links and/or similar technologies consist of a few lines of programming code and can be embedded in our websites or platforms. Web beacons are usually used in conjunction with cookies and primarily used for statistical analysis purposes. This technology can also be used for tracking traffic patterns on websites and platforms, as well as finding out if an e-mail has been received and opened and to see if there has been any response.</li>
                                                                <li>We may employ cookies and other technologies as follows:
                                                                    <ol>
                                                                        <li>tracking information such as the number of visitors and their frequency of use, profiles of visitors and their preferred sites;</li>
                                                                        <li>making our websites and platforms easier to use;</li>
                                                                        <li>to better tailor our services to your interests and needs;</li>
                                                                        <li>collating information on a user’s search and browsing history;</li>
                                                                        <li>when you interact with us on our websites and platforms, we may automatically receive and record information on our server logs from your browser. We may collect for the purposes of analysis, statistical and site-related information including, without limitation, information relating to how a visitor arrived at the website or platform, the browser used by a visitor, the operating system a visitor is using, a visitor's IP address, and a visitor's click stream information and time stamp (which may include for example, information about which pages they have viewed, the time the pages were accessed and the time spent per web page);</li>
                                                                        <li>using such information to understand how people use our websites and platforms, and to help us improve their structure and contents;</li>
                                                                        <li>using cookies that are necessary in order to enable our websites and platforms to operate, for example, cookies that enable you to log onto secure parts of our websites and platforms; and/or</li>
                                                                        <li>personalising the website and platform for you, including delivering advertisements which may be of particular interest to you and using cookie related information to allow us to understand the effectiveness of our advertisements.</li>
                                                                    </ol>
                                                                </li>
                                                                <li>Some cookies we use are from third party companies to provide us with web analytics and intelligence about our websites and platforms. These companies collect information about your interaction with our websites and platforms. We use such information to compile statistics about visitors who interact with our sites and platforms to gauge the effectiveness of our communications, and to provide more pertinent information to our visitors.</li>
                                                                <li>If you do not agree to such use of cookies, you can adjust your browser settings. Unless you have adjusted your browser settings to block cookies, our system will issue cookies as soon as you visit our site or click on a link in a targeted email that we have sent you, even if you have previously deleted our cookies. However, you may not be able to enter certain part(s) of our site or platform. This may also impact your user experience while on our site or platform.</li>
                                                            </ol>
                                                        </li>
                                                        <li>
                                                            <strong>Third Party Sites</strong>
                                                            <p>Our website may contain links to other websites operated by third parties. We are not responsible for the data protection practices of websites operated by third parties that are linked to our website. We encourage you to learn about the data protection policies of such third party websites. Some of these third party websites may be co-branded with our logo or trademark, even though they are not operated or maintained by us. Once you have left our website, you should check the applicable Data Protection Policy of the third party website to determine how they will handle any information they collect from you.</p>
                                                        </li>
                                                        <li>
                                                            <strong>Withdrawal, Access and Correction of our Personal Data</strong>
                                                            <p>If you have any questions or feedback relating to your Personal Data or our Data Protection Policy, would like to withdraw your consent to any use of your Personal Data as set out in this Data Protection Policy; or would like to obtain access and make corrections to your Personal Data records, you can email us at <a href="mailto:contact@thehomeground.asia">contact@thehomeground.asia</a>.</p>
                                                            <p>If we ever send you information by email concerning new products, services or information that you did not expressly request, we will provide you with an email address which you may then request no further notices.</p>
                                                        </li>
                                                        <li>
                                                            <strong>Governing Law</strong>
                                                            <p>This Data Protection Policy shall be governed in all respects by the laws of Singapore.</p>
                                                        </li>
                                                    </ol>
                                                    <p className="last-update">Last updated on August 2020</p> */}
                                                    <p>
                                                    {
                                                        this.props.dataProtection.length>0 &&
                                                        this.props.dataProtection.map((o,k)=> {
                                                          var content = o.post_content;
                                                            // content = content.replace(/&nbsp;/g, '<p></p>');
                                                            content = content.replace(/\r\n/g,'<p></p>');
                                                            return <p>
                                                            {ReactHtmlParser(content)}

                                                          </p> })
                                                      }  
                                               </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {/* Coach Listing Ends here */}



                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



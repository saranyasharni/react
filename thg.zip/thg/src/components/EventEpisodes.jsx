import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import * as actions from '../actions/THGTV';
import history from "../stores/history";

class EventEpisodes extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        let event_id = window.location.pathname.split('/')[3]
        // console.log(event_id, 'event_idjkjkjk')
        THIS.props.getAllEpisodes({ event_id: event_id });
    }
    
    showMore(e) {
        e.preventDefault();
        jQuery('.text-center .alert').html('<strong>No More Videos</strong>');
                jQuery('.text-center .alert').removeClass('alert-success').addClass('alert-danger')
                
        setTimeout(function () {
            jQuery(".text-center .alert").removeClass('alert-danger');
        }, 2000);
    }

    render() {
        let events_new_id = window.location.pathname.split('/')[3]
        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Main Wrapper Starts here */}

                    <section className="category-sec container-fluid bdr-btm">
                        <div className="row parent-cat py-3">
                        <div className="container">
                            {/* { console.log(items, '5555555555')} */}
                            <h4>
                            <a href="javascript:;" className="back">
                            <Link 
                             to={`/category/thg-tv/`}
                            >
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                            </Link>
                            </a>
                            Episodes 
                            </h4>
                        </div>
                        </div>
                    </section>
                        {/* Coach Listing Starts here */}
                        <section className="container-fluid">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-12 text-center mb-5">
                                            {/* <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            /> */}
                                        </div>
                                        <div className="col-md-12">
                                     
                                            
                                            <div className="row">
                                                {
                                                    // console.log(this.props.episodesList, 'this.props.episodesList'),
                                                    this.props.episodesList.length > 0 &&
                                                    this.props.episodesList.map((o, k) => {
                                                        return <div className="col-md-3 mb-4" key={o.id}>
                                                            <div className="article-item video-snip" data-id={o.id} >
                                                                <Link 
                                                                to={`/thgtvdetail/${o.base_title}/${o.id}&&&${window.location.pathname.split('/')[3]}`}
                                                                className="art-img art-background"
                                                                    style={{ backgroundImage: `url(${o.img_url})` }}
                                                                    onClick={(e) => {
                                                                        localStorage.setItem('programme_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                    }}>
                                                                    {/* <img src={o.img_url} alt="img" /> */}
                                                                    <span className="video-label">
                                                                        <span>
                                                                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"} alt="icon" />
                                                                            {/* 12:32 */}
                                                                        </span>
                                                                    </span>
                                                                </Link>
                                                                <div className="art-cont">
                                                                    {/* <a href="javascript:;" className="favorite">
                                                                    <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                                                    <img
                                                                        className="filled"
                                                                        src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                        alt="icon"
                                                                    />
                                                                </a> */}
                                                                    <Link 
                                                                      to={`/thgtvdetail/${o.base_title}/${o.id}&&&${window.location.pathname.split('/')[3]}`} className="art-title"
                                                                        onClick={(e) => {
                                                                            localStorage.setItem('programme_id', jQuery(e.target).closest('.article-item').data('id'))
                                                                        }}>
                                                                        {o.name}
                                                                    </Link>
                                                                    <span className="date-time">
                                                                        <Moment format='DD MMM YYYY'>{o.date_start}</Moment>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    })
                                                }
                                                <div className="col-md-12 text-center my-5 pb-3">
                                                <div className="alert" role="alert">
                                                </div>
                                                    <button className="btn btn-orange" type="button" onClick={(e) => { this.showMore(e) }}>Show More</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {/* Coach Listing Ends here */}

                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        episodesList: state.THGTV.episodesList
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getAllEpisodes: (data) => dispatch(actions.getAllEpisodes(data))
    }
};

const eventEpisodes = connect(
    mapStateToProps,
    mapDispatchToProps,
)(EventEpisodes);

export default eventEpisodes;



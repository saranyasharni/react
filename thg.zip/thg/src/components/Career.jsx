/** @format */

import React, { Component, Fragment } from "react";

import jQuery from "jquery";

import { Link } from "react-router-dom";

import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";

import history from "../stores/history";

export default class Career extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
		this.props.getCareer('career')
  }
  componentDidMount() {
    document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
    console.log(jQuery('.fp-content').find('p'), "getting")
    
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />
          <Fragment>
            <section className="container-fluid mt-5">
              <div className="row">
                <div className="container">
                  <div className="row">
                    <div className="col-12 text-center mb-5">
                    </div>
                    <div className="col-md-12">
                      <h3 className="title">{ this.props.career[0] ? 
                      this.props.career[0].post_title : ''}</h3>
                      <div className="row">
                        <div className="col-md-8 fp-content">
                          
                          {/* { 

                          ReactHtmlParser(
                            this.props.career[0] ? this.props.career[0].post_content : ''
                          )
                          } */}
                          {
                            this.props.career.length > 0 &&
                           // console.log(this.props.career[0].post_content, 'this.props.career'),
                            this.props.career.map((o, k) => {
                                var content = o.post_content;
                                content = content.replace(/\r\n\r\n/g, '<p></p>');
                                content = content.replace(/\r\n/g,'<br>');
                                return <p>
                                    {ReactHtmlParser(content)}

                                </p>
                            })
                          }
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

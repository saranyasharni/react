import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Home';
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class Home_Reel extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getReelArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 3, slug: 'reel' });
    }

    render() {

        return (

            <section className="container-fluid reel py-5">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <h3 className="col-md-12 mb-5 text-center">Reel</h3>
                            {
                                this.props.reelArticlesList.length > 0 &&
                                this.props.reelArticlesList.map((o, k) => {
                                    return <div className="col-md-4">
                                        <div className="reel-item">
                                            <Link to={`/videodetail/${o.post_name}`}><div className="reel-thumb">
                                                {<img class="video-fluid lazyload" data-src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" />}
                                                <Link to={`/videodetail/${o.post_name}`} className="play-btn">
                                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/play-icon.svg"} alt="icon/" />
                                                </Link>
                                            </div></Link>
                                            <Link to={`/videodetail/${o.post_name}`}>
                                                <p className="text-truncate">
                                                    {o.post_title}
                                                </p>
                                            </Link>
                                        </div>
                                    </div>
                                })
                            }
                            <div className="col text-center mt-3 mt-sm-5">
                                <Link to="/category/reel" className="btn btn-orange">View All</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        reelArticlesList: state.Home.reelArticles
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getReelArticlesList: (data) => dispatch(actions.getReelArticlesList(data)),
    }
};

const homeReel = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Home_Reel);

export default homeReel;



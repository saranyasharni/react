import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Home';
import * as thgactions from '../../actions/THGTV';
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class Home_THGTv extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getVideoStreamApi();
        // this.props.getTHGTvList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5, slug: 'thg-tv' });
    }

    render() {

        return (

            <section className="thg-tv container-fluid bg-gray mt-3">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 col-12">
                                <h3 className="title">
                                    Thg Tv
                                    <Link to="/category/thg-tv">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                    </Link>
                                </h3>
                            </div>
                            {
                                console.log(this.props.programmesList, 'this.props.programmesList'),
                                this.props.programmesList.length > 0 &&
                                this.props.programmesList.map((o, k) => {
                                    if (k === 0) {
                                        return <div className="col-md-6 col-12 program-item" key={o.id} data-id={o.id}>
                                            <Link to={`/episodes/${o.base_name}/${o.id}`} className="tv-wrap"
                                                onClick={(e) => {
                                                    console.log('id',jQuery(e.target).closest('.program-item').data('id'))
                                                    localStorage.setItem('programme_id', jQuery(e.target).closest('.program-item').data('id'))
                                                }}>
                                                {<img class="video-fluid tv-thumb lazyload" data-src={o.img_url} alt="image" />}

                                                {/* <img
                                                    className="tv-thumb img-fluid"
                                                    src={process.env.PUBLIC_URL + "/assets/images/thg-thumb-big.jpg"}
                                                    alt="icon"
                                                /> */}
                                                <span className="video-label full-w">
                                                    <p>{o.name}</p>
                                                    <span>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />
                                                        {/* 14:53 */}
                                                    </span>
                                                </span>
                                            </Link>
                                        </div>
                                    } else if (k === 1) {
                                        return <div className="col-md-6 col-12">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="row">
                                                        {this.props.programmesList.map((m, l) => {
                                                            if (l === 1 || l === 2) {
                                                                return <div className="col-6 program-item" key={m.id} data-id={m.id}>
                                                                    <Link to={`/episodes/${o.base_name}/${o.id}`} className="tv-thumb-sm"
                                                                        onClick={(e) => {
                                                                            console.log('id',jQuery(e.target).closest('.program-item').data('id'))
                                                                            localStorage.setItem('programme_id', jQuery(e.target).closest('.program-item').data('id'))
                                                                        }}>
                                                                        {<img class="video-fluid thumb lazyload" data-src={m.img_url} alt="image" />}
                                                                    </Link>
                                                                    <Link to={`/episodes/${o.base_name}/${o.id}`} className="play-btn">
                                                                        <img
                                                                            className="img-fluid lazyload"
                                                                            data-src={process.env.PUBLIC_URL + "/assets/images/play-icon.svg"}
                                                                            alt="icon"
                                                                        />
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                    <div className="row">
                                                        {this.props.programmesList.map((n, p) => {
                                                            if (p === 3 || p === 4) {
                                                                return <div className="col-6 program-item" key={n.id} data-id={n.id}>
                                                                    <Link to={`/episodes/${o.base_name}/${o.id}`} className="tv-thumb-sm"
                                                                        onClick={(e) => {
                                                                            console.log('id',jQuery(e.target).closest('.program-item').data('id'))
                                                                            localStorage.setItem('programme_id', jQuery(e.target).closest('.program-item').data('id'))
                                                                        }}>
                                                                        {<img class="video-fluid thumb lazyload" data-src={n.img_url} alt="image" />}
                                                                    </Link>
                                                                    <Link to={`/episodes/${o.base_name}/${o.id}`} className="play-btn">
                                                                        <img
                                                                            className="img-fluid lazyload"
                                                                            data-src={process.env.PUBLIC_URL + "/assets/images/play-icon.svg"}
                                                                            alt="icon"
                                                                        />
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    }

                                })
                            }
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        THGTvList: state.Home.THGTvList,
        programmesList: state.THGTV.programmesList,
        programmeStreamList: state.THGTV.programmeStreamList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getTHGTvList: (data) => dispatch(actions.getTHGTvList(data)),
        getVideoStreamApi: () => dispatch(thgactions.getVideoStraming()),
    }
};

const homeTHGTv = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Home_THGTv);

export default homeTHGTv;



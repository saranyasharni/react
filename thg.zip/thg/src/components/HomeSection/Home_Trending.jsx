import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Home';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";
import ContentLoader, { Facebook } from "react-content-loader";

class Home_Trending extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.getBannerList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5 });
        this.props.getTrendingLists();
    }

    componentDidMount() {
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
        

    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.bannerList.length > 0) {
                window.$('.banner .owl-carousel').owlCarousel({
                    items: 1,
                    loop: false,
                    dots: true,
                    autoplay:true,
                    autoplayTimeout:3000,
                    autoplayHoverPause:true,
                    rewind: true
                });

            }
            setTimeout(function () {
                var bannerH = window.$(".banner .owl-carousel").height();
                bannerH ? window.$(".trending-wrap").innerHeight(bannerH) : window.$(".trending-wrap").innerHeight("590px");
            }, 1000);

            if (THIS.props.trendingList.length > 0) {
                window.$(".mscroll-y").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "outside"
                });
            }

        })
    }

    render() {
        return (

            <section className="hero-sec container-fluid">
            <>
            <div className="row home_loader">
                {
                    this.props.homeLoader ?
                    
                    <div className="loader-pro d-block" style={{
                        marginLeft: '48%', 
                        marginRight: '45%' ,
                        marginTop:'10%',
                        marginBottom:'20%'
                    }} >

                    <img
                      className="img-fluid lazyload"
                      data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                      alt="Avatar"
                    />
              </div>
                    : 
                    <>
                    <div className="banner col-md-8 p-0">
                    <div className={this.props.latest_art_status === -1 ? 'd-block' : 'd-none'}>
                    <h3 className="noarticle">No Articles</h3>
                    </div>
                {
                    this.props.bannerList.length > 0 &&
                    (<div className="owl-carousel">
                        {this.props.bannerList.map((o, k) => {
                            return <Link to={`/${o.post_name}`} key={o.ID}><div className="item lazyload"
                                // data-bg={(o.custom_feature_image_url) ? o.custom_feature_image_url : o.image_url}
                                // style={{ backgroundImage: `url(${(o.custom_feature_image_url) ? o.custom_feature_image_url : o.image_url})` }}
                            >
                                <img src={(o.custom_feature_image_url) ? o.custom_feature_image_url : o.image_url} alt="icon" />
                                <div className="carousel-cont">
                                    <div>
                                        <Link to={`/category/${(o.cat_name).split(',')[0].toLowerCase()}`}>
                                            <span className="tag">{(o.cat_name).split(',')[0]}</span>
                                        </Link>
                                        <h4 class="txt-ellipse-no">
                                            {o.post_title}
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            </Link>
                        })
                        }</div>)
                    }

            </div>
            <div className="trending-wrap col-md-4 ">

                <h3 className="title">Trending</h3>
                <div className={this.props.trending_art_status === -1 ? 'd-block' : 'd-none'}>
                <h3 className="noarticle">No Articles</h3>
                </div>
                <div className="trend-article mscroll-y">
                {
                this.props.trendingList.length > 0 &&
                this.props.trendingList.map((m, n) => {
                    {
                        return <Link to={`/${m.post_name}`} className="trend-item">
                            <span className="trend-img">
                                <img data-src={(m.thumbnail_image) ? m.thumbnail_image : m.custom_feat_image_url} className="img-fluid lazyload" alt="image" />
                            </span>
                            <span className="trend-cont">
                                <p>
                                    {m.post_title}
                                </p>
                                <span className="date-time">
                                <Moment format='DD MMM YYYY'>{m.post_date}</Moment>
                                </span>
                            </span>
                        </Link>
                    }
                })
                }
            
                </div>

                
                </div>
                    </>
                }
           
            </div>
            </>
        
    
               
            </section>
        
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        latestArticlesList: state.Home.latestArticles,
        bannerList: state.Home.bannerList,
        trendingList: state.Home.trendingList,
        homeLoader: state.Home.homeLoader,
        latest_art_status: state.Home.latest_art_status
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getLatestArticlesList: (data) => dispatch(actions.getLatestArticlesList(data)),
        getBannerList: (data) => dispatch(actions.getBannerList(data)),
        getTrendingLists: () => dispatch(actions.getTrendingList()),
    }
};

const homeTrending = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Home_Trending);

export default homeTrending;

import React, { Component, Fragment } from 'react'
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


export default class Price_Section extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (
            // <div className="container-fluid py-5">
            //     <div className="row">
            //         <div className="col-md-6 ">
            //             <img className="lazyload" data-src={process.env.PUBLIC_URL+ "/assets/images/Gift.png"} alt="image" />
            //         </div>
            //         <div className="col-md-6 price-cont">
            //         <h3>Contests and Giveaways</h3>
            //             <Link to='/contest' className="btn btn-orange">
            //                 Enter Now
            //             </Link>
            //         </div>
            //         <div className="col-md-6 price-cont">
            //             <h3>Get a Dining voucher</h3>
                        
            //             <button className="btn btn-gray">
                        
            //                 <Link to='/contest' style={{ textDecoration: 'none', color: 'black' }}>Subscribe to win</Link>
            //                 </button>
            //         </div>
            //     </div>
            // </div>
            <div className="container price-sec">
            <div className="row">
                <div className="col-md-5">
                <img
                    className="contest-lft-img"
                    src={process.env.PUBLIC_URL+ "/assets/images/Gift.png"}
                    alt="image"
                />
                </div>
                <div className="col-md-6 price-cont">
                <h3>Contests and Giveaways</h3>
                <Link to='/contest' className="btn btn-orange">
                    Enter Now
                </Link>
                </div>
            </div>
            </div>







        )
    }
}



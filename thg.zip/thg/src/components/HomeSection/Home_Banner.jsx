import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Home';
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';

class Home_Banner extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
        this.props.getExclusiveArticlesList({ user_id: userid, slug: "exclusive", page_no: 0, limit: 4 });
    }

    componentDidMount() {
        jQuery(document).ready(function () {
            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });
            // Marquee Animation (Exclusive News Item Animation)
            // window.requestAnimationFrame = (function () {
            //     return window.requestAnimationFrame ||
            //         window.webkitRequestAnimationFrame ||
            //         window.mozRequestAnimationFrame ||
            //         function (callback) {
            //             window.setTimeout(callback, 1000 / 60);
            //         };
            // })();

            // var speed = 5000;
            // (function currencySlide() {
            //     var currencyPairWidth = jQuery('.slideItem:first-child').outerWidth();
            //     jQuery(".slideContainer").animate({
            //         marginLeft: -currencyPairWidth
            //     }, speed, 'linear', function () {
            //         jQuery(this).css({
            //             marginLeft: 0
            //         }).find("li:last").after(jQuery(this).find("li:first"));
            //     });
            //     requestAnimationFrame(currencySlide);
            // })();
        })
    }

    componentDidUpdate() {
        jQuery(document).ready(function () {
            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });
            // Marquee Animation (Exclusive News Item Animation)
            window.requestAnimationFrame = (function () {
                return window.requestAnimationFrame ||
                    window.webkitRequestAnimationFrame ||
                    window.mozRequestAnimationFrame ||
                    function (callback) {
                        window.setTimeout(callback, 1000 / 60);
                    };
            })();

            var speed = 5000;
            (function currencySlide() {
                var currencyPairWidth = jQuery('.slideItem:first-child').outerWidth();
                jQuery(".slideContainer").animate({
                    marginLeft: -currencyPairWidth
                }, speed, 'linear', function () {
                    jQuery(this).css({
                        marginLeft: 0
                    }).find("li:last").after(jQuery(this).find("li:first"));
                });
                requestAnimationFrame(currencySlide);
            })();
        })
    }


    render() {

        return (

            <section className="container-fluid flash-news row">
                <span className="exclusive">
                    <img src={process.env.PUBLIC_URL + "/assets/images/star.svg"} alt="icon" />
                Exclusive
                </span>
                <div className="fl-news-item">
                    <div className="container mscroll-x">
                        <ul className="list-inline slideContainer">
                            {
                                this.props.exclusiveCategoryList.length > 0 &&
                                this.props.exclusiveCategoryList.map((o, k) => {
                                    return <li className="list-inline-item slideItem" key={o.ID}>
                                        <Link to={`/${o.post_name}`}>
                                            {o.post_title}
                                        </Link>
                                    </li>
                                })
                            }
                        </ul>
                    </div>
                </div>
            </section>

        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        exclusiveCategoryList: state.Home.exclusiveCategoryList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getExclusiveArticlesList: (data) => dispatch(actions.getExclusiveCategoryList(data)),
    }
};

const homeBanner = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Home_Banner);

export default homeBanner;




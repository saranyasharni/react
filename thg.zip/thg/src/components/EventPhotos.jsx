import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import * as actions from "../actions/Feature_Parent";
import history from "../stores/history";

import { Link } from "react-router-dom";
import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class EventPhotos extends Component {
  constructor(props) {
    super(props);
    this.state = { open: false, imageUrl: null, desc : null};
    this.handleShowImage = this.handleShowImage.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.goToPreviousPath = this.goToPreviousPath.bind(this);
  }

  componentDidMount() {
    
    var THIS = this;
    THIS.props.getLatestPhotos({
      page_no: 0,
      limit: "",
      event_id: this.props.location.pathname.split('/')[3] ? this.props.location.pathname.split('/')[3] : localStorage.getItem("event_id"),
    });
    // this.props.updateCoachPageNo({ flag: 1 });
    // THIS.props.fetchArchiveArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, slug: 'master-class', limit: 9 });
  }

  showMore(e) {
    // e.preventDefault();
    // this.props.updateCoachPageNo({ flag: 0 });
    // this.props.getNewArchiveListByUser({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.coachPageNo + 1, slug: 'master-class', limit: 9 });
  }

  handleShowImage(imageUrl, desc) {
    this.setState({ imageUrl }, () => {
    this.setState({ open: true });
    this.setState({ desc });
    window.jQuery("#event-photo-pop").modal("show");
    });
  }

  handleClose() {
    // console.log("handleClose")
    window.jQuery("#event-photo-pop").modal("hide");
  }

  goToPreviousPath() {
    alert()
    
  }
  // coachModal(e, userid) {
  //     e.preventDefault();
  //     var userDetail = this.props.coachList.filter(function (item) {
  //         return item.ID === userid;
  //     })
  //     this.props.updateCoachDetails(userDetail[0]);
  //     window.jQuery("#coach-detail").modal('show');

  // }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />
          <section className="category-sec container-fluid bdr-btm">
            <div className="row parent-cat py-3">
            <div className="container">
                {/* { console.log(items, '5555555555')} */}
                <h4>
                <a href="javascript:;" className="back">
                <Link 
                to={`/category/featured-events/`}
                // onClick={() => 
                  
                // }
                >
                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                </Link>
                </a>
                    Photos 
                </h4>
            </div>
            </div>
          </section>
          <Fragment>
            {/* Main Wrapper Starts here */}

            {/* Coach Listing Starts here */}
            <section className="container-fluid mt-5">
              <div className="row">
                <div className="container">
                  <div className="row">
                    {/* <div className="col-12 text-center mb-5">
                     
                    </div> */}
                    <div className="col-md-12">
                 
                      
                      <div
                        className={
                          this.props.latestPhotosList.length > 0
                            ? "col-md-12 col-12 d-none"
                            : "col-md-12 col-12 d-block"
                        }
                      >
                        <h3 className="noarticle">No Photos</h3>
                      </div>
                      <div className="row">
                        {this.props.latestPhotosList.length > 0 &&
                          this.props.latestPhotosList.map((o, k) => {
                            // var cat_name = (o.cat_name).split(',');
                            // cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                            // var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                            return (
                              <a
                                href="javascript:;"
                                className="col-md-3 p-3 photo-small-thumb text-center"
                                onClick={() => {
                                  this.handleShowImage(o.guid, o.event_caption);
                                }}
                                 
                              >
                               
                                <img
                                  className="img-fluid lazyload"
                                  data-src={o.guid}
                                  alt="img"
                                  style={{ width: 230, height: 170 }}
                                />
                                <div className="event-photo-overlay">
                                {/* <span className="name">John Doe</span> */}
                                <p>
                                  {o.event_caption.substring(0,130)}
                                </p>
                               
                                </div>
                                {/* <span className="maginfy">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/search-icon.svg"} alt="icon" />
                                                        </span> */}
                              </a>
                            );
                          })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="modal fade"
                id="event-photo-pop"
                tabIndex={-1}
                role="dialog"
                aria-hidden="true"
              >
                <div
                  className="modal-dialog modal-dialog-centered"
                  role="document"
                >
                  <div className="modal-content">
                  <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                      &#10005;
                    </button>
                    <div className="modal-body">
                      {this.state.open && (
                        <div className="row">
                          <div className="col-md-12">
                            <div className="col-md-12 text-center event-photos">
                              <img
                                className="img-fluid lazyload"
                                src={this.state.imageUrl}
                                alt="img"
                                // onMouseOut={()=>{
                                //     this.handleClose();

                                //   }}
                              />
                              <p>
                                {this.state.desc}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              {/* Survey Popup Ends here */}
            </section>
            <br />
            <br />
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    latestPhotosList: state.FeatureParent.latestPhotos,
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getLatestPhotos: (data) => dispatch(actions.getLatestPhotosList(data)),
  };
};

const eventPhotos = connect(mapStateToProps, mapDispatchToProps)(EventPhotos);

export default eventPhotos;

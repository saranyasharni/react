import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import AdSense from 'react-adsense';
import HeroBanner from './FeatureSection/Hero_Banner'
import AdSection from './FeatureSection/Ad_Section'
import CategorySection from './FeatureSection/Category_Section'
import FeaturedArticles from './FeatureSection/Featured_Articles'
import PhotoSection from './FeatureSection/Photo_Section'
import Schedule from './FeatureSection/Schedule'
import VideoSection from './FeatureSection/Video_Section'
import LiveStream from './FeatureSection/LiveStream'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";


export default class Feature_Parent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        THIS.props.getFeaturedEventsBanner({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5 })
        // THIS.props.getLatestPhotos({ limit: 7 })
        jQuery(document).ready(function () {
            window.$(".feature-nav").addClass("active");

            window.jQuery(".mscroll-y").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            window.jQuery(".mscroll-y-inside").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });

            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            // var stickyBTM = window.jQuery(".sticky-btm-height").height();
            // window.jQuery(".sticky-btm-height").height(stickyBTM);
            // window.jQuery('.schedule-head,.lft-head').sticky({ topSpacing: 0, bottomSpacing: window.jQuery(".sticky-btm-height").outerHeight(true) });

            window.jQuery('[data-toggle="tooltip"]').tooltip({
                trigger: 'hover'
            });
            window.jQuery('[data-toggle="tooltip"]').on('click', function () {
                window.jQuery(this).tooltip('hide')
            })

        });
    }

    componentDidUpdate() {
        jQuery(document).ready(function () {
            window.$(".feature-nav").addClass("active");

            window.$(".mscroll-y").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            window.$(".mscroll-y-inside").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });

            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            // var stickyBTM = window.jQuery(".sticky-btm-height").height();
            // window.jQuery(".sticky-btm-height").height(stickyBTM);
            // window.jQuery('.schedule-head,.lft-head').sticky({ topSpacing: 0, bottomSpacing: window.jQuery(".sticky-btm-height").outerHeight(true) });

            // window.jQuery('[data-toggle="tooltip"]').tooltip({
            //     trigger: 'hover'
            // });
            window.jQuery('[data-toggle="tooltip"]').on('click', function () {
                window.jQuery(this).tooltip('hide')
            })
        })
    }

    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Category Section Starts here */}
                        <CategorySection purchaseTicket={this.props.purchaseTicket} />
                        {/* Category Section Ends here */}

                        {/* Hero Banner Starts here */}
                        <HeroBanner />
                        {/* Hero Banner Ends here */}

                        {/* Featured Articles Starts here */}
                        <FeaturedArticles />
                      
                
                        <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              {/* <UserAgent tablet mobile>
                <div className="ad_sze container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 288, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent> */}
              <UserAgent windows mac>
                <div className="ad_sze container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 1111, 
                      marginBottom :'20px',
                      height: 140, 
                      float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider> 
                        {/* Featured Articles Ends here */}
                        {
                          this.props.livtStreamVideos &&
                          this.props.livtStreamVideos.length > 0 &&
                          <LiveStream/>
                        }
                        
                        {/* Schedule Starts here */}
                        {
                            this.props.featuredEventsBannerList.length >0 &&
                            <Schedule 
                                list = {this.props.featuredEventsBannerList[0]}
                            />
                        }
                        
                        {/* Schedule Ends here */}
                            {/* ad will be place here */}
                            <AdSection />
                            {/* ad will be place here */}

                            {/* Photos Sec Starts here */}
                            <PhotoSection />
                            {/* Photo Sec Ends here */}

                            {/* Videos Sec Starts here */}
                            <VideoSection />
                            {/* Videos Sec Ends here */}
                            {this.props.purchaseTicket !="" && (this.props.purchaseTicket !== null) &&              
                            <div className="container text-center mt-0 mt-sm-5 mb-5 pb-4" id="ticket-video-leasr">
                            <a className="btn btn-orange" href={this.props.purchaseTicket } target={"_blank"}>
                              <img className="mr-3 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/ticket-icon.svg"} alt="icon" />
                          {"Purchase Tickets"}
                            </a>
                            </div>
                          }
                        <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              {/* <UserAgent tablet mobile>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 288, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent> */}
              <UserAgent windows mac>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 1111, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider> 
                            <Footer />

                    </Fragment>

                </div>
            </div >
        )
    }
}



import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../actions/Sports';
import * as headerActions from '../actions/common/Header';
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import { userDetails } from '../actions/common/Header';
import { THGTvList } from '../actions/Home';

export default class Archive_Articles extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        this.props.updateCoachPageNo({ flag: 1 });
        THIS.props.fetchArchiveArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, slug: 'master-class', limit: 9 });
    }

    showMore(e) {
        e.preventDefault();
        this.props.updateCoachPageNo({ flag: 0 });
        this.props.getNewArchiveListByUser({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.coachPageNo + 1, slug: 'master-class', limit: 9 });
    }

    // coachModal(e, userid) {
    //     e.preventDefault();
    //     var userDetail = this.props.coachList.filter(function (item) {
    //         return item.ID === userid;
    //     })
    //     this.props.updateCoachDetails(userDetail[0]);
    //     window.jQuery("#coach-detail").modal('show');

    // }

    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Main Wrapper Starts here */}


                        {/* Coach Listing Starts here */}
                        <section className="container-fluid mt-5">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-12 text-center mb-5">
                                            <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            />
                                        </div>
                                        <div className="col-md-12">
                                            <h3 className="title">Archive Articles</h3>
                                            <div className="row">
                                                {
                                                    this.props.archiveList.length > 0 &&
                                                    this.props.archiveList.map((o, k) => {
                                                        var cat_name = (o.cat_name).split(',');
                                                        cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                                        var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                                        return <div className="col-md-6 col-lg-4">
                                                            <div className="article-item">
                                                                <Link to={`/${o.post_name}`} className="art-img art-background"
                                                                    style={{ backgroundImage: `url(${(o.custom_feature_image_url === undefined || o.custom_feature_image_url === null || o.custom_feature_image_url === "") ? o.image_url : o.custom_feature_image_url})` }}>
                                                                    {/* <img src={(o.custom_feature_image_url === undefined || o.custom_feature_image_url === null) ? o.image_url : o.custom_feature_image_url} alt="img" /> */}

                                                                    {(o.video_file === null || o.video_file === undefined) ? '' : <span className="video-label"><img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span>}

                                                                </Link>
                                                                <div className="art-cont">
                                                                    <span className="tag">{cat_name}</span>
                                                                    <a href="javascript:;" className="favorite" data-id={o.ID} data-bucket-id={o.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                                        onClick={(e) => {
                                                                            this.bucketList(e)
                                                                        }}>
                                                                        <img
                                                                            className="outline"
                                                                            src={image}
                                                                            alt="icon"
                                                                            data-article-id={o.ID}
                                                                        />
                                                                        <img
                                                                            className="filled"
                                                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                            alt="icon"
                                                                        />
                                                                    </a>
                                                                    <Link to={`/${o.post_name}`} className="art-title">
                                                                        {o.post_title}
                                                                    </Link>
                                                                    <span className="date-time">
                                                                        <Moment fromNow>{o.post_date}</Moment>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    })
                                                }
                                                <div className="col-md-12 text-center my-5 pb-3">
                                                    <button className="btn btn-orange" type="button" onClick={(e) => { this.showMore(e) }}>Show More</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {/* Coach Listing Ends here */}
                        {/* Main Wrapper Ends here */}
                        {/* Modal Popup Starts here */}
                        <div
                            className="modal fade coach-detail"
                            id="coach-detail"
                            tabIndex={-1}
                            role="dialog"
                            aria-hidden="true"
                        >
                            <div className="modal-dialog modal-dialog-centered" role="document">
                                <div className="modal-content">
                                    <button
                                        type="button"
                                        className="close"
                                        data-dismiss="modal"
                                        aria-label="Close"
                                    >
                                        <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                                    </button>
                                    <div className="modal-body p-0">
                                        <div className="col-12 p-0 coach-img">
                                            <img
                                                className="img-fluid"
                                                src={this.props.coachDetails.guid}
                                                alt="icon"
                                            />
                                        </div>
                                        <div className="coach-cont">
                                            <p className="name">
                                                {this.props.coachDetails.display_name}
                                                <span className="mt-1">{(this.props.coachDetails.profession) ? this.props.coachDetails.profession : ''}</span>
                                            </p>
                                            <p className="short-bio">
                                                Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                                accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                                                quae ab illo inventore veritatis et quasi architecto beatae vitae
                                                dicta sunt explicabo.
            </p>
                                            <a href={`tel:${(this.props.coachDetails.phone_no && this.props.coachDetails.phone_no != 'undefined') ? this.props.coachDetails.phone_no : ''}`}>
                                                <img src={process.env.PUBLIC_URL + "/assets/images/phone-icon.svg"} alt="icon" />
                                                <span>{(this.props.coachDetails.phone_no && this.props.coachDetails.phone_no != 'undefined') ? this.props.coachDetails.phone_no : ''}</span>
                                            </a>
                                            <a href={(this.props.coachDetails.user_email && this.props.coachDetails.user_email != 'undefined') ? this.props.coachDetails.user_email : ''}>
                                                <img src={process.env.PUBLIC_URL + "/assets/images/envelope-icon.svg"} alt="icon" />
                                                <span>{(this.props.coachDetails.user_email && this.props.coachDetails.user_email != 'undefined') ? this.props.coachDetails.user_email : ''}</span>
                                            </a>
                                            <a className="lh-unset mb-0" href="javascript:;">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/gps-xs.svg"} alt="icon" />
                                                <span>
                                                    {(this.props.coachDetails.location && this.props.coachDetails.location != 'undefined') ? this.props.coachDetails.location.split(',')[0] : ''}
                                                    <br />
                                                    {(this.props.coachDetails.location && this.props.coachDetails.location != 'undefined') ? this.props.coachDetails.location.split(',')[1] : ''}
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



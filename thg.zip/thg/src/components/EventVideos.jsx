import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../actions/Feature_Parent';
import StripeCheckout from 'react-stripe-checkout';
import { Link } from 'react-router-dom';

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import ReactPlayer from 'react-player'

class EventVideos extends Component {
    constructor(props) {
        super(props);
        this.state = {
            playControls : false,
            amount:''
        }
    }

    componentDidMount() {  
        var THIS = this;
        THIS.props.getLatestVideos({ 
            user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0,
            page_no: 0, limit: '', event_id: this.props.location.pathname.split('/')[3] ? this.props.location.pathname.split('/')[3] : localStorage.getItem('event_id') })
        }
        playVideo(thumb) {
            this.setState({
                amount:thumb
            })
            var subscption = JSON.parse(localStorage.getItem('subscription'))
            // console.log(subscption, 'subscption')
            if (!localStorage.user_id)   {
                
                window.jQuery('#signup-modal').modal('show')
            } else if (!subscption) {
                // console.log(thumb, 'thumb')
                window.jQuery('#success-pop-subscribed-full-video-sec').modal('show')
            } else {
                // console.log(subscption.subscribed_event_id, 'op')
                // console.log(subscption.subscribed, 'op')
                // console.log(subscption.subscribed_user_id, 'op')
                // if (subscption.subscribed_event_id && 
                //     subscption.subscribed === 1 &&
                //     subscption.subscribed_user_id
                // ) {
                
                this.setState(
                    {
                        playControls:!this.state.playControls
                    }
                )
                // } else {
                //     alert('both has valu')
                //     console.log(subscption.subscribed_event_id, 'op')
                // console.log(subscption.subscribed, 'op')
                // console.log(subscption.subscribed_user_id, 'op')
                //     console.log(subscption, 'subscption')
                //     window.jQuery('#success-pop-subscribed-full-video-sec').modal('show')
                // }
            }
        }
    render() {

        return (
            <>
            <div className="container-fluid">
                <div className="row">
                    <Header />
                    <section className="category-sec container-fluid bdr-btm">
                        <div className="row parent-cat py-3">
                        <div className="container">
                            {/* { console.log(items, '5555555555')} */}
                            <h4>
                            <a href="javascript:;" className="back">
                            <Link 
                            to={`/category/featured-events/`}
                            // onClick={() => 
                            // history.goBack()
                            // }
                            >
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                            </Link>
                            </a>
                            Videos 
                            </h4>
                        </div>
                        </div>
                    </section>
                    <Fragment>
                        {/* Main Wrapper Starts here */}


                        {/* Coach Listing Starts here */}
                        <section className="container-fluid mt-5">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        {/* <div className="col-12 text-center mb-5">
                                            <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            />
                                        </div> */}
                                        <div className="col-md-12">
                                       
                                            <div className={this.props.latestVideos.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                                                <h3 className="noarticle">No Videos</h3>
                                            </div>
                                            <div className="row video-sec h-auto pb-5">
                                                {
                                                    this.props.latestVideos.length > 0 &&
                                                    this.props.latestVideos.map((o, k) => {
                                                        return <div className="col-md-6 p-3 main_video_events" key={o.ID}>
                                                            <ReactPlayer className="thumb_video" url={o.guid}
                                                            
                                                            config={{ file: { 
                                                                attributes: {
                                                                  controlsList: 'nodownload'
                                                                }
                                                            }}}
                                                            // onClick = {() => {
                                                            //     if (o.event_amount === '' || o.event_amount === null){
                                                                    
                                                            //         this.setState({
                                                            //             playControls:!this.state.playControls
                                                            //         })
                                                            //     } else {
                                                            //         if (o.plan_subscribed
                                                            //             ) {     
                                                                    
                                                            //         this.setState({
                                                            //             playControls:!this.state.playControls
                                                            //         })
                                                                        
                                                            //         } else {    
                                                                    
                                                            //             this.playVideo(o.event_amount, o.plan_subscribed)
                                                            //         }
                                                            //     }
                                                              
                                                            // }}
                                                            light = {o.event_thumbnail}
                                                            controls 
                                                            // = {
                                                    
                                                            //     (o.event_amount === '' || o.event_amount === null) ?
                                                            //     true : 
                                                            //     (o.plan_subscribed) ? true :
                                                            //     false
                                                            // }
                                                            // playing = {
                                                            //     (o.event_amount === '' || o.event_amount === null) ?
                                                            //     true : 
                                                            //     (o.plan_subscribed) ? true :
                                                            //     false
                                                            // }
                                                            />
                                                        </div>
                                                    })
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </Fragment>

                    <Footer />
                    
                </div>
                <div
             className="modal fade submit-entry"
             id="success-pop-subscribed-full-video-sec"
             tabIndex={-1}
             role="dialog"
             aria-hidden="true"
             >
             <div className="modal-dialog modal-dialog-centered" role="document">
                 <div className="modal-content">
                 <button
                     type="button"
                     className="close"
                     data-dismiss="modal"
                     aria-label="Close"
                 >
                 <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                 </button>
                 <div className="modal-body success-pop">
                     {/* <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" /> */}
                     <h3 className="mb-3">To watch videos please subscribe now</h3>
                     <StripeCheckout
                        amount={this.state.amount}
                        billingAddress
                        shippingAddress
                        name="subscribe now." // the pop-in header title
                        // description="Big Data Stuff" // the pop-in header subtitle
                        // className="btn btn-orange" 
                        style = {{marginLeft:'900px'}}
                        // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                        // description="Awesome Product"
                        // image="assets/images/logo-small.png"
                        stripeKey="pk_test_51GwUThARRSyCmdWnhY2AOexGvuotGtH8QMd1Uit4vk6DNj6KifR6hZUX7trwcdcgv4RwyO3Yb8LS8NxuSrmVYkMd00HXcjZCI8"
                        token={this.onToken}
                    >
                <button
                type="submit"
                className="btn btn-asphalt succ_ok" 
                
                onClick={(e) => {
                    window.jQuery('#success-pop-subscribed-full-video-sec').modal('hide')
                }}
                >
                SUBSCRIBE NOW
                </button>
                    </StripeCheckout> 
                 </div>
                 {/* <div className="modal-body success-btm">
                     <button className="btn btn-white mr-2"
                        onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                     >View all submissions</button>
                     <button className="btn btn-white"
                        onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                     >Editor's Pick</button>
                 </div> */}
                 </div>
             </div>
             </div>
            </div>
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        latestPhotosList: state.FeatureParent.latestPhotos,
        latestVideos: state.FeatureParent.latestVideos
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getLatestVideos: (data) => dispatch(actions.getLatestVideosList(data)),
    }
};

const eventVideos = connect(
    mapStateToProps,
    mapDispatchToProps,
)(EventVideos);

export default eventVideos;



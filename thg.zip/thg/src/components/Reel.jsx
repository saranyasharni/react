import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import AdSense from 'react-adsense';
import Category from './ReelSection/Category'
import Documentary from './ReelSection/Documentary'
import MasterClass from './ReelSection/Master_Class'
import TopPicks from './ReelSection/Top_Picks'
import WebSeries from './ReelSection/Web_Series'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";


export default class Reel extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        this.props.updatePageNo({ flag: 1 });
        THIS.props.getTopPicksList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5, slug: 'top-picks' })
        THIS.props.getWebSeriesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: 'web-series' })
        THIS.props.getDocumentaryList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: 'documentaries' })
        THIS.props.getMasterClassList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 4, slug: 'master-class' })
        jQuery(document).ready(function () {
            window.$(".reel-nav").addClass("active");
            if (THIS.props.webSeriesList.length > 0 && THIS.props.documentaryList.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });

                window.$(".mscroll-y").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "outside"
                });

                window.$(".mscroll-y-inside").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "inside"
                });

            }
        });
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            window.$(".reel-nav").addClass("active");
            if (THIS.props.webSeriesList.length > 0 && THIS.props.documentaryList.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });

                window.$(".mscroll-y").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "outside"
                });

                window.$(".mscroll-y-inside").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "inside"
                });

            }

            if(THIS.props.archiveStatus === 1){
                jQuery('.archive .alert').html('<strong>No More Archive Articles Found</strong>');
                jQuery('.archive .alert').removeClass('alert-success').addClass('alert-danger')
                THIS.props.changeArchiveStatus(0);
                setTimeout(function () {
                    jQuery(".archive .alert").removeClass('alert-danger');
                }, 2000);
            }
        });
    }

    showMore(e) {
        e.preventDefault();
        this.props.updatePageNo({ flag: 0 });
        this.props.getNewMasterClassList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.archivePageNo + 1, limit: 4, slug: 'master-class' })
    }

    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>

                        {/* Category Section Starts here */}
                        <Category />
                        {/* Category Section Ends here */}

                        {/* Top Picks Starts here */}
                        <TopPicks />
                        {/* Top Picks Ends here */}
                        
                           
                            <UserAgentProvider
                    ua={ window.navigator.userAgent }
                    >
                    {/* <UserAgent tablet mobile>
                        <div className="ad_sze_up container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 288, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent> */}
                    <UserAgent windows mac>
                        <div className="ad_sze_up container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 1111, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent>
                    </UserAgentProvider>
                        {/* Web Series Starts here */}
                        <WebSeries />
                        {/* Web Series Ends here */}
                       
                           
                            <UserAgentProvider
                    ua={ window.navigator.userAgent }
                    >
                    {/* <UserAgent tablet mobile>
                        <div className="ad_sze container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 288, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent> */}
                    <UserAgent windows mac>
                        <div className="ad_sze container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 1111, height: 140, 
                                float: "left",
                                marginBottom:'23px'
                            } }
                            format=""
                        />
                        </div>
                    </UserAgent>
                    </UserAgentProvider>
                        {/* Documentary Starts here */}
                        <Documentary />
                        {/* Documentary Ends here */}

                        {/* ad will be place here */}
                    <section className="container-fluid my-5">
                    <div className="row">
                           
                          
                    <UserAgentProvider
                    ua={ window.navigator.userAgent }
                    >
                    {/* <UserAgent tablet mobile>
                        <div className="container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 288, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent> */}
                    <UserAgent windows mac>
                        <div className="container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 1111, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent>
                    </UserAgentProvider>
                            </div>
                        </section>
                        {/* ad will be place here */}

                        {/* Master Class Starts here */}
                        <MasterClass />
                        {/* Master Class Ends here */}

                        {/* Archive Button Starts here */}
                        {/* <div className="container text-center mb-5 archive">
                            <div className="alert" role="alert">
                            </div>
                            <button type="button" className="btn btn-green" onClick={(e) => this.showMore(e)}>
                                <img className="mr-2" src={process.env.PUBLIC_URL + "/assets/images/archive-icon.svg"} alt="icon" />
                            Archive
                            </button>
                        </div> */}
                        {/* Archive Button Ends here */}
                
                <UserAgentProvider
                    ua={ window.navigator.userAgent }
                    >
                    {/* <UserAgent tablet mobile>
                        <div className="container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 288, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent> */}
                    <UserAgent windows mac>
                        <div className="ad_sze container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 1111, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent>
                    </UserAgentProvider>

                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



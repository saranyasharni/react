import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import ArticleDetails from './VideoDetailSection/Article_Details'
import WebSeries from './VideoDetailSection/Web_Series'

export default class Video_Detail extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    var THIS = this;
    let search = (window.location.pathname).split('/')[2];
    THIS.props.getVideoArticleDetail({ user_id: 0, page_no: 0, limit: 12, slug: search })
    THIS.props.getLatestViideos({ user_id: 0, page_no: 0, limit: 12, slug: 'reel' })
  }

  componentWillReceiveProps(nextProps) {
    var THIS = this;
    if (nextProps.location !== this.props.location) {
      let searchParam = (nextProps.location.pathname).split('/')[2];
      THIS.props.getVideoArticleDetail({ user_id: 0, page_no: 0, limit: 12, slug: searchParam })
    }
  }


  render() {

    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>
            {
              /* Main Wrapper Starts here */
            }
            {/* Article Details Starts here */}
            <ArticleDetails />
            {/* Article Details Ends here */}

            {/* Web Series Starts here */}
            <WebSeries />
            {/* Web Series Ends here */}





          </Fragment>

          <Footer />
        </div>
      </div>
    )
  }
}



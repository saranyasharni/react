import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Reel_Category';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Latest_Web_Series extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="thg-tv four-grid container-fluid">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 col-12">
                                <h3 className="title">{`LATEST ${window.location.pathname.split('/')[2].replace('-', ' ').toUpperCase()}`}</h3>
                            </div>
                            <div className={this.props.reelBanner.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                                <h3 className="noarticle">No Articles</h3>
                            </div>
                            {
                                this.props.reelBanner.length > 0 &&
                                this.props.reelBanner.map((o, k) => {
                                    if (k === 0) {
                                        return <div className="col-md-6 col-12">
                                            <Link to={`/videodetail/${o.post_name}`} className="tv-wrap">
                                                {<img className="video-fluid tv-thumb lazyload" data-src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" />}
                                                {/* {(o.video_file === null) ? (o.video_link === '') ? <img class="video-fluid tv-thumb" src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid tv-thumb" src={o.video_link} frameborder="0" /> : <video className="tv-thumb" src={o.video_file} alt="video" style={{ maxWidth: '100%', height: 'auto' }} />} */}
                                                {/* <img
                                                    className="tv-thumb img-fluid"
                                                    src={process.env.PUBLIC_URL + "/assets/images/thg-thumb-big.jpg"}
                                                    alt="icon"
                                                /> */}
                                                <span className="art-cont">
                                                    <img
                                                        className="play-icon lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                        alt="icon"
                                                    />
                                                    <p>
                                                        {o.post_title}
                                                    </p>
                                                    <span className="date-time"><Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment></span>
                                                </span>
                                            </Link>
                                        </div>
                                    } else if (k === 1) {
                                        return <div className="col-md-6 col-12">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="row">
                                                        {this.props.reelBanner.map((m, l) => {
                                                            if (l === 1 || l === 2) {
                                                                return <div className="col-6">
                                                                    <Link to={`/videodetail/${m.post_name}`} className="tv-thumb-sm single-line-tle">
                                                                        <img className="video-fluid thumb lazyload" data-src={(m.thumbnail_image === "" || m.thumbnail_image === null || m.thumbnail_image === undefined) ? m.custom_feature_image_url : m.thumbnail_image} alt="image" />
                                                                        {/* {(m.video_file === null) ? (m.video_link === '') ? <img class="video-fluid thumb" src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={m.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={m.video_file} alt="video" />} */}
                                                                        <span className="art-cont">
                                                                            <p className="text-truncate">
                                                                                <img
                                                                                    className="play-icon lazyload"
                                                                                    data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                                    alt="icon"
                                                                                />
                                                                                {m.post_title}
                                                                            </p>
                                                                        </span>
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                    <div className="row">
                                                        {this.props.reelBanner.map((n, p) => {
                                                            if (p === 3 || p === 4) {
                                                                return <div className="col-6">
                                                                    <Link to={`/videodetail/${n.post_name}`} className="tv-thumb-sm single-line-tle">
                                                                        <img className="video-fluid thumb lazyload" data-src={(n.thumbnail_image === "" || n.thumbnail_image === null || n.thumbnail_image === undefined) ? n.custom_feature_image_url : n.thumbnail_image} alt="image" />
                                                                        {/* {(n.video_file === null) ? (n.video_link === '') ? <img class="video-fluid thumb" src={(n.custom_feature_image_url === "" || n.custom_feature_image_url === null || n.custom_feature_image_url === undefined) ? n.image_url : n.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={n.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={n.video_file} alt="video" />} */}
                                                                        <span className="art-cont">
                                                                            <p className="text-truncate">
                                                                                <img
                                                                                    className="play-icon lazyload"
                                                                                    data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                                    alt="icon"
                                                                                />
                                                                                {n.post_title}
                                                                            </p>
                                                                        </span>
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    }
                                })}
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        reelBanner: state.ReelCategory.reelBanner,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getReelChildBannerList: (data) => dispatch(actions.getReelChildBannerList(data)),
    }
};

const latestWebSeries = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Latest_Web_Series);

export default latestWebSeries;



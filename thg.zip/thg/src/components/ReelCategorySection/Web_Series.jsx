import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Reel_Category';
import * as headerActions from '../../actions/common/Header';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Web_Series extends Component {
    constructor(props) {
        super(props);
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.articleMoreStatus === 1) {
                jQuery('.article-list .alert').html('<strong>No More Articles Found</strong>');
                jQuery('.article-list .alert').removeClass('alert-success').addClass('alert-danger')
                THIS.props.changeArticleMoreStatus(0);
                setTimeout(function () {
                    jQuery(".article-list .alert").removeClass('alert-danger');
                }, 2000);
            }


        })


    }


    showMore(e) {
        e.preventDefault();
        var search = window.location.pathname.split('/')[2]
        this.props.updateReelArticlePageNo({ flag: 0 });
        this.props.getNewReelChildArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.reelArticlePageNo + 1, limit: 12, slug: search })
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        // var url = jQuery(e.target).closest(".article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        var url = jQuery(e.target).closest(".article-item").find('.art-background img').attr('src')
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
    }

    render() {

        return (

            <section className="container-fluid my-5">
                <div className="row">
                    <div className="container">
                        <h3 className="title">{window.location.pathname.split('/')[2].replace('-', ' ').toUpperCase()}</h3>
                        <div className={this.props.reelChildArticles.length > 0 ? 'd-none' : 'd-block'}>
                            <h3 className="noarticle">No Articles</h3>
                        </div>
                        <div className="row">
                            {
                                this.props.reelChildArticles.length > 0 &&
                                this.props.reelChildArticles.map((o, k) => {
                                    var cat_name = (o.cat_name).split(',');
                                    cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                    var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                    return <div className="col-md-3 mb-4" key={o.ID}>
                                        <div className="article-item video-snip">
                                            <Link to={`/videodetail/${o.post_name}`} className="art-img art-background"
                                                // style={{ backgroundImage: `url(${o.s3_thumbnail_image_260 !== null 
                                                //     ? o.s3_thumbnail_image_260 
                                                //     : o.thumbnail_image !== null
                                                //     ? o.thumbnail_image
                                                //     : o.custom_feature_image_url})` }}
                                            >
                                            
                                            {
                                                  jQuery(window).width() <= 767 ? (
                                                
                                                    <img src={
                                                        o.custom_feature_image_url !== null 
                                                            ? o.custom_feature_image_url 
                                                            : o.thumbnail_image 
                                                   } alt="img" 
                                                   />    
                                                ) : (
                                                    <img src={o.s3_thumbnail_image_260 !== null 
                                                        ? o.s3_thumbnail_image_260 
                                                        : o.thumbnail_image !== null
                                                        ? o.thumbnail_image
                                                        : o.custom_feature_image_url} alt="img" /> 
                                                    
                                                )
                                            }
                                                <span className="video-label">
                                                    <span>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"} alt="icon" />
                                        {o.video_duration ? parseFloat(o.video_duration).toFixed(2) : '00:00'}
                                        </span>
                                                </span>
                                            </Link>
                                            <div className="art-cont">
                                                <a href="javascript:;" className="favorite" data-id={o.ID} data-bucket-id={o.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                    onClick={(e) => {
                                                        this.bucketList(e)
                                                    }}>

                                                    <img className="outline lazyload" data-src={image} alt="icon" data-article-id={o.ID} />
                                                    <img
                                                        className="filled lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                        alt="icon"
                                                    />
                                                </a>
                                                <Link to={`/${o.post_name}`} className="art-title">
                                                    {o.post_title}
                                                </Link>
                                                <span className="date-time">
                                                    <Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                })
                            }
                            <div className="col-md-12 text-center article-list mt-4 mb-5">
                                <div className="alert" role="alert">
                                </div>
                                <button className="btn btn-orange" type="button" onClick={(e) => { this.showMore(e) }}>Show more</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        reelChildArticles: state.ReelCategory.reelChildArticles,
        reelArticlePageNo: state.ReelCategory.reelArticlePageNo,
        bucketItem: state.Header.bucketItem,
        articleMoreStatus: state.ReelCategory.articleMoreStatus,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getReelChildArticlesList: (data) => dispatch(actions.getReelChildArticlesList(data)),
        getNewReelChildArticlesList: (data) => dispatch(actions.getNewReelChildArticlesList(data)),
        updateReelArticlePageNo: (data) => dispatch(actions.updateReelArticlePageNo(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
        changeArticleMoreStatus: (data) => dispatch(actions.updateArticleMoreStatus(data)),
    }
};

const webSeries = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Web_Series);

export default webSeries;



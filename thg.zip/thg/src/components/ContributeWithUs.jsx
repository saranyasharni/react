import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import history from "../stores/history";
import ReactPhoneInput from "react-phone-input-2";
import 'react-phone-input-2/lib/style.css'

export default class ContributeWithUs extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.contributeStatus === 1) {
                THIS.props.resetContribute({
                    fullName: '',
                    email: '',
                    mobileNo: '',
                    companyAddress: '',
                    interestOfChoosing: '',
                    message: '',
                    contributeErrors: {}
                })
                jQuery('.advertise-forms .alert').html('<strong>Success!</strong> Contribute With Us Successfully.');
                jQuery('.advertise-forms .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".advertise-forms .alert").removeClass('alert-success');
                }, 2000);
                localStorage.setItem('contributor', true);
                THIS.props.updateContributeStatus(0);
                setTimeout(function () {
                    history.push('/')
                }, 1000);
            } else if (THIS.props.contributeStatus === 2) {
                jQuery('.advertise-forms .alert').html('<strong>Error!</strong> Failed To Contribute.');
                jQuery('.advertise-forms .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".advertise-forms .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateContributeStatus(0);
            }
        })
    }

    async contribute(event) {
        event.preventDefault();
        if (await this.validateContributeForm()) {
            this.props.createContribute({
                fullName: this.props.fullName,
                email: this.props.email,
                mobileNo: this.props.mobileNo,
                companyAddress: this.props.companyAddress,
                interest: this.props.interestOfChoosing,
                message: this.props.message,
                user_id: localStorage.getItem('user_id')
            })
        }

    }

    async validateContributeForm() {
        await this.props.resetContribute({
            contributeErrors: {}
        })
        let valid = true;
        let errors = this.props.contributeErrors;
        if (this.props.fullName == "" || this.props.fullName == null) {
            valid = false;
            errors.fullName = "please enter name"
        }
        if (this.props.email == "" || this.props.email == null) {
            valid = false;
            errors.email = "please enter mail"
        }
        if (!this.props.email == "") {
            if (!this.validateEmail(this.props.email)) {
              valid = false;
              errors.email = "please enter a valid email"
            }
          }
        if (this.props.mobileNo == "" || this.props.mobileNo == null) {
            valid = false;
            errors.mobileNo = "please enter mobile no"
        }
        if (this.props.companyAddress == "" || this.props.companyAddress == null) {
            valid = false;
            errors.companyAddress = "please enter company address"
        }
        if (this.props.interestOfChoosing == "" || this.props.interestOfChoosing == null) {
            valid = false;
            errors.interestOfChoosing = "please enter your interested categories"
        }
        if (this.props.message == "" || this.props.message == null) {
            valid = false;
            errors.message = "please leave message"
        }
        this.props.updateContributeErrors(errors);
        return valid;

    }

    validateEmail(email) {
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

        return expression.test(String(email).toLowerCase());
    }

    render() {

        return (


            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    <section
                        className="advertise-section relative"
                        style={{ paddingBottom: "1em!important", height: "75rem" }}
                    >
                        <div className="container">
                            <div className="row">
                                <div className="col-sm-6 contribute-bg" style={{ backgroundImage: `url(${process.env.PUBLIC_URL + "/assets/images/contribute-bg.jpg"})` }}></div>
                                <div className="col-sm-6 advertise-form ">
                                    <div className="white-bg-advertise">
                                        <h1 className="text-left">Contribute with us</h1>
                                    </div>
                                    <form className="advertise-forms">
                                        <div className="alert" role="alert">
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="examplename"
                                                value={(this.props.fullName) ? this.props.fullName : ''}

                                                onChange={e => {
                                                    if (e.target.value.match("^[a-zA-Z ]*$") != null) {
                                                        this.props.updateContributeInfo('fullName', e.target.value)
                                                    }
                                                }}
                                                placeholder="Fullname"
                                            />
                                            {(this.props.contributeErrors.fullName && this.props.contributeErrors.fullName.length > 0) ?
                                                < span className='text-danger'>{this.props.contributeErrors.fullName}</span> : ''}
                                            <i className="fa fa-user-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="exampleemail"
                                                value={(this.props.email) ? this.props.email : ''}
                                                onChange={e => this.props.updateContributeInfo('email', e.target.value)}
                                                placeholder="Email"
                                            />
                                            {(this.props.contributeErrors.email && this.props.contributeErrors.email.length > 0) ?
                                                < span className='text-danger'>{this.props.contributeErrors.email}</span> : ''}
                                            <i className="fa fa-envelope-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <ReactPhoneInput
                                                inputProps={{
                                                    name: 'phone'
                                                }}
                                                placeholder="Enter Phone Number"
                                                country={"sg"}
                                                value={(this.props.mobileNo) ? this.props.mobileNo : ''}
                                                onChange={phone => this.props.updateContributeInfo('mobileNo', phone)}
                                            />
                                            {(this.props.contributeErrors.mobileNo && this.props.contributeErrors.mobileNo.length > 0) ?
                                                < span className='text-danger'>{this.props.contributeErrors.mobileNo}</span> : ''}
                                            {/* <i className="fa fa-mobile" aria-hidden="true" /> */}
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="companyaddress"
                                                value={(this.props.companyAddress) ? this.props.companyAddress : ''}
                                                onChange={e => this.props.updateContributeInfo('companyAddress', e.target.value)}
                                                placeholder="Company Address"
                                            />
                                            {(this.props.contributeErrors.companyAddress && this.props.contributeErrors.companyAddress.length > 0) ?
                                                < span className='text-danger'>{this.props.contributeErrors.companyAddress}</span> : ''}
                                            <i className="fa fa-address-book-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="interest"
                                                value={(this.props.interestOfChoosing) ? this.props.interestOfChoosing : ''}
                                                onChange={e => this.props.updateContributeInfo('interestOfChoosing', e.target.value)}
                                                placeholder="Interest of Choosing"
                                            />
                                            {(this.props.contributeErrors.interestOfChoosing && this.props.contributeErrors.interestOfChoosing.length > 0) ?
                                                < span className='text-danger'>{this.props.contributeErrors.interestOfChoosing}</span> : ''}
                                            <i className="fa fa-adjust" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="message"
                                                value={(this.props.message) ? this.props.message : ''}
                                                onChange={e => this.props.updateContributeInfo('message', e.target.value)}
                                                placeholder="Message"
                                            />
                                            {(this.props.contributeErrors.message && this.props.contributeErrors.message.length > 0) ?
                                                < span className='text-danger'>{this.props.contributeErrors.message}</span> : ''}
                                            <i className="fa fa-comment-o" aria-hidden="true" />
                                        </div>
                                        <button
                                            type="button"
                                            className="btn btn-primary btn-block advertise-btn"
                                            onClick={e => this.contribute(e)}>
                                            SUBMIT
          </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>



                    <Footer />
                </div>
            </div >


        )
    }
}



import React, { Component, Fragment } from 'react'
import AdSense from 'react-adsense';
import jQuery from 'jquery'
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";
import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import { PageView, initGA, Event } from './../tracking';

import Category from './SubCategory/Category'
import FeaturedArticles from './SubCategory/Featured_Articles'
import ArticlesVideos from './SubCategory/Articles_Videos'
import LatestArticles from './SubCategory/Latest_Articles'
import PopularArticles from './SubCategory/Popular_Articles'

export default class SubCategory extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
      
    var search = window.location.pathname.split('/')[3]
    
    let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
    let subslug = search !== '' ? search : window.location.pathname.split('/')[2];
    
    this.props.updatePageNo({ flag: 1 });
    this.props.getCategoryList({ user_id: userid, slug: subslug, filter_cat_id: '', page_no: 0, limit: 9 });
    this.props.getFeaturedArticlesList({ user_id: userid, slug: subslug, filter_cat_id: '', page_no: 0, limit: 12 });
    this.props.getPopularArticlesList({ user_id: userid, slug: subslug, filter_cat_id: '', page_no: 0, limit: 6 });
    this.props.getHighLightsArticlesList({ user_id: userid, slug: 'highlights', filter_cat_id: '', page_no: 0, limit: 7 });
  // this.props.getSubCategoryList({ user_id: userid, slug: search, page_no: 0 });
    jQuery(document).ready(function () {
      window.jQuery(`.${window.location.pathname.split('/')[2]}-nav `).addClass("active");

      window.$(".mscroll-x").mCustomScrollbar({
        axis: "x",
        scrollEasing: "linear",
        scrollInertia: 300
      });

      window.$(".mscroll-y").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "outside"
      });

      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside"
      });

    });
  }

  componentDidUpdate() {
     // alert()
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.location !== this.props.location) {
      
      if (window.screen.width < 767) {
        window.jQuery('.navbar-toggler').click()
      }
      window.jQuery('.navbar-toggler').data('target', '');
      initGA('UA-173387540-1');
      PageView();
      let category = (nextProps.location.pathname).split('/')[2];
      let nextParam = (nextProps.location.pathname).split('/')[3];
      let prevParam = (this.props.location.pathname).split('/')[2];
      // console.log(nextParam, 'nextParam')
      // console.log(prevParam, 'prevParam')
      window.$(`.${category}-nav`).addClass("active");
      window.$(`.${prevParam}-nav`).removeClass("active");
      window.$(".cat-item").removeClass("active");
      localStorage.setItem('sub_cat', '')
      let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
      this.props.updatePageNo({ flag: 1 })
      this.props.getCategoryList({ user_id: userid, filter_cat_id: '', slug: nextParam, page_no: 0, limit: 9 });
      this.props.getFeaturedArticlesList({ user_id: userid, filter_cat_id: '', slug: nextParam, page_no: 0, limit: 12 });
      this.props.getPopularArticlesList({ user_id: userid, filter_cat_id: '', slug: nextParam, page_no: 0, limit: 6 });
      //this.props.getSubCategoryList({ user_id: userid, filter_cat_id: '', slug: nextParam, page_no: 0 });
      this.props.getHighLightsArticlesList({ user_id: userid, slug: 'highlights', filter_cat_id: '', page_no: 0, limit: 7 });
    }
  }

  componentWillUnmount() {
    localStorage.setItem('sub_cat', '')
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>

            {/* Category Section Starts here */}
            <Category />
            {/* Category Section Ends here */}

            {/* Latest Articles Starts here */}
            <LatestArticles />
            {/* Latest Articles Ends here */}
        
                      <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="1638754887"
                                style={{ width: 1100, height: 140, float: "left" }}
                                format=""
                            />
                        </div> 
            {/* Featured Articles Starts here */}
            <FeaturedArticles />
            {/* Featured Articles Ends here */}

            {/* Popular Articles Starts here */}
            <PopularArticles />
            {/* Popular Articles Ends here */}

            {/* Articles & Videos Starts here */}
            <ArticlesVideos />
            {/* Articles & Videos Ends here */}

            
            <UserAgentProvider
                                ua={window.navigator.userAgent}
                              >
                                <UserAgent tablet>
                                <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={{ width: 710, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                                </UserAgent>
                                <UserAgent mobile>
                                <div className="container mt-5">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={{ width: 328, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                                </UserAgent>
                                <UserAgent windows mac>
                                <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={{ width: 1111, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                                </UserAgent>

                                
                              </UserAgentProvider>
          </Fragment>

          <Footer />
        </div>
      </div>
    )
  }
}



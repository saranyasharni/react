import React, { Component, Fragment } from 'react'


export default class Category_Section extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="category-sec container-fluid mb-5">
                {/* parent-cat Starts here */}
                <div className="row parent-cat py-4">
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                                <a href="javascript:;" className="active">
                                    Sports Wear
                    <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;">
                                    Style
                    <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;">
                                    Gaming
                    <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;">
                                    Travel Insights
                    <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                {/* parent-cat Ends here */}
            </section>







        )
    }
}



import React, { Component, Fragment } from 'react'


export default class Review_Popular_Articles extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="container-fluid article-content">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 text-center mb-5">
                                <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"} alt="Ad" />
                            </div>
                            <div className="col-md-8">
                                <div className="row">
                                    <div className="col-12 mb-3">
                                        <div className="article-hero-img mb-3">
                                            <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/review-child-hero.jpg"}
                                                alt="image"
                                            />
                                        </div>
                                        <div className="article-head">
                                            <div className="tag-wrap">
                                                <span>Sports Wear</span>
                                                <span>Sports</span>
                                            </div>
                                            <div className="share-sec text-right">
                                                <button className>
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/heart-lg.svg"} alt="icon" />
                                                    <img
                                                        className="filled"
                                                        src={process.env.PUBLIC_URL + "/assets/images/heart-lg-filled.svg"}
                                                        alt="icon"
                                                    />
                                                </button>
                                                <button className="share">
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/share.svg"} alt="icon" />
                                                </button>
                                            </div>
                                            <h1 className="mt-4">
                                                Reprehenderit in voluptate velit esse cillum dolore eu
                                                fugiat nulla pariatur excepteur
                                        </h1>
                                            <span className="post-by">
                                                - Tyrone Williams (19 Mar 2020)
                                        </span>
                                        </div>
                                        <div className="article-content mt-4">
                                            <p>
                                                Incididunt ut labore et dolore magna aliqua. Ut enim ad
                                                minim veniam, quis nostrud exercitation ullamco laboris nisi
                                                ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                                                reprehenderit in voluptate velit esse cillum dolore eu
                                                fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                                proident, sunt in culpa qui officia deserunt mollit anim id
                                                est laborum.Sed ut perspiciatis unde omnis iste natus error
                                                sit voluptatem accusantium doloremque laudantium, totam rem
                                                aperiam, eaque ipsa quae ab illo inventore veritatis et
                                                quasi architecto beatae vitae dicta sunt explicabo. Nemo
                                                enim ipsam voluptatem quia voluptas sit aspernatur aut odit
                                                aut fugit, sed quia consequuntur magni dolores eos qui
                                                ratione voluptatem sequi nesciunt.
                                        </p>
                                            <p>
                                                Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                                amet, consectetur, adipisci velit, sed quia non numquam eius
                                                modi tempora incidunt ut labore et dolore magnam aliquam
                                                quaerat voluptatem. Ut enim ad minima veniam, quis nostrum
                                                exercitationem ullam corporis suscipit laboriosam, nisi ut
                                                aliquid ex ea commodi consequatur? Quis autem vel eum iure
                                                reprehenderit qui in ea voluptate velit esse quam nihil
                                                molestiae consequatur, vel illum qui dolorem eum fugiat quo
                                                voluptas nulla pariatur
                                        </p>
                                            <p className="font-weight-bold mb-2">Pros:</p>
                                            <ul className="list-unstyled pro-con mb-4">
                                                <li>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit
                                            </li>
                                                <li>
                                                    Sed do eiusmod tempor incididunt ut labore et dolore magna
                                                    aliqua
                                            </li>
                                                <li>
                                                    Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                                    laboris nisi
                                            </li>
                                                <li>
                                                    Excepteur sint occaecat cupidatat non proident, sunt in
                                                    culpa qui official
                                            </li>
                                                <li>
                                                    At vero eos et accusamus et iusto odio dignissimos ducimus
                                                    qui
                                            </li>
                                                <li>
                                                    Nam libero tempore, cum soluta nobis est eligendi optio
                                                    cumque nihil impedit quo minus
                                            </li>
                                                <li>
                                                    Placeat facere possimus, omnis voluptas assumenda est,
                                                    omnis dolor repellendus
                                            </li>
                                            </ul>
                                            <p className="font-weight-bold mb-2">Cons:</p>
                                            <ul className="list-unstyled pro-con">
                                                <li>
                                                    {" "}
                                            At vero eos et accusamus et iusto odio dignissimos ducimus
                                            qui
                                            </li>
                                                <li>
                                                    Nam libero tempore cum soluta nobis est eligendi optio
                                                    cumque nihil impedit quo minus id quod
                                            </li>
                                                <li>
                                                    Accusamus et iusto odio dignissimos ducimus qui blanditiis
                                                    praesentium voluptatum
                                            </li>
                                                <li>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                                    sed do eiusmod tempor incididunt
                                            </li>
                                                <li>
                                                    Duis aute irure dolor in reprehenderit in voluptate velit
                                                    esse cillum dolore eu fugiat nulla pariatur
                                            </li>
                                                <li>
                                                    Excepteur sint occaecat cupidatat non proident sunt in
                                                    culpa qui officia
                                            </li>
                                            </ul>
                                        </div>
                                        <div className="share-item mt-4 mb-5">
                                            <p>Overall Rating:</p>
                                            <ul className="list-inline rating-star">
                                                <li className="list-inline-item mr-0">
                                                    <a href="javascript:;" className="active">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                                <li className="list-inline-item mr-0">
                                                    <a href="javascript:;" className="active">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                                <li className="list-inline-item mr-0">
                                                    <a href="javascript:;" className="active">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                                <li className="list-inline-item mr-0">
                                                    <a href="javascript:;">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                                <li className="list-inline-item mr-0">
                                                    <a href="javascript:;">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="share-item mt-4">
                                            <p>Share this:</p>
                                            <ul className="list-inline">
                                                <li className="list-inline-item">
                                                    <a href="javascript:;">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/fb-icon.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                                <li className="list-inline-item">
                                                    <a href="javascript:;">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/insta-icon.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                                <li className="list-inline-item">
                                                    <a href="javascript:;">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/twitter-icon.svg"} alt="icon" />
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="post-nav btn-group mt-3">
                                            <button className="btn">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                            At vero eos et accusamus et iusto odio dignissimos dulory
                                            iutgiu
                                        </button>
                                            <button className="btn">
                                                Nam libero tempore, cum soluta nobis est eligendi optio
                                                soluta
                                            <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                            </button>
                                        </div>
                                        <hr className="my-5" />
                                        <div className="comment-wrap mb-5">
                                            <h4 className="mb-4">Rate &amp; Review</h4>
                                            <div className="mb-4">
                                                <ul className="list-inline rating-star">
                                                    <li className="list-inline-item mr-0">
                                                        <a href="javascript:;" className="active">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </a>
                                                    </li>
                                                    <li className="list-inline-item mr-0">
                                                        <a href="javascript:;" className="active">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </a>
                                                    </li>
                                                    <li className="list-inline-item mr-0">
                                                        <a href="javascript:;" className="active">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </a>
                                                    </li>
                                                    <li className="list-inline-item mr-0">
                                                        <a href="javascript:;">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </a>
                                                    </li>
                                                    <li className="list-inline-item mr-0">
                                                        <a href="javascript:;">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </a>
                                                    </li>
                                                </ul>
                                                <span className="review-range">Good</span>
                                            </div>
                                            <form className="add-comment mt-3 mb-5 text-right">
                                                <textarea
                                                    className="form-control"
                                                    rows={5}
                                                    placeholder="Write your review..."
                                                    defaultValue={""}
                                                />
                                                <button type="submit" className="btn btn-orange">
                                                    Submit
                                            </button>
                                            </form>
                                            <div className="comment-sec">
                                                <div className="comment mb-4">
                                                    <div className="avatar">
                                                        <img
                                                            className="img-fluid"
                                                            src={process.env.PUBLIC_URL + "/assets/images/avatar-3.png"}
                                                            alt="avatar"
                                                        />
                                                    </div>
                                                    <div className="comment-item">
                                                        <span className="name clearfix">Byron Craig</span>
                                                        <span className="badge badge-success">
                                                            4
                                                <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </span>
                                                        <p>
                                                            Lorem ipsum dolor sit amet, consectetur adipiscing
                                                            elit, sed do eiusmod tempor incididunt ut labore et
                                                            dolore magna aliqua. Ut enim ad minim veniam, quis
                                                            nostrud exercitation ullamco laboris nisi ut aliquip
                                                            ex ea commodo
                                                </p>
                                                        <a href="javascript:;" className="reply">
                                                            Reply
                                                </a>
                                                    </div>
                                                </div>
                                                <div className="comment mb-4">
                                                    <div className="avatar">
                                                        <img
                                                            className="img-fluid"
                                                            src={process.env.PUBLIC_URL + "/assets/images/avatar-1.png"}
                                                            alt="avatar"
                                                        />
                                                    </div>
                                                    <div className="comment-item">
                                                        <span className="name clearfix">Juan Matthews</span>
                                                        <span className="badge badge-warning">
                                                            2.5
                                                <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </span>
                                                        <p>
                                                            Neque porro quisquam est, qui dolorem ipsum quia dolor
                                                            sit amet, consectetur, adipisci velit, sed quia non
                                                            numquam eius modi tempora incidunt ut labore et dolore
                                                            magnam aliquam quaerat voluptatem.
                                                </p>
                                                        <a href="javascript:;" className="reply">
                                                            Reply
                                                </a>
                                                        <div className="child-comment mt-3">
                                                            <div className="avatar">
                                                                <img
                                                                    className="img-fluid"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/avatar-1.png"}
                                                                    alt="avatar"
                                                                />
                                                            </div>
                                                            <div className="comment-item">
                                                                <span className="name">Juan Matthews</span>
                                                                <p>
                                                                    Neque porro quisquam est, qui dolorem ipsum quia
                                                                    dolor sit amet, consectetur, adipisci velit, sed
                                                                    quia non numquam eius modi tempora incidunt ut
                                                                    labore et dolore magnam aliquam quaerat
                                                                    voluptatem.
                                                    </p>
                                                                <a href="javascript:;" className="reply">
                                                                    Reply
                                                    </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="comment mb-4">
                                                    <div className="avatar">
                                                        <img
                                                            className="img-fluid"
                                                            src={process.env.PUBLIC_URL + "/assets/images/avatar-3.png"}
                                                            alt="avatar"
                                                        />
                                                    </div>
                                                    <div className="comment-item">
                                                        <span className="name clearfix">Byron Craig</span>
                                                        <span className="badge badge-danger">
                                                            2
                                                <img src={process.env.PUBLIC_URL + "/assets/images/star-orange.svg"} alt="icon" />
                                                        </span>
                                                        <p>
                                                            Lorem ipsum dolor sit amet, consectetur adipiscing
                                                            elit, sed do eiusmod tempor incididunt ut labore et
                                                            dolore magna aliqua. Ut enim ad minim veniam, quis
                                                            nostrud exercitation ullamco laboris nisi ut aliquip
                                                            ex ea commodo
                                                </p>
                                                        <a href="javascript:;" className="reply">
                                                            Reply
                                                </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 d-none d-sm-block">
                                <div className="mb-5">
                                    <div className="col p-0">
                                        <h3 className="title">Related Articles</h3>
                                    </div>
                                    <div className="whats-happen high-light col p-0">
                                        <div className="wt-item-encl mscroll-y-inside">
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img1.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>
                                                        Lorem ipsum dolor sit amet, consectetur adipiscing eli..
                                            </p>
                                                </div>
                                            </a>
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img2.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>
                                                        Excepteur sint occaecat cupidatat non proident, su...
                                            </p>
                                                </div>
                                            </a>
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img3.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>
                                                        Sed ut perspiciatis unde omnis iste natus error sit
                                                        vo...
                                            </p>
                                                </div>
                                            </a>
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img1.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>Nemo enim ipsam voluptatem quia voluptas...</p>
                                                </div>
                                            </a>
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img2.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>
                                                        Quis autem vel eum iure reprehenderit qui in ea ptat...
                                            </p>
                                                </div>
                                            </a>
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img3.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>
                                                        Sed ut perspiciatis unde omnis iste natus error sit
                                                        vo...
                                            </p>
                                                </div>
                                            </a>
                                            <a href="javascript:;" className="wt-item">
                                                <div className="cal">
                                                    <img
                                                        className="img-fluid"
                                                        src={process.env.PUBLIC_URL + "/assets/images/thumb-img2.jpg"}
                                                        alt="img"
                                                    />
                                                </div>
                                                <div className="cal-cont">
                                                    <p>
                                                        Excepteur sint occaecat cupidatat non proident, su...
                                            </p>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-center">
                                    <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-ver.jpg"} alt="ad" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}



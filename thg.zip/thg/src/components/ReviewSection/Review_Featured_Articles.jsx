import React, { Component, Fragment } from 'react'


export default class Review_Featured_Articles extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="container-fluid bg-gray">
                <div className="row">
                    <div className="container">
                        <h3 className="title">Related Articles</h3>
                        <div className="snip-caurosel owl-carousel">
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img5.jpg"} alt="img" />
                                    <span className="video-label">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />
                                        12:32
                                    </span>
                                </a>
                                <div className="art-cont">
                                    <span className="tag">Cycling</span>
                                    <a href="javascript:;" className="favorite">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Lorem ipsum dolor sit amet, consectet ur adipiscing elit sed do
                                        eius modtem por incid
                                    </a>
                                    <span className="date-time">6 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img6.jpg"} alt="img" />
                                </a>
                                <div className="art-cont">
                                    <span className="tag">Travel</span>
                                    <a href="javascript:;" className="favorite active">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                        accusantium dolor emqu
                                    </a>
                                    <span className="date-time">11 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img7.jpg"} alt="img" />
                                    <span className="video-label">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />
                                        12:32
                                    </span>
                                </a>
                                <div className="art-cont">
                                    <span className="tag">MotorSports</span>
                                    <a href="javascript:;" className="favorite">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do
                                        eiusmod tempor incid
                                    </a>
                                    <span className="date-time">12 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img8.jpg"} alt="img" />
                                </a>
                                <div className="art-cont">
                                    <span className="tag">cycling</span>
                                    <a href="javascript:;" className="favorite active">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                        accusantium dolor emqu
                                    </a>
                                    <span className="date-time">14 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img5.jpg"} alt="img" />
                                </a>
                                <div className="art-cont">
                                    <span className="tag">Travel</span>
                                    <a href="javascript:;" className="favorite">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Lorem ipsum dolor sit amet, consectet ur adipiscing elit sed do
                                        eius modtem por incid
                                    </a>
                                    <span className="date-time">6 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img2.jpg"} alt="img" />
                                </a>
                                <div className="art-cont">
                                    <span className="tag">Running</span>
                                    <a href="javascript:;" className="favorite">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                        accusantium dolor emqu
                                    </a>
                                    <span className="date-time">11 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img1.jpg"} alt="img" />
                                </a>
                                <div className="art-cont">
                                    <span className="tag">Swimming</span>
                                    <a href="javascript:;" className="favorite active">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do
                                        eiusmod tempor incid
                                    </a>
                                    <span className="date-time">12 hours ago</span>
                                </div>
                            </div>
                            <div className="article-item">
                                <a href="javascript:;" className="art-img">
                                    <img src={process.env.PUBLIC_URL + "/assets/images/snip-img4.jpg"} alt="img" />
                                </a>
                                <div className="art-cont">
                                    <span className="tag">Basket Ball</span>
                                    <a href="javascript:;" className="favorite">
                                        <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                        <img
                                            className="filled"
                                            src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                            alt="icon"
                                        />
                                    </a>
                                    <a href="javascript:;" className="art-title">
                                        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                        accusantium dolor emqu
                                    </a>
                                    <span className="date-time">14 hours ago</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}



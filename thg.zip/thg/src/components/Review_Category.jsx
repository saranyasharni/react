import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import CategorySection from './ReviewSection/Category_Section'
import ReviewFeaturedArticles from './ReviewSection/Review_Featured_Articles'
import ReviewPopularArticles from './ReviewSection/Review_Popular_Articles'

export default class Review_Category extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    jQuery(document).ready(function () {
      window.$(".review-nav").addClass("active");
      window.$(".snip-caurosel").owlCarousel({
        items: 4,
        loop: false,
        dots: false,
        margin: 15,
        nav: true,
        responsive: {
          0: {
            items: 1
          },
          768: {
            items: 4
          }
        }
      });

      window.$(".mscroll-y").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "outside"
      });

      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside"
      });

    });
  }

  componentDidUpdate() {
    jQuery(document).ready(function () {
      window.$(".review-nav").addClass("active");
      window.$(".snip-caurosel").owlCarousel({
        items: 4,
        loop: false,
        dots: false,
        margin: 15,
        nav: true,
        responsive: {
          0: {
            items: 1
          },
          768: {
            items: 4
          }
        }
      });

      window.$(".mscroll-y").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "outside"
      });

      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside"
      });

    })
  }

  render() {

    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>
            {/* Category Section Starts here */}
            <CategorySection />
            {/* Category Section Ends here */}

            {/* Popular Articles Starts here */}
            <ReviewPopularArticles />
            {/* Popular Articles Ends here */}

            {/* Featured Articles Starts here */}
            <ReviewFeaturedArticles />
            {/* Featured Articles Ends here */}


          </Fragment>
          <Footer />
        </div>
      </div>
    )
  }
}
import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import $, { valHooks } from 'jquery';
import Footer from '../containers/common/Footer';
import config from '../actions/common/Api_Links';
import Header from '../containers/common/Header';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
function GiveAwayWinners() {
    let day = 1;
    const [item, setItem] = useState([]);
    useEffect(() => {
        $(document).ready(function(){
            window.$(".mscroll-x").mCustomScrollbar({
                axis:"x",
                scrollEasing:"linear",
                scrollInertia: 300
            });
    
            window.$(".mscroll-y-inside").mCustomScrollbar({
                axis:"y",
                scrollEasing:"linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });
          
            window.$('.winner-slider .owl-carousel').owlCarousel({
                items:1,
                loop:true,
                dots:false,
                nav:true
            });
          
    
        });
    
    });
    useEffect (() => {
        let formData = new URLSearchParams();    //formdata object
        
        formData.append('post_id', localStorage.getItem('cotest_slug'));
    
        fetch(config.get_giveaway_winners, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
      
        .then(res => res.json())
        .then(data => {
     
            setItem([]);
            if (data.status === 1) {
                setItem(data.result);
            } else {
                setItem([]);
            }
            
        });

    }, [])
    
    return (
    <>
        <Header />
        <>
        <section className="category-sec container-fluid bdr-btm">
            <div className="row parent-cat py-3">
            <div className="container">
                <h4>
                <a href="javascript:;" className="back">
                <Link to = {`/contestgiveaway/${localStorage.cotest_slug ? localStorage.getItem('cotest_slug'): ''}`}>
                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                </Link>
                </a>
                Giveaway Winners
                </h4>
            </div>
            </div>
        </section>
        {/* Category Section Ends here */}
        {/* Submission Section Starts here */}
        <section className="container-fluid mt-5 mb-5 min-h-vp winner-wrap">
            <div className="row">
            <div className="container">
            {
                item.length > 0 ? (
                <>
                 
                <h2>
                <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/award-icon.svg"} alt="icon" />
                Congratulations!
                </h2>
                </>
                ): (
                <>
                <h2>
                
                
                </h2>
                </>
                )
                }
                <div className="winner-slider">
                
                {
                    item.length > 0 && 
                    <div className="owl-carousel">
                    { item.length > 0 && 
                    item.map((o,k) => {
                    return (
                    <>
                    <div className="slide-item">
                    <div className="img-wrap"
                     style={{ backgroundImage: `url(${(o.image_url === "" || o.image_url === null || o.image_url === undefined) ? "" : o.image_url})`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat', height: '400px'}}
                    >
                    {/* <img className="img-fluid" src=
                    {
                        o.image_url ? o.image_url :process.env.PUBLIC_URL + "/assets/images/winner-photo.jpg"  
                    } 
                        alt="icon" /> */}
                    </div>
                    <div className="win-cont">
                    {/* <span className="day">Day {day++} </span>
                    {' '} */}
                    <h5><b>Winner of</b> {" "}<span className="won">{o.product_name}</span> </h5>
                    <br/>
                    <span className="name">{o.first_name}{' '}{o.last_name}</span>
                    <br/>    
                    <p>
                        {ReactHtmlParser(o.description ? o.description : '')}
                    </p>
                        
                    </div>
                    </div>
                    
                    </>
                    )
                    })    
                    }  
                  
                      </div>
                   
                    }
                </div>
                
            </div>
            </div>
        </section>
        {/* Giveaway Section Ends here */}
        </>
        <Footer />
        </>
    );
}

export default GiveAwayWinners;

import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import ArticleDetails from './ThgTvDetailSection/Article_Details'
import WebSeries from './ThgTvDetailSection/Web_Series'

export default class ThgTv_Detail extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        
        let programme_id = window.location.pathname.split('/')[3].split('&&&')[0]
        let event_id = window.location.pathname.split('/')[3].split('&&&')[1]
        this.props.getLikes({
            article_id:programme_id,
            user_id:localStorage.user_id ? localStorage.getItem('user_id'): 0
        })
        // console.log(programme_id, 'uiuiuiuiuiiuiui-0980879878')
        // console.log(event_id, 'uiuiuiuiuiiuiui-0980879878')
        var THIS = this;
        jQuery('.loader-pro').removeClass('d-none')
        jQuery('.loader-pro').addClass('d-block')
        const elem2 = document.createElement("script");
        elem2.type = "text/javascript"
        elem2.src =
            "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
        elem2.id = "player"
        elem2.async = false;
        elem2.onload = () => this.scriptLoaded(programme_id);
        //For head
        document.head.appendChild(elem2);
        
        // THIS.props.getStreamVideoArticleDetail({ 'programme_id': localStorage.getItem('programme_id') })
        THIS.props.getStreamVideoArticleDetail({
            'programme_id': programme_id, 'event_id': event_id 
        })
    }
    
    scriptLoaded(programmeID) {
        const _CONFIG = {
            divID: '#player-container',
            appID: '7386573047397500',
            autoPlay: true,
            config: 'espxplayer',
            applyModel: true,
            programme_id: programmeID,
            countdown: true,
            videoAlignment: 'center'
            // chatElement: '#chat-container' // Optional: To custom chat position, accept className or element ID
        }
        window.ESPxPlayer.createPlayer(_CONFIG).then((p) => {
            this.player = p;
            window.jQuery('#toggle-sharing svg').css('display', 'none')
            window.jQuery('#toggle-sharing').attr('title', '')
            window.jQuery('.data-share div').css('display', 'none')
            // var videoCusHeight = window.jQuery("#player-container video").height();
            // window.jQuery("#player-container").height(videoCusHeight);
            var screenWdth = jQuery(window).width();
            if (screenWdth <= 768) {
                setTimeout(() => {
                    p.listenTo(p, 'play', () => {
                        var videoCusHeight = window.jQuery("#player-container video").height();
                        console.log('inside ready', videoCusHeight)
                    });
                    var videoCusHeight = window.jQuery("#player-container video").height();
                    // console.log('videoCusHeight', videoCusHeight - 33)
                    let hgt =  Number(videoCusHeight) + 30
                    window.jQuery("#player-container").height(hgt);
                }, 500)
            }
        });
        jQuery('.loader-pro').removeClass('d-block')
        jQuery('.loader-pro').addClass('d-none')
    }

    componentWillUnmount() {
        var element = document.getElementById('player');
        if(element){
            element.parentNode.removeChild(element)
        }
        let player = window.ESPxPlayer.getPlayer();
        console.log('window.ESPxPlayer', player)

        if(player && player['_options']['parentId'] === "#player-container"){
            window.ESPxPlayer.destroyPlayer();
        }
    }

    componentWillReceiveProps(nextProps) {
        
        var THIS = this;
        let programme_id = window.location.pathname.split('/')[3].split('&&&')[0]
        let event_id = window.location.pathname.split('/')[3].split('&&&')[1]
        console.log(nextProps.location, 'nextProps.location')
        console.log(this.props.location, 'this.props.location')
        if (nextProps.location !== this.props.location) {
            // alert('came')
            this.props.getLikes({
                article_id:programme_id,
                user_id:localStorage.user_id ? localStorage.getItem('user_id'): 0
            })

            var element = document.getElementById('player');
            if (element) {
                element.parentNode.removeChild(element)
            }
            // console.log('window.ESPxPlayer', window.ESPxPlayer)
            if(window.ESPxPlayer){
                let player = window.ESPxPlayer.getPlayer();
                // console.log('window.ESPxPlayer', player)
                if(player && player['_options']['parentId'] === "#player-container"){
                    window.ESPxPlayer.destroyPlayer();
                }
            }

            // var element = document.getElementById('player')
            // if(element){
            //     element.parentNode.removeChild(element)
            // }
            // window.ESPxPlayer.destroyPlayer();
            jQuery('.loader-pro').removeClass('d-none')
            jQuery('.loader-pro').addClass('d-block')
            const elem2 = document.createElement("script");
            elem2.type = "text/javascript"
            elem2.src =
                "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
            elem2.id = "player"
            elem2.async = false;
            elem2.onload = () => this.scriptLoaded(programme_id);
            //For head
            document.head.appendChild(elem2);
            THIS.props.getStreamVideoArticleDetail({
                'programme_id': programme_id, 'event_id': event_id 
            })
            
        }
    }


    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {
                            /* Main Wrapper Starts here */
                        }
                        {/* Article Details Starts here */}
                        <ArticleDetails />
                        {/* Article Details Ends here */}

                        {/* Web Series Starts here */}
                        <WebSeries />
                        {/* Web Series Ends here */}

                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



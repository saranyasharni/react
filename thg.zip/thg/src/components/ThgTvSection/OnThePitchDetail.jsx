import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import history from "../../stores/history";
import ReactHtmlParser, {
    processNodes,
    convertNodeToElement,
    htmlparser2,
  } from "react-html-parser";
import * as sportsActions from '../../actions/Sports';
import Header from '../../containers/common/Header'
import Footer from '../../containers/common/Footer'
import { connect } from 'react-redux'
import * as actions from '../../actions/THGTV';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class OnThePitchDetail extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.updatePageNo({ flag: 1 });
        this.props.getOnThePitchList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 8, slug: 'on-the-pitch' })
        
    }
    componentDidMount() {
        jQuery(".btn-orange").click(function(){
            jQuery(this).addClass('d-none');     
        });
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.archiveStatus === 0) {
                jQuery('.alert').html('<strong>No More Videos to show</strong>');
                jQuery('.alert').removeClass('alert-success').addClass('alert-danger')
                jQuery('.btn-orange').removeClass('d-none')
                jQuery(".btn-orange").addClass('d-inblock')
                THIS.props.changeArchiveStatus(0)
                setTimeout(function () {
                    jQuery(".alert").removeClass('alert-danger');
                }, 2000);
                
            } 
            if (THIS.props.show_hide === 1) {
                jQuery('.btn-orange').removeClass('d-none')
                jQuery(".btn-orange").addClass('d-inblock')
                THIS.props.showHide(0);
            }
        })
    }
    showMore(e) {
        e.preventDefault();
        this.props.updatePageNo({ flag: 0 });
        this.props.getNewOnThePitchList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.archivePageNo + 1, limit: 4, slug: 'on-the-pitch' })
    }
    render() {

        return (
            <>
            <div className="container-fluid">
                <div className="row">
                <Header />
                <section className="category-sec container-fluid bdr-btm">
                        <div className="row parent-cat py-3">
                        <div className="container">
                            {/* { console.log(items, '5555555555')} */}
                            <h4>
                            <a href="javascript:;" className="back">
                            <Link 
                            onClick={() => 
                            history.goBack()
                            }
                            >
                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                            </Link>
                            </a>
                            On The Pitch
                            </h4>
                        </div>
                        </div>
                    </section>
                {
                    //console.log(this.props.onThePitchList, 'onThePitchList')
                }
                <section className="container-fluid ">
                    <div className="row">
                        <div className="container">
                        <div className="col-12 text-center mb-5"></div> 
   
                        
                        <div className="row h-50">
                        <div className={this.props.onThePitchList.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                        
                            <h3 className="noarticle">No Articles</h3>
                            <div className="col-12 text-center mb-20"></div>   
                        <div className="col-12 text-center mb-10"></div>   
                        <div className="col-12 text-center mb-10"></div>   
                        <div className="col-12 text-center mb-90"></div>   
                        </div>
                            {
                                this.props.onThePitchList &&
                                this.props.onThePitchList.length > 0 &&
                                this.props.onThePitchList.map((i,k) => {
                                    return (
                                        <div 
                                        key = {i.ID}
                                        className="col-md-3 mb-4"
                                        >
                                        <div className="article-item video-snip">
                                            <a 
                                            href={`videodetail/${i.post_name}`} 
                                            className="art-img">
                                            <img 
                                            src={i.thumbnail_image ? i.thumbnail_image : i.custom_feature_image_url}  
                                            alt="img" />
                                            <span className="video-label">
                                                <span>
                                                <img src={process.env.PUBLIC_URL+"/assets/images/video-play-filled.svg"} alt="icon" />
                                                {/* 12:32 */}
                                                </span>
                                            </span>
                                            </a>
                                            <div className="art-cont">
                                            
                                                <Link to={`videodetail/${i.post_name}`} className="art-title">
                                                    {ReactHtmlParser(i.post_content ? i.post_content: '')}
                                                </Link>
                                                <span className="date-time">
                                                    <Moment format='DD MMM YYYY'>{i.date_publish}</Moment>
                                                </span>
                                            </div>
                                        </div>
                                        </div>
                                    )
                                })
                            }
                            
                            <div className={this.props.onThePitchList &&
                                this.props.onThePitchList.length > 0 ? "col-md-12 text-center mt-4 mb-3 d-block": "col-md-12 text-center mt-4 mb-3 d-none"}>
                                <div className="alert" role="alert">
                                </div>
                                <button className="btn btn-orange"
                                onClick={(e) => this.showMore(e)}
                                >
                                
                                Show more</button>
                            </div>
                        </div>
                        </div>
                    </div>
                </section>
                <Footer />
                </div>
            </div>
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        programmesList: state.THGTV.programmesList,
        show_hide: state.THGTV.show_hide,
        onThePitchList: state.THGTV.onThePitchList,
        archiveStatus: state.THGTV.archiveStatus,
        archivePageNo: state.THGTV.archivePageNo,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
        getOnThePitchList: (data) => dispatch(actions.getOnThePitchList(data)),
        getNewOnThePitchList: (data) => dispatch(actions.getMoreOnThePitchList(data)),
        showHide: (data) => dispatch(actions.show_hide(data)),
        changeArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data)),
    }
};

const onThePitch = connect(
    mapStateToProps,
    mapDispatchToProps,
)(OnThePitchDetail);

export default onThePitch;



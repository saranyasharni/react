import React, { Component, Fragment } from 'react'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class Live_Stream extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="live-stream container-fluid">
                <div className="loader-pro d-none" style={{ marginLeft: '52%', marginRight: '42%' }}>

                    <img
                        className="img-fluid lazyload"
                        data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                        alt="Avatar"
                    />
                </div>
                <div className="row">
                    <div 
                    id="player-container"
                    style={{ width: '100%', height: '506px', maxWidth: '100%' }}
                    >
                    {/* <iframe 
                    id="iframe-player-container"
                    frameborder="0" scrolling="no" espx-fullscreen allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" 
                    src="https://widgets.espx.cloud/embed/f66c1523-76eb-4ac0-b672-53fa4553ed7a?app_id=7386573047397500" 
                    
                    width="100%" height="100%"
                    >

                    </iframe> */}
                    </div>
                </div>
            </section>

        )
    }
}



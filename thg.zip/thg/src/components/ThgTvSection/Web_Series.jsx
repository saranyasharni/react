import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/THGTV';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Web_Series extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        THIS.props.getVideoStreamApi();

        jQuery(document).ready(function () {
            // jQuery(".article-item span").click(function () {
            //     console.log('iteeee',jQuery(this).find('.art-img'))
            //     // jQuery(this).siblings(".title").attr("contenteditable", "true");
            // });
        })
    }

    render() {

        return (

            <section className="container-fluid mt-0 mb-5">
                <div className="row">
                    <div className="container">
                        <h3 className="title">Livestreams &amp; Videos</h3>
                        <div className="row">
                            {
                                this.props.programmesList.length > 0 &&
                                this.props.programmesList.map((o, k) => {
                                    return <div className="col-md-3 mb-4" key={o.id}>
                                        <div className="article-item video-snip" data-id={o.id}>
                                            <Link to={`/episodes/${o.base_name}/${o.id}`} className="art-img art-background"
                                                style={{ backgroundImage: `url(${o.img_url})` }}
                                                onClick={(e) => {
                                                    localStorage.setItem('event_id', jQuery(e.target).closest('.article-item').data('id'))
                                                }}>
                                                {/* <img src={o.img_url} alt="img" /> */}
                                                <span className="video-label">
                                                    <span>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"} alt="icon" />
                                                        {/* 12:32 */}
                                                    </span>
                                                </span>
                                            </Link>
                                            <div className="art-cont">
                                                {/* <a href="javascript:;" className="favorite">
                                                    <img className="outline" src={process.env.PUBLIC_URL + "/assets/images/heart.svg"} alt="icon" />
                                                    <img
                                                        className="filled"
                                                        src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                        alt="icon"
                                                    />
                                                </a> */}
                                                <Link to={`/episodes/${o.base_name}/${o.id}`} className="art-title"
                                                    onClick={(e) => {
                                                        localStorage.setItem('event_id', jQuery(e.target).closest('.article-item').data('id'))
                                                    }}>
                                                    {o.name}
                                                </Link>
                                                <span className="date-time">
                                                    <Moment format='DD MMM YYYY'>{o.date_publish}</Moment>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                })}
                            {/* <div className="col-md-12 text-center mt-4 mb-3">
                                <button className="btn btn-orange">Show more</button>
                            </div> */}
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        programmesList: state.THGTV.programmesList,
        programmeStreamList: state.THGTV.programmeStreamList,
        programme_id: state.THGTV.programme_id
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getVideoStreamApi: () => dispatch(actions.getVideoStraming()),
        updateProgrammeId: (data) => dispatch(actions.changeProgrammeId(data))
    }
};

const webSeries = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Web_Series);

export default webSeries;



import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/THGTV';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class On_The_Pitch extends Component {
    constructor(props) {
        super(props);
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            // if (THIS.props.archiveStatus === 1) {
            //     var element = window.jQuery('.cloning-element').clone()
            //     console.log('clone', THIS.props.archiveStatus)
            //     jQuery(element).removeClass('d-none')
            //     jQuery(element).removeClass('cloning-element')
            //     window.jQuery('.main-element').last().append(element)
            //     THIS.props.changeArchiveStatus(0)
            // }
        })
    }

    render() {

        return (

            <section className="thg-tv four-grid container-fluid">
                <div className="row">
                    <div className="container main-element">
                        <div className="row">
                            <div className="col-md-12 col-12">
                                <h3 className="title">
                                    On the Pitch
                                    <a href="/onthepitch">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                    </a>
                                </h3>
                            </div>
                        </div>
                        <div className="row">
                            <div className={this.props.onThePitchList.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                                <h3 className="noarticle">No Articles</h3>
                            </div>
                            {
                                this.props.onThePitchList.length > 0 &&
                                this.props.onThePitchList.map((o, k) => {
                                    if (k === 0) {
                                        return <div className="col-md-6 col-12">
                                            <Link to={`/videodetail/${o.post_name}`} className="tv-wrap">
                                                {<img className="video-fluid tv-thumb lazyload" data-src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" />}
                                                <span className="art-cont">
                                                    <img
                                                        className="play-icon lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                        alt="icon"
                                                    />
                                                    <p>
                                                        {o.post_title}
                                                    </p>
                                                    <span className="date-time"><Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment></span>
                                                </span>
                                            </Link>
                                        </div>
                                    }
                                })}
                            <div className="col-md-6 col-12">
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="row">
                                            {this.props.onThePitchList.map((m, l) => {
                                                if (l === 1 || l === 2) {
                                                    return <div className="col-6">
                                                        <Link to={`/videodetail/${m.post_name}`} className="tv-thumb-sm single-line-tle">
                                                            <img className="video-fluid thumb lazyload" data-src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="image" />
                                                            {/* {(m.video_file === null) ? (m.video_link === '') ? <img class="video-fluid thumb" src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={m.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={m.video_file} alt="video" />} */}
                                                            {/* <video
                                                                            className="video-fluid thumb"
                                                                            src={m.video_file}
                                                                            alt="image"
                                                                        /> */}
                                                            <span className="art-cont">
                                                                <p className="text-truncate">
                                                                    <img
                                                                        className="play-icon lazyload"
                                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                        alt="icon"
                                                                    />
                                                                    {m.post_title}
                                                                </p>
                                                            </span>
                                                        </Link>
                                                    </div>
                                                }

                                            })}
                                        </div>
                                        <div className="row">
                                            {this.props.onThePitchList.map((n, p) => {
                                                if (p === 3 || p === 4) {
                                                    return <div className="col-6">
                                                        <Link to={`/videodetail/${n.post_name}`} className="tv-thumb-sm single-line-tle">
                                                            <img className="video-fluid thumb lazyload" data-src={(n.custom_feature_image_url === "" || n.custom_feature_image_url === null || n.custom_feature_image_url === undefined) ? n.image_url : n.custom_feature_image_url} alt="image" />
                                                            {/* {(n.video_file === null) ? (n.video_link === '') ? <img class="video-fluid thumb" src={(n.custom_feature_image_url === "" || n.custom_feature_image_url === null || n.custom_feature_image_url === undefined) ? n.image_url : n.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={n.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={n.video_file} alt="video" />} */}
                                                            {/* <video
                                                                            className="video-fluid thumb"
                                                                            src={n.video_file}
                                                                            alt="image"
                                                                        /> */}
                                                            <span className="art-cont">
                                                                <p className="text-truncate">
                                                                    <img
                                                                        className="play-icon lazyload"
                                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                        alt="icon"
                                                                    />
                                                                    {n.post_title}
                                                                </p>
                                                            </span>
                                                        </Link>
                                                    </div>
                                                }

                                            })}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row d-none cloning-element">
                            {
                                this.props.onThePitchList.length > 0 &&
                                this.props.onThePitchList.map((o, k) => {
                                    // console.log('page', this.props.archivePageNo)
                                    if (k === (this.props.archivePageNo * 5)) {
                                        return <div className="col-md-6 col-12">
                                            <Link to={`/videodetail/${o.post_name}`} className="tv-wrap">
                                                {<img className="video-fluid tv-thumb lazyload" data-src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" />}
                                                <span className="art-cont">
                                                    <img
                                                        className="play-icon lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                        alt="icon"
                                                    />
                                                    <p>
                                                        {o.post_title}
                                                    </p>
                                                    <span className="date-time"><Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment></span>
                                                </span>
                                            </Link>
                                        </div>
                                    }
                                })}
                            <div className="col-md-6 col-12">
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="row">
                                            {this.props.onThePitchList.map((m, l) => {
                                                if (l === (this.props.archivePageNo * 5) + 1 || l === (this.props.archivePageNo * 5) + 2) {
                                                    return <div className="col-6">
                                                        <Link to={`/videodetail/${m.post_name}`} className="tv-thumb-sm">
                                                            <img className="video-fluid thumb lazyload" data-src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="image" />
                                                            {/* {(m.video_file === null) ? (m.video_link === '') ? <img class="video-fluid thumb" src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={m.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={m.video_file} alt="video" />} */}
                                                            {/* <video
                                                                            className="video-fluid thumb"
                                                                            src={m.video_file}
                                                                            alt="image"
                                                                        /> */}
                                                            <span className="art-cont">
                                                                <p className="text-truncate">
                                                                    <img
                                                                        className="play-icon lazyload"
                                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                        alt="icon"
                                                                    />
                                                                    {m.post_title}
                                                                </p>
                                                            </span>
                                                        </Link>
                                                    </div>
                                                }

                                            })}
                                        </div>
                                        <div className="row">
                                            {this.props.onThePitchList.map((n, p) => {
                                                if (p === (this.props.archivePageNo * 5) + 3 || p === (this.props.archivePageNo * 5) + 4) {
                                                    return <div className="col-6">
                                                        <Link to={`/videodetail/${n.post_name}`} className="tv-thumb-sm">
                                                            <img className="video-fluid thumb lazyload" data-src={(n.custom_feature_image_url === "" || n.custom_feature_image_url === null || n.custom_feature_image_url === undefined) ? n.image_url : n.custom_feature_image_url} alt="image" />
                                                            {/* {(n.video_file === null) ? (n.video_link === '') ? <img class="video-fluid thumb" src={(n.custom_feature_image_url === "" || n.custom_feature_image_url === null || n.custom_feature_image_url === undefined) ? n.image_url : n.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={n.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={n.video_file} alt="video" />} */}
                                                            {/* <video
                                                                            className="video-fluid thumb"
                                                                            src={n.video_file}
                                                                            alt="image"
                                                                        /> */}
                                                            <span className="art-cont">
                                                                <p className="text-truncate">
                                                                    <img
                                                                        className="play-icon lazyload"
                                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                        alt="icon"
                                                                    />
                                                                    {n.post_title}
                                                                </p>
                                                            </span>
                                                        </Link>
                                                    </div>
                                                }

                                            })}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        programmesList: state.THGTV.programmesList,
        onThePitchList: state.THGTV.onThePitchList,
        archiveStatus: state.THGTV.archiveStatus,
        archivePageNo: state.THGTV.archivePageNo,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getOnThePitchList: (data) => dispatch(actions.getOnThePitchList(data)),
        changeArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data)),
    }
};

const onThePitch = connect(
    mapStateToProps,
    mapDispatchToProps,
)(On_The_Pitch);

export default onThePitch;



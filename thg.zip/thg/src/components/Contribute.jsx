import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import { Link } from 'react-router-dom';

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';

import history from "../stores/history";

export default class Contribute extends Component {
    constructor(props) {
        super(props);
    }
    componentWillMount() {
		// this.props.getQuickLinks()
		// this.props.getAdvertiseWithUs('advertise-with-us')
		
		//this.props.getPrivacyData('privacy-policy')
		// this.props.getReachUs('reach-us')
		this.props.getContribute('contribute')
	}
    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Main Wrapper Starts here */}


                        {/* Coach Listing Starts here */}
                        <section className="container-fluid mt-5">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-12 text-center mb-5">
                                            {/* <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            /> */}
                                        </div>
                                        <div className="col-md-12">
                                            <h3 className="title">{ this.props.contribute[0] ? 
                                            this.props.contribute[0].post_title : ''}</h3>
                                            <div className="row">
                                                <div className="col-md-8 fp-content">
                                                {
                                                    this.props.contribute.length > 0 &&
                                                    this.props.contribute.map((o, k) => {
                                                    var content = o.post_content;
                                                    // content = content.replace(/&nbsp;/g, '<p></p>');
                                                    content = content.replace(/\r\n/g,'<p></p>');
                                                    return <p>
                                                    {ReactHtmlParser(content)}

                                                    </p>
                                                    })
                                                }
                                                    {/* <p>We immerse ourselves in communities based on 5 guiding principles:</p>
                                                    <ol>
                                                        <li>To keep our ears close to the ground and provide balanced reporting</li>
                                                        <li>Embrace every point of view in order to help readers generate their own opinions and understanding</li>
                                                        <li>Bring live experiences to the community</li>
                                                        <li>Create original content that sparks conversations</li>
                                                        <li>We investigate and ask the necessary questions to better explain stories</li>
                                                    </ol>
                                                    <p>&nbsp;</p>
                                                    <p>&nbsp;</p>
                                                    <p>&nbsp;</p>
                                                    <p>&nbsp;</p> */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {/* Coach Listing Ends here */}



                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Feature_Category';
import * as headerActions from '../../actions/common/Header';


class Web_Series extends Component {
    constructor(props) {
        super(props);
    }

    showMore(e) {
        e.preventDefault();
        var search = window.location.pathname.split('/')[2]
        this.props.updateReelArticlePageNo({ flag: 0 });
        this.props.getNewReelChildArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.reelArticlePageNo + 1, limit: 16, slug: search })
    }

    render() {

        return (

            <section className="container-fluid my-5">
                <div className="row">
                    <div className="container">
                        <h3 className="title">{window.location.pathname.split('/')[2].replace('-', ' ').toUpperCase()}</h3>
                        <div className="row">
                            {
                                this.props.reelChildArticles.length > 0 &&
                                this.props.reelChildArticles.map((o, k) => {
                                    var cat_name = (o.cat_name).split(',');
                                    cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                    var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                    return <div className="col-md-3 mb-4" key={o.ID}>
                                        <div className="article-item video-snip">
                                            <Link to={`/videodetail/${o.post_name}`} className="art-img art-background"
                                                style={{ backgroundImage: `url(${(o.custom_feature_image_url === undefined || o.custom_feature_image_url === null || o.custom_feature_image_url === '') ? o.image_url : o.custom_feature_image_url})` }}>
                                                <span className="video-label">
                                                    <span>
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"} alt="icon" />
                                        12:32
                                        </span>
                                                </span>
                                            </Link>
                                            <div className="art-cont">
                                                <a href="javascript:;" className="favorite" data-id={o.ID} data-bucket-id={o.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                    onClick={(e) => {
                                                        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').data('id'))
                                                        this.props.changeBucketItem('bucket_id', jQuery(e.target).closest('.favorite').data('bucket-id'))
                                                    }}>

                                                    <img className="outline" src={image} alt="icon" data-article-id={o.ID} />
                                                    <img
                                                        className="filled"
                                                        src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                        alt="icon"
                                                    />
                                                </a>
                                                <Link to={`/${o.post_name}`} className="art-title">
                                                    {o.post_title}
                                                </Link>
                                                <span className="date-time">
                                                    <Moment fromNow>{o.post_date_gmt}</Moment>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                })
                            }
                            <div className="col-md-12 text-center mt-4 mb-5">
                                <button className="btn btn-orange" type="button" onClick={(e) => { this.showMore(e) }}>Show more</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        reelChildArticles: state.FeatureCategory.reelChildArticles,
        reelArticlePageNo: state.FeatureCategory.reelArticlePageNo,
        bucketItem: state.Header.bucketItem,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getReelChildArticlesList: (data) => dispatch(actions.getReelChildArticlesList(data)),
        getNewReelChildArticlesList: (data) => dispatch(actions.getNewReelChildArticlesList(data)),
        updateReelArticlePageNo: (data) => dispatch(actions.updateReelArticlePageNo(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    }
};

const webSeries = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Web_Series);

export default webSeries;



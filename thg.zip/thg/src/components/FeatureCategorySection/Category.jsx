import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";


export default class Category extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="category-sec container-fluid">
                {/* parent-cat Starts here */}
                <div className="row parent-cat py-4 rgt-btn">
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                            <Link to={`/feature-event/news`} className="news-cat">
                                    News
                <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/feature-event/schedule`} className="schedule-cat">
                                    Schedule
                <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/feature-event/photos`} className="photos-cat">
                                    Photos
                <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/feature-event/videos`} className="videos-cat">
                                    Videos
                <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/feature-event/ticket`} className="ticket-cat">
                                    Ticketing
                <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                        </ul>
                        <button className="btn btn-orange d-none d-sm-none d-md-block">
                            <img className="mr-2" src={process.env.PUBLIC_URL + "/assets/images/ticket-icon.svg"} alt="icon" />
            Purchase Tickets
          </button>
                    </div>
                </div>
                {/* parent-cat Ends here */}
            </section>








        )
    }
}



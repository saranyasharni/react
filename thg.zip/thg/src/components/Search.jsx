import React, { Component, Fragment } from 'react'

import jQuery from 'jquery';

import { Link } from 'react-router-dom';

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class Search extends Component {
    constructor(props) {
        super(props);
    }

    searchArticles(e) {
        e.preventDefault();
        // console.log(e.target.value.length, 'e.target.length')
        this.props.changeSearchTerm({ searchTerm: e.target.value });
        if (e.target.value.length >= 3) {
            this.props.fetchSearchArticlesList({ search_term: e.target.value })
        }  
        
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        var url = jQuery(e.target).closest(".article-item").find('.art-background img').attr('src')
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
    }

    onFormSubmit = e => {
        e.preventDefault();
        window.jQuery('.search-bt').attr('disabled', true)
        this.props.fetchSearchArticlesList({ search_term: this.props.searchTerm })
    }

    componentWillUnmount() {
        this.props.changeSearchTerm({ searchTerm: '' });
        this.props.changeSearchArticles([])
    }

    componentDidMount() {
        document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
    }
    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        <section className="container-fluid hero-banner search-banner mb-3 mb-sm-4">
                            <div className="row">
                                <img
                                    className="img-fluid search-bannerIMG lazyload"
                                    data-src={process.env.PUBLIC_URL + "/assets/images/search-banner.jpg"}
                                    alt="image"
                                />
                                <div className="hero-cont">
                                    <div className="container text-center">
                                        <h1>Browse All Topics</h1>
                                        <span className="tagline">
                                            {/* Lorem ipsum dolor sit amet consectetur adipiscing elit */}
                                        </span>
                                        <form className="search-form" onSubmit = {this.onFormSubmit}>
                                            <div className="form-group mb-0">
                                                <input
                                                    placeholder="Search here..."
                                                    type="text"
                                                    className="form-control"
                                                    name
                                                    onChange={(e) => {
                                                      
                                                        this.searchArticles(e)
                                                    }}
                                                />
                                                <button type="submit" className="btn btn-orange submit search-bt">Search</button>
                                            </div>
                                        </form>
                                        <span className={this.props.searchTerm ? "tagline search-key d-block" : "tagline search-key d-none"}>
                                            {this.props.searchList.length} Results for <strong>{this.props.searchTerm}</strong>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {
                            /* Search Results Starts here */
                        }
                        <section className="container-fluid mt-2 mb-5 pb-3">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-12">
                                            <h3 className="title search">
                                                Search Results
                                                {/* <span className="keyword">{this.props.searchTerm}</span> */}
                                            </h3>
                                        </div>
                                        <div className={this.props.searchList.length > 0 ? 'd-none' : 'col-12 d-block'}>
                                            <h3 className="noarticle">No Articles</h3>
                                        </div>
                                        <div className="col-12">
                                            <div className="row">
                                                {
                                                    this.props.searchList.length > 0 &&
                                                    this.props.searchList.map((o, k) => {
                                                        var cat_name = (o.cat_name).split(',');
                                                        cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                                        var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                                        return <div className="col-lg-3 col-md-4 col-12 mb-4">
                                                            <div className="article-item" key={o.ID}>
                                                                <Link to={`/${o.post_name}`} className="art-img art-background"
                                                                // style={{ backgroundImage: `url(${(o.s3_thumbnail_image_260 !== null && o.s3_thumbnail_image_260 !== undefined)
                                                                // ? o.s3_thumbnail_image_260 
                                                                // : o.thumbnail_image !== null
                                                                // ? o.thumbnail_image
                                                                // : o.custom_feature_image_url})` }}
                                                                >
                                                                {
                                                                    jQuery(window).width() <= 767 ? (
                                                                        <img src={
                                                                                o.custom_feature_image_url !== null 
                                                                                ? o.custom_feature_image_url 
                                                                                : o.thumbnail_image 
                                                                            }
                                                                            alt="img" 
                                                                            />
                                                                        ): (
                                                                            <img src={(o.s3_thumbnail_image_260 !== null && o.s3_thumbnail_image_260 !== undefined)
                                                                            ? o.s3_thumbnail_image_260 
                                                                            : o.thumbnail_image !== null
                                                                            ? o.thumbnail_image
                                                                            : o.custom_feature_image_url} alt="img" />
                                                                        )
                                                                }
                                                                
                                                                </Link>
                                                                
                                                                <div className="art-cont">
                                                                    <Link to={`/category/${(o.cat_name).split(',')[0].toLowerCase()}`}>
                                                                        <span className="tag">{cat_name}</span>
                                                                    </Link>
                                                                    <a
                                                                        href="javascript:;"
                                                                        className="favorite"
                                                                        data-id={o.ID}
                                                                        data-bucket-id={o.bucket_id}
                                                                        data-toggle="modal"
                                                                        data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                                        onClick={(e) => {
                                                                            this.bucketList(e)
                                                                        }}
                                                                    >
                                                                        <img
                                                                            className="outline lazyload"
                                                                            data-src={image}
                                                                            alt="icon"
                                                                            data-article-id={o.ID}
                                                                        />
                                                                        <img
                                                                            className="filled lazyload"
                                                                            data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                            alt="icon"
                                                                        />
                                                                    </a>
                                                                    <Link to={`/${o.post_name}`} className="art-title">
                                                                        {o.post_title}
                                                                    </Link>
                                                                    <span className="date-time">
                                                                        {/* <Moment fromNow>{o.post_date_gmt}</Moment> */}
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    })
                                                }
                                                {/* <div className="col-lg-3 col-md-4 col-12 mb-4">
                                                    <div className="article-item">
                                                        <a href="javascript:;" className="art-img">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/snip-img3.jpg"} alt="img" />
                                                        </a>
                                                        <div className="art-cont">
                                                            <span className="tag">Travel</span>
                                                            <a
                                                                href="javascript:;"
                                                                className="favorite"
                                                                data-toggle="modal"
                                                                data-target="#bucket-list"
                                                            >
                                                                <img
                                                                    className="outline"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart.svg"}
                                                                    alt="icon"
                                                                />
                                                                <img
                                                                    className="filled"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                    alt="icon"
                                                                />
                                                            </a>
                                                            <a href="javascript:;" className="art-title">
                                                                Lorem ipsum dolor sit amet, consectet ur adipiscing elit sed
                                                                do eius modtem por incid
                  </a>
                                                            <span className="date-time">6 hours ago</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3 col-md-4 col-12 mb-4">
                                                    <div className="article-item">
                                                        <a href="javascript:;" className="art-img">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/snip-img2.jpg"} alt="img" />
                                                        </a>
                                                        <div className="art-cont">
                                                            <span className="tag">Running</span>
                                                            <a
                                                                href="javascript:;"
                                                                className="favorite active"
                                                                data-toggle="modal"
                                                                data-target="#remove-article"
                                                            >
                                                                <img
                                                                    className="outline"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart.svg"}
                                                                    alt="icon"
                                                                />
                                                                <img
                                                                    className="filled"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                    alt="icon"
                                                                />
                                                            </a>
                                                            <a href="javascript:;" className="art-title">
                                                                Sed ut perspiciatis unde omnis iste natus error sit
                                                                voluptatem accusantium dolor emqu
                  </a>
                                                            <span className="date-time">11 hours ago</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3 col-md-4 col-12 mb-4">
                                                    <div className="article-item">
                                                        <a href="javascript:;" className="art-img">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/snip-img1.jpg"} alt="img" />
                                                        </a>
                                                        <div className="art-cont">
                                                            <span className="tag">Swimming</span>
                                                            <a href="javascript:;" className="favorite">
                                                                <img
                                                                    className="outline"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart.svg"}
                                                                    alt="icon"
                                                                />
                                                                <img
                                                                    className="filled"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                    alt="icon"
                                                                />
                                                            </a>
                                                            <a href="javascript:;" className="art-title">
                                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit sed
                                                                do eiusmod tempor incid
                  </a>
                                                            <span className="date-time">12 hours ago</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3 col-md-4 col-12 mb-4">
                                                    <div className="article-item">
                                                        <a href="javascript:;" className="art-img">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/snip-img4.jpg"} alt="img" />
                                                        </a>
                                                        <div className="art-cont">
                                                            <span className="tag">Basket Ball</span>
                                                            <a href="javascript:;" className="favorite active">
                                                                <img
                                                                    className="outline"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart.svg"}
                                                                    alt="icon"
                                                                />
                                                                <img
                                                                    className="filled"
                                                                    src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                    alt="icon"
                                                                />
                                                            </a>
                                                            <a href="javascript:;" className="art-title">
                                                                Sed ut perspiciatis unde omnis iste natus error sit
                                                                voluptatem accusantium dolor emqu
                  </a>
                                                            <span className="date-time">14 hours ago</span>
                                                        </div>
                                                    </div>
                                                </div> */}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {
                            /* Search Results Ends here */
                        }



                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



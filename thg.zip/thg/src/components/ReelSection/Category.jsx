import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class Category extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="category-sec container-fluid mb-5">
                {/* parent-cat Starts here */}
                <div className="row parent-cat py-4">
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                                <Link to={`/reel/top-picks`}>
                                    Top Picks
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/reel/web-series`}>
                                    Web Series
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/reel/documentaries`}>
                                    Documentaries
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                            <li className="list-inline-item">
                                <Link to={`/reel/master-class`}>
                                    Master Class
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>
                {/* parent-cat Ends here */}
            </section>







        )
    }
}



import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Reel';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Top_Picks extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="thg-tv four-grid container-fluid">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 col-12">
                                <h3 className="title">
                                    Top Picks
                                    <Link to={`/reel/top-picks`}>
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                    </Link>
                                </h3>
                            </div>
                            <div className={this.props.topPicksList.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                                <h3 className="noarticle">No Articles</h3>
                            </div>
                            {
                                this.props.topPicksList.length > 0 &&
                                this.props.topPicksList.map((o, k) => {
                                    if (k === 0) {
                                        return <div className="col-md-6 col-12">
                                            <Link to={`/videodetail/${o.post_name}`} className="tv-wrap">
                                                {<img className="img-fluid tv-thumb lazyload" data-src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" />}
                                                {/* {(o.video_file === null) ? (o.video_link === '') ? <img class="img-fluid tv-thumb" src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid tv-thumb" src={o.video_link} frameborder="0" /> : <video className="tv-thumb" src={o.video_file} alt="video" style={{ maxWidth: '100%', height: 'auto' }} />} */}
                                                {/* {(o.video_file === '' || o.video_file === null || o.video_file === undefined) ? <img
                                                    className="tv-thumb img-fluid"
                                                    src={(o.custom_feature_image_url === undefined || o.custom_feature_image_url === null || o.custom_feature_image_url === '') ? o.image_url : o.custom_feature_image_url}
                                                    alt="icon"
                                                /> : <video
                                                        className="tv-thumb"
                                                        src={o.video_file}
                                                        alt="image"
                                                        style={{ maxWidth: '100%', height: 'auto' }}
                                                    />} */}


                                                <span className="art-cont">
                                                    <img
                                                        className="play-icon lazyload"
                                                        data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                        alt="icon"
                                                    />
                                                    <p>
                                                        {o.post_title}
                                                    </p>
                                                    <span className="date-time"><Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment></span>
                                                </span>
                                            </Link>
                                        </div>
                                    } else if (k === 1) {
                                        return <div className="col-md-6 col-12">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="row">
                                                        {this.props.topPicksList.map((m, l) => {
                                                            if (l === 1 || l === 2) {
                                                                return <div className="col-6">
                                                                    <Link to={`/videodetail/${m.post_name}`} className="tv-thumb-sm single-line-tle">
                                                                        {<img className="video-fluid thumb lazyload" data-src={(m.thumbnail_image === "" || m.thumbnail_image === null || m.thumbnail_image === undefined) ? m.custom_feature_image_url : m.thumbnail_image} alt="image" />}
                                                                        {/* {(m.video_file === null) ? (m.video_link === '') ? <img class="video-fluid thumb" src={(m.custom_feature_image_url === "" || m.custom_feature_image_url === null || m.custom_feature_image_url === undefined) ? m.image_url : m.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={m.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={m.video_file} alt="video" />} */}
                                                                        {/* {(m.video_file === '' || m.video_file === null || m.video_file === undefined) ? <img
                                                                            className="tv-thumb img-fluid"
                                                                            src={(m.custom_feature_image_url === undefined || m.custom_feature_image_url === null || m.custom_feature_image_url === '') ? m.image_url : m.custom_feature_image_url}
                                                                            alt="icon"
                                                                        /> : <video
                                                                                className="tv-thumb"
                                                                                src={m.video_file}
                                                                                alt="image"
                                                                                style={{ maxWidth: '100%', height: 'auto' }}
                                                                            />} */}
                                                                        <span className="art-cont">
                                                                            <p className="text-truncate">
                                                                                <img
                                                                                    className="play-icon lazyload"
                                                                                    data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                                    alt="icon"
                                                                                />
                                                                                {m.post_title}
                                                                            </p>
                                                                        </span>
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                    <div className="row">
                                                        {this.props.topPicksList.map((n, p) => {
                                                            if (p === 3 || p === 4) {
                                                                return <div className="col-6">
                                                                    <Link to={`/videodetail/${n.post_name}`} className="tv-thumb-sm 
                                                                    single-line-tle
                                                                    ">
                                                                        {<img className="video-fluid thumb lazyload" data-src={(n.thumbnail_image === "" || n.thumbnail_image === null || n.thumbnail_image === undefined) ? n.custom_feature_image_url : n.thumbnail_image} alt="image" />}
                                                                        {/* {(n.video_file === null) ? (n.video_link === '') ? <img class="video-fluid thumb" src={(n.custom_feature_image_url === "" || n.custom_feature_image_url === null || n.custom_feature_image_url === undefined) ? n.image_url : n.custom_feature_image_url} alt="image" /> : <iframe className="video-fluid thumb" src={n.video_link} frameborder="0" /> : <video className="video-fluid thumb" src={n.video_file} alt="video" />} */}
                                                                        <span className="art-cont">
                                                                            <p className="text-truncate">
                                                                                <img
                                                                                    className="play-icon lazyload"
                                                                                    data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"}
                                                                                    alt="icon"
                                                                                />
                                                                                {n.post_title}
                                                                            </p>
                                                                        </span>
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    }
                                })}
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        topPicksList: state.Reel.topPicksList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getTopPicksList: (data) => dispatch(actions.getTopPicksList(data)),
    }
};

const topPicks = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Top_Picks);

export default topPicks;



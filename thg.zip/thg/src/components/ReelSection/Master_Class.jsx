import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import Moment from 'react-moment';
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Reel';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Master_Class extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="container-fluid bg-gray my-5">
                <div className="row">
                    <div className="container">
                        <h3 className="title">
                            Master Class
                            <Link to={`/reel/master-class`}>
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                            </Link>
                        </h3>
                        <div className={this.props.masterClassList.length > 0 ? 'd-none' : 'd-block'}>
                            <h3 className="noarticle">No Articles</h3>
                        </div>
                        <div className="row">
                            {
                                this.props.masterClassList.length > 0 &&
                                this.props.masterClassList.map((o, k) => {
                                    return <div className="col-md-6" key={o.ID}>
                                        <div className="master-wrap">
                                            <div className="master-img">
                                            {
                                            jQuery(window).width() <= 767 ? (
                                            <img src={
                                                    o.custom_feature_image_url !== null 
                                                        ? o.custom_feature_image_url 
                                                        : o.thumbnail_image 
                                                } 
                                                style={{ width: '100%', height: '240px' }}
                                                alt="img" 
                                                />
                                            ): (
                                                <img
                                                    className="lazyload"
                                                    data-src={o.s3_thumbnail_image_260 !== null 
                                                    ? o.s3_thumbnail_image_260 
                                                    : o.thumbnail_image !== null
                                                    ? o.thumbnail_image
                                                    : o.custom_feature_image_url}
                                                    alt="image"
                                                    style={{ width: '100%', height: '240px' }}
                                                />
                                            )
                                            }
                                                
                                            </div>
                                            <div className="master-cont">
                                                <div className="w-100">
                                                    <Link to={`/videodetail/${o.post_name}`}>
                                                        <span className="name d-block text-truncate">
                                                            {o.post_title}
                                                        </span></Link>
                                                    <span className="occup d-block text-truncate">
                                                        Teaches Acting
                                            </span>
                                                </div>
                                                <p>
                                                    {ReactHtmlParser(o.post_content)}
                                                </p>
                                                <Link to={`/videodetail/${o.post_name}`} className="btn btn-orange">Watch Videos</Link>
                                            </div>
                                        </div>
                                    </div>
                                })}
                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    console.log('state', state)
    return {
        masterClassList: state.Reel.masterClassList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getMasterClassList: (data) => dispatch(actions.getMasterClassList(data)),
    }
};

const masterClass = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Master_Class);

export default masterClass;




import React, { Component, Fragment, useCallback } from 'react';
import $, { valHooks } from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import Footer from '../containers/common/Footer';
import Header from '../containers/common/Header';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import Tippy from '@tippy.js/react'
import 'tippy.js/dist/tippy.css'
import Dropzone from 'react-dropzone'
class Submit extends Component {
    
    componentWillMount() {
        this.props.getProfileDetail({ user_id: localStorage.getItem('user_id') })
        this.props.getContestDetail({ slug: localStorage.getItem('cotest_slug') })
    }

    componentDidMount() {
        
        let THIS = this;
        $(document).ready(function () {
           // window.$('.btn-orange').prop('disabled', true);
            window.jQuery('.input-group.date').datepicker({
                    format: "dd/mm/yyyy",
                    endDate: "+0d"
            }).off('change').change((e) => { THIS.props.changeInput("dob", e.target.value); THIS.handleChange(e) });

            window.$(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300
            });

            window.$(".mscroll-y-inside").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });
        });
    }
    componentDidUpdate() {
        var THIS = this;
        $(document).ready(function () {
            window.$('.input-group.date').datepicker({ format: "dd/mm/yyyy" });
           // window.$('.btn-orange').prop('disabled', true);
            if (THIS.props.contestStatus === 1) {
                //THIS.props.contest_email : '' 
                THIS.props.resetForm({
                    contest_email:'',
                    first_name:'',
                    last_name:'',
                    monthly_income:'',
                    imageUrl:'',
                    dob:'',
                    photos_desc:'',
                    mobile_no:'',
                    contest_occupation:'',
                    errors : {},
                })
                $('#accept').prop("checked", false);
                $('.form-control').val('')
                $('.upload_icon_contest').removeClass('d-none')
                $('.upload_icon_contest').addClass('d-inblock')
                $('.upload-drag').find('.thumb_image').attr('src', '')
                $('.upload-drag').find('.thumb_image').removeClass('d-block')
                $('.upload-drag').find('.thumb_image').addClass('d-none')
                $('.upload-drag').find('.thumb_video').attr('src', '')
                $('.upload-drag').find('.thumb_video').removeClass('d-inblock')
                $('.upload-drag').find('.thumb_video').addClass('d-none')
                //window.jQuery('#success-pop').modal('show')
                setTimeout(function () {
                    $("#give-away-form .alert").removeClass('alert-success');
                }, 2000);
                setTimeout(function () {
                    window.$('#submit-entry').modal('hide')
                }, 2000);
                THIS.props.updateContestStatus(0);

            } 
        })
    }

    handleDropzone (files) {
        let errors = this.props.errors;
        if (files) {
            let compareFile = files[0].size / 1024 / 1024
            // console.log(compareFile, "videoFiles")
            if (compareFile > 10.2) {
                errors.imageUrl = 'Please Upload less than 10MB';
                this.props.updateErrors(errors);
            } else {
                var filetype = files[0].type;
                let type = filetype.split('/')[0]
                $('.upload-drag').addClass('d-none')
                $('.contest-loader-pro').addClass('d-block')
                $('.contest-loader-pro').removeClass('d-none')
                $('#contestfile').off('click');
                errors.imageUrl = '';
                this.props.updateErrors(errors);
                this.props.uploadImage({ upload_file: files[0], typeFile: type})
            }
        }
    }
    handleChange(event) { 
    //console.log(event.target.name, 'nameOF')
        let errors = this.props.errors;
        let valid = true;
        const target = event.target;
        const value = target.value ;
        const name = target.name;
    
        this.setState({
          [name]: value
        });
    
        switch (name) {
            case 'first_name':
                valid = false;
                errors.first_name = (value.length === null)? 'Please enter your first name': '';
                this.props.updateErrors(errors);
            break;
            case 'photos_desc':
                valid = false;
              //  console.log(value.length, 'value of Desc90')
                errors.photos_desc = (value.length >= 400)? 'Please keep your description within 400 characters with spaces': '';
                this.props.updateErrors(errors);
            break;
            case 'monthly_income':
                valid = false;
                errors.monthly_income = (value.length === null)? 'Please enter your monthly income': '';
                this.props.updateErrors(errors);
            break;
            case 'last_name':
                valid = false;
                errors.last_name = (value.length === null)? 'Please enter your last name': '';
                this.props.updateErrors(errors);
            break;
            case 'email':
                valid = false;
                errors.contest_email = (value.length === null)? 'Plese enter your mail': '';
                this.props.updateErrors(errors);
            break;
        
            case 'mobile_no':
                valid = false;
                errors.mobile_no = (value.length !== null && value.length < 8)? 'Mobile number must be more than 8 digits': '';
                this.props.updateErrors(errors);
            break; 
            case 'date_of_birth':
                errors.date_of_birth = (value.length === null)? 'Please enter your dob' : '';
                this.props.updateErrors(errors);
            break; 
            case 'occupation':
                errors.occupation = (value.length === null)? 'Please enter your occupation' : '';
                this.props.updateErrors(errors);
            break; 
            case 'accept':
                errors.terms = (event.target.checked === false)? 'Please accept the terms and conditions to participate' : '';
                this.props.updateErrors(errors);
            break; 
            default:
                this.props.updateErrors(errors);
            break;
            }
      }

    submitEntry(e) {
        console.log(this.props.contest_email, 'this.props.email')
        e.preventDefault();
        if (this.validateForm()) {
            
        this.props.createSubmitEntry({
            
            user_id: localStorage.getItem('user_id'),
            contest_id: this.props.contestDetail[0].ID,
            contest_name: this.props.contestDetail[0].post_title,
            image_url: this.props.imageUrl,
            first_name: this.props.first_name,
            last_name:this.props.last_name,
            dob:this.props.dob,
            email:this.props.contest_email,
            mobile_no:this.props.mobile_no,
            occupation:this.props.contest_occupation,
            monthly_income:this.props.monthly_income,
            photos_desc:this.props.photos_desc,
            type:this.props.fileType
        })
       }
    }

    validateForm() {
        let valid = true;
        let errors = this.props.errors;
        if (this.props.imageUrl == "") {
            errors.imageUrl = "Please upload a photograph or video file to proceed."
            //this.props.updateContestStatus(3);
            valid = false;
        }
        if (this.props.first_name == '') {
            errors.first_name = "Please enter your first name"
            valid = false;
        }
        if (this.props.photos_desc === '') {
            errors.photos_desc = "Please enter your description of photo"
            valid = false;
        }
        if (this.props.photos_desc !== '') {
            if (this.props.photos_desc.length >= 400) {
                errors.photos_desc = 'Please keep your description within 400 characters with spaces'
                valid = false;
            }
            
        }

        if (this.props.last_name == '') {
            errors.last_name = "Please enter your last name"
            valid = false;
        
        }
        
        if (this.props.mobile_no.length < 8) {
            errors.mobile_no = "Mobile number must be more than 8 digits"
            valid = false;
        }

        if (this.props.mobile_no === '') {
            errors.mobile_no = "Please enter your mobile number"
            valid = false;
        }
        
        if (this.props.dob == '') {
            errors.date_of_birth = "Please enter your date of birth"
            valid = false;
        
        }
        if (this.props.contest_email === '') {
            errors.contest_email = "Plese enter your email"
            valid = false;
        }
        if (!this.props.contest_email == "") {
            if (!this.validateEmail(this.props.contest_email)) {
              valid = false;
              errors.contest_email = "please enter a valid email";
            }
        }
        if (this.props.contest_occupation === '') {
            errors.occupation = "Please enter your occupation"
            valid = false;
        }
        if (this.props.monthly_income === '') {
            errors.monthly_income = "Please enter your monthly income"
            valid = false;
        }
        // if (this.props.monthly_income === '') {
        //     errors.monthly_income = "Cannot be empty"
        //     valid = false;
        // }
        if ($('#accept').is(":checked") === false) {
            errors.terms = "Please accept the terms and conditions to participate"
            valid = false;
        }
        this.props.updateErrors(errors);
        return valid;
        
    }
    validateEmail(email) {
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    
        return expression.test(String(email).toLowerCase());
      }
    

    render() {
        
        
        return (
            <div class="container-fluid">
                <div className="row">
                    <Header />
                    <Fragment>
                    <section className="category-sec container-fluid">
                        <div className="row parent-cat py-3">
                            <div className="container">
                            <h4>
						    <a href="/contest" className="back">
							<img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
						    </a>    
                            {this.props.contestDetail.length > 0 &&
                            this.props.contestDetail[0].post_title
                            }
					        </h4>
                            </div>
                        </div>
                    </section>

                    <section className="container-fluid hero-banner mb-3 mb-sm-4">
                        {
                        //console.log(this.props.contestDetail, 'this.props.contestDetail'),
                        this.props.contestDetail.length > 0 &&
                            this.props.contestDetail.map((o, k) => {
                                return <div className="row"
                                style={{ backgroundImage: `url(${(o.custom_feat_image_url === "" || o.custom_feat_image_url === null || o.custom_feat_image_url === undefined) ? "" : o.custom_feat_image_url})`, backgroundSize: 'cover', backgroundPositionX: '50%', backgroundPositionY: 'center', backgroundRepeat: 'no-repeat', height: '500px'}}
                                >
                                    {/* <img 
                                    className="img-fluid w-100" src={(o.custom_feat_image_url === undefined || o.custom_feat_image_url === null || o.custom_feat_image_url === "") ? o.image_url : o.custom_feat_image_url} alt="image"
                                    style={{ width: "100%" }} /> */}
                                    <div className="hero-cont">
                                        <div className="container">
                                            <div className="row">
                                                <div className="col-lg-9 col-md-8">
                                                    <h1>{o.post_title}</h1>
                                                </div>
                                                {/* <div className="col-lg-3 col-md-4 book-tic text-right">
                                                    <button
                                                        className="btn btn-orange"
                                                        data-toggle="modal"
                                                        data-target="#submit-entry"
                                                    >
                                                        Submit Entry
        </button>
                                                </div> */}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            })}
                    </section>
                {
                    /* Hero Banner Ends here */
                }
                {
                    /* contestsubmt Section Starts here */
                }
                <section className="container-fluid mt-2 mb-5">
                <div className="row">
                    <div className="container contest-detail">
                    <div className="row mt-3">
                        <div className="col-md-8">
                        <div className="row">
                        <div className="col-12 wt-detail-cont">
                            <div className="head-contest mb-2">
                                <img
                                    className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-icon.svg"}
                                    alt="icon"
                                />
                                <Moment 
                                format="DD MMM YYYY" withTitle>
                                {
                                this.props.contestDetail.length > 0 && this.props.contestDetail[0].start_date !== undefined
                                ? this.props.contestDetail[0].start_date: new Date()
                                } 
                                
                                </Moment> 
                                {'  -  '}
                                <Moment 
                                format="DD MMM YYYY " withTitle>
                                {
                                this.props.contestDetail.length > 0 && this.props.contestDetail[0].end_date !== undefined
                                ? this.props.contestDetail[0].end_date: new Date()
                                }
                                </Moment> 
                                
                            </div>
                            
                            </div>
                            <div className="col-12 mt-4 contest_desc">
                            <p>
                            {this.props.contestDetail.length > 0 &&
                            this.props.contestDetail.map((o, k) => {
                                var content = o.post_content;
                                // content = content.replace(/&nbsp;/g, '<p></p>');
                                content = content.replace(/\r\n/g,'<p></p>');
                                content = content.replace('','<p></p>');

                                return <p>
                                {ReactHtmlParser(content)}

                                </p>
                            })}
                            </p>
                            </div>
                            <div className="col-12 mt-0">
            {/* {ReactHtmlParser(this.props.contestDetail.length > 0 ? this.props.contestDetail[0].post_content : 'post_content') } */}
                            <Link to = "/all-submissions">
                            <button className="btn btn-white mr-2">View all Submissions</button>
                            </Link>
                            <Link to = "/editors-pick">
                            <button className="btn btn-white mr-2">Editor's Pick</button>
                            </Link>

                            {this.props.contestDetail.length > 0 && this.props.contestDetail[0].winnersCount >= 1 &&
                            <Link to = "/contest-winner">
                            <button className="btn btn-white">Winners</button>
                            </Link>
                            }
                            
                            </div>
                            
                            <div className="col-12 mt-3">
                            <h5>Your Details</h5>
                            <form className="contest-form row">
                                <div className="col-md-6 form-group">
                                <div className="input-group">
                                    <input
                                    type="text"
                                    className="form-control"
                                    placeholder="First Name"
                                    name = "first_name"
                                    onChange={(e) => {
                                            
                                        this.props.changeInput(   
                                        "first_name", e.target.value)
                                        this.handleChange(e);
                                    
                                    
                                    }}
                                    
                                    />
                                    <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Last Name"
                                    name = "last_name"
                                    onChange={(e) => {
                                            
                                        this.props.changeInput(   
                                        "last_name", e.target.value)
                                        this.handleChange(e);
                                    
                                    }}
                                    
                                    />
                                
                                </div>
                                {
                                this.props.errors.first_name &&
                                this.props.errors.first_name.length > 0 ? (
                                <span className="text-danger">
                                    {this.props.errors.first_name}
                                </span>
                                ) : (
                                ""
                                                                    ) }
                                                            {<br></br>}
                                {
                                this.props.errors.last_name &&
                                this.props.errors.last_name.length > 0 ? (
                                <span 
                                
                                className="text-danger">
                                    {this.props.errors.last_name}
                                </span>
                                ) : (
                                ""
                                )}
                                </div>
                                <div className="col-md-6 form-group">
                                <div
                                    className="input-group date mar-t-no"
                                    data-date-format="dd/mm/yyyy"
                                >
                                <input
                                type="text"
                                className="form-control"
                                
                                placeholder= "Date of Birth"
                                />
                                <div className="input-group-addon">
                                <img src={process.env.PUBLIC_URL + "/assets/images/calendar-icon.svg"} alt="icon" />
                                </div>
                                    
                                </div>
                                {this.props.errors.date_of_birth &&
                                    this.props.errors.date_of_birth.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.date_of_birth}
                                    </span>
                                    ) : (
                                    ""
                                )}
                                </div>
                                <div className="col-md-6 form-group">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Email"
                                    name = "email"
                                    onChange={(e) => {
                                            
                                        this.props.changeInput(   
                                        "contest_email", e.target.value)
                                        this.handleChange(e);
                                    
                                    
                                    }}
                                    
                                />
                                    {this.props.errors.contest_email &&
                                    this.props.errors.contest_email.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.contest_email}
                                    </span>
                                    ) : (
                                    ""
                                    )}
                                </div>
                                <div className="col-md-6 form-group">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Mobile Number"
                                    name = "mobile_no"
                                    onChange={(e) => {
                                            
                                        this.props.changeInput(   
                                        "mobile_no", e.target.value)
                                        this.handleChange(e);
                                    
                                    }}

                                />
                                    {this.props.errors.mobile_no &&
                                    this.props.errors.mobile_no.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.mobile_no}
                                    </span>
                                    ) : (
                                    ""
                                    )}
                                </div>
                                <div className="col-md-6 form-group">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Occupation"
                                    name = 'occupation'
                                    onChange={(e) => {{this.props.changeInput(    
                                        "contest_occupation", e.target.value);
                                        this.handleChange(e)
                                    }}}
                                />
                                    {this.props.errors.occupation &&
                                    this.props.errors.occupation.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.occupation}
                                    </span>
                                    ) : (
                                    ""
                                    )}
                                </div>
                                <div className="col-md-6 form-group">
                                <select className="form-control"
                                    name= "monthly_income"
                                    onChange={(e) => {
                                        //console.log(e.target.value, 'done123')
                                        let value = e.target.value;
                                        this.props.changeInput('monthly_income', value);
                                        let errors = this.props.errors
                                        errors.monthly_income = (value.length === null)? 'Please enter your monthly income': '';
                                        this.props.updateErrors(errors);
                                    }}
                                >
                                    <option>Monthly Income</option>
                                    <option>&#60; $5,000 </option>
                                    <option>$5,001 to $10,000 </option>
                                    <option>$10,001 to $15,000</option>
                                    <option>&#62; $15,001</option>
                                </select>
                                {this.props.errors.monthly_income &&
                                    this.props.errors.monthly_income.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.monthly_income}
                                    </span>
                                    ) : (
                                    ""
                                    )}
                                </div>
                                <div className="col-md-12">
                                <textarea
                                    className="form-control"
                                    name = "photos_desc"
                                    placeholder = 'Description of your photo'
                                    // defaultValue={"Description of your photos"}
                                    onChange={(e) => {{this.props.changeInput(    
                                        "photos_desc", e.target.value);
                                        this.handleChange(e)
                                }}}
                                />
                                {
                                this.props.errors.photos_desc &&
                                this.props.errors.photos_desc.length > 0 ? (
                                <span 
                                //style= {{marginLeft: "62px"}}
                                className="text-danger">
                                    {this.props.errors.photos_desc}
                                </span>
                                ) : (
                                ""
                                )}
                                </div>

                            </form>
                            </div>
                            <div className="col-12 mt-4">
                            <h5>Upload Your Files</h5>
                            {/* <Tippy content={<div><p>1. Look for images that are in landscape. Do not submit images that are in portrait.</p> <p>2. Image or video needs to be less than 10MB.</p><p>3. Ensure that the image is not pixelated, clearly taken and the lighting is good.</p><p>4. If the image you have uploaded does not meet the above requirements, we reserve the right to replace it with an alternative image.</p></div>} >
                            <i class="fa fa-info-circle const-file-i" aria-hidden="true"></i>
                            </Tippy> */}
                            
                            <Dropzone 
                            onDrop={
                            acceptedFiles => {this.handleDropzone(acceptedFiles)}
                            }>
                            {({getRootProps, getInputProps}) => (
                            <div className="img-upload-wrap mb-3" 
                            style = {{ outline: 'none'}}
                            {...getRootProps()}
                            >
                                <div className="upload-drag"
                                
                                >
                                <input 
                                
                                {...getInputProps()}
                                id="contestfile" type="file" style={{ display: "none" }} accept="video/*,image/*"  onChange={(e) => { 
                                if (e.target.files[0]) {
                                    let compareFile = e.target.files[0].size / 1024 / 1024
                                    let errors = this.props.errors;
                                    //console.log(compareFile, "videoFiles")
                                    if (compareFile > 10.2) {
                                        errors.imageUrl = 'Please Upload less than 10MB';
                                        this.props.updateErrors(errors);
                                    } else {
                                        var filetype = e.target.files[0].type;
                                        let type = filetype.split('/')[0]
                                        $('.upload-drag').addClass('d-none')
                                        $('.contest-loader-pro').addClass('d-block')
                                        $('.contest-loader-pro').removeClass('d-none')
                                        errors.imageUrl = '';
                                        this.props.updateErrors(errors);
                                        this.props.uploadImage({ upload_file: e.target.files[0], typeFile: type})
                                    }
                                    //console.log(e.target.files[0].type, 'e.target.files[0].type')
                                   
                                } 
                                }} />
                                
                                <img 
                                className = "upload_icon_contest"
                                src={process.env.PUBLIC_URL+ "/assets/images/upload-icon.svg"} alt="icon" />
                                
                                
                                <img
                                    //onClick={() => $('#contestfile').click()}
                                    className="thumb_image d-none"
                                    src={process.env.PUBLIC_URL + "assets/images/snip-img5.jpg"}
                                    style = {{width: '30%', height:"29%"}}
                                    alt="image"
                                />
                                <video 
                                className ="thumb_video d-none"
                                src="" preload="auto" controls="" controlslist="nodownload" 
                                style={{width :"30%" , height : "29%"}}>

                                </video>
                                                            
                                <span>
                                    Drag &amp; Drop <br />
                                    <small>
                                    your file or <a href="javascript:;"
                                        //onClick={() => $('#contestfile').click()} 
                                    >browse</a>
                                    </small>
                                </span>
                                </div>
                                <div className="contest-loader-pro d-none">

                                <img
                                    className="img-fluid"
                                    src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                    alt="Avatar"
                                />
                                </div>

                                <span className="info">
                                Upload either JPEG, JPG, PNG file type.
                                </span>
                                
                            </div>
                            )}
                            </Dropzone>
                            {this.props.errors.imageUrl &&
                                this.props.errors.imageUrl.length > 0 ? (
                                <span className="text-danger">
                                    {this.props.errors.imageUrl}
                                </span>
                                ) : (
                                ""
                            )}
                            </div>
                            <div className="col-12 mt-4 contest-btm">
                            <p>
                            <label className="custom-checkbox">
                                <input 
                                type="checkbox" 
                                name="accept" 
                                id = "accept"
                                value={this.props.terms}
                                onChange={(e) => {this.props.changeInput(
                                //errors: {}, 
                                "terms", e.target.value 
                                );
                                this.handleChange(e)
                            }}
                            />
                            <span className="checkmark"></span>
                            </label>I have read
                                and understood the{" "}
                                <a 
                                href="javascript:;"
                                data-toggle="modal"
                                data-target="#rules-regulation"
                                >Contest Terms &amp; Conditions.</a>
                                {this.props.errors.terms &&
                                    this.props.errors.terms.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.terms}
                                    </span>
                                    ) : (
                                    ""
                                )}
                            </p>
                            {
                            
                            }
                            <button
                                className={
                                    this.props.contestDetail.length > 0 
                                    && this.props.contestDetail[0].submit_option !== undefined
                                    &&( this.props.contestDetail[0].submit_option === 1) ? "btn btn-orange mb-4 submit_disable":"btn btn-orange mb-4"
                                } 
                                data-toggle="modal"
                                //data-target="#success-pop"
                                disabled= {this.props.contestDetail.length > 0 
                                    && this.props.contestDetail[0].submit_option !== undefined
                                    &&( this.props.contestDetail[0].submit_option === 1) ? true:false}
                                onClick={(e) => this.submitEntry(e)}
                            >
                                Enter Now
                            </button>
                            </div>
                        </div>
                        </div>
                        {/* <div className="col-md-4">
                        <div className="text-center d-none d-sm-none d-md-block">
                            <img className="img-fluid" src={process.env.PUBLIC_URL+"/assets/images/ad-ver.jpg"} alt="ad" />
                        </div>
                        </div> */}
                    </div>
                    </div>
                </div>
                </section>

                {
                    /* contestsubmt Section Ends here */
                }


                </Fragment>
                <Footer />
                   {
                        /* Rules & Regulations Popup Starts here */
                    }
                    <div
                        className="modal fade pop-large"
                        id="rules-regulation"
                        tabIndex={-1}
                        role="dialog"
                        aria-hidden="true"
                    >
                        <div className="modal-dialog modal-dialog-centered" role="document">
                            <div className="modal-content">
                                <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                                </button>
                                <div className="modal-head">
                                    <h3>Terms &amp; Conditions</h3>
                                </div>
                                <div className="modal-body rules">
                                    <div className="mscroll-y-inside">

                                    <p>
                                    {this.props.contestDetail && this.props.contestDetail.length  > 0 &&
                                        this.props.contestDetail.map((o, k) => {
                                            
                                            var content = o.terms_conditions;
                                            if (content !== null) {
                                                content = content.replace(/\r\n/g,'<p></p>');
                                            }
                                            return <p>
                                            {ReactHtmlParser(content)}

                                            </p>
                                    })}                    
                                    </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                    className="modal fade submit-entry"
                    id="success-pop"
                    tabIndex={-1}
                    role="dialog"
                    aria-hidden="true"
                    >
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                        <button
                            type="button"
                            className="close"
                            data-dismiss="modal"
                            aria-label="Close"
                        >
                        <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                        </button>
                        <div className="modal-body success-pop">
                            <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" />
                            {/* <h3 className="mb-3">AWESOME</h3> */}
                            <p className="mb-4">Thank you for your submission</p>
                            <button className="btn btn-asphalt succ_ok"
                                onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                             >DONE</button>
                        </div>
                        {/* <div className="modal-body success-btm">
                            <button className="btn btn-white mr-2"
                               onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                            >View all submissions</button>
                            <button className="btn btn-white"
                               onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                            >Editor's Pick</button>
                        </div> */}
                        </div>
                    </div>
                    </div>
                    {
                        /* Terms & Conditions Popup Starts here */
                    }
                    <div
                        className="modal fade pop-large"
                        id="terms-conditions"
                        tabIndex={-1}
                        role="dialog"
                        aria-hidden="true"
                    >
                        <div className="modal-dialog modal-dialog-centered" role="document">
                            <div className="modal-content">
                                <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                                </button>
                                <div className="modal-head">
                                    <h3>Terms &amp; Conditions</h3>
                                </div>
                                <div className="modal-body rules">
                                    <div className="mscroll-y-inside">
                                        <p>
                                            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                                            nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                                            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                                            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                                            culpa qui officia deserunt mollit anim id est laborum.Sed ut
                                            perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                            doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                            inventore veritatis et quasi architecto beatae vitae dicta sunt
                                            explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                                            aut odit aut fugit, sed quia consequuntur magni dolores eos qui
                                            ratione voluptatem sequi nesciunt.
          </p>
                                        <p>
                                            Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                                            consectetur, adipisci velit, sed quia non numquam eius modi tempora
                                            incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut
                                            enim ad minima veniam, quis nostrum exercitationem ullam corporis
                                            suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis
                                            autem vel eum iure reprehenderit qui in ea voluptate velit esse quam
                                            nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo
                                            voluptas nulla pariatur
          </p>
                                        <p>
                                            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                                            nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                                            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                                            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                                            culpa qui officia deserunt mollit anim id est laborum.Sed ut
                                            perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                            doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                            inventore veritatis et quasi architecto beatae vitae dicta sunt
                                            explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                                            aut odit aut fugit, sed quia consequuntur magni dolores eos qui
                                            ratione voluptatem sequi nesciunt.
          </p>
                                        <p>
                                            Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                                            consectetur, adipisci velit, sed quia non numquam eius modi tempora
                                            incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut
                                            enim ad minima veniam, quis nostrum exercitationem ullam corporis
                                            suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis
                                            autem vel eum iure reprehenderit qui in ea voluptate velit esse quam
                                            nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo
                                            voluptas nulla pariatur
          </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {
                        /* Terms & Conditions Popup Ends here */
                    }
                </div>

            </div>

        );
    }

}

export default Submit;

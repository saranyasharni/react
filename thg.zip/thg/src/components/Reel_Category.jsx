import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import Category from './ReelCategorySection/Category'
import LatestWebSeries from './ReelCategorySection/Latest_Web_Series'
import WebSeries from './ReelCategorySection/Web_Series'

export default class Reel_Category extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    var search = window.location.pathname.split('/')[2]
    this.props.updateReelArticlePageNo({ flag: 1 })
    this.props.getReelChildBannerList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5, slug: search })
    this.props.getReelChildArticlesList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 16, slug: search })
  }

  componentDidMount() {
    var THIS = this;
    var search = window.location.pathname.split('/')[2]

    jQuery(document).ready(function () {
      window.$(`.${search}-cat `).addClass("active");
      window.$(".snip-caurosel").owlCarousel({
        items: 4,
        loop: false,
        dots: false,
        margin: 15,
        nav: true,
        responsive: {
          0: {
            items: 1
          },
          768: {
            items: 4
          }
        }
      });

      window.$(".mscroll-y").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "outside"
      });

      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside"
      });



    });
  }

  componentDidUpdate() {
    jQuery(document).ready(function () {
      window.$(".snip-caurosel").owlCarousel({
        items: 4,
        loop: false,
        dots: false,
        margin: 15,
        nav: true,
        responsive: {
          0: {
            items: 1
          },
          768: {
            items: 4
          }
        }
      });

      window.$(".mscroll-y").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "outside"
      });

      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside"
      });

    })
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.location !== this.props.location) {
      let nextParam = (nextProps.location.pathname).split('/')[2];
      let prevParam = (this.props.location.pathname).split('/')[2];
      window.$(`.${nextParam}-cat`).addClass("active");
      window.$(`.${prevParam}-cat`).removeClass("active");
      let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
      this.props.updateReelArticlePageNo({ flag: 1 })
      this.props.getReelChildBannerList({ user_id: userid, page_no: 0, limit: 5, slug: nextParam })
      this.props.getReelChildArticlesList({ user_id: userid, page_no: 0, limit: 16, slug: nextParam })
    }
  }

  render() {

    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>
            {/* Category Section Starts here */}
            <Category />
            {/* Category Section Ends here */}

            {/* Latest Web Series Starts here */}
            <LatestWebSeries />
            {/* Latest Web Series Ends here */}

            {/* Web Series Starts here */}
            <WebSeries />
            {/* Web Series Ends here */}


          </Fragment>

          <Footer />
        </div>
      </div>
    )
  }
}
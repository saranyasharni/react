import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Article_Detail';
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import history from "../../stores/history";
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class Sub_Category_Section extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        jQuery(document).ready(function () {
            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300
            });
        })
    }

    componentDidUpdate() {
        jQuery(document).ready(function () {
            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300
            });
        })
        jQuery('.item').off('click').click(function () {
            jQuery('.item').removeClass('active')
            jQuery(this).toggleClass('active')
            localStorage.setItem('sub_cat',jQuery(this).data('sub'))
            history.push(`/category/${localStorage.getItem('category')}`)
        })
    }

    render() {

        return (

            <section className="category-sec container-fluid mb-5">
                {/* parent-cat Starts here */}
                {/* <div className="row parent-cat py-4">
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                                <a href="javascript:;" className="active">
                                    Local
              <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;">
                                    International
              <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;">
                                    UGC (User Generated Content)
              <span className="tick">
                                        <img src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div> */}
                {/* parent-cat Ends here */}
                {/* child-cat Starts here */}
                <div className={this.props.subCategoryList.length > 0 ? "row child-cat py-3 d-block" : "row child-cat py-3 d-none"}>
                    <div className="container mscroll-x">
                        <ul className="list-inline mb-0">
                            {this.props.articleDetail.length > 0 && this.props.subCategoryList.length > 0 &&
                                this.props.subCategoryList.map((o, k) => {
                                    return <li className="list-inline-item" key={o.child_id}>
                                        <a href="javascript:;" data-sub={o.sub_category} className={(this.props.articleDetail[0].cat_slug.split(',')[1] === o.slug) ? 'item active' : 'item'}>
                                            {o.sub_category}
                                            <span className="tick">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                            </span>
                                        </a>
                                    </li>

                                })
                            }
                        </ul>
                    </div>
                </div>
                {/* child-cat Ends here */}
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        articleDetail: state.ArticleDetail.articleDetail,
        subCategoryList: state.ArticleDetail.subCategoryList
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getArticleDetail: (data) => dispatch(actions.getArticleDetail(data)),
        getSportsSubCategoryList: (data) => dispatch(actions.getSportsSubCategoryList(data))
    }
};

const subCategories = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Sub_Category_Section);

export default subCategories;

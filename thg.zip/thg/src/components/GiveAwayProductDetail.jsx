import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, withRouter } from "react-router-dom";
import Footer from '../containers/common/Footer';
import Header from '../containers/common/Header';
import jQuery from 'jquery';
import { connect } from "react-redux";
import * as actions from '../actions/Contest';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import { render } from '@testing-library/react';

class GiveAwayProductDetail extends Component {
    
    componentDidMount() {    
      
        // console.log(localStorage.getItem('cotests_name'), 'cotest_slug90909')     
        let pathId = window.location.pathname.split('/')[2]
        this.props.getproductDetail({ 
          post_id: pathId, 
          slug: localStorage.getItem('cotest_slug'),
          day: localStorage.getItem('day_no')
        })
        let THIS = this;

        jQuery(document).ready(function(){
            window.jQuery('.input-group.date').datepicker({
                format: "dd/mm/yyyy",
                endDate: "+0d"
        }).off('change').change((e) => { THIS.props.changeInput("dob", e.target.value); THIS.handleChange(e) });
            
            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis:"x",
                scrollEasing:"linear",
                scrollInertia: 300
            });
    
            window.jQuery(".mscroll-y-inside").mCustomScrollbar({
                axis:"y",
                scrollEasing:"linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });
            // if (THIS.props.product_detail.relatedProducts && THIS.props.product_detail.relatedProducts.length > 0) {
                
            //     window.jQuery(".related-carousel .owl-carousel").owlCarousel({
            //         items:4,
            //         loop:false,
            //         dots:false,
            //         margin:15,
            //         nav:true,
            //         responsive:{
            //             0:{
            //                 items:1
            //             },
            //             768:{
            //                 items:4
            //             }
            //         }
            //     });
            // }
            
        });
    
    }

    componentDidUpdate() {
      
        var THIS = this;
        jQuery(document).ready(function () {
            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis:"x",
                scrollEasing:"linear",
                scrollInertia: 300
            });
    
            window.jQuery(".mscroll-y-inside").mCustomScrollbar({
                axis:"y",
                scrollEasing:"linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });
            if (THIS.props.product_detail.relatedProducts && THIS.props.product_detail.relatedProducts.length > 0) {
                
                window.jQuery(".related-carousel .owl-carousel").owlCarousel({
                    items:4,
                    loop:false,
                    dots:false,
                    margin:15,
                    nav:true,
                    responsive:{
                        0:{
                            items:1
                        },
                        768:{
                            items:4
                        }
                    }
                });
            }
            if (THIS.props.contestStatus === 1) {
            jQuery('#give-away-form .alert').html('<strong>Success!</strong> Contest Booked Successfully.');
            jQuery('#give-away-form .alert').removeClass('alert-danger').addClass('alert-success')
            THIS.props.updateContestStatus(0);
            jQuery('#accept').prop("checked", false);
            THIS.props.resetForm({ 
              contest_email:'',
                    first_name:'',
                    last_name:'',
                    monthly_income:'',
                    imageUrl:'',
                    dob:'',
                    photos_desc:'',
                    mobile_no:'',
                    occupation:'',
              errors : {},
              
            })
            jQuery('.form-control').val('')
            setTimeout(function () {
              jQuery("#give-away-form .alert").removeClass('alert-success');
            }, 2000);
            // setTimeout(function () {
            //   window.jQuery('#success-pop').modal('hide')
            // }, 2000);
    
          }
        })         
        
    }
    componentWillReceiveProps(nextProps) {
      // console.log(nextProps.location.pathname, 'nextProps.params')
      // console.log(this.props.location.pathname, 'this.props.location')
      if (nextProps.location.pathname !== this.props.location.pathname) {
        let pathId = window.location.pathname.split('/')[2]
        this.props.getproductDetail({ 
          post_id: pathId, 
          slug: localStorage.getItem('cotest_slug'),
          day: localStorage.getItem('day_no')
        })
      }
    }
    handleChange(event) { 
      
        let errors = this.props.errors;
        let valid = true;
        const target = event.target;
        const value = target.value ;
        const name = target.name;
    
        this.setState({
          [name]: value
        });
    
        switch (name) {
            case 'first_name':
                valid = false;
                errors.first_name = (value.length === null)? 'Please enter your first name': '';
                this.props.updateErrors(errors);
            break;
            // case 'photos_desc':
            //     valid = false;
            //   //  console.log(value.length, 'value of Desc90')
            //     errors.photos_desc = (value.length >= 250)? 'Please write minimum 250 characters': '';
            //     this.props.updateErrors(errors);
            // break;
            case 'monthly_income':
                valid = false;
                errors.monthly_income = (value.length === null)? 'Please enter your montly income': '';
                this.props.updateErrors(errors);
            break;
            case 'last_name':
                valid = false;
                errors.last_name = (value.length === null)? 'Plese enter your last name': '';
                this.props.updateErrors(errors);
            break;
            case 'email':
                valid = false;
                errors.contest_email = (value.length === null)? 'Please enter your email': '';
                this.props.updateErrors(errors);
            break;
          case 'mobile_no':
            valid = false;
            errors.mobile_no = (value.length !== null && value.length < 8)? 'Mobile number must be more than 8 digits': '';
            this.props.updateErrors(errors);
          break; 
          case 'date_of_birth':
            errors.date_of_birth = (value.length === null)? 'Please enter your date of birth' : '';
            this.props.updateErrors(errors);
          break; 
          case 'occupation':
            errors.occupation = (value.length === null)? 'Please enter your occupation' : '';
            this.props.updateErrors(errors);
          break; 
          case 'accept':
            errors.terms = (event.target.checked === false)? 'Please accept the terms and conditions to participate' : '';
            this.props.updateErrors(errors);
          break; 
          default:
            this.props.updateErrors(errors);
          break;
        }
    }

    validateForm() {
    let valid = true;
    let errors = this.props.errors;
    //console.log(this.props.dob, 'DOB$%^')
    if (this.props.dob === '') {
        errors.date_of_birth = "Please enter your date of birth"
        valid = false;
    }
    if (this.props.first_name == '') {
        errors.first_name = "Please enter your first name"
        valid = false;
    
    }
    if (this.props.last_name == '') {
        errors.last_name = "Please enter your last name"
        valid = false;
    
    }
    if (this.props.mobile_no.length < 8) {
      errors.mobile_no = "Mobile number must be more than 8 digits"
      valid = false;
    }

    if (this.props.mobile_no === '') {
      errors.mobile_no = "Please enter your mobile number"
      valid = false;
    } 
    
    if (this.props.occupation === '') {
      errors.occupation = "Please enter your occupation"
      valid = false;
    }
    if (this.props.contest_email === '') {
            
        errors.contest_email = "Please enter your email"
        valid = false;
    }
    if (!this.props.contest_email == "") {
        if (!this.validateEmail(this.props.contest_email)) {
          valid = false;
          errors.contest_email = "please enter a valid email";
        }
    }
    // if (this.props.photos_desc === '') {
    //   errors.photos_desc = "Cannot be empty"
    //   valid = false;
    // }
    if (jQuery('#accept').is(":checked") === false) {
      errors.terms = "Please accept the terms and conditions to participate"
      valid = false;
    }
    if (this.props.monthly_income === '') {
        errors.monthly_income = "Please enter your monthly income"
        valid = false;
    }
    this.props.updateErrors(errors);
    return valid;
    
    }
    validateEmail(email) {
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    
        return expression.test(String(email).toLowerCase());
    }
    giveAway(e) {
        e.preventDefault();
        //consoe.log('cc', $('#accept').is(":checked"))
        if (this.validateForm()) {
        
            this.props.createGiveAway({
                user_id: localStorage.getItem('user_id'),
                contest_id: this.props.product_detail.giftdetail[0].ID,
                contest_name: localStorage.getItem('cotests_name'),
                product_name: this.props.product_detail.giftdetail[0].post_title,
                first_name: this.props.first_name,
                last_name: this.props.last_name,
                dob: this.props.dob,
                email: this.props.contest_email,
                mobile: this.props.mobile_no,
                occupation: this.props.occupation,
                monthly_income: this.props.monthly_income
            })
        }
    
    }

    render() {
        return (
            <>
            <Header />
           
              <section className="category-sec container-fluid bdr-btm">
                <div className="row parent-cat py-3">
                  <div className="container">
                    <h4>
                        <Link to = {`/contestgiveaway/${localStorage.cotest_slug ? localStorage.getItem('cotest_slug'): ''}`}>
                        <a href="javascript:;" className="back">
                            <img src={process.env.PUBLIC_URL+'/assets/images/left-arrow.svg'} alt="icon" />
                        </a>
                        </Link>
                        
                        Day {
                          localStorage.day_no ? localStorage.getItem('day_no') : 1
                        }{
                          this.props.product_detail.giftdetail &&
                          <small>- {this.props.product_detail.giftdetail && this.props.product_detail.giftdetail[0].post_title}</small>
                        } 
                        
                    </h4>
                  </div>
                </div>
              </section>
              {/* Category Section Ends here */}
              {/* Giveaway Section Starts here */}
              <section className="container-fluid mt-2 mb-5">
                <div className="row">
                    {
                   // console.log(this.props.product_detail, 'this.props.product_detail')
                    }
                    <div className="container contest-detail product-detail-wrap mt-5">
                    <div className="row mt-3">
                      <div className="col-md-8">
                        <div className="row">
                          <div className="col-12">
                            {/* <h1>{this.props.product_detail.giftdetail && this.props.product_detail.giftdetail[0].post_title}</h1> */}
                            <div className="product-img">
                              <img
                                className="img-fluid"
                                src = {this.props.product_detail.giftdetail ? this.props.product_detail.giftdetail[0].image_url: ''}
                                // src={process.env.PUBLIC_URL+"/assets/images/prod-detail-img.jpg"}
                                alt="img"
                              />
                            
                            </div>
                          </div>
                          <div className="col-12">
                          <p>
                          {ReactHtmlParser(this.props.product_detail.giftdetail ? this.props.product_detail.giftdetail[0].post_content : 'post_content') }
                          </p>
                          <br/>
                          
                            {/* <h5>
                              <strong>
                                Enter for a chance to win on November 28, 2016.
                              </strong>
                            </h5>
                            <p>
                              Sed do eiusmod tempor incididunt ut labore et dolore magna
                              aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                              ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
                              aute irure dolor in reprehenderit in voluptate velit esse
                              cillum dolore eu fugiat nulla pariatur. Excepteur sint
                              occaecat cupidatat non proident, sunt in culpa qui officia
                              deserunt mollit anim id est laborum.Sed ut perspiciatis unde
                              omnis iste natus error sit voluptatem accusantium doloremque
                              laudantium, totam rem aperiam, eaque ipsa quae ab illo
                              inventore veritatis et quasi architecto beatae vitae dicta
                              sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
                              aspernatur aut odit aut fugit, sed quia consequuntur magni
                              dolores eos qui ratione voluptatem sequi nesciunt.
                            </p>
                            <h5>
                              <strong>Enter for Today's Prize </strong>
                            </h5>
                            <p>
                              Sed do eiusmod tempor incididunt ut labore et dolore magna
                              aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                              ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
                              aute irure dolor in reprehenderit in voluptate velit esse
                              cillum dolore eu fugiat nulla pariatur. Excepteur sint
                              occaecat cupidatat non proident, sunt in culpa qui officia
                              deserunt mollit anim id est laborum.Sed ut perspiciatis unde
                              omnis iste natus error sit voluptatem accusantium doloremque
                              laudantium, totam rem aperiam, eaque ipsa quae ab illo
                              inventore veritatis et quasi architecto beatae vitae dicta
                              sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
                              aspernatur aut odit aut fugit, sed quia consequuntur magni
                              dolores eos qui ratione voluptatem sequi nesciunt.
                            </p> */}
                          </div>
                          <div className="col-12">
                            <h5>Your Details</h5>
                            <form className="contest-form row">
                              <div className="col-md-6 form-group">
                                <div className="input-group">
                                  <input
                                    type="text"
                                    className="form-control"
                                    placeholder="First Name"
                                    name = "first_name"
                                    onChange={(e) => {
                                                                
                                        this.props.changeInput(   
                                        "first_name", e.target.value)
                                        this.handleChange(e);
                                    
                                    
                                    }}
                                  />
                                  <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Last Name"
                                    name = "last_name"
                                    onChange={(e) => {
                                                                
                                        this.props.changeInput(   
                                        "last_name", e.target.value)
                                        this.handleChange(e)
                                    
                                    }}
                                  />

                                </div>
                                {
                                    this.props.errors.first_name &&
                                    this.props.errors.first_name.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.first_name}
                                    </span>
                                    ) : (
                                    ""
                                    )
                                    
                                    }
                                    {<br></br>}
                                    {
                                    this.props.errors.last_name &&
                                    this.props.errors.last_name.length > 0 ? (
                                      
                                    <span 
                                    
                                    className="text-danger">
                                        {this.props.errors.last_name}
                                    </span>
                                    ) : (
                                    ""
                                )}
                              </div>
                              <div className="col-md-6 form-group ">
                                <div
                                  className="input-group date mar-t-no"
                                  data-date-format="dd/mm/yyyy"
                                >
                                  <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Date of Birth"
                                    name= "date_of_birth"
                                    onChange={(e) => {
                                                                
                                        this.props.changeInput(   
                                        "dob", e.target.value)
                                        this.handleChange(e)
                                    
                                    }}
                                    //defaultValue
                                  />
                                  <div className="input-group-addon">
                                    <img src={process.env.PUBLIC_URL+"/assets/images/calendar-icon.svg"} alt="icon" />
                                  </div>
                                </div>
                                {this.props.errors.date_of_birth &&
                                    this.props.errors.date_of_birth.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.date_of_birth}
                                    </span>
                                    ) : (
                                    ""
                                )}
                              </div>
                              <div className="col-md-6 form-group">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Email"
                                  name = "email"
                                  onChange={(e) => {
                                                                
                                    this.props.changeInput(   
                                    "contest_email", e.target.value)
                                    this.handleChange(e)
                                
                                }}
                                  
                                />
                                 {this.props.errors.contest_email &&
                                    this.props.errors.contest_email.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.contest_email}
                                    </span>
                                    ) : (
                                    ""
                                )}
                                
                              </div>
                              <div className="col-md-6 form-group">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Mobile Number"
                                  name = "mobile_no"
                                  onChange={(e) => {                                
                                    this.props.changeInput(   
                                    "mobile_no", e.target.value)
                                    this.handleChange(e);
                                }}
                                />
                                  {this.props.errors.mobile_no &&
                                        this.props.errors.mobile_no.length > 0 ? (
                                        <span className="text-danger">
                                            {this.props.errors.mobile_no}
                                        </span>
                                        ) : (
                                        ""
                                    )}
                              </div>
                              <div className="col-md-6 form-group">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Occupation"
                                  name = "occupation"
                                  onChange={(e) => {
                                                                
                                    this.props.changeInput(   
                                    "occupation", e.target.value)
                                    this.handleChange(e);
                                }}
                                />
                                   {this.props.errors.occupation &&
                                    this.props.errors.occupation.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.occupation}
                                    </span>
                                    ) : (
                                    ""
                                    )}
                              </div>
                              <div className="col-md-6 form-group">
                                <select className="form-control"
                                name= "monthly_income"
                                placeholder = "Monthly Income"
                                onChange={(e) => {
                                    //console.log(e.target.value, 'done123')
                                    this.props.changeInput('monthly_income', e.target.value)}}
                                >
                                  <option>Monthly Income</option>
                                  <option>&#60; $5,000 </option>
                                  <option>$5,001 to $10,000 </option>
                                  <option>$10,001 to $15,000</option>
                                  <option>&#62; $15,001</option>
                                </select>
                                {this.props.errors.monthly_income &&
                                    this.props.errors.monthly_income.length > 0 ? (
                                    <span className="text-danger">
                                        {this.props.errors.monthly_income}
                                    </span>
                                    ) : (
                                    ""
                                )}
                              </div>
                              {/* <div className="col-md-12">
                                <textarea
                                    className="form-control"
                                    name= "photos_desc"
                                    placeholder = 'Description of your photo'
                                    onChange={(e) => {{this.props.changeInput(    
                                        "photos_desc", e.target.value);
                                        this.handleChange(e)
                                    }}}
                                  //defaultValue={"Description of your photos"}
                                />
                                   {
                                this.props.errors.photos_desc &&
                                this.props.errors.photos_desc.length > 0 ? (
                                <span 
                                //style= {{marginLeft: "62px"}}
                                className="text-danger">
                                    {this.props.errors.photos_desc}
                                </span>
                                ) : (
                                ""
                                )}
                              </div> */}
                            </form>
                          </div>
                          <div className="col-12 mt-4 contest-btm">
                            <p>
                            <label className="custom-checkbox">
                                <input 
                                type="checkbox" 
                                name="accept" 
                                id = "accept"
                                value={this.props.terms}
                                onChange={(e) => {this.props.changeInput(
                                //errors: {}, 
                                "terms", e.target.value 
                                );
                                this.handleChange(e)
                            }}
                            />
                            <span className="checkmark"></span>
                            </label>I have
                              read and understood the{" "}
                              <a href="javascript:;"
                              data-toggle="modal"
                              data-target="#terms-conditions"
                              >Giveaway Terms &amp; Conditions.</a>
                               {this.props.errors.terms &&
                                this.props.errors.terms.length > 0 ? (
                                <span className="text-danger">
                                    {this.props.errors.terms}
                                </span>
                                ) : (
                                ""
                            )}
                            </p>
                            <button
                              className="btn btn-orange mb-4"
                              data-toggle="modal"
                           //  data-target="#success-pop"
                              onClick={(e) => this.giveAway(e)}
                            >
                              Join GiveAway
                            </button>
                          </div>
                        </div>
                      </div>
                      {/* <div className="col-md-4">
                        <div className="text-center d-none d-sm-none d-md-block">
                          <img className="img-fluid" src={process.env.PUBLIC_URL+'/assets/images/ad-ver.jpg'} alt="ad" />
                        </div>
                      </div> */}
                    </div>
                  </div>
                </div>
              </section>
              {/* Giveaway Section Ends here */}
              
                <Footer />
                <div
                    className="modal fade submit-entry"
                    id="success-pop"
                    tabIndex={-1}
                    role="dialog"
                    aria-hidden="true"
                    >
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                        <button
                            type="button"
                            className="close"
                            data-dismiss="modal"
                            aria-label="Close"
                        >
                        <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                        </button>
                        <div className="modal-body success-pop">
                            <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" />
                            {/* <h3 className="mb-3">AWESOME</h3> */}
                            <p className="mb-4">Thank you for your submission</p>
                            <button className="btn btn-asphalt succ_ok"
                                onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                             >DONE</button>
                        </div>
                        {/* <div className="modal-body success-btm">
                            <button className="btn btn-white mr-2"
                               onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                            >View all submissions</button>
                            <button className="btn btn-white"
                               onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                            >Editor's Pick</button>
                        </div> */}
                        </div>
                    </div>
                    </div>
                    {
            /* Terms & Conditions Popup Starts here */
          }
          <div
            className="modal fade pop-large"
            id="terms-conditions"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-head">
                  <h3>Terms &amp; Conditions</h3>
                </div>
                <div className="modal-body rules">
                  <div className="mscroll-y-inside">
                    <p>
                    {this.props.product_detail.giftdetail && this.props.product_detail.giftdetail.length > 0 &&
                      this.props.product_detail.giftdetail.map((o, k) => {
                          var content = o.terms_conditions;
                          // content = content.replace(/&nbsp;/g, '<p></p>');
                          if (content !== null) {
                            content = content.replace(/\r\n/g,'<p></p>');
                          }

                          return <p>
                          {ReactHtmlParser(content)}

                          </p>
                      })}  
                    </p>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          {
            /* Terms & Conditions Popup Ends here */
          }
            </>
        )
    }
    
}
     
const mapStateToProps = (state, ownProps) => {
    return {
        contestStatus: state.Contest.contestStatus,
        errors: state.Contest.errors,
        imageUrl: state.Contest.imageUrl,
        occupation: state.Contest.occupation,
        dob: state.Contest.dob,
        terms: state.Contest.terms,
        mobile_no : state.Contest.mobile_no,
        first_name : state.Contest.first_name,
        last_name: state.Contest.last_name,
        contest_email: state.Contest.contest_email,
        monthly_income: state.Contest.monthly_income,
        photos_desc:state.Contest.photos_desc,
        product_detail: state.Contest.product_detail
    }
  };
  
  const mapDispatchToProps = (dispatch, state) => {
    return {
        getproductDetail: (data) => dispatch(actions.productDetail(data)),
        changeInput: (f, e) => dispatch(actions.inputChange(f, e)),
        createGiveAway: (data) => dispatch(actions.createGiveAway(data)),
        updateContestStatus: (data) => dispatch(actions.contestStatus(data)),
        resetForm: (data) => dispatch(actions.resetForm(data)),
        updateErrors: (data) => dispatch(actions.updateErrors(data))
        
    }
  };

export default connect(mapStateToProps, mapDispatchToProps) (GiveAwayProductDetail)

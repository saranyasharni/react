import React, { Component, Fragment,useEffect,useState } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import SubCategory from './FeatureArticleDetail/Sub_Category_Section'
import RelatedArticlesSection from './FeatureArticleDetail/Related_Articles_Section'
import ArticleDetailSection from './FeatureArticleDetail/Article_Detail_Section'

import ReactGA from "react-ga";
import { PageView, initGA, Event } from './../tracking';

import { Helmet } from 'react-helmet';


const GiveAwayStatus = props => {
    let {giveawayDetail,getGiveAwayStatus,articleDetail,getSurveyQuestionList,survayList}=props.prop
    let user_id = localStorage.getItem('user_id');
    let {awayStatus=undefined}=giveawayDetail
    useEffect( () => {  
        if(user_id && awayStatus){
            let article = localStorage.getItem('article');
            article=article?JSON.parse(article):article
            let  articleArray=article?article["article"]:[]
            let  length=articleArray.length
            let articleId=articleDetail.length>0?articleDetail[0]["ID"]:null
            let result = []
            if(length>0){
                result = articleArray.filter(article => article.articleId == articleId)
            }
            if(result.length==0 && articleId ){
                let data = {articleId,user_id,status:true}
                articleArray.push(data);
                localStorage.setItem("article",JSON.stringify({article:articleArray}))
                length++;
            }
            let articleStatus = articleArray.filter(article => article.status)
            let articleLength = articleStatus.length
            if( user_id && survayList.length && awayStatus && articleLength==1){
              window.jQuery('#survey-pop').modal("show")
              articleArray = articleArray.map((article)=>{
                article["status"]=false;
                return article
              })
              localStorage.setItem("article",JSON.stringify({article:articleArray}))
           }  
        }        
    }, [giveawayDetail,articleDetail,user_id,survayList])
    useEffect( () => {  
            getGiveAwayStatus({user_id});
            getSurveyQuestionList()     
    }, [user_id])
   
    return true
  }

export default class Feature_Article_Detail extends Component {
    constructor(props) {
        super(props);
        this.state = {questionNumber:0};
        this.handleSubmit=this.handleSubmit.bind(this);
        this.handleChangeQuestion=this.handleChangeQuestion.bind(this)
        this.handleCloseSurvay=this.handleCloseSurvay.bind(this)
    }
    handleSubmit(e){
      e.preventDefault()
      let answer_id = window.jQuery('input[name="answer"]:checked').val();
      let question = this.props.survayList[this.state.questionNumber];
      let {question_id} = question
      let user_id = localStorage.getItem('user_id');
      let ip = localStorage.getItem('ip_address');
      this.props.createSubmitSurvay({ user_id, question_id, answer_id, ip })
      this.handleChangeQuestion()
      window.jQuery('input[name="answer"]:checked').prop('checked', false)
    }
    handleChangeQuestion(){
      let questionNumber = this.state.questionNumber+1;
      if(questionNumber>=this.props.survayList.length){
        this.handleCloseSurvay()
        this.setState({questionNumber:0})
      }else{
        this.setState({questionNumber})
      }
    }
    handleCloseSurvay(){
      window.jQuery('#survey-pop').modal("hide")
    }
  
    
    componentWillMount() {
        initGA('UA-173387540-1');
        let search = (window.location.pathname).split('/')[2];
        ReactGA.event({
            category: 'Article Detail',
            action: 'Article View',
            label: search.replace(/-/g, ' ')
        });
        // if (localStorage.getItem('draft_status') == 0) {
        //   alert('draft')
          this.props.getArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: search })
        // } else {
        //   alert('draft no')
          // this.props.getDraftArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: search })
        // }

    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.location !== this.props.location) {
            let searchParam = (nextProps.location.pathname).split('/')[2];
            PageView();
            ReactGA.event({
                category: 'Article Detail',
                action: 'Article View',
                label: searchParam.replace(/-/g, ' ')
            });
            // if (localStorage.getItem('draft_status') == 0) {
            //     alert('0')
                this.props.getArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: searchParam })
            // } else {
            //   alert('1')
                // this.props.getDraftArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: searchParam })
            // }
        }
    }

    componentDidMount() {
        let search = (window.location.pathname).split('/')[2];
        var THIS = this;
        var owl = jQuery(".snip-caurosel")
    }

    componentWillUnmount() {
      localStorage.setItem('draft_status', 0)
      window.jQuery(`.${localStorage.getItem('category')}-nav `).removeClass("active");
    }
    
    render() {
        //alert()
        return (<>
            <div className="container-fluid">
                {/* {check status of give away and set article count} */}
                <GiveAwayStatus prop={this.props}/>
                <div className="row">
                    <Helmet>
                        <meta property="og:image" content="%PUBLIC_URL%/logo192.png" />
                        <meta property="og:title" content={this.props.articleDetail.length > 0 ? this.props.articleDetail[0].post_title : 'THG'} />
                    </Helmet>
                    <Header />

                    {this.props.loading 
                    ?
                    (
                        <>
                        <div className="loader-pro d-block" style={{
                                 marginLeft: '48%', 
                                 marginRight: '45%' ,
                                 marginTop:'10%',
                                 marginBottom:'20%'
                                 }} >

                            <img
                                className="img-fluid lazyload"
                                data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                alt="Avatar"
                            />
                        </div>
                        </>
                    ) :
                    (
                        <>
                        <Fragment>
                        {/* Category Section Starts here */}
                        {/* <SubCategory /> */}
                        {/* Category Section Ends here */}

                        {/* Popular Articles Starts here */}
                        <ArticleDetailSection />
                        {/* Popular Articles Ends here */}

                        {/* Featured Articles Starts here */}
                        <RelatedArticlesSection />
                        {/* Featured Articles Ends here */}



                    </Fragment>


                        </>
                    )
                     }

                    


                    <Footer />
                </div>
                
            </div>
            {
            /* Survey Popup Starts here */
          }
        <div
            className="modal fade"
            id="survey-pop"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-body">
                  <div className="interested">
                    <p className="lead">
                      Few things about you
            <span>This survey helps to improve you feeds...</span>
                    </p>
                  </div>
                  {this.props.survayList.length>=1  &&
                  
                  <form className="pop-form p-0 mt-5">
                      <div className="form-group mb-4">
                        <span className="label-lg">{this.props.survayList[this.state.questionNumber]['text']}</span>
                        <div className="col-12 px-0">
                          {this.props.survayList[this.state.questionNumber]['answers'].map((answer)=>{
                            return <>
                             <label className="custom-checkbox radio col-12">
                            <input type="radio" name="answer"  value={answer.answer_id}  />{" "}
                              {answer.text}
                          <span className="checkmark" />
                          </label>
                            </>
                          })}
                         
                        </div>
                        <hr className="mt-5"/>
                        <div className="col-12 text-center mt-4">
                          <a href="javascript:;" className="btn btn-asphalt" onClick={this.handleSubmit}>{this.props.survayList.length==this.state.questionNumber+1?"DONE":"Next"}</a>
                        </div>
                      </div>
                    
                    <div className="text-center mt-3 mb-0">
                      {/* <hr />
                      <button className="btn btn-asphalt">DONE</button> */}
                      <a href="javascript:;" className="no-thnx" onClick={this.handleCloseSurvay}>
                        No thanks, maybe next time.
                      </a>
                    </div>
                  </form>}
                </div>
              </div>
            </div>
          </div>
          {
            /* Survey Popup Ends here */
          }
            </>
        )
    }
}
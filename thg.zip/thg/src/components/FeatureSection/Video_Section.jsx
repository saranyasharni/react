import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Feature_Parent';
import * as headerActions from '../../actions/common/Header';
import jQuery from 'jquery';
import history from '../../stores/history';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import ReactPlayer from 'react-player'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import StripeCheckout from 'react-stripe-checkout';

class Video_Section extends Component {
    constructor(props) {
        super(props);
        this.state = {
            playControls : false,
            amount: '',
           
        }
    }

    onToken = (token, addresses) => {
        //console.log('token', token)
        //console.log('addresses', addresses)
        window.jQuery('#success-pop-subscribed-video-sec1').modal('show')
        this.props.subscribeEvent(
            {
                user_id :localStorage.getItem('user_id'),
                event_id :localStorage.getItem('event_id')
            }
        )
        // history.push("/paymentsuccess")
    };

    playVideo(payment, paidInfo) {
        if (payment === null) {
            payment = 5
        }
        this.setState({
            amount:payment
        })
        if (!localStorage.user_id)   {
            window.jQuery('#signup-modal').modal('show')
        } else if (!paidInfo) {
            window.jQuery('#success-pop-subscribed-video-sec').modal('show')
        } else {
            this.setState({
                playControls:!this.state.playControls
            })
        }
    }
    
    render() {
        
        // console.log(subscption, 'subscptionsubscption9090')
        var eventId = localStorage.event_id ? localStorage.getItem('event_id') : this.props.event_id;
        
        return (
            <>
            <section className="container-fluid my-5" id="video">
                <div className="row">
                    <div className="container">
                        <h3 className="title">
                            Videos
                            <Link 
                            to={`/events/videos/${eventId}`} 
                            // onClick={(e) => {
                            //     if (
                            //         this.props.latestVideos && 
                            //     this.props.latestVideos.length > 0 &&
                            //         this.props.latestVideos[0].event_amount === null ||
                            //     this.props.latestVideos[0].event_amount === '' 
                            //     ) {
                                    
                            //         history.push(`/events/videos/${eventId}`)  
                            //     } else {
                                    
                            //     if (
                            //     this.props.latestVideos && 
                            //     this.props.latestVideos.length > 0 &&
                            //     this.props.latestVideos[0].plan_subscribed){
                                    
                            //         history.push(`/events/videos/${eventId}`)
                            //     } else {
                            //         if (!localStorage.user_id) {
                            //             window.jQuery('#signup-modal').modal('show')
                            //         } else {
                                    
                            //             window.jQuery('#success-pop-subscribed-video-sec').modal('show')
                            //         }
                            //     }
                            // }

                             
                            //     localStorage.setItem('event_id', eventId);
                            // }}
                            >
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                            </Link>
                        </h3>
                        
                        <div className={this.props.latestVideos.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                            <h3 className="noarticle">No Videos</h3>
                        </div>
                        <div className="row video-sec">
                            {
                                this.props.latestVideos.length > 0 &&
                                this.props.latestVideos.map((o, k) => {
                                    
                                    if (k === 0) {
                                        return <div className="col-md-6 mt-1 big_video" key={k}>
                                            <ReactPlayer className="thumb mt-1.5" url={o.guid}
                                            config={{ file: { 
                                                attributes: {
                                                  controlsList: 'nodownload'
                                                }
                                                }}}
                                                light = {o.event_thumbnail}
                                                controls 
                                                // onClick = {(e) => {
                                                //     e.preventDefault()
                                                //     if (o.event_amount === '' || o.event_amount === null){
                                                //         this.setState({
                                                //             playControls:!this.state.playControls
                                                //         })
                                                //     } else {
                                                //         if (o.plan_subscribed
                                                //             ) {     
                                                //         this.setState({
                                                //             playControls:!this.state.playControls
                                                //         })
                                                            
                                                //         } else {    
                                                //             this.playVideo(o.event_amount, o.plan_subscribed)
                                                //         }
                                                //     }
                                                    
                                                   
                                                // }}
                                                // controls = {
                                                    
                                                //     (o.event_amount === '' || o.event_amount === null) ?
                                                //     true : 
                                                //     (o.plan_subscribed) ? true :
                                                //     false
                                                // }
                                                // playing = {
                                                //     (o.event_amount === '' || o.event_amount === null) ?
                                                //     true : 
                                                //     (o.plan_subscribed) ? true :
                                                //     false
                                                // }
                                             />
                                        </div>
                                    } })}
                                     {this.props.latestVideos.length > 0 &&
                                         <div className="col-md-6 rgt-side">
                                            <div className="row">
                                                {this.props.latestVideos.map((m, l) => {

                                                    if (l > 0 && l < 3) {
                                                        let clss_name = ''
                                                        // if (l == 1) {
                                                            
                                                        //     clss_name = "pr-3-mob"
                                                        //   } else {
                                                            
                                                        //     clss_name = "pl-3-mob"
                                                        //   }
                                                        return <div className={`col-md-6 col-6 pt-2 pt-sm-0 pb-0 pb-sm-3 ${l==1 ? 'pr-3-mob' : 'pl-3-mob'}`}
                                                        key={l}>
                                                            <ReactPlayer 
                                                             config={{ file: { 
                                                                attributes: {
                                                                  controlsList: 'nodownload'
                                                                }
                                                              }}}
                                                            className="thumb" url={m.guid}   
                                                            controls
                                                            // onClick = {(e) => {
                                                            //     e.preventDefault()
                                                            //     if (m.event_amount === '' || m.event_amount === null){
                                                            //         this.setState({
                                                            //             playControls:!this.state.playControls
                                                            //         })
                                                            //     } else {
                                                            //         if (m.plan_subscribed
                                                            //             ) {     
                                                            //         this.setState({
                                                            //             playControls:!this.state.playControls
                                                            //         })
                                                                        
                                                            //         } else {    
                                                            //             this.playVideo(m.event_amount, m.plan_subscribed)
                                                            //         }
                                                            //     }
                                                                
                                                               
                                                            // }}
                                                            // controls = {
                                                                
                                                            //     (m.event_amount === '' || m.event_amount === null) ?
                                                            //     true : 
                                                            //     (m.plan_subscribed) ? true :
                                                            //     false
                                                            // }
                                                            // playing = {
                                                            //     (m.event_amount === '' || m.event_amount === null) ?
                                                            //     true : 
                                                            //     (m.plan_subscribed) ? true :
                                                            //     false
                                                            // }
                                                            light = {m.event_thumbnail}
                                                            />
                                                        </div>
                                                    } else {
                                                        if (l > 2 && l < 5) {
                                                        let clss_name = ''
                                                        // if (l == 3) {
                                                        //     clss_name = "pr-3-mob"
                                                        //   } else {
                                                        //     clss_name = "pl-3-mob"
                                                        //   }
                                                        return <div className={`col-md-6 col-6 pt-2 pt-sm-3 ${l==3 ? 'pr-3-mob': 'pl-3-mob'}`}
                                                        key={l}>
                                                            <ReactPlayer 
                                                             config={{ file: { 
                                                                attributes: {
                                                                  controlsList: 'nodownload'
                                                                }
                                                              }}}
                                                            className="thumb" 
                                                            url={m.guid} 
                                                            
                                                            // onClick = {(e) => {
                                                            //     e.preventDefault()
                                                            //     if (m.event_amount === '' || m.event_amount === null){
                                                            //         this.setState({
                                                            //             playControls:!this.state.playControls
                                                            //         })
                                                            //     } else {
                                                            //         if (m.plan_subscribed
                                                            //             ) {     
                                                            //         this.setState({
                                                            //             playControls:!this.state.playControls
                                                            //         })
                                                                        
                                                            //         } else {    
                                                            //             this.playVideo(m.event_amount, m.plan_subscribed)
                                                            //         }
                                                            //     }
                                                                
                                                               
                                                            // }}
                                                            controls 
                                                            // = {
                                                                
                                                            //     (m.event_amount === '' || m.event_amount === null) ?
                                                            //     true : 
                                                            //     (m.plan_subscribed) ? true :
                                                            //     false
                                                            // }
                                                            
                                                            // = {
                                                            //     (m.event_amount === '' || m.event_amount === null) ?
                                                            //     true : 
                                                            //     (m.plan_subscribed) ? true :
                                                            //     false
                                                            // }
                                                            light = {m.event_thumbnail}
                                                            />
                                                        </div>  
                                                        }
                                                    }

                                                })}
                                            </div>
                                        </div>
                                        }
                                   
                        </div>
                    </div>
                </div>
            </section>
            <div
             className="modal fade submit-entry"
             id="success-pop-subscribed-video-sec"
             tabIndex={-1}
             role="dialog"
             aria-hidden="true"
            >
            <div className="modal-dialog modal-dialog-centered" data-id = {this.state.amount} role="document">
                <div className="modal-content">
                <button
                     type="button"
                     className="close"
                     data-dismiss="modal"
                     aria-label="Close"
                >
                    <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-body success-pop">
                    {/* <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" /> */}
                    <h3 className="mb-3">To watch videos please subscribe now</h3>
                    <StripeCheckout
                        amount={this.state.amount}
                        billingAddress
                        shippingAddress
                        name="subscribe now." // the pop-in header title
                        // description="Big Data Stuff" // the pop-in header subtitle
                        // className="btn btn-orange" 
                        style = {{marginLeft:'900px'}}
                        // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                        // description="Awesome Product"
                        // image="assets/images/logo-small.png"
                        stripeKey="pk_test_51GwUThARRSyCmdWnhY2AOexGvuotGtH8QMd1Uit4vk6DNj6KifR6hZUX7trwcdcgv4RwyO3Yb8LS8NxuSrmVYkMd00HXcjZCI8"
                        token={this.onToken}
                    >
                <button
                type="submit"
                className="btn btn-asphalt succ_ok" 
                
                onClick={(e) => {
                    window.jQuery('#success-pop-subscribed-video-sec').modal('hide')
                }}
                >
                SUBSCRIBE NOW
                </button>
                    </StripeCheckout> 
                 </div>
                 {/* <div className="modal-body success-btm">
                     <button className="btn btn-white mr-2"
                        onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                     >View all submissions</button>
                     <button className="btn btn-white"
                        onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                     >Editor's Pick</button>
                 </div> */}
                 </div>
             </div>
             </div>
            </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        // programmesList: state.THGTV.programmesList,
        // programmeStreamList: state.THGTV.programmeStreamList,
        // programme_id: state.THGTV.programme_id,
        featuredEventsBannerList: state.FeatureParent.featuredEventsBannerList,
        playControls: state.FeatureParent.playControls,        
        latestVideos: state.FeatureParent.latestVideos,

    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        // getVideoStreamApi: () => dispatch(actions.getVideoStraming()),
        setPlayVideo: (data) => dispatch(actions.setPlayVideo(data)),
        subscribeEvent: (data) => dispatch(actions.subscribeEvent(data))
    }
};

const videoSection = connect(
    mapStateToProps,
    mapDispatchToProps,
) (Video_Section);

export default videoSection;



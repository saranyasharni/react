import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import * as actions from "../../actions/ThgTvDetail";
import config from '../../actions/common/Api_Links'
import * as Featured_actions from "../../actions/Feature_Parent";
import jQuery, { data } from "jquery";
import history from "../../stores/history";
import Moment from "react-moment";
import Header from '../../containers/common/Header';
import Footer from '../../containers/common/Footer';
import { Link } from "react-router-dom";
import ReactGA from "react-ga";
import StripeCheckout from 'react-stripe-checkout';
import {
  FacebookShareCount,
  FacebookShareButton,
  FacebookIcon,
  TwitterIcon,
  TwitterShareButton,
  WhatsappIcon,
  WhatsappShareButton,
} from "react-share";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class LiveVideoSection extends Component {
    
constructor(props) {
  super(props); 
  this.state = {
    amount : ''
  }
}

componentWillMount() {
  let event_id = window.location.pathname.split('/')[2]
  this.props.getEventDetail(event_id)
}

componentDidMount() {
  var THIS = this;
  jQuery(document).ready(function () {
    
    if (THIS.props.relatedVideos.length > 0) {
      window.$(".mscroll-y").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "outside",
      });
      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside",
      });
    }

    let programme_id = window.location.pathname.split('/')[3]
   
    THIS.props.getLikes({
        article_id:programme_id,
        user_id:localStorage.user_id ? localStorage.getItem('user_id'): 0
    })
   
    THIS.props.getRelatedVideos({
        article_id:programme_id,
    })

    // jQuery('.loader-pro').removeClass('d-none')
    // jQuery('.loader-pro').addClass('d-block')
    const elem2 = document.createElement("script");
    elem2.type = "text/javascript"
    elem2.src =
        "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
    elem2.id = "player"
    elem2.async = false;
    // console.log(THIS.props.eventDetail, 'eventDetail1')
    setTimeout(function() {   

    console.log(THIS.props.eventDetail, 'eventDetail2')
    var amount_val = THIS.props.eventDetail && THIS.props.eventDetail[0] ? THIS.props.eventDetail[0].event_amount : '5'
    if (THIS.props.eventDetail && THIS.props.eventDetail[0].plan_subscribed && THIS.props.eventDetail[0].plan_subscribed === 1) {
      
      elem2.onload = () => THIS.scriptLoaded(programme_id);
      document.head.appendChild(elem2);     
    } else {
      jQuery('#container_subscribe_videos_').removeClass('d-none')
      jQuery('#container_subscribe_videos_').addClass('d-block')
      jQuery('.loader-pro').removeClass('d-block')
      jQuery('.loader-pro').addClass('d-none')
      jQuery('#player-container').removeClass('d-block')
      jQuery('#player-container').addClass('d-none')
      THIS.setState({
        amount : amount_val
      })
    }
  }, 3000)
   
      jQuery('.loader-pro').removeClass('d-block')
      jQuery('.loader-pro').addClass('d-none')
   
      THIS.props.getStreamVideoArticleDetail({
          'programme_id': programme_id
      })
    });
   
  }

  componentWillReceiveProps(nextProps) {
    var THIS = this;
    let play = true
    let programme_id = window.location.pathname.split('/')[3]
    if (nextProps.location !== this.props.location) {
        THIS.props.getLikes({
            article_id:programme_id,
            user_id:localStorage.user_id ? localStorage.getItem('user_id'): 0
        })
        
        THIS.props.getRelatedVideos({
            article_id:programme_id,
        })

        var element = document.getElementById('player');
        if(element){
            element.parentNode.removeChild(element)
        }
        // console.log('window.ESPxPlayer', window.ESPxPlayer)
        if(window.ESPxPlayer){
            let player = window.ESPxPlayer.getPlayer();
            // console.log('window.ESPxPlayer', player)
            if(player && player['_options']['parentId'] === "#player-container"){
                window.ESPxPlayer.destroyPlayer();
            }
        }

        // var element = document.getElementById('player')
        // if(element){
        //     element.parentNode.removeChild(element)
        // }
        // window.ESPxPlayer.destroyPlayer();
        jQuery('.loader-pro').removeClass('d-none')
        jQuery('.loader-pro').addClass('d-block')
        const elem2 = document.createElement("script");
        elem2.type = "text/javascript"
        elem2.src =
            "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
        elem2.id = "player"
        elem2.async = false;
        elem2.onload = () => THIS.scriptLoaded(programme_id);
        
        document.head.appendChild(elem2);     
        //For head
        document.head.appendChild(elem2);
        THIS.props.getStreamVideoArticleDetail({
            'programme_id': programme_id,
        })
        
    }
}

  scriptLoaded(programmeID) {
    // alert('elseif')
    const _CONFIG = {
        divID: '#player-container',
        appID: '7386573047397500',
        autoPlay: false,
        config: 'espxplayer',
        applyModel: true,
        programme_id: programmeID,
        countdown: true,
        videoAlignment: 'center',
        // apiCDN:'https://api.espx.cloud',
        //     widgetUrl:'https://widgets.espx.cloud/',
        //     interaction: {
        //         proxy_url: 'https://interaction.espx.cloud/'
        //     },
        // chatElement: '#chat-container' // Optional: To custom chat position, accept className or element ID
    }
    
    window.ESPxPlayer.createPlayer(_CONFIG).then((p) => {
    
        this.player = p;
        window.jQuery('#toggle-sharing svg').css('display', 'none')
        window.jQuery('#toggle-sharing').attr('title', '')
        window.jQuery('.data-share div').css('display', 'none')
        // var videoCusHeight = window.jQuery("#player-container video").height();
        // window.jQuery("#player-container").height(videoCusHeight);
        var screenWdth = jQuery(window).width();
        if (screenWdth <= 768) {
            setTimeout(() => {
                p.listenTo(p, 'play', () => {
                  var videoCusHeight = window.jQuery("#player-container video").height();
                  console.log('inside ready', videoCusHeight)
                });
                var videoCusHeight = window.jQuery("#player-container video").height();
                // console.log('videoCusHeight', videoCusHeight - 33)
                let hgt =  Number(videoCusHeight) + 30
                window.jQuery("#player-container").height(hgt);
            }, 500)
        }
    });
    
    jQuery('.loader-pro').removeClass('d-block')
    jQuery('.loader-pro').addClass('d-none')
}

  componentDidUpdate() {
    var THIS = this;
    jQuery(document).ready(function () {
      if (THIS.props.relatedVideos.length > 0) {
        window.$(".mscroll-y").mCustomScrollbar({
          axis: "y",
          scrollEasing: "linear",
          scrollInertia: 300,
          autoHideScrollbar: "true",
          autoExpandScrollbar: "true",
          scrollbarPosition: "outside",
        });
        window.$(".mscroll-y-inside").mCustomScrollbar({
          axis: "y",
          scrollEasing: "linear",
          scrollInertia: 300,
          autoHideScrollbar: "true",
          autoExpandScrollbar: "true",
          scrollbarPosition: "inside",
        });
      }

      jQuery(".change-pass")
        .off("click")
        .click(function () {
          jQuery(".change-pass-encl").slideUp();
          jQuery(".change-pass").show();
          jQuery(this).hide();
          jQuery(this).parent().find(".change-pass-encl").slideToggle();
          THIS.props.updateCommentReview("rating", 0);
        });

      jQuery(".cancel-pass")
        .off("click")
        .click(function () {
          jQuery(".change-pass").show();
          jQuery(".change-pass-encl").slideUp();
          THIS.props.updateCommentReview("rating", 0);
        });
    });

    if (THIS.props.commentStatus === 1) {
      jQuery(".rating-item").find("a").removeClass("active");
      jQuery(".add-comment .alert").html(
        "<strong>Success!</strong> Comment Created Successfully."
      );
      jQuery(".add-comment .alert")
        .removeClass("alert-danger")
        .addClass("alert-success");
      setTimeout(function () {
        jQuery(".add-comment .alert").removeClass("alert-success");
      }, 2000);
      THIS.props.updateCommentReview("commentStatus", 0);
      THIS.props.updateCommentReview("comment_review", "");
    } else if (THIS.props.commentStatus === 2) {
      jQuery(".add-comment .alert").html(
        "<strong>Error!</strong> Failed To Add Comment."
      );
      jQuery(".add-comment .alert")
        .removeClass("alert-success")
        .addClass("alert-danger");
      setTimeout(function () {
        jQuery(".add-comment .alert").removeClass("alert-danger");
      }, 2000);
      THIS.props.updateCommentReview("commentStatus", 0);
    }

    if (THIS.props.replyCommentStatus === 1) {
      jQuery(".rating-item").find("a").removeClass("active");
      jQuery(".reply-section .alert").html(
        "<strong>Success!</strong> Comment Created Successfully."
      );
      jQuery(".reply-section .alert")
        .removeClass("alert-danger")
        .addClass("alert-success");
      setTimeout(function () {
        jQuery(".reply-section .alert").removeClass("alert-success");
      }, 2000);
      setTimeout(function () {
        jQuery(".change-pass").show();
        jQuery(".change-pass-encl").slideUp();
      }, 1000);
      THIS.props.updateCommentReview("replyCommentStatus", 0);
      THIS.props.updateCommentReview("reply_comment_review", "");
    } else if (THIS.props.replyCommentStatus === 2) {
      jQuery(".reply-section .alert").html(
        "<strong>Error!</strong> Failed To Add Comment."
      );
      jQuery(".reply-section .alert")
        .removeClass("alert-success")
        .addClass("alert-danger");
      setTimeout(function () {
        jQuery(".reply-section .alert").removeClass("alert-danger");
      }, 2000);
      THIS.props.updateCommentReview("replyCommentStatus", 0);
    }

    jQuery(".rating-item")
      .off("click")
      .click(function () {
        jQuery(".rating-item").find("a").removeClass("active");
        jQuery(this).prevAll().find("a").addClass("active");
        jQuery(this).find("a").addClass("active");
        console.log("count", jQuery(".rating-item").find("a.active").length);
        THIS.props.updateCommentReview(
          "rating",
          jQuery(".rating-item").find("a.active").length
        );
    });
}

componentWillUnmount() {
  var element = document.getElementById('player');
  if (element) {
      element.parentNode.removeChild(element)
  }
  let player = window.ESPxPlayer.getPlayer();
  // console.log('window.ESPxPlayer', player)
  if (player && player['_options']['parentId'] === "#player-container") {
      window.ESPxPlayer.destroyPlayer();
  }
}

createComment(e) {
    e.preventDefault();
    this.props.createCommentForArticle({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      program_id: this.props.streamVideoDetail[0].id,
      comment_content: this.props.comment_review,
      author_ip: localStorage.getItem("ip_address"),
      author_name: localStorage.getItem("user_login"),
      email_id: localStorage.getItem("user_email"),
      rating_count: this.props.rating,
    });
  }

  replyComment(e) {
    e.preventDefault();
    this.props.replyCommentForArticle({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      program_id: this.props.streamVideoDetail[0].id,
      comment_content: this.props.reply_comment_review,
      author_ip: localStorage.getItem("ip_address"),
      author_name: localStorage.getItem("user_login"),
      email_id: localStorage.getItem("user_email"),
      rating_count: this.props.rating,
      comment_id: this.props.comment_id,
    });
  }

  share_on_fb = (title, description) => {
    ReactGA.event({
      category: "Share On Facebook",
      action: "Share Article",
      label: title,
    });
    var url = window.location.href;
    window.open(
      "http://www.facebook.com/sharer/sharer.php?s=100&p[title]=" +
        decodeURIComponent(title) +
        "&u=" +
        encodeURIComponent(url) +
        "&p[summary]=" +
        description,
      "sharer",
      "toolbar=0,status=0,width=600,height=360"
    );
  };

  whatsappShare(name) {
    ReactGA.event({
        category: "Share On Whatsapp",
        action: "Share Article",
        label: name,
    });
  }

  twitterShare(name) {
    ReactGA.event({
        category: "Share On Twitter",
        action: "Share Article",
        label: name,
    });
  }
  onToken = (token, addresses) => {
    //console.log('token', token)
    //console.log('addresses', addresses)
    window.jQuery('#success-pop-featured').modal('show')
    this.props.subscribeEvent(
        {
            user_id :localStorage.getItem('user_id'),
            event_id :window.location.pathname.split('/')[2]
        }
    )
    // history.push("/paymentsuccess")
  };
  render() {
    
    let programme_id = window.location.pathname.split('/')[3]
    // console.log(this.props.eventDetail, 'eventDetail')
    return (
        <div className="container-fluid">
        <div className="row">
            <Header />

            <Fragment>
                
            <section className="container-fluid article-content">
          <div className="row">
          <div className="container">
            <div className="row">
              <div className="col-12 text-center my-5">
        
              </div>

              {
            // console.log(this.props.streamVideoDetail, 'this.props.streamVideoDetail'),
              this.props.streamVideoDetail.length > 0 &&
                this.props.streamVideoDetail.map((o, k) => {
                    
                  var content = o.descr;
                  if (content) {
                    content = content.replace(/\r\n/g, "</p><p>");
                    content = content.replace(/\[embed]/g, "");
                    content = content.replace(/\[\/embed]/g, "");
                  } else {
                    content = ''
                  }
                  return (
                    <div className="col-md-8">
                      <div className="row">
                        <div className="col-12 mb-3">
                          <div
                            className="loader-pro d-block"
                            style={{ marginLeft: "52%", marginRight: "42%" }}
                          >
                            <img
                              className="img-fluid lazyload"
                              data-src={
                                process.env.PUBLIC_URL +
                                "/assets/images/loading.gif"
                              }
                              alt="Avatar"
                            />
                          </div>
                          <div
                            id="player-container"
                            style={{
                              width: "900px",
                              height: "506px",
                              maxWidth: "100%",
                            }}
                            
                          ></div>
                          <div
                            className = "d-none"
                            data-id = {this.state.amount}
                            id="container_subscribe_videos_"
                            style={{
                              width: "900px",
                              height: "406px",
                              maxWidth: "100%",
                            }}

                          >
                            <h3 className="noarticle">To watch videos subscribe here</h3>
                            <StripeCheckout
                       amount={this.state.amount}
                     
                       billingAddress
                       shippingAddress
                       name="subscribe now." // the pop-in header title
                       // description="Big Data Stuff" // the pop-in header subtitle
                       // className="btn btn-orange" 
                      
                       // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                       // description="Awesome Product"
                       // image="assets/images/logo-small.png"
                       stripeKey="pk_test_51GwUThARRSyCmdWnhY2AOexGvuotGtH8QMd1Uit4vk6DNj6KifR6hZUX7trwcdcgv4RwyO3Yb8LS8NxuSrmVYkMd00HXcjZCI8"
                       token={this.onToken}
                   >
               <button
               type="submit"
               className="btn btn-asphalt succ_ok_subsz_container text-center" 
               style = {{marginLeft: '270px'}}
               onClick={(e) => {
                   window.jQuery('#success-pop-subscribed-video-sec1').modal('hide')
               }}
               >
               SUBSCRIBE NOW
               </button>
                   </StripeCheckout> 
                          </div>
                          <div className="article-hero-img mb-3"></div>
                          <div className="article-head">
                            <div className="tag-wrap"></div>
                            <div className="share-sec text-right">
                              <button className="mr-1">
                              {
                                // console.log(this.props.userlikedData[0].userLiked, 'userlikedData'),
                                this.props.userlikedData && this.props.userlikedData[0].userLiked === 'false' ? (
                                  // console.log('if'),
                                  <img
                                  onClick = {() => 
                                    {
                                    !localStorage.user_id ? window.jQuery('#signup-modal').modal('show') :
                                    this.props.likeVideo({
                                    user_id:localStorage.user_id ? localStorage.getItem('user_id') : 0,
                                    article_id:programme_id,
                                    liked:'true'
                                  })}}
                                  className="lazyload if"
                                  data-src={
                                    process.env.PUBLIC_URL +
                                    "/assets/images/heart-lg.svg"
                                  }
                                  alt="icon"
                                />
                                ) : (
                                  // console.log('else'),
                                  <img
                                  className="lazyload else"
                                  data-src={
                                    process.env.PUBLIC_URL +
                                    "/assets/images/heart-lg-filled.svg"
                                  }
                                  onClick = {() => {
                                    !localStorage.user_id ? window.jQuery('#signup-modal').modal('show') :
                                    this.props.likeVideo({
                                    user_id:localStorage.user_id ? localStorage.getItem('user_id') : 0,
                                    article_id:programme_id,
                                    liked:'false'
                                  })}}
                                  alt="icon"
                                />
                                )
                                }
                                
                                {/* <img
                                  className="filled lazyload"
                                  data-src={
                                    process.env.PUBLIC_URL +
                                    "/assets/images/heart-lg-filled.svg"
                                  }
                                  alt="icon"
                                /> */}
                              </button>
                              {/* {o.no_of_likes} */}
                              {
                                
                              this.props.userlikedData.length > 0 ? this.props.userlikedData[0].likes : '0'}
                              <button className="ml-3">
                                <img
                                  className="lazyload"
                                  data-src={
                                    process.env.PUBLIC_URL +
                                    "/assets/images/view.svg"
                                  }
                                  alt="icon"
                                />
                              </button>
                              {o.no_of_views}
                            </div>
                            <h1 className="mt-4">{o.name}</h1>
                            <span className="post-by">
                              - {o.createdBy.display_name} (
                              <Moment format="DD MMM YYYY" withTitle>
                                {o.date_publish}
                              </Moment>
                              )
                            </span>
                          </div>
                          <div className="article-content mt-4">
                           <p> {ReactHtmlParser(content)}</p>
                          </div>
                          <div className="share-item mt-4">
                            <p>Share this:</p>
                            <ul className="list-inline">
                              <li className="list-inline-item">
                                <a 
                                href="javascript:;"
                                onClick={() =>
                                  this.share_on_fb(
                                    o.name,
                                    "description"
                                  )
                                }
                                >
                                  <img
                                    className="lazyload"
                                    data-src={
                                      process.env.PUBLIC_URL +
                                      "/assets/images/fb-icon.svg"
                                    }
                                    alt="icon"
                                  />
                                </a>
                              </li>
                              <li className="list-inline-item">
                              <WhatsappShareButton
                                    url={window.location.href}
                                    title={"whatsapp"}
                                    separator=":: "
                                    className="Demo__some-network__share-button"
                                    onShareWindowClose={() =>
                                      this.whatsappShare(o.name)
                                    }
                                  >
                                    <WhatsappIcon size={32} round />
                                  </WhatsappShareButton>
                                {/* <a href="javascript:;">
                                  <img
                                    className="lazyload"
                                    data-src={
                                      process.env.PUBLIC_URL +
                                      "/assets/images/insta-icon.svg"
                                    }
                                    alt="icon"
                                  />
                                </a> */}
                              </li>
                              <li className="list-inline-item">
                              <TwitterShareButton
                                    url={window.location.href}
                                    title={"Twitter"}
                                    className="Demo__some-network__share-button"
                                    onShareWindowClose={() =>
                                      this.twitterShare(o.name)
                                    }
                                  >
                                    <TwitterIcon size={32} round />
                                  </TwitterShareButton>
                                {/* <a href="javascript:;">
                                  <img
                                    className="lazyload"
                                    data-src={
                                      process.env.PUBLIC_URL +
                                      "/assets/images/twitter-icon.svg"
                                    }
                                    alt="icon"
                                  />
                                </a> */}
                              </li>
                            </ul>
                          </div>
                          {/* <div className="post-nav btn-group mt-3">
                                                    <Link to={`/videodetail/${o.prevArticle.post_name}`} className="btn">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                                        {o.prevArticle.post_title}
                                                    </Link>
                                                    <Link to={`/videodetail/${o.nextArticle.post_name}`} className="btn">
                                                        {o.nextArticle.post_title}
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                                    </Link>
                                                </div> */}
                          <hr className="my-5" />
                          <div className="comment-wrap mb-5">
                            <h4>Comments</h4>
                            <form className="add-comment mt-3 mb-5 text-right">
                              <div className="alert" role="alert"></div>
                              <textarea
                                className="form-control"
                                rows={5}
                                placeholder="Add Comment..."
                                value={this.props.comment_review}
                                onChange={(e) =>
                                  this.props.updateCommentReview(
                                    "comment_review",
                                    e.target.value
                                  )
                                }
                              />
                              <button
                                type="button"
                                className="btn btn-orange"
                                onClick={(e) => {
                                  localStorage.user_id
                                    ? this.createComment(e)
                                    : window
                                        .jQuery("#signup-modal")
                                        .modal("show");
                                }}
                              >
                                Comment
                              </button>
                            </form>
                            <div className="comment-sec">
                              {this.props.videoCommentsList.length > 0 &&
                                this.props.videoCommentsList.map((c, b) => {
                                  return (
                                    <div
                                      className="comment mb-4"
                                      key={c.comment_ID}
                                      data-id={c.comment_ID}
                                    >
                                      <div className="avatar">
                                        <img
                                          className="img-fluid lazyload"
                                          data-src={
                                            c.user_avatar
                                              ? c.user_avatar
                                              : process.env.PUBLIC_URL +
                                                "/assets/images/avatar.png"
                                          }
                                          alt="avatar"
                                        />
                                      </div>
                                      <div className="comment-item">
                                        <span className="name">
                                          {c.comment_author}
                                        </span>
                                        <p>{c.comment_content}</p>
                                        <span className="date-time">
                                          <Moment format="DD MMM YYYY">
                                            {c.comment_date}
                                          </Moment>
                                        </span>
                                        <br />
                                        <a
                                          href="javascript:;"
                                          className="reply change-pass"
                                          onClick={(e) => {
                                            jQuery(e.target)
                                              .closest(".comment-item")
                                              .find(".loader-pro")
                                              .removeClass("d-none");
                                            jQuery(e.target)
                                              .closest(".comment-item")
                                              .find(".loader-pro")
                                              .addClass("d-block");
                                            this.props.updateCommentReview(
                                              "comment_id",
                                              jQuery(e.target)
                                                .closest(".comment")
                                                .data("id")
                                            );
                                            this.props.getSubComments({
                                              program_id: localStorage.getItem(
                                                "programme_id"
                                              ),
                                              comment_id: jQuery(e.target)
                                                .closest(".comment")
                                                .data("id"),
                                            });
                                          }}
                                        >
                                          Reply
                                        </a>
                                        <div
                                          className="loader-pro d-none"
                                          style={{
                                            marginLeft: "25%",
                                            marginRight: "67%",
                                            marginTop: "6%",
                                          }}
                                        >
                                          <img
                                            className="img-fluid lazyload"
                                            data-src={
                                              process.env.PUBLIC_URL +
                                              "/assets/images/loading.gif"
                                            }
                                            alt="Avatar"
                                          />
                                        </div>
                                        <div className="change-pass-encl mt-4 mb-0">
                                          {this.props.subCommentsList.length >
                                            0 &&
                                            this.props.subCommentsList.map(
                                              (s, t) => {
                                                return (
                                                  <div className="child-comment mt-3">
                                                    <div className="avatar">
                                                      <img
                                                        className="img-fluid lazyload"
                                                        data-src={
                                                          s.user_avatar
                                                            ? s.user_avatar
                                                            : process.env
                                                                .PUBLIC_URL +
                                                              "/assets/images/avatar.png"
                                                        }
                                                        alt="avatar"
                                                      />
                                                    </div>
                                                    <div className="comment-item">
                                                      <span className="name">
                                                        {s.comment_author}
                                                      </span>
                                                      <p>{s.comment_content}</p>
                                                      <span className="date-time">
                                                        <Moment format="DD MMM YYYY">
                                                          {s.comment_date}
                                                        </Moment>
                                                      </span>
                                                      <br />
                                                    </div>
                                                  </div>
                                                );
                                              }
                                            )}

                                          <div className="child-comment mt-3">
                                            <div className="comment-item">
                                              <form className="reply-section mt-3 mb-5 text-right">
                                                <div
                                                  className="alert text-left"
                                                  role="alert"
                                                ></div>
                                                <textarea
                                                  className="form-control reply-comment"
                                                  rows={5}
                                                  placeholder="Add Comment..."
                                                  value={
                                                    this.props
                                                      .reply_comment_review
                                                  }
                                                  onChange={(e) =>
                                                    this.props.updateCommentReview(
                                                      "reply_comment_review",
                                                      e.target.value
                                                    )
                                                  }
                                                />
                                                <button
                                                  className="btn btn-trans cancel-pass"
                                                  type="button"
                                                  style={{ marginTop: "10px" }}
                                                >
                                                  Cancel
                                                </button>
                                                <button
                                                  type="button"
                                                  className="btn btn-orange"
                                                  onClick={(e) => {
                                                    localStorage.user_id
                                                      ? this.replyComment(e)
                                                      : window
                                                          .jQuery(
                                                            "#signup-modal"
                                                          )
                                                          .modal("show");
                                                  }}
                                                >
                                                  Comment
                                                </button>
                                              </form>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

              <div className="col-md-4 d-none d-sm-block">
                <div className="mb-5">
                  <div className="col p-0">
                    <h3 className="title">Latest Videos</h3>
                  </div>
                  <div className="whats-happen high-light col p-0">
                    {this.props.relatedVideos.length > 0 && (
                      <div className="wt-item-encl mscroll-y-inside">
                        {this.props.relatedVideos.map((l, v) => {
                          let event_id = window.location.pathname.split('/')[2]
                          return (
                            <Link
                              // to={`/feature-live-stream/${event_id}/${l.id}`}
                              className="wt-item"
                              data-id={l.id}
                              onClick={(e) => {
                                if (this.props.eventDetail && this.props.eventDetail[0].plan_subscribed === 1) {
                                  history.push(`/feature-live-stream/${event_id}/${l.id}`)
                                } else {
                                  // alert()
                                  this.setState({
                                    amount : this.props.eventDetail && this.props.eventDetail[0] ? 
                                    this.props.eventDetail[0].event_amount : ''
                                  })
                                  window.jQuery('#success-pop-subscribed-video-sec1').modal('show')
                                }
                              }}
                            >
                              <div className="cal">
                                <img
                                  className="img-fluid"
                                  src={l.img_url}
                                  alt="img"
                                />
                                <span className="play-icon">
                                  <img
                                    src={
                                      process.env.PUBLIC_URL +
                                      "/assets/images/video-play-filled.svg"
                                    }
                                    alt="icon"
                                  />
                                </span>
                              </div>
                              <div className="cal-cont">
                                <p>{l.name}</p>
                              </div>
                            </Link>
                          );
                        })}{" "}
                      </div>
                    )}
                  </div>
                </div>
               
              </div>
            </div>
          </div>
        </div>
      </section>

      <div
            className="modal fade submit-entry"
            id="success-pop-subscribed-video-sec1"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
           >
           <div className="modal-dialog modal-dialog-centered" data-id = {this.state.amount} role="document">
               <div className="modal-content">
               <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
               >
                   <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
               </button>
               <div className="modal-body success-pop">
                   {/* <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" /> */}
                   <h3 className="mb-3">To watch videos please subscribe now</h3>
                   <StripeCheckout
                       amount={this.state.amount}
                       billingAddress
                       shippingAddress
                       name="subscribe now." // the pop-in header title
                       // description="Big Data Stuff" // the pop-in header subtitle
                       // className="btn btn-orange" 
                       style = {{marginLeft:'900px'}}
                       // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                       // description="Awesome Product"
                       // image="assets/images/logo-small.png"
                       stripeKey="pk_test_51GwUThARRSyCmdWnhY2AOexGvuotGtH8QMd1Uit4vk6DNj6KifR6hZUX7trwcdcgv4RwyO3Yb8LS8NxuSrmVYkMd00HXcjZCI8"
                       token={this.onToken}
                   >
               <button
               type="submit"
               className="btn btn-asphalt succ_ok" 
               
               onClick={(e) => {
                   window.jQuery('#success-pop-subscribed-video-sec1').modal('hide')
               }}
               >
               SUBSCRIBE NOW
               </button>
                   </StripeCheckout> 
                </div>
                {/* <div className="modal-body success-btm">
                    <button className="btn btn-white mr-2"
                       onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                    >View all submissions</button>
                    <button className="btn btn-white"
                       onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                    >Editor's Pick</button>
                </div> */}
                </div>
            </div>
            </div>
            </Fragment>

            <Footer />
        </div>
    </div>
          );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    streamVideoDetail: state.FeatureParent.streamVideoDetail,
    videoCommentsList: state.ThgTvDetail.videoCommentsList,
    relatedVideos: state.FeatureParent.relatedVideos,
    subCommentsList: state.ThgTvDetail.subCommentsList,
    commentStatus: state.ThgTvDetail.commentStatus,
    replyCommentStatus: state.ThgTvDetail.replyCommentStatus,
    comment_review: state.ThgTvDetail.comment_review,
    reply_comment_review: state.ThgTvDetail.reply_comment_review,
    rating: state.ThgTvDetail.rating,
    comment_id: state.ThgTvDetail.comment_id,
    userlikedData : state.ThgTvDetail.userlikedData,
    eventDetail: state.FeatureParent.eventDetail
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getStreamVideoArticleDetail: (data) =>
      dispatch(Featured_actions.streamVideo(data)),
    getSubComments: (data) => dispatch(actions.getSubCommentsList(data)),
    createCommentForArticle: (data) => dispatch(actions.createComment(data)),
    replyCommentForArticle: (data) => dispatch(actions.replyComment(data)),
    updateCommentReview: (f, e) => dispatch(actions.changeCommentReview(f, e)),
    likeVideo: (data) => dispatch(actions.likeVideo(data)),
    getLikes: (data) => dispatch(actions.getLikes(data)),
    getRelatedVideos : (data) => dispatch(Featured_actions.getRelatedVideos(data)),
    getEventDetail : (data) => dispatch(Featured_actions.getEventDetail(data)),
    subscribeEvent: (data) => dispatch(Featured_actions.subscribeEvent(data))
  };
};

const articleDetails = connect(
  mapStateToProps,
  mapDispatchToProps
)(LiveVideoSection);

export default articleDetails;

import React, { Component, Fragment } from 'react'
import jQuery, { data } from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Feature_Parent';
import config from "../../actions/common/Api_Links";
import { Link } from 'react-router-dom';
import history from '../../stores/history';
import Moment from 'react-moment';
import StripeCheckout from 'react-stripe-checkout';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Hero_Banner extends Component {
    constructor(props) {
        super(props);
        this.state={
            stateClick:true
        }
    }

    componentDidMount() {
        var THIS = this;
        
        jQuery(document).ready(function () {
            if (THIS.props.featuredEventsBannerList.length > 0) {
                var owl = window.$('.banner .owl-carousel').owlCarousel({
                    items: 1,
                    loop: false,
                    dots: true,
                    rewind: true
                });
            }

        })

    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            let owl;
            if (THIS.props.featuredEventsBannerList.length > 0) {
                owl = window.$('.banner .owl-carousel').owlCarousel({
                    items: 1,
                    loop: false,
                    dots: true,
                    rewind: true,

                });
                let buttons = document.getElementsByClassName('owl-dot');               
                let buttonsView= document.getElementsByClassName('view-details-class');               
                let eventId =localStorage.getItem('event_id');
                let indexEvent =0;

                if(eventId){
                    
                    THIS.props.featuredEventsBannerList.map((item,index) => {
                    if(item.ID==eventId){
                        history.push(`/category/featured-events/${item.post_name}`)        
                        indexEvent=index   
                    }
                    return item.ID
                  });
                }
                    for (let i=0;i<buttons.length; i++) {
                      if(indexEvent==i){
                        buttons[i].click();
                        if(THIS.state.stateClick){
                        buttonsView[i].click();
                        THIS.setState({stateClick:false})
                        }
                    }
                    }
            }            
        })
    }

    onToken = (token, addresses) => {
        //console.log('token', token)
        //console.log('addresses', addresses)
        window.jQuery('#success-pop-featured').modal('show')
        this.props.subscribeEvent(
            {
                user_id :localStorage.getItem('user_id'),
                event_id :localStorage.getItem('event_id')
            }
        )
        // history.push("/paymentsuccess")
    };
    getDaysArray = (year, month) => {
        // console.log(year, 'year')
        // console.log(month, 'month')
        var monthIndex = month - 1;
        var names = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
        var date = new Date(year, monthIndex, 1);
        var result = [];
        
        while (date.getMonth() == monthIndex) {
            result.push(date.getDate() + "-" + names[date.getDay()]);
            date.setDate(date.getDate() + 1);
        }
        // console.log(result, 'getDaysArray')
        return result;
    }


    render() {

        return (
            <>
            <section className="container-fluid hero-banner">
                <div className="row banner">
                    {
                        this.props.featuredEventsBannerList.length > 0 &&
                        (<div className="owl-carousel">
                            {this.props.featuredEventsBannerList.map((o, k) => {
                                
                                let evn_id = o.ID
                                return <div className="slide-item  banner-background" data-event={o.ID}
                                    // style={{ backgroundImage: `url(${(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url})` }}
                                    >
                                    <img src={(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url} alt="icon" />
                                    <div className="carousel-cont">
                                        <div className="container">
                                            {/* <span className="tag">{(o.cat_name) ? (o.cat_name).split(',')[0] : ''}</span> */}
                                            <h4 className="mb-3">
                                                {o.post_title}
                                            </h4>
                                            <a href="javascript:;" className="text-link view-details-class" onClick={(e) => {
                                                e.preventDefault()
                                                if (o.live_stream === 'Yes') { 
                                                   
                                                    this.props.getAllCategories(o.live_stream, o.event_amount, o.plan_subscribed, o.category_field_url)   
                                                } else {
                                                    this.props.setLiveStreamVideos([])
                                                }
                                                localStorage.setItem('event_id', evn_id)
                                                this.props.setEventId(evn_id)
                                                this.props.getLatestArticles({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, event_id: evn_id })
                                                this.props.getLatestPhotos({ page_no: 0, limit: 7, event_id: evn_id })
                                                this.props.getLatestVideos({ 
                                                    user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0,
                                                    page_no: 0, 
                                                    limit: 5, 
                                                    event_id: evn_id 
                                                })
                                                this.props.getScheduleList({
                                                    category_id: '161',
                                                    year: new Date().getFullYear(),
                                                    // month: new Date().getMonth() + 1,
                                                    event_id : evn_id
                                                })
                                                this.props.setMonth({
                                                    currentMonth: new Date().getMonth(), 
                                                    currentYear: new Date().getFullYear(), datesOfMonth: this.getDaysArray(new Date().getFullYear(), new Date().getMonth() + 1) 
                                                })
                                                this.props.setPurchaseTicket(o.purchase_ticket_link)}
                                            }
                                                >
                                                View Details
                      <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/right-arrow-orange.svg"} alt="icon" />
                                            </a>
                                            {
                                        //     (o.subscription_plan && o.subscription_plan !== null
                                        //     && o.subscription_plan === 'Paid') ?
                                        //     (localStorage.user_id) ?
                                        //     (<StripeCheckout
                                        //         amount={o.event_amount}
                                        //         billingAddress
                                        //         shippingAddress
                                        //         name="subscribe now." // the pop-in header title
                                        //         // description="Big Data Stuff" // the pop-in header subtitle
                                        //         // className="btn btn-orange" 
                                        //         style = {{marginLeft:'900px'}}
                                        //         // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                                        //         // description="Awesome Product"
                                        //         // image="assets/images/logo-small.png"
                                        //         stripeKey="pk_test_51GwUThARRSyCmdWnhY2AOexGvuotGtH8QMd1Uit4vk6DNj6KifR6hZUX7trwcdcgv4RwyO3Yb8LS8NxuSrmVYkMd00HXcjZCI8"
                                        //         token={this.onToken}
                                        //     >
                                        // <button
                                        //         type="submit"
                                        //         className="btn btn-orange" 
                                        //         style = {{marginLeft:'900px'}}
                                        //         // onClick={(e) => {
                                        //         //     window.jQuery('#signup-modal').modal('show')
                                        //         // }}
                                        //         >
                                        //         SUBSCRIBE NOW
                                        // </button>
                                        //          </StripeCheckout>) :
                                        //     (<button
                                        //         type="submit"
                                        //         className="btn btn-orange" 
                                        //         style = {{marginLeft:'900px'}}
                                        //         onClick={(e) => {
                                        //             window.jQuery('#signup-modal').modal('show')
                                        //         }}
                                        //         >
                                        //         SUBSCRIBE NOW
                                        // </button>)
                                        // : ''
                                        } 
                                        </div>
                                        {/* <button type="button" className="btn btn-orange" >Find Out More</button> */}
                                    </div>
                                    
                                </div>
                            })}
                        </div>
                    )}
                </div>
            </section>

             <div
             className="modal fade submit-entry"
             id="success-pop-featured"
             tabIndex={-1}
             role="dialog"
             aria-hidden="true"
             >
             <div className="modal-dialog modal-dialog-centered" role="document">
                 <div className="modal-content">
                 <button
                     type="button"
                     className="close"
                     data-dismiss="modal"
                     aria-label="Close"
                 >
                <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-body success-pop">
                    <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" />
                    {/* <h3 className="mb-3">AWESOME</h3> */}
                    <p className="mb-4">Subscribed Successfully</p>
                    <button className="btn btn-asphalt succ_ok"
                        onClick = {(e) => { window.jQuery('#success-pop-featured').modal('hide')} }
                    >
                        DONE
                    </button>
                 </div>
                 {/* <div className="modal-body success-btm">
                     <button className="btn btn-white mr-2"
                        onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                     >View all submissions</button>
                     <button className="btn btn-white"
                        onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                     >Editor's Pick</button>
                 </div> */}
                 </div>
             </div>
             </div>
          </>  
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        latestArticlesList: state.FeatureParent.latestArticles,
        featuredEventsBannerList: state.FeatureParent.featuredEventsBannerList,
        purchaseTicket:state.FeatureParent.purchaseTicket,

    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getLatestArticles: (data) => dispatch(actions.getLatestArticlesList(data)),
        getFeaturedEventsBanner: (data) => dispatch(actions.getFeaturedEventsBanner(data)),
        getLatestPhotos: (data) => dispatch(actions.getLatestPhotosList(data)),
        getLatestVideos: (data) => dispatch(actions.getLatestVideosList(data)),
        getScheduleList: (data) => dispatch(actions.getCalendarEvents(data)),
        setPurchaseTicket: (data) => dispatch(actions.setPurchaseTicket(data)),
        setEventId:(data) => dispatch(actions.setEventId(data)),
        setMonth: (data) => dispatch(actions.setMonthAndYear(data)),
        subscribeEvent: (data) => dispatch(actions.subscribeEvent(data)),
        getAllCategories : (data , data1, data2, data4) => dispatch(actions.getAllCategories(data, data1, data2, data4)),
        setLiveStreamVideos : (data) => dispatch(actions.setLiveStreamVideos(data))
    }
};

const heroBanner = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Hero_Banner);

export default heroBanner;



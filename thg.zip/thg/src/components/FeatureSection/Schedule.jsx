import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Feature_Parent';
import * as headerActions from '../../actions/common/Header';
import jQuery from 'jquery';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Schedule extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.setMonth({ 
            datesOfMonth: this.getDaysArray(this.props.currentYear, this.props.currentMonth + 1) 
        })
        this.props.fetchEventCategories()
        // console.log(this.props.currentMonth + 1, 'this.props.currentMonth + 1')
        this.props.fetchCalendarEvents({
           category_id: '161',
            year: this.props.currentYear,
            month: this.props.currentMonth + 1,
            event_id : this.props.list.ID
        })
    }

    componentDidUpdate() {
    
        jQuery(document).ready(function () {
            window.$(".feature-nav").addClass("active");

            window.$(".mscroll-y").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            window.$(".mscroll-y-inside").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });

            window.jQuery(".mscroll-x").mCustomScrollbar({
                axis: "x",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            // var stickyBTM = window.jQuery(".sticky-btm-height").height();
            // window.jQuery(".sticky-btm-height").height(stickyBTM);
            // window.jQuery('.schedule-head,.lft-head').sticky({ topSpacing: 0, bottomSpacing: window.jQuery(".sticky-btm-height").outerHeight(true) });

            window.jQuery('[data-toggle="tooltip"]').tooltip({
                trigger: 'hover'
            });
            window.jQuery('[data-toggle="tooltip"]').on('click', function () {
                window.jQuery(this).tooltip('hide')
            })
        })
    }

    getNextMonth(e) {
        // console.log(this.props.currentMonth, 'this.props.currentMonth')
        e.preventDefault();
        if (this.props.currentMonth === 11) {
            // alert('next')
            // alert()
            // console.log(this.props.currentMonth, 'this.props.currentMonth')
            this.props.setMonth({ 
                currentMonth: 0, currentYear: this.props.currentYear + 1, datesOfMonth: this.getDaysArray(this.props.currentYear + 1, 1) })
            this.props.fetchCalendarEvents({
               // category_id: jQuery('#sport').find('option:selected').val(),
                year: this.props.currentYear + 1,
                month: 1,
                event_id: this.props.event_id
            })
        } else {
            this.props.increaseMonth({ flag: 1 })
            this.props.setMonth(
                { 
                    datesOfMonth: this.getDaysArray(this.props.currentYear, this.props.currentMonth + 2) 
                })
                // console.log(this.props.currentMonth, 'this.props.currentMonth')
                this.props.fetchCalendarEvents({
                //category_id: jQuery('#sport').find('option:selected').val(),
                year: this.props.currentYear,
                month: this.props.currentMonth + 2,
                event_id: this.props.event_id
            })
        }
    }

    getPreviousMonth(e) {
        // console.log(this.props.currentMonth, 'this.props.currentMonth')
        e.preventDefault();
        if (this.props.currentMonth === 0) {
            // alert('prev')
            this.props.setMonth(
                { currentMonth: 11, 
                    currentYear: this.props.currentYear - 1, 
                    datesOfMonth:  this.getDaysArray(this.props.currentYear - 1, 12) 
                })
            this.props.fetchCalendarEvents({
                //category_id: jQuery('#sport').find('option:selected').val(),
                year: this.props.currentYear - 1,
                month: 12,
                event_id: this.props.event_id

            })
        } else {
            this.props.increaseMonth({ flag: 0 })
            this.props.setMonth({ 
                datesOfMonth: this.getDaysArray(this.props.currentYear, this.props.currentMonth) 
            })
            this.props.fetchCalendarEvents({
                //category_id: jQuery('#sport').find('option:selected').val(),
                year: this.props.currentYear,
                month: this.props.currentMonth,
                event_id: this.props.event_id
            })
        }
    }

    backToToday(e) {

        e.preventDefault();
        // console.log('vale', jQuery('#sport').find('option:selected').val())
        this.props.setMonth({ currentMonth: new Date().getMonth(), currentYear: new Date().getFullYear(), datesOfMonth: this.getDaysArray(new Date().getFullYear(), new Date().getMonth() + 1) })
        this.props.fetchCalendarEvents({
            //category_id: jQuery('#sport').find('option:selected').val(),
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            event_id: this.props.event_id
        })

    }

    eventsByCategory(e, value) {
        //console.log(this.props.event_id, 'event_id_check_change')
        e.preventDefault();
        this.props.fetchCalendarEvents({
            //category_id: value,
            year: this.props.currentYear,
            month: this.props.currentMonth + 1,
            event_id: this.props.event_id
        })

    }

    getDaysArray = (year, month) => {
        // console.log(year, 'year')
        // console.log(month, 'month')
        var monthIndex = month - 1;
        var names = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
        var date = new Date(year, monthIndex, 1);
        var result = [];
        
        while (date.getMonth() == monthIndex) {
            result.push(date.getDate() + "-" + names[date.getDay()]);
            date.setDate(date.getDate() + 1);
        }
        // console.log(result, 'getDaysArray')
        return result;
    }

    getDateArray = (start, end) => {
        var arr = new Array();
        var dt = new Date(start);
        while (dt <= end) {
            arr.push(new Date(dt));
            dt.setDate(dt.getDate() + 1);
        }
        return arr;
    }

    render() {

        return (

            <section className="container-fluid schedule" id="schedule">

                <div className="row">
                    <div className="container">
                    <h3 className="title">Schedule</h3>
                        <div className="month-nav">
                            <a href="javascript:;" className="prev" onClick={
                                e => {
                                    this.getPreviousMonth(e)
                                }
                            }>
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                            </a>
                            <span>
                                <a href="javascript:;">{`${this.props.monthNames[this.props.currentMonth]} ${this.props.currentYear}`}</a>
                            </span>
                            <a href="javascript:;" className="next" onClick={
                                e => {
                                    this.getNextMonth(e)
                                }
                            }>
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                            </a>
                            <a href="javascript:;" className="back-today" onClick={e => this.backToToday(e)}>
                                Back to today
              </a>
                        </div>
                        <div className="schedule-cal mt-4">
                            <div className="schedule-wrap">
                                <div className="schedule-left">
                                    <div className="lft-head">
                                        
                                    </div>
                                    <ul className="list-unstyled">
                                        {
                                            this.props.calendarEvents.length > 0 ?
                                                this.props.calendarEvents.map((c, e) => {
                                                    return <li key={c.ID}>
                                                        <p className="text-truncate">
                                                            {c.post_title}
                                                                      
                                                        </p>
                                                        {
                                                            
                                                            c.streaming_url && 
                                                            <a 
                                                            
                                                            className = "stream_now"
                                                            onClick = {() =>
                                                                                        
                                                                localStorage.user_id ?
                                                                '':
                                                                window.jQuery('#signup-modal').modal('show')
                                                            }
                                                            target={localStorage.user_id? "_blank": ''}
                                                            href = {
                                                            localStorage.user_id ?
                                                            c.streaming_url:'javascript:void(0);'
                                                            }>
                                                             
                                                            streaming now
                                                            </a>
                                                        }
                                                         
                                                       
                                                    </li>
                                                }) : <li>
                                                    <span className="text-truncate">
                                                        No Events
                                            </span>
                                                </li>}
                                    </ul>
                                </div>
                                <div className="schedule-right mscroll-x">
                                    <div className="schedule-head">
                                        {
                                            this.props.datesOfMonth.length > 0 &&
                                            this.props.datesOfMonth.map((o, k) => {
                                                var daySplit = o.split('-')
                                                return <div className="th-head" key={k}>
                                                    {daySplit[0]}<span>{daySplit[1]}</span>
                                                </div>
                                            })
                                        }
                                    </div>
                                    <div className="schedule-body">
                                        {
                                            this.props.calendarEvents.length > 0 ?
                                                this.props.calendarEvents.map((r, s) => {
                                                    return <div className="td-item-row">
                                                        {
                                                            this.props.datesOfMonth.length > 0 &&
                                                            this.props.datesOfMonth.map((w, y) => {
                                                                var datesArray = this.getDateArray(new Date(r.StartDate), new Date(r.EndDate));
                                                                // console.log(r.StartTime, 'STARTTIME')
                                                                // console.log('w', this.getDateArray(new Date(r.StartDate), new Date(r.EndDate))[0].getMonth() === this.props.currentMonth)
                                                                // var time = r.StartTime.getHour();
                                                                // console.log(r.StartTime.split(':')[0], 'SPLIT');
                                                                // console.log(r.StartTime.split(':')[1], 'SPLIT')
                                                               // console.log(r.EndDate, 'End')
                                                                return <div className="td-item">
                                                                    {
                                                                    datesArray.map((d, b) => {
  
                                                                        return ((d.getMonth() === this.props.currentMonth) && (d.getDate()).toString() === w.split('-')[0]) ? 
                                                                        <a href="javascript:;"
                                                                            className="event-dot"
                                                                            data-toggle="tooltip"
                                                                            data-html="true"
                                                                            title={`<p class='mb-0'>
                                                                            <strong>Venue:</strong>${' '}
                                                                            ${r.city ? r.city: r.venue_values.split(',')[0] }
                                                                            </p>
                                                                           ${r.post_content &&
                                                                            `<p class='mb-0'><strong>Description:
                                                                            </strong>
                                                                             ${ r.post_content }
                                                                             </p>`
                                                                            }
                                                                            <p class='mb-0'
                                                                            >
                                                                            <strong>
                                                                            Start: </strong>${r.StartTime !== ''? r.StartTime.split(':')[0] +':'+r.StartTime.split(':')[1] 
                                                                            :''}
                                                                            </p>
                                                                            <p 
                                                                            class='mb-0'
                                                                            >
                                                                            <strong>
                                                                            ${r.FinishTime === r.StartTime? '' : 
                                                                            'End:'}
                                                                            </strong>${r.FinishTime !== r.StartTime ? r.FinishTime.split(':')[0]+':'+r.FinishTime.split(':')[1]
                                                                            :''}        
                                                                            </p>
                                                                            `}
                                                                        /> : ''
                                                                    })
                                                                    }

                                                                </div>
                                                            })}
                                                        {/* <div className="td-item">
                                                        <a
                                                            href="javascript:;"
                                                            className="event-dot"
                                                            data-toggle="tooltip"
                                                            data-html="true"
                                                            title="<p class='mb-0'><strong>Venue:</strong>France</p><p class='mb-0'><strong>Timing:</strong>12:20 IST</p>"
                                                        />
                                                    </div>
                                                    <div className="td-item">
                                                        <a
                                                            href="javascript:;"
                                                            className="event-dot"
                                                            data-toggle="tooltip"
                                                            data-html="true"
                                                            title="<p class='mb-0'><strong>Venue:</strong>France</p><p class='mb-0'><strong>Timing:</strong>12:20 IST</p>"
                                                        />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item" />
                                                    <div className="td-item">
                                                        <a href="javascript:;">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/cup.svg"} alt="icon" />
                                                        </a>
                                                    </div>
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/cup.svg"} alt="icon" />
                                                        </a>
                                                    </div>
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/cup.svg"} alt="icon" />
                                                        </a>
                                                    </div>
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/cup.svg"} alt="icon" />
                                                        </a>
                                                    </div>
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item" />
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div>
                                                    <div className="td-item">
                                                        <a href="javascript:;" className="event-dot" />
                                                    </div> */}
                                                    </div>
                                                }) : <div className="td-item-row">
                                                    <span className="text-center"></span>
                                                </div>}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        currentYear: state.FeatureParent.currentYear,
        currentMonth: state.FeatureParent.currentMonth,
        monthNames: state.FeatureParent.monthNames,
        currentDate: state.FeatureParent.currentDate,
        daysOfMonth: state.FeatureParent.daysOfMonth,
        datesOfMonth: state.FeatureParent.datesOfMonth,
        increaseCount: state.FeatureParent.increaseCount,
        decreaseCount: state.FeatureParent.decreaseCount,
        calendarEvents: state.FeatureParent.calendarEvents,
        eventCategories: state.FeatureParent.eventCategories,
        category_id: state.FeatureParent.category_id,
        event_id: state.FeatureParent.event_id
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getLatestArticlesList: (data) => dispatch(actions.getLatestArticlesList(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
        increaseMonth: (data) => dispatch(actions.updateMonthAndYear(data)),
        setMonth: (data) => dispatch(actions.setMonthAndYear(data)),
        fetchCalendarEvents: (data) => { dispatch(actions.getCalendarEvents(data)) },
        fetchEventCategories: () => dispatch(actions.getEventCategoryList()),
    }
};

const schedule = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Schedule);

export default schedule;



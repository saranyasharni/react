import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import * as actions from "../../actions/Feature_Parent";
import * as headerActions from "../../actions/common/Header";
import jQuery from "jquery";
import Moment from "react-moment";
import { Link } from "react-router-dom";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import Tippy from '@tippy.js/react'
import 'tippy.js/dist/tippy.css'


class Photo_Section extends Component {
  constructor(props) {
    super(props);
    this.state = { open: false, imageUrl: null, desc : null };
    this.handleShowImage = this.handleShowImage.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }
  // componentDidMount() {
  //   var lastLocation = location.pathname
    
  //   console.log(lastLocation, 'lastUrl')
  // }
  handleShowImage(imageUrl,desc) {
    this.setState({ imageUrl }, () => {
      this.setState({ open: true });
      this.setState({ desc });
      window.jQuery("#event-photo-pop").modal("show");
    });
  }
  handleClose() {
      // console.log("handleClose")
    window.jQuery("#event-photo-pop").modal("hide");
  }
  
  render() {

    var eventId = localStorage.event_id ? localStorage.getItem('event_id') : this.props.event_id
    
    return (
      <section className="container-fluid my-5" id = "photos">
        <div className="row">
          <div className="container">
            <h3 className="title">
              Photos
              <Link
                to={`/events/photos/${eventId}`}
                onClick={(e) => {
                  // var eventId = window
                  //   .jQuery(".owl-item.active")
                  //   .find(".slide-item")
                  //   .data("event");
                  localStorage.setItem("event_id", eventId);
                }}
              >
                <img
                  className="lazyload"
                  data-src={
                    process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"
                  }
                  alt="icon"
                />
              </Link>
            </h3>
            <div
              className={
                this.props.latestPhotosList.length > 0
                  ? "col-md-12 col-12 d-none"
                  : "col-md-12 col-12 d-block"
              }
            >
              <h3 className="noarticle">No Photos</h3>
            </div>
            <div className="row video-sec h-auto">
              <div className=" col-md-6">
                {/* <div className="photo-lft"> */}
                  {this.props.latestPhotosList.length > 0 &&
                    this.props.latestPhotosList.map((m, l) => {
                      if (l === 0) {
                        return (
                          <a href="javascript:;"  
                          className = 'submission-thumb'
                          onClick={() => {
                            this.handleShowImage(m.guid, m.event_caption);
                          }}>
                            
                            <img
                              // className="img-fluid lazyload"
                              src={m.guid ? m.guid : ""}
                              alt="img"
                            />
                            
                            <div className="submission-overlay">
                                <p>
                                    {m.event_caption}
                                </p>
                            </div>
                             
                          </a>
                        );
                      }
                    })}
                {/* </div> */}
              </div>

              <div className=" col-md-6 rgt-side ">
                {/* <div className="photo-rgt"> */}

                  <div className="row">

                    {this.props.latestPhotosList.length > 0 &&
                      this.props.latestPhotosList.map((o, k) => {
                        if (k > 0 && k < 3) {
                          let clss_name =  ''
                          if (k == 1) {
                            clss_name = "pr-3-mob"
                          } else {
                            clss_name = "pl-3-mob"
                          }

                          return (
                            <div 
                            className={`col-md-6 col-6 pt-2 pt-sm-0 pb-0 pb-sm-3 ${clss_name}`}
                            key = {k}
                            >
                            <a href="javascript:;"  onClick={() => {
                                this.handleShowImage(o.guid, o.event_caption);
                              }} 
                              className = "photo-small-thumb"
                              >                             
                              <img
                                // className="img-fluid lazyload"
                                src={o.guid ? o.guid : ""}
                                alt="img"
                              />
                              <div className="contest-overlay">
                               
                                <p>
                                  {o.event_caption ? o.event_caption.substring(0,250):''}
                                </p>
                               
                                </div>
                             
                              {/* <span className="maginfy">
                            <img src={process.env.PUBLIC_URL + "/assets/images/search-icon.svg"} alt="icon" />
                        </span> */}
                            </a>
                            </div>
                          );
                        }
                      })}
                      {this.props.latestPhotosList.length > 0 &&
                      this.props.latestPhotosList.map((o, k) => {
                        if (k > 2 && k < 5) {
                          let clss_name = ''
                          if (k == 3) {
                            clss_name = "pr-3-mob"
                          } else {
                            clss_name = "pl-3-mob"
                          }
                          return (
                            <div 
                            className={`col-md-6 col-6 pt-2 pt-sm-3 ${clss_name}`}
                            key = {k}
                            >
                            <a href="javascript:;"  onClick={() => {
                                this.handleShowImage(o.guid, o.event_caption);
                              }} 
                              className = "photo-small-thumb"
                              >                             
                              <img
                                // className="img-fluid lazyload"
                                src={o.guid ? o.guid : ""}
                                alt="img"
                              />
                              <div className="contest-overlay">
                               
                                <p>
                                  {o.event_caption ? o.event_caption.substring(0,250):''}
                                </p>
                               
                                </div>
                             
                              {/* <span className="maginfy">
                            <img src={process.env.PUBLIC_URL + "/assets/images/search-icon.svg"} alt="icon" />
                        </span> */}
                            </a>
                            </div>
                          );
                        }
                      })}
                  </div>
                {/* </div> */}
              </div>
            </div>
          </div>
        </div>
        <div
                className="modal fade"
                id="event-photo-pop"
                tabIndex={-1}
                role="dialog"
                aria-hidden="true"
              >
                <div
                  className="modal-dialog modal-dialog-centered"
                  role="document"
                >
                  <div className="modal-content">
                  <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                      &#10005;
                    </button>
                    <div className="modal-body">
                      {this.state.open && (
                        <div className="row">
                          <div className="col-md-12">
                            <div className="col-md-12 text-center event-photos">

                              <img
                                className="img-fluid lazyload"
                                src={this.state.imageUrl}
                                alt="img"
                                // onMouseOut={()=>{
                                //     this.handleClose();

                                //   }}
                              />
                              <p>
                                {this.state.desc.substring(0,450)}
                              </p>  
                            </div>
                            
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

      </section>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    latestPhotosList: state.FeatureParent.latestPhotos,
    event_id: state.FeatureParent.event_id,
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getLatestPhotos: (data) => dispatch(actions.getLatestPhotosList(data)),
  };
};

const photoSection = connect(
  mapStateToProps,
  mapDispatchToProps
)(Photo_Section);

export default photoSection;

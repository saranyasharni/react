import React, { Component, Fragment } from 'react'


export default class Ad_Section extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        return (

            <section className="container-fluid my-5">
                <div className="row">
                    <div className="col-12 text-center mt-4">
                        {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"} alt="Ad" /> */}
                    </div>
                </div>
            </section>







        )
    }
}



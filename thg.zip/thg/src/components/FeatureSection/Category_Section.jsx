import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import jQuery from 'jquery'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


export default class Category_Section extends Component {
    constructor(props) {
        super(props);
    }

    scrollEvent(e, scrollto) {
        console.log(window.jQuery(`#ticket-video-leasr`), 'scrollto')
        e.preventDefault()
        if (window.jQuery(`#ticket-video-leasr`).length && scrollto === 'ticket') {
            
            jQuery('html, body').animate({
                scrollTop: window.jQuery(`#ticket-video-leasr`).offset().top
            }, 1000);
        } else {
            if (scrollto !== 'ticket') {
                jQuery('html, body').animate({
                    scrollTop: window.jQuery(`#${scrollto}`).offset().top
                }, 1000);
            }
        }
        
        // console.log('schedule', window.jQuery(`#${scrollto}`).offset())
        // jQuery(window).scrollTop(window.jQuery('#schedule').offset().top);
    }

    render() {

        return (

            <section className="category-sec container-fluid">
                {/* parent-cat Starts here */}
                <div className="row parent-cat py-4 rgt-btn">
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                                <a href="javascript;"
                                    onClick={e => this.scrollEvent(e, 'news')}>
                                    News
                <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript;"
                                    onClick={e => this.scrollEvent(e, 'schedule')}>
                                    Schedule
                <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript;"
                                    onClick={e => this.scrollEvent(e, 'photos')}>
                                    Photos
                <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript;"
                                    onClick={e => this.scrollEvent(e, 'video')}>
                                    Videos
                <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript;"
                                    onClick={e => this.scrollEvent(e, 'ticket')}>
                                    Ticketing
                <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                        </ul>
            {this.props.purchaseTicket!="" && (this.props.purchaseTicket !== null) &&              
          <a className="btn btn-orange d-none d-sm-none d-md-block" href={this.props.purchaseTicket} target={"_blank"}>
                                                <img className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/ticket-icon.svg"} alt="icon" />
                                            {"Purchase Tickets"}
                                        </a>}
                    </div>
                </div>
                {/* parent-cat Ends here */}
            </section>







        )
    }
}



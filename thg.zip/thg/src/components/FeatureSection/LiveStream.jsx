import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Feature_Parent';
import * as headerActions from '../../actions/common/Header';
import history from "../../stores/history";
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import StripeCheckout from 'react-stripe-checkout';

class LiveStream extends Component {
    constructor(props) {
        super(props);
        this.state = {
            // playControls : false,
            amount: '',  
        }
    }

    playVideo(subscribed, live_stream, payment, id) {
        
        if (payment === null) {
            payment = 5
        }
        this.setState({
            amount:payment
        })
        if (!localStorage.user_id)   {
            window.jQuery('#signup-modal').modal('show')
        } else if (subscribed === 0) {
            window.jQuery('#success-pop-subscribed-video-sec').modal('show')
        } else {
            console.log('Not came')
        }
    }
    componentDidMount() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.livtStreamVideos && THIS.props.livtStreamVideos.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });
            }

        })

    }

    componentDidUpdate() {
      
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.livtStreamVideos && THIS.props.livtStreamVideos.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });


            }

        })
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        var url = jQuery(e.target).closest(".article-item").find('.art-background img').attr('src')
        // var url = jQuery(e.target).closest(".article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
    }
    onToken = (token, addresses) => {
        //console.log('token', token)
        //console.log('addresses', addresses)
        window.jQuery('#success-pop-subscribed-video-sec').modal('hide')
        // window.jQuery('#success-pop-featured').modal('show')
        this.props.subscribeEvent(
            {
                user_id :localStorage.getItem('user_id'),
                event_id :localStorage.getItem('event_id')
            }
        )
        // history.push("/paymentsuccess")
      };
    render() {

        return (
            <>
            <section className="container-fluid mb-5" id="live-videos">
                <div className="row">
                    <div className="container">
                        <h3 className="title">
                            {/* Latest Articles */}
                            {/* EVENT details */}
                            Live Stream Videos
                        </h3>
                        <div className={this.props.livtStreamVideos.length > 0 ? 'd-none' : 'd-block'}>
                            <h3 className="noarticle">No Streams</h3>
                        </div>
                            {
                                // console.log(this.props.livtStreamVideos, 'this.props.livtStreamVideos'),
                                this.props.livtStreamVideos 
                                && this.props.livtStreamVideos.length > 0 &&
                                (<div className="snip-caurosel owl-carousel">

                                {this.props.livtStreamVideos.map((o, k) => {
                                    let event_id = localStorage.getItem('event_id')
                                    return <div className="article-item" key={k}>
                                        <Link 
                                        // to={`/feature-live-stream/${o.id}`} 
                                        onClick = { () => {
                                            
                                            if (o.subscribed === 1) {
                                                
                                                history.push(`/feature-live-stream/${event_id}/${o.id}`)
                                                               
                                            } else {
                                                
                                                this.playVideo(o.subscribed, o.live_stream, o.event_amount, o.id)
                                            }
                                        }
                                            
                                        }
                                        className="art-img art-background"
                                            // style={{ backgroundImage: `url(${o.s3_thumbnail_image_260 !== null 
                                            // ? o.s3_thumbnail_image_260 
                                            // : o.thumbnail_image !== null
                                            // ? o.thumbnail_image
                                            // : o.custom_feature_image_url})` }}
                                            >
                                            <img src= {o.img_url}
                                            alt="img" />
                                           {/* <span className="video-label"><img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span> */}
                                        </Link>
                                        <div className="art-cont">
                                            {/* <Link to={`/category/${(o.cat_name) ? (o.cat_name).split(',')[0] : ''}`}>
                                                <span className="tag">{cat_name}</span>
                                            </Link> */}
                                            <a href="javascript:;" className="favorite" 
                                            data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                onClick={(e) => {
                                                    this.bucketList(e)
                                                }}>

                                                {/* <img className="outline lazyload" data-src={image} alt="icon" data-article-id={o.ID} /> */}
                                                {/* <img
                                                    className="filled lazyload"
                                                    data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                    alt="icon"
                                                /> */}
                                            </a>
                                            <Link
                                            //  to={`/feature-live-stream/${o.id}`} 
                                            onClick = { () => {
                                            
                                                if (o.subscribed === 1) {
                                                    
                                                    history.push(`/feature-live-stream/${event_id}/${o.id}`)
                                                                   
                                                } else {
                                                    
                                                    this.playVideo(o.subscribed, o.live_stream, o.event_amount, o.id)
                                                }
                                            }
                                                
                                            } 
                                             className="art-title">
                                                {o.name}
                                            </Link>
                                            <span className="date-time">
                                                <Moment format='DD MMM YYYY'>{o.date_start}</Moment>
                                            </span>
                                        </div>
                                    </div>
                                })}</div>)

                            }
                    </div>
                </div>
            </section>
            <div
            className="modal fade submit-entry"
            id="success-pop-subscribed-video-sec"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
           >
           <div className="modal-dialog modal-dialog-centered" data-id = {this.state.amount} role="document">
               <div className="modal-content">
               <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
               >
                   <img src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"} alt="icon" />
               </button>
               <div className="modal-body success-pop">
                   {/* <img className="mb-3" src={process.env.PUBLIC_URL+"/assets/images/green-check.svg"} alt="icon" /> */}
                   <h3 className="mb-3">To watch videos please subscribe now</h3>
                   <StripeCheckout
                       amount={this.state.amount}
                       billingAddress
                       shippingAddress
                       name="subscribe now." // the pop-in header title
                       // description="Big Data Stuff" // the pop-in header subtitle
                       // className="btn btn-orange" 
                       style = {{marginLeft:'900px'}}
                       // customInput={<input type="text" id="coupon" placeholder="Do You have a coupon code?"/>}
                       // description="Awesome Product"
                       // image="assets/images/logo-small.png"
                       stripeKey="pk_test_51GwUThARRSyCmdWnhY2AOexGvuotGtH8QMd1Uit4vk6DNj6KifR6hZUX7trwcdcgv4RwyO3Yb8LS8NxuSrmVYkMd00HXcjZCI8"
                       token={this.onToken}
                   >
               <button
               type="submit"
               className="btn btn-asphalt succ_ok" 
               
               onClick={(e) => {
                   window.jQuery('#success-pop-subscribed-video-sec').modal('hide')
               }}
               >
               SUBSCRIBE NOW
               </button>
                   </StripeCheckout> 
                </div>
                {/* <div className="modal-body success-btm">
                    <button className="btn btn-white mr-2"
                       onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                    >View all submissions</button>
                    <button className="btn btn-white"
                       onClick = {e =>{ window.$('#success-pop').modal('hide')} }
                    >Editor's Pick</button>
                </div> */}
                </div>
            </div>
            </div>
        </>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        latestArticlesList: state.FeatureParent.latestArticles,
        bucketItem: state.Header.bucketItem,
        livtStreamVideos: state.FeatureParent.livtStreamVideos
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getLatestArticlesList: (data) => dispatch(actions.getLatestArticlesList(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
        subscribeEvent: (data) => dispatch(actions.subscribeEvent(data))

    }
};

const livestream = connect(
    mapStateToProps,
    mapDispatchToProps,
)(LiveStream);

export default livestream;



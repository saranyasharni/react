import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Feature_Parent';
import * as headerActions from '../../actions/common/Header';
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class Featured_Articles extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.latestArticlesList.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });
            }

        })

    }

    componentDidUpdate() {
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.latestArticlesList.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });


            }

        })
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        var url = jQuery(e.target).closest(".article-item").find('.art-background img').attr('src')
        // var url = jQuery(e.target).closest(".article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".article-item").find('.art-cont .art-title').text())
    }

    render() {

        return (

            <section className="container-fluid bg-gray mb-5" id="news">
                <div className="row">
                    <div className="container">
                        <h3 className="title">
                            {/* Latest Articles */}
                            {/* EVENT details */}
                            News
                        </h3>
                        <div className={this.props.latestArticlesList.length > 0 ? 'd-none' : 'd-block'}>
                            <h3 className="noarticle">No Articles</h3>
                        </div>
                            {
                                this.props.latestArticlesList.length > 0 &&
                                (<div className="snip-caurosel owl-carousel">
                                {this.props.latestArticlesList.map((o, k) => {
                                    var cat_name = (o.cat_name) ? (o.cat_name).split(',') : '';
                                    cat_name = cat_name ? (cat_name[1] === undefined) ? cat_name[0] : cat_name[1] : '';
                                    var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                    return <div className="article-item" key={o.ID}>
                                        <Link to={`/feature/${o.post_name}`} className="art-img art-background"
                                            // style={{ backgroundImage: `url(${o.s3_thumbnail_image_260 !== null 
                                            // ? o.s3_thumbnail_image_260 
                                            // : o.thumbnail_image !== null
                                            // ? o.thumbnail_image
                                            // : o.custom_feature_image_url})` }}
                                            >
                                            {
                                            jQuery(window).width() <= 767 ? (
                                            <img src={
                                                    o.custom_feature_image_url !== null 
                                                        ? o.custom_feature_image_url 
                                                        : o.thumbnail_image 
                                                }
                                                alt="img" 
                                                />
                                            ): (
                                                <img
                                                    className="lazyload"
                                                    data-src={o.s3_thumbnail_image_260 !== null 
                                                    ? o.s3_thumbnail_image_260 
                                                    : o.thumbnail_image !== null
                                                    ? o.thumbnail_image
                                                    : o.custom_feature_image_url}
                                                    alt="image"
                                                />
                                            )
                                            }
                                            {(o.video_file === null || o.video_file === undefined) ? '' : <span className="video-label"><img src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span>}
                                        </Link>
                                        <div className="art-cont">
                                            <Link to={`/category/${(o.cat_name) ? (o.cat_name).split(',')[0] : ''}`}>
                                                <span className="tag">{cat_name}</span>
                                            </Link>
                                            <a href="javascript:;" className="favorite" data-id={o.ID} data-bucket-id={o.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                onClick={(e) => {
                                                    this.bucketList(e)
                                                }}>

                                                <img className="outline lazyload" data-src={image} alt="icon" data-article-id={o.ID} />
                                                <img
                                                    className="filled lazyload"
                                                    data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                    alt="icon"
                                                />
                                            </a>
                                            <Link to={`/feature/${o.post_name}`} className="art-title">
                                                {o.post_title}
                                            </Link>
                                            <span className="date-time">
                                                <Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment>
                                            </span>
                                        </div>
                                    </div>
                                })}</div>)

                            }
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        latestArticlesList: state.FeatureParent.latestArticles,
        bucketItem: state.Header.bucketItem,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getLatestArticlesList: (data) => dispatch(actions.getLatestArticlesList(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    }
};

const featureArticles = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Featured_Articles);

export default featureArticles;



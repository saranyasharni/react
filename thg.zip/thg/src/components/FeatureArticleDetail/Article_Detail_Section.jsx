/** @format */

import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import * as actions from "../../actions/Article_Detail";
import * as headerActions from "../../actions/common/Header";
import jQuery from "jquery";
import Moment from "react-moment";
import { Link } from "react-router-dom";
import ReactPlayer from 'react-player/lazy';
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";
import fetch from "node-fetch";
import {
  FacebookShareCount,
  FacebookShareButton,
  FacebookIcon,
  TwitterIcon,
  TwitterShareButton,
  WhatsappIcon,
  WhatsappShareButton,
} from "react-share";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import ReactStars from "react-rating-stars-component";

import ReactGA from "react-ga";
import AdSense from 'react-adsense';
class Popular_Articles extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    jQuery.getJSON("https://api.ipify.org?format=json", function (data) {
      // console.log("data", data);
      localStorage.setItem("ip_address", data.ip);
    });
  }

  componentDidMount() {
  
    if (window.location.pathname === '/the-us-open-dogged-with-withdrawals-and-criticism-is-trotting-ahead') {
      jQuery("iframe").css('height', '300px')
    }
    jQuery('.content_art').find('p').children('.size-full').closest('p').find('em').css('font-size', '12px')
    jQuery('.content_art').find('p').children('.size-full').closest('p').find('p').css('font-size', '12px')
    
    var THIS = this;
    jQuery(document).ready(function () {
      if (
        THIS.props.articleDetail.length > 0  &&
        THIS.props.articleDetail[0].relatedArticles.length > 0
      ) {
        window.$(".mscroll-y-inside").mCustomScrollbar({
          axis: "y",
          scrollEasing: "linear",
          scrollInertia: 300,
          autoHideScrollbar: "true",
          autoExpandScrollbar: "true",
          scrollbarPosition: "inside",
        });
      }
    });
  }

  componentDidUpdate() {
    var THIS = this;
    
    jQuery(document).ready(function () {
      jQuery(".art-description").find("a").attr("target", "_blank");
      jQuery('.content_art').find('p').children('.size-full').closest('p').find('em').css('font-size', '12px')
      jQuery('.content_art').find('p').children('.size-full').closest('p').find('a').css('font-size', '12px')
    
      if (
        THIS.props.articleDetail.length > 0 &&
        THIS.props.articleDetail[0].relatedArticles.length > 0
      ) {
        THIS.props.updateDesignState(true);

        window.$(".mscroll-y-inside").mCustomScrollbar({
          axis: "y",
          scrollEasing: "linear",
          scrollInertia: 300,
          autoHideScrollbar: "true",
          autoExpandScrollbar: "true",
          scrollbarPosition: "inside",
        });
      }
      jQuery(".change-pass")
        .off("click")
        .click(function () {
          jQuery(".change-pass-encl").slideUp();
          jQuery(".change-pass").show();
          jQuery(this).hide();
          jQuery(this).parent().find(".change-pass-encl").slideToggle();
          THIS.props.updateCommentReview("rating", 0);
        });

      jQuery(".cancel-pass")
        .off("click")
        .click(function () {
          jQuery(".change-pass").show();
          jQuery(".change-pass-encl").slideUp();
          THIS.props.updateCommentReview("rating", 0);
        });
    });

    if (THIS.props.commentStatus === 1) {
      ReactGA.event({
        category: "Comment",
        action: "Add Comment Success",
        label: this.props.articleDetail[0].post_title,
      });
      jQuery(".rating-item").find("a").removeClass("active");
      jQuery(".add-comment .alert").html(
        "<strong>Success!</strong> Comment Created Successfully."
      );
      jQuery(".add-comment .alert")
        .removeClass("alert-danger")
        .addClass("alert-success");
      setTimeout(function () {
        jQuery(".add-comment .alert").removeClass("alert-success");
      }, 2000);
      THIS.props.updateCommentReview("commentStatus", 0);
      THIS.props.updateCommentReview("comment_review", "");
    } else if (THIS.props.commentStatus === 2) {
      jQuery(".add-comment .alert").html(
        "<strong>Error!</strong> Failed To Add Comment."
      );
      jQuery(".add-comment .alert")
        .removeClass("alert-success")
        .addClass("alert-danger");
      setTimeout(function () {
        jQuery(".add-comment .alert").removeClass("alert-danger");
      }, 2000);
      THIS.props.updateCommentReview("commentStatus", 0);
    }

    if (THIS.props.replyCommentStatus === 1) {
      jQuery(".rating-item").find("a").removeClass("active");
      jQuery(".reply-section .alert").html(
        "<strong>Success!</strong> Comment Created Successfully."
      );
      jQuery(".reply-section .alert")
        .removeClass("alert-danger")
        .addClass("alert-success");
      setTimeout(function () {
        jQuery(".reply-section .alert").removeClass("alert-success");
      }, 2000);
      setTimeout(function () {
        jQuery(".change-pass").show();
        jQuery(".change-pass-encl").slideUp();
      }, 1000);
      THIS.props.updateCommentReview("replyCommentStatus", 0);
      THIS.props.updateCommentReview("reply_comment_review", "");
    } else if (THIS.props.replyCommentStatus === 2) {
      jQuery(".reply-section .alert").html(
        "<strong>Error!</strong> Failed To Add Comment."
      );
      jQuery(".reply-section .alert")
        .removeClass("alert-success")
        .addClass("alert-danger");
      setTimeout(function () {
        jQuery(".reply-section .alert").removeClass("alert-danger");
      }, 2000);
      THIS.props.updateCommentReview("replyCommentStatus", 0);
    }

    jQuery(".rating-item")
      .off("click")
      .click(function () {
        jQuery(".rating-item").find("a").removeClass("active");
        jQuery(this).prevAll().find("a").addClass("active");
        jQuery(this).find("a").addClass("active");
        console.log("count", jQuery(".rating-item").find("a.active").length);
        THIS.props.updateCommentReview(
          "rating",
          jQuery(".rating-item").find("a.active").length
        );
      });
  }

  createComment(e) {
    e.preventDefault();
    this.props.createCommentForArticle({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      article_id: this.props.articleDetail[0].ID,
      comment_content: this.props.comment_review,
      author_ip: localStorage.getItem("ip_address"),
      author_name: localStorage.getItem("user_login"),
      email_id: localStorage.getItem("user_email"),
      rating_count: this.props.rating,
    });
  }

  replyComment(e) {
    e.preventDefault();
    this.props.replyCommentForArticle({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      article_id: this.props.articleDetail[0].ID,
      comment_content: this.props.reply_comment_review,
      author_ip: localStorage.getItem("ip_address"),
      author_name: localStorage.getItem("user_login"),
      email_id: localStorage.getItem("user_email"),
      rating_count: this.props.rating,
      comment_id: this.props.comment_id,
    });
  }

  componentWillUnmount() {
    localStorage.setItem("article_detail", false);
  }

  share_on_fb = (title, description) => {
    ReactGA.event({
      category: "Share On Facebook",
      action: "Share Article",
      label: title,
    });
    var url = window.location.href;
    window.open(
      "http://www.facebook.com/sharer/sharer.php?s=100&p[title]=" +
        decodeURIComponent(title) +
        "&u=" +
        encodeURIComponent(url) +
        "&p[summary]=" +
        description,
      "sharer",
      "toolbar=0,status=0,width=600,height=360"
    );
  };

  replaceCumulative(str, find, replace) {
    for (var i = 0; i < find.length; i++) {
      str = str.split(find[i]).join(replace[i]);
    }
    return str;
  }
  replaceVideoCumulative(str, find, replace) {
   
    for (var i = 0; i < find.length; i++) {
   
      str = str.split(find[i]).join(replace[i]);
    }
    //console.log(str, 'str345')
    return str;
  }


  bucketList(e) {
    this.props.changeBucketItem(
      "article_id",
      jQuery(e.target).closest(".favorite").attr("data-id")
    );
    var bucketId = jQuery(e.target).closest(".favorite").attr("data-bucket-id");
    this.props.changeBucketItem("bucket_id", bucketId ? bucketId : "");
    var url = jQuery(".article-hero-img img").attr("src");
    var tit = [];
    jQuery(".tag-wrap span").each(function () {
      tit.push(jQuery(this).text());
    });
    jQuery("#bucket-list")
      .find(".article-item")
      .find(".art-img img")
      .attr("src", url);
    jQuery("#bucket-list")
      .find(".article-item")
      .find(".art-cont span.tag")
      .text(tit[0]);
    jQuery("#bucket-list")
      .find(".article-item")
      .find(".art-cont p")
      .text(jQuery(".article-title").text());
    localStorage.setItem("save_item", jQuery(".article-title").text());
  }

  whatsappShare() {
    ReactGA.event({
      category: "Share On Whatsapp",
      action: "Share Article",
      label: this.props.articleDetail[0].post_title,
    });
  }

  twitterShare() {
    ReactGA.event({
      category: "Share On Twitter",
      action: "Share Article",
      label: this.props.articleDetail[0].post_title,
    });
  }

  render() {
    return (
      <section className="container-fluid article-content">
        <div className="row">
          <div className="container">
            {this.props.articleDetail.length > 0 &&
              this.props.articleDetail.map((o, k) => {
                var content = o.post_content;
                content = this.replaceVideoCumulative(
                  o.post_content,
                  ["][/video]"],
                  ["</video>"]
                );
                content = this.replaceCumulative(
                  o.post_content,
                  ["[/caption]"],
                  ["</caption>"]
                );
                content = content.replace(/\r\n/g, "</p><p>");
                content = content.replace(/\[embed]/g, "");
                content = content.replace(/\[\/embed]/g, "");
                content = content.replace(/\/\/embed/g, "/embed");
                content = content.replace(/\[video/g, "<video>"); 
                content = ReactHtmlParser(
                
                content.replace(
                    /\[caption([^\]]+)align="([^"]+)"\s+width="(\d+)"\]/g,
                    ""
                  ), {
                    transform: function  transform(node, index) {
                      if (node.type === 'tag' && node.name === 'img') {
                        let cls = node.attribs.class
                        node.attribs.class = `${cls} lazyload`;
                        return convertNodeToElement(node, index, transform);
                      }
                      if (node.type === 'tag' && node.name === 'video') {
                        node.attribs.controls = 'controls'
                        node.attribs.width="700" 
                        node.attribs.height="400"
                        
                        let mp4 = node.children[0].data.split('mp4=')[1].replace('"','')
                        let video = mp4.replace('"', '').replace('][/video]', '')

                        node.children[0].data =  <source src={video} type="video/mp4"></source>
                        return convertNodeToElement(node, index, transform);
                      }
                    }
                  }
                );
                var cat_name = o.cat_name ? o.cat_name.split(",") : [];
                var cat_name_arr = [];
                cat_name.forEach((element, i) => {

                  cat_name_arr.push(<span key={i}>{element}</span>);
                });
                return (
                  <div className="row" key={o.ID}>
                    <div className="col-12 text-center mb-5">
                      {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"} alt="Ad" /> */}
                    </div>
                    <div className="col-md-8">
                      <div className="row">
                        <div className="col-12 mb-3">
                          <div className="article-hero-img mb-3">
                          {
                              o.custom_s3_video_link ?
                              (
                                <>
                                <ReactPlayer className="title_thumb_video mt-0" url={o.custom_s3_video_link}
                               
                                  config={{ file: { 
                                      attributes: {
                                        controlsList: 'nodownload'
                                      }
                                    }}}
                                    
                                  controls  />
                                </>
                              ) :
                              (
                                <>
                              <img
                              className="img-fluid lazyload"
                              data-src={
                                o.custom_feature_image_url === undefined ||
                                o.custom_feature_image_url === null ||
                                o.custom_feature_image_url === ""
                                  ? o.image_url
                                  : o.custom_feature_image_url
                              }
                              alt="image"
                            />

                            </>
                              )
                            }
                          </div>
                          <div className="article-head">
                            <div className="img-credit mb-4">
                              <p className="text-left">
                                {o.feat_img_credit_text
                                  ? o.feat_img_credit_text
                                  : ""}
                              </p>
                            </div>
                            {/* <div className="tag-wrap">{cat_name_arr}</div> */}
                            <div className="share-sec text-right">
                              <button
                                className="favorite"
                                data-id={o.ID}
                                data-bucket-id={o.bucket_id}
                                data-toggle="modal"
                                data-target={
                                  localStorage.user_id
                                    ? o.bucket_list_status === 1
                                      ? "#remove-article"
                                      : "#bucket-list"
                                    : "#signup-modal"
                                }
                                onClick={(e) => {
                                  localStorage.setItem("article_detail", true);
                                  this.bucketList(e);
                                }}
                              >
                                <img
                                  className="lazyload"
                                  data-src={
                                    o.bucket_list_status === 1
                                      ? process.env.PUBLIC_URL +
                                        "/assets/images/heart-lg-filled.svg"
                                      : process.env.PUBLIC_URL +
                                        "/assets/images/heart-lg.svg"
                                  }
                                  alt="icon"
                                  data-article-id={o.ID}
                                />
                                <img
                                  className="filled lazyload"
                                  data-src={
                                    process.env.PUBLIC_URL +
                                    "/assets/images/heart-lg-filled.svg"
                                  }
                                  alt="icon"
                                />
                              </button>
                              <div className="article-share-btn">
                                <button className="share">
                                  <img
                                    className="lazyload"
                                    data-src={
                                      process.env.PUBLIC_URL +
                                      "/assets/images/share.svg"
                                    }
                                    alt="icon"
                                  />
                                </button>
                                <div className="article-share-sec">
                                  <a
                                    className="fb-btn"
                                    onClick={() =>
                                      this.share_on_fb(
                                        this.props.articleDetail[0].post_title,
                                        "description"
                                      )
                                    }
                                  >
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/fb-icon.svg"
                                      }
                                      alt="icon"
                                      style={{ cursor: "pointer" }}
                                    />
                                  </a>
                                  {/* <a href="whatsapp://send" data-text="Text you want to Share" class="wa_btn wa_btn_s" data-href="URL you want to share" >
                              <button>Share on WhatsApp</button>
                            </a> */}
                                  {/* <a className="fb-btn" onClick={this.share_on_fb('title', 'description')}><i className="fa fa-facebook" aria-hidden="true"></i></a> */}
                                  {/* <FacebookShareButton
                              url={window.location.href}
                              quote={"hi hello this is my article"}
                              className="Demo__some-network__share-button"
                            >
                              <FacebookIcon size={32} round />
                            </FacebookShareButton> */}
                                  <br />
                                  {/* <a href="javascript:;">
                              <img src={"../../assets/images/articledetail/fb-icon.svg"} alt="icon" />
                              Facebook
                            </a> */}
                                  {/* <a href="javascript:;">
                              <img src={"../../assets/images/articledetail/insta-icon.svg"} alt="icon" />
                              Instagram
                            </a> */}
                                  <WhatsappShareButton
                                    url={window.location.href}
                                    title={"whatsapp"}
                                    separator=":: "
                                    className="Demo__some-network__share-button"
                                    onShareWindowClose={() =>
                                      this.whatsappShare()
                                    }
                                  >
                                    <WhatsappIcon size={32} round />
                                  </WhatsappShareButton>
                                  <br />
                                  <TwitterShareButton
                                    url={window.location.href}
                                    title={"Twitter"}
                                    className="Demo__some-network__share-button"
                                    onShareWindowClose={() =>
                                      this.twitterShare()
                                    }
                                  >
                                    <TwitterIcon size={32} round />
                                  </TwitterShareButton>
                                  {/* <a href="javascript:;">
                              <img src={"../../assets/images/articledetail/twitter-icon.svg"} alt="icon" />
                              Twitter
                            </a> */}
                                </div>
                              </div>
                              {/* <button className="share">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/share.svg"} alt="icon" />
                                                        </button> */}
                            </div>
                            <h1 className="article-title mt-4">
                              {o.post_title}
                            </h1>
                            <span className="post-by">
                              - {o.display_name} (
                              <Moment format="DD MMM YYYY" withTitle>
                                {o.post_date_gmt}
                              </Moment>
                              )
                            </span>
                          </div>
                          {/* <AdSense.Google
                            client='ca-pub-9111417808865977'
                            slot='1638754887'
                            style={{ display: 'block', width: 720, margin: "auto" }}
                            format='auto'
                            responsive='true'
                            layout="display"
                            layoutKey='-gw-1+2a-9x+5c'
                            /> */}
                          <div className="article-content art-description mt-4 article-content-main">
                            {/* var caption_replace = replace_embed_code; */}

                            <p className= 'content_art'>{content}</p>
                          </div>
                          {/* <AdSense.Google
                            client='ca-pub-9111417808865977'
                            slot='9857840469'
                            style={{ display: 'block', width: 720, margin: "auto" }}
                            format='auto'
                            responsive='true'
                            layout="display"
                            layoutKey='-gw-1+2a-9x+5c'
                            />   */}
                          <div
                            className={
                              cat_name.includes("Review")
                                ? "share-item mt-4 mb-5"
                                : "share-item mt-4 mb-5 d-none"
                            }
                          >
                            <strong>Overall Rating</strong>
                            <ReactStars
                              count={5}
                              value={localStorage.getItem("over")}
                              size={24}
                              isHalf={true}
                              emptyIcon={<i className="far fa-star"></i>}
                              halfIcon={<i className="fa fa-star-half-alt"></i>}
                              fullIcon={<i className="fa fa-star"></i>}
                              activeColor="#FF8800"
                            />
                          </div>
                          {/* <div className="post-nav btn-group mt-3">

                                                    <Link to={`/${o.prevArticle.post_name}`} className="btn">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                                        {o.prevArticle.post_title}
                                                    </Link>
                                                    <Link to={`/${o.nextArticle.post_name}`} className="btn">
                                                        {o.nextArticle.post_title}
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                                    </Link>
                                                </div> */}
                          <hr className="my-5" />
                          <div
                            className={
                              cat_name.includes("Review")
                                ? "comment-wrap mb-5 d-none"
                                : "comment-wrap mb-5"
                            }
                          >
                            <h4>Comments</h4>
                            <form className="add-comment mt-3 mb-5 text-right">
                              <div className="alert" role="alert"></div>
                              <textarea
                                className="form-control"
                                rows={5}
                                placeholder="Add Comment..."
                                value={this.props.comment_review}
                                onChange={(e) =>
                                  this.props.updateCommentReview(
                                    "comment_review",
                                    e.target.value
                                  )
                                }
                              />
                              <button
                                type="button"
                                className="btn btn-orange"
                                onClick={(e) => {
                                  localStorage.user_id
                                    ? this.createComment(e)
                                    : window
                                        .jQuery("#signup-modal")
                                        .modal("show");
                                }}
                              >
                                Comment
                              </button>
                            </form>
                            <div className="comment-sec">
                              {this.props.commentsList.length > 0 &&
                                this.props.commentsList.map((c, b) => {
                                  return (
                                    <div
                                      className="comment mb-4"
                                      key={c.comment_ID}
                                      data-id={c.comment_ID}
                                    >
                                      <div className="avatar">
                                        <img
                                          className="img-fluid lazyload"
                                          data-src={
                                            c.user_avatar
                                              ? c.user_avatar
                                              : process.env.PUBLIC_URL +
                                                "/assets/images/avatar.png"
                                          }
                                          alt="avatar"
                                        />
                                      </div>
                                      <div className="comment-item">
                                        <span className="name">
                                          {c.comment_author}
                                        </span>
                                        <p>{c.comment_content}</p>
                                        <span className="date-time">
                                          <Moment fromNow>
                                            {c.comment_date}
                                          </Moment>
                                        </span>
                                        <br />
                                        <a
                                          href="javascript:;"
                                          className="reply change-pass"
                                          onClick={(e) => {
                                            jQuery(e.target)
                                              .closest(".comment-item")
                                              .find(".loader-pro")
                                              .removeClass("d-none");
                                            jQuery(e.target)
                                              .closest(".comment-item")
                                              .find(".loader-pro")
                                              .addClass("d-block");
                                            this.props.updateCommentReview(
                                              "comment_id",
                                              jQuery(e.target)
                                                .closest(".comment")
                                                .data("id")
                                            );
                                            this.props.getSubComments({
                                              comment_id: jQuery(e.target)
                                                .closest(".comment")
                                                .data("id"),
                                            });
                                          }}
                                        >
                                          Reply
                                        </a>
                                        <div
                                          className="loader-pro d-none"
                                          style={{
                                            marginLeft: "25%",
                                            marginRight: "67%",
                                            marginTop: "6%",
                                          }}
                                        >
                                          <img
                                            className="img-fluid lazyload"
                                            data-src={
                                              process.env.PUBLIC_URL +
                                              "/assets/images/loading.gif"
                                            }
                                            alt="Avatar"
                                          />
                                        </div>
                                        <div className="change-pass-encl mt-4 mb-0">
                                          {this.props.subCommentsList.length >
                                            0 &&
                                            this.props.subCommentsList.map(
                                              (s, t) => {
                                                return (
                                                  <div className="child-comment mt-3">
                                                    <div className="avatar">
                                                      <img
                                                        className="img-fluid lazyload"
                                                        data-src={
                                                          s.user_avatar
                                                            ? s.user_avatar
                                                            : process.env
                                                                .PUBLIC_URL +
                                                              "/assets/images/avatar.png"
                                                        }
                                                        alt="avatar"
                                                      />
                                                    </div>
                                                    <div className="comment-item">
                                                      <span className="name">
                                                        {s.comment_author}
                                                      </span>
                                                      <p>{s.comment_content}</p>
                                                      <span className="date-time">
                                                        <Moment fromNow>
                                                          {s.comment_date}
                                                        </Moment>
                                                      </span>
                                                      <br />
                                                    </div>
                                                  </div>
                                                );
                                              }
                                            )}

                                          <div className="child-comment mt-3">
                                            <div className="comment-item">
                                              <form className="reply-section mt-3 mb-5 text-right">
                                                <div
                                                  className="alert text-left"
                                                  role="alert"
                                                ></div>
                                                <textarea
                                                  className="form-control reply-comment"
                                                  rows={5}
                                                  placeholder="Add Comment..."
                                                  value={
                                                    this.props
                                                      .reply_comment_review
                                                  }
                                                  onChange={(e) =>
                                                    this.props.updateCommentReview(
                                                      "reply_comment_review",
                                                      e.target.value
                                                    )
                                                  }
                                                />
                                                <button
                                                  className="btn btn-trans cancel-pass"
                                                  type="button"
                                                  style={{ marginTop: "10px" }}
                                                >
                                                  Cancel
                                                </button>
                                                <button
                                                  type="button"
                                                  className="btn btn-orange"
                                                  onClick={(e) => {
                                                    localStorage.user_id
                                                      ? this.replyComment(e)
                                                      : window
                                                          .jQuery(
                                                            "#signup-modal"
                                                          )
                                                          .modal("show");
                                                  }}
                                                >
                                                  Comment
                                                </button>
                                              </form>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                          <div
                            className={
                              cat_name.includes("Review")
                                ? "add-comment comment-wrap mb-5"
                                : "add-comment comment-wrap mb-5 d-none"
                            }
                          >
                            <h4 className="mb-4">Rate &amp; Review</h4>
                            <div className="alert" role="alert"></div>
                            <div className="mb-4">
                              <ul className="list-inline rating-star">
                                <li className="list-inline-item rating-item mr-0">
                                  <a href="javascript:;" className="">
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/star-orange.svg"
                                      }
                                      alt="icon"
                                    />
                                  </a>
                                </li>
                                <li className="list-inline-item rating-item mr-0">
                                  <a href="javascript:;" className="">
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/star-orange.svg"
                                      }
                                      alt="icon"
                                    />
                                  </a>
                                </li>
                                <li className="list-inline-item rating-item mr-0">
                                  <a href="javascript:;" className="">
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/star-orange.svg"
                                      }
                                      alt="icon"
                                    />
                                  </a>
                                </li>
                                <li className="list-inline-item rating-item mr-0">
                                  <a href="javascript:;">
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/star-orange.svg"
                                      }
                                      alt="icon"
                                    />
                                  </a>
                                </li>
                                <li className="list-inline-item rating-item mr-0">
                                  <a href="javascript:;">
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/star-orange.svg"
                                      }
                                      alt="icon"
                                    />
                                  </a>
                                </li>
                              </ul>
                              {/* <span className="review-range">Good</span> */}
                            </div>
                            <form className="add-comment mt-3 mb-5 text-right">
                              <textarea
                                className="form-control"
                                rows={5}
                                placeholder="Write your review..."
                                value={this.props.comment_review}
                                onChange={(e) =>
                                  this.props.updateCommentReview(
                                    "comment_review",
                                    e.target.value
                                  )
                                }
                              />
                              <button
                                type="button"
                                className="btn btn-orange"
                                onClick={(e) => {
                                  localStorage.user_id
                                    ? this.createComment(e)
                                    : window
                                        .jQuery("#signup-modal")
                                        .modal("show");
                                }}
                              >
                                Submit
                              </button>
                            </form>
                            <div className="comment-sec">
                              {this.props.commentsList.length > 0 &&
                                this.props.commentsList.map((c, b) => {
                                  return (
                                    <div
                                      className="comment mb-4"
                                      key={c.comment_ID}
                                      data-id={c.comment_ID}
                                    >
                                      <div className="avatar">
                                        <img
                                          className="img-fluid lazyload"
                                          data-src={
                                            c.user_avatar
                                              ? c.user_avatar
                                              : process.env.PUBLIC_URL +
                                                "/assets/images/avatar.png"
                                          }
                                          alt="avatar"
                                        />
                                      </div>
                                      <div className="comment-item">
                                        <span className="name clearfix">
                                          {c.comment_author}
                                        </span>
                                        <span
                                          className={`badge ${
                                            c.rating
                                              ? c.rating > 3
                                                ? "badge-success"
                                                : c.rating > 2
                                                ? "badge-warning"
                                                : "badge-danger"
                                              : "badge-danger"
                                          }`}
                                        >
                                          {c.rating}
                                          <img
                                            className="lazyload"
                                            data-src={
                                              process.env.PUBLIC_URL +
                                              "/assets/images/star-orange.svg"
                                            }
                                            alt="icon"
                                          />
                                        </span>
                                        <p>{c.comment_content}</p>
                                        <span className="date-time">
                                          <Moment fromNow>
                                            {c.comment_date}
                                          </Moment>
                                        </span>
                                        <br />
                                        <a
                                          href="javascript:;"
                                          className="reply change-pass"
                                          onClick={(e) => {
                                            jQuery(e.target)
                                              .closest(".comment-item")
                                              .find(".loader-pro")
                                              .removeClass("d-none");
                                            jQuery(e.target)
                                              .closest(".comment-item")
                                              .find(".loader-pro")
                                              .addClass("d-block");
                                            this.props.updateCommentReview(
                                              "comment_id",
                                              jQuery(e.target)
                                                .closest(".comment")
                                                .data("id")
                                            );
                                            this.props.getSubComments({
                                              comment_id: jQuery(e.target)
                                                .closest(".comment")
                                                .data("id"),
                                            });
                                          }}
                                        >
                                          Reply
                                        </a>
                                        <div
                                          className="loader-pro d-none"
                                          style={{
                                            marginLeft: "25%",
                                            marginRight: "67%",
                                            marginTop: "6%",
                                          }}
                                        >
                                          <img
                                            className="img-fluid lazyload"
                                            data-src={
                                              process.env.PUBLIC_URL +
                                              "/assets/images/loading.gif"
                                            }
                                            alt="Avatar"
                                          />
                                        </div>
                                        <div className="change-pass-encl mt-4 mb-0">
                                          {this.props.subCommentsList.length >
                                            0 &&
                                            this.props.subCommentsList.map(
                                              (s, t) => {
                                                return (
                                                  <div className="child-comment mt-3">
                                                    <div className="avatar">
                                                      <img
                                                        className="img-fluid lazyload"
                                                        data-src={
                                                          s.user_avatar
                                                            ? s.user_avatar
                                                            : process.env
                                                                .PUBLIC_URL +
                                                              "/assets/images/avatar.png"
                                                        }
                                                        alt="avatar"
                                                      />
                                                    </div>
                                                    <div className="comment-item">
                                                      <span className="name clearfix">
                                                        {s.comment_author}
                                                      </span>
                                                      <span
                                                        className={`badge ${
                                                          s.rating
                                                            ? s.rating > 3
                                                              ? "badge-success"
                                                              : s.rating > 2
                                                              ? "badge-warning"
                                                              : "badge-danger"
                                                            : "badge-danger"
                                                        }`}
                                                      >
                                                        {s.rating}
                                                        <img
                                                          className="lazyload"
                                                          data-src={
                                                            process.env
                                                              .PUBLIC_URL +
                                                            "/assets/images/star-orange.svg"
                                                          }
                                                          alt="icon"
                                                        />
                                                      </span>
                                                      <p>{s.comment_content}</p>
                                                      <span className="date-time">
                                                        <Moment fromNow>
                                                          {s.comment_date}
                                                        </Moment>
                                                      </span>
                                                      <br />
                                                    </div>
                                                  </div>
                                                );
                                              }
                                            )}

                                          <div className="child-comment mt-3">
                                            <div className="mb-4">
                                              <ul className="list-inline rating-star">
                                                <li className="list-inline-item rating-item mr-0">
                                                  <a
                                                    href="javascript:;"
                                                    className=""
                                                  >
                                                    <img
                                                      className="lazyload"
                                                      data-src={
                                                        process.env.PUBLIC_URL +
                                                        "/assets/images/star-orange.svg"
                                                      }
                                                      alt="icon"
                                                    />
                                                  </a>
                                                </li>
                                                <li className="list-inline-item rating-item mr-0">
                                                  <a
                                                    href="javascript:;"
                                                    className=""
                                                  >
                                                    <img
                                                      className="lazyload"
                                                      data-src={
                                                        process.env.PUBLIC_URL +
                                                        "/assets/images/star-orange.svg"
                                                      }
                                                      alt="icon"
                                                    />
                                                  </a>
                                                </li>
                                                <li className="list-inline-item rating-item mr-0">
                                                  <a
                                                    href="javascript:;"
                                                    className=""
                                                  >
                                                    <img
                                                      className="lazyload"
                                                      data-src={
                                                        process.env.PUBLIC_URL +
                                                        "/assets/images/star-orange.svg"
                                                      }
                                                      alt="icon"
                                                    />
                                                  </a>
                                                </li>
                                                <li className="list-inline-item rating-item mr-0">
                                                  <a href="javascript:;">
                                                    <img
                                                      className="lazyload"
                                                      data-src={
                                                        process.env.PUBLIC_URL +
                                                        "/assets/images/star-orange.svg"
                                                      }
                                                      alt="icon"
                                                    />
                                                  </a>
                                                </li>
                                                <li className="list-inline-item rating-item mr-0">
                                                  <a href="javascript:;">
                                                    <img
                                                      className="lazyload"
                                                      data-src={
                                                        process.env.PUBLIC_URL +
                                                        "/assets/images/star-orange.svg"
                                                      }
                                                      alt="icon"
                                                    />
                                                  </a>
                                                </li>
                                              </ul>
                                              {/* <span className="review-range">Good</span> */}
                                            </div>
                                            <div className="comment-item">
                                              <form className="reply-section mt-3 mb-5 text-right">
                                                <div
                                                  className="alert text-left"
                                                  role="alert"
                                                ></div>
                                                <textarea
                                                  className="form-control reply-comment"
                                                  rows={5}
                                                  placeholder="Add Comment..."
                                                  value={
                                                    this.props
                                                      .reply_comment_review
                                                  }
                                                  onChange={(e) =>
                                                    this.props.updateCommentReview(
                                                      "reply_comment_review",
                                                      e.target.value
                                                    )
                                                  }
                                                />
                                                <button
                                                  className="btn btn-trans cancel-pass"
                                                  type="button"
                                                  style={{ marginTop: "10px" }}
                                                >
                                                  Cancel
                                                </button>
                                                <button
                                                  type="button"
                                                  className="btn btn-orange"
                                                  onClick={(e) => {
                                                    localStorage.user_id
                                                      ? this.replyComment(e)
                                                      : window
                                                          .jQuery(
                                                            "#signup-modal"
                                                          )
                                                          .modal("show");
                                                  }}
                                                >
                                                  Submit
                                                </button>
                                              </form>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4 d-none d-sm-block">
                      <div className="mb-5">
                        <div className="col p-0">
                          <h3 className="title">Related Articles</h3>
                          <div className={
                            console.log(this.props.articleDetail[0].relatedArticles, 'this.props.articleDetail'),
                            this.props.articleDetail && this.props.articleDetail.length > 0 ? 'd-none' : 'd-block'}>
                            {/* <h3 className="noarticle">No Articles</h3> */}
                        </div>
                        </div>
                        <div className={this.props.articleDetail && 
                        
                          this.props.articleDetail[0].relatedArticles.length > 0 ? "whats-happen high-light col p-0 d-block":"whats-happen high-light col p-0 d-none" }>
                         
                            {this.props.articleDetail &&
                            this.props.articleDetail[0].relatedArticles.length > 0 &&
                            <div className="wt-item-encl mscroll-y-inside">
                              {this.props.articleDetail[0].relatedArticles.map((m, n) => {
                                return (
                                  <Link
                                    to={`/feature/${m.post_name}`}
                                    className="wt-item"
                                    key={m.ID}
                                  >
                                    <div className="cal"
                                    style={{ backgroundImage: `url(${(m.thumbnail_image === "" || m.thumbnail_image === null || m.thumbnail_image === undefined) ? m.custom_feature_image_url : m.thumbnail_image})`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat', height: '65px' }}
                                    >
                                      {/* <img
                                        className="img-fluid lazyload"
                                        data-src={
                                          m.thumbnail_image ===
                                            undefined ||
                                          m.thumbnail_image === null ||
                                          m.thumbnail_image === ""
                                            ? m.custom_feature_image_url
                                            : m.thumbnail_image
                                        }
                                        alt="img"
                                      /> */}
                                    </div>
                                    <div className="cal-cont">
                                      <p>{m.post_title}</p>
                                    </div>
                                  </Link>
                                );
                                  })
                                }
                          </div>
                          }
                        </div>
                      </div>
                      <div className="text-center">
                        {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-ver.jpg"} alt="ad" /> */}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </section>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    articleDetail: state.ArticleDetail.articleDetail,
    designState: state.ArticleDetail.designState,
    commentsList: state.ArticleDetail.commentsList,
    subCommentsList: state.ArticleDetail.subCommentsList,
    commentStatus: state.ArticleDetail.commentStatus,
    replyCommentStatus: state.ArticleDetail.replyCommentStatus,
    comment_review: state.ArticleDetail.comment_review,
    reply_comment_review: state.ArticleDetail.reply_comment_review,
    rating: state.ArticleDetail.rating,
    comment_id: state.ArticleDetail.comment_id,
    bucketItem: state.Header.bucketItem,
    overList: state.ArticleDetail.overList,
    feature_related_articles :state.ArticleDetail.feature_related_articles
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getArticleDetail: (data) => dispatch(actions.getArticleDetail(data)),
    getSubComments: (data) => dispatch(actions.getSubCommentsList(data)),
    updateDesignState: (data) => dispatch(actions.updateDesignState(data)),
    createCommentForArticle: (data) => dispatch(actions.createComment(data)),
    replyCommentForArticle: (data) => dispatch(actions.replyComment(data)),
    updateCommentReview: (f, e) => dispatch(actions.changeCommentReview(f, e)),
    changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
  };
};

const popularArticles = connect(
  mapStateToProps,
  mapDispatchToProps
)(Popular_Articles);

export default popularArticles;

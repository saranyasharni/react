import React, { Component, Fragment } from 'react'

class notFound extends Component {
    render() {

        return (
            <div className="container1" 
            //style={divstyle}
            >
                <h2>Oops! Page not found.</h2>
                <h1 
                //style = {headStyle}
                >404</h1>
                <p>We are sorry but the page you are looking for does not exist.</p>
                <br />
                <br />
                <a 
                //style = {aStyle} 
                className="linkd" href="/"
                >
                    Go back home
                </a>
            </div>
        )
    }
}

export default notFound;



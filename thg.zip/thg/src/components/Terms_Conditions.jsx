/** @format */

import React, { Component, Fragment } from "react";

import jQuery from "jquery";

import { Link } from "react-router-dom";

import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";
import { userDetails } from "../actions/common/Header";
import { THGTvList } from "../actions/Home";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";

export default class Terms_Conditions extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    //this.props.getTermsContents({ page_slug: "terms-and-condtions" });
    this.props.getTermsData('terms-and-condtions')
  }

  componentDidMount(){
    document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
  }
  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>
            {/* Main Wrapper Starts here */}

            {/* Coach Listing Starts here */}
            <section className="container-fluid mt-5">
              <div className="row">
                <div className="container">
                  <div className="row">
                    <div className="col-12 text-center mb-5">
                      {/* <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            /> */}
                    </div>
                    <div className="col-md-12">
                      <h3 className="title">{
                        this.props.termsData.length ? this.props.termsData[0].post_title: ''
                      }
                      </h3>
                      <div className="row">
                        <div className="col-12 fp-content">
                          {/* <p>
                            Welcome to our Site. By continuing to view and
                            access TheHomeGround (“Site”), and its contents or
                            videos, you are hereby agreeing to comply with and
                            be bound by the following terms and conditions of
                            use and our{" "}
                            <Link to="/data-protection-policy">
                              Data Protection Policy
                            </Link>
                            . If you do not agree with these terms and
                            conditions, you should not access or use the
                            website.
                          </p>
                          <p>
                            In these terms and conditions, TheHomeGround Digital
                            Network Pte Ltd. refers to the owner of the website
                            collectively referred to as "we or “us”. The term
                            “you” or “member” refers to the user or viewer of
                            our website.
                          </p>
                          <p>
                            <strong>Definitions</strong>
                            <br />
                            Unless the context otherwise requires, terms used in
                            these Terms of Use shall have the following meaning
                          </p>
                          <p>
                            <strong>“Account”</strong> means a registered
                            account opened by a Member under this Site.
                          </p>
                          <p>
                            <strong>“Agreement”</strong> means the agreement
                            formed by these Terms of Use and the{" "}
                            <Link to="/data-protection-policy">
                              Data Protection Policy
                            </Link>
                          </p>
                          <p>
                            <strong>“Content”</strong> means all information,
                            news, advertisements, audio, video, pictures,
                            graphics, blogs, webcasts, podcasts, broadcasts,
                            messages, comments, suggestions, ideas and other
                            content.
                          </p>
                          <p>
                            <strong>“Interactive Areas”</strong> means areas on
                            the Site that users can post or upload user
                            generated content, comments, videos, photos,
                            messages or other materials.
                          </p>
                          <p>
                            <strong>“Member”</strong> means a registered member
                            of the Site.
                          </p>
                          <p>
                            <strong>“Third Party Products”</strong> means
                            products and services of third parties, including
                            other users, advertised on or available at the Site
                            or websites linked from the Site.
                          </p>
                          <p>
                            <strong>“Third Party User Content”</strong> means
                            all User Content that is not created, transmitted,
                            posted or uploaded by you.
                          </p>
                          <p>
                            <strong>“User Content”</strong> means all Content on
                            this Site which is created, transmitted, posted or
                            uploaded by a user of the Site.
                          </p>
                          <ol>
                            <li>
                              <strong>Warranties and Representations</strong>
                              <ol>
                                <li>
                                  The Contents of this Site are for your general
                                  information and use only. To the extent
                                  permitted by law, we are not liable and
                                  responsible for the accuracy, completeness or
                                  suitability of the information and materials
                                  published on this Site. We are also not liable
                                  and responsible for the Contents of third
                                  party websites that are accessible via links
                                  from our Site.
                                </li>
                                <li>
                                  We may, modify the Terms of Use, add or remove
                                  terms at any time, and such modifications,
                                  additions or deletions will be effective
                                  immediately upon posting. Your use of the Site
                                  after such posting shall be deemed as
                                  acceptance by you of the modifications,
                                  additions or deletions.
                                </li>
                                <li>
                                  Your use of any information or materials on
                                  this Site is entirely at your own risk. You
                                  shall be responsible to ensure that any
                                  products and services available through this
                                  Site meet your specific requirements.
                                </li>
                                <li>
                                  We may change or discontinue any aspect,
                                  service or feature of the Site at any time,
                                  including, but not limited to, Content, hours
                                  of availability, and equipment needed for
                                  access or use.
                                </li>
                              </ol>
                            </li>
                            <li>
                              <strong>User Access</strong>
                              <ol>
                                <li>
                                  You may create an Account via an online
                                  registration form that may allow you to
                                  receive information from us and/or to
                                  participate in certain Interactive Areas on
                                  the Site. We will use the information you
                                  provide in accordance with our{" "}
                                  <Link to="/data-protection-policy">
                                    Data Protection Policy
                                  </Link>
                                </li>
                                <li>
                                  You warrant that all information that you
                                  provide on the registration form is complete
                                  and accurate to the best of your knowledge and
                                  that you agree to maintain and promptly update
                                  your registration information on the Site to
                                  ensure its completeness and accuracy.
                                </li>
                                <li>
                                  You may be required to choose a password
                                  and/or user name during registration andyou
                                  acknowledge and agree that we may rely on this
                                  password or user name to identify you. You
                                  shall be responsible for protecting the
                                  confidentiality of your user name(s) or
                                  password(s), if any.
                                </li>
                              </ol>
                            </li>
                            <li>
                              <strong>
                                User Participation and Content Guidelines
                              </strong>
                              <ol>
                                <li>
                                  If you are under 16 years of age, you confirm
                                  that you have obtained the legal consent of
                                  your parent or legal guardian to enter into
                                  this Agreement.
                                </li>
                                <li>
                                  By submitting User Content to the Site, you
                                  automatically grant us, the royalty-free,
                                  perpetual, irrevocable, non-exclusive right
                                  and license, but not the obligation, to use,
                                  publish, reproduce, modify, adapt, edit,
                                  translate and to authorise third-parties to
                                  use, publish and/or transmit your Content
                                  worldwide in any form, media or technology now
                                  known or hereafter, without payment to you or
                                  to any third parties.
                                </li>
                                <li>
                                  You agree not to upload, post or transmit any
                                  User Content that:
                                  <ol>
                                    <li>
                                      is not created by you and/or you have not
                                      been authorised or have received express
                                      permission from the owner of the Content
                                      to submit the Content to the Site.
                                    </li>
                                    <li>
                                      deliberately upsets or harms others.{" "}
                                    </li>
                                    <li>
                                      violates or infringes in any way upon the
                                      rights of others and/or contains blatant
                                      expressions of bigotry, racially,
                                      ethnically offensive, obscene or lewd
                                      Content, hate speech, abusiveness,
                                      vulgarity or profanity.
                                    </li>
                                    <li>
                                      you know to be false, misleading or
                                      inaccurate.
                                    </li>
                                    <li>
                                      violates any law or advocates or provides
                                      instruction on dangerous, illegal, or
                                      predatory acts and/or would encourage,
                                      criminal conduct or give rise to civil
                                      liability.
                                    </li>
                                    <li>
                                      that infringes any copyright, patent,
                                      trademark, trade secret, or any other
                                      intellectual or proprietary or privacy
                                      right of any party or individual.
                                    </li>
                                    <li>
                                      is for commercial purposes, with the
                                      intention to solicit funds or to promote
                                      the sale of any goods or services.
                                    </li>
                                    <li>
                                      you agree not to represent or suggest,
                                      directly or indirectly, our endorsement of
                                      User Content.
                                    </li>
                                    <li>
                                      you agree not to upload, post or otherwise
                                      transmit any User Content, software
                                      viruses, computer codes, or other
                                      materials designed to interrupt, destroy,
                                      or limit the functionality of the Site or
                                      any computer software or hardware or
                                      telecommunications equipment; and/or
                                    </li>
                                    <li>
                                      you agree not to use any service,
                                      technology or automated system to
                                      artificially inflate the page views that
                                      your User Content receives.{" "}
                                    </li>
                                  </ol>
                                </li>
                              </ol>
                            </li>
                            <li>
                              <strong>Third Party Content</strong>
                              <ol>
                                <li>
                                  We do not vouch for the accuracy or
                                  credibility of any Content, and you
                                  acknowledge and agree that when you post or
                                  view Content on the Site, you are doing so at
                                  your own risk. You further acknowledge and
                                  agree that the views expressed by you and
                                  other users in the Content do not reflect our
                                  views nor signify that we endorse these third
                                  parties. We shall have the right, but not the
                                  obligation, to monitor User Content posted or
                                  uploaded to the Site to determine compliance
                                  with these Terms of Use. We do however,
                                  reserve the right, to screen, edit, refuse to
                                  post, remove or terminate your Account without
                                  prior notice to you.
                                </li>
                                <li>
                                  All trademarks reproduced in this website,
                                  which are not the property of, or licensed to
                                  us, are acknowledged on the Site.
                                </li>
                              </ol>
                            </li>
                            <li>
                              <strong>Advertisements and Promotions</strong>
                              <ol>
                                <li>
                                  We may run advertisements and promotions from
                                  third parties on the Site. Yourcorrespondence
                                  with, participation in promotions of these
                                  advertisers, or purchase and/or usage of Third
                                  Party Products and any terms, conditions,
                                  warranties or representations associated with
                                  such dealings, are solely between you and such
                                  third party. We shall not be responsible or
                                  liable for any loss or damage of any sort
                                  incurred as the result of any such dealings.
                                </li>
                                <li>
                                  If you wish to advertise on the Website,
                                  please email{" "}
                                  <a href="mailto:advertise@thehomeground.asia">
                                    advertise@thehomeground.asia
                                  </a>
                                </li>
                              </ol>
                            </li>
                            <li>
                              <strong>Governing Law</strong>
                              <p>
                                Your use of our Site and any dispute arising out
                                of such use of the Site is subject to the laws
                                of Singapore.
                              </p>
                            </li>
                            <li>
                              <strong>Indemnification</strong>
                              <ol>
                                <li>
                                  You agree to indemnify and hold us, our
                                  subsidiaries, affiliates, officers, directors,
                                  partners, and employees and each of their
                                  respective officers, directors, and employees
                                  harmless from any and all claims, demands,
                                  actions, liabilities, penalties, and expenses,
                                  including, but not limited to, attorneys' fees
                                  and expenses, arising out of your:
                                  <ol>
                                    <li>use of this Site;</li>
                                    <li>connection to the Site;</li>
                                    <li>
                                      breach of any terms and conditions of this
                                      Term of Use or our{" "}
                                      <Link to="/data-protection-policy">
                                        Data Protection Policy
                                      </Link>
                                      ; and/or
                                    </li>
                                    <li>
                                      violation of any rights of another person
                                      or entity.
                                    </li>
                                  </ol>
                                </li>
                              </ol>
                            </li>
                          </ol>
                          <p className="last-update">
                            Last updated on August 2020
                          </p> */}
                          {
                            this.props.termsData.length > 0 &&
                            this.props.termsData.map((o, k) => {
                                var content = o.post_content;
                                // content = content.replace(/&nbsp;/g, '<p></p>');
                                content = content.replace(/\r\n/g,'<p></p>');
                                return <p>
                                  {ReactHtmlParser(content)}

                                </p>
                            })
                          }
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            {/* Coach Listing Ends here */}
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

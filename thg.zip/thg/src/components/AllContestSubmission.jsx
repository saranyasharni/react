import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import Footer from '../containers/common/Footer';
import Header from '../containers/common/Header';
function AllContestSubmission() {
    useEffect(() => {

    }, []);
 
    return (
    <>
        <Header />
        <div>
        <section className="category-sec container-fluid bdr-btm">
            <div className="row parent-cat py-3">
            <div className="container">
                <h4>
                <a href="javascript:;" className="back">
                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                </a>
                View all submissions - <small>Photo of the day</small>
                </h4>
            </div>
            </div>
        </section>
        {/* Category Section Ends here */}
        {/* Submission Section Starts here */}
        <section className="container-fluid mt-5 mb-5 min-h-vp">
            <div className="row">
            <div className="container">
                <div className="row">
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-1.jpg"}
                        alt="thumb"
                        />
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="video-tag">
                        <img src="images/play-icon.svg" alt="icon" />
                        2:98
                        </div>
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-3.jpg"}
                        alt="thumb"
                        />
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="video-tag">
                        <img src="images/play-icon.svg" alt="icon" />
                        2:98
                        </div>
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="video-tag">
                        <img src="images/play-icon.svg" alt="icon" />
                        2:98
                        </div>
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="video-tag">
                        <img src="images/play-icon.svg" alt="icon" />
                        2:98
                        </div>
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-12 mb-4">
                    <div className="submission-thumb">
                    <div>
                        <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL +"/assets/images/submission-thumb-2.jpg"}
                        alt="thumb"
                        />
                        <div className="submission-overlay">
                        <span className="name">John Doe</span>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit
                            esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                            occaecat cupidatat non proident, sunt in culpa qui officia
                        </p>
                        <button className="btn btn-orange">
                            <img src="images/play-arrow.svg" />
                            Play
                        </button>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
                <div className="row">
                <div className="col text-center mt-4 mb-5">
                    <button className="btn btn-orange">Show more</button>
                </div>
                </div>
            </div>
            </div>
        </section>
        </div>

        <Footer />
    </>
    );
}

export default AllContestSubmission;

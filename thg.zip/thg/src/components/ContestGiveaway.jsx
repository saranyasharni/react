import React, { Component, Fragment } from 'react';
import $ from 'jquery'
import Header from '../containers/common/Header';
import Footer from '../containers/common/Footer';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import moment from 'moment';

import { BrowserRouter as Router, Switch, Route, Link, withRouter } from "react-router-dom";
class Giveaway extends Component {
  componentWillMount() {
    this.props.getProfileDetail({ user_id: localStorage.getItem('user_id') })
    //this.props.getContestDetail({ slug: localStorage.getItem('cotest_slug') })
    this.props.getGiveawayDetail({ slug: localStorage.getItem('cotest_slug') })
  }
  componentDidMount() {
    let THIS = this;
        $(document).ready(function () {
        //   window.$('[data-toggle="tooltip"]').tooltip({
        //     placement : 'bottom'
        // });
            window.jQuery('.input-group.date').datepicker({
                    format: "dd/mm/yyyy",
                    endDate: "+0d"
            }).off('change').change((e) => { THIS.props.changeInput("dob", e.target.value); THIS.handleChange(e) });
     // window.$('#survey-pop').modal('show')
      window.$('.banner .owl-carousel').owlCarousel({
        items: 1,
        loop: true,
        dots: true
      });

      window.$(".snip-caurosel").owlCarousel({
        items: 4,
        loop: false,
        dots: false,
        margin: 15,
        nav: true,
        responsive: {
          0: {
            items: 1
          },
          768: {
            items: 4
          }
        }
      });


      window.$(".mscroll-x").mCustomScrollbar({
        axis: "x",
        scrollEasing: "linear",
        scrollInertia: 300
      });

      window.$(".mscroll-y-inside").mCustomScrollbar({
        axis: "y",
        scrollEasing: "linear",
        scrollInertia: 300,
        autoHideScrollbar: "true",
        autoExpandScrollbar: "true",
        scrollbarPosition: "inside"
      });

    });

  }
  componentDidUpdate() {
  
    var THIS = this;
    $(document).ready(function () {
  
    
      if (THIS.props.contestStatus === 1) {
  
        $('#give-away-form .alert').html('<strong>Success!</strong> Contest Booked Successfully.');
        $('#give-away-form .alert').removeClass('alert-danger').addClass('alert-success')
       
        $('#accept').prop("checked", false);
        THIS.props.resetForm({ 
          errors : {},
          
        })
        $('.form-control').val('')
        setTimeout(function () {
          $("#give-away-form .alert").removeClass('alert-success');
        }, 2000);
        setTimeout(function () {
          window.$('#join-giveaway').modal('hide')
        }, 2000);
        THIS.props.updateContestStatus(0);
      } 
    })
  }
  
  handleChange(event) { 
    
        let errors = this.props.errors;
        let valid = true;
        const target = event.target;
        const value = target.value ;
        const name = target.name;
    
        this.setState({
          [name]: value
        });
    
        switch (name) {
          case 'mobile_no':
            valid = false;
            errors.mobile_no = (value.length !== null && value.length < 8)? 'Mobile number must be more than 8 digits': '';
            this.props.updateErrors(errors);
          break; 
          case 'date_of_birth':
            errors.date_of_birth = (value.length === null)? 'Can not be empty' : '';
            this.props.updateErrors(errors);
          break; 
          case 'occupation':
            errors.occupation = (value.length === null)? 'Can not be empty' : '';
            this.props.updateErrors(errors);
          break; 
          case 'accept':
            errors.terms = (event.target.checked === false)? 'Please accept the terms and conditions to participate' : '';
            this.props.updateErrors(errors);
          break; 
          default:
            this.props.updateErrors(errors);
          break;
        }
      }

    validateForm() {
    let valid = true;
    let errors = this.props.errors;
    //console.log(this.props.dob, 'DOB$%^')
    if (this.props.dob === '') {

        errors.date_of_birth = "Cannot be empty"
        valid = false;
    }

    if (this.props.mobile_no.length < 8) {
      errors.mobile_no = "Mobile number must be more than 8 digits"
      valid = false;
    }

    if (this.props.mobile_no === '') {
      errors.mobile_no = "Cannot be empty"
      valid = false;
    } 
    
    if (this.props.occupation === '') {
      errors.occupation = "Cannot be empty"
      valid = false;
    }
    
    if ($('#accept').is(":checked") === false) {
      errors.terms = "Please accept the terms and conditions to participate"
      valid = false;
    }
    this.props.updateErrors(errors);
    return valid;
    
  }
  giveAway(e) {
    e.preventDefault();
    //console.log('cc', $('#accept').is(":checked"))
    if (this.validateForm()) {
      this.props.createGiveAway({
        user_id: localStorage.getItem('user_id'),
        contest_id: this.props.contestDetail[0].ID,
        contest_name: this.props.contestDetail[0].post_name
      })
    }
    
  }

  render() {
    let day = 1;
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />
          <Fragment>
          <section className="category-sec container-fluid">
              <div className="row parent-cat py-3">
                  <div className="container">
                  <h4>
                    <a href="/contest" className="back">
                   <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                    </a>    
                    {this.props.give_away_detail_list.give_away && this.props.give_away_detail_list.give_away.length > 0 ? this.props.give_away_detail_list.give_away[0].post_title: 'GiveAway'}
                  </h4>
                  </div>
              </div>
              </section>
            {
              /* Hero Banner Starts here */
            }
            <section className="container-fluid hero-banner mb-3 mb-sm-4">
              { 
              
              this.props.give_away_detail_list.give_away && 
              this.props.give_away_detail_list.give_away.length > 0 &&
                this.props.give_away_detail_list.give_away.map((o, k) => {
                  return <div className="row"
                  style={{ backgroundImage: `url(${(o.image_url === "" || o.image_url === null || o.image_url === undefined) ? "" : o.image_url})`, backgroundSize: 'cover', backgroundPositionX: '50%', backgroundPositionY: 'center', backgroundRepeat: 'no-repeat', height: '500px' }}
                  >
                    {/* <img className="img-fluid" src={(o.image_url === undefined || o.image_url === null || o.image_url === "") ? process.env.PUBLIC_URL+ "assets/images/contest-slider-2.jpg" : o.image_url} alt="image"
                      style={{ width: "100%" }} /> */}
                    <div className="hero-cont">
                      <div className="container">
                        <div className="row">
                          <div className="col-lg-9 col-md-8">
                            <h1>{o.post_title}</h1>
                          </div>
                          {/* <div className="col-lg-3 col-md-4 book-tic text-right">
                            <button className="btn btn-orange" data-toggle="modal" data-target="#join-giveaway">Join Giveaway</button>
                          </div> */}
                        </div>
                      </div>
                    </div>
                  </div>
                })}
            </section>
            {
              /* Hero Banner Ends here */
            }
            {
              this.props.give_away_detail_list.give_away_winners && 
              this.props.give_away_detail_list.give_away_winners >= 1 ?
              <section className="container-fluid mt-2 mb-2">
              <div className="row">
                <div className="container">
                  <div className="row"
                  style = {{marginLeft:'3px'}}
                  >         
                    
                      <Link to = "/giveaway-winner">
                      <button className="btn btn-white">Winners</button>
                      </Link>
                    
                  </div>
                </div>
              </div>
            </section>
            : (
              <>
              </>
            )
            }
             
            {
              /* Giveaway Section Starts here */
            }
            <section className="container-fluid mt-4 mb-5 h-100">
              <div className="row">
                <div className="container contest-detail">
                  <div className="row">
                  {
                    
                        this.props.give_away_detail_list.give_away_list &&
                        this.props.give_away_detail_list.give_away_list.length > 0 &&
                        this.props.give_away_detail_list.give_away_list.map((o, k) => {
                          return  <div 
                          className="col-lg-3 col-md-4 col-sm-6 col-12 giveaway-prod-encl"
                          key = {o.post_id}
                          >
                        <span className="day-snip"
                         data-id = {day}
                        >Day 0{day++}</span>
                        {/* <Link 
                        style = {{textDecoration:'none'}}
                        to = {`/productDetail/${o.post_id}`}> */
                        //console.log( day, ' day90')
                        }
                          <a 
                         
                          href = 
                          {o.product_availability === 'closed' ? "javascript:;"
                          : o.product_availability === 'upcoming' ?  "javascript:;"
                            :`/productDetail/${o.post_id}`
                          }
                          
                          className="giveaway-prod"
                         // data-date= {o.pro_date}
                          data-id = {day-1}
                          onClick = {(e) => {
                          localStorage.setItem('day_no', $(e.target).data('id'))
                          // console.log($(e.target).data('date'), 'date_vice')
                          //localStorage.setItem('day_date', $(e.target).data('date'))
                          }}
                          >
                          <div className="giveaway-img"
                          data-id = {day-1}   
                          //data-date= {o.pro_date}
                          >
                          
                          <img
                            data-id = {day-1}
                            //data-date= {o.pro_date}
                            className=
                            {o.product_availability === 'closed' ? 'img-fluid closed_img'
                            : o.product_availability === 'upcoming' ? 'img-fluid closed_img'

                            :'img-fluid open_img'}
                            src={o.image_url ? o.image_url : process.env.PUBLIC_URL + "assets/images/give-away-3.jpg"}
                            alt="product-img"
                          />
                          <div className = 
                          {o.product_availability === 'closed' ? 'closed'
                          :o.product_availability === 'upcoming' ? 'closed':
                          'open'}>
                          <p> {o.product_availability === 'upcoming' ? 'Coming soon': 'Closed'}</p>
                          </div>
                          
                          </div>
                         
                          <span className="text-truncate"
                          data-id = {day-1}
                          //data-date= {o.pro_date}
                          >
                          
                          {o.post_title ? o.post_title: 'Title'}
                          
                          </span>
                          <p className="contests-pro-date">
                        
                          {  moment(o.pro_date).format("DD/MM")  }
                          </p>
                            
                          <span className="prod-desc"
                          data-id = {day-1}
                          //data-date= {o.pro_date}
                          >
                          <p className = 'text-truncate'>
                          {ReactHtmlParser(o.post_content ? o.post_content.substring(0, 84) : 'post_content') }
                          </p>
                          </span>
                          
                          </a>
                          
                          {/* </Link> */}
                        </div>
                        })
                    }
                   
                   
                  </div>
                  <div class="row mt-5">
                  <div class="col-md-9">
                  <div class="row">
                  <div class="col-12">
                    
                    <p>
                    {this.props.give_away_detail_list.give_away && this.props.give_away_detail_list.give_away.length > 0 &&
                      this.props.give_away_detail_list.give_away.map((o, k) => {
                          var content = o.post_content;
                          // content = content.replace(/&nbsp;/g, '<p></p>');
                          content = content.replace(/\r\n/g,'<p></p>');
                          content = content.replace('                           ','<p></p>');

                          return <p>
                          {ReactHtmlParser(content)}

                          </p>
                    })}
                    </p>
                    {/* {ReactHtmlParser(this.props.give_away_detail_list.give_away ? this.props.give_away_detail_list.give_away[0].post_content : "Description" )}    */}
                   
                  </div>
                  
                </div>
						</div>
						
					</div>
                  {/* <div className="row">
                    <div className="col-12 text-center my-5">
                      <img className="img-fluid" src={process.env.PUBLIC_URL+"assets/images/ad-landscape.jpg"} alt="Ad" />
                    </div>
                  </div> */}
                </div>
              </div>
            </section>
            {
              /* Giveaway Section Ends here */
            }

          </Fragment>
          <Footer />
          <div
            className="modal fade submit-entry"
            id="join-giveaway"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-head">
                  <h3>Join Giveaway</h3>
                </div>
                <div className="modal-body px-0">
                  <form className="pop-form" id="give-away-form">
                    <div className="alert" role="alert">
                    </div>
                    <div className="form-group row">
                      <div className="col-md-6 pr-md-0 mb-md-0 mb-4">
                        <label>First Name</label>
                        <input
                          className="form-control"
                          type="text"
                          name
                          value={this.props.userProfile ? this.props.userProfile.first_name : ''}
                        />
                      </div>
                      <div className="col-md-6 pl-md-0">
                        <label>Last Name</label>
                        <input
                          className="form-control"
                          type="text"
                          name
                          value={this.props.userProfile ? this.props.userProfile.last_name : ''}
                        />
                      </div>
                    </div>
                    <div className="form-group">
                        <label>Date of Birth</label>
                        <div 
                        className="input-group date" data-date-format="dd/month/yyyy"
                        >
                            <input
                            type="text"
                            name= "date_of_birth"
                            className="form-control"
                            value={this.props.dob}
                            onChange={(e) => {
                              this.props.changeInput(
                                "dob",
                                e.target.value
                              );
                              this.handleChange(e);
                          }}
                            //onChange = {(e) =>  {this.handleChange(e)}}
                            // disabled = {this.props.userProfile.date_of_birth !== undefined ? true : false}
                            // placeholder = {this.props.userProfile ? this.props.userProfile.date_of_birth : ''}
                            //onChange = {(e) =>  {this.handleChange(e)}}
                            
                            />
                            <div className="input-group-addon">
                            <img src={process.env.PUBLIC_URL + "assets/images/calendar-icon.svg"} alt="icon" />
                            </div>
                            
                        </div>
                        {this.props.errors.date_of_birth &&
                        this.props.errors.date_of_birth.length > 0 ? (
                        <span className="text-danger">
                            {this.props.errors.date_of_birth}
                        </span>
                        ) : (
                        ""
                        )}
                    </div>
                    <div className="form-group">
                                            <label>Mobile Number</label>
                                            <input
                                                type="number"
                                                className="form-control"
                                                name = "mobile_no"
                                                //pattern="[1-9]{1}[0-9]{9}"
                                                // disabled = {this.props.userProfile.mobile_no !== undefined ? true : false}
                                                // placeholder = {this.props.userProfile ? this.props.userProfile.mobile_no : ''}
                                                // onChange = {e =>  this.handleChange(e)
                                                onChange={(e) => {
                                                    
                                                        this.props.changeInput(   
                                                        "mobile_no", e.target.value)
                                                        this.handleChange(e);
                                                    
                                                    
                                                }}
                                                value={this.props.mobile_no}
                                            />
                                            {this.props.errors.mobile_no &&
                                            this.props.errors.mobile_no.length > 0 ? (
                                            <span className="text-danger">
                                                {this.props.errors.mobile_no}
                                            </span>
                                            ) : (
                                            ""
                                            )}
                                        </div>
                    <div className="form-group">
                      <label>Email Address</label>
                      <input
                        type="mail"
                        className="form-control"
                        name
                        value={this.props.userProfile ? this.props.userProfile.user_email : ''}
                      />
                     
                    </div>
                    <div className="form-group mb-4">
                      <label>Occupation</label>
                      <input
                        type="mail"
                        className="form-control"
                        name = "occupation"
                        value={this.props.occupation}
                        onChange={(e) => {{this.props.changeInput(    
                          "occupation", e.target.value);
                          this.handleChange(e)
                        }}}
                      />
                       {this.props.errors.occupation &&
                        this.props.errors.occupation.length > 0 ? (
                        <span className="text-danger">
                            {this.props.errors.occupation}
                        </span>
                        ) : (
                        ""
                      )}
                    </div>
                    <div className="form-group text-right">
                      {/* <a href="javascript:;" className="add-ques">
                        ADD more questions
            </a> */}
                    </div>
                    <div className="form-group mb-3">
                      <span className="agree">
                        <label className="custom-checkbox">
                          <input 
                          type="checkbox" 
                          name="accept" 
                          id="accept" 
                          onChange={(e) => {this.props.changeInput(
                            //errors: {}, 
                            "terms", e.target.value 
                            );
                            this.handleChange(e)
                          }}
                          />
                          <span className="checkmark"></span>
                        </label>
                        {/* <img className="mr-1" src={process.env.PUBLIC_URL + "assets/images/tick-circle.svg"} alt="icon" /> */}
                        <span>
                          I have read and accepted the <a href="javascript:;"> Terms and Conditions</a> and <a href="javascript:;">Privacy Policy</a> of THG
              </span>
                      </span>
                      {this.props.errors.terms &&
                        this.props.errors.terms.length > 0 ? (
                        <span className="text-danger">
                            {this.props.errors.terms}
                        </span>
                        ) : (
                        ""
                        )}
                    </div>
                    <div className="form-group mb-0 text-center">
                      <button type="button" className="mt-4 btn btn-asphalt" onClick={(e) => this.giveAway(e)}>
                        Giveaway
                    </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          {
            /* Rules & Regulations Popup Starts here */
          }
          <div
            className="modal fade pop-large"
            id="rules-regulation"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-head">
                  <h3>Rules &amp; Regulations</h3>
                </div>
                <div className="modal-body rules">
                  <div className="mscroll-y-inside">
                    <p>
                      - Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat.
          </p>
                    <p>
                      - Duis aute irure dolor in reprehenderit in voluptate velit esse
                      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                      cupidatat non proident, sunt in culpa qui officia deserunt
          </p>
                    <p>
                      - Mollit anim id est laborum.Sed ut perspiciatis unde omnis iste
                      natus error sit voluptatem accusantium doloremque laudantium, totam
                      rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
                      architecto beatae vitae dicta sunt explicabo.
          </p>
                    <p>
                      - Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit
                      aut fugit, sed quia consequuntur magni dolores eos qui ratione
                      voluptatem sequi nesciunt.
          </p>
                    <p>
                      - Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                      consectetur, adipisci velit, sed quia non numquam eius modi tempora
                      incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut
                      enim ad minima veniam
          </p>
                    <p>
                      - Quis nostrum exercitationem ullam corporis suscipit laboriosam,
                      nisi ut aliquid ex ea commodi consequatur Quis autem vel eum iure
                      reprehenderit qui in ea
          </p>
                    <p>
                      - Voluptate velit esse quam nihil molestiae consequatur, vel illum
                      qui dolorem eum fugiat quo voluptas nulla pariatur
          </p>
                    <p>
                      - Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat.
          </p>
                    <p>
                      - Duis aute irure dolor in reprehenderit in voluptate velit esse
                      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                      cupidatat non proident, sunt in culpa qui officia deserunt
          </p>
                    <p>
                      - Mollit anim id est laborum.Sed ut perspiciatis unde omnis iste
                      natus error sit voluptatem accusantium doloremque laudantium, totam
                      rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
                      architecto beatae vitae dicta sunt explicabo.
          </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {
            /* Terms & Conditions Popup Starts here */
          }
          <div
            className="modal fade pop-large"
            id="terms-conditions"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-head">
                  <h3>Terms &amp; Conditions</h3>
                </div>
                <div className="modal-body rules">
                  <div className="mscroll-y-inside">
                    <p>
                      Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                      reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                      pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                      culpa qui officia deserunt mollit anim id est laborum.Sed ut
                      perspiciatis unde omnis iste natus error sit voluptatem accusantium
                      doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                      inventore veritatis et quasi architecto beatae vitae dicta sunt
                      explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                      aut odit aut fugit, sed quia consequuntur magni dolores eos qui
                      ratione voluptatem sequi nesciunt.
          </p>
                    <p>
                      Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                      consectetur, adipisci velit, sed quia non numquam eius modi tempora
                      incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut
                      enim ad minima veniam, quis nostrum exercitationem ullam corporis
                      suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis
                      autem vel eum iure reprehenderit qui in ea voluptate velit esse quam
                      nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo
                      voluptas nulla pariatur
          </p>
                    <p>
                      Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                      reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                      pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                      culpa qui officia deserunt mollit anim id est laborum.Sed ut
                      perspiciatis unde omnis iste natus error sit voluptatem accusantium
                      doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                      inventore veritatis et quasi architecto beatae vitae dicta sunt
                      explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                      aut odit aut fugit, sed quia consequuntur magni dolores eos qui
                      ratione voluptatem sequi nesciunt.
          </p>
                    <p>
                      Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                      consectetur, adipisci velit, sed quia non numquam eius modi tempora
                      incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut
                      enim ad minima veniam, quis nostrum exercitationem ullam corporis
                      suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis
                      autem vel eum iure reprehenderit qui in ea voluptate velit esse quam
                      nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo
                      voluptas nulla pariatur
          </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {
            /* Terms & Conditions Popup Ends here */
          }
          {
            /* Survey Popup Starts here */
          }
          <div
            className="modal fade"
            id="survey-pop"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img src={process.env.PUBLIC_URL + "assets/images/close-icon.svg"} alt="icon" />
                </button>
                <div className="modal-body">
                  <div className="interested">
                    <p className="lead">
                      Few things about you
            <span>This survey helps to improve you feeds...</span>
                    </p>
                  </div>
                  <form className="pop-form p-0 mt-5">
                      <div className="form-group mb-4">
                        <span className="label-lg">Where do you like to go on a holiday?</span>
                        <div className="col-12 px-0">
                          <label className="custom-checkbox radio col-12">
                            <input type="radio" name="trip" defaultChecked="checked" />{" "}
                  Beach
                          <span className="checkmark" />
                          </label>
                          <label className="custom-checkbox radio col-12">
                            <input type="radio" name="trip" /> Mountain
                            <span className="checkmark" />
                          </label>
                          <label className="custom-checkbox radio col-12">
                            <input type="radio" name="trip" /> City
                            <span className="checkmark" />
                          </label>
                        </div>
                        <hr className="mt-5"/>
                        <div className="col-12 text-center mt-4">
                          <a href="javascript:;" className="btn btn-asphalt">Next</a>
                        </div>
                      </div>
                    
                    <div className="text-center mt-3 mb-0">
                      {/* <hr />
                      <button className="btn btn-asphalt">DONE</button> */}
                      <a href="javascript:;" className="no-thnx">
                        No thanks, maybe next time.
                      </a>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          {
            /* Survey Popup Ends here */
          }
        </div>
      </div>

    );
  }

}

export default Giveaway;

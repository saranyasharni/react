import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import history from "../stores/history";
import MailchimpSubscribe from "react-mailchimp-subscribe";
const CustomForm = ({ status, message, onValidated }) => {
    
};
export default class Subscribe extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount(){
        // this.props.getFreqList()
        document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
        this.props.getCatList()
        
        let THIS = this;
        jQuery(document).ready(function () {
        window.jQuery(".select2").select2({
            closeOnSelect : false,
            placeholder : "Notify about these topics",
            allowHtml: true,
            allowClear: true,
            
        })
        //window.jQuery(".select2").select2({disabled:true});

        window.jQuery('.select2').on('select2:close', function () {
            
            var selectedValues = jQuery(this).val();
            // console.log("selectedValues", selectedValues);
            THIS.props.updateSubscribeInfo('notify_topics', selectedValues)
        });
    })
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.subscribeStatus === 1) {
                THIS.props.resetSubscribe({
                    firstName: '',
                    lastName:'',
                    email: '',
                    frequency: '',
                    notify_topics: [],
                    subscribeErrors: {}
                })
                jQuery('.subscribe-forms .alert').html('<strong>Success!</strong> Subscribed Successfully.');
                jQuery('.subscribe-forms .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".subscribe-forms .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateSubscribeStatus(0);
                setTimeout(function () {
                   history.push('/')
                }, 1000);
            } else if (THIS.props.subscribeStatus === 2) {
                jQuery('.subscribe-forms .alert').html('<strong>Error!</strong> Already Subscribed.');
                jQuery('.subscribe-forms .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".subscribe-forms .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateSubscribeStatus(0);
            } else if (THIS.props.subscribeStatus === 3) {
                jQuery('.subscribe-forms .alert').html('<strong>Error!</strong> Failed To Subscribe.');
                jQuery('.subscribe-forms .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".subscribe-forms .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateSubscribeStatus(0);
            }
        })
    }
    

    subscribe(event) {
        event.preventDefault();
        // console.log("frequeny", this.props.frequency)
        // console.log("notify", this.props.notify_topics)

        if (this.validateSubscribeForm()) {
            this.props.createSubscribe({
                firstName: this.props.firstName,
                lastName: this.props.lastName,
                email: this.props.email,
                frequency: this.props.frequency,
                notify_topics: this.props.notify_topics
            })
        }

    }

    validateSubscribeForm() {
        let valid = true;
        let errors = this.props.subscribeErrors;
        if (this.props.email == "" || this.props.email == null) {
            valid = false;
            errors.email = "Please enter your email"
        }
        if (this.props.firstName == "" || this.props.firstName == null) {
            valid = false;
            errors.firstName = "Please enter your first name"
        }
        if (this.props.lastName == "" || this.props.lastName == null) {
            valid = false;
            errors.lastName = "Please enter your last name"
        }
        if (this.props.frequency === [] || this.props.frequency == "" || this.props.frequency == null) {
            valid = false;
            errors.frequency = "Please choose a frequency"
        }
        if (this.props.notify_topics === [] || this.props.notify_topics == "" || this.props.notify_topics == null) {
            valid = false;
            errors.notify_topics = "Plese choose any topics"
        }
        
        this.props.updateSubscribeErrors(errors);
        return valid;

    }

    render() {
        const url = "//xxxx.us13.list-manage.com/subscribe/post?u=zefzefzef&id=fnfgn";
        return (

            < div className="container-fluid" >
                <div className="row">
                    <Header />
                    <section className="subscribe-section relative ">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-lg-6 col-md-12 subscribe-bg" style={{ backgroundImage: `url(${process.env.PUBLIC_URL + "/assets/images/subscribe-bg.jpg"})` }}></div>
                                <div className="col-lg-6 col-md-12 subscribe-form relative">
                                    <div className="adjustsection-subscribe">
                                        <h1 className="text-center">Subscribe to us!</h1>
                                        <p className="text-center">
                                        Get our newsletter in your inbox{" "}
                                        </p>
                                        <MailchimpSubscribe
                                        url={url}
                                        render={({ subscribe, status, message }) => (
                                        <form className="subscribe-forms">
                                            <div className="alert" role="alert">
                                            </div>
                                            <div className="form-group">
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    id="examplename"
                                                    value={(this.props.firstName) ? this.props.firstName : ''}
                                                    onChange={e => this.props.updateSubscribeInfo('firstName', e.target.value)}
                                                    placeholder="First Name"
                                                />
                                                {(this.props.subscribeErrors.firstName && this.props.subscribeErrors.firstName.length > 0) ?
                                                    < span className='text-danger'>{this.props.subscribeErrors.firstName}</span> : ''}
                                            </div>
                                            <div className="form-group">
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    id="examplename"
                                                    value={(this.props.lastName) ? this.props.lastName : ''}
                                                    onChange={e => this.props.updateSubscribeInfo('lastName', e.target.value)}
                                                    placeholder="Last Name"
                                                />
                                                {(this.props.subscribeErrors.lastName && this.props.subscribeErrors.lastName.length > 0) ?
                                                    < span className='text-danger'>{this.props.subscribeErrors.lastName}</span> : ''}
                                            </div>
                                            <div className="form-group">
                                                <input
                                                    type="email"
                                                    className="form-control"
                                                    id="exampleemail"
                                                    value={(this.props.email) ? this.props.email : ''}
                                                    onChange={e => this.props.updateSubscribeInfo('email', e.target.value)}
                                                    placeholder="Email"
                                                />
                                                {(this.props.subscribeErrors.email && this.props.subscribeErrors.email.length > 0) ?
                                                    < span className='text-danger'>{this.props.subscribeErrors.email}</span> : ''}
                                            </div>
                                            <div className="profile-form">
                                            <div className="form-group subscribe-form-lists">
                                                {/* <label>
                                                    Frequency
                
                                                </label> */}
                                                <select className="form-control freek" value={(this.props.frequency === 'undefined') ? '' : this.props.frequency}
                                                    onChange={e => this.props.updateSubscribeInfo('frequency', e.target.value)}>
                                                    {/* {
                                                        this.props.frequencyList.map((o, k) => (

                                                            <option key={k}
                                                                value={o.value_id}>{o.value_name}</option>
                                                        ))
                                                    } */}
                                                    <option value="Select">Select Frequency</option>
                                                    <option value="10">Daily</option>
                                                    <option value="12">Weekly</option>
                                                </select>
                                            </div>
                                            {(this.props.subscribeErrors.frequency && this.props.subscribeErrors.frequency.length > 0) ?
                                            < span className='text-danger'>{this.props.subscribeErrors.frequency}</span> : ''}
                                            <div className="form-group fn_try">
                                                {/* <label>
                                                    Notify about these topics

                                                </label> */}
                                                <select className="form-control select2"   multiple value={this.props.notify_topics}>
                                                    
                                                    {
                                                        this.props.categoryList.length > 0 &&
                                                        this.props.categoryList.map((c, d) => (
                                                            
                                                            <option 
                                                            value={c.term_id} className="optionGroup ">{c.name
                                                            }
                                                            </option>
                                                              

                                                        ))
                                                    }
                                                    
                                                </select>
                                            </div>
                                            {(this.props.subscribeErrors.notify_topics && this.props.subscribeErrors.notify_topics.length > 0) ?
                                                    < span className='text-danger'>{this.props.subscribeErrors.notify_topics}</span> : ''}
                                            </div>
                                            <button
                                                type="button"
                                                className="btn btn-primary btn-block subscribe"
                                                onClick={e => this.subscribe(e)}>
                                                Subscribe
                                        </button>
           
                                        </form>
                                         )}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>



                    <Footer />
                </div>
            </div >


        )
    }
}



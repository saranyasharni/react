import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import AdSense from 'react-adsense';
import LiveStream from './ThgTvSection/Live_Stream'
import WebSeries from './ThgTvSection/Web_Series'
import OnThePitch from './ThgTvSection/On_The_Pitch'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";

export default class TGHTV extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.props.updatePageNo({ flag: 1 });
        this.props.getOnThePitchList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5, slug: 'on-the-pitch' })
        if (this.props.bannerEpisode === '') {
            this.props.getVideoStreamApi()
        }
    }

    componentDidMount() {
        var THIS = this;
        jQuery('.loader-pro').removeClass('d-none')
        jQuery('.loader-pro').addClass('d-block')
        jQuery(document).ready(function () {
            window.$(".thgtv-nav").addClass("active");
        })

        // const elem2 = document.createElement("script");
        // elem2.type = "text/javascript"
        // elem2.src =
        //     "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
        // elem2.id = "player"
        // elem2.async = false;
        // document.head.appendChild(elem2);
        // jQuery(document).ready(function () {
        //     window.$(".thgtv-nav").addClass("active");
        // });
        
    }

    componentDidUpdate() {
        var THIS = this;
        if (this.props.bannerEpisode !== '') {
            var element = document.getElementById('player');
            if (!element) {
                const elem2 = document.createElement("script");
                elem2.type = "text/javascript"
                elem2.src =
                    "https://static-cdn.espx.cloud/lib/player/latest/ESPxPlayer.js";
                elem2.id = "player"
                elem2.async = false;
                elem2.onload = () => this.scriptLoaded(this.props.bannerEpisode);
                //For head
                document.head.appendChild(elem2);
                jQuery(document).ready(function () {
                    window.$(".thgtv-nav").addClass("active");
                });
            }   
        }
    }

    scriptLoaded(programmeID) {    
        // console.log(this.props.bannerEpisode, 'this.props.bannerEpisode')
        const _CONFIG = {
            divID: '#player-container',
            appID: '7386573047397500',
            autoPlay: false,
            config: 'espxplayer',
            applyModel: true,
            programme_id: programmeID,
            countdown: false,
            videoAlignment: 'center'
        }

        if(window.ESPxPlayer){
            let player = window.ESPxPlayer.getPlayer();
            console.log('player', player)
            if(player && player['_options']['parentId'] === "#player-container"){
                window.ESPxPlayer.destroyPlayer();
            }
            window.ESPxPlayer.createPlayer(_CONFIG).then((p) => {
                this.player = p;
                window.jQuery('#toggle-sharing svg').css('display', 'none')
                window.jQuery('#toggle-sharing').attr('title', '')
                window.jQuery('.data-share div').css('display', 'none')
                // var videoCusHeight = window.jQuery("#player-container video").height();
                // window.jQuery("#player-container").height(videoCusHeight);
                var screenWdth = jQuery(window).width();
                if (screenWdth <= 768) {
                    // console.log('came768')
                    setTimeout(() => {
                        // console.log('came7689')
                        p.on('play', function() {
                            var videoCusHeight = window.jQuery("#player-container video").height();
                            //console.log('videoCusHeight', videoCusHeight)
                            let hgt =  Number(videoCusHeight) + 50
                            window.jQuery("#player-container").height(hgt);
                        });
                        
                    }, 500)
                }
            }).catch((e) => {
                console.log("catch", e)
            });
        }

        jQuery('.loader-pro').removeClass('d-block')
        jQuery('.loader-pro').addClass('d-none')

    }

        componentWillUnmount() {
            
            var element = document.getElementById('player');
            if(element){
                element.parentNode.removeChild(element)
            }
            console.log('window.ESPxPlayer', window.ESPxPlayer)
            if(window.ESPxPlayer){
                let player = window.ESPxPlayer.getPlayer();
                console.log('player', player)
                if(player && player['_options']['parentId'] === "#player-container"){
                    window.ESPxPlayer.destroyPlayer();
                }
            }
        }

    // showMore(e) {
    //     e.preventDefault();
    //     this.props.updatePageNo({ flag: 0 });
    //     this.props.getNewOnThePitchList({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.archivePageNo + 1, limit: 5, slug: 'on-the-pitch' })
    // }

    render() {

        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Livestream Section Starts here */}
                        <LiveStream />
                        {/* Livestream Section Ends here */}

                        {/* Ad Section Starts here */}
                        <div className="container text-center my-sm-5 my-3">
                            {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"} alt="Ad" /> */}
                        </div>
                        {/* Ad Section Ends here */}

                        {/* Web Series Starts here */}
                        <WebSeries />
                        {/* Web Series Ends here */}

                        {/* Ad Section Starts here */}
                        <div className="container text-center mt-0 mb-5">
                            {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"} alt="Ad" /> */}
                        </div>
                        {/* Ad Section Ends here */}
                        
                                <UserAgentProvider
                    ua={ window.navigator.userAgent }
                    >
                    {/* <UserAgent tablet mobile>
                        <div className="ad_sze container">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 288, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent> */}
                    <UserAgent windows mac>
                        <div className="ad_sze container mb-4">
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="1638754887"
                            style={ { width: 1111, height: 140, float: "left" } }
                            format=""
                        />
                        </div>
                    </UserAgent>
                    </UserAgentProvider>
                        {/* On The Pitch Starts here */}
                        <OnThePitch />
                        {/* On The Pitch Ends here */}

                        {/* Archive Button Starts here */}
                        
                        {/* Archive Button Ends here */}
                        
                        <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              {/* <UserAgent tablet mobile>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="1638754887"
                    style={ { width: 288, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent> */}
              <UserAgent windows mac>
                <div className="container mt-5">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="1638754887"
                    style={ { width: 1111, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider>

                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
    }
}



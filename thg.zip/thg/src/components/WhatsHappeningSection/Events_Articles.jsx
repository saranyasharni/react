import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Whats_Happening';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import AdSense from 'react-adsense';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import moment from 'moment';
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";


class Events_Articles extends Component {
    constructor(props) {
        super(props);
       //this.myRef = React.createRef() 
    }
    
    componentDidMount() {
        
        var THIS = this;
        jQuery(document).ready(function () {   
            
            jQuery(".up_more").click(function(){
                jQuery(this).hide();
            });

            window.jQuery('#calendars').datepicker({ 
            format: "dd/mm/yyyy",
            autoclose: true,
            //todayHighlight: true,
            beforeShowDay: function(date) {
                var d = date;
                var curr_date = d.getDate().toString().padStart(2, "0");
                var curr_month = (d.getMonth() + 1).toString().padStart(2, "0"); 
                var curr_year = d.getFullYear();
                var formattedDate = curr_year + "-" + curr_month + "-" + curr_date
                    if (jQuery.inArray(formattedDate, THIS.props.setdateArray) != -1) {
                        
                        if (new Date(formattedDate).toDateString() == new Date().toDateString()) {
                            return {
                                classes: 'after activeClass'
                            };
                        } else if (Date.parse(formattedDate) < Date.parse(new Date())) {
                            return {
                                classes: 'before activeClass'
                            };
                        } else {
                            return {
                                classes: 'after activeClass'
                            };
                        }
                        
                    }
                return;
                }
            }).off('changeDate').on('changeDate', function (e) {
                window.jQuery('#month-filter').val('')
                THIS.props.changeFilterBy('date')
                THIS.props.updateDateChange(true)
                let nextToDate = new Date(e.date);
                nextToDate.setDate(nextToDate.getDate());
               // console.log('e', nextToDate)
                setTimeout(function () {
                    THIS.filter(e);
                }, 1000);
            })
        })      
    
        // const elem = document.createElement("script");
        // elem.src = `${process.env.PUBLIC_URL}/assets/js/date-calendar.js`;
        // elem.async = true;
        // document.body.appendChild(elem);
    }

    componentDidUpdate() {
        // const elem = document.createElement("script");
        // elem.src = `${process.env.PUBLIC_URL}/assets/js/date-calendar.js`;
        // elem.async = true;
        // document.body.appendChild(elem);
        var THIS = this;
        jQuery(document).ready(function () {
         
            if (THIS.props.showHideStatus === 1) {
                jQuery(".hidden-content").slideDown();
                jQuery('.hidden-content .up_more').show();
                THIS.props.changeShowStatus(0);
            }
            if (THIS.props.articleMoreStatus === 1) {
                jQuery('.article-list .alert').html('<strong>No more events to show.</strong>');

                jQuery('.article-list .alert').removeClass('alert-success').addClass('alert-danger')
                jQuery('.hidden-content .up_more').show();
                THIS.props.changeArticleMoreStatus(0);
                setTimeout(function () {
                    jQuery(".article-list .alert").removeClass('alert-danger');
                }, 2000);
            }
        })
    }

    showMoreUpcoming(e) {
        e.preventDefault();  
        //jQuery(this).hide();
        var search = window.location.pathname.split('/')[2]
        this.props.updateUpcomingEventNo({ upcomingFlag: 0 });
        let monthFilter = window.jQuery('#month-filter').val()
        let catFilter = window.jQuery('#cat-filter').val()
        let dateFilter = '';
        if (this.props.changeDate) {
            let nextToDate = new Date(window.jQuery('#calendars').datepicker('getDate'));
            nextToDate.setDate(nextToDate.getDate() + 1);
            dateFilter = nextToDate.toISOString().slice(0, 10);
        }

        if (monthFilter || catFilter || dateFilter) {
            this.props.getNewUpcomingEventsFilter({
                filter_by: this.props.filterBy,
                slug_name: catFilter,
                month: monthFilter,
                date: dateFilter,
                page_no: this.props.upcomingEventNo + 1,
                limit: 6
            })
        } else {
            this.props.getNewUpcomingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.upcomingEventNo + 1, limit: 6 })
        }
    }

    filter(e) {
        // e.preventDefault();
        var monthFilter = window.jQuery('#month-filter').val();
        var catFilter = window.jQuery('#cat-filter').val();
        this.props.updateUpcomingEventNo({ upcomingFlag: 1 });
        var dateFilter = '';
        if (this.props.changeDate) {
            let nextToDate = new Date(window.jQuery('#calendars').datepicker('getDate'));
            nextToDate.setDate(nextToDate.getDate() + 1);
            dateFilter = nextToDate.toISOString().slice(0, 10);
        }
        
        if (monthFilter || catFilter || dateFilter) {
            this.props.getUpcomingEventsFilter({
                filter_by: this.props.filterBy,
                slug_name: catFilter,
                month: monthFilter,
                date: dateFilter,
                page_no: 0,
                limit: 6
            })
        } else {
            
            this.props.getUpcomingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 6 })
        }

    }

    componentWillUnmount() {
        this.props.changeFilterBy('')
        this.props.updateDateChange(false)
    }

    clearDate(e) {
        this.props.changeFilterBy('')
        window.jQuery('#calendars').datepicker('setDate', null);
        this.props.updateDateChange(false)
        // this.props.getUpcomingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 6 })
    }
    render() {
        
        var catFilter = window.jQuery('#cat-filter').val()
        return (

            <section className="container-fluid">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 mb-2 mb-sm-4">
                                <h3 className="title">Upcoming Events</h3>
                                <div className="filter-option">
                                    <form className="form-inline">
                                        <label className="lead mr-2">Filters:</label>
                                        <div className="form-group mr-2">
                                            <select className="form-control" id="cat-filter"
                                                onChange={e => { this.filter(e) }}>
                                                <option value="">Choose</option>
                                                {
                                                    this.props.categoryFilterList.length > 0 &&
                                                    this.props.categoryFilterList.map((c, f) => (
                                                        <option value={c.cat_slug}>{c.cat_name}</option>
                                                    ))
                                                }
                                            </select>
                                        </div>
                                        <div className="form-group mr-2">
                                            <select className="form-control" id="month-filter"
                                                onChange={async (e) => {
                                                    await this.props.changeFilterBy('month')
                                                    await this.props.updateDateChange(false)
                                                    this.filter(e)
                                                }}>
                                                <option value="">Choose</option>
                                                <option value="1">January</option>
                                                <option value="2">February</option>
                                                <option value="3">March</option>
                                                <option value="4">April</option>
                                                <option value="5">May</option>
                                                <option value="6">June</option>
                                                <option value="7">July</option>
                                                <option value="8">August</option>
                                                <option value="9">September</option>
                                                <option value="10">October</option>
                                                <option value="11">November</option>
                                                <option value="12">December</option>
                                            </select>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                            <div className="col-md-8" >
                                <div className="row">
                                    <div className={this.props.upcomingEvents.length > 0 ? 'col-12 d-none' : 'col-12 d-block'}>
                                        <h3 className="noarticle">No events to show.</h3>
                                    </div>
                                    <div className="col-12">
                                        {
                                            this.props.upcomingEvents.length > 0 &&
                                            this.props.upcomingEvents.map((o, k) => {
                                                
                                                var cat_name_arr = [];
                                                  
                                                let start_date = o.start_date_and_time[0].split(' ')[0].split('/')[0] 
                                                let end_date = o.end_date_and_time[0].split(' ')[0] 
                                                    // console.log(start_date, 'o.start_date_and_time')
                                                    // console.log(end_date, 'o.end_date_and_time')
                                                    o.end_date_and_time[0] !== '' && 

                                                    (start_date) !==
                                                    (end_date) 
                                                    ?
                                                    cat_name_arr.push(<span style={{ paddingRight: '10px' }}>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                                                        
                                                        {moment(start_date).format("DD MMM YYYY") 
                                                        
                                                        }
                                                        {
                                                             o.end_date_and_time[0] !== ''
                                                             ? (
                                                                 <>
                                                                     { " - " }
                                                                     {moment(end_date).format("DD MMM YYYY") }
                                                                 </>
  
                                                             ): ''
                                                        } 


                                                        {/* <Moment format='DD MMM YYYY' withTitle>{element.split(' ')[0]}</Moment> 
                                                        {
                                                            o.end_date_and_time[0] !== ''
                                                            ? (
                                                                <>
                                                                    { " - " }
                                                    <Moment format='DD MMM YYYY' withTitle>{element.split(' ')[2]}</Moment>
                                                                </>
 
                                                            ): ''

                                                        } */}
                                                        
                                                        </span>)
                                                    : 
                                                    cat_name_arr.push(<span style={{ paddingRight: '10px' }}>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                                                        {moment(start_date).format("DD MMM YYYY") 
                                                        
                                                        }
                                                        </span>)
                                             
                                                return <div className="hor-article-item event-item" data-id={o.ID}>
                                                    <Link to={`/whats_happening/${o.post_name}`} className="art-img"
                                                        onClick={(e) => {
                                                            localStorage.setItem('article_id', jQuery(e.target).closest('.event-item').data('id'))
                                                        }}>
                                                        <img src={(o.thumbnail_image === "" || o.thumbnail_image === null || o.thumbnail_image === undefined) ? o.custom_feature_image_url : o.thumbnail_image} alt="img" />
                                                    </Link>
                                                    <div className="art-cont">
                                                        <span className="date-cal text-truncate">
                                                            {cat_name_arr}
                                                        </span>
                                                       
                                                        <span className="tag"> {
                                                            
                                                        (this.props.filterBy !== "") && (this.props.filterBy !== 'month')
                                                        
                                                         ? o.cat_name.split(',')[0] : o.cat_name.replace(/,/g, ", ")}</span>
                                                        <Link to={`/whats_happening/${o.post_name}`} className="art-title"
                                                            onClick={(e) => {
                                                                localStorage.setItem('article_id', jQuery(e.target).closest('.event-item').data('id'))
                                                            }}>
                                                            <p className="text-truncate">
                                                                {o.post_title}
                                                            </p>
                                                            <span className="text-truncate">
                                                                {o.post_content.replace(/<(.|\n)*?>/g, '')}
                                                            </span>
                                                        </Link>
                                                        <span className="date-time location text-truncate">
                                                            {
                                                                o.venue &&
                                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon.svg"} alt="icon" />
                                                            }
                                                            
                                                            {o.venue}
                                                        </span>
                                                    </div>
                                                </div>
                                            })
                                        }

                                        <div className="hidden-content">
                                        {
                                            this.props.moreUpcomingEvents.length > 0 && 
                                            this.props.moreUpcomingEvents.map((o,k) => {
                                                var cat_name_arr = [];
                                                let start_date = o.start_date_and_time[0].split(' ')[0].split('/')[0] 
                                                let end_date = o.end_date_and_time[0].split(' ')[0] 
                                                  
                                                    o.end_date_and_time[0] !== '' && 

                                                    (start_date) !==
                                                    (end_date) 
                                                    ?
                                                    cat_name_arr.push(<span style={{ paddingRight: '10px' }}>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                                                        
                                                        {moment(start_date).format("DD MMM YYYY") 
                                                        
                                                        }
                                                        {
                                                             o.end_date_and_time[0] !== ''
                                                             ? (
                                                                 <>
                                                                     { " - " }
                                                                     {moment(end_date).format("DD MMM YYYY") }
                                                                 </>
  
                                                             ): ''
                                                        } 


                                                        {/* <Moment format='DD MMM YYYY' withTitle>{element.split(' ')[0]}</Moment> 
                                                        {
                                                            o.end_date_and_time[0] !== ''
                                                            ? (
                                                                <>
                                                                    { " - " }
                                                    <Moment format='DD MMM YYYY' withTitle>{element.split(' ')[2]}</Moment>
                                                                </>
 
                                                            ): ''

                                                        } */}
                                                        
                                                        </span>)
                                                    : 
                                                    cat_name_arr.push(<span style={{ paddingRight: '10px' }}>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                                                        {moment(start_date).format("DD MMM YYYY") 
                                                        
                                                        }
                                                        </span>)
                                             
                                                return <div className="hor-article-item event-item" data-id={o.ID}>
                                                    <Link to={`/whats_happening/${o.post_name}`} className="art-img"
                                                        onClick={(e) => {
                                                            localStorage.setItem('article_id', jQuery(e.target).closest('.event-item').data('id'))
                                                        }}>
                                                        <img src={(o.thumbnail_image === "" || o.thumbnail_image === null || o.thumbnail_image === undefined) ? o.custom_feature_image_url : o.thumbnail_image} alt="img" />
                                                    </Link>
                                                    <div className="art-cont">
                                                        <span className="date-cal text-truncate">
                                                            {cat_name_arr}
                                                        </span>
                                                       
                                                        <span className="tag"> {
                                                            
                                                        (this.props.filterBy !== "") && (this.props.filterBy !== 'month')
                                                        
                                                         ? o.cat_name.split(',')[0] : o.cat_name.replace(/,/g, ", ")}</span>
                                                        <Link to={`/whats_happening/${o.post_name}`} className="art-title"
                                                            onClick={(e) => {
                                                                localStorage.setItem('article_id', jQuery(e.target).closest('.event-item').data('id'))
                                                            }}>
                                                            <p className="text-truncate">
                                                                {o.post_title}
                                                            </p>
                                                            <span className="text-truncate">
                                                                {o.post_content.replace(/<(.|\n)*?>/g, '')}
                                                            </span>
                                                        </Link>
                                                        <span className="date-time location text-truncate">
                                                            {
                                                                o.venue &&
                                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon.svg"} alt="icon" />
                                                            }
                                                            
                                                            {o.venue}
                                                        </span>
                                                    </div>
                                                </div>
                                            
                                            
                                            
                                            }) 
                                            
                                        }
                                         <div className={`col-12 article-list text-center mt-4 ${this.props.upcomingEvents.length > 0 ? 'd-block' : 'd-none'}`}>
                                            <div className="alert" role="alert">
                                            </div>
                                            <button className="btn btn-orange up_more" type="button" onClick={(e) => this.showMoreUpcoming(e)}>Show More</button>
                                        </div>
                                        </div>
                                        <div className={`col-12 article-list text-center mt-4 ${this.props.upcomingEvents.length > 0 ? 'd-block' : 'd-none'}`}>
                                            
                                            <button className="btn btn-orange up_more" type="button" onClick={(e) => this.showMoreUpcoming(e)}>Show More</button>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="mb-5">
                                    <div className="col p-0 calendar">
                                        <div id="calendars" className="custom-calendar" />
                                    </div>
                                    <button 
                                    className="btn btn-orange col pl-5 mt-2" 
                                    onClick = {async (e) => {
                                        await this.props.changeFilterBy('')
                                        await this.props.updateDateChange(false)
                                        this.clearDate(e)}}
                                    type="button">Clear Date</button>
                                </div>
                                
                                {/* <AdSense.Google
                                    client='ca-pub-9111417808865977'
                                    slot='1638754887'
                                    style={{ display: 'block', margin: "auto" }}
                                    format='auto'
                                    responsive='true'
                                    layout="display"
                                    layoutKey='-gw-1+2a-9x+5c'
                                />  */}
                                 
                              

                                        <UserAgentProvider
                                                    ua={ window.navigator.userAgent }
                                                    >
                                                    
                                                    <UserAgent windows mac>
                                                
                                                    <AdSense.Google
                                                            client="ca-pub-9111417808865977"
                                                            slot="2845449790"
                                                            style={{ width: 350, height: 837, float: "left" }}
                                                            format=""
                                                        />
                                            
                                                </UserAgent>
                                                </UserAgentProvider> 
                              
                                    {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-ver.jpg"} alt="ad" /> */}
                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        )
    }
}

const mapStateToProps = (state, ownProps) => {
    //console.log(state.WhatsHappening.setdateArray, 'coming')
    return {
        upcomingEvents: state.WhatsHappening.upcomingEvents,
        ongoingEvents: state.WhatsHappening.ongoingEvents,
        upcomingEventNo: state.WhatsHappening.upcomingEventNo,
        ongoingEventNo: state.WhatsHappening.ongoingEventNo,
        articleMoreStatus: state.WhatsHappening.articleMoreStatus,
        changeDate: state.WhatsHappening.changeDate,
        categoryFilterList: state.WhatsHappening.categoryFilterList,
        filterBy: state.WhatsHappening.filterBy,
        setdateArray: state.WhatsHappening.setdateArray,
        loading: state.WhatsHappening.loading,
        moreUpcomingEvents: state.WhatsHappening.moreUpcomingEvents,
        showHideStatus: state.WhatsHappening.showHideStatus
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getWhatsHappenBanner: (data) => dispatch(actions.getWhatsHappenBanner(data)),
        getFeaturedEvents: (data) => dispatch(actions.getFeaturedEvents(data)),
        getUpcomingEvents: (data) => dispatch(actions.getUpcomingEvents(data)),
        getNewUpcomingEvents: (data) => dispatch(actions.getMoreUpcomingEvents(data)),
        getUpcomingEventsFilter: (data) => dispatch(actions.getUpcomingEventsFilter(data)),
        getNewUpcomingEventsFilter: (data) => dispatch(actions.getMoreUpcomingEventsFilter(data)),
        updateUpcomingEventNo: (data) => dispatch(actions.updateUpcomingEventNo(data)),
        changeArticleMoreStatus: (data) => dispatch(actions.updateArticleMoreStatus(data)),
        updateDateChange: (data) => dispatch(actions.updateDateValue(data)),
        changeFilterBy: (data) => dispatch(actions.updateFilterBy(data)),
        changeLoading: (date) => dispatch(actions.SetLoading(date)),
        changeShowStatus: (date) => dispatch(actions.changeShowStatus(date))
    }
};

const eventsArticles = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Events_Articles);

export default eventsArticles;



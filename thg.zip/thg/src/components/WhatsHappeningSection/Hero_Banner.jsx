/** @format */

import React, { Component, Fragment } from "react";
import jQuery from "jquery";
import { connect } from "react-redux";
import * as actions from "../../actions/Whats_Happening";
import { Link } from "react-router-dom";
import Moment from "react-moment";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Hero_Banner extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    var THIS = this;
    jQuery(document).ready(function () {
      if (THIS.props.whatsHappenBannerList.length > 0) {
        window.$(".banner .owl-carousel").owlCarousel({
          items: 1,
          loop: false,
          dots: true,
          rewind: true,
        });
      }
    });
  }

  componentDidUpdate() {
    var THIS = this;
    jQuery(document).ready(function () {
      if (THIS.props.whatsHappenBannerList.length > 0) {
        window.$(".banner .owl-carousel").owlCarousel({
          items: 1,
          loop: false,
          autoplay:true,
          autoplayTimeout:3000,
          autoplayHoverPause:true,
          dots: true,
          rewind: true,
        });
      }
    });
  }

  render() {
    return (
      <section className="container-fluid hero-banner mb-3 mb-sm-4">
        <div className="row banner">
          {this.props.whatsHappenBannerList.length > 0 && (
            <div className="owl-carousel">
              {this.props.whatsHappenBannerList.map((o, k) => {
                var cat_name = o.cat_name.split(",");
                var cat_name_arr = [];
                let start_date = o.start_date_and_time[0].split(' ')[0] 
                let end_date = o.end_date_and_time[0].split(' ')[0] 
                //alert(end_date)
                cat_name.forEach((element, i) => {
                  cat_name_arr.push(
                    <span key={i} className="tag mr-2 mb-2">
                      {element}
                    </span>
                  );
                });
                return (
                  <Link
                    to={`/whats_happening/${o.post_name}`}
                    key={o.ID}
                    onClick={(e) => {
                      localStorage.setItem(
                        "article_id",
                        jQuery(e.target).closest(".slide-item").data("id")
                      );
                    }}
                  >
                    <div
                      className="slide-item banner-background"
                      data-id={o.ID}
                      // style={{
                      //   backgroundImage: `url(${
                      //     o.custom_feature_image_url === "" ||
                      //     o.custom_feature_image_url === null ||
                      //     o.custom_feature_image_url === undefined
                      //       ? o.image_url
                      //       : o.custom_feature_image_url
                      //   })`,
                      // }}
                    >
                      <img 
                        src={
                          o.custom_feature_image_url === "" ||
                          o.custom_feature_image_url === null ||
                          o.custom_feature_image_url === undefined
                          ? o.image_url
                          : o.custom_feature_image_url
                        } 
                        alt="icon" 
                      />
                      <div className="carousel-cont">
                        <div className="container">
                          {cat_name_arr}
                          <h4>{o.post_title}</h4>
                          <div className="date-location my-3">
                          {
                                  Date.parse(start_date.split('/')[0]) !==
                                  Date.parse(end_date.split('/')[0]) 
                                  ? (
                                   <>
                                   <span className="mr-3">
                                  <img
                                  className="mr-2 lazyload"
                                  data-src={
                                  process.env.PUBLIC_URL +
                                  "/assets/images/calendar-icon.svg"
                                  }
                                  alt="icon"
                                  />
                                  <Moment format="DD MMM YYYY" withTitle>
                                    {o.start_date_and_time[0]}
                                  </Moment>{" "}
                                  {"-"}{" "}
                                  <Moment format="DD MMM YYYY" withTitle>
                                    {o.end_date_and_time[0]}
                                  </Moment>
                                  </span>
                                   </>
                                 ) :
                                 (
                                  <>
                                    <span className="mr-3">
                                    <img
                                      className="mr-2 lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/calendar-icon.svg"
                                      }
                                      alt="icon"
                                    />
                    
                                    <Moment format="DD MMM YYYY" withTitle>
                                      {o.start_date_and_time[0]}
                                    </Moment>
                              
                                    </span>
                                  </>
                                )
                              }
                            
                            <span>
                              <img
                                className="mr-2 lazyload"
                                data-src={
                                  process.env.PUBLIC_URL +
                                  "/assets/images/gps-icon-lg.svg"
                                }
                                alt="icon"
                              />
                              {o.venue}
                            </span>
                          </div>
                          <Link
                            to={`/whats_happening/${o.post_name}`}
                            className="text-link"
                          >
                            View Details
                            <img
                              className="lazyload"
                              data-src={
                                process.env.PUBLIC_URL +
                                "/assets/images/right-arrow-orange.svg"
                              }
                              alt="icon"
                            />
                          </Link>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </section>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    featuredEvents: state.WhatsHappening.featuredEvents,
    whatsHappenBannerList: state.WhatsHappening.whatsHappenBannerList,
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getWhatsHappenBanner: (data) =>
      dispatch(actions.getWhatsHappenBanner(data)),
    getFeaturedEvents: (data) => dispatch(actions.getFeaturedEvents(data)),
  };
};

const heroBanner = connect(mapStateToProps, mapDispatchToProps)(Hero_Banner);

export default heroBanner;

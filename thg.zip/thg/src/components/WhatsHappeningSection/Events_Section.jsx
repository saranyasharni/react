import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Whats_Happening';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Events_Section extends Component {
    constructor(props) {
        super(props);
    }
        
    componentDidMount() {
        var THIS = this;
        jQuery(document).ready(function () {   
            
            jQuery(".btn-orange").click(function(){
                jQuery(this).hide();
                    
            });
        })
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
           // console.log(THIS.props.articleMoreStatus_post, 'sta123')
            if (THIS.props.showHideStatus_past === 1) {
                
                jQuery(".hidden-content-past").slideDown();
              //  jQuery(".hidden-content-past").show()
               //console.log(('.hidden-content .past_show_more').html(), '5678')
                jQuery('.hidden-content-past .past_show_more').show()
                THIS.props.changeShowStatusPast(0);

            }
            if (THIS.props.articleMoreStatus_post === 1) {
                
              //  jQuery('.hidden-content-past .past_show_more').hide()
                jQuery('.article-list .alert').html('<strong>No more events to show.</strong>');
                jQuery('.article-list .alert').removeClass('alert-success').addClass('alert-danger')
                THIS.props.changeArticleMoreStatus(0);

                setTimeout(function () {
                    jQuery(".article-list .alert").removeClass('alert-danger');
                }, 2000);
               
            }
        })
    }

    showMoreOngoing(e) {
        e.preventDefault();
        var search = window.location.pathname.split('/')[2]
        this.props.updateOngoingEventNo({ ongoingFlag: 0 });
        this.props.getNewOngoingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: this.props.ongoingEventNo + 1, limit: 6 })
    }

    render() {

        return (

            <section className="container-fluid my-5">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-12">
                                <h3 className="title">Past Events</h3>
                            </div>
                            <div className="col-md-8">
                                <div className="row">
                                    <div className={this.props.ongoingEvents.length > 0 ? 'col-12 d-none' : 'col-12 d-block'}>
                                        <h3 className="noarticle">No Events</h3>
                                    </div>
                                    <div className="col-12">
                                        {
                                            this.props.ongoingEvents.length > 0 &&
                                            this.props.ongoingEvents.map((o, k) => {
                                                var cat_name_arr = [];
                                              
                                                    // console.log(o.start_date_and_time, 'o.start_date_time[0]')
                                                    let start_date = o.start_date_and_time[0].split(' ')[0]
                                                    let end_date = o.end_date_and_time[0] !== '' 
                                                    ? o.end_date_and_time[0].split(' ')[0] 
                                                    : ''
                                                    o.end_date_and_time[0] !== '' &&
                                                    (start_date) !==
                                                    (end_date) 
                                                    ?
                                                    cat_name_arr.push(<span style={{paddingRight:'10px'}}><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                            
                                                    <Moment format='DD MMM YYYY' withTitle>
                                                    {o.start_date_and_time[0].split(' ')[0]}</Moment> 
                                                    {
                                                        o.end_date_and_time[0] !== ''
                                                        ? (
                                                            <>
                                                            { " - " }
                                                        <Moment format='DD MMM YYYY' withTitle>{o.end_date_and_time[0].split(' ')[0]}</Moment>

                                                            </>
                                                        ) : ''
                                                    }
                                                    
                                                    </span>) :
                                                     cat_name_arr.push(<span style={{paddingRight:'10px'}}><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                            
                                                     <Moment format='DD MMM YYYY' withTitle>
                                                     {o.start_date_and_time[0].split(' ')[0]}</Moment> 
                                                     
                                                     </span>); 

                                              
                                                return <div className="hor-article-item event-item" data-id={o.ID}>
                                                    <Link to={`/whats_happening/${o.post_name}`} className="art-img"
                                                        onClick={(e) => {
                                                            localStorage.setItem('article_id', jQuery(e.target).closest('.event-item').data('id'))
                                                        }}>
                                                        <img className="lazyload" data-src={(o.thumbnail_image === "" || o.thumbnail_image === null || o.thumbnail_image === undefined) ? o.custom_feature_image_url : o.thumbnail_image} alt="img" />
                                                    </Link>
                                                    <div className="art-cont">
                                                        <span className="date-cal text-truncate">
                                                            {/* <img src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" /> */}
                                                            {/* <Moment fromNow>{o.post_date_gmt}</Moment> */}
                                                            {cat_name_arr}
                                                        </span>
                                                        <span className="tag">{o.cat_name.replace(/,/g, ", ")}</span>
                                                        <Link to={`/whats_happening/${o.post_name}`} className="art-title"
                                                            onClick={(e) => {
                                                                localStorage.setItem('article_id', jQuery(e.target).closest('.event-item').data('id'))
                                                            }}>
                                                            <p className="text-truncate">
                                                                {o.post_title}
                                                            </p>
                                                            <span className="text-truncate">
                                                                {o.post_content.replace(/<(.|\n)*?>/g, '').replace()}
                                                            </span>
                                                        </Link>
                                                        <span className="date-time location text-truncate">
                                                            {
                                                            o.venue &&    
                                                            <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon.svg"} alt="icon" />
                                                            }
                                                            {o.venue}
                                                        </span>
                                                    </div>
                                                </div>
                                            })
                                            
                                        }
                                        <div class="hidden-content-past">
										
                                        <div className= {`col-12 article-list text-center mt-4 ${this.props.ongoingEvents.length > 0 ? 'd-block' : 'd-none'}`}>
                                            <div className="alert" role="alert">
                                            </div>
                                            <button className="btn btn-orange past_show_more" type="button" onClick={(e) => this.showMoreOngoing(e)}>Show More</button>
                                        </div>
                                        </div>
                                        
                                        <div className={`col-12 article-list text-center mt-4 ${this.props.ongoingEvents.length > 0 ? 'd-block' : 'd-none'}`}>
                                            
                                            <button className="btn btn-orange past_show_more" type="button" onClick={(e) => this.showMoreOngoing(e)}>Show More</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="text-center d-none d-sm-none d-md-block">
                                    {/* <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/ad-ver.jpg"} alt="ad" /> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        upcomingEvents: state.WhatsHappening.upcomingEvents,
        ongoingEvents: state.WhatsHappening.ongoingEvents,
        upcomingEventNo: state.WhatsHappening.upcomingEventNo,
        ongoingEventNo: state.WhatsHappening.ongoingEventNo,
        articleMoreStatus: state.WhatsHappening.articleMoreStatus,
        showHideStatus_past:state.WhatsHappening.showHideStatus_past,
        articleMoreStatus_post:state.WhatsHappening.articleMoreStatus_post
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getWhatsHappenBanner: (data) => dispatch(actions.getWhatsHappenBanner(data)),
        getFeaturedEvents: (data) => dispatch(actions.getFeaturedEvents(data)),
        getOngoingEvents: (data) => dispatch(actions.getOngoingEvents(data)),
        getNewOngoingEvents: (data) => dispatch(actions.getMoreOngoingEvents(data)),
        updateOngoingEventNo: (data) => dispatch(actions.updateOngoingEventNo(data)),
        changeArticleMoreStatus: (data) => dispatch(actions.updateArticleMoreStatus(data)),
        changeShowStatusPast: (date) => dispatch(actions.changeShowStatusPast(date))
    }
};

const eventsSection = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Events_Section);

export default eventsSection;



import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Whats_Happening';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Featured_Events extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.featuredEvents.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });


            }

        })
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.featuredEvents.length > 0) {
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });


            }

        })
    }

    render() {

        return (

            <section className="container-fluid bg-gray mt-5">
                <div className="row">
                    <div className="container">
                        <h3 className="title">Featured Events</h3>
                        <div className={this.props.featuredEvents.length > 0 ? 'd-none' : 'd-block'}>
                            <h3 className="noarticle">No Events</h3>
                        </div>
                        {
                            this.props.featuredEvents.length > 0 &&
                            (<div className="snip-caurosel owl-carousel">
                                {this.props.featuredEvents.map((o, k) => {
                                    //console.log(o.end_date_and_time, 'DATETIME!@#')
                                    var cat_name = (o.cat_name).split(',');
                                    let start_date = o.start_date_and_time[0].split(' ')[0].split(' ')[0];

                                    let end_date = o.end_date_and_time[0] === ''
                                    ? ''
                                    : o.start_date_and_time[0].split(' ')[3].split(' ')[0]
                                    cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                    return <div className="article-item event-snip" data-id={o.ID}>
                                        <Link to={`/whats_happening/${o.post_name}`} className="art-img art-background"
                                            // style={{ backgroundImage: `url(${(o.thumbnail_image === "" || o.thumbnail_image === null || o.thumbnail_image === undefined) ? o.custom_feature_image_url : o.thumbnail_image})` }}
                                            // onClick={(e) => {
                                            //     localStorage.setItem('article_id', jQuery(e.target).closest('.article-item').data('id'))
                                            // }}
                                            >
                                        <img src={o.s3_thumbnail_image_260 !== null 
                                                ? o.s3_thumbnail_image_260 
                                                : o.thumbnail_image !== null
                                                ? o.thumbnail_image
                                                : o.custom_feature_image_url} alt="img" />    
                                        </Link>
                                        <div className="art-cont">
                                        { 
                                        o.end_date_and_time[0] !== '' && 
                                            (start_date) !== (end_date) ? (
                                                <>
                                                <span className="date-cal text-truncate">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />   
                                                   
                                                <Moment format="DD MMM YYYY" withTitle>
                                                {o.start_date_and_time[0].split(' ')[0]}
                                                </Moment> { " - "}
                                                <Moment format="DD MMM YYYY" withTitle>
                                                {o.start_date_and_time[0].split(' ')[3]}
                                                </Moment> 
                                                </span>
                                                </>
                                            ) : (
                                                <>
                                                <span className="date-cal">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />   
                                                   
                                                <Moment format="DD MMM YYYY" withTitle>
                                                {o.start_date_and_time[0].split(' ')[0]}
                                                </Moment> 
                                        
                                                </span>
                                                </>
                                            )
                                        }
                                        
                                        <span className="tag" style={{color:"#b0b0b0c2"}}>{o.cat_name.replace(/,/g, ", ")}</span>
                                        <Link to={`/whats_happening/${o.post_name}`} className="art-title "
                                            onClick={(e) => {
                                                localStorage.setItem('article_id', jQuery(e.target).closest('.article-item').data('id'))
                                            }}>
                                            <span className="arti_title text-truncate">{o.post_title}</span> 
                                        </Link>
                                        <span className="date-time location text-truncate">
                                            {
                                             o.venue &&    
                                             <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon.svg"} alt="icon" />
                                            }
                                            
                                            {o.venue}
                                        </span>
                                        </div>
                                    </div>
                                })}</div>)}
                    </div>
                </div>
            </section>

        )
    }
}

const mapStateToProps = (state, ownProps) => {
    // console.log('state', state)
    return {
        featuredEvents: state.WhatsHappening.featuredEvents,
        whatsHappenBannerList: state.WhatsHappening.whatsHappenBannerList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getWhatsHappenBanner: (data) => dispatch(actions.getWhatsHappenBanner(data)),
        getFeaturedEvents: (data) => dispatch(actions.getFeaturedEvents(data)),
    }
};

const featuredEvents = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Featured_Events);

export default featuredEvents;



import React, { Component, Fragment } from 'react'
import jQuery from 'jquery'
import { connect } from 'react-redux'
import * as actions from '../../actions/Whats_Happening_Category';
import { Link } from 'react-router-dom';
import Moment from 'react-moment';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Featured_Events extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        var THIS = this;
        jQuery(document).ready(function () {
            console.log(THIS.props.featuredEvents.length, 'owlcheck')
            if (THIS.props.featuredEvents.length > 0) {
                
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });


            }

        })
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            console.log(THIS.props.featuredEvents.length, 'owlcheck')
            if (THIS.props.featuredEvents.length > 0) {
                
                window.$(".snip-caurosel").owlCarousel({
                    items: 4,
                    loop: false,
                    dots: false,
                    margin: 15,
                    nav: true,
                    responsive: {
                        0: {
                            items: 1
                        },
                        768: {
                            items: 4
                        }
                    }
                });


            }

        })
    }

    render() {

        return (

            <section className="container-fluid bg-gray mt-5">
                <div className="row">
                    <div className="container">
                        <h3 className="title">Featured Events</h3>
                        <div className={this.props.featuredEvents.length > 0 ? 'd-none' : 'd-block'}>
                            <h3 className="noarticle">No Articles</h3>
                        </div>
                        {
                            this.props.featuredEvents.length > 0 &&
                            (<div className="snip-caurosel owl-carousel">
                                {this.props.featuredEvents.map((o, k) => {
                                    var cat_name = (o.cat_name).split(',');
                                    cat_name = (cat_name[1] === undefined) ? cat_name[0] : cat_name[1];
                                    let start_date = o.start_date_and_time[0].split(' ')[0].split(' ')[0];
                                    let end_date = o.start_date_and_time[0].split(' ')[3] !== undefined 
                                    ?o.start_date_and_time[0].split(' ')[3]
                                    : ''
                                    return <div className="article-item event-snip" data-id={o.ID}>
                                        <Link to={`/whats_happening/${o.post_name}`} className="art-img art-background"
                                            // style={{ backgroundImage: `url(${(o.thumbnail_image === "" || o.thumbnail_image === null || o.thumbnail_image === undefined) ? o.custom_feature_image_url : o.thumbnail_image})` }}
                                            // onClick={(e) => {
                                            //     localStorage.setItem('article_id', jQuery(e.target).closest('.article-item').data('id'))
                                            // }}
                                            >
                                               <img src={o.s3_thumbnail_image_260 !== null 
                                                ? o.s3_thumbnail_image_260 
                                                : o.thumbnail_image !== null
                                                ? o.thumbnail_image
                                                : o.custom_feature_image_url} alt="img" />    
                                        </Link>
                                        <div className="art-cont">
                                            {
                                            o.end_date_and_time[0] !== '' && 
                                            Date.parse(start_date) !== Date.parse(end_date) ? (
                                                <>
                                                <span className="date-cal text-truncate">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />   
                                                   
                                                <Moment format="DD MMM YYYY" withTitle>
                                                {o.start_date_and_time[0].split(' ')[0]}
                                                </Moment> { " - "}
                                                <Moment format="DD MMM YYYY" withTitle>
                                                {o.start_date_and_time[0].split(' ')[3] !== undefined 
                                                ? o.start_date_and_time[0].split(' ')[3]
                                                : ''
                                            }
                                                </Moment> 
                                                </span>
                                                </>
                                            ) : (
                                                <>
                                                <span className="date-cal">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />   
                                                   
                                                <Moment format="DD MMM YYYY" withTitle>
                                                {o.start_date_and_time[0].split(' ')[0]}
                                                </Moment> 
                                        
                                                </span>
                                                </>
                                            )
                                        }
                                        
                                            {/* <span className="date-cal">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-orange-icon.svg"} alt="icon" />
                                                <Moment format="DD MMM YYYY" withTitle>
                                                    {o.start_date_and_time[0]}
                                                </Moment>
                                            </span> */}
                                            <span className="tag" style= {{color:"#b8b5b5"}}>{o.cat_name.replace(/,/g, " , ")}</span>
                                            <Link to={`/whats_happening/${o.post_name}`} className="art-title text-truncate"
                                                onClick={(e) => {
                                                    localStorage.setItem('article_id', jQuery(e.target).closest('.article-item').data('id'))
                                                }}>
                                                {o.post_title}
                                            </Link>
                                            <span className="date-time location text-truncate">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon.svg"} alt="icon" />
                                                {o.venue}
                                            </span>
                                        </div>
                                    </div>
                                })}</div>)}
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        featuredEvents: state.WhatsHappeningCategory.featuredEvents,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
    }
};

const featuredEvents = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Featured_Events);

export default featuredEvents;



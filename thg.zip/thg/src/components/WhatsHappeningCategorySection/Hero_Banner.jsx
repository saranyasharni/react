import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import jQuery from 'jquery';
import Moment from 'react-moment';
import { withStyles } from '@material-ui/styles';
import {Typography,Backdrop,CircularProgress,Snackbar} from '@material-ui/core';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
const useStyles = theme => ({
    backdrop: {
        //zIndex: theme.zIndex + 1,
        color: '#fff',
    },
});

class Hero_Banner extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const {classes} = this.props;
        return (
            <>
            
            <section className="container-fluid hero-banner mb-3 mb-sm-4">
                {
                    //console.log(this.props.whatshappenArticleDetail, 'done'),
                    this.props.whatshappenArticleDetail.length > 0 &&
                    this.props.whatshappenArticleDetail.map((o, k) => {
                        var cat_name = o.cat_name.split(',')
                        var cat_name_arr = [];

                        let start_date = o.start_date_and_time[0].split(' ')[0] 
                        let end_date = o.end_date_and_time[0].split(' ')[0] 
                        cat_name.forEach((element, i) => {
                            cat_name_arr.push(<span key={i} className="tag mr-2">{element}</span>);
                        });
                        return <div className="row" 
                        // style={{ backgroundImage: `url(${(o.custom_feature_image_url === "" || o.custom_feature_image_url === null || o.custom_feature_image_url === undefined) ? o.image_url : o.custom_feature_image_url})`, backgroundSize: 'cover', backgroundPositionX: '50%', backgroundPositionY: 'center', backgroundRepeat: 'no-repeat', height: '500px', width: '103%' }}
                        >
                            <img
                                className="whats-happen-banner"
                                src={o.custom_feature_image_url}
                                alt="image"
                            />
                            <div className="hero-cont">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-lg-9 col-md-8">
                                            {cat_name_arr}
                                            <h1>{o.post_title}</h1>
                                            <div className="date-location mt-3">
                                                {
                                                    o.end_date_and_time[0] !== '' && 
                                                    Date.parse(start_date) !==
                                                    Date.parse(end_date) 
                                                    ? 
                                                    (
                                                        <>
                                                        <span className="mr-3">
                                                            <img
                                                                className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-icon.svg"}
                                                                alt="icon"
                                                            />
                                                            <Moment format="DD MMM YYYY" withTitle>
                                                                {o.start_date_and_time[0].split(' ')[0]}
                                                            </Moment>
                                                            {
                                                                o.end_date_and_time[0] !== ''
                                                                ? (
                                                                    <>
                                                                    {" - "}
                                                                    <Moment format="DD MMM YYYY" withTitle>
                                                                        {o.end_date_and_time[0]}
                                                                    </Moment>
                                                                    </>
                                                                )
                                                                
                                                                : ''

                                                            }
                                                            
                                                        </span>
                                                         </>
                                                     ) : (
                                                         <>
                                                           <span className="mr-3">
                                                            <img
                                                                className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-icon.svg"}
                                                                alt="icon"
                                                            />
                                                            <Moment format="DD MMM YYYY" withTitle>
                                                                {o.start_date_and_time[0].split(' ')[0]}
                                                            </Moment>
                                                            
                                                            
                                                        </span>
                                                         </>
                                                     )
                                                }
                                               
                                                <span>
                                                    <img
                                                        className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon-lg.svg"}
                                                        alt="icon"
                                                    />
                                                    {o.venue}
                                                </span>
                                            </div>
                                        </div>
                                        {
                                        o.purchase_ticket_link && (
                                        <>
                                        <div className="col-lg-3 col-md-4 book-tic text-right">
                                        {o.purchaseTicket!="" && (o.purchaseTicket !== null) &&              

                                            <a className="btn btn-orange" href={o.purchase_ticket_link} target="_blank">
                                                <img className="mr-3 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/ticket-icon.svg"} alt="icon" />
                                            Purchase Tickets
                                        </a>}
                                        </div>
                                        </>
                                        )}
                                    </div>


                                </div>
                            </div>
                        </div>
                    })
                }
            </section>

            </>

        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        whatshappenArticleDetail: state.WhatsHappeningCategory.whatshappenArticleDetail,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
    }
};

const heroBanner = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Hero_Banner);

export default withStyles(useStyles) (heroBanner);



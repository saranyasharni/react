import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import jQuery from 'jquery';
import Moment from 'react-moment';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import { FacebookShareCount, FacebookShareButton, FacebookIcon, TwitterIcon, TwitterShareButton, WhatsappIcon, WhatsappShareButton } from "react-share";
import { InstagramMedia } from 'react-instagram-media'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

import ReactGA from "react-ga";

class Whats_Happening_Detail extends Component {
    constructor(props) {
        super(props);
    }
    share_on_fb = (title, description) => {
        ReactGA.event({
            category: 'Share On Facebook',
            action: 'Share Event',
            label: title
        });
        var url = window.location.href;
        window.open('http://www.facebook.com/sharer/sharer.php?s=100&p[title]=' + decodeURIComponent(title) + '&u=' + encodeURIComponent(url) + '&p[summary]=' + description, 'sharer', 'toolbar=0,status=0,width=600,height=360');
    }

    componentDidUpdate() {
        jQuery(document).ready(function () {
            jQuery('.wt-detail-cont').find('a').attr('target', "_blank").css("color", "#007bff")
        })
    }
    componentDidMount() {
        jQuery(document).ready(function () {
            jQuery('.wt-detail-cont').find('a').attr('target', "_blank").css("color", "#007bff")
        })
    }

    replaceCumulative(str, find, replace) {
        for (var i = 0; i < find.length; i++) {
            str = str.split(find[i]).join(replace[i]);
        }
        return str;
    };

    whatsappShare() {
        ReactGA.event({
            category: 'Share On Whatsapp',
            action: 'Share Event',
            label: this.props.whatshappenArticleDetail[0].post_title
        });
    }

    twitterShare() {
        ReactGA.event({
            category: 'Share On Twitter',
            action: 'Share Event',
            label: this.props.whatshappenArticleDetail[0].post_title
        });
    }

    render() {
        //alert()
        return (
            <section className="container-fluid wt-detail mt-2">
                <div className="row">
                    <div className="container">
                        {
                            
                            this.props.whatshappenArticleDetail.length > 0 &&
                            this.props.whatshappenArticleDetail.map((o, k) => {

                               
                                var content = o.post_content;
                                content = this.replaceCumulative(o.post_content, ['[/caption]'], ['</caption>']);
                                content = content.replace(/\r\n/g, '</p><p>');
                                content = content.replace(/\[embed]/g, '');
                                content = content.replace(/\[\/embed]/g, '');
                                content = content.replace(/\/\/embed/g, '/embed');
                                content = ReactHtmlParser(content.replace(/\[caption([^\]]+)align="([^"]+)"\s+width="(\d+)"\]/g, ''))
                                return <div className="row">
                                    <div className="col-md-8">
                                        <div className="wt-detail-cont mb-3 mb-sm-5 whats_hapen_content">
                                            <p className="lead">Summary</p>
                                            {content}
                                        </div>
                                        <div className="wt-detail-cont mb-3 mb-sm-5
                                        whats_hapen_content
                                        ">
                                            <p className="lead">Organisation</p>
                                            {ReactHtmlParser(o.organisation)}
                                        </div>
                                        <div className="wt-detail-cont">
                                            <div className="row">
                                                <div className="col-lg-5 col-md-12 mb-4">
                                                    <div className="head">
                                                        <img
                                                            className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/calendar-icon.svg"}
                                                            alt="icon"
                                                        />
                                                        Date &amp; Time
                                                    </div>
                                                    <p>
                                                        {/* {console.log(o.start_date_and_time, 'o.start_date_and_time')}               */}
                                                    <span className="show_format">
                                                    { 
                                                        
                                                        <>
                                                        
                                                        <Moment 
                                                        format="DD MMM YYYY HH:mm" withTitle>
                                                        {o.start_date_and_time[0]}
                                                        </Moment>
                                                        </>
                                                    
                                                    }
                                                    
                                                    {
                                                    o.end_date_and_time[0] !== ''
                                                    ? (
                                                    <>
                                                        { ' - ' }
                                                        {
                                                            
                                                            <>
                                                            <Moment 
                                                            format="DD MMM YYYY HH:mm" withTitle>
                                                            {o.end_date_and_time[0]}
                                                            </Moment>
                                                            </>
                                                            
                                                        }
                                                        
                                                        </>
                                                    ) : ''
                                                    }
                                                    
                                                    <br />
                                                </span>
                                                       
                                                </p>
                                                </div>
                                                <div className="col-lg-3 col-md-12 mb-4">
                                                    <div className="head">
                                                        <img
                                                            className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/gps-icon-lg.svg"}
                                                            alt="icon"
                                                        />
                                                        Venue
                                                    </div>
                                                    <p>
                                                        {ReactHtmlParser(o.venue.replace(/\r\n/g, '<br />'))}
                                                    </p>
                                                </div>
                                                {!o.contact_info ? " " : (
                                                    <>
                                                        <div className="col-lg-4 col-md-12">
                                                    <div className="head">
                                                        <img
                                                            className="mr-2 lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/callout-icon.svg"}
                                                            alt="icon"
                                                        />

                                                        Contact info
                                                    </div>
                                                    <p>{ReactHtmlParser(o.contact_info.replace(/\r\n/g, '<br />'))}
                                                        {/* Tyrone Williams
                                            <br />
                                                        <a href="tel:(341)-021-0016">Phone: (341)-021-0016</a>
                                                        <br />
                                                        <a href="mailto: tyrone.williams@gmail.com">
                                                            Mail: tyrone.williams@gmail.com
                                            </a>
                                                        <br />
                                                        <a href="http://google.com" target="_blank">
                                                            Web: www.rallyrace.com
                                            </a> */}
                                                    </p>
                                                </div>
                                                    </>
                                                )}
                                                
                                            </div>

                                            <div className="share-item mt-4">
                                                <p>Share this:</p>
                                                <ul className="list-inline">
                                                    <li className="list-inline-item">
                                                    <a className="fb-btn" onClick={() => this.share_on_fb(
                                                        this.props.whatshappenArticleDetail.length > 0 && this.props.whatshappenArticleDetail[0].post_title, 'description')}>
                                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/fb-icon.svg"} alt="icon" style={{ cursor: 'pointer' }} />
                                                    </a>
                                                    </li>
                                                    <li className="list-inline-item">
                                                        <WhatsappShareButton
                                                            url={window.location.href}
                                                            title={'whatsapp'}
                                                            separator=":: "
                                                            className="Demo__some-network__share-button"
                                                            onShareWindowClose={() => this.whatsappShare()}
                                                        >
                                                            <WhatsappIcon size={32} round />
                                                        </WhatsappShareButton>
                                                    </li>
                                                    <li className="list-inline-item">
                                                        <TwitterShareButton
                                                            url={window.location.href}
                                                            title={'Twitter'}
                                                            className="Demo__some-network__share-button"
                                                            onShareWindowClose={() => this.twitterShare()}
                                                        >
                                                            <TwitterIcon size={32} round />
                                                        </TwitterShareButton>
                                                    </li>
                                                    <li className="list-inline-item">
                                                        <InstagramMedia
                                                            uri={window.location.href}
                                                        />
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="text-center mt-5 mb-3">
                                            {/* <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="ad"
                                            /> */}
                                        </div>
                                    </div>
                                    <div className="col-md-4">
                                        {/* <div className="wt-detail-cont mb-3 mb-sm-5">
                                            <p className="lead">Event Location</p>
                                            <div className="map-sec">
                                                <img
                                                    style={{ width: "100%" }}
                                                    className="img-fluid"
                                                    src={process.env.PUBLIC_URL + "/assets/images/map-area.jpg"}
                                                    alt="map"
                                                />
                                            </div>
                                        </div> */}
                                    </div>
                                </div>
                            })
                        }
                    </div>
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        whatshappenArticleDetail: state.WhatsHappeningCategory.whatshappenArticleDetail,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
    }
};

const whatsHappeningDetail = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Whats_Happening_Detail);

export default whatsHappeningDetail;



import React, { Component, Fragment } from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import jQuery from 'jquery'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class Footer extends Component {
	constructor(props) {
		super(props);
	}

	componentWillMount() {
		// this.props.getQuickLinks()
		// this.props.getAdvertiseWithUs('advertise-with-us')
		
		//this.props.getPrivacyData('privacy-policy')
		// this.props.getReachUs('reach-us')
		// this.props.getContribute('contribute')
	}

	componentDidUpdate() {
		var THIS = this;
		jQuery(document).ready(function () {
			if (THIS.props.subscribeFooterStatus === 1) {
				THIS.props.resetFooterSubscribe({
					fullName: '',
					email: '',
					subscribeFooterErrors: {}
				})
				jQuery('.ftr-subscribe .alert').html('<strong>Success!</strong> Subscribe Successfully.');
				jQuery('.ftr-subscribe .alert').removeClass('alert-danger').addClass('alert-success')
				setTimeout(function () {
					jQuery(".ftr-subscribe .alert").removeClass('alert-success');
				}, 2000);
				THIS.props.updateSubscribeFooterStatus(0);
			} else if (THIS.props.subscribeFooterStatus === 2) {
				jQuery('.ftr-subscribe .alert').html('<strong>Error!</strong> Already Subscribed.');
				jQuery('.ftr-subscribe .alert').removeClass('alert-success').addClass('alert-danger')
				setTimeout(function () {
					jQuery(".ftr-subscribe .alert").removeClass('alert-danger');
				}, 2000);
				THIS.props.updateSubscribeFooterStatus(0);
			} else if (THIS.props.subscribeFooterStatus === 3) {
				jQuery('.ftr-subscribe .alert').html('<strong>Error!</strong> Failed To Subscribe.');
				jQuery('.ftr-subscribe .alert').removeClass('alert-success').addClass('alert-danger')
				setTimeout(function () {
					jQuery(".ftr-subscribe .alert").removeClass('alert-danger');
				}, 2000);
				THIS.props.updateSubscribeFooterStatus(0);
			}
		})
	}

	footerSubscribe(event) {
		event.preventDefault();
		if (this.validateSubscribeFooterForm()) {
			this.props.createSubscribeFooter({
				fullName: this.props.ftr_fullName,
				email: this.props.ftr_email
			})
		}
	}

	validateSubscribeFooterForm() {
		let valid = true;
		let errors = this.props.subscribeFooterErrors;
		if (this.props.ftr_email == "" || this.props.ftr_email == null) {
			valid = false;
			errors.ftr_email = "Cannot be Empty"
		}
		this.props.updateSubscribeFooterErrors(errors);
		return valid;
	}

	render() {

		return (
			<footer className="container-fluid">
				<div className="row">
					<div className="container">
						<div className="row">

							<div className="col-md-4 col-12 mb-4 mb-sm-0">
								<h4>Quick links</h4>
								<ul className="list-inline quick-link">
									{this.props.categoryList.length > 0 &&
										this.props.categoryList.map((o, k) => {
											
											return <li className="list-inline-item" key={o.term_id}><Link to={`/category/${o.slug}`}>{o.name}</Link></li>
										})

									}
								</ul>
							</div>

							<div className="col-md-4 text-left text-sm-center col-12 mb-4 mb-sm-0">
								<h4>Follow us on</h4>
								<ul className="list-inline social-icon mb-0">
									<li className="list-inline-item">
										<a href="https://www.facebook.com/thehomegroundasia/" target="_blank"><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/facebook.svg"} alt="icon" /></a>
									</li>
									<li className="list-inline-item">
										<a href="https://www.instagram.com/thehomegroundasia/" target="_blank"><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/instagram.svg"} alt="icon" /></a>
									</li>
									<li className="list-inline-item">
										<a href="https://www.youtube.com/channel/UCymcdY7G_Wt7S5duyR7Bbig" target="_blank"><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/youtube-icon.svg"} alt="icon" /></a>
									</li>
								</ul>
							</div>

							<div className="col-md-4">
								<Link style= {{textDecoration:"none"}}to="/subscribe">
								<h4>
									Subscribe to THG
									
									<span>We will tell you everything here</span>
								</h4>
								</Link>

								{/* <form className="ftr-subscribe">
									<div className="alert" role="alert">
									</div>
									<div className="form-group">
										<input type="text" name="email" className="form-control"
											value={(this.props.ftr_email) ? this.props.ftr_email : ''}
											onChange={e => this.props.updateSubscribeFooterInfo('email', e.target.value)}
											placeholder="Enter your mail" />
										{(this.props.subscribeFooterErrors.ftr_email && this.props.subscribeFooterErrors.ftr_email.length > 0) ?
											< span className='' style={{ color: '#E2E2E2' }}>{this.props.subscribeFooterErrors.ftr_email}</span> : ''}
										<button className="send" type="button" onClick={e => this.footerSubscribe(e)}><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/send-icon.svg"} alt="icon" /></button>
									</div>
								</form> */}
							</div>

						</div>
					</div>
				</div>
				<div className="row ftr-btm">
					<div className="container">
						<ul className="ftr-link list-inline text-center">
							<li className="list-inline-item">
								<Link to="/about-us">About Us</Link>
							</li>
							<li className="list-inline-item">
								<Link to="/terms-conditions">Terms & Conditions</Link>
							</li>
							<li className="list-inline-item">
								<Link to="/data-protection-policy">Data Protection Policy</Link>
							</li>
							<li className="list-inline-item">
								<Link to="/career">Careers</Link>
							</li>
							<li className="list-inline-item">
								<Link to="/contribute-to-THG">Contribute With Us</Link>
							</li>
							<li className="list-inline-item">
								<Link to="/reach-us">Reach Us</Link>
							</li>
							<li className="list-inline-item">
								<Link to="/advertise-with-us">Advertise With Us</Link>
							</li>
						</ul>

						<p className="copyright text-center">© 2020 TheHomeGround Asia by "TheHomeGround Digital Network Pte Ltd". All Rights Reserved.</p>

					</div>
				</div>
			</footer>

		)
	}
}



/** @format */

import React, { Component, Fragment } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import GoogleLogin from "react-google-login";
import FacebookLogin from "react-facebook-login";
import jQuery from "jquery";
import Moment from "react-moment";

//import {ReactComponent as minus} from "../assets/images/minus.svg";
import { PageView, initGA, Event } from "./../../tracking";
import ReactGA from "react-ga";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class Header extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    this.getWeather();
    // this.getCountry()
  }

//   getCountry = async () => {
//     fetch('https://extreme-ip-lookup.com/json/')
// .then( res => res.json())
// .then(response => {
//     console.log("Country: ", response.country);
//  })
//  .catch((data, status) => {
//     console.log('Request failed');
//  })
//   };

  getWeather = async () => {
    const country = await fetch(
      "https://api.ipdata.co?api-key=88ae77dfa7ae0262b3edddb07214a312607013f0077f20deaf3792c9"
    );
    const country_name = await country.json();
    let city =
      country_name.city === "Ranipet" ? "Ranipettai" : country_name.city;
    const api_call = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city},${country_name.country_name}&appid=8d2de98e089f1c28e1a22fc19a24ef04`
    );
    const response = await api_call.json();
    // console.log(response, 'hease')
    if(response.cod !== "404" && response.cod !== "500" && response.cod !== "400" ){
      console.log('temp-response', response)
      this.props.resetForm({
        country: country_name.country_name,
        temperature: Math.round((response && response.main.temp !== '' ? 300 :response.main.temp) - 273.15)
      });
    }
    
  };

  componentDidMount() {
    var THIS = this;
    jQuery(document).ready(function () {
      
      if (THIS.props.categoryList.length > 0) {
        window.$(".mscroll-x").mCustomScrollbar({
          axis:"x",
          scrollEasing:"linear",
          scrollInertia: 300
        });
  
        window.$(".mscroll-x-submenu").mCustomScrollbar({
          axis:"x",
          scrollEasing:"linear",
          scrollInertia: 300, 
          scrollbarPosition: "outside"
        });
  
        window.$(".mscroll-y-inside").mCustomScrollbar({
          axis:"y",
          scrollEasing:"linear",
          scrollInertia: 300,
          //autoHideScrollbar: "true",
         // autoExpandScrollbar: "true",
          //scrollbarPosition: "inside"
        });
      }
    })
    
    jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item").click(function(){
      //alert()
			jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item").not(this).removeClass("open");
			if(jQuery(this).hasClass('open'))
			{
				jQuery(this).removeClass("open");
			} else{
				jQuery(this).addClass("open");
			}	
      });
  
  //   jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item > .nav-link").click(function(){
  //     alert()
      
  // })
        // jQuery(".more-menu .minus").click(function() {
        //     // jQuery(this).closest(".more-menu").siblings('.sub-menu').slideUp();
        //     jQuery(this).siblings(".plus").show()
        //     jQuery(this).hide()
        // });
        // jQuery(".more-menu .plus").click(function(){
        //     //jQuery(this).closest(".more-menu").siblings('.sub-menu').slideToggle();
        //     jQuery(this).siblings(".minus").show()
        //     jQuery(this).hide()
        // });
    let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
    // this.props.getSubCategoryList({ user_id: userid, slug: 'sports', page_no: 0 });
    // this.props.getSubCategoryEsports({ user_id: userid, slug: 'esports', page_no: 0 });
    // this.props.getSubCategoryTravel({ user_id: userid, slug: 'travel', page_no: 0 });
    // this.props.getSubCategoryReview({ user_id: userid, slug: 'review', page_no: 0 });
    this.props.getCategoryList();
    initGA("UA-173387540-1");
    PageView();
    var THIS = this;
    THIS.props.getBucketListByUser({
      user_id: localStorage.getItem("user_id"),
    });
    jQuery(document).ready(function () {
      window.jQuery('[data-toggle="tooltip"]').tooltip({
        trigger: "hover",
      });
      window.jQuery('[data-toggle="tooltip"]').on("click", function () {
        window.jQuery(this).tooltip("hide");
      });
      jQuery(".interest-item")
        .off("click")
        .click(function () {
          jQuery(this).toggleClass("active");
        });
      jQuery(".create-bucket-btn").click(function () {
        jQuery(".create-bucket").slideDown();
      });

      jQuery(".create-bucket .btn-trans").click(function () {
        jQuery(".create-bucket").slideUp();
      });

      jQuery(".hdr-nav .nav-link").click(function () {
        jQuery(".navbar-collapse").removeClass("show");
      });
    });
  }

  componentDidUpdate() {
    
    var THIS = this;
    jQuery(document).ready(function () {

      if (THIS.props.categoryList.length > 0) {
        window.$(".mscroll-x").mCustomScrollbar({
          axis:"x",
                scrollEasing:"linear",
                scrollInertia: 300
        });
  
        window.$(".mscroll-x-submenu").mCustomScrollbar({
          axis:"x",
                scrollEasing:"linear",
              scrollInertia: 300, 
                scrollbarPosition: "outside"
        });
  
        window.$(".mscroll-y-inside").mCustomScrollbar({
          axis:"y",
                scrollEasing:"linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
          });
      }
      window.jQuery('[data-toggle="tooltip"]').tooltip({
        trigger: "hover",
      });
      window.jQuery('[data-toggle="tooltip"]').on("click", function () {
        window.jQuery(this).tooltip("hide");
      });

      jQuery(".interest-item")
        .off("click")
        .click(function () {
          jQuery(this).toggleClass("active");
        });
      jQuery(".create-bucket-btn").click(function () {
        jQuery(".create-bucket").slideDown();
      });

      jQuery(".create-bucket .btn-trans").click(function () {
        jQuery(".create-bucket").slideUp();
      });

      jQuery(".hdr-nav .nav-link").click(function () {
        jQuery(".navbar-collapse").removeClass("show");
      });
      if (THIS.props.articleSuccess === 1) {
        THIS.props.resetForm({
          errors: {},
        });
        ReactGA.event({
          category: "Add to favorites",
          action: "Save Article Success",
          label: localStorage.getItem("save_item"),
        });
        let articleId = THIS.props.bucketItem.article_id;
        let bucketId = THIS.props.bucketItem.bucket_id;
        jQuery(".bucket-form .alert").html(
          "Article successfully added to bookmark list."
        );
        jQuery(".bucket-form .alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
        setTimeout(function () {
          jQuery(".bucket-form .alert").removeClass("alert-success");
        }, 2000);
        // THIS.props.changeBucketItem('bucket_id', "")
        jQuery("#bucket_select").val("").trigger("change");
        THIS.props.changeArticleStatus(0);
        setTimeout(function () {
          window.jQuery("#bucket-list").modal("hide");
        }, 2000);
        if (localStorage.getItem("article_detail") === "true") {
          
          jQuery(`img[data-article-id=${articleId}]`).attr(
            "src",
            process.env.PUBLIC_URL + "/assets/images/heart-lg-filled.svg"
          );
          jQuery(`button[data-id=${articleId}]`).attr(
            "data-target",
            "#remove-article"
          );
          jQuery(`button[data-id=${articleId}]`).attr(
            "data-bucket-id",
            bucketId
          );
        } else {
          jQuery(`img[data-article-id=${articleId}]`).attr(
            "src",
            process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"
          );
          jQuery(`a[data-id=${articleId}]`).attr(
            "data-target",
            "#remove-article"
          );
          jQuery(`a[data-id=${articleId}]`).attr("data-bucket-id", bucketId);
        }
      } else if (THIS.props.articleSuccess === 2) {
        ReactGA.event({
          category: "Remove from favorites",
          action: "Remove Article Success",
          label: localStorage.getItem("save_item"),
        });
        let articleId = THIS.props.bucketItem.article_id;
        jQuery("#remove-article .alert").html(
          "<strong>Success!</strong> Article Removed From The Bucket."
        );
        jQuery("#remove-article .alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
        setTimeout(function () {
          jQuery("#remove-article .alert").removeClass("alert-success");
        }, 2000);
        if (localStorage.user_id) {
          THIS.props.get3BucketList({
            user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
          });
          THIS.props.getArticleListByBucket({
            user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
            page_no: 0,
            limit: 12,
            bucket_id: localStorage.bucket_id
              ? localStorage.getItem("bucket_id")
              : 0,
          });
        }
        THIS.props.changeArticleStatus(0);
        setTimeout(function () {
          window.jQuery("#remove-article").modal("hide");
        }, 2000);
        if (localStorage.getItem("article_detail") === "true") {
          jQuery(`img[data-article-id=${articleId}]`).attr(
            "src",
            process.env.PUBLIC_URL + "/assets/images/heart-lg.svg"
          );
          jQuery(`button[data-id=${articleId}]`).attr(
            "data-target",
            "#bucket-list"
          );
          jQuery(`button[data-id=${articleId}]`).attr("data-bucket-id", "");
        } else {
          jQuery(`img[data-article-id=${articleId}]`).attr(
            "src",
            process.env.PUBLIC_URL + "/assets/images/heart.svg"
          );
          jQuery(`a[data-id=${articleId}]`).attr("data-target", "#bucket-list");
          jQuery(`a[data-id=${articleId}]`).attr("data-bucket-id", "");
        }
      } else if (THIS.props.articleSuccess === 3) {
        jQuery(".bucket-form .alert").html(
          "Bookmark list successfully created."
        );
        jQuery(".bucket-form .alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
        THIS.props.changeArticleStatus(0);
        setTimeout(function () {
          jQuery(".bucket-form .alert").removeClass("alert-success");
        }, 2000);
        jQuery(".create-bucket .btn-trans").click();
        jQuery("#bucket_name").val("");
      }

      if (THIS.props.articleError === 1) {
        jQuery(".bucket-form .alert").html(
          "<strong>Error!</strong> Failed To Add."
        );
        jQuery(".bucket-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeArticleErrorStatus(0);
        setTimeout(function () {
          jQuery(".bucket-form .alert").removeClass("alert-danger");
        }, 2000);
      } else if (THIS.props.articleError === 2) {
        jQuery("#remove-article .alert").html(
          "<strong>Error!</strong> Failed To Remove."
        );
        jQuery("#remove-article .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeArticleErrorStatus(0);
        setTimeout(function () {
          jQuery("#remove-article .alert").removeClass("alert-danger");
        }, 2000);
      } else if (THIS.props.articleError === 3) {
        jQuery(".bucket-form .alert").html(
          "<strong>Error!</strong> Failed To Create Bucket."
        );
        jQuery(".bucket-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeArticleErrorStatus(0);
        setTimeout(function () {
          jQuery(".bucket-form .alert").removeClass("alert-danger");
        }, 2000);
      } else if  (THIS.props.articleError === 4) {
        jQuery(".bucket-form .alert").html(
          "<strong>Error!</strong> Bookmark list already exist."
        );
        jQuery(".bucket-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeArticleErrorStatus(0);
        setTimeout(function () {
          jQuery(".bucket-form .alert").removeClass("alert-danger");
        }, 2000);
      }

      if (THIS.props.success) {
        ReactGA.event({
          category: "Registration",
          action: "Publication | Success",
          label: "Email",
        });
      }

      if (THIS.props.registrationStatus === 1) {
        jQuery("#signup-form .alert").html(
          "<strong>Error!</strong> User Already Exist."
        );
        jQuery("#signup-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeRegistrationStatus(0);
        setTimeout(function () {
          jQuery("#signup-form .alert").removeClass("alert-danger");
        }, 2000);
      } else if (THIS.props.registrationStatus === 2) {
        jQuery("#intersted-modal.alert").html(
          "<strong>Success!</strong> Interested Items Added."
        );
        jQuery("#intersted-modal.alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
        setTimeout(function () {
          jQuery("#intersted-modal.alert").removeClass("alert-success");
        }, 2000);
        setTimeout(function () {
          jQuery("#signup-modal").find("button.close").click();
          THIS.props.changeRegistration(false);
        }, 2000);
        THIS.props.changeRegistrationStatus(0);
      } else if (THIS.props.registrationStatus === 3) {
        jQuery("#intersted-modal.alert").html(
          "<strong>Error!</strong> Failed To Add.Try again after some time."
        );
        jQuery("#intersted-modal.alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        setTimeout(function () {
          jQuery("#intersted-modal.alert").removeClass("alert-danger");
        }, 2000);
        THIS.props.changeRegistrationStatus(0);
      } else if (THIS.props.registrationStatus === 4) {
        jQuery("#signup-form .alert").html(
          "<strong>Error!</strong> Failed to sign up. Try again another some time."
        );
        jQuery("#signup-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeRegistrationStatus(0);
        ReactGA.event({
          category: "Registration",
          action: "Publication | Failure",
          label: "Email",
        });
        setTimeout(function () {
          jQuery("#signup-form .alert").removeClass("alert-danger");
        }, 2000);
      }

      if (THIS.props.loginStatus === 1) {
        jQuery("#login-form .alert").html(
          "<strong>Success!</strong> User Logged In."
        );
        jQuery("#login-form .alert")
          .removeClass("alert-danger")
          .addClass("alert-success");
        THIS.props.changeLoginStatus(0);
        ReactGA.event({
          category: "Login",
          action: "Publication | Success",
          label: "Email",
        });
        setTimeout(function () {
          jQuery("#login-form .alert").removeClass("alert-success");
        }, 2000);
        setTimeout(function () {
          window.jQuery("#signup-modal").modal("hide");
          window.location.reload();
        }, 2000);
      } else if (THIS.props.loginStatus === 2) {
        jQuery("#login-form .alert").html(
          "<strong>Error!</strong> Invalid Username and Password"
        );
        jQuery("#login-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeLoginStatus(0);
        ReactGA.event({
          category: "Login",
          action: "Publication | Failure",
          label: "Email",
        });
        setTimeout(function () {
          jQuery("#login-form .alert").removeClass("alert-danger");
        }, 2000);
      } else if (THIS.props.loginStatus === 5) {
        
        jQuery("#login-form .alert").html(
          "<strong>Error!</strong> Failed To Login."
        );
        jQuery("#login-form .alert")
          .removeClass("alert-success")
          .addClass("alert-danger");
        THIS.props.changeLoginStatus(0);
        ReactGA.event({
          category: "Login",
          action: "Publication | Failure",
          label: "Email",
        });
        setTimeout(function () {
          jQuery("#login-form .alert").removeClass("alert-danger");
        }, 2000);
      }
    });
  }

  interestedIn(e) {
    e.preventDefault();
    let interested = [];
    jQuery(".interest-item.active").each(function (item) {
      interested.push(jQuery(this).data("value"));
    });
    this.props.addInterestedByUser({
      user_id: localStorage.getItem("registered_id"),
      interested_in: interested.join(),
    });
  }

  signup(res) {
    this.props.createUser(res);
  }

  login(res) {
    this.props.loginUser(res);
  }

  async formSubmit(e) {
    e.preventDefault();
    if (await this.validateForm()) {
      this.signup({
        first_name: this.props.firstName,
        last_name: this.props.lastName,
        email_id: this.props.email,
        password: this.props.password,
        subscribe_value: 0,
        user_type: 0,
        google_pid: "",
        fb_pid: "",
      });
    }
  }

  async validateForm() {
    await this.props.resetForm({
      errors: {},
    });
    let valid = true;
    let errors = this.props.errors;
    if (this.props.firstName == "") {
      valid = false;
      errors.firstName = "Cannot be Empty";
    }
    if (this.props.lastName == "") {
      valid = false;
      errors.lastName = "Cannot be Empty";
    }
    if (this.props.email == "") {
      valid = false;
      errors.email = "Cannot be Empty";
    }
    if (!this.props.email == "") {
      if (!this.validateEmail(this.props.email)) {
        valid = false;
        errors.email = "please enter a valid email";
      }
    }
    if (this.props.password == "") {
      valid = false;
      errors.password = "Cannot be Empty";
    }
    if (this.props.confirmPassword == "") {
      valid = false;
      errors.confirmPassword = "Cannot be Empty";
    }
    if (this.props.password !== this.props.confirmPassword) {
      valid = false;
      errors.password = "Password Not Matching";
      errors.confirmPassword = "Password Not Matching";
    }
    this.props.updateErrors(errors);
    return valid;
  }

  validateEmail(email) {
    const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

    return expression.test(String(email).toLowerCase());
  }

  async validateLoginForm() {
    await this.props.resetForm({
      errors: {},
    });
    let valid = true;
    let errors = this.props.errors;
    if (this.props.loginEmail == "") {
      valid = false;
      errors.loginEmail = "Cannot be Empty";
    }
    if (!this.props.loginEmail == "") {
      if (!this.validateEmail(this.props.loginEmail)) {
        valid = false;
        errors.loginEmail = "please enter a valid email";
      }
    }
    if (this.props.loginPassword == "") {
      valid = false;
      errors.loginPassword = "Cannot be Empty";
    }
    this.props.updateErrors(errors);
    return valid;
  }

  async loginFormSubmit(e) {
    e.preventDefault();
    if (await this.validateLoginForm()) {
      this.login({
        first_name: "",
        last_name: "",
        email_id: this.props.loginEmail,
        password: this.props.loginPassword,
        subscribe_value: 0,
        user_type: 0,
        google_pid: "",
        fb_pid: "",
      });
    }
  }

  closeModal = () => {
    this.props.resetForm({
      firstName: "",
      lastName: "",
      loginEmail: "",
      loginPassword: "",
      email: "",
      password: "",
      confirmPassword: "",
      success: false,
      errors: {},
    });
    window.jQuery("#signup-modal").modal("hide");
    jQuery(".interest-item").removeClass("active");
  };

  addArticle(e) {
    e.preventDefault();
    if (this.validateArticleBucket()) {
      this.props.addArticleToBucket({
        ...this.props.bucketItem,
        user_id: localStorage.getItem("user_id"),
      });
    }
  }

  validateArticleBucket() {
    let valid = true;
    let errors = this.props.errors;
    if (
      this.props.bucketItem.bucket_id == "" ||
      this.props.bucketItem.bucket_id == undefined ||
      this.props.bucketItem.bucket_id == "undefined"
    ) {
      valid = false;
      errors.bucket_id = "Choose list";
    }
    this.props.updateErrors(errors);
    return valid;
  }

  removeArticle(e) {
    e.preventDefault();
    this.props.removeArticleFromBucket({
      ...this.props.bucketItem,
      user_id: localStorage.getItem("user_id"),
    });
  }

  addBucket(e) {
    e.preventDefault();
    if (this.validateBucket()) {
      this.props.createBucket({
        bucket_name: this.props.bucket_name,
        user_id: localStorage.getItem("user_id"),
      });
    }
  }

  validateBucket() {
    let valid = true;
    let errors = this.props.errors;
    if (this.props.bucket_name == "") {
      valid = false;
      errors.bucketName = "Cannot be Empty";
    }
    this.props.updateErrors(errors);
    return valid;
  }

  showRelatedArticles(e) {
    e.preventDefault();
    let subslug = jQuery(e.target).data('slug')
    
    let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
    this.props.getCategoryList({ user_id: userid, slug: subslug, filter_cat_id: '', page_no: 0, limit: 9 });
    this.props.getFeaturedArticlesList({ user_id: userid, slug: subslug, page_no: 0, filter_cat_id:'', limit: 12 });
    this.props.getPopularArticlesList({ user_id: userid, slug: subslug, page_no: 0, filter_cat_id:'', limit: 6 });
  }
  handleToggle(e) {
    // console.log(jQuery(e.target).attr('class'), "GOTIT")
    // if (jQuery(e.target).attr('class') === 'plus') {
    //   jQuery(e.target).hide()
    //   jQuery(e.target).siblings().show()
    // } else if () {

    // }
    jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item > .more-menu").removeClass("active");
      jQuery(e.target).closest('.more-menu').addClass('active');
      // jQuery(e.target).hide();
      // jQuery(e.target).siblings().show();
      // console.log(jQuery(e.target).closest('.more-menu').siblings(".sub-menu").css('display'), "KKKKKKK");
      if (jQuery(e.target).closest('.more-menu').siblings(".sub-menu").css('display') == 'none') {
        console.log(jQuery(e.target).closest('.more-menu').find('.minus'), "KKKKKKK");
          jQuery(e.target).closest('.more-menu').find('.minus').show()
          jQuery(e.target).closest('.more-menu').find('.plus').hide()
      } else {
        jQuery(e.target).closest('.more-menu').find('.minus').hide()
        jQuery(e.target).closest('.more-menu').find('.plus').show()
      }

      jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item > .more-menu:not(.active)").siblings(".sub-menu").slideUp();
      jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item > .more-menu:not(.active)").find(".minus").hide();
      jQuery(".hor-submenu .hdr-nav .navbar-nav .nav-item > .more-menu:not(.active)").find(".plus").show();
      jQuery(e.target).closest('.more-menu').siblings(".sub-menu").slideToggle();
  }
  render() {
    const htmlDecode = (input) => {
      var e = document.createElement('div');
      e.innerHTML = input;
      return e.childNodes[0].nodeValue;
    } 
    const responseGoogle = (response) => {
      console.log(response, 'response')
      var res = response.profileObj;
      if (res) {
        this.signup({
          first_name: res.givenName,
          last_name: res.familyName,
          email_id: res.email,
          password: null,
          subscribe_value: 0,
          user_type: 2,
          google_pid: res.googleId,
          fb_pid: "",
        });
      }
    };
    const responseGoogleLogin = (response) => {
      console.log(response, 'response')
      var res = response.profileObj;
      if (res) {
        this.login({
          first_name: res.givenName,
          last_name: res.familyName,
          email_id: res.email,
          password: null,
          subscribe_value: 0,
          user_type: 2,
          google_pid: res.googleId,
          fb_pid: "",
        });
      }
    };

    const responseFacebook = (response) => {
      console.log("res", response);
      if (response.status != "unknown") {
        this.signup({
          first_name: response.first_name,
          last_name: response.last_name,
          email_id: response.email,
          password: null,
          subscribe_value: 0,
          user_type: 1,
          google_pid: "",
          fb_pid: response.id,
        });
      }
    };
    const responseFacebookLogin = (response) => {
      console.log("res", response);
      if (response.status != "unknown") {
        this.login({
          first_name: response.first_name,
          last_name: response.last_name,
          email_id: response.email,
          password: null,
          subscribe_value: 0,
          user_type: 1,
          google_pid: "",
          fb_pid: response.id,
        });
      }
    };

    return (

      <Fragment>
        <header className="container-fluid hor-submenu">
          {/* <div className="container check">{undefined}</div> */}
          {/* TopBar Starts here */}
          {/* {console.log(this.props.sub_cat_list_esports, 'Need U')}
          {console.log(this.props.sub_cat_list_travel, 'Need 123')} */}
          <section className="top-bar row">
            <div className="container">
              <div className="row">
                <div className="col-md-6 col-12">
                  <p className="first">
                    <Moment format="llll"></Moment>
                  </p>
                  <p
                    className= "loca_param" 
                    data-id = {this.props.country ? this.props.country: ''}                 
                  >
                    <img
                      className="lazyload"
                      data-src={
                        process.env.PUBLIC_URL + "/assets/images/sun-icon.svg"
                      }
                      alt="icon"
                    />
                    {this.props.country ? this.props.country.toUpperCase(): ''}{" "}
                    {`${this.props.temperature}°C`}
                  </p>
                </div>
                <div className="col-md-6 text-right d-none d-md-block">
                  <p className="first">
                    {this.props.userDetails.length > 0 ||
                    localStorage.user_id ? (
                      <Link
                        data-toggle="tooltip"
                        data-placement="bottom"
                        data-html="true"
                        data-original-title="<p class='mb-1 px-2'><small>Profile</small></p>"
                        to={`/profile/${
                          localStorage.user_login
                            ? localStorage.getItem("user_login")
                            : this.props.userDetails[0].user_login
                        }`}
                      >{`Hi, ${
                        localStorage.user_displayname
                          ? localStorage.getItem("user_displayname")
                          : this.props.userDetails[0].display_name
                      }`}</Link>
                    ) : (
                      <a
                        href="javascript:;"
                        data-toggle="modal"
                        data-target="#signup-modal"
                      >
                        Login &amp; Sign up
                      </a>
                    )}
                  </p>
                  <p>
                    <Link to="/subscribe">Subscribe</Link>
                  </p>
                  {/* {localStorage.getItem("user_id") ? ( */}
                    <p className="pr-0">
                      <Link to="/contribute-to-THG">Contribute With Us</Link>
                    </p>
                  {/* ) : (
                    ""
                  )} */}
                </div>
              </div>
            </div>
          </section>
          {/* TopBar Ends here */}

          {/* Header Menu Starts here */}
          <section className="hdr-menu row">
            <div className="container">
              <div className="row">
                <div className="col-md-2 nav-brand">
                  <Link to={"/"}>
                    <img
                      className="lazyload"
                      data-src={
                        process.env.PUBLIC_URL + "/assets/images/hdr-logo.svg"
                      }
                      alt="THG"
                    />
                  </Link>
                </div>
                <div className="col-md-10 col-12 nav-sec">
                  <nav className="hdr-nav navbar navbar-expand-md">
                    <button
                      className="navbar-toggler"
                      type="button"
                      data-toggle="collapse"
                      data-target="#collapsibleNavbar"
                    >
                      <span>&nbsp;</span>
                      <span>&nbsp;</span>
                      <span>&nbsp;</span>
                    </button>
                    <div
                      className="collapse navbar-collapse justify-content-end"
                      id="collapsibleNavbar"
                    >
                      <ul className="navbar-nav">
                        <li className="add-btn d-block d-md-none">
                          {this.props.userDetails.length > 0 ||
                          localStorage.user_id ? (
                            <Link
                              to={`/profile/${
                                localStorage.user_login
                                  ? localStorage.getItem("user_login")
                                  : this.props.userDetails[0].user_login
                              }`}
                            >{`Hi, ${
                              localStorage.user_displayname
                                ? localStorage.getItem("user_displayname")
                                : this.props.userDetails[0].display_name
                            }`}</Link>
                          ) : (
                            <a
                              href="javascript:;"
                              data-toggle="modal"
                              data-target="#signup-modal"
                            >
                              Login &amp; Sign up
                            </a>
                          )}
                          <a href="javascript:;">Subscribe</a>
                          <a href="javascript:;">Contribute With Us</a>
                        </li>
                        {/* <li className="nav-item">
                          <Link
                            to={"/category/news"}
                            className="nav-link news-nav"
                            onClick = {(e) => {localStorage.setItem('categories', 'news')}}
                          >
                            News
                          </Link>
                        </li> */}
                        {
                         
                          this.props.categoryList.length > 0 && this.props.categoryList.map((o,k) => {
                            const decoded_category = htmlDecode(o.name)
                            return  <li className="nav-item">
                            
                            <Link
                              to={`/category/${o.slug}`}
                              className={`nav-link ${o.slug}-nav`}
                              onClick = {(e) => {localStorage.setItem('categories', `${o.slug}`)}}
                            >
                              <span>
                              {decoded_category}
                              </span>
                            </Link>
                             
                            {o.sub_categories.length > 0 ?
                              
                              <ul className="list-inline sub-menu">
                                <div className="mscroll-x-submenu">
                                  {
                                     o.sub_categories.length > 0 &&
                                      o.sub_categories.map((k, l) => {
                                        let decoded_subCategory = htmlDecode(k.name)
                                          return  <li className="list-inline-item" key={o.child_id}>
                                           <Link 
                                            to= {o.slug !=='reel' ? `/category/${o.slug}/${k.slug}` :`/reel/${k.slug}`} 
                                            data-sub={k.name} 
                                            data-subSlug= 'sports'
                                            data-slug={k.slug} 
                                            onClick = {(e) => {localStorage.setItem('categories', `${o.slug}`)}}
                                          >
                                          {decoded_subCategory}
                                          </Link>
                                       </li>
                                      })
                                  }
                                 
                              </div>
                            </ul> : ''
                           }

                          {
                            o.sub_categories.length > 0 && 
                                <span 
                                className="more-menu"
                                onClick = {(e) => {this.handleToggle(e)}}

                                >
                              <img 
                              className="plus" 
                              src={process.env.PUBLIC_URL +
                                  "/assets/images/plus.svg"
                              } 
                              alt="icon" />
                              <img className="minus" src={
                                process.env.PUBLIC_URL +
                                "/assets/images/minus.svg"
                              }
                            alt="icon" />
                            </span>
                              }
                          </li>
                            
                          })
                        
                          
                        }
                         {/* <li className="nav-item">
                          <Link
                            to={"/category/whats_happening"}
                            className="nav-link whats_happening-nav"
                            onClick = {(e) => {localStorage.setItem('categories', 'whats_happening')}}
                          >
                            What's Happening
                          </Link>
                        </li> */}
                        {/* <li className="nav-item">
                          <Link
                            to={"/category/esports"}
                            className="nav-link esports-nav"
                            onClick = {(e) => {localStorage.setItem('categories', 'esports')}}
                          >
                            Esports
                          </Link>
                          <span className="more-menu">
                            <img 
                            className="plus" 
                            src={process.env.PUBLIC_URL +
                                "/assets/images/plus.svg"
                            } 
                            alt="icon" />
                            <img className="minus" src={
                              process.env.PUBLIC_URL +
                              "/assets/images/minus.svg"
                            }
                          alt="icon" />
                          </span>
                          <ul className="list-inline sub-menu">
                              <div className="mscroll-x-submenu">
                                {
                                   this.props.sub_cat_list_esports.length > 0 &&
                                    this.props.sub_cat_list_esports.map((o, k) => {
                                        return  <li className="list-inline-item" key={o.child_id}>
                                         <Link 
                                         to={`/category/esports/${o.slug}`}
                                         data-sub={o.sub_category} 
                                         data-subSlug= 'esports'
                                         data-slug={o.slug} 
                                        //  onClick={(e) => {
                                        //    this.showRelatedArticles(e)
                                        //  }}
                                       
                                         >{o.sub_category}</Link>
                                     </li>
                                    })
                                }
                               
                            </div>
                          </ul>
                        </li>
                        <li className="nav-item">
                          <Link
                            to={"/category/travel"}
                            className="nav-link travel-nav "
                            onClick = {(e) => {localStorage.setItem('categories', 'travel')}}
                          >
                            Experiences
                          </Link>
                          <span className="more-menu">
                            <img 
                            className="plus" 
                            src={process.env.PUBLIC_URL +
                                "/assets/images/plus.svg"
                            } 
                            alt="icon" />
                            <img className="minus" src={
                              process.env.PUBLIC_URL +
                              "/assets/images/minus.svg"
                            }
                          alt="icon" />
                          </span>
                          <ul className="list-inline sub-menu">
                              <div className="mscroll-x-submenu">
                                {
                                    this.props.sub_cat_list_travel.length > 0 &&
                                    this.props.sub_cat_list_travel.map((o, k) => {
                                        return  <li 
                                          className="list-inline-item"
                                          key={o.child_id}
                                        >
                                        <Link 
                                        to={`/category/travel/${o.slug}`}
                                        
                                          data-sub={o.sub_category} 
                                          data-subSlug= 'travel'
                                          data-slug={o.slug} 
                                          // onClick={(e) => {
                                          //   this.showRelatedArticles(e)
                                          // }}
                                        >
                                          {o.sub_category}
                                        </Link>
                                     </li>
                                    })
                                }
                               
                            </div>
                          </ul>
                        </li>
                        
                        <li className="nav-item">
                          <Link
                            to={"/category/review"}
                            className="nav-link review-nav"
                            onClick = {(e) => {localStorage.setItem('categories', 'review')}}
                          >
                            Review
                          </Link>
                          <span className="more-menu">
                            <img 
                            className="plus" 
                            src={process.env.PUBLIC_URL +
                                "/assets/images/plus.svg"
                            } 
                            alt="icon" />
                            <img className="minus" src={
                              process.env.PUBLIC_URL +
                              "/assets/images/minus.svg"
                            }
                          alt="icon" />
                          </span>
                          <ul className="list-inline sub-menu">
                              <div className="mscroll-x-submenu">
                                {
                                    this.props.sub_cat_list_review.length > 0 &&
                                    this.props.sub_cat_list_review.map((o, k) => {
                                        return  <li 
                                          className="list-inline-item"
                                          key={o.child_id}
                                        >
                                        <Link 
                                          to={`/category/review/${o.slug}`}
                                          data-sub={o.sub_category} 
                                          data-subSlug= 'review'
                                          data-slug={o.slug} 
                                          // onClick={(e) => {
                                          //   this.showRelatedArticles(e)
                                          // }}
                                        >
                                          {o.sub_category}
                                        </Link>
                                     </li>
                                    })
                                }
                               
                            </div>
                          </ul>
                        </li> */}
                        {/* <li className="nav-item">
                          <Link
                            to={"/category/thg-tv"}
                            className="nav-link thgtv-nav"
                            onClick = {(e) => {localStorage.setItem('categories', 'thgtv')}}
                          >
                            THG TV
                          </Link>
                        </li>
                        <li className="nav-item">

                                                    <Link to={"/category/reel"} className="nav-link reel-nav">Reel</Link>
                                                </li>
                       
                        
                        <li className="nav-item">
                          <Link
                            to={"/category/featured-events"}
                            className="nav-link feature-nav"
                            onClick = {(e) => {localStorage.setItem('categories', 'feature')}}
                          >
                            Featured Event
                          </Link>
                        </li> */}
                        <li class="nav-item d-none d-md-block">
                        <Link to={"/search"} className = "nav-link search-btn">
                        <img
                          className="lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/search-icon.svg"
                          }
                          alt="icon"
                        />
                        </Link>
										    </li>
                        {
                          localStorage.getItem('user_id') ? (
                            <>
                            <li class="nav-item d-block d-md-none">
                              {/* <a class="nav-link" href="javascript:;">Profile</a> */}
                              <Link to={`/profile/${localStorage.getItem('user_login')}`} className="nav-link">
                                Profile
                              </Link>
                            </li>
                            <li class="nav-item d-block d-md-none">
                            <Link to={`/bookmarklist/${localStorage.getItem('user_login')}`} className="nav-link">
                              {/* <a class="nav-link" href="javascript:;">Bookmark List</a> */}
                              Bookmark List
                            </Link>
                            </li>
                            {/* <li class="nav-item d-block d-md-none">
                            <Link 
                            to={`/settings/${localStorage.getItem('user_login')}`} 
                            className="nav-link"
                            >
                              settings
                            </Link>
                            </li> */}
                            </>
                          )
                          : (
                           <>
                            <li class="nav-item d-block d-md-none">
                            <a
                              className="nav-link"
                              href="javascript:;"
                              data-toggle="modal"
                              data-target="#signup-modal"
                            >
                              Login
                            </a>
                            </li>
                           </> 
                          )
                        }
                        <li class="nav-item d-block d-md-none">
                          <Link to = "/subscribe" className="nav-link" href="javascript:;">Subscribe</Link>
                        </li>
                        <li class="nav-item d-block d-md-none">
                          <Link to = "/contribute-to-THG" className="nav-link" href="javascript:;">Contribute With Us</Link>
                        </li>
                        <li class="nav-item d-block d-md-none">
                          <Link to = "/about-us" className="nav-link" href="javascript:;">About Us</Link>
                        </li>
                      </ul>
                    </div>
                  </nav>
                  <Link to={"/search"} className = "search-btn d-block d-md-none">
                    <img
                      className="lazyload"
                      data-src={
                        process.env.PUBLIC_URL +
                        "/assets/images/search-icon.svg"
                      }
                      alt="icon"
                    />
                  </Link>
                </div>
              </div>
            </div>
          </section>
          {/* Header Menu Ends here */}
        </header>

        {/* Modal Popup Starts here */}
        <div
          className="modal fade signup-modal"
          id="signup-modal"
          tabIndex="-1"
          role="dialog"
          aria-hidden="true"
        >
          <div className="modal-dialog modal-dialog-centered" role="document">
            <div className="modal-content">
              <button
                type="button"
                className="close"
                onClick={() => this.closeModal()}
              >
                <img
                  src={process.env.PUBLIC_URL + "/assets/images/close-icon.svg"}
                  alt="icon"
                />
              </button>
              <div className="modal-body">
                <div
                  className={
                    this.props.success
                      ? "d-none row nav nav-tabs nav-fill"
                      : "row nav nav-tabs nav-fill"
                  }
                  id="nav-tab"
                  role="tablist"
                >
                  <a
                    className="nav-item active"
                    data-toggle="tab"
                    href="#login-popup"
                    role="tab"
                    aria-controls="nav-home"
                    aria-selected="true"
                  >
                    Login
                  </a>
                  <a
                    className="nav-item"
                    data-toggle="tab"
                    href="#signup-popup"
                    role="tab"
                    aria-controls="nav-profile"
                    aria-selected="false"
                  >
                    Sign up
                  </a>
                </div>
                <div
                  className={
                    this.props.success ? "d-none tab-content" : "tab-content"
                  }
                >
                  <div
                    className="tab-pane fade show active"
                    id="login-popup"
                    role="tabpanel"
                  >
                    <form className="pop-form mt-4" id="login-form">
                      <div className="alert" role="alert"></div>
                      <div className="form-group">
                        <label className="sr-only">Email</label>
                        <input
                          className="form-control"
                          type="text"
                          name="email"
                          placeholder="Email"
                          value={this.props.loginEmail}
                          onChange={(e) => {
                            this.props.changeInput(
                              "loginEmail",
                              e.target.value
                            );
                          }}
                        />
                        {this.props.errors.loginEmail &&
                        this.props.errors.loginEmail.length > 0 ? (
                          <span className="text-danger">
                            {this.props.errors.loginEmail}
                          </span>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="form-group">
                        <label className="sr-only">Password</label>
                        <input
                          className="form-control"
                          type="password"
                          name="password"
                          placeholder="Password"
                          value={this.props.loginPassword}
                          onChange={(e) => {
                            this.props.changeInput(
                              "loginPassword",
                              e.target.value
                            );
                          }}
                        />
                        {this.props.errors.loginPassword &&
                        this.props.errors.loginPassword.length > 0 ? (
                          <span className="text-danger">
                            {this.props.errors.loginPassword}
                          </span>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="form-group text-center">
                        <button
                          type="button"
                          className="mt-3 btn btn-asphalt"
                          onClick={(e) => this.loginFormSubmit(e)}
                        >
                          Login
                        </button>
                      </div>
                    </form>
                    <div className="separate">
                      <span>or</span>
                    </div>
                    <div className="text-center social-btn-wrap">
                      <GoogleLogin
                        className="btn btn-white"
                        clientId="926007051286-9pvcdch05s3jmcnpapj58ilcneodi5ma.apps.googleusercontent.com"
                        onSuccess={responseGoogleLogin}
                        onFailure={responseGoogleLogin}
                        render={(renderProps) => (
                          <button
                            className="btn btn-white"
                            onClick={renderProps.onClick}
                            disabled={renderProps.disabled}
                          >
                            <img
                              className="lazyload"
                              data-src={
                                process.env.PUBLIC_URL +
                                "/assets/images/google-icon-btn.svg"
                              }
                              alt="icon"
                            />
                            Login with Google
                          </button>
                        )}
                      />

                      <FacebookLogin
                        appId="810976889696035"
                        fields="name,email,picture,first_name,last_name"
                        callback={responseFacebookLogin}
                        cssClass="btn btn-white"
                        textButton="Login with Facebook"
                        icon={
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/fb-icon-btn.svg"
                            }
                            alt="icon"
                          />
                        }
                        autoLoad={false}
                        disableMobileRedirect={true}
                      />
                    </div>
                  </div>
                  <div
                    className="tab-pane fade show"
                    id="signup-popup"
                    role="tabpanel"
                  >
                    <form className="pop-form mt-4" id="signup-form">
                      <div className="alert" role="alert"></div>

                      <div className="form-group">
                        <div className="row">
                          <div className="col-md-6 pr-0">
                            <label className="sr-only">First Name</label>
                            <input
                              type="text"
                              className="form-control"
                              name="fname"
                              placeholder="First Name"
                              value={this.props.firstName}
                              onChange={(e) => {
                                if (
                                  e.target.value.match("^[a-zA-Z ]*$") != null
                                ) {
                                  this.props.changeInput(
                                    "firstName",
                                    e.target.value
                                  );
                                }
                              }}
                            />
                            {this.props.errors.firstName &&
                            this.props.errors.firstName.length > 0 ? (
                              <span className="text-danger">
                                {this.props.errors.firstName}
                              </span>
                            ) : (
                              ""
                            )}
                          </div>

                          <div className="col-md-6 border-left pl-0">
                            <label className="sr-only">Last Name</label>
                            <input
                              type="text"
                              className="pl-3 form-control"
                              name="fname"
                              placeholder="Last Name"
                              value={this.props.lastName}
                              onChange={(e) => {
                                if (
                                  e.target.value.match("^[a-zA-Z ]*$") != null
                                ) {
                                  this.props.changeInput(
                                    "lastName",
                                    e.target.value
                                  );
                                }
                              }}
                            />
                            {this.props.errors.lastName &&
                            this.props.errors.lastName.length > 0 ? (
                              <span className="text-danger">
                                {this.props.errors.lastName}
                              </span>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="sr-only">Email</label>
                        <input
                          className="form-control"
                          type="text"
                          name="email"
                          placeholder="Email"
                          value={this.props.email}
                          onChange={(e) => {
                            // console.log("hi", e.target.value);
                            this.props.changeInput("email", e.target.value);
                          }}
                        />
                        {this.props.errors.email &&
                        this.props.errors.email.length > 0 ? (
                          <span className="text-danger">
                            {this.props.errors.email}
                          </span>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="form-group">
                        <label className="sr-only">Password</label>
                        <input
                          className="form-control"
                          type="password"
                          name="password"
                          placeholder="Password"
                          value={this.props.password}
                          onChange={(e) =>
                            this.props.changeInput("password", e.target.value)
                          }
                        />
                        {this.props.errors.password &&
                        this.props.errors.password.length > 0 ? (
                          <span className="text-danger">
                            {this.props.errors.password}
                          </span>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="form-group mb-3">
                        <label className="sr-only">Confirm Password</label>
                        <input
                          className="form-control"
                          type="password"
                          name="confirmPassword"
                          placeholder="Confirm Password"
                          value={this.props.confirmPassword}
                          onChange={(e) =>
                            this.props.changeInput(
                              "confirmPassword",
                              e.target.value
                            )
                          }
                        />
                        {this.props.errors.confirmPassword &&
                        this.props.errors.confirmPassword.length > 0 ? (
                          <span className="text-danger">
                            {this.props.errors.confirmPassword}
                          </span>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="form-group mb-3 lt_cngs">
                        {/* <span className="agree">
                          <img
                            className="mr-1 lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-circle.svg"
                            }
                            alt="icon"
                          />
                        </span> */}
                          {/* <span>By clicking sign up, you agree to the Terms and Conditions of use.</span> */}
                      </div>
                      <div className="form-group text-center">
                        <button
                          type="button"
                          className="mt-3 btn btn-asphalt"
                          onClick={(e) => this.formSubmit(e)}
                        >
                          Sign up
                          <img
                            className="ml-1 lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/next-white-arrow.svg"
                            }
                            alt="icon"
                          />
                        </button>
                      </div>
                    </form>
                    <div className="separate">
                      <span>or</span>
                    </div>
                    <div className="text-center social-btn-wrap">
                      <GoogleLogin
                        className="btn btn-white"
                        clientId="926007051286-9pvcdch05s3jmcnpapj58ilcneodi5ma.apps.googleusercontent.com"
                        onSuccess={responseGoogle}
                        onFailure={responseGoogle}
                        render={(renderProps) => (
                          <button
                            className="btn btn-white"
                            onClick={renderProps.onClick}
                            disabled={renderProps.disabled}
                          >
                            <img
                              className="lazyload"
                              data-src={
                                process.env.PUBLIC_URL +
                                "/assets/images/google-icon-btn.svg"
                              }
                              alt="icon"
                            />
                            Sign up with Google
                          </button>
                        )}
                      />

                      <FacebookLogin
                        appId="810976889696035"
                        fields="name,email,picture,first_name,last_name"
                        callback={responseFacebook}
                        cssClass="btn btn-white"
                        textButton="Sign up with Facebook"
                        icon={
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/fb-icon-btn.svg"
                            }
                            alt="icon"
                          />
                        }
                        autoLoad={false}
                        disableMobileRedirect={true}
                      />
                    </div>
                  </div>
                </div>
                <div
                  className={
                    this.props.success
                      ? "d-block interested p-4"
                      : "d-none interested p-4"
                  }
                >
                  <p className="lead">
                    Are you interested in
                    <span>pick some categories</span>
                  </p>
                  <div
                    className="alert"
                    role="alert"
                    id="intersted-modal"
                  ></div>
                  <div className="row mt-4">
                    <div className="col-md-4">
                      <div className="interest-item" data-value="news">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/sports-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">News</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="sports">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/sports-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">Sports</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="esports">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/esports-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">Culture</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="travel">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/travel-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">Lifestyle</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="review">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/review-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">Review</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="thgtv">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/thg-tv-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">THG TV</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="reel">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/reel-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">Reel</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="events">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/event-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">What's happening</span>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="interest-item" data-value="events">
                        <i className="tick">
                          <img
                            className="lazyload"
                            data-src={
                              process.env.PUBLIC_URL +
                              "/assets/images/tick-orange.svg"
                            }
                            alt="icon"
                          />
                        </i>
                        <img
                          className="mt-4 img-fluid lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/event-icon.svg"
                          }
                          alt="icon"
                        />
                        <span className="text-truncate">Featured Events</span>
                      </div>
                    </div>
                  </div>
                  <h />
                  <div className="col-12 mt-4 text-center">
                    <button
                      className="btn btn-asphalt"
                      type="button"
                      onClick={(e) => {
                        this.interestedIn(e);
                      }}
                    >
                      Done
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          {/* Bucket List Popup Starts here */}
          <div
            className="modal fade"
            id="bucket-list"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img
                    className="lazyload"
                    data-src={
                      process.env.PUBLIC_URL + "/assets/images/close-icon.svg"
                    }
                    alt="icon"
                  />
                </button>
                <div className="modal-head">
                  <h3>Save to BookMark List</h3>
                </div>
                <div className="modal-body">
                  <div className="article-item">
                    <div className="art-img">
                      <img
                        src={
                          process.env.PUBLIC_URL +
                          "/assets/images/popup-thumb.jpg"
                        }
                        alt="image"
                      />
                    </div>
                    <div className="art-cont">
                      <span className="tag">Rally</span>
                      <p className= "model-para-tag">
                        Excepteur sint occaecat cupidatat non proident, sunt in
                        culpa qui officia deserunt mollit anim id est laborum.
                      </p>
                    </div>
                  </div>
                  <form className="bucket-form mt-5">
                    <div className="alert" role="alert"></div>
                    <div className="form-group mt-2 mb-2">
                      <label>Choose your bookmark list</label>
                      <select
                        className="mt-3 form-control"
                        id="bucket_select"
                        value={this.props.bucketItem.bucket_id}
                        onChange={(e) => {
                          jQuery(
                            `a[data-id=${this.props.bucketItem.article_id}]`
                          ).attr("data-bucket-id", e.target.value);
                          this.props.changeBucketItem(
                            "bucket_id",
                            e.target.value
                          );
                        }}
                      >
                        <option value="">Choose...</option>
                        {this.props.bucketList.length > 0 &&
                          this.props.bucketList.map((o, k) => (
                            <option key={k} value={o.id}>
                              {o.bucket_name}
                            </option>
                          ))}
                      </select>
                      {this.props.errors.bucket_id &&
                      this.props.errors.bucket_id.length > 0 ? (
                        <span className="text-danger">
                          {this.props.errors.bucket_id}
                        </span>
                      ) : (
                        ""
                      )}
                    </div>
                    <div className="form-group text-right"
                      onClick = {(e) => {
                        console.log(jQuery(e.target).closest('.text-right').siblings('.create-bucket').find('.form-control'), '567')
                        jQuery(e.target).closest('.text-right').siblings('.create-bucket').find('.form-control').val("")
                      }}
                    >
                      <a
                        href="javascript:;"
                        className="text-link create-bucket-btn"
                      >
                        Create New Bookmark List
                      </a>
                    </div>
                    <div className="form-group create-bucket">
                      <input
                        className="form-control"
                        type="text"
                        placeholder="New bookmark name..."
                        value={this.props.bucket_name}
                        onChange={(e) =>
                          this.props.changeInput("bucket_name", e.target.value)
                        }
                        id="bucket_name"
                      />
                      {this.props.errors.bucketName &&
                      this.props.errors.bucketName.length > 0 ? (
                        <span className="text-danger">
                          {this.props.errors.bucketName}
                        </span>
                      ) : (
                        ""
                      )}
                      <div className="text-right">
                        <a 
                          href="javascript:;" 
                          onClick = {(e) => {{
                            jQuery(e.target).closest('.text-right').siblings('.form-control').val("")
                          }}}
                          className="btn btn-trans">
                          Cancel 
                        </a>
                        <button
                          className="btn btn-green-flat"
                          type="button"
                          onClick={(e) => {
                            this.addBucket(e);
                          }}
                        >
                          Save
                        </button>
                      </div>
                    </div>
                    <div className="form-group mt-5 mb-3 text-center">
                      <button
                        className="mt-5 btn btn-asphalt"
                        type="button"
                        onClick={(e) => {
                          this.addArticle(e);
                        }}
                      >
                        Save to BookMark list
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          {/* Bucket List Popup Ends here */}
          {/* Remove Popup Starts here */}
          <div
            className="modal fade"
            id="remove-article"
            tabIndex={-1}
            role="dialog"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <img
                    className="lazyload"
                    data-src={
                      process.env.PUBLIC_URL + "/assets/images/close-icon.svg"
                    }
                    alt="icon"
                  />
                </button>
                <div className="modal-body text-center p-5">
                  <img
                    className="img-fluid mb-4 lazyload"
                    data-src={
                      process.env.PUBLIC_URL +
                      "/assets/images/doc-remove-icon.svg"
                    }
                    alt="icon"
                  />
                  <h3>Are you sure want to remove?</h3>
                  <p className="sub-title">
                    This post will be removed <br />
                    from your bookmark.
                  </p>
                  <div className="alert"></div>
                  <div className="col-12 mt-4 btn-wrap">
                    <button
                      className="btn btn-gray"
                      type="button"
                      data-dismiss="modal"
                    >
                      Cancel
                    </button>
                    <button
                      className="btn btn-red"
                      type="button"
                      onClick={(e) => this.removeArticle(e)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Remove Popup Ends here */}
        </div>
      </Fragment>
    );
  }
}

/** @format */

import React, { Component, Fragment } from "react";

import jQuery from "jquery";

import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";
import { userDetails } from "../actions/common/Header";
import { THGTvList } from "../actions/Home";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

export default class Coach_Listing extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    var THIS = this;
    this.props.updateCoachPageNo({ flag: 1 });
    // THIS.props.getCoachListByUser({
    //   user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
    //   page_no: 0,
    //   limit: 9,
    //   search_term: "",
    // });
  }

  showMore(e) {
    e.preventDefault();
    this.props.updateCoachPageNo({ flag: 0 });
    this.props.getNewCoachListByUser({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      page_no: this.props.coachPageNo + 1,
      limit: 9,
      search_term: this.props.coachSearch ? this.props.coachSearch : "",
    });
  }

  searchCoachList(e) {
    e.preventDefault();
    this.props.updateCoachPageNo({ flag: 1 });
    this.props.getCoachListByUser({
      user_id: localStorage.user_id ? localStorage.getItem("user_id") : 0,
      page_no: 0,
      limit: 9,
      search_term: this.props.coachSearch,
    });
  }

  coachModal(e, userid) {
    e.preventDefault();
    var userDetail = this.props.coachList.filter(function (item) {
      return item.ID === userid;
    });
    this.props.updateCoachDetails(userDetail[0]);
    window.jQuery("#coach-detail").modal("show");
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>
            {/* Main Wrapper Starts here */}

            {/* Coach Listing Starts here */}
            <section className="container-fluid mt-5">
              <div className="row">
                <div className="container">
                  <div className="row">
                    <div className="col-12 text-center mb-5">
                      {/* <img
                        className="img-fluid"
                        src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                        alt="Ad"
                      /> */}
                    </div>
                    <div className="col-md-12">
                      <h3 className="title">Coaches</h3>
                      <div className="container">
                        <form action="" className="filter-form row">
                          <div className="col-12 form-title">Search :</div>
                          <div className="col-md-8 form-group">
                            <input
                              placeholder="Enter Location,Name or Profession"
                              type="text"
                              className="form-control"
                              name
                              onChange={(e) => {
                                e.preventDefault();
                                if (!e.target.value) {
                                  this.props.updateCoachPageNo({ flag: 1 });
                                  this.props.getCoachListByUser({
                                    user_id: localStorage.user_id
                                      ? localStorage.getItem("user_id")
                                      : 0,
                                    page_no: 0,
                                    limit: 9,
                                    search_term: "",
                                  });
                                }
                                this.props.updateCoachSearch(e.target.value);
                              }}
                            />
                          </div>
                          <div className="col-md-2 form-group">
                            <button
                              type="button"
                              className="btn btn-orange submit form-control"
                              onClick={(e) => {
                                this.searchCoachList(e);
                              }}
                            >
                              Search
                            </button>
                          </div>
                        </form>
                      </div>
                      <div className="row">
                        {this.props.coachList.length > 0 &&
                          this.props.coachList.map((o, k) => {
                            return (
                              <div className="col-md-6 col-lg-4">
                                <div className="coach-item">
                                  <div className="coach-img">
                                    <img
                                      className="img-fluid"
                                      src={o.guid}
                                      alt="img"
                                      data-id={o.ID}
                                      onClick={(e) => {
                                        this.coachModal(
                                          e,
                                          jQuery(e.target).data("id")
                                        );
                                      }}
                                    />
                                  </div>
                                  <div className="coach-cont">
                                    <p className="name">
                                      {o.display_name}
                                      <span className="mt-1">
                                        {o.profession ? o.profession : ""}
                                      </span>
                                    </p>
                                    <a
                                      href={`tel:${
                                        o.phone_no && o.phone_no != "undefined"
                                          ? o.phone_no
                                          : ""
                                      }`}
                                    >
                                      <img
                                        src={
                                          process.env.PUBLIC_URL +
                                          "/assets/images/phone-icon.svg"
                                        }
                                        alt="icon"
                                      />
                                      <span className="text-truncate">
                                        {o.phone_no && o.phone_no != "undefined"
                                          ? o.phone_no
                                          : ""}
                                      </span>
                                    </a>
                                    <a
                                      className="mb-0"
                                      href={
                                        o.user_email &&
                                        o.user_email != "undefined"
                                          ? o.user_email
                                          : ""
                                      }
                                    >
                                      <img
                                        src={
                                          process.env.PUBLIC_URL +
                                          "/assets/images/envelope-icon.svg"
                                        }
                                        alt="icon"
                                      />
                                      <span className="text-truncate">
                                        {o.user_email &&
                                        o.user_email != "undefined"
                                          ? o.user_email
                                          : ""}
                                      </span>
                                    </a>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        <div className="col-md-12 text-center my-5 pb-3">
                          <button
                            className="btn btn-orange"
                            type="button"
                            onClick={(e) => {
                              this.showMore(e);
                            }}
                          >
                            Show More
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            {/* Coach Listing Ends here */}
            {/* Main Wrapper Ends here */}
            {/* Modal Popup Starts here */}
            <div
              className="modal fade coach-detail"
              id="coach-detail"
              tabIndex={-1}
              role="dialog"
              aria-hidden="true"
            >
              <div
                className="modal-dialog modal-dialog-centered"
                role="document"
              >
                <div className="modal-content">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <img
                      className="lazyload"
                      data-src={
                        process.env.PUBLIC_URL + "/assets/images/close-icon.svg"
                      }
                      alt="icon"
                    />
                  </button>
                  <div className="modal-body p-0">
                    <div className="col-12 p-0 coach-img">
                      <img
                        className="img-fluid lazyload"
                        data-src={this.props.coachDetails.guid}
                        alt="icon"
                      />
                    </div>
                    <div className="coach-cont">
                      <p className="name">
                        {this.props.coachDetails.display_name}
                        <span className="mt-1">
                          {this.props.coachDetails.profession
                            ? this.props.coachDetails.profession
                            : ""}
                        </span>
                      </p>
                      <p className="short-bio">
                        Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium doloremque laudantium, totam rem
                        aperiam, eaque ipsa quae ab illo inventore veritatis et
                        quasi architecto beatae vitae dicta sunt explicabo.
                      </p>
                      <a
                        href={`tel:${
                          this.props.coachDetails.phone_no &&
                          this.props.coachDetails.phone_no != "undefined"
                            ? this.props.coachDetails.phone_no
                            : ""
                        }`}
                      >
                        <img
                          className="lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/phone-icon.svg"
                          }
                          alt="icon"
                        />
                        <span>
                          {this.props.coachDetails.phone_no &&
                          this.props.coachDetails.phone_no != "undefined"
                            ? this.props.coachDetails.phone_no
                            : ""}
                        </span>
                      </a>
                      <a
                        href={
                          this.props.coachDetails.user_email &&
                          this.props.coachDetails.user_email != "undefined"
                            ? this.props.coachDetails.user_email
                            : ""
                        }
                      >
                        <img
                          className="lazyload"
                          data-src={
                            process.env.PUBLIC_URL +
                            "/assets/images/envelope-icon.svg"
                          }
                          alt="icon"
                        />
                        <span>
                          {this.props.coachDetails.user_email &&
                          this.props.coachDetails.user_email != "undefined"
                            ? this.props.coachDetails.user_email
                            : ""}
                        </span>
                      </a>
                      <a className="lh-unset mb-0" href="javascript:;">
                        <img
                          className="lazyload"
                          data-src={
                            process.env.PUBLIC_URL + "/assets/images/gps-xs.svg"
                          }
                          alt="icon"
                        />
                        <span>
                          {this.props.coachDetails.location &&
                          this.props.coachDetails.location != "undefined"
                            ? this.props.coachDetails.location.split(",")[0]
                            : ""}
                          <br />
                          {this.props.coachDetails.location &&
                          this.props.coachDetails.location != "undefined"
                            ? this.props.coachDetails.location.split(",")[1]
                            : ""}
                        </span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

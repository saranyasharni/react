import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/Video_Detail';
import jQuery from 'jquery';
import {
    FacebookShareCount,
    FacebookShareButton,
    FacebookIcon,
    TwitterIcon,
    TwitterShareButton,
    WhatsappIcon,
    WhatsappShareButton,
  } from "react-share";
import ReactGA from "react-ga";
import Moment from 'react-moment';
import * as headerActions from "../../actions/common/Header";
import { Link } from 'react-router-dom';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import ReactPlayer from 'react-player'
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Article_Details extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        localStorage.setItem('article_detail', true)
        jQuery.getJSON("https://api.ipify.org?format=json",
            function (data) {
                console.log('data', data)
                localStorage.setItem('ip_address', data.ip)
            })
    }

    componentDidMount() {
        var THIS = this
        jQuery(document).ready(function () {
            if (THIS.props.latestVideos.length > 0) {
                window.$(".mscroll-y").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "outside"
                });
                window.$(".mscroll-y-inside").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "inside"
                });
            }

        })

    }


    componentDidUpdate() {
        var THIS = this
        jQuery(document).ready(function () {
            if (THIS.props.latestVideos.length > 0) {
                window.$(".mscroll-y").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "outside"
                });
                window.$(".mscroll-y-inside").mCustomScrollbar({
                    axis: "y",
                    scrollEasing: "linear",
                    scrollInertia: 300,
                    autoHideScrollbar: "true",
                    autoExpandScrollbar: "true",
                    scrollbarPosition: "inside"
                });
            }
            jQuery(".change-pass").off('click').click(function () {
                jQuery(".change-pass-encl").slideUp();
                jQuery(".change-pass").show();
                jQuery(this).hide();
                jQuery(this).parent().find(".change-pass-encl").slideToggle();
                THIS.props.updateCommentReview('rating', 0)
            });

            jQuery(".cancel-pass").off('click').click(function () {
                jQuery(".change-pass").show();
                jQuery(".change-pass-encl").slideUp();
                THIS.props.updateCommentReview('rating', 0)
            });

        })

        if (THIS.props.commentStatus === 1) {
            jQuery('.rating-item').find('a').removeClass('active')
            jQuery('.add-comment .alert').html('<strong>Success!</strong> Comment Created Successfully.');
            jQuery('.add-comment .alert').removeClass('alert-danger').addClass('alert-success')
            setTimeout(function () {
                jQuery(".add-comment .alert").removeClass('alert-success');
            }, 2000);
            THIS.props.updateCommentReview('commentStatus', 0);
            THIS.props.updateCommentReview('comment_review', '');
        } else if (THIS.props.commentStatus === 2) {
            jQuery('.add-comment .alert').html('<strong>Error!</strong> Failed To Add Comment.');
            jQuery('.add-comment .alert').removeClass('alert-success').addClass('alert-danger')
            setTimeout(function () {
                jQuery(".add-comment .alert").removeClass('alert-danger');
            }, 2000);
            THIS.props.updateCommentReview('commentStatus', 0);
        }

        if (THIS.props.replyCommentStatus === 1) {
            jQuery('.rating-item').find('a').removeClass('active')
            jQuery('.reply-section .alert').html('<strong>Success!</strong> Comment Created Successfully.');
            jQuery('.reply-section .alert').removeClass('alert-danger').addClass('alert-success')
            setTimeout(function () {
                jQuery(".reply-section .alert").removeClass('alert-success');
            }, 2000);
            setTimeout(function () {
                jQuery(".change-pass").show();
                jQuery(".change-pass-encl").slideUp();
            }, 1000);
            THIS.props.updateCommentReview('replyCommentStatus', 0);
            THIS.props.updateCommentReview('reply_comment_review', '');
        } else if (THIS.props.replyCommentStatus === 2) {
            jQuery('.reply-section .alert').html('<strong>Error!</strong> Failed To Add Comment.');
            jQuery('.reply-section .alert').removeClass('alert-success').addClass('alert-danger')
            setTimeout(function () {
                jQuery(".reply-section .alert").removeClass('alert-danger');
            }, 2000);
            THIS.props.updateCommentReview('replyCommentStatus', 0);
        }

        jQuery('.rating-item').off('click').click(function () {
            jQuery('.rating-item').find('a').removeClass('active')
            jQuery(this).prevAll().find('a').addClass('active')
            jQuery(this).find('a').addClass('active')
            console.log('count', jQuery('.rating-item').find('a.active').length)
            THIS.props.updateCommentReview('rating', jQuery('.rating-item').find('a.active').length);
        })

    }

    componentWillUnmount(){
        localStorage.setItem('article_detail', false)
    }
    share_on_fb = (title, description) => {
        ReactGA.event({
          category: "Share On Facebook",
          action: "Share Article",
          label: title,
        });
        var url = window.location.href;
        window.open(
          "http://www.facebook.com/sharer/sharer.php?s=100&p[title]=" +
            decodeURIComponent(title) +
            "&u=" +
            encodeURIComponent(url) +
            "&p[summary]=" +
            description,
          "sharer",
          "toolbar=0,status=0,width=600,height=360"
        );
      };
    

    createComment(e) {
        e.preventDefault()
        this.props.createCommentForArticle({
            user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0,
            article_id: this.props.articleVideoDetail[0].ID,
            comment_content: this.props.comment_review,
            author_ip: localStorage.getItem('ip_address'),
            author_name: localStorage.getItem('user_login'),
            email_id: localStorage.getItem('user_email'),
            rating_count: this.props.rating
        })
    }

    replyComment(e) {
        e.preventDefault()
        this.props.replyCommentForArticle({
            user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0,
            article_id: this.props.articleVideoDetail[0].ID,
            comment_content: this.props.reply_comment_review,
            author_ip: localStorage.getItem('ip_address'),
            author_name: localStorage.getItem('user_login'),
            email_id: localStorage.getItem('user_email'),
            rating_count: this.props.rating,
            comment_id: this.props.comment_id
        })
    }
    replaceCumulative(str, find, replace) {
   
        for (var i = 0; i < find.length; i++) {
            if (str !== null) {
                str = str.split(find[i]).join(replace[i]);
            } else {
                str = ''
            }
          
        }
        //console.log(str, 'str345')
        return str;
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        var url = jQuery('.article-hero-img img').attr('src')
        var tit = [];
        jQuery('.tag-wrap span').each(function () {
            tit.push(jQuery(this).text())
        });
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(tit[0])
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery('.article-title').text())
        localStorage.setItem('save_item', jQuery('.article-title').text())
    }

    whatsappShare() {
        ReactGA.event({
            category: "Share On Whatsapp",
            action: "Share Article",
            label: this.props.articleVideoDetail[0].post_title,
        });
    }
    
    twitterShare() {
        ReactGA.event({
            category: "Share On Twitter",
            action: "Share Article",
            label: this.props.articleVideoDetail[0].post_title,
        });
    }

    render() {
        const htmlDecode = (input) => {
            var e = document.createElement('div');
            e.innerHTML = input;
            return e.childNodes[0].nodeValue;
        } 
        return (
            <section className="container-fluid article-content">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 text-center my-5">
                                {/* <img
                                    className="img-fluid"
                                    src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                    alt="Ad"
                                /> */}
                            </div>
                            {
                                this.props.articleVideoDetail.length > 0 ?
                                this.props.articleVideoDetail.map((o, k) => {
                                    var content = o.post_content;
                                    content = this.replaceCumulative(
                                    o.post_content,
                                    ["[/caption]"],
                                    ["</caption>"]
                                    );

                                    content = this.replaceCumulative(
                                    o.post_content,
                                    ["][/video]"],
                                    ["</video>"]
                                    );
                                
                                    content = content.replace(/\r\n/g, "</p><p>");
                                    content = content.replace(/\[embed]/g, "");
                                    content = content.replace(/\[\/embed]/g, "");
                                    content = content.replace(/\/\/embed/g, "/embed");  
                                    content = content.replace(/\[video/g, "<video>"); 
                                // content = content.replace(/\"][video]"/g, "</video>"); 

                                    // console.log(content, 'content')
                                    content = ReactHtmlParser(
                                    // content.replace(
                                    //   /\[video([^\]]+)width="(\d+)"\s+height="(\d+)"/g,
                                    //   "<video>"
                                    // ),

                                    content.replace(
                                        /\[caption([^\]]+)align="([^"]+)"\s+width="(\d+)"\]/g,
                                        ""
                                    ), {
                                        
                                        transform: function  transform(node, index) {
                                        if (node.type === 'tag' && node.name === 'img') {
                                            let cls = node.attribs.class
                                            node.attribs.class = `${cls} lazyload`;
                                            return convertNodeToElement(node, index, transform);
                                        }
                                        if (node.type === 'tag' && node.name === 'video') {

                                            node.attribs.controls = 'controls'
                                            node.attribs.controlsList= "nodownload"
                                            node.attribs.width="500px" 
                                            node.attribs.height="300px"
                                            let mp4 = node.children[0].data.split('mp4=')[1].replace('"','')
                                         //   console.log(mp4, 'mp4')
                                            let video = mp4.replace('"', '').replace('][/video]', '')
                                            node.children[0].data =  <source src={video} type="video/mp4"></source>
                                            return convertNodeToElement(node, index, transform);

                                        }
                                        
                                        }
                                    });
                                    var cat_name = o.cat_name ? o.cat_name.split(",") : [];
                                    var cat_slugs = o.cat_slug ? o.cat_slug.split(",") : [];
                                    var cat_name_arr = [];
                                    cat_name.forEach((element, i) => {
                                    let decoded_subCategory = htmlDecode(element)
                                    cat_name_arr.push(<Link to = {`/reel/${cat_slugs[i]}`}><span key={i}>{decoded_subCategory}</span></Link>);
                                    });
                                    return <div className="col-md-8">
                                        <div className="row">
                                            <div className="col-12 mb-3">
                                                <div className="article-hero-img mb-3">
                                                    {
                                                    
                                                    (o.custom_s3_video_link) ? <ReactPlayer className="thumb" url={o.custom_s3_video_link} 
                                                    
                                                    width='100%' height='340px' playing controls
                                                    config={{ file: { 
                                                        attributes: {
                                                            controlsList: 'nodownload'
                                                        }
                                                    }}} 
                                                    /> :
                                                    <ReactPlayer className="thumb" url={o.custom_video_link} width='100%' height='340px' 
                                                    config={{ file: { 
                                                        attributes: {
                                                            controlsList: 'nodownload'
                                                        }
                                                    }}} 
                                                    playing controls />}
                                                    {/* <video className="thumb" src={"https://thgtv-image-upload.s3.ap-southeast-1.amazonaws.com/1590662682121_videoplayback.mp4"} alt="video" controls autoPlay playsinline loop muted style={{ width: '100%', height: '340px' }} /> */}
                                                    {/* <iframe width="100%" height="350" src="https://www.youtube.com/embed/96kI8Mp1uOU?autoplay=1" frameborder="0" allowfullscreen></iframe> */}
                                                </div>
                                                <div className="article-head">
                                                    <div className="tag-wrap">
                                                        {cat_name_arr}
                                                    </div>
                                                    <div className="share-sec text-right">
                                                        <button className="favorite"
                                                         id = "video_share_sec"
                                                         data-id={o.ID} data-bucket-id={o.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                            onClick={(e) => {
                                                                this.bucketList(e)
                                                            }}>
                                                            <img className="lazyload" data-src={(o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-lg-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart-lg.svg"} alt="icon" data-article-id={o.ID} />
                                                            <img
                                                                className="filled lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/heart-lg-filled.svg"}
                                                                alt="icon"
                                                            />
                                                        </button>
                                                        <div className="article-share-btn">
                                <button className="share">
                                  <img
                                    className="lazyload"
                                    data-src={
                                      process.env.PUBLIC_URL +
                                      "/assets/images/share.svg"
                                    }
                                    alt="icon"
                                  />
                                </button>
                                <div className="article-share-sec">
                                  <a
                                    className="fb-btn"
                                    onClick={() =>
                                      this.share_on_fb(
                                        this.props.articleVideoDetail[0].post_title,
                                        "description"
                                      )
                                    }
                                  >
                                    <img
                                      className="lazyload"
                                      data-src={
                                        process.env.PUBLIC_URL +
                                        "/assets/images/fb-icon.svg"
                                      }
                                      alt="icon"
                                      style={{ cursor: "pointer" }}
                                    />
                                  </a>
                                  {/* <a href="whatsapp://send" data-text="Text you want to Share" class="wa_btn wa_btn_s" data-href="URL you want to share" >
                              <button>Share on WhatsApp</button>
                            </a> */}
                                  {/* <a className="fb-btn" onClick={this.share_on_fb('title', 'description')}><i className="fa fa-facebook" aria-hidden="true"></i></a> */}
                                  {/* <FacebookShareButton
                              url={window.location.href}
                              quote={"hi hello this is my article"}
                              className="Demo__some-network__share-button"
                            >
                              <FacebookIcon size={32} round />
                            </FacebookShareButton> */}
                                  <br />
                                  {/* <a href="javascript:;">
                              <img src={"../../assets/images/articledetail/fb-icon.svg"} alt="icon" />
                              Facebook
                            </a> */}
                                  {/* <a href="javascript:;">
                              <img src={"../../assets/images/articledetail/insta-icon.svg"} alt="icon" />
                              Instagram
                            </a> */}
                                  <WhatsappShareButton
                                    url={window.location.href}
                                    title={"whatsapp"}
                                    separator=":: "
                                    className="Demo__some-network__share-button"
                                    onShareWindowClose={() =>
                                      this.whatsappShare()
                                    }
                                  >
                                    <WhatsappIcon size={32} round />
                                  </WhatsappShareButton>
                                  <br />
                                  <TwitterShareButton
                                    url={window.location.href}
                                    title={"Twitter"}
                                    className="Demo__some-network__share-button"
                                    onShareWindowClose={() =>
                                      this.twitterShare()
                                    }
                                  >
                                    <TwitterIcon size={32} round />
                                  </TwitterShareButton>
                                  {/* <a href="javascript:;">
                              <img src={"../../assets/images/articledetail/twitter-icon.svg"} alt="icon" />
                              Twitter
                            </a> */}
                                </div>
                              </div>
                                                    </div>
                                                    <h1 className="mt-4">
                                                        {o.post_title}
                                                    </h1>
                                                    <span className="post-by">- {o.display_name} (<Moment format="DD MMM YYYY" withTitle>
                                                        {o.post_date_gmt}
                                                    </Moment>)</span>
                                                </div>
                                                <div className="article-content video_deta_content mt-4">


                                                 <p>  {content} </p>
                                                </div>
                                                {/* <div className="share-item mt-4">
                                                    <p>Share this:</p>
                                                    <ul className="list-inline">
                                                        <li className="list-inline-item">
                                                            <a href="javascript:;">
                                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/fb-icon.svg"} alt="icon" />
                                                            </a>
                                                        </li>
                                                        <li className="list-inline-item">
                                                            <a href="javascript:;">
                                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/insta-icon.svg"} alt="icon" />
                                                            </a>
                                                        </li>
                                                        <li className="list-inline-item">
                                                            <a href="javascript:;">
                                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/twitter-icon.svg"} alt="icon" />
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div> */}
                                                {/* <div className="post-nav btn-group mt-3">
                                                    <Link to={`/videodetail/${o.prevArticle.post_name}`} className="btn">
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                                        {o.prevArticle.post_title}
                                                    </Link>
                                                    <Link to={`/videodetail/${o.nextArticle.post_name}`} className="btn">
                                                        {o.nextArticle.post_title}
                                                        <img src={process.env.PUBLIC_URL + "/assets/images/chevron-icon.svg"} alt="icon" />
                                                    </Link>
                                                </div> */}
                                                <hr className="my-5" />
                                                <div className="comment-wrap mb-5">
                                                    <h4>Comments</h4>
                                                    <form className="add-comment mt-3 mb-5 text-right">
                                                        <div className="alert" role="alert">
                                                        </div>
                                                        <textarea
                                                            className="form-control"
                                                            rows={5}
                                                            placeholder="Add Comment..."
                                                            value={this.props.comment_review}
                                                            onChange={e => this.props.updateCommentReview('comment_review', e.target.value)}
                                                        />
                                                        <button type="button" className="btn btn-orange" onClick={(e) => {
                                                            (localStorage.user_id) ? this.createComment(e) :
                                                                window.jQuery('#signup-modal').modal('show')
                                                        }}>
                                                            Comment
                      </button>
                                                    </form>
                                                    <div className="comment-sec">
                                                        {
                                                            this.props.videoCommentsList.length > 0 &&
                                                            this.props.videoCommentsList.map((c, b) => {
                                                                return <div className="comment mb-4" key={c.comment_ID} data-id={c.comment_ID}>
                                                                    <div className="avatar">
                                                                        <img
                                                                            className="img-fluid lazyload"
                                                                            data-src={(c.user_avatar) ? c.user_avatar : process.env.PUBLIC_URL + "/assets/images/avatar.png"}
                                                                            alt="avatar"
                                                                        />
                                                                    </div>
                                                                    <div className="comment-item">
                                                                        <span className="name">{c.comment_author}</span>
                                                                        <p>
                                                                            {c.comment_content}
                                                                        </p>
                                                                        <span className="date-time">
                                                                            <Moment fromNow>{c.comment_date}</Moment>
                                                                        </span><br />
                                                                        <a href="javascript:;" className="reply change-pass" onClick={e => {
                                                                            jQuery(e.target).closest('.comment-item').find('.loader-pro').removeClass('d-none')
                                                                            jQuery(e.target).closest('.comment-item').find('.loader-pro').addClass('d-block')
                                                                            this.props.updateCommentReview('comment_id', jQuery(e.target).closest('.comment').data('id'))
                                                                            this.props.getSubComments({ comment_id: jQuery(e.target).closest('.comment').data('id') })
                                                                        }}>
                                                                            Reply
                            </a>
                                                                        <div className="loader-pro d-none" style={{ marginLeft: '25%', marginRight: '67%', marginTop: '6%' }}>

                                                                            <img
                                                                                className="img-fluid lazyload"
                                                                                data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                                                                alt="Avatar"
                                                                            />
                                                                        </div>
                                                                        <div className="change-pass-encl mt-4 mb-0">
                                                                            {this.props.subCommentsList.length > 0 &&
                                                                                this.props.subCommentsList.map((s, t) => {
                                                                                    return <div className="child-comment mt-3">
                                                                                        <div className="avatar">
                                                                                            <img
                                                                                                className="img-fluid lazyload"
                                                                                                data-src={(s.user_avatar) ? s.user_avatar : process.env.PUBLIC_URL + "/assets/images/avatar.png"}
                                                                                                alt="avatar"
                                                                                            />
                                                                                        </div>
                                                                                        <div className="comment-item">
                                                                                            <span className="name">{s.comment_author}</span>
                                                                                            <p>
                                                                                                {s.comment_content}
                                                                                            </p>
                                                                                            <span className="date-time">
                                                                                                <Moment fromNow>{s.comment_date}</Moment>
                                                                                            </span><br />
                                                                                        </div>
                                                                                    </div>
                                                                                })
                                                                            }

                                                                            <div className="child-comment mt-3">
                                                                                <div className="comment-item">
                                                                                    <form className="reply-section mt-3 mb-5 text-right">
                                                                                        <div className="alert text-left" role="alert">
                                                                                        </div>
                                                                                        <textarea
                                                                                            className="form-control reply-comment"
                                                                                            rows={5}
                                                                                            placeholder="Add Comment..."
                                                                                            value={this.props.reply_comment_review}
                                                                                            onChange={e => this.props.updateCommentReview('reply_comment_review', e.target.value)}
                                                                                        />
                                                                                        <button className="btn btn-trans cancel-pass" type="button" style={{ marginTop: '10px' }}>Cancel</button>
                                                                                        <button type="button" className="btn btn-orange"
                                                                                            onClick={(e) => {
                                                                                                (localStorage.user_id) ? this.replyComment(e) :
                                                                                                    window.jQuery('#signup-modal').modal('show')

                                                                                            }}>
                                                                                            Comment
                    </button>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                }):
                                (
                                    <>
                                        <div
                                          className="loader-pro d-none"
                                          style={{
                                            marginLeft: "20%",
                                            marginRight: "50%",
                                            marginTop: "6%",
                                          }}
                                        >
                                        <img
                                            className="img-fluid lazyload"
                                            data-src={
                                              process.env.PUBLIC_URL +
                                              "/assets/images/loading.gif"
                                            }
                                            alt="Avatar"
                                          />
                                          </div>
                                        </>
                                                        
                                    
                                )
                            }

                            <div className="col-md-4 d-none d-sm-block">
                                <div className="mb-5">
                                    <div className="col p-0">
                                        <h3 className="title">Latest Videos</h3>
                                    </div>
                                    <div className="whats-happen high-light col p-0">
                                    {
                                        this.props.latestVideos.length > 0 &&
                                        <div className="wt-item-encl mscroll-y-inside">
                                                {
                                                this.props.latestVideos.map((l, v) => {
                                                    return <Link to={`/videodetail/${l.post_name}`} className="wt-item">
                                                        <div className="cal">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={l.s3_thumbnail_image_260 !== null 
                                                                    ? l.s3_thumbnail_image_260 
                                                                    : l.thumbnail_image !== null
                                                                    ? l.thumbnail_image
                                                                    : l.custom_feature_image_url}
                                                                alt="img"
                                                            />
                                                            <span className="play-icon">
                                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"} alt="icon" />
                                                            </span>
                                                        </div>
                                                        <div className="cal-cont">
                                                            <p>
                                                                {l.post_title}
                                                            </p>
                                                        </div>
                                                    </Link>
                                                })
                                            }
                                        </div>
                                    }  
                                    </div>
                                </div>
                                {/* <div className="text-center">
                                    <img className="img-fluid lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/ad-ver.jpg"} alt="ad" />
                                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </section >







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        articleVideoDetail: state.VideoDetail.articleVideoDetail,
        videoCommentsList: state.VideoDetail.videoCommentsList,
        latestVideos: state.VideoDetail.latestVideos,
        subCommentsList: state.VideoDetail.subCommentsList,
        commentStatus: state.VideoDetail.commentStatus,
        replyCommentStatus: state.VideoDetail.replyCommentStatus,
        comment_review: state.VideoDetail.comment_review,
        reply_comment_review: state.VideoDetail.reply_comment_review,
        rating: state.VideoDetail.rating,
        comment_id: state.VideoDetail.comment_id,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getVideoArticleDetail: (data) => dispatch(actions.getVideoArticleDetail(data)),
        getSubComments: (data) => dispatch(actions.getSubCommentsList(data)),
        createCommentForArticle: (data) => dispatch(actions.createComment(data)),
        replyCommentForArticle: (data) => dispatch(actions.replyComment(data)),
        updateCommentReview: (f, e) => dispatch(actions.changeCommentReview(f, e)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    }
};

const articleDetails = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Article_Details);

export default articleDetails;



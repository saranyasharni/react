/* eslint-disable */
import React, { Component, Fragment } from 'react';
import jQuery from 'jquery';
import { BrowserRouter as Router, Switch, Route, Link, withRouter } from "react-router-dom";
import Header from '../containers/common/Header';
import Footer from '../containers/common/Footer';
import GoogleLogin from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import Moment from 'react-moment';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class VaucherSubscribe extends Component {
    componentWillMount() {
        this.props.updatePageNo({ flag: 1 });
        this.props.getBannerContestList({ page_no: 0, limit: 4 })
        this.props.getContestList({ page_no: 0, limit: 4 })
    }
    componentDidMount() {
        var THIS = this;
        jQuery(document).ready(function () {
            if (THIS.props.contestList.length > 0) {
                window.jQuery('.banner .owl-carousel').owlCarousel({
                    items: 1,
                    loop: true,
                    autoplay:true,
                    autoplayTimeout:3000,
                    autoplayHoverPause:true,
                    dots: true
                });
            }
        });

    }
    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {

            if (THIS.props.contestList.length > 0) {
                window.jQuery('.banner .owl-carousel').owlCarousel({
                    items: 1,
                    loop: true,
                    autoplay:true,
                    autoplayTimeout:3000,
                    autoplayHoverPause:true,
                    dots: true
                });
            }
            if (THIS.props.archiveStatus === 1) {
                
                jQuery('.alert').html('<strong>No more contests to show.</strong>');

                jQuery('.alert').removeClass('alert-success').addClass('alert-danger')
                
                THIS.props.updateArchiveStatus(0);
                setTimeout(function () {
                    jQuery(".alert").removeClass('alert-danger');
                }, 2000);
            }
        });

    }
    showMore(e) {
        e.preventDefault();
        this.props.updatePageNo({ flag: 0 });
        this.props.getNewContestList({ page_no: this.props.contestPageNo + 1, limit: 4 });
    }

    render() {
        const LinkStyle = {
            textDecoration: 'none',
            color: 'white'
        };
        return (

            <div className="container-fluid">
                <div className="row">
                    <Header />
                    <Fragment>
                        <section className="category-sec container-fluid">
                            <div className="row parent-cat py-3">
                                <div className="container">
                                    <h4 style= {{marginBottom:'2px'}}>
                                    
                                    Contests and Giveaways
                                    </h4>
                                </div>
                            </div>
                        </section>
                        {
                            /* Hero Banner Starts here */
                        }
                        <section className="container-fluid hero-banner contest mb-3 mb-sm-4">
                            <div className="row banner">
                            <div
                            className={
                                this.props.bannerContestList.contestStatus &&
                                this.props.bannerContestList.contestStatus === 1
                                ? "col-md-12 col-12 d-block"
                                : "col-md-12 col-12 d-none"
                            }
                            >
                            <h3 className="noarticle">No Contests</h3>
                            </div>
                                {
                                
                                    this.props.bannerContestList.length > 0 &&

                                    (<div className="owl-carousel">
                                        {this.props.bannerContestList.map((o, k) => {
                                            return <div className="slide-item"
                                            style={{ backgroundImage: `url(${(o.custom_featured_image_url === "" || o.custom_featured_image_url === null || o.custom_featured_image_url === undefined) ? o.giveaway_thumbnail_image_url : o.custom_featured_image_url})`, backgroundSize: 'cover', backgroundPositionX: '50%', backgroundPositionY: 'center', backgroundRepeat: 'no-repeat', height: '500px', width: '100%' }}
                                             key={o.post_id} data-slug={o.post_id}
                                             data-id = {o.post_title}
                                             >
                                                
                                                {/* <img className="lazyload" data-src={o.custom_featured_image_url? o.custom_featured_image_url: process.env.PUBLIC_URL+"/assets/images/contest-slider-1.jpg"} alt="icon" /> */}
                                                <div className="carousel-cont">
                                                    <div className="container">
                                                        <h4 className="text-truncate">{o.post_title}</h4>
                                                        <p className="text-truncate">
                                                            {ReactHtmlParser(o.post_content.slice(0, 150))}
                                                        </p>
                                                        {
                                                            (o.post_type !== 'contest') ?
                                                                <button type="button" className="btn btn-orange" onClick={(e) => {
                                                                localStorage.setItem('cotest_slug', jQuery(e.target).closest('div.slide-item').data("slug"))
                                                                localStorage.setItem('cotests_name', jQuery(e.target).closest('div.slide-item').data("id"))
                                                                {
                                                                (localStorage.user_id) ? 
                                                                this.props.history.push(`/contestgiveaway/${o.post_id}`) : window.jQuery('#signup-modal').modal('show')
                                                                }
                                                                }}>Find Out More</button> :
                                                                <button type="button" className="btn btn-orange" onClick={(e) => {
                                                                    localStorage.setItem('cotest_slug', jQuery(e.target).closest('div.slide-item').data("slug"))
                                                                    localStorage.setItem('cotests_name', jQuery(e.target).closest('div.slide-item').data("id"))
                                                                    {
                                                                        (localStorage.user_id) ? this.props.history.push(`/contestsubmit/${o.post_id}`) : window.jQuery('#signup-modal').modal('show')
                                                                    }
                                                                }}>Find Out More</button>
                                                        }
                                                        {/* <button className="btn btn-orange">Submit Entry</button> */}
                                                    </div>
                                                </div>
                                            </div>
                                        })}</div>)}
                            </div>
                        </section>
                        {
                            /* Hero Banner Ends here */
                        }

                        <section className="container-fluid mt-4 mb-5 contest-list">
                            <div className="row">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-md-8">
                                            <div className="row">
                                                <div className="col-12">
                                                    {
                                                        // console.log(this.props.contestList, 'this.props.contestList'),
                                                        this.props.contestList.length > 0 &&
                                                        this.props.contestList.map((r, m) => {
                                                            return <div className="hor-article-item event-item" key={m} 
                                                            data-slug={r.post_id}
                                                            data-id={r.post_title}
                                                            >
                                                                <a href="javascript:;" className="art-img">
                                                                    <img className="lazyload" data-src={(r.custom_featured_image_url === undefined || r.custom_featured_image_url === null || r.custom_featured_image_url === "") ? r.giveaway_thumbnail_image_url : r.custom_featured_image_url} alt="img" />
                                                                </a>
                                                                <div className="art-cont">
                                                                    <a href="javascript:;" className="art-title">
                                                                        <p className="text-truncate">{r.post_title}</p>
                                                                        <span className="">
                                                                            {ReactHtmlParser(r.post_content.slice(0,400))}
                                                                        </span>
                                                                    </a>
                                                                    {
                                                                        (r.post_type !== 'contest') ?
                                                                            <button type="button" className="btn btn-orange" onClick={(e) => {
                                                                                localStorage.setItem('cotest_slug', jQuery(e.target).closest('div.hor-article-item').data("slug"))
                                                                                localStorage.setItem('cotests_name', jQuery(e.target).closest('div.hor-article-item').data("id"))
                                                                                {
                                                                            (localStorage.user_id) ? this.props.history.push(`/contestgiveaway/${r.post_id}`) : window.jQuery('#signup-modal').modal('show')
                                                                                }
                                                                            }}>Find out more</button> :
                                                                            <button type="button" className="btn btn-orange" onClick={(e) => {
                                                                                localStorage.setItem('cotest_slug', jQuery(e.target).closest('div.hor-article-item').data("slug"))
                                                                                localStorage.setItem('cotests_name', jQuery(e.target).closest('div.hor-article-item').data("id"))
                                                                                {
                                                                                (localStorage.user_id) ? this.props.history.push(`/contestsubmit/${r.post_id}`) : window.jQuery('#signup-modal').modal('show')
                                                                                }
                                                                            }}>Find out more</button>
                                                                    }
                                                                </div>
                                                            </div>
                                                        })}
                                                    {
                                                    this.props.contestList.length > 0 &&
                                                    <div 
                                                    className={
                                                    this.props.contestList.length > 0 ? 'col-12 text-center mt-4 d-block'
                                                    : 'col-12 text-center mt-4 d-none'
                                                    }>
                                                    <div className="alert" role="alert">
                                                    </div>
                                                    <button type="button" className="btn btn-orange" onClick={(e) => { this.showMore(e) }}>Show More</button>
                                                    </div>
                                                    }
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            {/* <div className="text-center d-none d-sm-none d-md-block">
                                                <img className="img-fluid" src={process.env.PUBLIC_URL + "assets/images/ad-ver.jpg"} alt="ad" />
                                            </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </Fragment>
                    <Footer />
                </div>

            </div >


        );
    }

}

export default VaucherSubscribe;

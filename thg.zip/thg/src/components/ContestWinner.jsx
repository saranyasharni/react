import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import $, { valHooks } from 'jquery';
import Footer from '../containers/common/Footer';
import Header from '../containers/common/Header';
import config from '../actions/common/Api_Links';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';

function ContestWinner() {
    let day = 1;
    const [item, setItem] = useState([]);
    useEffect(() => {
        $(document).ready(function(){
            window.$(".mscroll-x").mCustomScrollbar({
                axis:"x",
                scrollEasing:"linear",
                scrollInertia: 300
            });
    
            window.$(".mscroll-y-inside").mCustomScrollbar({
                axis:"y",
                scrollEasing:"linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });
    
            window.$('.winner-slider .owl-carousel').owlCarousel({
                items:1,
                loop:true,
                dots:false,
                nav:true
            });
    
        });
    
    });
    useEffect (() => {
        let formData = new URLSearchParams();    //formdata object
        formData.append('post_id', localStorage.getItem('cotest_slug'));
    
        fetch(config.get_contest_winners, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
      
        .then(res => res.json())
        .then(data => {
            //console.log(data, 'NOWTESTI')
            setItem([]);
            if (data.status === 1) {
                setItem(data.result);
            } else {
                setItem([]);
            }
            
        });

    }, [])
    return (
        <>
        <Header />
        <>
        <section className="category-sec container-fluid bdr-btm">
            <div className="row parent-cat py-3">
            <div className="container">
                <h4>
                <a href="javascript:;" className="back">
                <Link to = {`/contestsubmit/${localStorage.cotest_slug ? localStorage.getItem('cotest_slug'): ''}`}>
                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                </Link>
                </a>
                Contest Winners
                </h4>
            </div>
            </div>
        </section>
        {/* Category Section Ends here */}
        {/* Submission Section Starts here */}
        <section className="container-fluid mt-5 mb-5 min-h-vp winner-wrap">
            <div className="row">
            <div className="container">
            {
                item.length > 0 ? (
                <>     
                <h2>
                <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/award-icon.svg"} alt="icon" />
                Congratulations!
                </h2>
                </>
                ): (
                <>
                <h2>
                
                {/* No Winners yet. */}
                </h2>
                        </>
                    )
                }
                
                <div className="winner-slider">
                {
                     item && item.length > 0 && 
                    <div className="owl-carousel">
                    
                    {
                    item.length > 0 && item.map((o,k) => {
                    return (
                    <>
                    <div className="slide-item">
                    <div className="img-wrap"
                    style={{ backgroundImage: `url(${(o.image_url === "" || o.image_url === null || o.image_url === undefined) ? "" : o.image_url})`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat', height: '400px'}}
                    >
                    {/* <img className="img-fluid" src=
                    {
                        o.image_url ? o.image_url :process.env.PUBLIC_URL + "/assets/images/winner-photo.jpg"  
                    } 
                        alt="icon" /> */}
                    </div>
                    <div className="win-cont">
                    {/* <span className="day">Day {day++}</span>
                    { ' ' } */}
                    <h5><b>Winner of</b> <span className="won">{o.contest_name}</span>
                    </h5>
                    <br/>
                    <span className="name">{o.first_name}{' '}{o.last_name}</span>
                     <br/>   
                    <p className="">
                        {(o.description ? o.description : '')}
                    </p>
                        
                    </div>
                    </div>
                    
                    </>
                    )
                    })    
                    } 
                    
    {/* <div className="slide-item">
    <div className="img-wrap">
    <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/winner-photo.jpg"} alt="icon" />
    </div>
    <div className="win-cont">
        <span className="day">Day 01</span>
        <h5>Rimowa Salsa Air Ultralight Cabin Multiwheel</h5>
        <span className="name">Jane Sanders</span>
        <p>
        Sed do eiusmod tempor incididunt ut labore et dolore magna
        aliqua. Ut enim ad minim veniam, quis nostrud exercitation
        ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
        aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia
        deserunt mollit anim id est laborum.
        </p>
        <p>
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
        accusantium doloremque laudantium, totam rem aperiam, eaque
        ipsa quae ab illo inventore veritatis et quasi architecto
        beatae vitae dicta sunt explicabo.{" "}
        </p>
    </div>
    </div>
    <div className="slide-item">
    <div className="img-wrap">
    <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/winner-photo.jpg"} alt="icon" />
    </div>
    <div className="win-cont">
        <span className="day">Day 01</span>
        <h5>Rimowa Salsa Air Ultralight Cabin Multiwheel</h5>
        <span className="name">Jane Sanders</span>
        <p>
        Sed do eiusmod tempor incididunt ut labore et dolore magna
        aliqua. Ut enim ad minim veniam, quis nostrud exercitation
        ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
        aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia
        deserunt mollit anim id est laborum.
        </p>
        <p>
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
        accusantium doloremque laudantium, totam rem aperiam, eaque
        ipsa quae ab illo inventore veritatis et quasi architecto
        beatae vitae dicta sunt explicabo.{" "}
        </p>
    </div>
    </div>
    <div className="slide-item">
    <div className="img-wrap">
    <img className="img-fluid" src={process.env.PUBLIC_URL + "/assets/images/winner-photo.jpg"} alt="icon" />
    </div>
    <div className="win-cont">
        <span className="day">Day 01</span>
        <h5>Rimowa Salsa Air Ultralight Cabin Multiwheel</h5>
        <span className="name">Jane Sanders</span>
        <p>
        Sed do eiusmod tempor incididunt ut labore et dolore magna
        aliqua. Ut enim ad minim veniam, quis nostrud exercitation
        ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
        aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia
        deserunt mollit anim id est laborum.
        </p>
        <p>
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
        accusantium doloremque laudantium, totam rem aperiam, eaque
        ipsa quae ab illo inventore veritatis et quasi architecto
        beatae vitae dicta sunt explicabo.{" "}
        </p>
    </div>
    </div> */}
                </div>
                }
                
                </div>
            </div>
            </div>
        </section>
        {/* Giveaway Section Ends here */}
        </>
        <Footer />
        </>
    );
}

export default ContestWinner;

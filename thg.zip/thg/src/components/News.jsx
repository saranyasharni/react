/** @format */

import React, { Component, Fragment } from "react";
import AdSense from "react-adsense";
import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";

// import scriptFiles from './script';

import jQuery from "jquery";

import NewsBanner from "./NewsSection/News_Banner";
import NewsTrending from "./NewsSection/News_Trending";
import NewsLatestArticles from "./NewsSection/News_Latest_Articles";
import NewsRecommendedArticles from "./NewsSection/News_Recommended_Articles";
import NewsMixedArticles from "./NewsSection/News_Mixed_Articles";
import NewsFeaturedArticles from "./NewsSection/News_Featured_Articles";
import NewsPriceSection from "./NewsSection/News_Price_Section";
import NewsPopularArticles from "./NewsSection/News_Popular_Articles";
import NewsArticles from "./NewsSection/NewsArticles";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";


export default class News extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    var search = window.location.pathname.split("/")[2];
    var THIS = this;
    jQuery(document).ready(function () {
      window.$(`.${search}-nav `).addClass("active");
      // if (THIS.props.newsFeatureArticlesList.length > 0 && THIS.props.newsLatestArticlesList.length > 0 && THIS.props.newsPopularArticlesList.length > 0) {
      //     window.$(".snip-caurosel").owlCarousel({
      //         items: 4,
      //         loop: false,
      //         dots: false,
      //         margin: 15,
      //         nav: true,
      //         responsive: {
      //             0: {
      //                 items: 1,
      //             },
      //             768: {
      //                 items: 4,
      //             }
      //         }
      //     });
      // }
    });
  }

  componentDidUpdate() {
    var search = window.location.pathname.split("/")[2];
    var THIS = this;
    jQuery(document).ready(function () {
      window.$(`.${search}-nav `).addClass("active");
      // if (THIS.props.newsFeatureArticlesList.length > 0 && THIS.props.newsLatestArticlesList.length > 0 && THIS.props.newsPopularArticlesList.length > 0) {
      //     window.$(".snip-caurosel").owlCarousel({
      //         items: 4,
      //         loop: false,
      //         dots: false,
      //         margin: 15,
      //         nav: true,
      //         responsive: {
      //             0: {
      //                 items: 1,
      //             },
      //             768: {
      //                 items: 4,
      //             }
      //         }
      //     });
      // }
    });
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />

          <Fragment>
            {/* Flash News Starts here */ }
            <NewsBanner />
            {/* Flash News Ends here */ }

            {/* Hero Section Starts here */ }
            <NewsTrending />
            {/* Hero Section Ends here */ }
            {/* <div className="container">
              <AdSense.Google
                client="ca-pub-9111417808865977"
                slot="1638754887"
                style={{ width: 1100, height: 140, float: "left" }}
                format=""
              />
            </div> */}
            {/* Latest Articles Starts here */ }
            <NewsLatestArticles />
            {/* Latest Articles Ends here */ }

            {/* Recommended edArticles Starts here */ }
            <NewsRecommendedArticles />
            {/* Recommed Articles Ends here */ }

            {/* Featured Articles Starts here */ }
            <NewsFeaturedArticles />
            {/* Featured Articles Ends here */ }

            {/* Reel Starts here */ }
            {/* <HomeReel /> */ }
            {/* Reel Ends here */ }

            <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              {/* <UserAgent tablet mobile>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="1849140896"
                    style={ { width: 288, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent> */}
              <UserAgent windows mac>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="1849140896"
                    style={ { width: 1111, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider>

            {/* Popular Articles Starts here */ }
            <NewsPopularArticles />
            {/* Popular Articles Ends here */ }
            <NewsArticles />
            {/* Mixed Articles Starts here */ }
            {/* <NewsMixedArticles /> */ }
            {/* Mixed Articles Ends here */ }

            {/* THG TV Section Starts here */ }
            {/* <HomeTHGTv /> */ }
            {/* THG TV Section Ends here */ }

            {/* Price Section Starts here */ }
            {/* <NewsPriceSection /> */ }
            {/* Price Section Ends here */ }

            <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              <UserAgent tablet>
                  <div className="container">
              <AdSense.Google
                  client="ca-pub-9111417808865977"
                  slot="9857840469"
                  style={{ width: 710, height: 140, float: "left" }}
                  format=""
              />
          </div>
              </UserAgent>
              <UserAgent mobile>
                <div className="container mt-5">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="7076859330"
                    style={ { width: 328, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
              <UserAgent windows mac>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="7076859330"
                    style={ { width: 1111, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider>
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

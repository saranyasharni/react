import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/ThgTvDetail';
import * as headerActions from '../../actions/common/Header';
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";

class Web_Series extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        jQuery(document).ready(function () {
            window.$(".snip-caurosel").owlCarousel({
                items: 4,
                loop: false,
                dots: false,
                margin: 15,
                nav: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    768: {
                        items: 4
                    }
                }
            });

        })

    }

    componentDidUpdate() {
        jQuery(document).ready(function () {
            
            window.$(".snip-caurosel").owlCarousel({
                items: 4,
                loop: false,
                dots: false,
                margin: 15,
                nav: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    768: {
                        items: 4
                    }
                }
            });

        })

    }


    render() {

        return (

            <section className="container-fluid bg-gray mt-0 mt-sm-4">
                <div className="row">
                    <div className="container">
                        <h3 className="title">
                            Related Videos
            <a href="javascript:;">
                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                            </a>
                        </h3>

                        {
                            this.props.relatedVideos.length > 0 &&
                            (<div className="snip-caurosel owl-carousel">
                                {this.props.relatedVideos.map((o, k) => {
                                    return <div className="article-item video-snip" key={o.id} data-id={o.id}>
                                        <Link to={`/episodes/${o.base_name}/${o.id}`} className="art-img art-background"
                                            style={{ backgroundImage: `url(${o.img_url})` }}
                                            onClick={(e) => {
                                                localStorage.setItem('event_id', jQuery(e.target).closest('.article-item').data('id'))
                                            }}>
                                            <span className="video-label">
                                                <span>
                                                    <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/video-play-filled.svg"} alt="icon" />
                                                </span>
                                            </span>
                                        </Link>
                                        <div className="art-cont">
                                            <Link to={`/episodes/${o.base_name}/${o.id}`} className="art-title">
                                                {o.name}
                                            </Link>
                                            <span className="date-time">
                                                <Moment format="DD MMM YYYY">{o.date_publish}</Moment>
                                            </span>
                                        </div>
                                    </div>
                                })}</div>)

                        }

                    </div>
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        streamVideoDetail: state.ThgTvDetail.streamVideoDetail,
        videoCommentsList: state.ThgTvDetail.videoCommentsList,
        relatedVideos: state.ThgTvDetail.relatedVideos,
        bucketItem: state.Header.bucketItem,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getStreamVideoArticleDetail: (data) => dispatch(actions.streamAuthorization(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    }
};

const webSeries = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Web_Series);

export default webSeries;



/** @format */

import React, { Component, Fragment } from "react";

import jQuery from "jquery";

import { Link } from "react-router-dom";

import Header from "../containers/common/Header";
import Footer from "../containers/common/Footer";
import ReactHtmlParser, {
  processNodes,
  convertNodeToElement,
  htmlparser2,
} from "react-html-parser";

import history from "../stores/history";

export default class AboutUs extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    //this.props.fetchPrivacyContents({ page_slug: "privacy-policy" });
		this.props.getAboutUsData('about-us')
		this.props.getCareer('career')
  }
  componentDidMount(){
    document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="row">
          <Header />
          {
          // console.log(this.props.aboutUs, "aboutUs")
          }
          <Fragment>
            {/* Main Wrapper Starts here */}

            {/* Coach Listing Starts here */}
            <section className="container-fluid mt-5">
              <div className="row">
                <div className="container">
                  <div className="row">
                    <div className="col-12 text-center mb-5">
                      {/* <img
                                                className="img-fluid"
                                                src={process.env.PUBLIC_URL + "/assets/images/ad-landscape.jpg"}
                                                alt="Ad"
                                            /> */}
                    </div>
                    <div className="col-md-12">
                      <h3 className="title">{ this.props.aboutUs[0] ? 
                      this.props.aboutUs[0].post_title : ''}</h3>
                      <div className="row">
                        <div className="col-md-8 fp-content">
                          <p>
                          {/* { 
                          ReactHtmlParser(
                            this.props.aboutUs[0] ? this.props.aboutUs[0].post_content : ''
                          )
                          } */}
                          {
                            this.props.aboutUs.length > 0 &&
                            this.props.aboutUs.map((o, k) => {
                                var content = o.post_content;
                                // content = content.replace(/&nbsp;/g, '<p></p>');
                                content = content.replace(/\r\n/g,'<p></p>');
                                content = content.replace('                           ','<p></p>');

                                return <p>
                                  {ReactHtmlParser(content)}

                                </p>
                            })
                          }
                          </p>
                          {/* <p>
                            TheHomeGround keeps communities connected and
                            inspired.
                          </p>
                          <p>
                            Our journalists provide insights and viewpoints from
                            a local perspective, inspire community engagement,
                            and provide clarity as well as vision on everything
                            that matters.
                          </p>
                          <p>
                            Our vision is news explained, news investigated. We
                            aim to always delve deeper to understand.
                          </p>
                          <p>
                            Our mission is to overcome individual and
                            geographical boundaries and give people access to
                            news, insights and local happenings. We empower
                            people across communities to share their stories and
                            unique perspectives.
                          </p>
                          <p>
                            <Link to="/how-we-make-THG">
                              <strong>How we make TheHomeGround</strong>
                            </Link>
                          </p>
                          <p>
                            <Link to="/reach-us">
                              <b>Reach Us</b>
                            </Link>
                          </p>
                          <p>
                            <Link to="/contribute-with-us">
                              <strong>Contribute to TheHomeGround</strong>
                            </Link>
                          </p>
                          <p>&nbsp;</p>
                          <p>&nbsp;</p>
                          <p>&nbsp;</p>
                          <p>&nbsp;</p> */}

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            {/* Coach Listing Ends here */}
          </Fragment>

          <Footer />
        </div>
      </div>
    );
  }
}

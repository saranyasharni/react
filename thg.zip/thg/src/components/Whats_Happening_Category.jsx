import React, { Component, Fragment } from 'react'
import AdSense from 'react-adsense';
import jQuery from 'jquery'
import { withStyles } from '@material-ui/styles';
import {Typography,Backdrop,CircularProgress,Snackbar} from '@material-ui/core';
import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'
import ReactGA from "react-ga";
import { PageView, initGA, Event } from './../tracking';

import HeroBanner from './WhatsHappeningCategorySection/Hero_Banner'
import WhatsHappeningDetail from './WhatsHappeningCategorySection/Whats_Happening_Detail'
import FeaturedEvents from './WhatsHappeningCategorySection/Featured_Events'
const useStyles = theme => ({
    backdrop: {
        //zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    },
});

class Whats_Happening_Category extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        initGA('UA-173387540-1');
        let search = (window.location.pathname).split('/')[2];
        // console.log(search, 'search')
        ReactGA.event({
            category: 'Event Detail',
            action: 'Event View',
            label: search.replace(/-/g, ' ')
        });
        this.props.getWhatsHappenArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, slug: 'whats_happening', article_id: localStorage.getItem('article_id'), cat_slug:search })
        this.props.getCategoryFeaturedEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: 'featured_event' })
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.location !== this.props.location) {
            let search = (nextProps.location.pathname).split('/')[2];
            ReactGA.event({
                category: 'Event Detail',
                action: 'Event View',
                label: search.replace(/-/g, ' ')
            });
            this.props.getWhatsHappenArticleDetail({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, slug: 'whats_happening', article_id: localStorage.getItem('article_id'), cat_slug:search })
        }
    }

    render() {
        const {classes} = this.props;
        return (
            
            <>
         
                <div className="container-fluid">
                <div className="row">
                   
                    <Header />
                    {

                        this.props.loading 
                        ?(
                            <>
                            <div className="loader-pro d-block" style={{
                                  marginLeft: '48%', 
                                  marginRight: '45%' ,
                                  marginTop:'10%',
                                  marginBottom:'20%'
                                 }} >

                            <img
                                className="img-fluid lazyload"
                                data-src={process.env.PUBLIC_URL + "/assets/images/loading.gif"}
                                alt="Avatar"
                            />
                        </div>
                            </>
                        ) : (
                            <>
                            <Fragment>
                            {/* Hero Banner Starts here */}
                            
                            <HeroBanner />
                            
                            
                            {/* Hero Banner Ends here */}
                            {/* <AdSense.Google
                                client='ca-pub-9111417808865977'
                                slot='1638754887'
                                style={{ display: 'block', width: 720, margin: "auto" }}
                                format='auto'
                                responsive='true'
                                layout="display"
                                layoutKey='-gw-1+2a-9x+5c'
                                />  */}
                            {/* Whats Happen Details Starts here */}
                            <WhatsHappeningDetail />
                            {/* Whats Happen Details Ends here */}

                            {/* Featured Events Starts here */}
                            {
                                this.props.featuredEvents.length > 0 &&
                                <FeaturedEvents />
                            }
                            
                            {/* Featured Events Ends here */}
                           
                        <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={{ width: 1100, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                            </Fragment>

                            </>
                        )
    
                    }
                    
                    <Footer />
                </div>
            </div>
            </>
        )

    }
}
export default withStyles(useStyles) (Whats_Happening_Category);
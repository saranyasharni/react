import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import { connect } from 'react-redux'
import * as actions from '../../actions/Sports';
import jQuery from 'jquery';
import Moment from 'react-moment';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class Latest_Articles extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
    }

    render() {
        const htmlDecode = (input) => {
            var e = document.createElement('div');
            e.innerHTML = input;
            return e.childNodes[0].nodeValue;
        } 
        return (

            <section className="thg-tv four-grid container-fluid">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 col-12">
                                <h3 className="title">Latest Articles</h3>
                            </div>
                            <div className={this.props.latestArticlesList.length > 0 ? 'col-md-12 col-12 d-none' : 'col-md-12 col-12 d-block'}>
                                <h3 className="noarticle">No Articles</h3>
                            </div>
                            {
                                this.props.latestArticlesList.length > 0 &&
                                this.props.latestArticlesList.map((o, k) => {
                                    if (k === 0) {
                                        let decoded_subCategory = htmlDecode(o.cat_name)
                                        return <div className="col-md-6 col-12" key={o.ID}>
                                            <Link to={`/${o.post_name}`} className="tv-wrap">
                                                <img
                                                    className="tv-thumb img-fluid lazyload"
                                                    data-src={(o.custom_feature_image_url === undefined || o.custom_feature_image_url === null || o.custom_feature_image_url === "") ? o.thumbnail_image: o.custom_feature_image_url}
                                                    alt="icon"
                                                />
                                                <span className="art-cont">
                                                    <span className="tag">{(decoded_subCategory).split(',')[0]}</span>
                                                    <p>
                                                        {o.post_title}
                                                    </p>
                                                    <span className="date-time">
                                                        <Moment format='DD MMM YYYY'>{o.post_date_gmt}</Moment>
                                                    </span>
                                                </span>
                                            </Link>
                                        </div>
                                    } else if (k === 1) {
                                        return <div className="col-md-6 col-12">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="row">
                                                        {this.props.latestArticlesList.map((m, l) => {
                                                            if (l === 1 || l === 2) {
                                                                return <div className="col-6" key={m.ID}>
                                                                    <Link to={`/${m.post_name}`} className="tv-thumb-sm">
                                                                        <img
                                                                            className="thumb lazyload"
                                                                            data-src={(m.thumbnail_image === undefined || m.thumbnail_image === null || m.thumbnail_image === "") ? m.custom_feature_image_url : m.thumbnail_image}
                                                                            alt="img"
                                                                        />
                                                                        <span className="art-cont">
                                                                            <p>
                                                                                {m.post_title}
                                                                            </p>
                                                                            <span className="date-time">
                                                                                <Moment format='DD MMM YYYY'>{m.post_date_gmt}</Moment>
                                                                            </span>
                                                                        </span>
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                    <div className="row">
                                                        {this.props.latestArticlesList.map((n, p) => {
                                                            if (p === 3 || p === 4) {
                                                                return <div className="col-6" key={n.ID}>
                                                                    <Link to={`/${n.post_name}`} className="tv-thumb-sm">
                                                                        <img
                                                                            className="thumb lazyload"
                                                                            data-src={(n.thumbnail_image === undefined || n.thumbnail_image === null || n.thumbnail_image === "") ? n.custom_feature_image_url : n.thumbnail_image}
                                                                            alt="img"
                                                                        />
                                                                        <span className="art-cont">
                                                                            <p>
                                                                                {n.post_title}
                                                                            </p>
                                                                            <span className="date-time">
                                                                                <Moment format='DD MMM YYYY'>{n.post_date_gmt}</Moment>
                                                                            </span>
                                                                        </span>
                                                                    </Link>
                                                                </div>
                                                            }

                                                        })}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    }

                                })
                            }


                        </div>
                    </div>
                </div>
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        latestArticlesList: state.Sports.latestArticlesList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getCategoryList: (data) => dispatch(actions.getCategoryList(data)),
    }
};

const latestArticles = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Latest_Articles);

export default latestArticles;



import React, { Component, Fragment } from 'react'
import { Link } from "react-router-dom";
import { connect } from 'react-redux'
import * as actions from '../../actions/Sports';
import * as headerActions from '../../actions/common/Header';
import jQuery from 'jquery';
import Moment from 'react-moment';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";
import AdSense from 'react-adsense';

class Popular_Articles extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        console.log(window.location.pathname, 'window.location.pathname')
        Moment.globalFilter = (d) => {
            if (d === 'a day ago') {
                return '1 day ago';
            } else if (d === 'a month ago') {
                return '1 month ago';
            } else if (d === 'a year ago') {
                return '1 year ago';
            } else {
                return d;
            }
        };
    }

    bucketList(e) {
        this.props.changeBucketItem('article_id', jQuery(e.target).closest('.favorite').attr('data-id'))
        var bucketId = jQuery(e.target).closest('.favorite').attr('data-bucket-id')
        this.props.changeBucketItem('bucket_id', (bucketId) ? bucketId : '')
        // var url = jQuery(e.target).closest(".hor-article-item").find('.art-background').css('background-image').replace(/(url\(|\)|")/g, '');
        var url = jQuery(e.target).closest(".hor-article-item").find('.art-background img').attr('src')
        jQuery('#bucket-list').find('.article-item').find('.art-img img').attr('src', url)
        jQuery('#bucket-list').find('.article-item').find('.art-cont span.tag').text(jQuery(e.target).closest(".hor-article-item").find('.art-cont span.tag').text())
        jQuery('#bucket-list').find('.article-item').find('.art-cont p').text(jQuery(e.target).closest(".hor-article-item").find('.art-cont .art-title').text())
        localStorage.setItem('save_item', jQuery(e.target).closest(".hor-article-item").find('.art-cont .art-title').text())
    }

    render() {
        const htmlDecode = (input) => {
            var e = document.createElement('div');
            e.innerHTML = input;
            return e.childNodes[0].nodeValue;
        } 
        return (

            <section className="container-fluid recommended mt-4">
                <div className="row">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-8">
                                <div className="row">
                                    <div className="col-12">
                                        <h3 className="title">
                                            Popular Articles
                                        {/* <a href="javascript:;">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/left-arrow.svg"} alt="icon" />
                                            </a> */}
                                        </h3>
                                    </div>
                                    <div className={this.props.popularArticlesList.length > 0 ? 'col-12 d-none' : 'col-12 d-block'}>
                                        <h3 className="noarticle">No Articles</h3>
                                    </div>
                                    <div className="col-12">
                                        {
                                            this.props.popularArticlesList.length > 0 &&
                                            this.props.popularArticlesList.map((o, k) => {
                                                var cat_name = (o.cat_name).split(',');
                                                var cat_name_arr = [];
                                                cat_name.forEach(element => {
                                                    cat_name_arr.push(element);
                                                });
                                                let decoded_subCategory = htmlDecode(cat_name[0])
                                                var image = (o.bucket_list_status === 1) ? process.env.PUBLIC_URL + "/assets/images/heart-filled.svg" : process.env.PUBLIC_URL + "/assets/images/heart.svg"
                                                return <div className="hor-article-item" key={o.ID}>
                                                    <Link to={`/${o.post_name}`} className="art-img art-background"
                                                        // style={{ backgroundImage: 
                                                        // `url(${(o.thumbnail_image === undefined || o.thumbnail_image === null || o.thumbnail_image === "") ? o.custom_feature_image_url : o.thumbnail_image})` }}
                                                    >
                                                    <img 
                                                        src={(o.thumbnail_image === undefined || o.thumbnail_image === null || o.thumbnail_image === "") ? o.custom_feature_image_url : o.thumbnail_image} 
                                                        alt="img" 
                                                    />
                                                        {(o.video_file === null || o.video_file === undefined) ? '' : <span className="video-label"><img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/play-arrow.svg"} alt="icon" />12:32</span>}
                                                    </Link>
                                                    <div className="art-cont">
                                                        <span className="tag">{decoded_subCategory}</span>
                                                        <a href="javascript:;" className="favorite" data-id={o.ID} data-bucket-id={o.bucket_id} data-toggle="modal" data-target={(localStorage.user_id) ? (o.bucket_list_status === 1) ? "#remove-article" : "#bucket-list" : "#signup-modal"}
                                                            onClick={(e) => {
                                                                this.bucketList(e)
                                                            }}>
                                                            <img
                                                                className="outline lazyload"
                                                                data-src={image}
                                                                alt="icon"
                                                                data-article-id={o.ID}
                                                            />
                                                            <img
                                                                className="filled lazyload"
                                                                data-src={process.env.PUBLIC_URL + "/assets/images/heart-filled.svg"}
                                                                alt="icon"
                                                            />
                                                        </a>
                                                        <Link to={`/${o.post_name}`} className="art-title popular_art_title">
                                                            <p>
                                                                {o.post_title}
                                                            </p>
                                                            <span className="text-truncate">
                                                                {o.post_content.replace(/<(.|\n)*?>/g, '')}
                                                            </span>
                                                        </Link>
                                                        <span className="date-time">
                                                            <Moment format='DD MMM YYYY' withTitle>{o.post_date_gmt}</Moment>
                                                        </span>
                                                    </div>
                                                </div>
                                            })
                                        }
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className={`mb-5 ${(window.location.pathname.split('/')[2]) === 'esports' ? 'd-block' : 'd-none'}`}>
                                    <UserAgentProvider ua={window.navigator.userAgent} >
                                        <UserAgent windows mac>
                                            <AdSense.Google
                                                client="ca-pub-9111417808865977"
                                                slot="2845449790"
                                                style={{ width: 160, float: "left" }}
                                                format=""
                                                // style={{ display: 'block', margin: "auto" }}
                                                // format='auto'
                                                // responsive='true'
                                                // layout="display"
                                                // layoutKey='-gw-1+2a-9x+5c'
                                            />
                                        </UserAgent>
                                    </UserAgentProvider>
                                 </div> 
                                {/* <div className={`mb-5 ${(window.location.pathname.split('/')[2]) === 'sports' ? 'd-block' : 'd-none'}`}>
                                    <div className="col p-0">
                                        <h3 className="title">Latest Scores</h3>
                                    </div>
                                    <iframe src="https://www.ligascore.com/widget/football" width="100%" height="400" frameborder="0"></iframe>
                                   
                                 </div>  */}
                                
                                <div className={`mb-4 ${(window.location.pathname.split('/')[2]) === 'sports' ? 'd-block' : 'd-none'}`}>
                                    <div className={`col p-0 ${this.props.highlightsList.length > 0 ? 'd-block' : 'd-none'}`}>
                                        <h3 className="title">Highlights</h3>
                                    </div>
                                    <div className={`whats-happen high-light col p-0 ${this.props.highlightsList.length > 0 ? 'd-block' : 'd-none'}`}>
                                        <div className="wt-item-encl h-auto">
                                            {
                                                this.props.highlightsList.length > 0 &&
                                                this.props.highlightsList.map((h, l) => {
                                                    return <Link to={`/${h.post_name}`} className="wt-item" key={h.ID}>
                                                        <div className="cal">
                                                            <img
                                                                className="img-fluid lazyload"
                                                                data-src={h.s3_thumbnail_image_260 !== null 
                                                                ? h.s3_thumbnail_image_260 
                                                                : h.thumbnail_image !== null
                                                                ? h.thumbnail_image
                                                                : h.custom_feature_image_url}
                                                                alt="img"
                                                            />
                                                        </div>
                                                        <div className="cal-cont">
                                                            <p>
                                                                {h.post_title}
                                                            </p>
                                                        </div>
                                                    </Link>
                                                })
                                            }
                                        </div>
                                        {/* <UserAgentProvider
                                ua={window.navigator.userAgent}
                              >
                                <UserAgent windows mac>
                                <AdSense.Google
                                    client="ca-pub-9111417808865977"
                                    slot="2845449790"
                                    style={{ width: 256, height: 1253, float: "left" }}
                                    format=""
                                />
                            
                        
                                </UserAgent>
                              </UserAgentProvider> */}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        popularArticlesList: state.Sports.popularArticlesList,
        bucketItem: state.Header.bucketItem,
        highlightsList: state.Sports.highlightsList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getPopularArticlesList: (data) => dispatch(actions.getPopularArticlesList(data)),
        changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
        getHighLightsArticlesList: (data) => dispatch(actions.getHighLightsArticles(data)),
    }
};

const popularArticles = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Popular_Articles);

export default popularArticles;



import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as 
actions from '../../actions/Sports';
import * as articleDetailActions from '../../actions/Article_Detail';
import jQuery from 'jquery';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
import "lazysizes/plugins/unveilhooks/ls.unveilhooks";


class Category extends Component {
    
    constructor(props) {
        super(props);
    }

    componentDidUpdate() {
        jQuery('.item').off('click').click(function () {
            localStorage.setItem('sub_cat', '')
            jQuery('.item').removeClass('active')
            jQuery(this).toggleClass('active')
        })

        jQuery('.cat-item').off('click').click(function () {
            jQuery('.cat-item').removeClass('active')
            jQuery(this).toggleClass('active')
        })
    }

    showRelatedArticles(e) {
        e.preventDefault();
        var search = window.location.pathname.split('/')[2]
        let location = ''
        if (jQuery('.loca_param').data('id')) {
            location = jQuery('.loca_param').data('id')
            
        }
        let filter_name = jQuery('.cat-item.active').data('name')
        let subslug = jQuery('.item.active').data('slug')
        let catslug = jQuery('.cat-item.active').data('id')
        let userid = (localStorage.user_id) ? localStorage.getItem('user_id') : 0;
        this.props.getCategoryList({ 
            user_id: userid, slug: subslug ? subslug : search, 
            filter_cat_id: catslug ? catslug : '', 
            page_no: 0, 
            limit: 9 ,
            location:location,
            filter_name: filter_name,
        });
        this.props.getFeaturedArticlesList({ 
            user_id: userid, slug: subslug ? subslug : search, page_no: 0, filter_cat_id: catslug ? catslug : '', 
            limit: 12,
            location:location,
            filter_name: filter_name,
        });
        this.props.getPopularArticlesList({ 
            user_id: userid, slug: subslug ? subslug : search, page_no: 0, 
            filter_cat_id: catslug ? catslug : '', 
            limit: 6,
            location:location,
            filter_name: filter_name,
        });
    }


    render() {

        return (

            <section className="category-sec container-fluid mb-5">
                {/* parent-cat Starts here */}
                <div className="row parent-cat py-4">
                    <div className="container">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item">
                                <a href="javascript:;" className="cat-item" 
                                data-name = 'local'
                                data-id="113" onClick={(e) => {
                                    this.showRelatedArticles(e)
                                }}>
                                    Local
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;" className="cat-item" 
                                data-id="114" 
                                data-name = 'international'
                                onClick={(e) => {
                                    this.showRelatedArticles(e)
                                }}>
                                    International
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="javascript:;" className="cat-item" data-id="115" onClick={(e) => {
                                    this.showRelatedArticles(e)
                                }}>
                                    UGC (User Generated Content)
                                    <span className="tick">
                                        <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                {/* parent-cat Ends here */}
                {/* child-cat Starts here */}
                {/* <div className="row child-cat py-3">
                    <div className="container mscroll-x">
                        <ul className="list-inline mb-0">
                            {this.props.subCategoryList.length > 0 &&
                                this.props.subCategoryList.map((o, k) => {
                                    return <li className="list-inline-item" key={o.child_id}>
                                        <a href="javascript:;" className={(localStorage.getItem('sub_cat') === o.sub_category) ? 'item active' : 'item'} data-sub={o.sub_category} data-slug={o.slug} onClick={(e) => {
                                            this.showRelatedArticles(e)
                                        }}>
                                            {o.sub_category}
                                            <span className="tick">
                                                <img className="lazyload" data-src={process.env.PUBLIC_URL + "/assets/images/tick-white.svg"} />
                                            </span>
                                        </a>
                                    </li>
                                })
                            }
                        </ul>
                    </div>
                </div> */}
                {/* child-cat Ends here */}
            </section>







        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        articlePageNo: state.Sports.articlePageNo,
        latestArticlesList: state.Sports.latestArticlesList,
        featuredArticlesList: state.Sports.featuredArticlesList,
        subCategoryList: state.ArticleDetail.subCategoryList,
        popularArticlesList: state.Sports.popularArticlesList,
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getCategoryList: (data) => dispatch(actions.getCategoryList(data)),
        getFeaturedArticlesList: (data) => dispatch(actions.getFeaturedArticlesList(data)),
        updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
        getSubCategoryList: (data) => dispatch(articleDetailActions.getSportsSubCategoryList(data)),
        getPopularArticlesList: (data) => dispatch(actions.getPopularArticlesList(data)),
    }
};

const category = connect(
    mapStateToProps,
    mapDispatchToProps,
)(Category);

export default category;


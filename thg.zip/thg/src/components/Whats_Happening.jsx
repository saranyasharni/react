import React, { Component, Fragment } from 'react'
import AdSense from 'react-adsense';
import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import HeroBanner from './WhatsHappeningSection/Hero_Banner'
import EventsArticles from './WhatsHappeningSection/Events_Articles'
import EventsSection from './WhatsHappeningSection/Events_Section'
import FeaturedEvents from './WhatsHappeningSection/Featured_Events'
import { useEffect, useState } from 'react'
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";


function Whats_Happening (props) {
    const today = new Date()
    
    const [date, setDate] = useState([]);
    useEffect(() => {
        require('../css/date-calendar.css')
    }, [])

    useEffect( () => {
        const fetchData = () => {
            props.getUpcomingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 6 })
        }
        fetchData();
    }, [])

    useEffect( () => {
        props.getEventDate({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 800 })
    }, [])

    useEffect( () => {
        setDate(props.date);
    }, [])

    useEffect(() => {
        var THIS = this;
        //console.log(THIS.props, 'upcomingWhta')
        props.updateUpcomingEventNo({ upcomingFlag: 1 })
        props.updateOngoingEventNo({ ongoingFlag: 1 })
        props.getWhatsHappenBanner({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 5 })
        props.getFeaturedEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 12, slug: 'featured_event' })
        props.getUpcomingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 6 })
        props.getOngoingEvents({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 6 })
        props.getUpcomingCategoryList()
        jQuery(document).ready(function () {
            window.$(".whats_happening-nav").addClass("active");

            window.$(".mscroll-y").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "outside"
            });

            window.$(".mscroll-y-inside").mCustomScrollbar({
                axis: "y",
                scrollEasing: "linear",
                scrollInertia: 300,
                autoHideScrollbar: "true",
                autoExpandScrollbar: "true",
                scrollbarPosition: "inside"
            });

        });
    }, [])

    
        return (
            <div className="container-fluid">
                <div className="row">
                    <Header />
                    
                    <Fragment>

                        {/* Hero Banner Starts here */}
                        <HeroBanner />
                        {/* Hero Banner Ends here */}

                        {/* Events Articles Starts here */}
                       
                        {
                            props.date && (props.date.length > 0) ?
                            <EventsArticles 
                                dateArr = {date}
                            /> : " "

                        }
                       
                        {/* Events Articles Ends here */}
                        {/* Featured Events Starts here */}
                        <FeaturedEvents />
                        {/* Featured Events Ends here */}
                      
                    
                        <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              {/* <UserAgent tablet mobile>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 288, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent> */}
              <UserAgent windows mac>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 1111, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider> 
                        
                        {/* Events Section Starts here */}
                        <EventsSection />
                        {/* Events Section Ends here */}
                     
                
                        <UserAgentProvider
              ua={ window.navigator.userAgent }
            >
              {/* <UserAgent tablet mobile>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 288, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent> */}
              <UserAgent windows mac>
                <div className="container">
                  <AdSense.Google
                    client="ca-pub-9111417808865977"
                    slot="9857840469"
                    style={ { width: 1111, height: 140, float: "left" } }
                    format=""
                  />
                </div>
              </UserAgent>
            </UserAgentProvider> 
                    </Fragment>

                    <Footer />
                </div>
            </div>
        )
 
}
export default Whats_Happening;
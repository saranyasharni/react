import React, { Component, Fragment } from 'react'

import jQuery from 'jquery'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

import history from "../stores/history";

export default class AdvertiseWithUs extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        document.title = "TheHomeGround Asia | News | Sports | Esports | Lifestyle | Events | TV"
        var THIS = this;
        jQuery(document).ready(function () {

            window.jQuery('.input-group.date').datepicker(
                { format: "dd/mm/yyyy" }).off('change').change((e) => { THIS.props.updateAdvertiseInfo('timeline', e.target.value) });
        })
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {

            window.jQuery('.input-group.date').datepicker(
                { format: "dd/mm/yyyy" }).off('change').change((e) => { THIS.props.updateAdvertiseInfo('timeline', e.target.value) });

            if (THIS.props.advertiseStatus === 1) {
                THIS.props.resetAdvertise({
                    fullName: '',
                    email: '',
                    mobileNo: '',
                    companyAddress: '',
                    interestOfChoosing: '',
                    message: '',
                    advertiseErrors: {}
                })
                jQuery('.advertise-forms .alert').html('<strong>Success!</strong> Advertise With Us Successfully.');
                jQuery('.advertise-forms .alert').removeClass('alert-danger').addClass('alert-success')
                setTimeout(function () {
                    jQuery(".advertise-forms .alert").removeClass('alert-success');
                }, 2000);
                THIS.props.updateAdvertiseStatus(0);
                setTimeout(function () {
                    history.push('/')
                }, 1000);
            } else if (THIS.props.advertiseStatus === 2) {
                jQuery('.advertise-forms .alert').html('<strong>Error!</strong> Failed To Advertise.');
                jQuery('.advertise-forms .alert').removeClass('alert-success').addClass('alert-danger')
                setTimeout(function () {
                    jQuery(".advertise-forms .alert").removeClass('alert-danger');
                }, 2000);
                THIS.props.updateAdvertiseStatus(0);
            }
        })
    }

    async advertise(event) {
        event.preventDefault();
        if (await this.validateAdvertiseForm()) {
            this.props.createAdvertise({
                fullName: this.props.fullName,
                email: this.props.email,
                budget: this.props.budget,
                timeline: '09/07/2020',
                objective: this.props.objective,
                companyAddress: this.props.companyAddress,
                message: this.props.message
            })
        }

    }

    async validateAdvertiseForm() {
        await this.props.resetAdvertise({
            advertiseErrors: {}
        })
        let valid = true;
        let errors = this.props.advertiseErrors;
        if (this.props.fullName == "" || this.props.fullName == null) {
            valid = false;
            errors.fullName = "please enter name"
        }
        if (this.props.email == "" || this.props.email == null) {
            valid = false;
            errors.email = "please enter mail"
        }
        if (!this.props.email == "") {
            if (!this.validateEmail(this.props.email)) {
                valid = false;
                errors.email = "please enter a valid email"
            }
        }
        if (this.props.budget == "" || this.props.budget == null) {
            valid = false;
            errors.budget = "please enter budget"
        }
        if (this.props.companyAddress == "" || this.props.companyAddress == null) {
            valid = false;
            errors.companyAddress = "please enter company address"
        }
        // if (this.props.timeline == "" || this.props.timeline == null) {
        //     valid = false;
        //     errors.timeline = "please give timeline"
        // }
        if (this.props.message == "" || this.props.message == null) {
            valid = false;
            errors.message = "please leave message"
        }
        if (this.props.objective == "" || this.props.objective == null) {
            valid = false;
            errors.objective = "please give objective"
        }
        this.props.updateAdvertiseErrors(errors);
        return valid;

    }

    validateEmail(email) {
        const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

        return expression.test(String(email).toLowerCase());
    }

    render() {

        return (


            < div className="container-fluid">
                <div className="row">
                    <Header />
                    <section className="advertise-section relative">
                        <div className="container">
                            <div className="row">
                                <div className="col-sm-6 advertise-bg" style={{ backgroundImage: `url(${process.env.PUBLIC_URL + "/assets/images/advertise-bg.png"})` }}></div>
                                <div className="col-sm-6 advertise-form ">
                                    <div className="blue-bg-advertise">
                                        <h1 className="text-left">Advertise with us</h1>
                                        <h3>Hello !</h3>
                                        {/* <p className="text-left">
                                            Lorem ipsum, or lipsum as it is sometimes known, is dummy text used
            in laying out print,{" "}
                                        </p> */}
                                    </div>
                                    <form className="advertise-forms">
                                        <div className="alert" role="alert">
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="examplename"
                                                value={(this.props.fullName) ? this.props.fullName : ''}
                                                onChange={e => {
                                                    if (e.target.value.match("^[a-zA-Z ]*$") != null) {
                                                        this.props.updateAdvertiseInfo('fullName', e.target.value)
                                                    }
                                                }}
                                                placeholder="Fullname"
                                            />
                                            {(this.props.advertiseErrors.fullName && this.props.advertiseErrors.fullName.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.fullName}</span> : ''}
                                            <i className="fa fa-user-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="exampleemail"
                                                value={(this.props.email) ? this.props.email : ''}
                                                onChange={e => this.props.updateAdvertiseInfo('email', e.target.value)}
                                                placeholder="Email"
                                            />
                                            {(this.props.advertiseErrors.email && this.props.advertiseErrors.email.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.email}</span> : ''}
                                            <i className="fa fa-envelope-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="companyaddress"
                                                value={(this.props.companyAddress) ? this.props.companyAddress : ''}
                                                onChange={e => this.props.updateAdvertiseInfo('companyAddress', e.target.value)}
                                                placeholder="Company Address"
                                            />
                                            {(this.props.advertiseErrors.companyAddress && this.props.advertiseErrors.companyAddress.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.companyAddress}</span> : ''}
                                            <i className="fa fa-address-book-o" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="budget"
                                                value={(this.props.budget) ? this.props.budget : ''}
                                                onChange={e => this.props.updateAdvertiseInfo('budget', e.target.value)}
                                                placeholder="Budget"
                                            />
                                            {(this.props.advertiseErrors.budget && this.props.advertiseErrors.budget.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.budget}</span> : ''}
                                            <i className="fa fa-dollar" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">

                                            {/* <input
                                                className="input-group date mar-t-no form-control"
                                                data-date-format="dd/mm/yyyy"
                                                type="text"
                                                placeholder="Timeline"
                                                value={(this.props.timeline) ? this.props.timeline : ''}

                                            /> */}
                                            {/* <input
                                                type="text"
                                                className="form-control"
                                                id="timeline"
                                                value={(this.props.timeline) ? this.props.timeline : ''}
                                                onChange={e => this.props.updateAdvertiseInfo('timeline', e.target.value)}
                                                placeholder="Timeline"
                                            /> */}
                                            {/* {(this.props.advertiseErrors.timeline && this.props.advertiseErrors.timeline.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.timeline}</span> : ''} */}
                                            <i className="fa fa-calendar" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="objective"
                                                value={(this.props.objective) ? this.props.objective : ''}
                                                onChange={e => this.props.updateAdvertiseInfo('objective', e.target.value)}
                                                placeholder="Objective"
                                            />
                                            {(this.props.advertiseErrors.objective && this.props.advertiseErrors.objective.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.objective}</span> : ''}
                                            <i className="fa fa-cog" aria-hidden="true" />
                                        </div>
                                        <div className="form-group relative">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="message"
                                                value={(this.props.message) ? this.props.message : ''}
                                                onChange={e => this.props.updateAdvertiseInfo('message', e.target.value)}
                                                placeholder="Message"
                                            />
                                            {(this.props.advertiseErrors.message && this.props.advertiseErrors.message.length > 0) ?
                                                < span className='text-danger'>{this.props.advertiseErrors.message}</span> : ''}
                                            <i className="fa fa-comment-o" aria-hidden="true" />
                                        </div>
                                        <button
                                            type="button"
                                            className="btn btn-primary btn-block advertise-btn"
                                            onClick={e => this.advertise(e)}>
                                            SEND
          </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>


                    <Footer />
                </div>
            </div >


        )
    }
}



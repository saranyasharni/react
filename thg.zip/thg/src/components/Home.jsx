import React, { Component, Fragment } from 'react'

import Header from '../containers/common/Header'
import Footer from '../containers/common/Footer'

// import scriptFiles from './script';

import jQuery from 'jquery'
import AdSense from 'react-adsense';
import HomeBanner from './HomeSection/Home_Banner'
import HomeTrending from './HomeSection/Home_Trending'
import HomeReel from './HomeSection/Home_Reel'
import LatestArticles from './HomeSection/Latest_Articles'
import RecommendedArticles from './HomeSection/Recommended_Articles'
import MixedArticles from './HomeSection/Mixed_Articles'
import FeaturedArticles from './HomeSection/Featured_Articles'
import HomeTHGTv from './HomeSection/Home_THGTv'
import PriceSection from './HomeSection/Price_Section'
import PopularArticles from './HomeSection/Popular_Articles'
import { UserAgentProvider, UserAgent } from "@quentin-sommer/react-useragent";
export default class Home extends Component {
    constructor(props) {
        super(props);
    }

    adcls() {
        const popup = document.querySelector(".full-screen");
        if(popup){
            popup.classList.toggle("hidden");
            window.jQuery('body').css('overflow', 'auto');
            sessionStorage.setItem("takeoverFirstTime", 1)
        }
    }
    
    componentDidMount() {

        setTimeout(function () {
            const popup = document.querySelector(".full-screen");
            if(popup){
                popup.classList.toggle("hidden");
                window.jQuery('body').css('overflow', 'hidden');
            }
        }, 5000);
        var THIS = this;
        jQuery(document).ready(function () {
            // if (THIS.props.featureArticlesList.length > 0 && THIS.props.latestArticlesList.length > 0 && THIS.props.popularArticlesList.length > 0) {
            //     window.$(".snip-caurosel").owlCarousel({
            //         items: 4,
            //         loop: false,
            //         dots: false,
            //         margin: 15,
            //         nav: true,
            //         responsive: {
            //             0: {
            //                 items: 1,
            //             },
            //             768: {
            //                 items: 4,
            //             }
            //         }
            //     });
            // }
        })
        // const installGoogleAds = () => {
        //     const elem = document.createElement("script");
        //     elem.src =
        //       "//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
        //     elem.async = true;
        //     elem.defer = true;
        //     document.body.insertBefore(elem, document.body.firstChild);
        //   };
        //   installGoogleAds();
        //   (adsbygoogle = window.adsbygoogle || []).push({});
    }

    componentDidUpdate() {
        var THIS = this;
        jQuery(document).ready(function () {
            // if (THIS.props.featureArticlesList.length > 0 && THIS.props.latestArticlesList.length > 0 && THIS.props.popularArticlesList.length > 0) {
            //     window.$(".snip-caurosel").owlCarousel({
            //         items: 4,
            //         loop: false,
            //         dots: false,
            //         margin: 15,
            //         nav: true,
            //         responsive: {
            //             0: {
            //                 items: 1,
            //             },
            //             768: {
            //                 items: 4,
            //             }
            //         }
            //     });
            // }
        })
    }

    render() {

        return (<>
            <div className="container-fluid">
                <div className="row">
                    <Header />

                    <Fragment>
                        {/* Flash News Starts here */}
                        <HomeBanner />
                        {/* Flash News Ends here */}

                        {/* Hero Section Starts here */}
                        <HomeTrending />
                        {/* Hero Section Ends here */}
                        {/* <div align="center"> */}
                        
                            {/* </div>                */}
                        {/* Latest Articles Starts here */}
                        <LatestArticles />
                        {/* Latest Articles Ends here */}
                        
                        {/* Recommended edArticles Starts here */}
                        <RecommendedArticles />
                        {/* Recommed Articles Ends here */}
                        
                        {/* Featured Articles Starts here */}
                        <FeaturedArticles />
                        {/* Featured Articles Ends here */}

                        {/* Reel Starts here */}
                        {/* <HomeReel /> */}
                        {/* Reel Ends here */}
                    
                            <UserAgentProvider
                                ua={window.navigator.userAgent}
                              >
                                {/* <UserAgent tablet mobile>
                                <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="1849140896"
                                style={{ width: 288, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                                </UserAgent> */}
                                <UserAgent windows mac>
                                <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="1849140896"
                                style={{ width: 1111, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                                </UserAgent>
                              </UserAgentProvider>
                        {/* Popular Articles Starts here */}
                        <PopularArticles />
                        {/* Popular Articles Ends here */}
                             

                        {/* Mixed Articles Starts here */}
                        <MixedArticles />
                        {/* Mixed Articles Ends here */}

                        {/* THG TV Section Starts here */}
                        <HomeTHGTv />
                        {/* THG TV Section Ends here */}
                        
                        {/* Price Section Starts here */}
                        <PriceSection />
                        {/* Price Section Ends here */}
  
                        <UserAgentProvider
                                ua={window.navigator.userAgent}
                            >
                                <UserAgent tablet>
                                <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={{ width: 710, height: 140, float: "left" }}
                                format=""
                            />
                        </div>
                                </UserAgent>
                                <UserAgent mobile>
                                <div className="container mt-5" >
                                <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={ { width: 328, height: 140, float: "left" } }
                                format=""
                                />
                                </div>
                                </UserAgent>
                            <UserAgent windows mac>
                            <div className="container">
                            <AdSense.Google
                                client="ca-pub-9111417808865977"
                                slot="9857840469"
                                style={{ width: 1111, height: 140, float: "left" }}
                                format=""
                            />
                            </div>
                            </UserAgent>
                            </UserAgentProvider>
                        
                    </Fragment>

                    <Footer />
                </div>
            </div>
            {/* {
                (sessionStorage.getItem("takeoverFirstTime") === 0  || sessionStorage.getItem("takeoverFirstTime") === null) &&
            
                <UserAgentProvider ua={window.navigator.userAgent}>
                    <UserAgent tablet mobile>
                        <div
                        className="full-screen hidden flex-container-center"
                        id="take_over"
                        >
                        <div>
                            <p className="ad_cls" onClick={this.adcls}>
                            x
                            </p>
                        </div>
                        <AdSense.Google
                            client="ca-pub-9111417808865977"
                            slot="9857840469"
                            style={{ width: 600, height: 600, float: "left" }}
                            format=""
                        />
                        </div>
                    </UserAgent>
                </UserAgentProvider>
            } */}
            </>
        )
    }
}



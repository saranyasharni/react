import React, { Component } from "react";
import Routes from './routes'
import { Provider } from 'react-redux'
import configureStore from './stores/configureStore';

class App extends Component {
  render = () => {
    return (
      <Provider store={configureStore()} >
        <div className="App">
          <Routes />
        </div>
      </Provider>
    );
  }

}

export default App;

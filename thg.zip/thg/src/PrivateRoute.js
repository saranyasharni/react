import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom';
class PrivateRoute extends Component {
    constructor(props) {
        super(props)
    }
    componentWillMount() {
        console.log('rest', localStorage.getItem('user_id'))
    }
    render() {
        const { component: Component, ...rest } = this.props;
        return (

            // Show the component only when the user is logged in
            // Otherwise, redirect the user to /signin page
            <Route {...rest} render={props => (
                localStorage.user_id ?
                    <Component {...props} />
                    : <Redirect to="/" />
            )} />
        );

    }
}

export default PrivateRoute;
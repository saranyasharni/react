import {connect} from 'react-redux'
import TermsConditionsComponent from '../components/Terms_Conditions'
import * as actions from '../actions/Data_Protection_Policy';
import * as footerActions from '../actions/common/Footer';
const mapStateToProps = (state, ownProps) => {
    // console.log('state',state.DataProtectionPolicy)
  return {
    termsContents: state.DataProtectionPolicy.termsContents,
    termsData: state.Footer.termsData
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    //getTermsContents: (data) => dispatch(actions.getTermsContents(data)),
    getTermsData : (data) => dispatch(footerActions.getTermsData(data)),
  }
};

const Terms_Conditions = connect(
  mapStateToProps,
  mapDispatchToProps,
)(TermsConditionsComponent);

export default Terms_Conditions;

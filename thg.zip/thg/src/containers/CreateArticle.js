import { connect } from 'react-redux'
import CreateArticleComponent from '../components/ProfileSection/CreateArticle'
import * as actions from '../actions/CreateArticle';

const mapStateToProps = (state, ownProps) => {

  return {
    
    dropdown: state.CreateArticle.dropdown,
    article_title: state.CreateArticle.article_title,
    article_id: state.CreateArticle.article_id,
    video_file: state.CreateArticle.video_file,
    video_file_name: state.CreateArticle.video_file_name,
    video_link: state.CreateArticle.video_link,
    article_content: state.CreateArticle.article_content,
    article_image: state.CreateArticle.s3_image_upload_link,
    category_ids: state.CreateArticle.category_ids,
    categories: state.CreateArticle.categories,
    articleStatus: state.CreateArticle.articleStatus,
    editStatus: state.CreateArticle.editStatus,
    articleErrors: state.CreateArticle.articleErrors,
    edit_article_image: state.CreateArticle.article_image,
    credit_line_img: state.CreateArticle.credit_line_img,
    credit_line_video: state.CreateArticle.credit_line_video,
    credit_text_video: state.CreateArticle.credit_text_video,
    credit_text: state.CreateArticle.credit_text
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    changeArticlesInfo: (f, e) => dispatch(actions.changeArticleInfo(f, e)),
    articleImageUpload: (data) => dispatch(actions.uploadArticleImage(data)),
    createNewArticle: (data) => dispatch(actions.createArticle(data)),
    scheduleNewArticle: (data) => dispatch(actions.scheduleForLater(data)),
    updateArticle: (data) => dispatch(actions.editArticle(data)),
    updateArticleStatus: (data) => dispatch(actions.changeArticleStatus(data)),
    updateEditStatus: (data) => dispatch(actions.changeEditStatus(data)),
    resetArticleForm: (data) => dispatch(actions.resetCreateArticleForm(data)),
    updateArticleErrors: (data) => dispatch(actions.updateCreateArticleErrors(data)),
    getArticleDetail: (data) => dispatch(actions.getArticleDetailById(data)),
    getCatList: () => dispatch(actions.getCategoryList())
  }
};

const CreateArticle = connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateArticleComponent);

export default CreateArticle;

import {connect} from 'react-redux'
import YourArticlesComponent from '../components/ProfileSection/YourArticles'
import * as actions from '../actions/YourArticles';

const mapStateToProps = (state, ownProps) => {
  return {
    deleteStatus: state.YourArticles.deleteStatus,
    pendingStatus: state.YourArticles.pendingStatus,
    draftArticlesList: state.YourArticles.draftArticlesList,
    publishArticlesList: state.YourArticles.publishArticlesList,
    pendingArticlesList: state.YourArticles.pendingArticlesList,
    draftArticlePageNo: state.YourArticles.draftArticlePageNo,
    publishArticlePageNo: state.YourArticles.publishArticlePageNo,
    pendingArticlePageNo: state.YourArticles.pendingArticlePageNo,
    articleMoreStatus: state.YourArticles.articleMoreStatus,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    deleteArticleFromList: (data) => dispatch(actions.deleteArticle(data)),
    updateArticle: (data) => dispatch(actions.moveToPending(data)),
    updateDeleteStatus: (data) => dispatch(actions.deleteArticleStatus(data)),
    updatePendingStatus: (data) => dispatch(actions.changePendingStatus(data)),
    getDraftArticlesList: (data) => dispatch(actions.draftArticles(data)),
    getPendingArticlesList: (data) => dispatch(actions.pendingArticles(data)),
    getPublishArticlesList: (data) => dispatch(actions.publishArticles(data)),
    moreDraftArticlesList: (data) => dispatch(actions.moreDraftArticles(data)),
    morePublishArticlesList: (data) => dispatch(actions.morePublishArticles(data)),
    morePendingArticlesList: (data) => dispatch(actions.morePendingArticles(data)),
    updateDraftPageNo: (data) => dispatch(actions.updateDraftPageNo(data)),
    updatePublishPageNo: (data) => dispatch(actions.updatePublishPageNo(data)),
    updatePendingPageNo: (data) => dispatch(actions.updatePendingPageNo(data)),
    changeArticleMoreStatus: (data) => dispatch(actions.updateArticleMoreStatus(data)),
  }
};

const YourArticles = connect(
  mapStateToProps,
  mapDispatchToProps,
)(YourArticlesComponent);

export default YourArticles;

import { connect } from 'react-redux'
import HomeComponent from '../components/Home'
import * as actions from '../actions/Home';

const mapStateToProps = (state, ownProps) => {
  return {
    // latestArticlesList: state.Home.latestArticles,
    // bannerList: state.Home.bannerList,
    // featureArticlesList: state.Home.featureArticles,
    // popularArticlesList: state.Home.popularArticles,
    // trendingList: state.Home.trendingList,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // getLatestArticlesList: () => dispatch(actions.getLatestArticlesList()),
    // getBannerList: () => dispatch(actions.getBannerList()),
  }
};

const Home = connect(
  mapStateToProps,
  mapDispatchToProps,
)(HomeComponent);

export default Home;

import { connect } from 'react-redux'
import ContestGiveawayComponenet from '../components/ContestGiveaway'
import * as actions from '../actions/Contest'
import * as profileactions from '../actions/Profile';

const mapStateToProps = (state, ownProps) => {
  return {
    contestDetail: state.Contest.contestDetail,
    userProfile: state.Profile.userProfile,
    contestStatus: state.Contest.contestStatus,
    occupation: state.Contest.occupation,
    errors: state.Contest.errors,
    dob:state.Contest.dob,
    mobile_no : state.Contest.mobile_no,
    terms: state.Contest.terms,
    give_away_detail_list : state.Contest.give_away_detail_list
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    changeInput: (f, e) => dispatch(actions.inputChange(f, e)),
    getGiveawayDetail: (data) => dispatch(actions.getGiveawayDetail(data)),
   // getContestDetail: (data) => dispatch(actions.getContestDetail(data)),
    getProfileDetail: (data) => dispatch(profileactions.getUserProfile(data)),
    createGiveAway: (data) => dispatch(actions.createGiveAway(data)),
    updateContestStatus: (data) => dispatch(actions.contestStatus(data)),
    resetForm: (data) => dispatch(actions.resetForm(data)),
    updateErrors: (data) => dispatch(actions.updateErrors(data))
  }
};

const ContestGiveaway = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ContestGiveawayComponenet);

export default ContestGiveaway;

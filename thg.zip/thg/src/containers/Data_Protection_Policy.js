import {connect} from 'react-redux'
import DataProtectionComponent from '../components/Data_Protection_Policy'
import * as actions from '../actions/Data_Protection_Policy';
import * as FooterActions from '../actions/common/Footer';

const mapStateToProps = (state, ownProps) => {
    //console.log('state',state.DataProtectionPolicy)
  return {
    privacyContents: state.DataProtectionPolicy.privacyContents,
    dataProtection: state.Footer.dataProtection
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getDataProtection : (data) => dispatch(FooterActions.getDataProtection(data)),
    //fetchPrivacyContents: (data) => dispatch(actions.getPrivacyContents(data)),
  }
};

const Data_Protection_Policy = connect(
  mapStateToProps,
  mapDispatchToProps,
)(DataProtectionComponent);

export default Data_Protection_Policy;

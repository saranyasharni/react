import {connect} from 'react-redux'
import CareerComponent from '../components/Career'
import * as actions from '../actions/Data_Protection_Policy';
import * as Footeractions from '../actions/common/Footer';
const mapStateToProps = (state, ownProps) => {
    //console.log('state',state.DataProtectionPolicy)
  return {
    career:state.Footer.career
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getCareer : (data) => dispatch(Footeractions.getCareer(data)),
  }
};

const Career = connect(
  mapStateToProps,
  mapDispatchToProps,
)(CareerComponent);

export default Career;

import { connect } from 'react-redux'
import ContestSubmitEntryComponenet from '../components/ContestSubmitEntry'
import * as actions from '../actions/Contest'
import * as profileactions from '../actions/Profile';

const mapStateToProps = (state, ownProps) => {
  return {
    contestDetail: state.Contest.contestDetail,
    userProfile: state.Profile.userProfile,
    contestStatus: state.Contest.contestStatus,
    errors: state.Contest.errors,
    imageUrl: state.Contest.imageUrl,
    occupation: state.Contest.occupation,
    contest_occupation: state.Contest.contest_occupation,
    dob: state.Contest.dob,
    terms: state.Contest.terms,
    mobile_no : state.Contest.mobile_no,
    first_name : state.Contest.first_name,
    last_name: state.Contest.last_name,
    contest_email: state.Contest.contest_email,
    monthly_income: state.Contest.monthly_income,
    photos_desc:state.Contest.photos_desc,
    fileType: state.Contest.fileType
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    changeInput: (f, e) => dispatch(actions.inputChange(f, e)),
    getContestDetail: (data) => dispatch(actions.getContestDetail(data)),
    getProfileDetail: (data) => dispatch(profileactions.getUserProfile(data)),
    createSubmitEntry: (data) => dispatch(actions.createSubmitEntry(data)),
    updateContestStatus: (data) => dispatch(actions.contestStatus(data)),
    updateErrors: (data) => dispatch(actions.updateErrors(data)),
    resetForm: (data) => dispatch(actions.resetForm(data)),
    uploadImage: (data) => dispatch(actions.uploadContestImage(data)),
  }
};

const ContestSubmitEntry = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ContestSubmitEntryComponenet);

export default ContestSubmitEntry;

import { connect } from 'react-redux'
import SubCategoryComponent from '../components/SubCategory'
import * as actions from '../actions/Sports';
import * as articleDetailActions from '../actions/Article_Detail';

const mapStateToProps = (state, ownProps) => {
  return {
    articlePageNo: state.Sports.articlePageNo,
    latestArticlesList: state.Sports.latestArticlesList,
    featuredArticlesList:state.Sports.featuredArticlesList,
    popularArticlesList: state.Sports.popularArticlesList,
    eSportsCategoryList: state.Sports.eSportsCategoryList,
    travelCategoryList: state.Sports.travelCategoryList,
    reviewCategoryList: state.Sports.reviewCategoryList,
    //subCategoryList: state.ArticleDetail.subCategoryList,
    highlightsList: state.Sports.highlightsList,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getCategoryList: (data) => dispatch(actions.getCategoryList(data)),
    getFeaturedArticlesList: (data) => dispatch(actions.getFeaturedArticlesList(data)),
    updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
   // getSubCategoryList: (data) => dispatch(articleDetailActions.getSportsSubCategoryList(data)),
    getPopularArticlesList: (data) => dispatch(actions.getPopularArticlesList(data)),
    getHighLightsArticlesList: (data) => dispatch(actions.getHighLightsArticles(data)),
  }
};

const Sports = connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubCategoryComponent);

export default Sports;

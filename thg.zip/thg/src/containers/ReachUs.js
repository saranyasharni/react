import {connect} from 'react-redux'
import ReachUsComponent from '../components/ReachUs'
import * as actions from '../actions/ReachUs';

const mapStateToProps = (state, ownProps) => {
  return {
    fullName: state.ReachUs.fullName,
    email: state.ReachUs.email,
    mobileNo: state.ReachUs.mobileNo,
    message: state.ReachUs.message,
    reachUsStatus: state.ReachUs.reachUsStatus,
    reachUsErrors: state.ReachUs.reachUsErrors,
    reachUs:state.Footer.reachUs
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    updateReachUsInfo: (f, e) => dispatch(actions.changeReachUsInfo(f, e)),
    updateReachUsStatus: (data) => dispatch(actions.changeReachUsStatus(data)),
    resetReachUs: (data) => dispatch(actions.resetReachUsForm(data)),
    createReachUs: (data) => dispatch(actions.fetchReachUs(data)),
    updateReachUsErrors: (data) => dispatch(actions.changeReachUsErrors(data)),
  }
};

const ReachUs = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ReachUsComponent);

export default ReachUs;

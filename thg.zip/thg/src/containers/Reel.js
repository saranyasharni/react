import { connect } from 'react-redux'
import ReelComponent from '../components/Reel'
import * as actions from '../actions/Reel';

const mapStateToProps = (state, ownProps) => {
  return {
    topPicksList: state.Reel.topPicksList,
    webSeriesList: state.Reel.webSeriesList,
    documentaryList: state.Reel.documentaryList,
    masterClassList: state.Reel.masterClassList,
    archivePageNo: state.Reel.archivePageNo,
    archiveStatus: state.Reel.archiveStatus,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getTopPicksList: (data) => dispatch(actions.getTopPicksList(data)),
    getWebSeriesList: (data) => dispatch(actions.getWebSeriesList(data)),
    getDocumentaryList: (data) => dispatch(actions.getDocumentaryList(data)),
    getMasterClassList: (data) => dispatch(actions.getMasterClassList(data)),
    getNewMasterClassList: (data) => dispatch(actions.getMoreMasterClassList(data)),
    updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
    changeArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data)),
  }
};

const Reel = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ReelComponent);

export default Reel;

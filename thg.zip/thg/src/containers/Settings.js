import { connect } from 'react-redux'
import SettingsComponent from '../components/ProfileSection/Settings'
import * as actions from '../actions/Settings';

const mapStateToProps = (state, ownProps) => {
  return {
    activateDeactivateSuccess: state.Settings.activateDeactivateSuccess,
    activeStatus: state.Settings.activeStatus,
    removeAccountSuccess: state.Settings.removeAccountSuccess,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    updateActivateStatus: (data) => dispatch(actions.changeActivateStatus(data)),
    updateInfo: (data) => dispatch(actions.changeActivateInfo(data)),
    deactivateAccount: (data) => dispatch(actions.activateDeactiveAccount(data)),
    deleteAccount: (data) => dispatch(actions.removeAccount(data)),
  }
};

const Settings = connect(
  mapStateToProps,
  mapDispatchToProps,
)(SettingsComponent);

export default Settings;

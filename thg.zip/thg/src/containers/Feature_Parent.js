import { connect } from 'react-redux'
import FeatureComponent from '../components/Feature_Parent'
import * as actions from '../actions/Feature_Parent';

const mapStateToProps = (state, ownProps) => {
  return {
    latestArticlesList: state.FeatureParent.latestArticles,
    // latestPhotosList: state.FeatureParent.latestPhotos,
    featuredEventsBannerList: state.FeatureParent.featuredEventsBannerList,
    currentYear: state.FeatureParent.currentYear,
    currentMonth: state.FeatureParent.currentMonth,
    monthNames: state.FeatureParent.monthNames,
    currentDate: state.FeatureParent.currentDate,
    daysOfMonth: state.FeatureParent.daysOfMonth,
    datesOfMonth: state.FeatureParent.datesOfMonth,
    increaseCount: state.FeatureParent.increaseCount,
    decreaseCount: state.FeatureParent.decreaseCount,
    purchaseTicket:state.FeatureParent.purchaseTicket,
    livtStreamVideos: state.FeatureParent.livtStreamVideos
    // calendarEvents: state.FeatureParent.calendarEvents,
    // eventCategories: state.FeatureParent.eventCategories,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getLatestArticles: (data) => dispatch(actions.getLatestArticlesList(data)),
    getLatestPhotos: (data) => dispatch(actions.getLatestPhotosList(data)),
    getLatestVideos: (data) => dispatch(actions.getLatestVideosList(data)),
    getFeaturedEventsBanner: (data) => dispatch(actions.getFeaturedEventsBanner(data)),
    increaseMonth: (data) => dispatch(actions.updateMonthAndYear(data)),
    setMonth: (data) => dispatch(actions.setMonthAndYear(data)),
    
    // fetchCalendarEvents: (data) => dispatch(actions.getCalendarEvents(data)),
    // fetchEventCategories: () => dispatch(actions.getEventCategoryList()),
  }
};

const Feature_Parent = connect(
  mapStateToProps,
  mapDispatchToProps,
)(FeatureComponent);

export default Feature_Parent;

import {connect} from 'react-redux'
import ContributeToTHGComponent from '../components/ContributeToTHG'
import * as actions from '../actions/Data_Protection_Policy';
import * as Footeractions from '../actions/common/Footer';
const mapStateToProps = (state, ownProps) => {
    //console.log('state',state.DataProtectionPolicy)
  return {
    contributeToTHG:state.Footer.contributeToTHG
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getContributeToTHG : (data) => dispatch(Footeractions.getContributeToTHG(data)),
  }
};

const ContributeToTHG = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ContributeToTHGComponent);

export default ContributeToTHG;

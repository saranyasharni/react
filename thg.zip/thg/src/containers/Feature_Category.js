import { connect } from 'react-redux'
import FeatureCategoryComponent from '../components/Feature_Category'
import * as actions from '../actions/Feature_Category';

const mapStateToProps = (state, ownProps) => {
  return {
    reelBanner: state.FeatureCategory.reelBanner,
    reelChildArticles: state.FeatureCategory.reelChildArticles,
    reelArticlePageNo: state.FeatureCategory.reelArticlePageNo,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getReelChildBannerList: (data) => dispatch(actions.getReelChildBannerList(data)),
    getReelChildArticlesList: (data) => dispatch(actions.getReelChildArticlesList(data)),
    getNewReelChildArticlesList: (data) => dispatch(actions.getNewReelChildArticlesList(data)),
    updateReelArticlePageNo: (data) => dispatch(actions.updateReelArticlePageNo(data)),
  }
};

const Feature_Category = connect(
  mapStateToProps,
  mapDispatchToProps,
)(FeatureCategoryComponent);

export default Feature_Category;

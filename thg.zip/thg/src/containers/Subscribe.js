import {connect} from 'react-redux'
import SubscribeComponent from '../components/Subscribe'
import * as actions from '../actions/Subscribe';
import * as actionsProfile from '../actions/Profile';


const mapStateToProps = (state, ownProps) => {
  return {
    firstName: state.Subscribe.firstName,
    lastName: state.Subscribe.lastName,
    email: state.Subscribe.email,
    frequency: state.Subscribe.frequency,
    // frequencyList: state.Profile.frequencyList,
    notify_topics: state.Subscribe.notify_topics,
    subscribeStatus: state.Subscribe.subscribeStatus,
    categoryList: state.Profile.catrgoryList,
    subscribeErrors: state.Subscribe.subscribeErrors,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    updateSubscribeInfo: (f, e) => dispatch(actions.changeSubscribeInfo(f, e)),
    updateSubscribeStatus: (data) => dispatch(actions.changeSubscribeStatus(data)),
    resetSubscribe: (data) => dispatch(actions.resetSubscribeForm(data)),
    createSubscribe: (data) => dispatch(actions.subscribeWithUs(data)),
    updateSubscribeErrors: (data) => dispatch(actions.changeSubscribeErrors(data)),
    // getFreqList: (data) => dispatch(actions.getFrequencyList(data)),
    getCatList: () => dispatch(actionsProfile.getCategoryList())
  }
};

const Subscribe = connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubscribeComponent);

export default Subscribe;

import { connect } from 'react-redux'
import ThgTvDetailComponent from '../components/ThgTvDetail'
import * as actions from '../actions/ThgTvDetail';

const mapStateToProps = (state, ownProps) => {
    // console.log('state1', state)
    return {
        streamVideoDetail: state.ThgTvDetail.streamVideoDetail,
        videoCommentsList: state.ThgTvDetail.videoCommentsList,
        relatedVideos: state.ThgTvDetail.relatedVideos,
        latestVideos: state.ThgTvDetail.latestVideos
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        getStreamVideoArticleDetail: (data) => dispatch(actions.streamAuthorization(data)),
        getLikes: (data) => dispatch(actions.getLikes(data))
    }
};

const ThgTv_Detail = connect(
    mapStateToProps,
    mapDispatchToProps,
)(ThgTvDetailComponent);

export default ThgTv_Detail;

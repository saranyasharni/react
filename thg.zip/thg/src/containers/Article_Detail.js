import { connect } from 'react-redux'
import ArticleDetailComponent from '../components/Article_Detail'
import * as actions from '../actions/Article_Detail';
import * as ContestActions from '../actions/Contest'
import * as SurvayActions from '../actions/Survay'

const mapStateToProps = (state, ownProps) => {
  return {
    articleDetail: state.ArticleDetail.articleDetail,
    // subCategoryList: state.ArticleDetail.subCategoryList,
    designState: state.ArticleDetail.designState,
    featureArticles: state.Home.featureArticles,
    commentsList: state.ArticleDetail.commentsList,
    commentStatus: state.ArticleDetail.commentStatus,
    replyCommentStatus: state.ArticleDetail.replyCommentStatus,
    loading:state.ArticleDetail.loading,
    giveawayDetail: state.Contest.giveawayDetail,
    survayList:state.Survay.survayList,
    relatedArticles : state.ArticleDetail.relatedArticles
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getArticleDetail: (data) => dispatch(actions.getArticleDetail(data)),
    getDraftArticleDetail: (data) => dispatch(actions.getDraftArticleDetail(data)),
    // getSportsSubCategoryList: (data) => dispatch(actions.getSportsSubCategoryList(data)),
    emptyArticleDetails: () => dispatch(actions.articleDetails([])),
    updateDesignState: (data) => dispatch(actions.updateDesignState(data)),
    createCommentForArticle: (data) => dispatch(actions.createComment(data)),
    getGiveAwayStatus: (data) => dispatch(ContestActions.getGiveAwayStatus(data)),
    getSurveyQuestionList: (data) => dispatch(SurvayActions.getSurveyQuestionList(data)),
    createSubmitSurvay: (data) => dispatch(SurvayActions.createSubmitSurvay(data)),

  }
};

const 
Article_Detail = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ArticleDetailComponent);

export default Article_Detail;

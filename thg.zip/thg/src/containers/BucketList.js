import { connect } from 'react-redux'
import BucketListComponent from '../components/ProfileSection/BucketList'
import * as actions from '../actions/BucketList';
import * as headerActions from '../actions/common/Header';

const mapStateToProps = (state, ownProps) => {
  return {
    bucketLists: state.BucketList.bucketLists,
    editBucketStatus: state.BucketList.editBucketStatus,
    bucketItem: state.Header.bucketItem,
    showHideBtn: state.BucketList.showHideBtn,
    id: state.BucketList.id,
    articleError: state.Header.articleError
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    get3BucketList: (data) => dispatch(actions.get3BucketList(data)),
    changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    editBucketItem:(data) => dispatch(actions.editBucketItem(data)),
    changeBucketStatus:(data) => dispatch(actions.editBucketStatus(data)),
    showHide:(data) => dispatch(actions.showHide(data)),
    editBucket:(data) => dispatch(actions.editBucket(data)),
  }
};

const BucketList = connect(
  mapStateToProps,
  mapDispatchToProps,
)(BucketListComponent);

export default BucketList;

import {connect} from 'react-redux'
import AboutUsComponent from '../components/AboutUs'
import * as actions from '../actions/Data_Protection_Policy';
import * as Footeractions from '../actions/common/Footer';
const mapStateToProps = (state, ownProps) => {
    //console.log('state',state.DataProtectionPolicy)
  return {
    privacyContents: state.DataProtectionPolicy.privacyContents,
    aboutUs:state.Footer.aboutUs,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    //fetchPrivacyContents: (data) => dispatch(actions.getPrivacyContents(data)),
    getAboutUsData : (data) => dispatch(Footeractions.getAboutUsData(data)),
    getCareer : (data) => dispatch(Footeractions.getCareer(data)),
  }
};

const AboutUs = connect(
  mapStateToProps,
  mapDispatchToProps,
)(AboutUsComponent);

export default AboutUs;

import { connect } from 'react-redux'
import ArchiveComponent from '../components/Archive_Articles'
import * as actions from '../actions/Archive_Articles';

const mapStateToProps = (state, ownProps) => {
  console.log('state',state)
  return {
    archiveList: state.Archive.archiveList,
    coachPageNo: state.Archive.coachPageNo,
    coachDetails:state.Archive.coachDetails,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    fetchArchiveArticlesList: (data) => dispatch(actions.getArchiveArticlesList(data)),
    getNewArchiveListByUser: (data) => dispatch(actions.getNewArchiveList(data)),
    updateCoachPageNo: (data) => dispatch(actions.updateCoachPageNo(data)),
    updateCoachDetails: (data) => dispatch(actions.updateCoachDetails(data))
  }
};

const Archive_Articles = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ArchiveComponent);

export default Archive_Articles;

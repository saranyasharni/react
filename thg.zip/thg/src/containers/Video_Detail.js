import {connect} from 'react-redux'
import VideoDetailComponent from '../components/Video_Detail'
import * as actions from '../actions/Video_Detail';

const mapStateToProps = (state, ownProps) => {
  return {
    articleVideoDetail: state.VideoDetail.articleVideoDetail,
    videoCommentsList: state.VideoDetail.videoCommentsList,
    relatedVideos: state.VideoDetail.relatedVideos,
    latestVideos: state.VideoDetail.latestVideos
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getVideoArticleDetail: (data) => dispatch(actions.getVideoArticleDetail(data)),
    getLatestViideos: (data) => dispatch(actions.getLatestVideoArticles(data)),
  }
};

const Video_Detail = connect(
  mapStateToProps,
  mapDispatchToProps,
)(VideoDetailComponent);

export default Video_Detail;

import { connect } from 'react-redux'
import SearchComponent from '../components/Search'
import * as actions from '../actions/Search';
import * as headerActions from '../actions/common/Header';

const mapStateToProps = (state, ownProps) => {
  // console.log('state',state.Search.searchList.length)
  return {
    searchList: state.Search.searchList,
    searchTerm: state.Search.searchTerm,
    bucketItem: state.Header.bucketItem,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    fetchSearchArticlesList: (data) => dispatch(actions.getSearchArticlesList(data)),
    changeSearchTerm: (data) => dispatch(actions.updateSearchTerm(data)),
    changeSearchArticles: (data) => dispatch(actions.searchArticlesList(data)),
    changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
  }
};

const Search = connect(
  mapStateToProps,
  mapDispatchToProps,
)(SearchComponent);

export default Search;

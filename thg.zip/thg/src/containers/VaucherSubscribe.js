import { connect } from 'react-redux'
import VaucherSubscribeComponent from '../components/VaucherSubscribe'
import * as actions from '../actions/Contest'

const mapStateToProps = (state, ownProps) => {
  return {
    contestList: state.Contest.contestList,
    contestPageNo: state.Contest.contestPageNo,
    bannerContestList: state.Contest.bannerContestList,
    loading:state.Contest.loading,
    archiveStatus: state.Contest.archiveStatus
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getContestList: (data) => dispatch(actions.getContestList(data)),
    getNewContestList: (data) => dispatch(actions.getNewContestList(data)),
    getBannerContestList: (data) => dispatch(actions.getBannerContestList(data)),
    updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
    updateArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data))
  }
};

const VaucherSubscribe = connect(
  mapStateToProps,
  mapDispatchToProps,
)(VaucherSubscribeComponent);

export default VaucherSubscribe;

import { connect } from 'react-redux'
import CoachListingComponent from '../components/Coach_Listing'
import * as actions from '../actions/Coach_Listing';

const mapStateToProps = (state, ownProps) => {
  console.log('state',state)
  return {
    coachList: state.CoachListing.coachList,
    coachPageNo: state.CoachListing.coachPageNo,
    coachDetails:state.CoachListing.coachDetails,
    coachSearch:state.CoachListing.coachSearch,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getCoachListByUser: (data) => dispatch(actions.getCoachList(data)),
    getNewCoachListByUser: (data) => dispatch(actions.getNewCoachList(data)),
    updateCoachPageNo: (data) => dispatch(actions.updateCoachPageNo(data)),
    updateCoachDetails: (data) => dispatch(actions.updateCoachDetails(data)),
    updateCoachSearch: (data) => dispatch(actions.updateCoachSearch(data))
  }
};

const Coach_Listing = connect(
  mapStateToProps,
  mapDispatchToProps,
)(CoachListingComponent);

export default Coach_Listing;

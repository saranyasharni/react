import { connect } from 'react-redux'
import ProfileComponent from '../components/ProfileSection/Profile'
import * as actions from '../actions/Profile';

const mapStateToProps = (state, ownProps) => {
  console.log('state', state.Profile)
  return {
    userProfile: state.Profile.userProfile,
    passwordErrors: state.Profile.passwordErrors,
    errors: state.Profile.errors,
    profileStatus: state.Profile.profileStatus,
    frequencyList: state.Profile.frequencyList,
    categoryList: state.Profile.catrgoryList,
    category_ids: state.Profile.category_ids,
    categories: state.Profile.categories,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getUserProfile: (data) => dispatch(actions.getUserProfile(data)),
    changeProfileInfo: (f, e) => dispatch(actions.changeProfileInfo(f, e)),
    createProfilePicture: (data) => dispatch(actions.uploadProfile(data)),
    changePasswordInformation: (data) => dispatch(actions.changePasswordInfo(data)),
    updateProfile: (data) => dispatch(actions.updateProfile(data)),
    removeProfilePicture: (data) => dispatch(actions.deleteProfilePicture(data)),
    updatePassword: (data) => dispatch(actions.changePassword(data)),
    resetForm: (data) => dispatch(actions.resetForm(data)),
    updatePassowrdErrors: (data) => dispatch(actions.updatePassowrdErrors(data)),
    updateErrors: (data) => dispatch(actions.updateErrors(data)),
    updateProfileStatus: (data) => dispatch(actions.changeProfileStatus(data)),
    getFreqList: (data) => dispatch(actions.getFrequencyList(data)),
    getCatList: () => dispatch(actions.getCategoryList())
  }
};

const Profile = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ProfileComponent);

export default Profile;

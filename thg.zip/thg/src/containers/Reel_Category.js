import { connect } from 'react-redux'
import ReelCategoryComponent from '../components/Reel_Category'
import * as actions from '../actions/Reel_Category';

const mapStateToProps = (state, ownProps) => {
  return {
    reelBanner: state.ReelCategory.reelBanner,
    reelChildArticles: state.ReelCategory.reelChildArticles,
    reelArticlePageNo: state.ReelCategory.reelArticlePageNo,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getReelChildBannerList: (data) => dispatch(actions.getReelChildBannerList(data)),
    getReelChildArticlesList: (data) => dispatch(actions.getReelChildArticlesList(data)),
    getNewReelChildArticlesList: (data) => dispatch(actions.getNewReelChildArticlesList(data)),
    updateReelArticlePageNo: (data) => dispatch(actions.updateReelArticlePageNo(data)),
  }
};

const Reel_Category = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ReelCategoryComponent);

export default Reel_Category;

import {connect} from 'react-redux'
import THGTvComponent from '../components/THGTV'
import * as actions from '../actions/THGTV';

const mapStateToProps = (state, ownProps) => {
  return {
    onThePitchList: state.THGTV.onThePitchList,
    programme_id: state.THGTV.programme_id,
    liveStatus: state.THGTV.liveStatus,
    archivePageNo: state.THGTV.archivePageNo,
    archiveStatus: state.THGTV.archiveStatus,
    bannerEpisode: state.THGTV.bannerEpisode,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getOnThePitchList: (data) => dispatch(actions.getOnThePitchList(data)),
    getVideoStreamApi: () => dispatch(actions.getVideoStraming()),
    updateLiveStreamPlayerStatus: (data) => dispatch(actions.changeLiveStatus(data)),
    getNewOnThePitchList: (data) => dispatch(actions.getMoreOnThePitchList(data)),
    updatePageNo: (data) => dispatch(actions.updatePageNo(data)),
    changeArchiveStatus: (data) => dispatch(actions.updateArchiveStatus(data)),
  }
};

const THGTV = connect(
  mapStateToProps,
  mapDispatchToProps,
)(THGTvComponent);

export default THGTV;

import { connect } from 'react-redux'
import WhatsHappeningComponent from '../components/Whats_Happening'
import * as actions from '../actions/Whats_Happening';
import { data } from 'jquery';

const mapStateToProps = (state, ownProps) => {
  return {
    featuredEvents: state.WhatsHappening.featuredEvents,
    whatsHappenBannerList: state.WhatsHappening.whatsHappenBannerList,
    upcomingEvents: state.WhatsHappening.upcomingEvents,
    ongoingEvents: state.WhatsHappening.ongoingEvents,
    upcomingEventNo: state.WhatsHappening.upcomingEventNo,
    ongoingEventNo: state.WhatsHappening.ongoingEventNo,
    filterBy: state.WhatsHappening.filterBy,
    date: state.WhatsHappening.setdateArray,
    loading:state.WhatsHappening.loading

  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getWhatsHappenBanner: (data) => dispatch(actions.getWhatsHappenBanner(data)),
    getFeaturedEvents: (data) => dispatch(actions.getFeaturedEvents(data)),
    getUpcomingEvents: (data) => dispatch(actions.getUpcomingEvents(data)),
    getOngoingEvents: (data) => dispatch(actions.getOngoingEvents(data)),
    updateUpcomingEventNo: (data) => dispatch(actions.updateUpcomingEventNo(data)),
    updateOngoingEventNo: (data) => dispatch(actions.updateOngoingEventNo(data)),
    getEventDate: (data) => dispatch(actions.getEventDates(data)),
    getUpcomingCategoryList: () => dispatch(actions.getUpcomingCategoryList()),
  }
};

const Whats_Happening = connect(
  mapStateToProps,
  mapDispatchToProps,
)(WhatsHappeningComponent);

export default Whats_Happening;

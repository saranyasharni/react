import { connect } from 'react-redux'
import AdvertiseWithUsComponent from '../components/AdvertiseWithUs'
import * as actions from '../actions/AdvertiseWithUs';

const mapStateToProps = (state, ownProps) => {
  return {
    fullName: state.AdvertiseWithUs.fullName,
    email: state.AdvertiseWithUs.email,
    budget: state.AdvertiseWithUs.budget,
    objective: state.AdvertiseWithUs.objective,
    companyAddress: state.AdvertiseWithUs.companyAddress,
    timeline: state.AdvertiseWithUs.timeline,
    message: state.AdvertiseWithUs.message,
    advertiseStatus: state.AdvertiseWithUs.advertiseStatus,
    advertiseErrors: state.AdvertiseWithUs.advertiseErrors,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    updateAdvertiseInfo: (f, e) => dispatch(actions.changeAdvertiseInfo(f, e)),
    updateAdvertiseStatus: (data) => dispatch(actions.changeAdvertiseStatus(data)),
    resetAdvertise: (data) => dispatch(actions.resetAdvertiseForm(data)),
    createAdvertise: (data) => dispatch(actions.advertiseWithUs(data)),
    updateAdvertiseErrors: (data) => dispatch(actions.changeAdvertiseErrors(data)),
  }
};

const AdvertiseWithUs = connect(
  mapStateToProps,
  mapDispatchToProps,
)(AdvertiseWithUsComponent);

export default AdvertiseWithUs;

import {connect} from 'react-redux'
import HowWeMakeTHGComponent from '../components/HowWeMakeTHG'
import * as actions from '../actions/Data_Protection_Policy';
import * as footerActions from '../actions/common/Footer'
const mapStateToProps = (state, ownProps) => {
    //console.log('state',state.DataProtectionPolicy)
  return {
    how_we_make: state.Footer.makeThg
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getMakeThg : (data) => dispatch(footerActions.getMakeThg(data))
    //fetchPrivacyContents: (data) => dispatch(actions.getPrivacyContents(data)),
  }
};

const HowWeMakeTHG = connect(
  mapStateToProps,
  mapDispatchToProps,
)(HowWeMakeTHGComponent);

export default HowWeMakeTHG;

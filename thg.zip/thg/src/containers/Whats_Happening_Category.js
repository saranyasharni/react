import {connect} from 'react-redux'
import WhatsHappeningCategoryComponent from '../components/Whats_Happening_Category'
import * as actions from '../actions/Whats_Happening_Category';

const mapStateToProps = (state, ownProps) => {
  return {
    whatshappenArticleDetail: state.WhatsHappeningCategory.whatshappenArticleDetail,
    featuredEvents: state.WhatsHappeningCategory.featuredEvents,
    loading: state.WhatsHappeningCategory.loading

  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getWhatsHappenArticleDetail: (data) => dispatch(actions.whatsHappenArticleDetail(data)),
    getCategoryFeaturedEvents: (data) => dispatch(actions.getWhatsHappenFeaturedEvents(data)),
  }
};

const Whats_Happening_Category = connect(
  mapStateToProps,
  mapDispatchToProps,
)(WhatsHappeningCategoryComponent);

export default Whats_Happening_Category;

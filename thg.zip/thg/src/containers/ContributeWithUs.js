import {connect} from 'react-redux'
import ContributeWithUsComponent from '../components/ContributeWithUs'
import * as actions from '../actions/ContributeWithUs';

const mapStateToProps = (state, ownProps) => {
  return {
    fullName: state.ContributeWithUs.fullName,
    email: state.ContributeWithUs.email,
    mobileNo: state.ContributeWithUs.mobileNo,
    companyAddress: state.ContributeWithUs.companyAddress,
    interestOfChoosing: state.ContributeWithUs.interestOfChoosing,
    message: state.ContributeWithUs.message,
    contributeStatus: state.ContributeWithUs.contributeStatus,
    contributeErrors: state.ContributeWithUs.contributeErrors,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    updateContributeInfo: (f, e) => dispatch(actions.changeContributeInfo(f, e)),
    updateContributeStatus: (data) => dispatch(actions.changeContributeStatus(data)),
    resetContribute: (data) => dispatch(actions.resetContributeForm(data)),
    createContribute: (data) => dispatch(actions.contributeWithUs(data)),
    updateContributeErrors: (data) => dispatch(actions.changeContributeErrors(data)),
  }
};

const ContributeWithUs = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ContributeWithUsComponent);

export default ContributeWithUs;

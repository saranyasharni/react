import { connect } from 'react-redux'
import HeaderComponent from '../../components/common/Header'
import * as actions from '../../actions/common/Header';
import * as bucketactions from '../../actions/BucketList';
import * as onebucketactions from '../../actions/BucketListArticle';
import * as  sportactions from '../../actions/Sports';
// import { divide } from 'lodash';
// import { data } from 'jquery';
const mapStateToProps = (state, ownProps) => {
  return {
    email: state.Header.email,
    password: state.Header.password,
    confirmPassword: state.Header.confirmPassword,
    firstName: state.Header.firstName,
    lastName: state.Header.lastName,
    errors: state.Header.errors,
    success: state.Header.success,
    userDetails: state.Header.userDetails,
    loginEmail: state.Header.loginEmail,
    loginPassword: state.Header.loginPassword,
    bucketItem: state.Header.bucketItem,
    bucket_name: state.Header.bucket_name,
    bucketList: state.Header.bucketList,
    articleSuccess: state.Header.articleSuccess,
    articleError: state.Header.articleError,
    loginStatus: state.Header.loginStatus,
    registrationStatus: state.Header.registrationStatus,
    country: state.Header.country,
    temperature: state.Header.temperature,
    subCategoryList: state.Header.subCategoryList,
    sub_cat_list_esports:state.Header.sub_cat_list_esports,
    sub_cat_list_travel:state.Header.sub_cat_list_travel,
    sub_cat_list_review:state.Header.sub_cat_list_review,
    categoryList:state.Header.categoryList

  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    changeInput: (f, e) => dispatch(actions.inputChange(f, e)),
    changeBucketItem: (f, e) => dispatch(actions.bucketItemChange(f, e)),
    updateErrors: (data) => dispatch(actions.updateErrors(data)),
    createUser: (data) => dispatch(actions.createUser(data)),
    resetForm: (data) => dispatch(actions.resetForm(data)),
    loginUser: (data) => dispatch(actions.loginUser(data)),
    addArticleToBucket: (data) => dispatch(actions.addArticleToBucket(data)),
    removeArticleFromBucket: (data) => dispatch(actions.removeArticleFromBucket(data)),
    createBucket: (data) => dispatch(actions.createBucket(data)),
    getBucketListByUser: (data) => dispatch(actions.getBucketList(data)),
    changeArticleStatus: (data) => dispatch(actions.articleBucketStatus(data)),
    changeArticleErrorStatus: (data) => dispatch(actions.articleBucketErrorStatus(data)),
    addInterestedByUser: (data) => dispatch(actions.addInterestedByUser(data)),
    changeLoginStatus: (data) => dispatch(actions.loginStatus(data)),
    changeRegistrationStatus: (data) => dispatch(actions.registrationStatus(data)),
    changeRegistration: (data) => dispatch(actions.registration(data)),
    get3BucketList: (data) => dispatch(bucketactions.get3BucketList(data)),
    getArticleListByBucket: (data) => dispatch(onebucketactions.getArticleListByBucket(data)),
    getSubCategoryList: (data) => dispatch(actions.getSportsSubCategoryList(data)),
    getSubCategoryEsports: (data) => dispatch(actions.getEsportsSubCategoryList(data)),
    getSubCategoryTravel: (data) => dispatch(actions.getTravelSubCategoryList(data)),
    //getCategoryList: (data) => dispatch(actions.getCategoryList(data)),
    getFeaturedArticlesList: (data) => dispatch(sportactions.getFeaturedArticlesList(data)),
    getPopularArticlesList: (data) => dispatch(sportactions.getPopularArticlesList(data)),
    getSubCategoryReview : (data) => dispatch(actions.getSubCategoryReview(data)),
    getCategoryList : () => dispatch(actions.getMainCategory()),
  }
};

const Header = connect(
  mapStateToProps,
  mapDispatchToProps,
)(HeaderComponent);

export default Header;

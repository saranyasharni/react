import { connect } from 'react-redux'
import FooterComponent from '../../components/common/Footer'
import * as actions from '../../actions/common/Footer';

const mapStateToProps = (state, ownProps) => {
  return {
    quickLinks: state.Footer.quickLinks,
    ftr_fullName: state.Footer.fullName,
    ftr_email: state.Footer.email,
    subscribeFooterStatus: state.Footer.subscribeFooterStatus,
    subscribeFooterErrors: state.Footer.subscribeFooterErrors,
    categoryList:state.Header.categoryList
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getQuickLinks: () => dispatch(actions.getAllQuickLinks()),
    updateSubscribeFooterInfo: (f, e) => dispatch(actions.changeSubscribeFooterInfo(f, e)),
    updateSubscribeFooterStatus: (data) => dispatch(actions.changeSubscribeFooterStatus(data)),
    resetFooterSubscribe: (data) => dispatch(actions.resetFooterSubscribeForm(data)),
    createSubscribeFooter: (data) => dispatch(actions.footerSubscribeWithUs(data)),
    updateSubscribeFooterErrors: (data) => dispatch(actions.changeSubscribeFooterErrors(data)),
    //getAdvertiseWithUs : (data) => dispatch(actions.getAdvertiseWithUs(data)),
    //getPrivacyData : (data) => dispatch(actions.getPrivacyData(data)),
    //getReachUs : (data) => dispatch(actions.getReachUs(data)),
    getContribute : (data) => dispatch(actions.getContribute(data)),
   
  }
};

const Footer = connect(
  mapStateToProps,
  mapDispatchToProps,
)(FooterComponent);

export default Footer;

import { connect } from 'react-redux'
import NewsComponent from '../components/News'
import * as actions from '../actions/News';

const mapStateToProps = (state, ownProps) => {
  return {
    newsLatestArticlesList: state.News.newsLatestArticles,
    newsBannerList: state.News.newsBannerList,
    newsFeatureArticlesList: state.News.newsFeatureArticles,
    newsPopularArticlesList: state.News.newsPopularArticles,
    trendingList: state.News.trendingList,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // getLatestArticlesList: () => dispatch(actions.getLatestArticlesList()),
    // getNewsBannerList: () => dispatch(actions.getNewsBannerList()),
  }
};

const News = connect(
  mapStateToProps,
  mapDispatchToProps,
)(NewsComponent);

export default News;

import {connect} from 'react-redux'
import SubscribedEventListComponent from '../components/ProfileSection/SubscribedEventList'
import * as actions from '../actions/SubscribedEventList';

const mapStateToProps = (state, ownProps) => {
  return {
    // deleteStatus: state.YourArticles.deleteStatus,
    // pendingStatus: state.YourArticles.pendingStatus,
    subscribedEventList: state.subscribedEvent.subscribedEventList,
    subScriptionEventPageNo: state.subscribedEvent.subScriptionEventPageNo,
    // pendingArticlesList: state.YourArticles.pendingArticlesList,
    // draftArticlePageNo: state.YourArticles.draftArticlePageNo,
    // publishArticlePageNo: state.YourArticles.publishArticlePageNo,
    // pendingArticlePageNo: state.YourArticles.pendingArticlePageNo,
    articleMoreStatus: state.subscribedEvent.articleMoreStatus,
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // deleteArticleFromList: (data) => dispatch(actions.deleteArticle(data)),
    // updateArticle: (data) => dispatch(actions.moveToPending(data)),
    // updateDeleteStatus: (data) => dispatch(actions.deleteArticleStatus(data)),
    // updatePendingStatus: (data) => dispatch(actions.changePendingStatus(data)),
    getSubscribedEventList: (data) => dispatch(actions.getSubscribedEventList(data)),
    updateSubscriptionEventPageNo: (data) => dispatch(actions.updateSubscriptionEventPageNo(data)),
    moreSubscribedEventListAction: (data) => dispatch(actions.moreSubscribedEventListAction(data)),
    // getPublishArticlesList: (data) => dispatch(actions.publishArticles(data)),
    // moreDraftArticlesList: (data) => dispatch(actions.moreDraftArticles(data)),
    // morePublishArticlesList: (data) => dispatch(actions.morePublishArticles(data)),
    // morePendingArticlesList: (data) => dispatch(actions.morePendingArticles(data)),
    
    // updatePublishPageNo: (data) => dispatch(actions.updatePublishPageNo(data)),
    // updatePendingPageNo: (data) => dispatch(actions.updatePendingPageNo(data)),
    changeArticleMoreStatus: (data) => dispatch(actions.updateArticleMoreStatus(data)),
  }
};

const SubscribedEventList = connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubscribedEventListComponent);

export default SubscribedEventList;

import {connect} from 'react-redux'
import ReviewCategoryComponent from '../components/Review_Category'

const mapStateToProps = (state, ownProps) => {
  return {
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
  }
};

const Review_Category = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ReviewCategoryComponent);

export default Review_Category;

import { connect } from 'react-redux'
import BucketListArticleComponent from '../components/ProfileSection/BucketListArticle'
import * as actions from '../actions/BucketListArticle';
import * as headerActions from '../actions/common/Header';
import * as bucketactions from '../actions/BucketList';

const mapStateToProps = (state, ownProps) => {
  return {
    articleLists: state.BucketListArticle.articleLists,
    articleListPageno: state.BucketListArticle.articleListPageno,
    articleMoreStatus: state.BucketListArticle.articleMoreStatus,
    bucketItem: state.Header.bucketItem,
    editBucketStatus: state.BucketList.editBucketStatus,
    articleError: state.Header.articleError
  }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // changeBucketStatus:(data) => dispatch(actions.editBucketStatus(data)),
    getArticleListByBucket: (data) => dispatch(actions.getArticleListByBucket(data)),
    getMoreArticleListByBucket: (data) => dispatch(actions.fetchMoreArticleListByBucket(data)),
    updateArticleListPageNo: (data) => dispatch(actions.updateArticleListPageNo(data)),
    changeBucketItem: (f, e) => dispatch(headerActions.bucketItemChange(f, e)),
    changeBucketStatus:(data) => dispatch(bucketactions.editBucketStatus(data)),
    editBucket:(data) => dispatch(bucketactions.editBucket(data)),
    changeArticleMoreStatus: (data) => dispatch(actions.updateArticleMoreStatus(data)),
  }
};

const BucketListArticle = connect(
  mapStateToProps,
  mapDispatchToProps,
)(BucketListArticleComponent);

export default BucketListArticle;

import {connect} from 'react-redux'
import ContributeComponent from '../components/Contribute'
// import * as actions from '../actions/Data_Protection_Policy';
import * as Footeractions from '../actions/common/Footer';
const mapStateToProps = (state, ownProps) => {
    //console.log('state',state.DataProtectionPolicy)
    return {
        contribute: state.Footer.contribute
    }
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    getContribute : (data) => dispatch(Footeractions.getContribute(data)),
    //fetchPrivacyContents: (data) => dispatch(actions.getPrivacyContents(data)),
  }
};

const Contribute = connect(
  mapStateToProps,
  mapDispatchToProps,
)(ContributeComponent);

export default Contribute;

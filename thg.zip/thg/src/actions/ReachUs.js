import config from './common/Api_Links'

export const changeReachUsInfo = (field, value) => {
    return {
        type: 'CHANGE_REACHUS_INFO',
        field, value
    }
};

export const changeReachUsStatus = (data) => ({
    type: 'REACHUS_STATUS',
    data
});

export const resetReachUsForm = (data) => {
    return {
        type: 'RESET_REACHUS_FORM',
        data
    }
};

export const changeReachUsErrors = (data) => {
    return {
        type: 'UPDATE_REACHUS_ERRORS',
        data
    }
};

export const fetchReachUs = (data) => {
    const { fullName, email, mobileNo, message } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('full_name', fullName);   //append the values with key, value pair
    formData.append('email', email);
    formData.append('mobile', mobileNo);
    formData.append('message', message);
    return dispatch => {
        return fetch(config.create_reach_us, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changeReachUsStatus(1))
                } else {
                    dispatch(changeReachUsStatus(2))
                }
            })


    };
};
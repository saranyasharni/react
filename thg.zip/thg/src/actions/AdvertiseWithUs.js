import config from './common/Api_Links'

export const changeAdvertiseInfo = (field, value) => {
    return {
        type: 'CHANGE_ADVERTISE_INFO',
        field, value
    }
};

export const changeAdvertiseStatus = (data) => ({
    type: 'ADVERTISE_STATUS',
    data
});

export const resetAdvertiseForm = (data) => {
    return {
        type: 'RESET_ADVERTISE_FORM',
        data
    }
};

export const changeAdvertiseErrors = (data) => {
    return {
        type: 'UPDATE_ADVERTISE_ERRORS',
        data
    }
};

export const advertiseWithUs = (data) => {
    const { fullName, email, budget, companyAddress, timeline, message, objective } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('full_name', fullName);   //append the values with key, value pair
    formData.append('email', email);
    formData.append('budget', budget);   //append the values with key, value pair
    formData.append('company_address', companyAddress);
    formData.append('timeline', timeline);   //append the values with key, value pair
    formData.append('message', message);
    formData.append('objective', objective);
    return dispatch => {
        return fetch(config.advertise_with_us, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changeAdvertiseStatus(1))
                } else {
                    dispatch(changeAdvertiseStatus(2))
                }
            })


    };
};
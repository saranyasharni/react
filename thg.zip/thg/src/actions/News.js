import config from './common/Api_Links'

export const newsLatestArticlesList = (data, status) => ({
    type: 'NEWS_LATEST_ARTICLES_LIST',
    data,
    status
});

export const newsRecommendedArticlesList = (data, status) => ({
    type: 'NEWS_RECOMMENDED_ARTICLES_LIST',
    data,
    status
});

export const newsBannerList = (data, status) => ({
    type: 'NEWS_BANNER_LIST',
    data,
    status
});

export const newsFeatureArticlesList = (data, status) => ({
    type: 'NEWS_FEATURE_ARTICLES_LIST',
    data,
    status
});

export const setLoading = (data) => ({
    type: 'SET_LOADING',
    data
});

export const reelArticlesList = (data) => ({
    type: 'REEL_ARTICLES_LIST',
    data
});

export const THGTvList = (data) => ({
    type: 'THG_TV_LIST',
    data
});

export const newsPopularArticlesList = (data, status) => ({
    type: 'NEWS_POPULAR_ARTICLES_LIST',
    data,
    status
});

export const newsSportsCategoryList = (data) => ({
    type: 'NEWS_SPORTS_CATEGORY_LIST',
    data
});

export const newsESportsCategoryList = (data) => ({
    type: 'NEWS_ESPORTS_CATEGORY_LIST',
    data
});

export const newsTravelCategoryList = (data) => ({
    type: 'NEWS_TRAVEL_CATEGORY_LIST',
    data
});

export const newsReviewCategoryList = (data) => ({
    type: 'NEWS_REVIEW_CATEGORY_LIST',
    data
});

export const whatsHappeningList = (data) => ({
    type: 'WHATS_HAPPENING_LIST',
    data
});

export const coachListsHome = (data) => ({
    type: 'COACH_LISTS',
    data
});

export const trendingList = (data, status) => ({
    type: 'TRENDING_LISTS',
    data,
    status
});


export const getNewsLatestArticlesList = (data) => {
    const { user_id, page_no, limit, slug, filter_cat_id } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.latest_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(newsLatestArticlesList([]));
                if (responseData.status === 1) {
                    dispatch(newsLatestArticlesList(responseData.data, responseData.status));
                } else {
                    dispatch(newsLatestArticlesList([], responseData.status));
                }
            })


    };
};

export const getNewsBannerList = (data) => {
    const { user_id, page_no, limit, slug, filter_cat_id } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('slug', slug);
    return dispatch => {
        dispatch(setLoading(true))
        return fetch(config.feature_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                
                if (responseData.status === 1) {
                    document.title = responseData.data[0].post_title;                    
                    dispatch(newsBannerList(responseData.data, responseData.status));
                    dispatch(setLoading(false))
                } else {
                    
                    dispatch(newsBannerList([], responseData.status));
                    dispatch(setLoading(false))
                }
            })

    };
};

export const getTrendingList = () => {
    // const { user_id, page_no, limit } = data
    // let formData = new URLSearchParams();    //formdata object

    // formData.append('user_id', user_id);   //append the values with key, value pair
    // formData.append('page_no', page_no);
    // formData.append('limit', limit);
    return dispatch => {
        dispatch(setLoading(true))
        return fetch(config.trending_list, {
            method: 'POST',
            // body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(setLoading(false))
                    dispatch(trendingList(responseData.articleLists, responseData.status));
                } else {
                    dispatch(setLoading(false))
                    dispatch(trendingList([], responseData.status));

                }
            })


    };
};

export const getNewsFeatureArticlesList = (data) => {
    const { user_id, page_no, limit, filter_cat_id, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.feature_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(newsFeatureArticlesList([]));
                if (responseData.status === 1) {
                    dispatch(newsFeatureArticlesList(responseData.data, responseData.status));
                } else {
                    dispatch(newsFeatureArticlesList([], responseData.status));
                }
            })


    };
};

export const getNewsPopularArticlesList = (data) => {
    const { user_id, page_no, limit, slug, filter_cat_id } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('filter_cat_id', filter_cat_id);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.popular_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(newsPopularArticlesList([]));
                if (responseData.status === 1) {
                    dispatch(newsPopularArticlesList(responseData.data, responseData.status));
                } else {
                    dispatch(newsPopularArticlesList([], responseData.status));
                }
            })


    };
};

export const getNewsSportsCategoryList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newsSportsCategoryList(responseData.data));
                } else {
                    dispatch(newsSportsCategoryList([]));
                }
            })


    };
};

export const getNewsESportsCategoryList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newsESportsCategoryList(responseData.data));
                } else {
                    dispatch(newsESportsCategoryList([]));
                }
            })


    };
};

export const getNewsTravelCategoryList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newsTravelCategoryList(responseData.data));
                } else {
                    dispatch(newsTravelCategoryList([]));
                }
            })


    };
};

export const getNewsReviewCategoryList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newsReviewCategoryList(responseData.data));
                } else {
                    dispatch(newsReviewCategoryList([]));
                }
            })


    };
};

export const getWhatsHappeningList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.what_happening_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(whatsHappeningList(responseData.data));
                } else {
                    dispatch(whatsHappeningList([]));
                }
            })


    };
};

export const getReelArticlesList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(reelArticlesList(responseData.data));
                } else {
                    dispatch(reelArticlesList([]));
                }
            })


    };
};

export const getTHGTvList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    // formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(THGTvList(responseData.data));
                } else {
                    dispatch(THGTvList([]));
                }
            })


    };
};

export const getCoachList = (data) => {
    const { user_id, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.coach_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(coachListsHome(responseData.data))
                } else {
                    dispatch(coachListsHome([]))
                }
            })


    };
};



export const getNewsRecommendedArticlesList = (data) => {
    const { page_no, limit, slug, filter_cat_id } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.recommended_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(newsRecommendedArticlesList(data.data, data.status));
                } else {
                    dispatch(newsRecommendedArticlesList([], data.status));
                }
            })


    };
};


import config from './common/Api_Links'

export const changeContributeInfo = (field, value) => {
    return {
        type: 'CHANGE_CONTRIBUTE_INFO',
        field, value
    }
};

export const changeContributeStatus = (data) => ({
    type: 'CONTRIBUTE_STATUS',
    data
});

export const resetContributeForm = (data) => {
    return {
        type: 'RESET_CONTRIBUTE_FORM',
        data
    }
};

export const changeContributeErrors = (data) => {
    return {
        type: 'UPDATE_CONTRIBUTE_ERRORS',
        data
    }
};

export const contributeWithUs = (data) => {
    const { fullName, email, mobileNo, companyAddress, interest, message, user_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('full_name', fullName);   //append the values with key, value pair
    formData.append('email', email);
    formData.append('mobile', mobileNo);   //append the values with key, value pair
    formData.append('company_address', companyAddress);
    formData.append('interest', interest);   //append the values with key, value pair
    formData.append('message', message);
    formData.append('user_id', user_id);
    return dispatch => {
        return fetch(config.contribute_with_us, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changeContributeStatus(1))
                } else {
                    dispatch(changeContributeStatus(2))
                }
            })


    };
};
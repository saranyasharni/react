import config from './common/Api_Links'
import jQuery from 'jquery';


export const streamVideoDetails = (data) => ({
    type: 'STREAM_VIDEO_DETAIL',
    data
});

export const videoCommentsList = (data) => ({
    type: 'VIDEO_COMMENTS_LIST',
    data
});

 
export const relatedVideosList = (data) => ({
    type: 'RELATED_VIDEOS_LIST',
    data
});

export const latestVideosList = (data) => ({
    type: 'LATEST_VIDEOS_LIST',
    data
});
export const setLikedData = (data) => ({
    type: 'SET_LIKED_DATA',
    data
});

export const subCommentsList = (data) => ({
    type: 'SUB_COMMENTS_LIST',
    data
});

export const changeCommentReview = (field, value) => ({
    type: 'COMMENT_REVIEW',
    field, value
});


export const streamAuthorization = (data) => {
    // console.log(data, 'coming for strem')
    const { programme_id, event_id } = data;
    return dispatch => {
        // return fetch(config.stream_authorization, {
        //     method: 'POST',
        //     body: JSON.stringify({
        //         "email": "live2asia@espxmedia.com",
        //         "password": "espxLive2!1"
        //     }),
        //     headers: {
        //         "Content-type": "application/json; charset=UTF-8"
        //     }
        // })
            // .then(response => {
            //     if (response.status === 201) {
            //         return response.json();
            //     }
            // })
            // .then(data => {
                if (programme_id != '') {
                    dispatch(getAllCategories(data.token))
                    dispatch(getAllEpisodesList(data.token, event_id))
                    dispatch(getStreamVideoDetail({ 'token': data.token, 'programme_id': programme_id }));
                    dispatch(getVideoCommentsList({ 'program_id': programme_id }))
                }
            // })
    };
};


export const getStreamVideoDetail = (data) => {
    const { token, programme_id } = data;
    return dispatch => {
        return fetch(config.get_programmes_list + '?id =' + programme_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                // "Authorization": token
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log(responseData)
                if (responseData.data) {
                    if (responseData.data.length > 0) {
                        document.title = responseData.data[0] && 
                        responseData.data[0].name ? 
                        responseData.data[0].name : 'TheHomeGround'
                    }
                    dispatch(streamVideoDetails(responseData.data));
                } else {
                    dispatch(streamVideoDetails([]));
                }
                
            })


    };
};

export const getAllCategories = (token) => {
    return dispatch => {
        return fetch(config.get_categories_list, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                // "Authorization": token
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('categ', responseData.data.filter(item => { return item.name == "THG TV" })[0].id)
                // dispatch(getAllProgrammes(token, responseData.data.filter(item => { return item.name == "THG TV" })[0].id));
                dispatch(relatedVideosList([]));
                let eventsData = responseData.data.filter(item => { return item.name == "THG TV" })[0]
                if (eventsData) {
                    dispatch(relatedVideosList(eventsData['Events']));
                }
            })


    };
};

export const getAllEpisodesList = (token, event_id) => {
    // console.log(event_id, 'testevent_id for allepoi')
    return dispatch => {
        return fetch(config.get_event_programme_list + event_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                // "Authorization": token
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(latestVideosList([]));
                if (responseData && responseData.Programmes !== undefined
                    && responseData.Programmes !== ''
                    && responseData.Programmes !== null
                    ) {

                    dispatch(latestVideosList(responseData.Programmes));
                } else {
                    dispatch(latestVideosList([]));
                }
            })


    };
};

export const getAllProgrammes = (token, category_id) => {
    return dispatch => {
        return fetch(config.get_programmes_list + '?category_id =' + category_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                // "Authorization": token
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(relatedVideosList(responseData.data));
                dispatch(latestVideosList(responseData.data));
            })


    };
};

export const getProgrammeCommentsList = (data) => {
    const { token, programme_id } = data;
    return dispatch => {
        return fetch(config.get_programmecomments_list, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                // "Authorization": token
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('responseDAta', responseData)
            })


    };
};

export const getVideoCommentsList = (data) => {
    const { program_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('prg_id', program_id);
    return dispatch => {
        return fetch(config.live_stream_comments_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(videoCommentsList(responseData.data));
                } else {
                    dispatch(videoCommentsList([]));
                }
            })


    };
};

export const getSubCommentsList = (data) => {
    const { program_id, comment_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('parent_id', comment_id);
    formData.append('prg_id', program_id);
    return dispatch => {
        return fetch(config.live_stream_subcomments_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(subCommentsList(responseData.data));
                    jQuery('.loader-pro').removeClass('d-block')
                    jQuery('.loader-pro').addClass('d-none')
                } else {
                    dispatch(subCommentsList([]));
                    jQuery('.loader-pro').removeClass('d-block')
                    jQuery('.loader-pro').addClass('d-none')
                }
            })


    };
};

export const createComment = (data) => {
    const { user_id, program_id, author_name, email_id, author_ip, comment_content, rating_count } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('program_id', program_id);
    formData.append('user_id', user_id);
    formData.append('author_name', author_name);
    formData.append('email_id', email_id);
    formData.append('author_ip', author_ip);
    formData.append('comment_content', comment_content);
    return dispatch => {
        return fetch(config.create_comment_for_livestream, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getVideoCommentsList(data))
                    dispatch(changeCommentReview('commentStatus', 1));
                    dispatch(changeCommentReview('rating', 0));
                } else {
                    dispatch(changeCommentReview('commentStatus', 2));
                }
            })


    };
};

export const replyComment = (data) => {
    const { user_id, program_id, author_name, email_id, author_ip, comment_content, rating_count, comment_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('program_id', program_id);
    formData.append('user_id', user_id);
    formData.append('author_name', author_name);
    formData.append('email_id', email_id);
    formData.append('author_ip', author_ip);
    formData.append('comment_content', comment_content);
    formData.append('rating_count', rating_count);
    formData.append('parent_id', comment_id);
    return dispatch => {
        return fetch(config.create_sub_comment_for_livestream, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getSubCommentsList(data))
                    dispatch(changeCommentReview('replyCommentStatus', 1));
                    dispatch(changeCommentReview('rating', 0));
                } else {
                    dispatch(changeCommentReview('replyCommentStatus', 2));
                }
            })


    };
};
export const likeVideo = (data) => {
    const {article_id, user_id, liked} = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    formData.append('user_id', user_id);
    formData.append('liked', liked);
    
    return dispatch => {
        return fetch(config.stream_api_like, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
               
                if (responseData.status === 1) {
                    dispatch(getLikes({
                        article_id:article_id,
                        user_id:user_id
                    }))      
                } else {
                    
                }
            })


    };
};

export const getLikes = (data) => {
    const {article_id, user_id} = data;
    // console.log(data, 'getLikes')
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    formData.append('user_id', user_id);
    
    return dispatch => {
        return fetch(config.get_stream_api_like, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
              
                if (responseData.status === 1) {
                   if (responseData.data.length > 0 && responseData.data[0].userLiked === false) {
                       
                    responseData.data[0].userLiked = 'false'
                   } 
                   if (responseData.data.length > 0 && responseData.data[0].userLiked === true) {
                       
                    responseData.data[0].userLiked = 'true'
                   } 
                    dispatch(setLikedData(responseData.data))
                } else {
                    dispatch(setLikedData([]))
                }
            })


    };
};

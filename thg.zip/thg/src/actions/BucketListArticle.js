import config from './common/Api_Links'

export const articleLists = (data) => ({
    type: 'ARTICLE_LISTS',
    data
});

export const moreArticleLists = (data) => ({
    type: 'MORE_ARTICLE_LISTS',
    data
});

export const updateArticleListPageNo = (data) => ({
    type: 'UPDATE_ARTICLE_LIST_PAGE_NO',
    data
});

export const updateArticleMoreStatus = (data) => ({
    type: 'UPDATE_ARTICLE_MORE_STATUS',
    data
});

export const getArticleListByBucket = (data) => {
    const { user_id, bucket_id, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('bucket_id', bucket_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.get_article_from_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(articleLists(responseData.articleLists))
                } else {
                    dispatch(articleLists([]))
                }
            })


    };
};

export const fetchMoreArticleListByBucket = (data) => {
    const { user_id, bucket_id, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('bucket_id', bucket_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.get_article_from_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(moreArticleLists(responseData.articleLists))
                } else {
                    dispatch(moreArticleLists([]))
                }
            })


    };
};
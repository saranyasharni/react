import config from './common//Api_Links'
import jQuery from 'jquery';

var _ = require('lodash');

export const searchArticlesList = (data) => ({
    type: 'SEARCH_ARTICLES_LIST',
    data
});

export const updateSearchTerm = (data) => ({
    type: 'UPDATE_SEARCH_TERM',
    data
});

export const getSearchArticlesList = (data) => {
    const { search_term } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('search_term', search_term);
    return dispatch => {
        return fetch(config.search_article, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    window.jQuery('.search-bt').attr('disabled', false)
                    if (search_term) {
                        var uniqueUsersByID = _.uniqBy(responseData.result,'ID');
                        dispatch(searchArticlesList(uniqueUsersByID))
                    } else {
                        dispatch(searchArticlesList([]))
                    }

                } else {
                    window.jQuery('.search-bt').attr('disabled', false)
                    dispatch(searchArticlesList([]))
                }
            })


    };
};

import config from './common/Api_Links'


export const changeActivateStatus = (data) => ({
    type: 'ACTIVATE_STATUS',
    data
});

export const changeActivateInfo = (data) => ({
    type: 'ACTIVATE_INFO',
    data
});



export const activateDeactiveAccount = (data) => {
    const { user_id, activate_status } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('activate_status', activate_status);
    return dispatch => {
        return fetch(config.activate_deactivate_account, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('response', responseData)
                if (responseData.status === 1) {
                    dispatch(changeActivateInfo({ 'activateDeactivateSuccess': 1, 'activeStatus': activate_status }))
                } else {
                    dispatch(changeActivateInfo({ 'activateDeactivateSuccess': 2 }))
                }
            })


    };
};

export const removeAccount = (data) => {
    const { user_id } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    return dispatch => {
        return fetch(config.delete_account, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('response', responseData)
                if (responseData.status === 1) {
                    dispatch(changeActivateInfo({ 'removeAccountSuccess': 1 }))
                } else {
                    dispatch(changeActivateInfo({ 'removeAccountSuccess': 2 }))
                }
            })


    };
};
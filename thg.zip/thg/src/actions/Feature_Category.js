import config from './common/Api_Links'

export const reelBannerList = (data) => ({
    type: 'REEL_BANNER_LIST',
    data
});

export const reelChildArticles = (data) => ({
    type: 'REEL_CHILD_ARTICLES',
    data
});

export const newReelChildArticles = (data) => ({
    type: 'NEW_REEL_CHILD_ARTICLES',
    data
});

export const updateReelArticlePageNo = (data) => ({
    type: 'UPDATE_REEL_PAGE_NO',
    data
});


export const getReelChildBannerList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(reelBannerList(data.data));
                } else {
                    dispatch(reelBannerList([]));
                }
            })


    };
};

export const getReelChildArticlesList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(reelChildArticles(data.data));
                } else {
                    dispatch(reelChildArticles([]));
                }
            })


    };
};

export const getNewReelChildArticlesList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(newReelChildArticles(data.data));
                } else {
                    dispatch(newReelChildArticles([]));
                }
            })


    };
};
import config from './common/Api_Links'
var moment = require("moment");

export const topPicksList = (data) => ({
    type: 'TOP_PICKK_LIST',
    data
});

export const webSeriesList = (data) => ({
    type: 'WEB_SERIES_LIST',
    data
});

export const documentaryList = (data) => ({
    type: 'DOCUMENTARY_LIST',
    data
});

export const masterClassList = (data) => ({
    type: 'MASTER_CLASS_LIST',
    data
});

export const newMasterClassList = (data) => ({
    type: 'NEW_MASTER_CLASS_LIST',
    data
});

export const updatePageNo = (data) => ({
    type: 'UPDATE_PAGE_NO',
    data
});

export const updateArchiveStatus = (data) => ({
    type: 'UPDATE_ARCHIVE_STATUS',
    data
});

export const getTopPicksList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    document.title = data.data[0].post_title
                    dispatch(topPicksList(data.data));
                } else {
                    dispatch(topPicksList([]));
                }
            })


    };
};

export const getWebSeriesList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    if (data.data[0].video_duration) {
                        // var minutes = Math.floor(data.data[0].video_duration / 60);
                        data.data[0].video_duration = moment.duration(data.data[0].video_duration, "minutes").format();
                        //console.log(minutes, 'minutes')
                    }

                    //console.log(data.data, 'data.data90')
                    dispatch(webSeriesList(data.data));
                } else {
                    dispatch(webSeriesList([]));
                }
            })


    };
};

export const getDocumentaryList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    if (data.data[0].video_duration) {
                        // var minutes = Math.floor(data.data[0].video_duration / 60);
                        data.data[0].video_duration = moment.duration(data.data[0].video_duration, "minutes").format();
                        //console.log(minutes, 'minutes')
                    }
                    dispatch(documentaryList(data.data));
                } else {
                    dispatch(documentaryList([]));
                }
            })


    };
};

export const getMasterClassList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(masterClassList(data.data));
                } else {
                    dispatch(masterClassList([]));
                }
            })


    };
};

export const getMoreMasterClassList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(newMasterClassList(data.data));
                } else {
                    dispatch(newMasterClassList([]));
                }
            })


    };
};
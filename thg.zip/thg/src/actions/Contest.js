import config from './common/Api_Links'
import jQuery from 'jquery'
import moment from 'moment';
// import { setLoading } from './Home';

export const contestList = (data) => ({
    type: 'CONTEST_LIST',
    data
});

export const setLoading = (data) => ({
    type: 'SET_LOADING',
    data
});

export const bannerContestList = (data) => ({
    type: 'BANNER_CONTEST_LIST',
    data
});
export const setSubmission = (data) => ({
    type: 'SET_SUBMISSION',
    data
});

export const giveAwayDetail = (data) => ({
    type: 'GIVE_AWAY_DETAIL',
    data
})
export const newContestList = (data) => ({
    type: 'NEW_CONTEST_LIST',
    data
});

export const contestDetail = (data) => ({
    type: 'CONTEST_DETAIL',
    data
});

export const contestStatus = (data) => ({
    type: 'CONTEST_STATUS',
    data
});

export const updatePageNo = (data) => ({
    type: 'UPDATE_PAGE_NO',
    data
});

export const setNewAllSubmission = (data) => ({
    type: 'ALL_SUBMISSION',
    data
});

export const setApprovedSubmission = (data) => ({
    type: 'APPROVED_SUBMISSION',
    data
});

export const updateArchiveStatus = (data) => ({
    type: 'UPDATE_ARCHIVE_STATUS',
    data
});

export const updateErrors = (data) => {
    return {
        type: 'UPDATE_ERRORS',
        data
    }
};

export const inputChange = (field, value) => {
    return {
        type: 'INPUT_CHANGE',
        field, value
    }
};
export const setNewApprovedSubmission = (data) => {
    return {
        type: 'SET_NEW_APPROVED_SUB',
        data
    }
};


export const resetForm = (data) => {
    return {
        type: 'RESET_FORM',
        data
    }
};

export const giveAwayStatus = (data) => ({
    type: 'GIVEAWAY_STATUS',
    data
});

export const setProductDetail = (data) => ({
    type: 'SET_PRODUCT_DETAIL',
    data
});


export const getContestList = (data) => {
    const { page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.contest_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(contestList(data.result));
                } else {
                    dispatch(contestList([]));
                }
            })


    };
};

export const getNewContestList = (data) => {
    const { page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.contest_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(newContestList(data.result));
                } else {
                    dispatch(newContestList([]));
                }
            })


    };
};

export const getBannerContestList = (data) => {
    const { page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.get_featured_contest, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then(data => {
                dispatch(bannerContestList([]));
                if (data.status === 1) {
                    
                    dispatch(bannerContestList(data.result));
                } else {
                    dispatch(setLoading(true));
                    dispatch(bannerContestList([]));
                }
            })


    };
};

export const getContestDetail = (data) => {
    const { slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('post_id', slug);
    return dispatch => {
        return fetch(config.contest_detail, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                //console.log("getContestDetail","data",data)
                if (data.status === 1) {
                  //  if (data.result[0].start_date)
                    if (!data.result[0].start_date) {

                        data.result[0].start_date = new Date()
                    } 
                    if (!data.result[0].end_date) {
                        data.result[0]['submit_option'] = 0
                        data.result[0].end_date = new Date()
                    } else {
                        let dateFormat = moment(new Date(data.result[0].end_date)).format("YYYY-MM-DD")
                        let currentDateFormat = moment(new Date()).format("YYYY-MM-DD")
                        if (dateFormat < currentDateFormat) {
                            data.result[0]['submit_option'] = 1
                        }
                        

                    }
                    
                    dispatch(contestDetail(data.result));
                    
                } else {
                    dispatch(contestDetail([]));
                }
            })


    };
};

export const getGiveawayDetail = (data) => {
    
    const { slug } = data
    let formData = new URLSearchParams();    //formdata object
    formData.append('post_id', slug);
    return dispatch => {
        return fetch(config.get_givwaway_detail, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
            })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then(data => {
                if (data.status === 1) {
                    if (data.result.give_away_list.length > 0) {
                        var day = 1000*60*60*24;
                        let date1 = new Date(data.result.give_away_list[0].start_date);
                        let date2 = new Date(data.result.give_away_list[0].end_date);
                
                        var diff = (date2.getTime()- date1.getTime())/day;
                        let dateArr = [];
                        for(var i=0; i<=diff; i++) {
                           var xx = date1.getTime()+day*i;
                        //    console.log(xx, 'each date')
                           //var yy = new Date(xx)
                           let fullDate = moment(new Date(xx)).format("YYYY-MM-DD")
                           dateArr.push(fullDate);
                        }
                    //    console.log(dateArr, 'dateRange');
                        data.result.give_away_list.forEach((i,k) => {
                            if (i.end_date) {
                                let dateConverEnd =  new Date(i.end_date)
                                i.end_date = moment(dateConverEnd).format("YYYY-MM-DD")
                            }
    
                            if (i.start_date) {
                                let dateConverStart =  new Date(i.start_date)
                                i.start_date = moment(dateConverStart).format("YYYY-MM-DD")
                            }
                            
                            let currentDateFormat = moment(new Date()).format("YYYY-MM-DD")
                           // data.result.give_away_list[k]['current_date'] = currentDateFormat
                           data.result.give_away_list[k]['pro_date'] = dateArr[k]
                        //    console.log(dateArr[k], 'dateArr[k]')
                        //    console.log(currentDateFormat, 'currentDateFormat')
                            if (dateArr[k] < currentDateFormat) {
                                data.result.give_away_list[k]['product_availability'] = 'closed'
                            } else if (dateArr[k] > currentDateFormat) {
                                //console.log('not came')
                                data.result.give_away_list[k]['product_availability'] = 'upcoming'
                            } else {
                                
                                data.result.give_away_list[k]['product_availability'] = 'open'
                            }
                           
                        });
                        
                    }
                   
                    // console.log(data.result.give_away_list[0].end_date, 'i.end_date')
                    // console.log(data.result.give_away_list[0].start_date, 'i.start_date')
                    //console.log(data.result, 'data.result')
                    dispatch(giveAwayDetail(data.result));
                } else {
                    dispatch(giveAwayDetail([]));
                }
            })


    };
};

export const createGiveAway = (data) => {
    const { user_id, contest_id, contest_name } = data
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('contest_id', contest_id);
    formData.append('contest_name', contest_name);
    formData.append('product_name', data.product_name);
    formData.append('first_name', data.first_name);
    formData.append('last_name', data.last_name);
    formData.append('dob', data.dob);
    formData.append('email', data.email);
    formData.append('mobile', data.mobile);
    formData.append('occupation', data.occupation);
    formData.append('monthly_income', data.monthly_income);
    
    return dispatch => {
        return fetch(config.give_away, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(contestStatus(1));
                    window.jQuery('#success-pop').modal('show')
                } else {
                    dispatch(contestStatus(2));
                }
            })
    };
};

export const createSubmitEntry = (data) => {
    const { user_id, contest_id, contest_name, image_url, first_name,
    last_name,dob,email,mobile_no,occupation,monthly_income,photos_desc,
    } = data
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('contest_id', contest_id);
    formData.append('contest_name', contest_name);
    formData.append('image_url', image_url);
    formData.append('first_name', first_name);
    formData.append('last_name', last_name);
    formData.append('dob', dob);
    formData.append('email', email);
    formData.append('mobile', mobile_no);
    formData.append('occupation', occupation);
    formData.append('monthly_income', monthly_income);
    formData.append('description', photos_desc);
    formData.append('file_type', data.type)
    return dispatch => {
        return fetch(config.submit_entry, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();

            }
        })
        .then(data => {
            if (data.status === 1) {
                window.jQuery('#success-pop').modal('show')
                dispatch(contestStatus(1));
            } else {
                dispatch(contestStatus(2));
            }
        })
    };
};

export const uploadContestImage = (data) => {
    const { upload_file } = data;
    let formData = new FormData();
    formData.append('upload_file', upload_file);
    return dispatch => {
        return fetch(config.profile_upload_to_s3_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    jQuery('.contest-loader-pro').removeClass('d-block')
                    jQuery('.contest-loader-pro').addClass('d-none')
                    jQuery('.upload-drag').addClass('d-block')
                    jQuery('.upload_icon_contest').addClass('d-none')
                    if (data.typeFile === 'image') {
                        jQuery('.upload-drag').find('.thumb_video').removeClass('d-inblock')
                        jQuery('.upload-drag').find('.thumb_video').addClass('d-inblock')
                        jQuery('.upload-drag').find('.thumb_video').attr('src', '')
                        jQuery('.upload-drag').find('.thumb_image').addClass('d-inblock')
                        jQuery('.upload-drag').find('.thumb_image').removeClass('d-none')
                        jQuery('.upload-drag').find('.thumb_image').attr('src', URL.createObjectURL(upload_file))
                    } else {
                        jQuery('.upload-drag').find('.thumb_image').removeClass('d-inblock')
                        jQuery('.upload-drag').find('.thumb_image').addClass('d-none')
                        jQuery('.upload-drag').find('.thumb_image').attr('src', '')
                        jQuery('.upload-drag').find('.thumb_video').addClass('d-inblock')
                        jQuery('.upload-drag').find('.thumb_video').removeClass('d-none')
                        jQuery('.upload-drag').find('.thumb_video').attr('src', URL.
                        createObjectURL(upload_file))
                    }
                    
                    dispatch(resetForm({ imageUrl: responseData.file_links_data[0].original_data, fileType: data.typeFile}))
                } else {
                    // dispatch(changeProfileStatus(3))
                }
            })


    };
};

export const getGiveAwayStatus = (data) => {
    const { user_id } = data
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id);   //append the values with key, value pair
    return dispatch => {
        return fetch(config.give_away_status, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then((data={}) => {
                let {status=""}=data
                if (status === 1) {
                    dispatch(giveAwayStatus(data.result));
                } else {
                    dispatch(giveAwayStatus({}));
                }
                
            })
    };
};

export const productDetail = (data) => {
    
 //   console.log(data, 'setProductDetail()')
    let formData = new URLSearchParams();    //formdata object
    formData.append('post_id', data.post_id);   //append the values with key, value pair
    formData.append('parent_id', data.slug);
    formData.append('day', data.day);
    return dispatch => {
        return fetch(config.get_giveaway_product_detail, {

            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
    
                dispatch(setProductDetail([]));
                if (data.status === 1) {
                    if (data.result.relatedProducts > 0 ) {
                        var day = 1000*60*60*24;
                    
                    let date1 = new Date(data.result.relatedProducts[0].start_date);
                    let date2 = new Date(data.result.relatedProducts[0].end_date);
            
                    var diff = (date2.getTime()- date1.getTime())/day;
                    let dateArr = [];
                    for(var i=0; i<=diff; i++) {
                       var xx = date1.getTime()+day*i;
                       var yy = new Date(xx);
                       let fullDate = yy.getFullYear()+"-"+(yy.getMonth()+1)+"-"+yy.getDate()
                       dateArr.push(fullDate);
                    }
                    //console.log(dateArr, 'dateRange');
                    data.result.relatedProducts.forEach((i,k) => {
                        if (i.end_date) {
                            let dateConverEnd =  new Date(i.end_date)
                            i.end_date = moment(dateConverEnd).format("YYYY-MM-DD")
                        }

                        if (i.start_date) {
                            let dateConverStart =  new Date(i.start_date)
                            i.start_date = moment(dateConverStart).format("YYYY-MM-DD")
                        }
                        
                        let currentDateFormat = moment(new Date()).format("YYYY-MM-DD")
                       // data.result.give_away_list[k]['current_date'] = currentDateFormat
                       data.result.relatedProducts[k]['pro_date'] = dateArr[k]
                        if (dateArr[k] >= currentDateFormat) {
                            data.result.relatedProducts[k]['product_availability'] = 'opened'
                        } else {
                            data.result.relatedProducts[k]['product_availability'] = 'closed'
                        }
                       
                    });
                    } 
                    
                    
                    // console.log(data.result.give_away_list[0].end_date, 'i.end_date')
                    // console.log(data.result.give_away_list[0].start_date, 'i.start_date')
                    //console.log(data.result, 'data.result')
                    dispatch(setProductDetail(data.result));
                } else {
                    dispatch(setProductDetail([]));
                }
            })


    };
};

export const getNewAllsubmisson = (data) => {
    
    //   console.log(data, 'setProductDetail()')
        let formData = new URLSearchParams();    //formdata object
        formData.append('post_id',localStorage.getItem('cotest_slug'));
        formData.append('page_no', data.page_no);
        formData.append('limit', data.limit); 
        return dispatch => {
           return fetch(config.get_all_contest_submissions, {
               method: 'POST',
               body: formData,
               headers: {
                   "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                   "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
               }
           })
               .then(response => {
                   if (response.status === 200) {
                       return response.json();
   
                   }
               })
               .then(data => {
                   //dispatch(setProductDetail([]));
                   if (data.status === 1) {
                      //console.log(data.result , 'data.result78')
                       dispatch(setNewAllSubmission(data.result));
                   } else {
                       dispatch(setNewAllSubmission([]));
                   }
               })
   
   
       };
};

export const allSubmission = (data) => {
    //   console.log(data, 'setProductDetail()')
        let formData = new URLSearchParams();    //formdata object
        formData.append('post_id', data.post_id)
        formData.append('page_no', data.page_no);
        formData.append('limit', data.limit); 
        return dispatch => {
           return fetch(config.get_all_contest_submissions, {
               method: 'POST',
               body: formData,
               headers: {
                   "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                   "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
               }
           })
               .then(response => {
                   if (response.status === 200) {
                       return response.json();
   
                   }
               })
               .then(data => {
                    //dispatch(setProductDetail([]));
                    if (data.status === 1) {
                        //console.log(data.result , 'data.result78')    
                        dispatch(setSubmission(data.result));
                    } else {
                       dispatch(setSubmission([]));
                    }
               })
   
       };
   };

   export const getApprovedsubmisson = (data) => {

        let formData = new URLSearchParams();    //formdata object
        formData.append('post_id',localStorage.getItem('cotest_slug'));
        formData.append('page_no', data.page_no);
        formData.append('limit', data.limit); 
        return dispatch => {
           return fetch(config.get_approved_submissions, {
               method: 'POST',
               body: formData,
               headers: {
                   "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                   "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
               }
           })
               .then(response => {
                   if (response.status === 200) {
                       return response.json();
   
                   }
               })
               .then(data => {
                  // dispatch(setProductDetail([]));
                   if (data.status === 1) {
                    //   console.log(data.result , 'data.result78')
                       dispatch(setApprovedSubmission(data.result));
                   } else {
                       dispatch(setApprovedSubmission([]));
                   }
               })
   
   
       };
   };

   export const getNewApproSubmisson = (data) => {

    let formData = new URLSearchParams();    //formdata object
    formData.append('post_id',localStorage.getItem('cotest_slug'));
    formData.append('page_no', data.page_no);
    formData.append('limit', data.limit); 
    return dispatch => {
       return fetch(config.get_approved_submissions, {
           method: 'POST',
           body: formData,
           headers: {
               "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
               "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
           }
        })
           .then(response => {
               if (response.status === 200) {
                   return response.json();

               }
            })
           .then(data => {
               //dispatch(setProductDetail([]));
               if (data.status === 1) {
                 // console.log(data.result , 'data.result78')
                   dispatch(setNewApprovedSubmission(data.result));
               } else {
                   dispatch(setNewApprovedSubmission([]));
               }
           })
   };
};


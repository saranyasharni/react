import config from './common/Api_Links'

export const latestArticleList = (data) => ({
    type: 'LATEST_ARTICLE_LIST',
    data
});

export const newLatestArticleList = (data, status) => ({
    type: 'NEW_LATEST_ARTICLE_LIST',
    data,
    status
});

export const featuredArticleList = (data) => ({
    type: 'FEATURED_ARTICLE_LIST',
    data
});

export const popularArticleList = (data) => ({
    type: 'POPULAR_ARTICLE_LIST',
    data
});

export const eSportsCategoryList = (data) => ({
    type: 'ESPORTS_CATEGORY_LIST',
    data
});

export const travelCategoryList = (data) => ({
    type: 'TRAVEL_CATEGORY_LIST',
    data
});

export const reviewCategoryList = (data) => ({
    type: 'REVIEW_CATEGORY_LIST',
    data
});

export const updatePageNo = (data) => ({
    type: 'UPDATE_PAGE_NO',
    data
});
export const show_hide = (data) => ({
    type: 'SHOW_HIDE',
    data
});
export const highlightsArticles = (data) => ({
    type: 'HIGH_LIGHTS_LIST',
    data
});

export const updateArticleVideoStatus = (data) => ({
    type: 'UPDATE_ARTICLE_VIDEO_STATUS',
    data
});


export const getCategoryList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);

    formData.append('limit', limit);

    formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    if (localStorage.categories) {
                        window
                          .jQuery(`.${localStorage.getItem("categories")}-nav `)
                          .addClass("active");
                      }
                    dispatch(latestArticleList(responseData.data));
                } else {
                    dispatch(latestArticleList([]));
                }
            })


    };
};

export const getNewCategoryList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newLatestArticleList(responseData.data));
                } else {
                    dispatch(newLatestArticleList([]), responseData.status);
                }
            })


    };
};

export const getFeaturedArticlesList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.feature_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(featuredArticleList([]));
                if (responseData.status === 1) {
                    document.title = responseData.data[0].post_title;
                    dispatch(featuredArticleList(responseData.data));
                } else {
                    dispatch(featuredArticleList([]));
                }
            })


    };
};

export const getNewFeaturedArticlesList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.feature_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(featuredArticleList(responseData.data));
                } else {
                    dispatch(featuredArticleList([]));
                }
            })


    };
};

export const getPopularArticlesList = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    formData.append('location', data.location);
    formData.append('filter_name', data.filter_name);
    formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.popular_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(popularArticleList(responseData.data));
                } else {
                    dispatch(popularArticleList([]));
                }
            })


    };
};

export const getHighLightsArticles = (data) => {
    const { user_id, page_no, slug, limit, filter_cat_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    formData.append('filter_cat_id', filter_cat_id);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(highlightsArticles(data.data));
                } else {
                    dispatch(highlightsArticles([]));
                }
            })


    };
};


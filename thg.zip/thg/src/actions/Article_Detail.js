/** @format */

import config from "./common/Api_Links";
import jQuery from "jquery";
import { getRecommendedArticlesList } from "./Home";

export const articleDetails = (data, status) => ({
  type: "ARTICLE_DETAIL",
  data,
  status
});
export const setLoading = (data) => ({
  type: 'SET_LOADING',
  data
});
export const nextArticleDetails = (data) => ({
  type: "NEXT_ARTICLE_DETAIL",
  data,
});

export const updateDesignState = (data) => ({
  type: "UPDATE_DESIGN_STATE",
  data,
});

export const articleDetailsRelated = (data,status) => ({
  type: "ARTICLE_DETAIL_RELATED",
  data,
  status
});

export const fea_articleDetailsRelated = (data) => ({
  type: "FEA_ARTICLE_DETAIL_RELATED",
  data,
});
export const sportsSubCategoryList = (data) => ({
  type: "SPORTS_SUB_CATEGORY_LIST",
  data,
});

export const commentsList = (data) => ({
  type: "COMMENTS_LIST",
  data,
});

export const subCommentsList = (data) => ({
  type: "SUB_COMMENTS_LIST",
  data,
});

export const changeCommentReview = (field, value) => ({
  type: "COMMENT_REVIEW",
  field,
  value,
});

export const overList = (field, value) => ({
  type: "OVER_LIST",
  field,
  value,
});

export const getArticleDetail = (data) => {
  
  const { user_id, page_no, limit, slug } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("user_id", user_id); //append the values with key, value pair
  formData.append("page_no", page_no);
  formData.append("limit", limit);
  formData.append("slug", slug);
  return (dispatch) => {
    dispatch(setLoading(true));
    return fetch(config.article_detail, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        
        if (responseData.status === 1) {
          // alert()
          if (responseData.data && responseData.data.length > 0) {
            //console.log(responseData.data, 'responseData.data')
                          
              
            let result_related = responseData.data;
            document.title = result_related[0] && 
            result_related[0].post_title ? 
            result_related[0].post_title : 'TheHomeGround'
            // result_related[0]['relatedArticles'] = [];
            dispatch(articleDetails(result_related), responseData.status);
            
            dispatch(getCommentsList({ article_id: responseData.data.ID }));
            if (localStorage.categories) {
              window
                .jQuery(`.${localStorage.getItem("categories")}-nav `)
                .addClass("active");
            }
            dispatch(setLoading(false));
            // dispatch(getRecommendedArticles({
            //   article_id:responseData.data[0].ID,
            //   cat_id:responseData.data[0].cat_ids,
            //   img_url :responseData.data[0].image_url
            // }))

          } else {
            dispatch(articleDetails([]), responseData.status);
            dispatch(setLoading(false));
          }
        }
      });
  };
};


export const getFeatureArticleDetail = (data) => {
  
  const { user_id, page_no, limit, slug } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("user_id", user_id); //append the values with key, value pair
  formData.append("page_no", page_no);
  formData.append("limit", limit);
  formData.append("slug", slug);
  formData.append("post_type", "feat_event_art")
  return (dispatch) => {
    //dispatch(setLoading(true));
    return fetch(config.article_detail, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        dispatch(articleDetails([]));
        if (responseData.status === 1) {
          if (responseData.data.length > 0 ) {
            // dispatch(getFeatureRelatedArticles({
            //   article_id:responseData.data[0].ID,
            //   cat_id:responseData.data[0].cat_ids,
            //   img_url :responseData.data[0].image_url
            // }))
            document.title = responseData.data[0] && 
            responseData.data[0].post_title ? 
            responseData.data[0].post_title : 'TheHomeGround'
            dispatch(articleDetails(responseData.data));
            
            dispatch(getCommentsList({ article_id: responseData.data[0].ID }));
            if (localStorage.categories) {  
              window
                .jQuery(`.${localStorage.getItem("categories")}-nav `)
                .addClass("active");
            }
            // dispatch(getRecommendedArticles('d'))
          }
        }
      });
  };
};
export const getFeatureRelatedArticles = (data) => {
  
  let formData = new URLSearchParams(); //formdata object
  formData.append("ID", data.article_id); //append the values with key, value pair
  formData.append("cat_ids", data.cat_id);
  formData.append("image_url", data.image_url ? data.image_url : '');
  formData.append("page_no", 0);
  formData.append("limit", 12);
  formData.append("post_type", "feat_event_art");
  
  return (dispatch) => {
    //dispatch(setLoading(true));
    return fetch(config.recommended_articles_detail, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        
        if (response.status === 200) {
        
          return response.json();
        }
      })
      .then((responseData) => {
        dispatch(fea_articleDetailsRelated([]));
        if (responseData.status === 1) {
          
          dispatch(fea_articleDetailsRelated(responseData.data.relatedArticles));
      //    dispatch(setLoading(false));
        } else {
          dispatch(fea_articleDetailsRelated([]));
        }
      });
  };
};

export const getRecommendedArticles = (data) => {  
  let formData = new URLSearchParams(); //formdata object
  formData.append("ID", data.article_id); //append the values with key, value pair
  formData.append("cat_ids", data.cat_id);
  formData.append("image_url", data.image_url ? data.image_url : '');
  formData.append("page_no", 0);
  formData.append("limit", 12);
  
  return (dispatch) => {
    //dispatch(setLoading(true));
    return fetch(config.recommended_articles_detail, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        
        if (response.status === 200) {
        
          return response.json();
        }
      })
      .then((responseData) => {
        dispatch(articleDetailsRelated([]));
        if (responseData.status === 1) {
        
          dispatch(articleDetailsRelated(responseData.data.relatedArticles, responseData.status));
      //    dispatch(setLoading(false));
        } else {
          dispatch(articleDetailsRelated([]));
        }
      });
    };
  };
  
export const getDraftArticleDetail = (data) => {
  const { user_id, page_no, limit, slug } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("user_id", user_id); //append the values with key, value pair
  formData.append("page_no", page_no);
  formData.append("limit", limit);
  formData.append("slug", slug);
  return (dispatch) => {
    return fetch(config.edit_article_detail, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        dispatch(articleDetails([]));
        if (responseData.status === 1) {
          if (responseData.data.length > 0 && responseData.data[0].cat_name) {
            dispatch(articleDetails(responseData.data));
            let subSlug = responseData.data[0].cat_name
              .split(",")[0]
              .toLowerCase();
            dispatch(getCommentsList({ article_id: responseData.data[0].ID }));
            if (localStorage.category) {
              window
                .jQuery(`.${localStorage.getItem("category")}-nav `)
                .removeClass("active");
            }
            // dispatch(sportsSubCategoryList([]));
            // dispatch(
            //   getSportsSubCategoryList({
            //     user_id,
            //     page_no,
            //     limit,
            //     slug: subSlug,
            //   })
            // );
          }
        }
      });
  };
};

export const getNextArticleDetail = (data) => {
  const { user_id, page_no, limit, slug } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("user_id", user_id); //append the values with key, value pair
  formData.append("page_no", page_no);
  formData.append("limit", limit);
  formData.append("slug", slug);
  return (dispatch) => {
    return fetch(config.article_detail, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        if (responseData.status === 1) {
          if (responseData.data.length > 0 && responseData.data[0].cat_name) {
            dispatch(nextArticleDetails(responseData.data));
            let subSlug = responseData.data[0].cat_name
              .split(",")[0]
              .toLowerCase();
            dispatch(getCommentsList({ article_id: responseData.data[0].ID }));
            //dispatch(sportsSubCategoryList([]));
            // dispatch(
            //   getSportsSubCategoryList({
            //     user_id,
            //     page_no,
            //     limit,
            //     slug: subSlug,
            //   })
            // );
          }
        }
      });
  };
};

export const getCommentsList = (data) => {
  const { article_id } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("article_id", article_id);
  return (dispatch) => {
    return fetch(config.get_comments_for_article, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        if (responseData.status === 1) {
          var rate = responseData.data;
          // console.log("threat1", rate);
          var total = 0;
          rate.map((item, i) => {
            total = total + Number(item.rating);
          });
          var over = total / responseData.data.length;
          // console.log("threatss", over);
          localStorage.setItem("over", over);
          dispatch(overList("overList", over));
          dispatch(commentsList(responseData.data));
        } else {
          dispatch(commentsList([]));
        }
      });
  };
};

export const getSubCommentsList = (data) => {
  const { comment_id } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("parent_id", comment_id);
  return (dispatch) => {
    return fetch(config.subcomments_list, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        if (responseData.status === 1) {
          dispatch(subCommentsList(responseData.data));
          jQuery(".loader-pro").removeClass("d-block");
          jQuery(".loader-pro").addClass("d-none");
        } else {
          dispatch(subCommentsList([]));
          jQuery(".loader-pro").removeClass("d-block");
          jQuery(".loader-pro").addClass("d-none");
        }
      });
  };
};


export const getSportsSubCategoryList = (data) => {
  const { user_id, page_no, slug } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("user_id", user_id); //append the values with key, value pair
  formData.append("page_no", page_no);
  formData.append("slug", slug);
  return (dispatch) => {
    dispatch(sportsSubCategoryList([]));
    return fetch(config.sub_category_list, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        if (responseData.status === 1) {
          // localStorage.setItem(
          //   "category",
          //   responseData.data[0].name.toLowerCase()
          // );
          // window
          //   .jQuery(`.${responseData.data[0].name.toLowerCase()}-nav `)
          //   .addClass("active");
          // let responseSubcategory;
          // let sportsCategory = [{ parent_id: 5, name: "Sports", child_id: 14, sub_category: "Athletics", slug: "athletics" },
          // { parent_id: 5, name: "Sports", child_id: 20, sub_category: "Netball", slug: "netball" },
          // { parent_id: 5, name: "Sports", child_id: 22, sub_category: "Football", slug: "football" },
          // { parent_id: 5, name: "Sports", child_id: 30, sub_category: "Sailing", slug: "sailing" }]
          // let esportsCategory = [{ parent_id: 24, name: "Esports", child_id: 122, sub_category: "Games", slug: "games" },
          // { parent_id: 24, name: "Esports", child_id: 123, sub_category: "People", slug: "people" },
          // { parent_id: 24, name: "Esports", child_id: 125, sub_category: "Events", slug: "events" }]
          // if (responseData.data[0].name.toLowerCase() == 'sports') {
          //     responseSubcategory = sportsCategory;
          // } else if (responseData.data[0].name.toLowerCase() == 'esports') {
          //     responseSubcategory = esportsCategory;
          // } else {
          //     responseSubcategory = responseData.data;
          // }

          dispatch(sportsSubCategoryList(responseData.data));
        } else {
           dispatch(sportsSubCategoryList([]));
        }
      });
  };
};
export const createComment = (data) => {
  const {
    user_id,
    article_id,
    author_name,
    email_id,
    author_ip,
    comment_content,
    rating_count,
  } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("article_id", article_id);
  formData.append("user_id", user_id);
  formData.append("author_name", author_name);
  formData.append("email_id", email_id);
  formData.append("author_ip", author_ip);
  formData.append("comment_content", comment_content);
  formData.append("rating_count", rating_count);
  return (dispatch) => {
    return fetch(config.create_comment, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        if (responseData.status === 1) {
          dispatch(getCommentsList(data));
          dispatch(changeCommentReview("commentStatus", 1));
          dispatch(changeCommentReview("rating", 0));
        } else {
          dispatch(changeCommentReview("commentStatus", 2));
        }
      });
  };
};

export const replyComment = (data) => {
  const {
    user_id,
    article_id,
    author_name,
    email_id,
    author_ip,
    comment_content,
    rating_count,
    comment_id,
  } = data;
  let formData = new URLSearchParams(); //formdata object

  formData.append("article_id", article_id);
  formData.append("user_id", user_id);
  formData.append("author_name", author_name);
  formData.append("email_id", email_id);
  formData.append("author_ip", author_ip);
  formData.append("comment_content", comment_content);
  formData.append("rating_count", rating_count);
  formData.append("parent_id", comment_id);
  return (dispatch) => {
    return fetch(config.create_sub_comment, {
      method: "POST",
      body: formData,
      headers: {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
      },
    })
      .then((response) => {
        if (response.status === 200) {
          return response.json();
        }
      })
      .then((responseData) => {
        if (responseData.status === 1) {
          dispatch(getSubCommentsList(data));
          dispatch(changeCommentReview("replyCommentStatus", 1));
          dispatch(changeCommentReview("rating", 0));
        } else {
          dispatch(changeCommentReview("replyCommentStatus", 2));
        }
      });
  };
};

import config from './common/Api_Links'

export const updatePrivacyContents = (data) => ({
    type: 'PRIVACY_CONTENTS',
    data
});

export const updateTermsContents = (data) => ({
    type: 'TERMS_CONTENTS',
    data
});

export const getPrivacyContents = (data) => {
    const { page_slug } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', page_slug); 
    return dispatch => {
        return fetch(config.privacy_policy, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(updatePrivacyContents(responseData.data))
                } else {
                    dispatch(updatePrivacyContents([]))
                }
            })


    };
};

export const getTermsContents = (data) => {
    const { page_slug } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', page_slug); 
    return dispatch => {
        return fetch(config.privacy_policy, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(updateTermsContents(responseData.data))
                } else {
                    dispatch(updateTermsContents([]))
                }
            })


    };
};
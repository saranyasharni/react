import config from './common/Api_Links'

export const deleteArticleStatus = (data) => ({
    type: 'DELETE_STATUS',
    data
});

export const draftArticleList = (data) => ({
    type: 'DRAFT_ARTICLES',
    data
});

export const pendingArticleList = (data) => ({
    type: 'PENDING_ARTICLES',
    data
});

export const publishArticleList = (data) => ({
    type: 'PUBLISH_ARTICLES',
    data
});

export const updateDraftPageNo = (data) => ({
    type: 'UPDATE_DRAFT_PAGE_NO',
    data
});

export const updatePublishPageNo = (data) => ({
    type: 'UPDATE_PUBLISH_PAGE_NO',
    data
});

export const updatePendingPageNo = (data) => ({
    type: 'UPDATE_PENDING_PAGE_NO',
    data
});

export const moreDraftArticleList = (data) => ({
    type: 'MORE_DRAFT_ARTICLES',
    data
});

export const morePublishArticleList = (data) => ({
    type: 'MORE_PUBLISH_ARTICLES',
    data
});

export const morePendingArticleList = (data) => ({
    type: 'MORE_PENDING_ARTICLES',
    data
});

export const changePendingStatus = (data) => ({
    type: 'CHANGE_PENDING_STATUS',
    data
});

export const updateArticleMoreStatus = (data) => ({
    type: 'UPDATE_ARTICLE_MORE_STATUS',
    data
});

export const deleteArticle = (data) => {
    const { article_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    return dispatch => {
        return fetch(config.delete_article, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(draftArticles({ user_id: (localStorage.user_id) ? localStorage.getItem('user_id') : 0, page_no: 0, limit: 4, post_status: 'draft' }))
                    dispatch(pendingArticles({ user_id: localStorage.getItem('user_id'), page_no: 0, limit: 4, post_status: 'pending' }))
                    dispatch(deleteArticleStatus(1))
                } else {
                    dispatch(deleteArticleStatus(2))
                }
            })


    };
};

export const draftArticles = (data) => {
    const { user_id, page_no, limit, post_status } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.your_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(draftArticleList(responseData.articleLists))
                } else {
                    dispatch(draftArticleList([]))
                }
            })


    };
};

export const pendingArticles = (data) => {
    const { user_id, page_no, limit, post_status } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.your_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(pendingArticleList(responseData.articleLists))
                } else {
                    dispatch(pendingArticleList([]))
                }
            })


    };
};

export const publishArticles = (data) => {
    const { user_id, page_no, limit, post_status } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.your_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(publishArticleList(responseData.articleLists))
                } else {
                    dispatch(publishArticleList([]))
                }
            })


    };
};

export const moreDraftArticles = (data) => {
    const { user_id, page_no, limit, post_status } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.your_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(moreDraftArticleList(responseData.articleLists))
                }
            })


    };
};

export const morePublishArticles = (data) => {
    const { user_id, page_no, limit, post_status } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.your_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(morePublishArticleList(responseData.articleLists))
                }
            })


    };
};

export const morePendingArticles = (data) => {
    const { user_id, page_no, limit, post_status } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.your_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(morePendingArticleList(responseData.articleLists))
                }
            })


    };
};

export const moveToPending = (data) => {
    const { article_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    return dispatch => {
        return fetch(config.update_article, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changePendingStatus(1))
                    dispatch(draftArticles({ user_id: localStorage.getItem('user_id'), page_no: 0, limit: 4, post_status: 'draft' }))
                    dispatch(pendingArticles({ user_id: localStorage.getItem('user_id'), page_no: 0, limit: 4, post_status: 'pending' }))
                } else {
                    dispatch(changePendingStatus(2))
                }
            })


    };
};
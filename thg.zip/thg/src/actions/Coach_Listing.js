import config from './common//Api_Links'

export const coachLists = (data) => ({
    type: 'COACH_LIST',
    data
});

export const newCoachLists = (data) => ({
    type: 'NEW_COACH_LIST',
    data
});

export const updateCoachPageNo = (data) => ({
    type: 'UPDATE_COACH_PAGE_NO',
    data
});

export const updateCoachDetails = (data) => ({
    type: 'UPDATE_COACH_DETAILS',
    data
});

export const updateCoachSearch = (data) => ({
    type: 'UPDATE_COACH_SEARCH',
    data
});

export const getCoachList = (data) => {
    const { user_id, page_no, limit, search_term } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('search_term', search_term);
    return dispatch => {
        return fetch(config.coach_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    let response = responseData.data;
                    response.forEach((item, i) => {
                        let field = item.user_extra_field_name.split(',')
                        let values = item.user_extra_values.split(',')
                        response[i] = { ...item, phone_no: (field.indexOf('Phone Number') != -1) ? values[field.indexOf('Phone Number')] : '', location: (field.indexOf('Location') != -1) ? values[field.indexOf('Location')] + ',' + values[field.indexOf('Location') + 1] : '', profession: (field.indexOf('Profession') != -1) ? values[field.indexOf('Profession')] : '' }
                    })
                    dispatch(coachLists(response))
                } else {
                    dispatch(coachLists([]))
                }
            })


    };
};

export const getNewCoachList = (data) => {
    const { user_id, page_no, limit, search_term } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('search_term', search_term);
    return dispatch => {
        return fetch(config.coach_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newCoachLists(responseData.data))
                } else {
                    dispatch(newCoachLists([]))
                }
            })


    };
};
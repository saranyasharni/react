import config from './common/Api_Links'

export const changeSubscribeInfo = (field, value) => {
    return {
        type: 'CHANGE_SUBSCRIBE_INFO',
        field, value
    }
};

export const changeSubscribeStatus = (data) => ({
    type: 'SUBSCRIBE_STATUS',
    data
});

export const resetSubscribeForm = (data) => {
    return {
        type: 'RESET_SUBSCRIBE_FORM',
        data
    }
};

export const changeSubscribeErrors = (data) => {
    return {
        type: 'UPDATE_SUBSCRIBE_ERRORS',
        data
    }
};

// export const freqList = (data) => {
//     return {
//         type: 'FREQ_LIST',
//         data
//     }
// };

export const subscribeWithUs = (data) => {
    const { firstName, lastName, email, frequency, notify_topics } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('first_name', firstName);   //append the values with key, value pair
    formData.append('last_name', lastName);   //append the values with key, value pair
    formData.append('email', email);
    formData.append('frequency', frequency);
    formData.append('notify_topics', notify_topics);

    return dispatch => {
        return fetch(config.subscribe, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changeSubscribeStatus(1))
                } else if (responseData.status === 0) {
                    dispatch(changeSubscribeStatus(2))
                } else {
                    dispatch(changeSubscribeStatus(3))
                }
            })


    };
};
// export const getFrequencyList = (data) => {

//     return dispatch => {
//         return fetch(config.get_frequency_list, {
//             method: 'POST',
//             headers: {
//                 "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
//                 "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
//             }
//         })
//             .then(response => {
//                 if (response.status === 200) {
//                     return response.json();

//                 }
//             })
//             .then(responseData => {
//                 if (responseData.status === 1) {
//                     let list_data = responseData.data;
//                     let list_data_arr = list_data.filter(function(item) {
                        
//                         if (item.value_name === 'Weekly Once') {
                           
//                             item.value_name = 'Weekly'
//                         }
//                         return item.value_name !== 'Three Days Once'
//                     })
//                     // console.log(list_data_arr, 'TTTTTTTTT')
//                     dispatch(freqList(list_data_arr))
//                 }
//             })


//     };
// };
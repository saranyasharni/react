import config from './common/Api_Links'
import history from "./../stores/history";
import jQuery from 'jquery';
export const latestArticlesList = (data) => ({
    type: 'LATEST_ARTICLES_LIST',
    data
});

export const latestPhotosList = (data) => ({
    type: 'LATEST_PHOTOS_LIST',
    data
});

export const setEventData = (data) => ({
    type: 'SET_EVENT_DATA',
    data
})

export const setRelatedVideos = (data) => ({
    type: 'SET_RELATED_VIDEOS',
    data
});

export const setEventId = (data) => ({
    type: 'SET_EVENT_ID',
    data
});

export const featuredEventVideosList = (data) => ({
    type: 'FEATURED_EVENT_VIDEOS_LIST',
    data
});

export const setPlayVideo = (data) => ({
    type: 'PLAY_VIDEO',
    data
});

export const featureBannerList = (data) => ({
    type: 'FEATURE_BANNER_LIST',
    data
});

export const updateMonthAndYear = (data) => ({
    type: 'UPDATE_MONTH_YEAR',
    data
});

export const setMonthAndYear = (data) => ({
    type: 'SET_MONTH_YEAR',
    data
});


export const setCalendarEvents = (data) => ({
    type: 'SET_CALENDAR_EVENTS',
    data
});

export const eventCategoryList = (data) => ({
    type: 'EVENT_CATEGORY_LIST',
    data
});

export const setPurchaseTicket = (data) => ({
    type: 'PURCHASE_TICKET',
    data
});

export const setLiveStreamVideos = (data) => ({
    type: 'LIVE_STREAM_VIDEOS',
    data
})

export const setStreamingVideo = (data) => ({
    type: 'SET_STREAM',
    data
})

export const subscribeEvent = (data) => {
    
    const { user_id, event_id } = data
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id);
    formData.append('event_id', event_id);
    return dispatch => {
        return fetch(config.event_subscription, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })

        .then(response => {
            if (response.status === 200) {
                
                return response.json();

            }
        })

        .then(responseData => {
            
            if (responseData.status === 1) {
                
                localStorage.setItem('subscription', JSON.stringify({
                    subscribed_event_id :event_id,
                    subscribed:'1',
                    subscribed_user_id:user_id
                }))

                // setTimeout(function () {
                    window.location.reload()
                // }, 2000)
            } else {
                // dispatch(latestArticlesList([]));
            }
        })

        .catch((err) => {
            console.log(err, 'error_cateched')
        })
    };
}

export const getLatestArticlesList = (data) => {
    const { user_id, page_no, limit, event_id } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('event_id', event_id);
    return dispatch => {
        return fetch(config.event_feature_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then(responseData => {
                dispatch(latestArticlesList([]));
                if (responseData.status === 1) {
                    dispatch(latestArticlesList(responseData.result));
                } else {
                    dispatch(latestArticlesList([]));
                }
            })
    };
};

export const getFeaturedEventsBanner = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.feature_event_banner, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })

            .then(responseData => {
                if (responseData.status === 1) {
                    if (localStorage.categories) {
                        window
                          .jQuery(`.${localStorage.getItem("categories")}-nav `)
                          .addClass("active");
                    }
                    if (responseData.result.length > 0) {
                        document.title = responseData.result[0].post_title
                        dispatch(featureBannerList(responseData.result));
                        history.push(`/category/featured-events/${responseData.result[0].post_name}`)   
                       
                        if (responseData.result[0].live_stream === 'Yes') {
                            dispatch(getAllCategories(responseData.result[0].live_stream, responseData.result[0].event_amount, responseData.result[0].plan_subscribed, responseData.result[0].category_field_url))
                        }

                        dispatch(getLatestArticlesList({ user_id, page_no, limit: 12, event_id: responseData.result[0].ID }));
                        dispatch(getLatestPhotosList({ page_no, limit: 7, event_id: responseData.result[0].ID }));
                        dispatch(getLatestVideosList({ page_no, limit: 5, event_id: responseData.result[0].ID }));
                        dispatch(setEventId(responseData.result[0].ID));
                        dispatch(setPurchaseTicket(responseData.result[0].purchase_ticket_link));
                    } else {
                        dispatch(featureBannerList([]));
                    }
                } else {
                    dispatch(featureBannerList([]));
                }
            })
    };
};

export const getAllCategories = (live_stream, event_amount, subscribed, category_field_url) => {
    
    if (category_field_url === null || category_field_url === '') {
        category_field_url = "THG Feature Events"
    }
    
    return dispatch => {
        return fetch(config.get_categories_list, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",        
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })

            .then(responseData => {
                
                if (responseData.data) {
                    let eventsData = responseData.data.filter(item => { return item.name === category_field_url })[0]

                    if (eventsData && eventsData.Programmes) {
    
                        eventsData.Programmes.map((i,k) => {
                        
                            i['subscribed'] = subscribed
                            i['live_stream'] = live_stream
                            i['event_amount'] = event_amount
                        })
                        // eventsData['Programmes']['paid'] = subscribed
                        // eventsData['Programmes']['live_stream'] = live_stream
                        // eventsData['Programmes']['event_amount'] = event_amount
                           
                    }
                    // console.log(eventsData.Programmes, 'eventsData')
                    if (eventsData) {
                        dispatch(setLiveStreamVideos(eventsData.Programmes));
                    } else {
                        dispatch(setLiveStreamVideos([]));
                    }
                    
                }
                
            })
    };
};

export const getStreamVideos = (episodeId) => {

    return dispatch => {
        return fetch(config.get_categories_list+'/'+episodeId, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                // console.log(data, 'livestremviedostest')
                if (data) {
                    dispatch(setLiveStreamVideos(data.Programmes));
                } else {
                    dispatch(setLiveStreamVideos([]));
                }
            })

    };
}

export const getRelatedVideos = (input) => {
    
    return dispatch => {
        return fetch(config.get_categories_list+'/5d13c430-e382-43ee-a2e7-2346b08457fc', {
            method: 'GET',
            
            headers: {
                "Content-type": "application/json; charset=UTF-8",
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                // console.log(data, 'livestremviedostest')
                if (data) {
                    let dispatch_arr = []
                    data.Programmes.map(i => {
                        // console.log(input.article_id, 'kkkkkkk')
                        // console.log(i.id, 'kkkkkkk90')
                        if (i.id !== input.article_id) {
                            // alert('came')
                            dispatch_arr.push(i)
                        }
                    })
                    // console.log(dispatch_arr, 'dispatch_arr')
                    dispatch(setRelatedVideos(dispatch_arr));
                } else {
                    dispatch(setRelatedVideos([]));
                }
            })


    };
}

export const streamVideo = (data) => {
    // alert('fff')
    return dispatch => {
        return fetch(config.get_programmes_list+'/'+data.programme_id, {
            method: 'GET',
            
            headers: {
                "Content-type": "application/json; charset=UTF-8",
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                // console.log(data, 'livestremviedostest')
                if (data) {
                    document.title = data && 
                    data.name ? 
                    data.name : 'TheHomeGround'
                    dispatch(setStreamingVideo([data]));
                } else {
                    dispatch(setStreamingVideo([]));
                }
            })


    };
}

export const getCalendarEvents = (data) => {
    
    const { category_id, year, month, event_id} = data
    let formData = new URLSearchParams();    //formdata object

    //formData.append('category_id', category_id);   //append the values with key, value pair
    formData.append('year', year);
    // formData.append('month', month);
    formData.append('event_id', event_id)
    return dispatch => {
        return fetch(config.calendar_event_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(setCalendarEvents(data.data));
                } else {
                    dispatch(setCalendarEvents([]));
                }
            })


    };
};

export const getEventCategoryList = () => {

    return dispatch => {
        return fetch(config.event_category_list, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(setMonthAndYear({ category_id: responseData.data[0].term_id }))
                    dispatch(eventCategoryList(responseData.data))
                } else {
                    dispatch(eventCategoryList(responseData.data))
                }
            })


    };
};

export const getLatestPhotosList = (data) => {
    const { page_no, limit, event_id } = data
    let formData = new URLSearchParams();    //formdata objec

    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('event_id', event_id);

    return dispatch => {
        return fetch(config.feature_event_photos, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(latestPhotosList(responseData.result));
                } else {
                    dispatch(latestPhotosList([]));
                }
            })


    };
};

export const getLatestVideosList = (data) => {
    let user_id = localStorage.user_id  ? localStorage.getItem('user_id') : 0;
    const { page_no, limit, event_id } = data
    let formData = new URLSearchParams();    //formdata objec
    // console.log(user_id, 'user_id')
    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('event_id', event_id);
    return dispatch => {
        return fetch(config.feature_event_videos, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(featuredEventVideosList([]));
                if (responseData.status === 1) {
                    dispatch(featuredEventVideosList(responseData.result));
                } else {
                    dispatch(featuredEventVideosList([]));
                }
            })
    };
};

export const getEventDetail = (data) => {
    let user_id = localStorage.user_id  ? localStorage.getItem('user_id') : 0;
    
    let formData = new URLSearchParams();    //formdata objec
    // console.log(user_id, 'user_id')
    formData.append('user_id', user_id);
    
    formData.append('event_id', data);
    return dispatch => {
        return fetch(config.get_event_detail, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                
                if (responseData.status === 1) {
                    dispatch(setEventData(responseData.result));
                } else {
                    dispatch(setEventData([]));
                }
            })
    };
};
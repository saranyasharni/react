import config from './common/Api_Links'

export const featuredEventList = (data) => ({
    type: 'FEATURED_EVENT_LIST',
    data
});

export const whatsHappenbannerList = (data) => ({
    type: 'WHATS_HAPPEN_BANNER_LIST',
    data
});

export const upcomingEventList = (data) => ({
    type: 'UPCOMING_EVENT_LIST',
    data
});

export const moreUpcomingEventList = (data) => ({
    type: 'MORE_UPCOMING_EVENT_LIST',
    data
});


export const moreOngoingEventsList = (data) => ({
    type: 'MORE_ONGOING_EVENTS_LIST',
    data
});

export const changeShowStatusPast = (data) => ({
    type: 'MORE_STATUS_LIST_PAST',
    data
});

export const ongoingEventsList = (data) => ({
    type: 'ONGOING_EVENTS_LIST',
    data
});

export const updateUpcomingEventNo = (data) => ({
    type: 'UPCOMING_EVENT_NO',
    data
});

export const updateOngoingEventNo = (data) => ({
    type: 'ONGOING_EVENT_NO',
    data
});

export const updateArticleMoreStatus = (data) => ({
    type: 'UPDATE_ARTICLE_MORE_STATUS',
    data
});

export const changeShowStatus = (data) => ({
    type: 'UPDATE_SHOW_HIDE_STATUS',
    data
});

export const updateDateValue = data => ({
    type: "UPDATE_VALUE",
    data
});

export const catFilterList = data => ({
    type: "CATEGORY_FILTER_LIST",
    data
});

export const updateFilterBy = data => ({
    type: "UPDATE_FILTER_BY",
    data
});

export const setdateArray = data => ({
    type: "SET_DATE_ARRAY",
    data
});

export const SetLoading = data => ({
    type: "SET_LOADING",
    payload: data
});

export const getFeaturedEvents = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        
        return fetch(config.what_happening_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    
                    data.data.forEach((e, j) => {
                        let start_date = e.start_date_and_time;
                        let end_date = e.end_date_and_time;
                        if (start_date.length > 0) {
                            start_date.forEach((element, i) => {
                                if (end_date[i] !== '') {
                                    start_date[i] = element+ ' - ' + end_date[i];
                                } else {
                                    
                                    start_date[i] = element
                                }
                            });
                        }
                        
                        e.start_date_and_time = start_date ? start_date : new Date();
                    });
                    dispatch(featuredEventList(data.data));
                } else {
                    dispatch(featuredEventList([]));
                }
            })


    };
};

export const getWhatsHappenBanner = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.what_happening_banners, {
            method: 'POST',
            //body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                dispatch(whatsHappenbannerList([]));
                if (data.status === 1) {
                    document.title = data.data[0].post_title
                    dispatch(whatsHappenbannerList(data.data));
                } else {
                    dispatch(whatsHappenbannerList([]));
                }
            })


    };
};

export const getUpcomingEvents = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        
        return fetch(config.upcoming_events, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    let date_array = [];
                    data.data.forEach((e, j) => {
                        //console.log(e.start_date_and_time[0].split(" ")[0], 'dateArray')
                        //e.end_date_and_time[0].split(" ")
                        date_array.push(e.start_date_and_time[0].split(" ")[0])
                        let start_date = e.start_date_and_time;
                        let end_date = e.end_date_and_time;
                        if (start_date.length > 0) {
                            start_date.forEach((element, i) => {
                                if (end_date[i] !== '') {
                                    start_date[i] = element.replace(' ', '/') + ' - ' + end_date[i].replace(' ', '/');
                                } else {
                                    start_date[i] = element 
                                }
                            });
                        }
                        e.start_date_and_time = start_date ? start_date : new Date();
                    });
                    //console.log(dateAray, 'dateAray')
                    //dispatch(setdateArray(date_array))
                    dispatch(upcomingEventList(data.data));
                    dispatch(SetLoading(false));
                } else {
                    dispatch(upcomingEventList([]));
                }
            })
    };
};

export const getEventDates = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        
        return fetch(config.upcoming_events, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    let date_array = [];
                    data.data.forEach((e, j) => {
                        
                        date_array.push(e.start_date_and_time[0].split(" ")[0])
                        
                    });
                    //console.log(date_array, 'dateAray')
                    dispatch(setdateArray(date_array))
                    
                } else {
                    dispatch(setdateArray([]));
                }
            })
    };
};

export const getMoreUpcomingEvents = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return  fetch(config.upcoming_events, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    let date_array = [];
                    data.data.forEach((e, j) => {
                        //console.log(e.start_date_and_time[0].split(" ")[0], 'dateArray')
                        //e.end_date_and_time[0].split(" ")
                        date_array.push(e.start_date_and_time[0].split(" ")[0])
                        let start_date = e.start_date_and_time;
                        let end_date = e.end_date_and_time;
                        if (start_date.length > 0) {
                            start_date.forEach((element, i) => {
                                if (end_date[i]) {
                                    if (Date.parse(start_date[i] === end_date[i])) {
                                        //start_date[i] = element.replace(' ', '/')
                                    } else {
                                        start_date[i] = element.replace(' ', '/') + ' - ' + end_date[i].replace(' ', '/');
                                    }
                                    
                                }
                            });
                        }
                        e.start_date_and_time = start_date ? start_date : new Date();
                    });
                    dispatch(moreUpcomingEventList(data.data));
                    
                } else {
                    dispatch(moreUpcomingEventList([]));
                }
            })
    };
};

export const getUpcomingEventsFilter = (data) => {
    const { date, slug_name, month, filter_by, limit, page_no} = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('filter_by', filter_by);   //append the values with key, value pair
    formData.append('slug', slug_name);
    formData.append('month', month);
    formData.append('date', date);
    formData.append('limit', limit);
    formData.append('page_no', page_no);

    return dispatch => {
        return fetch(config.upcoming_events_month_filter, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    responseData.data.forEach((e, j) => {
                        let start_date = e.start_date_and_time;
                        let end_date = e.end_date_and_time;
                        if (start_date.length > 0) {
                            start_date.forEach((element, i) => {
                                if (end_date[i] !== '') {
                                    start_date[i] = element.replace(' ', '/') + ' - ' + end_date[i].replace(' ', '/');
                                } else {
                                    start_date[i] = element
                                }
                            });
                        }
                        //console.log(start_date, 'deff')
                        e.start_date_and_time = start_date ? start_date : new Date();
                    });
                    dispatch(upcomingEventList(responseData.data));
                } else {
                    dispatch(upcomingEventList([]));
                }
            })


    };
};

export const getMoreUpcomingEventsFilter = (data) => {
    const { date,filter_by, slug_name, month, limit, page_no} = data
    //console.log(data, 'more filter')
    let formData = new URLSearchParams();    //formdata object

    formData.append('filter_by', filter_by);   //append the values with key, value pair
    formData.append('slug', slug_name);
    formData.append('month', month);
    formData.append('date', date);
    formData.append('limit', limit);
    formData.append('page_no', page_no);
    
    return dispatch => {
        return fetch(config.upcoming_events_month_filter, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    data.data.forEach((e, j) => {
                        let start_date = e.start_date_and_time;
                        let end_date = e.end_date_and_time;
                        if (start_date.length > 0) {
                            start_date.forEach((element, i) => {
                                if (end_date[i] !== '') {
                                    start_date[i] = element.replace(' ', '/') + ' - ' + end_date[i].replace(' ', '/');
                                } else {
                                    start_date[i] = element
                                }
                            });
                        }
                        //console.log(start_date, 'deff')
                        e.start_date_and_time = start_date ? start_date : new Date();
                    });
                    dispatch(moreUpcomingEventList(data.data));
                } else {
                    dispatch(moreUpcomingEventList([]));
                }
            })


    };
};

export const getOngoingEvents = (data) => {

    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.ongoing_events, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    // console.log(responseData.data, 'responseData.data')
                  
                    dispatch(ongoingEventsList(responseData.data));
                } else {
                    dispatch(ongoingEventsList([]));
                }
            })


    };
};

export const getMoreOngoingEvents = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.ongoing_events, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                   
                    dispatch(moreOngoingEventsList(data.data));
                } else {
                    dispatch(moreOngoingEventsList([]));
                }
            })


    };
};

export const getUpcomingCategoryList = () => {
    return dispatch => {
        return fetch(config.upcoming_category_list, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(catFilterList(responseData.categoryLists));
                } else {
                    dispatch(catFilterList([]));
                }
            })


    };
};
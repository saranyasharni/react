import config from './common/Api_Links'
import jQuery from 'jquery';

export const videoArticleDetails = (data) => ({
    type: 'VIDEO_ARTICLE_DETAIL',
    data
});

export const videoCommentsList = (data) => ({
    type: 'VIDEO_COMMENTS_LIST',
    data
});

export const relatedVideosList = (data) => ({
    type: 'RELATED_VIDEOS_LIST',
    data
});

export const latestVideosList = (data) => ({
    type: 'LATEST_VIDEOS_LIST',
    data
});

export const subCommentsList = (data) => ({
    type: 'SUB_COMMENTS_LIST',
    data
});

export const changeCommentReview = (field, value) => ({
    type: 'COMMENT_REVIEW',
    field, value
});

export const getVideoArticleDetail = (data) => {
    const { user_id, page_no, limit, slug } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        dispatch(videoArticleDetails([]));
        dispatch(relatedVideosList([]));
        if (localStorage.categories) {  
            window
              .jQuery(`.${localStorage.getItem("categories")}-nav `)
              .addClass("active");
        }
        return fetch(config.article_detail, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();

            }
        })
        .then(responseData => {
            if (responseData.status === 1) {
                if (responseData.data.length > 0) {
                    document.title = responseData.data[0] && 
                    responseData.data[0].post_title ? 
                    responseData.data[0].post_title : 'TheHomeGround'
                }
                dispatch(videoArticleDetails(responseData.data));
                dispatch(relatedVideosList(responseData.data[0].relatedArticles));
                dispatch(getVideoCommentsList({ article_id: responseData.data[0].ID }))

            } else {
                dispatch(videoArticleDetails([]));
                dispatch(relatedVideosList([]));
                dispatch(getVideoCommentsList([]))
            }
        })


    };
};

export const getVideoCommentsList = (data) => {
    const { article_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    return dispatch => {
        return fetch(config.get_comments_for_article, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(videoCommentsList(responseData.data));
                } else {
                    dispatch(videoCommentsList([]));
                }
            })


    };
};

export const getSubCommentsList = (data) => {
    const { comment_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('parent_id', comment_id);
    return dispatch => {
        return fetch(config.subcomments_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(subCommentsList(responseData.data));
                    jQuery('.loader-pro').removeClass('d-block')
                    jQuery('.loader-pro').addClass('d-none')
                } else {
                    dispatch(subCommentsList([]));
                    jQuery('.loader-pro').removeClass('d-block')
                    jQuery('.loader-pro').addClass('d-none')
                }
            })


    };
};

export const getLatestVideoArticles = (data) => {
    const { user_id, page_no, limit, slug } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                dispatch(latestVideosList([]));
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                        dispatch(latestVideosList(responseData.data));

                } else {
                    dispatch(latestVideosList([]));
                }
            })


    };
};

export const createComment = (data) => {
    const { user_id, article_id, author_name, email_id, author_ip, comment_content, rating_count } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    formData.append('user_id', user_id);
    formData.append('author_name', author_name);
    formData.append('email_id', email_id);
    formData.append('author_ip', author_ip);
    formData.append('comment_content', comment_content);
    formData.append('rating_count', rating_count);
    return dispatch => {
        return fetch(config.create_comment, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getVideoCommentsList(data))
                    dispatch(changeCommentReview('commentStatus', 1));
                    dispatch(changeCommentReview('rating', 0));
                } else {
                    dispatch(changeCommentReview('commentStatus', 2));
                }
            })


    };
};

export const replyComment = (data) => {
    const { user_id, article_id, author_name, email_id, author_ip, comment_content, rating_count, comment_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    formData.append('user_id', user_id);
    formData.append('author_name', author_name);
    formData.append('email_id', email_id);
    formData.append('author_ip', author_ip);
    formData.append('comment_content', comment_content);
    formData.append('rating_count', rating_count);
    formData.append('parent_id', comment_id);
    return dispatch => {
        return fetch(config.create_sub_comment, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getSubCommentsList(data))
                    dispatch(changeCommentReview('replyCommentStatus', 1));
                    dispatch(changeCommentReview('rating', 0));
                } else {
                    dispatch(changeCommentReview('replyCommentStatus', 2));
                }
            })


    };
};
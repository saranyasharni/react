import config from './common/Api_Links'

export const latestArticlesList = (data, status) => ({
    type: 'LATEST_ARTICLES_LIST',
    data,
    status
});

export const recommendedArticlesList = (data, status) => ({
    type: 'RECOMMENDED_ARTICLES_LIST',
    data,
    status
});

export const setLoading = (data) => ({
    type: 'SET_LOADING',
    data
});

export const bannerList = (data) => ({
    type: 'BANNER_LIST',
    data
});

export const featureArticlesList = (data) => ({
    type: 'FEATURE_ARTICLES_LIST',
    data
});

export const reelArticlesList = (data) => ({
    type: 'REEL_ARTICLES_LIST',
    data
});

export const THGTvList = (data) => ({
    type: 'THG_TV_LIST',
    data
});

export const popularArticlesList = (data) => ({
    type: 'POPULAR_ARTICLES_LIST',
    data
});

export const sportsCategoryList = (data) => ({
    type: 'SPORTS_CATEGORY_LIST',
    data
});

export const eSportsCategoryList = (data) => ({
    type: 'ESPORTS_CATEGORY_LIST',
    data
});

export const travelCategoryList = (data) => ({
    type: 'TRAVEL_CATEGORY_LIST',
    data
});

export const reviewCategoryList = (data) => ({
    type: 'REVIEW_CATEGORY_LIST',
    data
});

export const exclusiveCategoryList = (data) => ({
    type: 'EXCLUSIVE_CATEGORY_LIST',
    data
});

export const whatsHappeningList = (data) => ({
    type: 'WHATS_HAPPENING_LIST',
    data
});

export const coachListsHome = (data) => ({
    type: 'COACH_LISTS',
    data
});

export const trendingList = (data,status) => ({
    type: 'TRENDING_LISTS',
    data,
    status
});

export const getLatestArticlesList = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', '');
    return dispatch => {
        return fetch(config.latest_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                dispatch(latestArticlesList([]));
                if (data.status === 1) {
                    dispatch(latestArticlesList(data.data, data.status));
                } else {
                    dispatch(latestArticlesList([], data.status));
                }
            })
    };
};

export const getRecommendedArticlesList = (data) => {
    const { page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', '');
    return dispatch => {
        return fetch(config.recommended_articles, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(recommendedArticlesList(data.data, data.status));
                } else {
                    dispatch(recommendedArticlesList([], data.status));
                }
            })


    };
};

export const getBannerList = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', '');
    return dispatch => {
        dispatch(setLoading(true))
        return fetch(config.feature_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();

            }
        })
        .then(data => {
            dispatch(bannerList([]));
            if (data.status === 1) {
                dispatch(bannerList(data.data, data.status));
            } else {
                dispatch(bannerList([], data.status));
            }
        })
    };
};

export const getTrendingList = () => {
    document.title = "TheHomeGround Asia – Latest and trending news and events happening around Asia. Delving deeper to better explain stories. Letting readers voice their opinions. Watch events live.";
    return dispatch => {
        return fetch(config.trending_list, {
            method: 'POST',
            // body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(setLoading(false))
                    dispatch(trendingList(responseData.articleLists, responseData.status));
                } else {
                    dispatch(trendingList([], responseData.status));

                }
            })
    };
};

export const getFeatureArticlesList = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', '');
    return dispatch => {
        dispatch(featureArticlesList([]));
        return fetch(config.feature_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(featureArticlesList(data.data));
                } else {
                    dispatch(featureArticlesList([]));
                }
            })


    };
};

export const getPopularArticlesList = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.popular_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(popularArticlesList([]));
                if (responseData.status === 1) {
                    dispatch(popularArticlesList(responseData.data));
                } else {
                    dispatch(popularArticlesList([]));
                }
            })


    };
};
export const getAllCategoryList = () => {
    let formData = new URLSearchParams();    //formdata object
    return dispatch => {
        return fetch(config.category_articles_all, {
            method: 'POST',
    
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {

                // console.log(data, 'data89898')
                if (data.status === 1) {
                    // alert()
                    dispatch(sportsCategoryList(data.data[0].sports));
                    dispatch(travelCategoryList(data.data[1].lifestyle));

                    dispatch(eSportsCategoryList(data.data[2].culture));
                    dispatch(reviewCategoryList(data.data[3].review));
                } else {
                    dispatch(sportsCategoryList([]));
                }
            })


    };
};


export const getExclusiveCategoryList = (data) => {
    const { user_id, page_no, slug, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.category_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(exclusiveCategoryList(data.data));
                } else {
                    dispatch(exclusiveCategoryList([]));
                }
            })


    };
};

export const getWhatsHappeningList = (data) => {
    const { user_id, page_no, limit } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('widget', 'home_widget')
    return dispatch => {
        return fetch(config.what_happening_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                
                dispatch(whatsHappeningList([]));
                if (data.status === 1) {
                    dispatch(whatsHappeningList(data.data));
                } else {
                    dispatch(whatsHappeningList([]));
                }
            })


    };
};

export const getReelArticlesList = (data) => {
    const { user_id, page_no, slug, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(reelArticlesList(responseData.data));
                } else {
                    dispatch(reelArticlesList([]));
                }
            })


    };
};

export const getTHGTvList = (data) => {
    const { user_id, page_no, slug, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('slug', slug);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(THGTvList(responseData.data));
                } else {
                    dispatch(THGTvList([]));
                }
            })


    };
};

export const getCoachList = (data) => {
    const { user_id, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.coach_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(coachListsHome(responseData.data))
                } else {
                    dispatch(coachListsHome([]))
                }
            })


    };
};

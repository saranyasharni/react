import config from './common/Api_Links'

export const updateSubscribedEventList = (data) => ({
    type: 'UPDATE_SUBSCRIBED_EVENT_LIST',
    data
});

export const pendingArticleList = (data) => ({
    type: 'PENDING_ARTICLES',
    data
});

export const publishArticleList = (data) => ({
    type: 'PUBLISH_ARTICLES',
    data
});

export const updateSubscriptionEventPageNo = (data) => ({
    type: 'UPDATE_SUBSCRIPTION_EVENT_PAGE_NO',
    data
});

export const updatePublishPageNo = (data) => ({
    type: 'UPDATE_PUBLISH_PAGE_NO',
    data
});

export const updatePendingPageNo = (data) => ({
    type: 'UPDATE_PENDING_PAGE_NO',
    data
});

export const moreSubscribedEventList = (data) => ({
    type: 'MORE_SUBSCRIBED_EVENT_LIST',
    data
});

export const morePublishArticleList = (data) => ({
    type: 'MORE_PUBLISH_ARTICLES',
    data
});

export const morePendingArticleList = (data) => ({
    type: 'MORE_PENDING_ARTICLES',
    data
});

export const changePendingStatus = (data) => ({
    type: 'CHANGE_PENDING_STATUS',
    data
});

export const updateArticleMoreStatus = (data) => ({
    type: 'UPDATE_ARTICLE_MORE_STATUS',
    data
});

export const getSubscribedEventList = (data) => {
    const { user_id, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.get_subscribed_event_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(updateSubscribedEventList(responseData.subscribedEventLists))
                } else {
                    dispatch(updateSubscribedEventList([]))
                }
            })


    };
};

export const moreSubscribedEventListAction = (data) => {
    const { user_id, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    // formData.append('post_status', post_status);
    return dispatch => {
        return fetch(config.get_subscribed_event_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(moreSubscribedEventList(responseData.subscribedEventLists))
                }
            })


    };
};
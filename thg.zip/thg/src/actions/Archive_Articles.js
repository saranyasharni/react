import config from './common//Api_Links'

export const archiveArticlesList = (data) => ({
    type: 'ARCHIVE_ARTICLES_LIST',
    data
});

export const newArchiveArticlesList = (data) => ({
    type: 'NEW_ARCHIVE_LIST',
    data
});

export const updateCoachPageNo = (data) => ({
    type: 'UPDATE_COACH_PAGE_NO',
    data
});

export const updateCoachDetails = (data) => ({
    type: 'UPDATE_COACH_DETAILS',
    data
});

export const getArchiveArticlesList = (data) => {
    const { user_id, slug, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('slug', slug);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(archiveArticlesList(responseData.data))
                } else {
                    dispatch(archiveArticlesList([]))
                }
            })


    };
};

export const getNewArchiveList = (data) => {
    const { user_id, slug, page_no, limit } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('slug', slug);
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(newArchiveArticlesList(responseData.data))
                } else {
                    dispatch(newArchiveArticlesList([]))
                }
            })


    };
};
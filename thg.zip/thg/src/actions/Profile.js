import config from './common/Api_Links'

export const updatePassowrdErrors = (data) => {
    return {
        type: 'UPDATE_PASSWORD_ERRORS',
        data
    }
};

export const changeProfileInfo = (field, value) => {
    return {
        type: 'CHANGE_PROFILE_INFO',
        field, value
    }
};

export const changePasswordInfo = (data) => {
    return {
        type: 'CHANGE_PASSWORD_INFO',
        data
    }
};

export const userProfile = (data) => {
    return {
        type: 'USER_PROFILE',
        data
    }
};

export const changeProfileStatus = (data) => ({
    type: 'PROFILE_STATUS',
    data
});

export const updateErrors = (data) => {
    return {
        type: 'UPDATE_ERRORS',
        data
    }
};

export const resetForm = (data) => {
    return {
        type: 'RESET_FORM',
        data
    }
};


export const userDetails = (data) => {
    return {
        type: 'USER_DETAILS',
        data
    }
};

export const freqList = (data) => {
    return {
        type: 'FREQ_LIST',
        data
    }
};

export const categorySubCategoryList = (data) => {
    return {
        type: 'CATEGORY_LIST',
        data
    }
};

export const getUserProfile = (data) => {
    const { user_id } = data;

    return dispatch => {
        return fetch(config.user_profile + user_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    let profile = responseData.profileResult[0];
                    let field = '';
                    let values = '';
                    if (profile.field_name !== null && profile.user_value !== null) {
                        field = profile.field_name.split(',')
                        values = profile.user_value.split(',')
                    }
                    // console.log(field, 'fieldBefore')
                    // console.log(values, 'valuesBefore')
                    profile = { ...profile, interested_in: (profile.interested_in === 'undefined' || profile.interested_in === null || profile.interested_in === '' || profile.interested_in === undefined) ? [] : (profile.interested_in).split(','), 
                    mobile_no: values[field.indexOf('Phone Number')],
                    gender_id: values[field.indexOf('Gender')], 
                    date_of_birth: values[field.indexOf('Date of Birth')], 
                    // subscribe : values[field.indexOf("Subscribe")],
                    frequency_id: values[field.indexOf('Frequency')] 
                    }
                // console.log(profile, 'after')
                    dispatch(userProfile(profile))
                }
            })


    };
};

export const updateProfile = (data) => {
    // console.log(data, 'data')
    // if (data.subscribed === 0) {
    //     data.interested_in = 0
    // }

    const { user_id, first_name, last_name, user_email, password, description, mobile_no, gender_id, date_of_birth, frequency_id, interested_in, subscribed } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('first_name', first_name);   //append the values with key, value pair
    formData.append('last_name', last_name);
    formData.append('email', user_email);
    formData.append('password', password);
    formData.append('description', description);   //append the values with key, value pair
    formData.append('mobile_no', mobile_no);
    formData.append('gender_id', gender_id);
    formData.append('date_of_birth', date_of_birth);
    formData.append('frequency_id', frequency_id);
    formData.append('interested_in', interested_in);
    // formData.append('subscribed', subscribed);

    return dispatch => {
        return fetch(config.user_profile + user_id, {
            method: 'PUT',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getUserProfile(data))
                    dispatch(changeProfileStatus(1))
                } else {
                    dispatch(changeProfileStatus(3))
                }
            })
            .catch(() => {
                dispatch(changeProfileStatus(3))
            })


    };
};

export const changePassword = (data) => {
    const { user_id, new_password } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('new_password', new_password);
    return dispatch => {
        return fetch(config.change_password, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changeProfileStatus(4))
                } else {
                    dispatch(changeProfileStatus(3))
                }
            })


    };
};

export const uploadProfile = (data) => {
    const { user_id, upload_file, image_id } = data;
    let formData = new FormData();
    formData.append('upload_file', upload_file);
    return dispatch => {
        return fetch(config.profile_upload_to_s3_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    if (image_id === null || image_id === undefined || image_id === '' || image_id === 'undefined') {
                        dispatch(createProfilePicture({ user_id: user_id, profile_image_link: responseData.file_links_data[0].original_data }))
                    } else {
                        dispatch(editProfilePicture({ user_id: user_id, profile_image_link: responseData.file_links_data[0].original_data, image_id: image_id }))
                    }

                } else {
                    dispatch(changeProfileStatus(3))
                }
            })


    };
};

export const createProfilePicture = (data) => {
    const { user_id, profile_image_link } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('profile_image_link', profile_image_link);
    return dispatch => {
        return fetch(config.upload_profile, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getUserProfile(data))
                    dispatch(changeProfileStatus(2))
                } else {
                    dispatch(changeProfileStatus(3))
                }
            })


    };
};

export const editProfilePicture = (data) => {
    const { user_id, profile_image_link, image_id } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('profile_image_link', profile_image_link);
    formData.append('image_id', image_id);
    return dispatch => {
        return fetch(config.edit_profile, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getUserProfile(data))
                    dispatch(changeProfileStatus(2))
                } else {
                    dispatch(changeProfileStatus(3))
                }
            })


    };
};

export const deleteProfilePicture = (data) => {
    const { user_id, image_id } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('image_id', image_id);
    return dispatch => {
        return fetch(config.delete_profile, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(getUserProfile(data))
                    dispatch(changeProfileStatus(1))
                } else {
                    dispatch(changeProfileStatus(3))
                }
            })


    };
};

export const getFrequencyList = (data) => {

    return dispatch => {
        return fetch(config.get_frequency_list, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    let list_data = responseData.data;
                    let list_data_arr = list_data.filter(function(item) {
                        
                        if (item.value_name === 'Weekly Once') {
                           
                            item.value_name = 'Weekly'
                        }
                        return item.value_name !== 'Three Days Once'
                    })
                    // console.log(list_data_arr, 'TTTTTTTTT')
                    dispatch(freqList(list_data_arr))
                }
            })


    };
};

export const getCategoryList = () => {

    return dispatch => {
        return fetch(config.category_subcategory_list, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                
                if (responseData.status === 1) {
                    //console.log('response', responseData.data)
                    let catLists = responseData.data;
                    // console.log("catLists", catLists);
                    let commentArr = ['whats_happening'];
                    let displayArr = [];
                    catLists.map(o => {
                        if(commentArr.includes(o.slug) === false)
                            displayArr.push(o);
                    })
                    
                    dispatch(categorySubCategoryList(displayArr))
                } else {
                    dispatch(categorySubCategoryList(responseData.data))
                }
            })


    };
};




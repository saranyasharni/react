import config from './common/Api_Links'

export const whatsHappenDetail = (data) => ({
    type: 'WHATS_HAPPEN_DETAIL',
    data
});

export const whatshappenEventList = (data) => ({
    type: 'WHATS_HAPPEN_FEATURED_EVENT_LIST',
    data
});

export const setLoading = (data) => ({
    type: 'SET_LOADING',
    data
});

export const whatsHappenArticleDetail = (data) => {
    const { user_id, article_id, slug, cat_slug} = data
    let formData = new URLSearchParams();    //formdata object
    
    return dispatch => {
        dispatch(setLoading(true));
        if (localStorage.categories) {
            window
            .jQuery(`.${localStorage.getItem("categories")}-nav `)
            .addClass("active");
        }
        let urlParams = new URLSearchParams(); 
        urlParams.append("user_id", user_id); //append the values with key, value pair
        urlParams.append("page_no", 1);
        urlParams.append("limit", 1);
        urlParams.append("slug", cat_slug);
        return fetch(config.article_detail, {
            method: "POST",
            body: urlParams,
            headers: {
              "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
              authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
            },
        }).then(response => {
            if (response.status === 200) {
                return response.json();
            }
        }).then(response => {
            if (response.status === 1) {
                
                let postID = response.data[0].ID
                document.title = response.data[0].post_title
                
                dispatch(getEventDetailByID({
                    event_id:postID,
                    user_id:user_id,
                    slug:slug
                }))
            }
        })
    };
};

export const getEventDetailByID = (data) => {
    //console.log(data, 'databyId')
    
    return dispatch => {
        let formData = new URLSearchParams(); 

        formData.append('user_id', data.user_id);   //append the values with key, value pair
        formData.append('article_id', data.event_id);
        formData.append('slug', data.slug);
        return fetch(config.whats_happen_article_detail, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
        .then(response => {
            if (response.status === 200) {
                return response.json();

            }
        })
        .then(responseData => {
            // console.log(responseData, 'RES!@#')
            if (responseData.status === 1) {
            
                dispatch(whatsHappenDetail(responseData.data));
                dispatch(setLoading(false));
            } else {
                dispatch(whatsHappenDetail([]));
                dispatch(setLoading(false));
            }
        })

    }
}

export const getWhatsHappenFeaturedEvents = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        
        return fetch(config.what_happening_articles_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                dispatch(whatshappenEventList([]));
                if (data.status === 1) {
                    data.data.forEach((e, j) => {
                        let start_date = e.start_date_and_time;
                        let end_date = e.end_date_and_time;
                        if (start_date.length > 0) {
                            start_date.forEach((element, i) => {
                                if (end_date[i]) {
                                    start_date[i] = element+ ' - ' + end_date[i];
                                }
                            });
                        }
                        
                        e.start_date_and_time = start_date ? start_date : new Date();
                    });
                    
                    dispatch(whatshappenEventList(data.data));
                } else {
                    dispatch(whatshappenEventList([]));
                }
            })


    };
};

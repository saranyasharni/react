import config from './common/Api_Links'
import jQuery from 'jquery';

let _ = require('lodash');

export const surveyQuestionList = (data) => ({
    type: 'SURVEY_QUESTIONS',
    data
});


export const getSurveyQuestionList = () => {
    return dispatch => {
        return fetch(config.survey_questions, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(surveyQuestionList(responseData.result))
                } else {
                    dispatch(surveyQuestionList([]))
                }
            })


    };
};
export const survayStatus = (data) => ({
    type: 'SURVAY_STATUS',
    data
});

export const createSubmitSurvay = (data) => {
    const { user_id, question_id, answer_id, ip } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('question_id', question_id);
    formData.append('answer_id', answer_id);
    formData.append('ip', ip);
    return dispatch => {
        return fetch(config.submit_survey_answer, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(survayStatus(1));
                } else {
                    dispatch(survayStatus(2));
                }
            })


    };
};

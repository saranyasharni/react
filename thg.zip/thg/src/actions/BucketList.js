import config from './common/Api_Links'

export const threeBucketLists = (data) => ({
    type: 'THREE_BUCKET_LIST',
    data
});

export const editBucketItem = (data) => ({
    type: 'EDIT_BUCKET_ITEM',
    data
});

export const editBucketStatus = (data) => ({
    type: 'EDIT_BUCKET_STATUS',
    data
});

export const showHide = (data) => ({
    type: 'SHOW_HIDE_BTN',
    data
});

export const get3BucketList = (data) => {
    const { user_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    return dispatch => {
        return fetch(config.get_bucket_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(threeBucketLists(responseData.bucketLists))
                }
            })


    };
};


export const editBucket = (data) => {
    const { bucket_id, bucket_name } = data;
    let formData = new URLSearchParams();    //formdata object
    let user_id = localStorage.user_id ? localStorage.getItem('user_id') : 0
    formData.append('bucket_id', bucket_id);
    formData.append('bucket_name', bucket_name);
    formData.append('user_id', user_id);
    return dispatch => {
        return fetch(config.edit_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                
                if (responseData.status === 1) {
                    
                    dispatch(editBucketStatus(1));
                    dispatch(get3BucketList({ user_id: localStorage.getItem('user_id') }))
                } else if (responseData.status === 0){
                    dispatch(editBucketStatus(3));
                } else {
                    dispatch(editBucketStatus(2));
                }
            })


    };
};


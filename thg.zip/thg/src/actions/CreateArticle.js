import config from './common/Api_Links'

import jQuery from 'jquery'

export const changeArticleInfo = (field, value) => {
    return {
        type: 'CHANGE_ARTICLE_INFO',
        field, value
    }
};

export const changeArticleStatus = (data) => ({
    type: 'ARTICLE_STATUS',
    data
});

export const changeEditStatus = (data) => ({
    type: 'EDIT_STATUS',
    data
});

export const resetCreateArticleForm = (data) => {
    return {
        type: 'RESET_ARTICLE_FORM',
        data
    }
};

export const updateCreateArticleErrors = (data) => {
    return {
        type: 'UPDATE_ARTICLE_ERRORS',
        data
    }
};

export const editArticleDetails = (data) => {
    return {
        type: 'EDIT_ARTICLE_DETAIIL',
        data
    }
};

export const categorySubCategoryList = (data) => {
    return {
        type: 'CATEGORY_LIST',
        data
    }
};


export const uploadArticleImage = (data) => {
    const { upload_file, flag } = data;
    let formData = new FormData();
    formData.append('upload_file', upload_file);
    return dispatch => {
        return fetch(config.profile_upload_to_s3_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    // console.log('image', responseData)
                    if (flag === 0) {
                        dispatch(changeArticleInfo('s3_image_upload_link', responseData.file_links_data[0].original_data))
                        jQuery('.loader-pro').addClass('d-none')
                        jQuery('.loader-pro').removeClass('d-block')
                        jQuery('.img-wrap').removeClass('d-none')
                        jQuery('.img-wrap').addClass('d-block')
                    } else if (flag === 1) {
                        dispatch(changeArticleInfo('video_file', responseData.file_links_data[0].original_data))
                        jQuery('.video-upload-element').html('Choose Video File')
                    }


                }
            })


    };
};

export const createArticle = (data) => {
    const { user_id, article_title, article_content, s3_image_upload_link, category_ids, custom_s3_video_link, custom_video_file,credit_video,credit_image } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('s3_image_upload_link', s3_image_upload_link);
    formData.append('article_title', article_title); //append the values with key, value pair
    formData.append('article_content', article_content);
    formData.append('custom_s3_video_link', custom_s3_video_link); //append the values with key, value pair
    formData.append('custom_video_file', custom_video_file);
    formData.append('category_ids', JSON.stringify(category_ids));
    formData.append('featured_image_credit_line', credit_image);
    formData.append('featured_video_credit_line', credit_video);
    
    return dispatch => {
        return fetch(config.create_article, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('response', responseData)
                if (responseData.status === 1) {
                    // dispatch(getUserProfile(data))
                    dispatch(changeArticleStatus(1))
                } else {
                    dispatch(changeArticleStatus(2))
                }
            })


    };
};

export const editArticle = (data) => {
    const { article_id, user_id, article_title, article_content, s3_image_upload_link, category_ids, custom_s3_video_link, custom_video_file, post_status,credit_image,credit_video } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('article_id', article_id);
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('s3_image_upload_link', s3_image_upload_link);
    formData.append('article_title', article_title); //append the values with key, value pair
    formData.append('article_content', article_content);
    formData.append('custom_s3_video_link', custom_s3_video_link); //append the values with key, value pair
    formData.append('custom_video_file', custom_video_file);
    formData.append('category_ids', JSON.stringify(category_ids));
    formData.append('post_status', post_status);
    formData.append('featured_image_credit_line', credit_image);
    formData.append('featured_video_credit_line', credit_video);
    return dispatch => {
        return fetch(config.edit_article, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('responseEDIT', responseData)
                if (responseData.status === 1) {
                    // dispatch(getUserProfile(data))
                    dispatch(changeEditStatus(1))
                } else {
                    dispatch(changeEditStatus(2))
                }
            })


    };
};

export const scheduleForLater = (data) => {
    const { user_id, article_title, article_content, s3_image_upload_link, category_ids, custom_s3_video_link, custom_video_file,credit_video,credit_image } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id); //append the values with key, value pair
    formData.append('s3_image_upload_link', s3_image_upload_link);
    formData.append('article_title', article_title); //append the values with key, value pair
    formData.append('article_content', article_content);
    formData.append('custom_s3_video_link', custom_s3_video_link); //append the values with key, value pair
    formData.append('custom_video_file', custom_video_file);
    formData.append('category_ids', JSON.stringify(category_ids));
    formData.append('feat_img_credit_text', credit_image);
    formData.append('feat_video_credit_text', credit_video);
    
    return dispatch => {
        return fetch(config.schedule_for_later, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log('response', responseData)
                if (responseData.status === 1) {
                    // dispatch(getUserProfile(data))
                    dispatch(changeArticleStatus(1))
                } else {
                    dispatch(changeArticleStatus(2))
                }
            })


    };
};

export const getArticleDetailById = (data) => {
    const { user_id, page_no, limit, slug } = data;
    let formData = new URLSearchParams();    //formdata object
    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.edit_article_detail, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    var resData = responseData.data[0]
                    if (resData.ID !== null) {
                        // console.log(resData, 'resData89')
                        var regex =  /(\d+)(_)/g;
                        let replaceFile = resData.custom_video_link !== null && resData.custom_video_link.split('/')[3] !== undefined 
                        
                        ?resData.custom_video_link.split('/')[3].replace(regex, '') : ''
                        var editData = {
                            article_id: resData.ID,
                            article_title: resData.post_title,
                            article_content: resData.post_content,
                            category_ids: resData.cat_ids.split(','),
                            s3_image_upload_link: (resData.custom_feature_image_url === '' || resData.custom_feature_image_url === undefined || resData.custom_feature_image_url === null) ? resData.image_url : resData.custom_feature_image_url,
                            video_link: resData.custom_s3_video_link,
                            video_file_name: replaceFile,
                            credit_text : resData.feat_img_credit_text,
                            credit_text_video : resData.feat_video_credit_text
                            //video_original_data : resData.custom_video_link
                        }
                    }
                    
                    dispatch(editArticleDetails(editData));

                }
            })


    };
};

export const getCategoryList = () => {
        
    return dispatch => {
        return fetch(config.category_subcategory_list, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    let catLists = responseData.data;
                    
                    //console.log("catLists", catLists);
                    let commentArr = ['whats_happening','featured-events', 'thg-tv'];
                    let displayArr = [];
                    catLists.map(o => {
                     
                        if(commentArr.includes(o.slug) === false)
                            displayArr.push(o);
                        if (o.slug === 'reel') {
                            let value = 'top-picks';
                        
                            o.sub_categories = o.sub_categories.filter(function(item) {
                                return item.slug !== value
                            })
                            //console.log(subArr, 'came789')
                        }
                    })
                    
                    dispatch(categorySubCategoryList(displayArr))
                } else {
                    dispatch(categorySubCategoryList(responseData.data))
                }
            })


    };
};




import config from './Api_Links'

export const saveQuickLinks = (data) => ({
    type: 'QUICK_LINKS',
    data
});

export const changeSubscribeFooterInfo = (field, value) => {
    return {
        type: 'CHANGE_SUBSCRIBE_FOOTER_INFO',
        field, value
    }
};

export const changeSubscribeFooterStatus = (data) => ({
    type: 'SUBSCRIBE_FOOTER_STATUS',
    data
});

export const resetFooterSubscribeForm = (data) => {
    return {
        type: 'RESET_FOOTER_SUBSCRIBE_FORM',
        data
    }
};

export const changeSubscribeFooterErrors = (data) => {
    return {
        type: 'UPDATE_SUBSCRIBE_FOOTER_ERRORS',
        data
    }
};

export const aboutUs = (data) => {
    return {
        type: 'ABOUT_US',
        data
    }
}
export const Career = (data) => {
    return {
        type: 'CAREER',
        data
    }
}
export const ContributeToTHG = (data) => {
    return {
        type: 'CONTRIBUTETOTHG',
        data
    }
}

export const setAdvertiseWithUs = (data) => {
    return {
        type: 'ADVERTISE_WITH_US',
        data
    }
}

export const setTermsData = (data) => {
    return {
        type: 'SET_TERMS_DATA',
        data
    }
}

export const setPrivacyData = (data) => {
    return {
        type: 'SET_PRIVACY_DATA',
        data
    }
}

export const setReachUs = (data) => {
    return {
        type: 'SET_REACH_US',
        data
    }
}
export const setDataProtection = (data) => {
    return {
        type: 'SET_DATA_PROTECTION',
        data
    }
}
export const Contribute = (data) => {
    return {
        type: 'SET_CONTRIBUTE',
        data
    }
}
export const makeTHG = (data) => {
    return {
        type: 'MAKE_THG',
        data
    }
}


export const getAllQuickLinks = () => {
    
    return dispatch => {
        return fetch(config.quick_links, {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    // alert()
                    // let arr = responseData.data.filter()
                    // console.log(responseData.data, 'quickLinks')
                    dispatch(saveQuickLinks(responseData.data))

                } else {
                    dispatch(saveQuickLinks([]))
                }

            })


    };
};

export const footerSubscribeWithUs = (data) => {
    const { fullName, email } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('full_name', fullName);   //append the values with key, value pair
    formData.append('email', email);
    return dispatch => {
        return fetch(config.subscribe, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(changeSubscribeFooterStatus(1))
                } else if (responseData.message.includes('Duplicate')) {
                    dispatch(changeSubscribeFooterStatus(2))
                } else {
                    dispatch(changeSubscribeFooterStatus(3))
                }
            })
    };
};

export const getAboutUsData = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(aboutUs(responseData.data))
                } else {
                    dispatch(aboutUs([]))
                }
            })
    };
};

export const getAdvertiseWithUs = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(setAdvertiseWithUs(responseData.data))
                } else {
                    dispatch(setAdvertiseWithUs([]))
                }
            })
    };
};

export const getTermsData = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(setTermsData(responseData.data))
                } else {
                    dispatch(setTermsData([]))
                }
            })
    };
};

export const getPrivacyData = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(setPrivacyData(responseData.data))
                } else {
                    dispatch(setPrivacyData([]))
                }
            })
    };
};

export const getReachUs = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(setReachUs(responseData.data))
                } else {
                    dispatch(setReachUs([]))
                }
            })
    };
};

export const getDataProtection = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(setDataProtection(responseData.data))
                } else {
                    dispatch(setDataProtection([]))
                }
            })
    };
};
export const getCareer = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(Career(responseData.data))
                } else {
                    dispatch(Career([]))
                }
            })
    };
};
export const getContributeToTHG = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(ContributeToTHG(responseData.data))
                } else {
                    dispatch(ContributeToTHG([]))
                }
            })
    };
};
export const getContribute = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(Contribute(responseData.data))
                } else {
                    dispatch(Contribute([]))
                }
            })
    };
};
export const getMakeThg = (data) => {
    let formData = new URLSearchParams();    //formdata object

    formData.append('page_slug', data);   //append the values with key, value pair
    
    return dispatch => {
        return fetch(config.list_page_details, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(makeTHG(responseData.data))
                } else {
                    dispatch(makeTHG([]))
                }
            })
    };
};
import config from './Api_Links'

export const registration = (data) => ({
    type: 'REGISTRATION',
    data
});

export const inputChange = (field, value) => {
    return {
        type: 'INPUT_CHANGE',
        field, value
    }
};

export const bucketItemChange = (field, value) => {
    return {
        type: 'BUCKET_ITEM_CHANGE',
        field, value
    }
};

export const bucketLists = (data) => ({
    type: 'BUCKET_LIST',
    data
});

export const updateErrors = (data) => {
    return {
        type: 'UPDATE_ERRORS',
        data
    }
};

export const resetForm = (data) => {
    return {
        type: 'RESET_FORM',
        data
    }
};

export const userDetails = (data) => {
    return {
        type: 'USER_DETAILS',
        data
    }
};

export const articleBucketStatus = (data) => {
    return {
        type: 'ARTICLE_BUCKET_STATUS',
        data
    }
};

export const articleBucketErrorStatus = (data) => {
    return {
        type: 'ARTICLE_BUCKET_ERROR_STATUS',
        data
    }
};

export const registrationStatus = (data) => {
    return {
        type: 'REGISTRATION_STATUS',
        data
    }
};

export const loginStatus = (data) => {
    return {
        type: 'LOGIN_STATUS',
        data
    }
};

export const sportsSubCategoryList = (data) => ({
    type: "SPORTS_SUB_CATEGORY_LIST",
    data,
});

export const EsportsSubCategoryList = (data) => ({
    type: "ESPORTS_SUB_CATEGORY_LIST",
    data,
})

export const travelSubCategoryList = (data) => ({
    type: "TRAVEL_SUB_CATEGORY_LIST",
    data,
})

export const reviewSubCategoryList = (data) => ({
    type: "REVIEW_SUB_CATEGORY_LIST",
    data,
})

export const categoryList = (data) => ({
    type: "CATEGORY_LISTS_HEADER",
    data,
})

export const createUser = (data) => {
    const { first_name, last_name, email_id, password, subscribe_value, user_type, google_pid, fb_pid } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('first_name', first_name);   //append the values with key, value pair
    formData.append('last_name', last_name);
    formData.append('email_id', email_id);
    formData.append('password', password);
    formData.append('subscribe_value', subscribe_value);   //append the values with key, value pair
    formData.append('user_type', user_type);
    formData.append('google_pid', google_pid);
    formData.append('fb_pid', fb_pid);
    return dispatch => {
        return fetch(config.registration, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200 || response.status === 422) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    
                    dispatch(registration(true))
                    localStorage.setItem('registered_id', (user_type === 0) ? responseData.userResult.userId : responseData.userResult[0].ID)
                } else if (responseData.message === 'User Already exist!!!') {
                    
                    dispatch(registrationStatus(1))
                } else {
                    
                    dispatch(registrationStatus(4))
                }
            })
            .catch((err) => {
                dispatch(registrationStatus(4))
            })


    };
};

export const addInterestedByUser = (data) => {
    const { user_id, interested_in } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('interested_in', interested_in);
    return dispatch => {
        return fetch(config.interested_by_user, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(registrationStatus(2))

                } else {
                    dispatch(registrationStatus(3))
                }

            })


    };
};

export const loginUser = (data) => {
    const { first_name, last_name, email_id, password, subscribe_value, user_type, google_pid, fb_pid } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('first_name', first_name);   //append the values with key, value pair
    formData.append('last_name', last_name);
    formData.append('email_id', email_id);
    formData.append('password', password);
    formData.append('subscribe_value', subscribe_value);   //append the values with key, value pair
    formData.append('user_type', user_type);
    formData.append('google_pid', google_pid);
    formData.append('fb_pid', fb_pid);
    return dispatch => {
        return fetch(config.login, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200 || response.status === 422) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1 && responseData.userResult[0] && responseData.userResult[0].ID) {
                    dispatch(loginStatus(1))
                    
                    dispatch(userDetails(responseData.userResult))
                    localStorage.setItem('user_id', responseData.userResult[0].ID)
                    localStorage.setItem('user_displayname', responseData.userResult[0].display_name)
                    localStorage.setItem('user_nicename', responseData.userResult[0].user_nicename)
                    localStorage.setItem('user_firstname', responseData.userResult[0].first_name)
                    localStorage.setItem('user_lastname', responseData.userResult[0].last_name)
                    localStorage.setItem('user_login', responseData.userResult[0].user_login)
                    localStorage.setItem('user_email', responseData.userResult[0].user_email)
                    localStorage.setItem('contributor', responseData.userResult[0].wp_capabilities.contributor)
                } else if (responseData.message && responseData.message === 'Invalid Username and Password') {
                    dispatch(loginStatus(2))
                } else {
                    
                    dispatch(loginStatus(5))
                }
            }).catch(() => {
                dispatch(loginStatus(5))
            })


    };
};

export const addArticleToBucket = (data) => {
    const { user_id, bucket_id, article_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('bucket_id', bucket_id);
    formData.append('article_id', article_id);
    return dispatch => {
        return fetch(config.add_article_to_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(articleBucketStatus(1))
                }
                else {
                    dispatch(articleBucketErrorStatus(1))
                }
            })


    };
};

export const removeArticleFromBucket = (data) => {
    const { user_id, bucket_id, article_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('bucket_id', bucket_id);
    formData.append('article_id', article_id);
    return dispatch => {
        return fetch(config.remove_article_from_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(articleBucketStatus(2))
                }
                else {
                    dispatch(articleBucketErrorStatus(2))
                }
            })


    };
};

export const createBucket = (data) => {
    const { user_id, bucket_name } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    formData.append('bucket_name', bucket_name);
    return dispatch => {
        return fetch(config.create_bucket, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(articleBucketStatus(3))
                    dispatch(getBucketList(data))
                } else {
                    if (responseData.status === 0) {
                        dispatch(articleBucketErrorStatus(4))
                    } else {

                        dispatch(articleBucketErrorStatus(3))
                    }
                }
            })


    };
};

export const getBucketList = (data) => {
    const { user_id } = data;
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);
    return dispatch => {
        return fetch(config.bucket_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                if (responseData.status === 1) {
                    dispatch(bucketLists(responseData.data))
                }
            })


    };
};

export const getSportsSubCategoryList = (data) => {
    const { user_id, page_no, slug } = data;
    let formData = new URLSearchParams(); //formdata object
  
    formData.append("user_id", user_id); //append the values with key, value pair
    formData.append("page_no", page_no);
    formData.append("slug", slug);
    return (dispatch) => {
      dispatch(sportsSubCategoryList([]));
      return fetch(config.sub_category_list, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
        },
      })
        .then((response) => {
          if (response.status === 200) {
            return response.json();
          }
        })
        .then((responseData) => {
          if (responseData.status === 1) {
            localStorage.setItem(
              "category",
              responseData.data[0].name.toLowerCase()
            );
            // window
            //   .jQuery(`.${responseData.data[0].name.toLowerCase()}-nav `)
            //   .addClass("active");
    
            dispatch(sportsSubCategoryList(responseData.data));
          } else {
            dispatch(sportsSubCategoryList([]));
          }
        });
    };
  };

    export const getEsportsSubCategoryList = (data) => {
    const { user_id, page_no, slug } = data;
    let formData = new URLSearchParams(); //formdata object
  
    formData.append("user_id", user_id); //append the values with key, value pair
    formData.append("page_no", page_no);
    formData.append("slug", slug);
    return (dispatch) => {
        dispatch(sportsSubCategoryList([]));
        return fetch(config.sub_category_list, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
        },
        })
        .then((response) => {
          if (response.status === 200) {
            return response.json();
          }
        })
        .then((responseData) => {
          if (responseData.status === 1) {
            localStorage.setItem(
              "category",
              responseData.data[0].name.toLowerCase()
            );
            // window
            //   .jQuery(`.${responseData.data[0].name.toLowerCase()}-nav `)
            //   .addClass("active");
    
            dispatch(EsportsSubCategoryList(responseData.data));
          } else {
            dispatch(EsportsSubCategoryList([]));
          }
        });
    };
    };

    export const getTravelSubCategoryList = (data) => {
    const { user_id, page_no, slug } = data;
    let formData = new URLSearchParams(); //formdata object
  
    formData.append("user_id", user_id); //append the values with key, value pair
    formData.append("page_no", page_no);
    formData.append("slug", slug);
    return (dispatch) => {
      dispatch(travelSubCategoryList([]));
      return fetch(config.sub_category_list, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
        },
      })
        .then((response) => {
          if (response.status === 200) {
            return response.json();
          }
        })
        .then((responseData) => {
          if (responseData.status === 1) {
            localStorage.setItem(
              "category",
              responseData.data[0].name.toLowerCase()
            );
            dispatch(travelSubCategoryList(responseData.data));
          } else {
            dispatch(travelSubCategoryList([]));
          }
        });
    };
  };

  export const getSubCategoryReview = (data) => {
    const { user_id, page_no, slug } = data;
    let formData = new URLSearchParams(); //formdata object
  
    formData.append("user_id", user_id); //append the values with key, value pair
    formData.append("page_no", page_no);
    formData.append("slug", slug);
    return (dispatch) => {
      dispatch(reviewSubCategoryList([]));
      return fetch(config.sub_category_list, {
        method: "POST",
        body: formData,
        headers: {
          "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
        },
      })
        .then((response) => {
          if (response.status === 200) {
            return response.json();
          }
        })
        .then((responseData) => {
          if (responseData.status === 1) {
            localStorage.setItem(
              "category",
              responseData.data[0].name.toLowerCase()
            );
            dispatch(reviewSubCategoryList(responseData.data));
          } else {
            dispatch(reviewSubCategoryList([]));
          }
        });
    };
  };

    export const getMainCategory = () => {
    return (dispatch) => {
        return fetch(config.list_categories, {
            method: "POST",
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                authorization: "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ=",
            },
        })
        .then((response) => {
            if (response.status === 200) {
                return response.json();
            }
        })
        .then((responseData) => {
            dispatch(categoryList([]));
            if (responseData.status === 1) {
                let catLists = responseData.data;
                // console.log("catLists", catLists);
                // let commentArr = ['featured-events'];
                // let displayArr = [];
                // catLists.map(o => {
                //     if(commentArr.includes(o.slug) === false)
                //         displayArr.push(o);
                // })
                // dispatch(categoryList(displayArr));
                dispatch(categoryList(catLists));
            } else {
                dispatch(categoryList([]));
            }
        });
    };
  };

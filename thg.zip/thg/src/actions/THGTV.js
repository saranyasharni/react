import config from './common/Api_Links'

export const onThePitchList = (data) => ({
    type: 'ON_THE_PITCH_LIST',
    data
});

export const programmesList = (data) => ({
    type: 'PROGRAMMES_LIST',
    data
});

export const episodesList = (data) => ({
    type: 'EPISODES_LIST',
    data
});

export const bannerEpisode = (id) => ({
    type: 'BANNER_EPISODE',
    id
});

export const programmeStreamsList = (data) => ({
    type: 'PROGRAMME_STREAM_LIST',
    data
});

export const changeProgrammeId = (data) => ({
    type: 'UPDATE_PROGRAMME_ID',
    data
});

export const changeLiveStatus = (data) => ({
    type: 'UPDATE_LIVE_STATUS',
    data
});

export const newArchiveList = (data) => ({
    type: 'NEW_ARCHIVE_LIST',
    data
});

export const updatePageNo = (data) => ({
    type: 'UPDATE_PAGE_NO',
    data
});

export const updateArchiveStatus = (data) => ({
    type: 'UPDATE_ARCHIVE_STATUS',
    data
});

export const show_hide = (data) => ({
    type: 'SHOW_HIDE',
    data
});

export const getOnThePitchList = (data) => {
    
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    // alert()
                    // console.log(data.data ,'data.data')
                    dispatch(onThePitchList(data.data));
                } else {
                    dispatch(onThePitchList([]));
                }
            })


    };
};

export const getMoreOnThePitchList = (data) => {
    const { user_id, page_no, limit, slug } = data
    let formData = new URLSearchParams();    //formdata object

    formData.append('user_id', user_id);   //append the values with key, value pair
    formData.append('page_no', page_no);
    formData.append('limit', limit);
    formData.append('slug', slug);
    return dispatch => {
        return fetch(config.reel_article_list, {
            method: 'POST',
            body: formData,
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "authorization": "Basic dGhnYWRtaW46dGhncGFzc3dvcmQ="
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(data => {
                if (data.status === 1) {
                    dispatch(newArchiveList(data.data));
                } else {
                    dispatch(newArchiveList([]));
                }
            })
    };
};

export const getVideoStraming = () => {
    return dispatch => {
        // return fetch(config.stream_authorization, {
        //     method: 'POST',
        //     body: JSON.stringify({
        //         "email": "live2asia@espxmedia.com",
        //         "password": "espxLive2!1"
        //     }),
        //     headers: {
        //         "Content-type": "application/json; charset=UTF-8"
        //     }
        // })
        //     .then(response => {
        //         if (response.status === 201) {
        //             return response.json();

        //         }
        //     })
        //     .then(data => {
        //         if (data.token != '') {
                    dispatch(getAllCategories(''))
                    // dispatch(getAllProgrammeStreams(data.token, data.id));
            //     }
            // })


    };
};

export const getAllCategories = (token) => {
    return dispatch => {
        return fetch(config.get_categories_list, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                // console.log(responseData, 'responseDatatg')
                if (responseData.data) {
                    // console.log('categ', responseData.data.filter(item => { return item.name == "THG TV" })[0].id)
                // dispatch(getAllProgrammes(token, responseData.data.filter(item => { return item.name == "THG TV" })[0].id));
                let eventsData = responseData.data.filter(item => { return item.name == "THG TV" })[0]
                dispatch(programmesList(eventsData['Events']));
                let episodeId = eventsData['Events'][0]['id'];
                dispatch(bannerEpisodesList(token, episodeId))
                }
                
            })


    };
};


export const getAllProgrammes = (token, category_id) => {
    return dispatch => {
        return fetch(config.get_programmes_list + '?category_id =' + category_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(programmesList(responseData.data));
            })


    };
};

export const getAllProgrammeStreams = (token, user_id) => {
    return dispatch => {
        return fetch(config.get_programmestreams_list + '?created_by=' + user_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
                // "Authorization": token
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(programmeStreamsList(responseData.data));
            })


    };
};

export const getAllEpisodes = (data) => {
    
    const { event_id } = data
    return dispatch => {
        // return fetch(config.stream_authorization, {
        //     method: 'POST',
        //     body: JSON.stringify({
        //         "email": "live2asia@espxmedia.com",
        //         "password": "espxLive2!1"
        //     }),
        //     headers: {
        //         "Content-type": "application/json; charset=UTF-8"
        //     }
        // })
        //     .then(response => {
        //         if (response.status === 201) {
        //             return response.json();

        //         }
        //     })
        //     .then(data => {
        //         if (data.token != '') {
                    dispatch(getAllEpisodesList('', event_id))
                    // dispatch(getAllProgrammeStreams(data.token, data.id));
            //     }
            // })
    };
};

export const getAllEpisodesList = (token, event_id) => {
    
    return dispatch => {
        return fetch(config.get_event_programme_list + event_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",

            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                dispatch(episodesList(responseData.Programmes));
            })


    };
};

export const bannerEpisodesList = (token, event_id) => {
    return dispatch => {
        return fetch(config.get_event_programme_list + event_id, {
            method: 'GET',
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "x-app-id": "7386573047397500",
              
            }
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();

                }
            })
            .then(responseData => {
                let id = responseData.Programmes[0]['id']
                if (window.location.pathname.split('/')[2] === 'thg-tv') {
                    document.title = responseData.Programmes[0]['name']
                }
                
                dispatch(bannerEpisode(id));
            })


    };
};
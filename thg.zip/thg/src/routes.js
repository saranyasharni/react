import React, { Component, Fragment } from 'react'
import { BrowserRouter as Router, Switch, Route, withRouter } from "react-router-dom";
import ScrollTop from './ScrollTop'
import Home from "./containers/Home";
import notFound from "./components/notFound";
import Sports from "./containers/Sports";
import SubCategory from "./containers/SubCategory";
import Article_Detail from "./containers/Article_Detail";
import PrivateRoute from './PrivateRoute';
import Feature_Article_Detail from "./containers/Feature_Article_Detail";
import TGHTV from "./containers/THGTV";
import Reel from "./containers/Reel";
import Reel_Category from "./containers/Reel_Category";
import Whats_Happening from "./containers/Whats_Happening";
import Whats_Happening_Category from "./containers/Whats_Happening_Category";
import Review_Category from "./containers/Review_Category";
import Feature_Parent from "./containers/Feature_Parent";
import Coach_Listing from "./containers/Coach_Listing";
import Video_Detail from "./containers/Video_Detail";
import ThgTvDetail from "./containers/ThgTvDetail";
import OnThePitch from "./components/ThgTvSection/OnThePitchDetail";
import BucketList from './containers/BucketList';
import BucketListArticle from './containers/BucketListArticle';
import CreateArticle from './containers/CreateArticle';
import Profile from './containers/Profile';
import Settings from './containers/Settings';
import YourArticles from './containers/YourArticles';
import AdvertiseWithUs from './containers/AdvertiseWithUs';
import ContributeWithUs from './containers/ContributeWithUs';
import ReachUs from './containers/ReachUs';
import AboutUs from './containers/AboutUs';
import Career from './containers/Career';
import Subscribe from './containers/Subscribe';
import checktexteditor from './components/checktexteditor';
import DataProtectionPolicy from './containers/Data_Protection_Policy';
import TermsConditions from './containers/Terms_Conditions';
import HowWeMakeTHG from './containers/HowWeMakeTHG';
import Archive_Articles from './components/Archive_Articles';
import News from './containers/News';
import Feature_Category from './containers/Feature_Category';
import VaucherSubscribe from './containers/VaucherSubscribe';
import ContestSubmitEntry from './containers/ContestSubmitEntry';
import ContestGiveaway from './containers/ContestGiveaway';
import GiveawayProductDetail from './components/GiveAwayProductDetail';
import Search from './containers/Search';
import EventPhotos from './components/EventPhotos';
import EventVideos from './components/EventVideos';
// import HowWeMakeTHG from './components/HowWeMakeTHG';
import AllContestSubmission from './components/ViewAllSubmissions';
import EditorsPick from './components/EditorsPick';
import ContestWinner from './components/ContestWinner';
import GiveAwaytWinner from './components/GiveAwayWinners';
import ContributeToTHG from './containers/ContributeToTHG';
import Contribute from './containers/Contribute';
import EventEpisodes from './components/EventEpisodes';
import FeatureEventSection from './components/FeatureSection/LiveVideoSection';
import SubscribedEventList from './containers/SubscribedEventList';

class Routes extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }
    
    // componentWillMount = async () => {
    //     var pathname = window.location.pathname;
    //     if (pathname.split('/')[1] == 'whats_happening') {
    //         console.log('true')
    //         let apicall = await fetch(pathname + '?id=' + localStorage.getItem('article_id'));
    //         // let apicall = await fetch(pathname + '/' + localStorage.getItem('article_id'));
    //     }
    // }

    componentDidUpdate = async (prevProps) => {
        // console.log("prevProps.location", prevProps.location);
        // console.log("this.props.location", this.props.location);
        var pathname = this.props.location.pathname;
        // console.log('pathname', pathname.split('/'))
        let apicall = await fetch(pathname);
    }

    render() {
        return (
            <Fragment>
                <ScrollTop />
                <Switch>
                    <Route exact path="/" component={Home} />
                    <PrivateRoute exact path="/feature-live-stream/:evnt_id/:slug" component={FeatureEventSection} />
                    <Route exact path="/category/news" component={News} />
                    {/* <Route exact path="/category/sports" component={Sports} />
                    <Route exact path="/category/esports" component={Sports} />
                    <Route exact path="/category/travel" component={Sports} /> */}
                    <Route exact path="/category/thg-tv" component={TGHTV} />
                    <Route exact path="/category/reel" component={Reel} />
                    <Route exact path="/archive_articles" component={Archive_Articles} />
                    <Route exact path="/reel/:slug" component={Reel_Category} />
                    <Route exact path="/category/whats_happening" component={Whats_Happening} />
                    <Route exact path="/whats_happening/:slug" component={Whats_Happening_Category} />
                    {/* <Route exact path="/category/review" component={Sports} /> */}
                    <Route exact path="/review/:slug" component={Review_Category} />
                    
                    <Route exact path="/category/featured-events" component={Feature_Parent} />
                    <Route exact path="/category/featured-events/:slug" component={Feature_Parent} />
                    <Route exact path="/feature-event/:slug" component={Feature_Category} />
                    
                    <Route exact path="/category/coach_list" component={Coach_Listing} />
                    <Route exact path="/videodetail/:slug" component={Video_Detail} />
                    <Route exact path="/thgtvdetail/:slug/:subId" component={ThgTvDetail} />
                    <Route exact path="/onthepitch" component={OnThePitch} />
                    <Route exact path="/bookmarklist/:user" component={BucketList} />
                    <Route exact path="/bookmarkarticles/:bucket" component={BucketListArticle} />
                    <Route exact path="/createarticle/:user" component={CreateArticle} />
                    <Route exact path="/editarticle/:user" component={CreateArticle} />
                    <Route exact path="/profile/:user" component={Profile} />
                    <Route exact path="/settings/:user" component={Settings} />
                    <Route exact path="/yourarticles/:user" component={YourArticles} />
                    {/* <Route exact path="/event-subscription/:user" component={SubscribedEventList} /> */}
                    <Route exact path="/subscribe" component={Subscribe} />
                    <Route exact path="/contest" component={VaucherSubscribe} />
                    <Route exact path="/career" component={Career} />
                    <Route exact path="/contestsubmit/:post_id" component={ContestSubmitEntry} />
                    <Route exact path="/contestgiveaway/:post_id" component={ContestGiveaway} />
                    <Route exact path="/productDetail/:id" component={GiveawayProductDetail} />
                    {/* <Route exact path="/contribute-with-us" component={ContributeWithUs} /> */}
                    <Route exact path="/about-us" component={AboutUs} />
                    <Route exact path="/reach-us" component={ReachUs} />
                    <Route exact path="/advertise-with-us" component={AdvertiseWithUs} />
                    <Route exact path="/data-protection-policy" component={DataProtectionPolicy} />
                    <Route exact path="/terms-conditions" component={TermsConditions} />
                    <Route exact path="/how-we-make-THG" component={HowWeMakeTHG} />
                    <Route exact path="/contribute-to-THG" component={ContributeToTHG} />
                    <Route exact path="/search" component={Search} />
                    <Route exact path= "/all-submissions" component = {AllContestSubmission} />
                    <Route exact path= "/editors-pick" component = {EditorsPick} />
                    
                    <Route exact path= "/contest-winner" component = {ContestWinner} />
                    <Route exact path= "/giveaway-winner" component = {GiveAwaytWinner} />
                    <Route exact path="/events/photos/:id" component={EventPhotos} />
                    <Route exact path="/events/videos/:id" component={EventVideos} />
                    <Route exact path="/category/:slug" component={Sports} /> 
                    <Route exact path="/category/:slug/:subSlug" component={SubCategory} /> 
                    <Route exact path="/episodes/:slug/:subSlug" component={EventEpisodes} /> 
                    <Route exact path="/contribute-with-us" component={Contribute} />
                    
                    <Route exact path="/:slug" component={Article_Detail} />
                    <Route exact path="/feature/:slug" component={Feature_Article_Detail} />
                    
                    <Route component={notFound} />
                </Switch>
            </Fragment>
        )
    }
}

export default withRouter(Routes);






